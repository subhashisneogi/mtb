import os
import logging
from pathlib import Path
from dotenv import load_dotenv
from datetime import timedelta
from django.urls import reverse_lazy
load_dotenv()
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = 'django-insecure-9&9#$hs$ufk!ymt*dl0!p6hrqa8ed@y0yxw27=rv&gejv+8-sg'
DEBUG = True
ALLOWED_HOSTS = ['*']

REST_FRAMEWORK = {
	'DEFAULT_AUTHENTICATION_CLASSES': (
		'knox.auth.TokenAuthentication',
	),
	'DEFAULT_PERMISSION_CLASSES': (
		'rest_framework.permissions.IsAuthenticated',
		'rest_framework.permissions.AllowAny',
	),
    'UPLOADED_FILES_USE_URL': False,
}

# REST_KNOX = {
#   'SECURE_HASH_ALGORITHM': 'cryptography.hazmat.primitives.hashes.SHA512',
#   'AUTH_TOKEN_CHARACTER_LENGTH': 64,
#   'TOKEN_TTL': timedelta(minutes=int(str(os.getenv('TOKEN_ACTIVE_MINUTES','0')))),
#   'USER_SERIALIZER': 'knox.serializers.UserSerializer',
#   'TOKEN_LIMIT_PER_USER': None,
#   'AUTO_REFRESH': False,
# }

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    ############# Third Party Apps ########
    # 'ckeditor',  # pip install django-ckeditor
    # 'ckeditor_uploader',  # pip install django-ckeditor
    'rest_framework',
    'knox',
    "phonenumber_field",
    ############## My Apps ####################
    'master',
    'accounts',
    'user_profile',
    'tea_production',
    'chemical_data',
    'gardens_managment',
    'leaf_receipt',
    'vehicle_management',
    'collection_center',
    "weighment_supply",
    'invoicing',
    "lot_batch_details",
    "packaging",
    "easy_weight_master",
]

# AUTH_USER_MODEL = 'user_profile.TraceteaUser'

PHONENUMBER_DB_FORMAT = 'NATIONAL'
CKEDITOR_UPLOAD_PATH = "uploads/"
CKEDITOR_CONFIGS = {
    'special': {
        'toolbar': 'Special',
        'width': 'auto',
        'toolbar_Special': [
            ['Styles', 'Font','Format', 'Bold', 'Italic', 'Underline', 'Strike', 'SpellChecker', 'Undo'],
            ['Link', 'Unlink', 'Anchor','JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock'],
            ['Image', 'Flash', 'Table', 'HorizontalRule'],
            ['TextColor', 'BGColor'],
            ['Smiley', 'SpecialChar'], ['Source'],
        ],
    }
}
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',

    'master.middleware.RequestMiddleware',

    # 'chemical_data.middleware.GlobalAPIExceptionMiddleware',
]
ROOT_URLCONF = 'tracetea_backend.urls'
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / "templates"],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages', 
            ],
        },
    },
]
WSGI_APPLICATION = 'tracetea_backend.wsgi.application'
# Database
DATABASES = {
	'default': {
		'ENGINE': 'django.db.backends.mysql',
		'NAME': str(os.getenv('DATABASES_NAME','')),
		'USER': str(os.getenv('DATABASES_USER','')),
		'PASSWORD': str(os.getenv('DATABASES_PASSWORD','')),
		'HOST': str(os.getenv('DATABASES_HOST','')),
		'PORT': str(os.getenv('DATABASES_PORT','')),
		'OPTIONS': {
			'sql_mode': 'traditional',
		}
	}
}
# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_L10N = True
USE_TZ = False
STATIC_URL = '/static/'
STATICFILES_DIRS = [
    os.path.join(BASE_DIR, "static"),
]
STATIC_ROOT = os.path.join(BASE_DIR, "static-root")
MEDIA_URL = '/media/'
MEDIA_DIR = os.path.join(BASE_DIR, 'media')
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
DATE_INPUT_FORMATS = ['%d/%m/%Y']

LOGIN_URL = 'accounts:admin_login'
LOGOUT_URL = 'accounts:logout'
LOGIN_REDIRECT_URL = "index"
LOGOUT_REDIRECT_URL = "accounts:admin_login"
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


MIN_PAGE_SIZE = 10