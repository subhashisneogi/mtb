
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.contrib.auth import views as auth_views
from django.conf.urls.static import static
from django.conf.urls import url, include
from master import views
from django.conf.urls import handler404, handler500
handler404 = views.my_custom_permission_denied_view
handler500 = views.error_500

urlpatterns = [
    path('dashboard/', views.index, name='index'),
    path('', views.landing_page, name="landing_page"),
    path('supply/collection/grah/admin/', views.dashboard_supply_collection_entity_wise_graph, 
         name='dashboard_supply_collection_entity_wise_graph'),
    path('supply/collection/grah/region/admin/', views.dashboard_supply_collection_region_wise_graph, 
         name='dashboard_supply_collection_region_wise_graph'),
    path('invoice/graph/entity/admin/', views.dashboard_invoice_entity_wise_graph, 
         name='dashboard_invoice_entity_wise_graph'),
    path('dashboard/laef/collection/graph/ajax/',
        views.dashboard_graph_ajax, name='dashboard_graph_ajax'),
    path('dashboard/invoice/graph/ajax/',
        views.dashboard_invoice_graph_ajax, name='graph_invoice_data_ajax'),
    path('account/details/', views.account_details, name='account_details'),
    # Admin Urls  
    path('admin/', admin.site.urls),
    # APP Urls
    url(r"^accounts/", include("accounts.urls", namespace="accounts")),
    url(r"^", include("user_profile.urls", namespace="user_profile")),
    path("", include("master.urls")),
    url(r"^", include("tea_production.urls", namespace="tea_production")),
    url(r"^", include("chemical_data.urls", namespace="chemical_data")),
    url(r"^", include("leaf_receipt.urls", namespace="leaf_receipt")),
    url(r"^", include("gardens_managment.urls", namespace="gardens_managment")),
    url(r"^", include("vehicle_management.urls", namespace="vehicle_management")),
    url(r"^", include("collection_center.urls", namespace="collection_center")),
    url(r"^", include("lot_batch_details.urls", namespace="lot_batch_details")),
    # url(r"^", include("invoicing.urls", namespace="invoicing")),
    url(r"^", include("weighment_supply.urls", namespace="weighment_supply")),
    url(r"^", include("packaging.urls", namespace="packaging")),
    url(r"^", include("invoicing.urls", namespace="invoicing")),
    url(r"^", include("easy_weight_master.urls", namespace="easy_weight_master")),
    url(r'^ckeditor/', include('ckeditor_uploader.urls')),
    path('privacy/', views.privacy, name='privacy'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_DIR)
