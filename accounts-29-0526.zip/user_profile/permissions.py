from django.urls import reverse

from user_profile.models import Profile, UserTypeMenuPermission


ACTION_NAMES = ("view", "add", "edit", "delete")
DEFAULT_ALLOWED_MENU_KEYS = {"dashboard"}


MENU_REGISTRY = [
    ("dashboard", "Dashboard"),
    ("region_master", "Region Master"),
    ("user_management", "User Management"),
    ("bulk_enrollment", "Bulk Enrollment"),
    ("tea_grade", "Tea Grade Management"),
    ("fertilizer", "Fertilizer Management"),
    ("chemical", "Chemical Management"),
    ("vehicle", "Vehicle Management"),
    ("collection_center", "Collection Center"),
    ("farm_diary", "STG Farm Diary"),
    ("supply_management", "Supply Management"),
    ("challan_process", "Challan Process"),
    ("reports", "Reports"),
    ("farm_diary_report", "Farm Diary Report"),
    ("supply_report", "Supply Report"),
    ("daily_transaction_report", "Daily Transaction Report"),
    ("challan_history_report", "Challan History Report"),
    ("aggregator_register_report", "Aggregator Register Report"),
    ("grower_register_report", "Grower Register Report"),
    ("entity_register_report", "Entity Register Report"),
]


USER_CATEGORY_REGISTRY = [
    ("blf", "BLF"),
]


URL_PERMISSION_MAP = {
    "index": ("dashboard", "view"),
    "region_list": ("region_master", "view"),
    "region_search": ("region_master", "view"),
    "region_view": ("region_master", "view"),
    "region_add": ("region_master", "add"),
    "region_edit": ("region_master", "edit"),
    "region_delete": ("region_master", "delete"),
    "all_users": ("user_management", "view"),
    "user_profile_search": ("user_management", "view"),
    "user_profile_view": ("user_management", "view"),
    "user_create": ("user_management", "add"),
    "grower_profile_create": ("user_management", "add"),
    "aggregator_profile_create": ("user_management", "add"),
    "blf_profile_create": ("user_management", "add"),
    "user_profile_delete": ("user_management", "delete"),
    "user_profile_active": ("user_management", "edit"),
    "user_profile_deactive": ("user_management", "edit"),
    "bulk_import_grower": ("bulk_enrollment", "add"),
    "bulk_import_aggregator": ("bulk_enrollment", "add"),
    "tea_grade_list": ("tea_grade", "view"),
    "tea_grade_create": ("tea_grade", "add"),
    "tea_grade_update": ("tea_grade", "edit"),
    "tea_grade_delete": ("tea_grade", "delete"),
    "fertilizer_list": ("fertilizer", "view"),
    "chemical_list": ("chemical", "view"),
    "chemical_view": ("chemical", "view"),
    "chemical_create": ("chemical", "add"),
    "chemical_edit": ("chemical", "edit"),
    "chemical_delete": ("chemical", "delete"),
    "chemical_delete_old": ("chemical", "delete"),
    "vehicle_list": ("vehicle", "view"),
    "vehicle_view": ("vehicle", "view"),
    "vehicle_create": ("vehicle", "add"),
    "vehicle_edit": ("vehicle", "edit"),
    "vehicle_delete": ("vehicle", "delete"),
    "collection_center_list": ("collection_center", "view"),
    "collection_center_details": ("collection_center", "view"),
    "collection_center_create": ("collection_center", "add"),
    "collection_center_update": ("collection_center", "edit"),
    "collection_center_delete": ("collection_center", "delete"),
    "farmdiary_user_list": ("farm_diary", "view"),
    "chemical_type_list": ("farm_diary", "view"),
    "chemical_view_list": ("farm_diary", "view"),
    "farm_diary_record_detail": ("farm_diary", "view"),
    "plucking_data_view_list": ("farm_diary", "view"),
    "farmdiary_labour_list": ("farm_diary", "view"),
    "farmdiary_monthly_shedule_list": ("farm_diary", "view"),
    "farmers_aggreements_forms_list": ("farm_diary", "view"),
    "chemical_view_create": ("farm_diary", "add"),
    "plucking_data_view_create": ("farm_diary", "add"),
    "farmdiary_labour_create": ("farm_diary", "add"),
    "farmdiary_monthly_shedule_create": ("farm_diary", "add"),
    "farm_diary_map_create": ("farm_diary", "add"),
    "farm_diary_mannual_map_create": ("farm_diary", "add"),
    "use_of_chemical_edit": ("farm_diary", "edit"),
    "plucking_data_view_edit": ("farm_diary", "edit"),
    "farmdiary_labour_edit": ("farm_diary", "edit"),
    "farmdiary_monthly_shedule_edit": ("farm_diary", "edit"),
    "farm_diary_mannual_map_edit": ("farm_diary", "edit"),
    "farm_diary_edit_map": ("farm_diary", "edit"),
    "farm_diary_edit_map_text_data": ("farm_diary", "edit"),
    "edit_farmers_signature": ("farm_diary", "edit"),
    "use_of_chemical_delete": ("farm_diary", "delete"),
    "plucking_data_delete": ("farm_diary", "delete"),
    "labour_data_delete": ("farm_diary", "delete"),
    "monthly_schedule_data_delete": ("farm_diary", "delete"),
    "supply_management_report": ("supply_management", "view"),
    "supply_management_report_detail": ("supply_management", "view"),
    "supply_management_options": ("supply_management", "view"),
    "supply_management_create": ("supply_management", "add"),
    "supply_management_edit": ("supply_management", "edit"),
    "supply_management_delete": ("supply_management", "delete"),
    "challan_process_list": ("challan_process", "view"),
    "challan_process_records": ("challan_process", "view"),
    "challan_process_detail": ("challan_process", "view"),
    "challan_process_create": ("challan_process", "add"),
    "challan_process_edit": ("challan_process", "edit"),
    "challan_process_delete": ("challan_process", "delete"),
    "supply_management_report_pdf": ("supply_report", "view"),
    "supply_management_excel": ("supply_report", "view"),
    "daily_transaction_report": ("daily_transaction_report", "view"),
    "daily_transaction_report_pdf": ("daily_transaction_report", "view"),
    "daily_transaction_report_excel": ("daily_transaction_report", "view"),
    "challan_history_report_pdf": ("challan_history_report", "view"),
    "challan_history_report_excel": ("challan_history_report", "view"),
    "aggregator_register_reports": ("aggregator_register_report", "view"),
    "report_aggregator_register_pdf": ("aggregator_register_report", "view"),
    "report_aggregator_register_excel": ("aggregator_register_report", "view"),
    "grower_register_reports": ("grower_register_report", "view"),
    "report_grower_register_pdf": ("grower_register_report", "view"),
    "report_grower_register_excel": ("grower_register_report", "view"),
    "entity_register_list": ("entity_register_report", "view"),
    "report_entity_register_pdf": ("entity_register_report", "view"),
    "report_entity_register_excel": ("entity_register_report", "view"),
}

REPORT_CHILD_MENU_KEYS = {
    "farm_diary_report",
    "supply_report",
    "daily_transaction_report",
    "challan_history_report",
    "aggregator_register_report",
    "grower_register_report",
    "entity_register_report",
}


def is_super_admin(user):
    if not user or not user.is_authenticated:
        return False
    if user.is_superuser:
        return True
    profile = getattr(user, "profile", None)
    user_type = getattr(getattr(profile, "user_type", None), "name", "")
    return str(user_type).strip().lower() in ("super admin", "superadmin")


def get_user_permission_category(user):
    if not user or not user.is_authenticated:
        return ""
    profile = Profile.cmobjects.filter(user=user).select_related("user_type").first()
    user_type = str(profile.user_type.name).strip().lower() if profile and profile.user_type else ""
    return "blf" if user_type == "blf" else ""


def _allow_all_permission():
    return {"can_view": True, "can_add": True, "can_edit": True, "can_delete": True}


def _disabled_permission():
    return {"can_view": False, "can_add": False, "can_edit": False, "can_delete": False}


def get_permission_map(user):
    if is_super_admin(user):
        return {key: _allow_all_permission() for key, _ in MENU_REGISTRY}
    category = get_user_permission_category(user)
    if not category:
        return {key: _allow_all_permission() for key, _ in MENU_REGISTRY}
    permission_map = {key: _disabled_permission() for key, _ in MENU_REGISTRY}
    for menu_key in DEFAULT_ALLOWED_MENU_KEYS:
        if menu_key in permission_map:
            permission_map[menu_key] = _allow_all_permission()
    if category != "blf":
        return permission_map
    rows = UserTypeMenuPermission.cmobjects.filter(user_category=category)
    for row in rows:
        if row.menu_key in DEFAULT_ALLOWED_MENU_KEYS:
            continue
        permission_map[row.menu_key] = {
            "can_view": row.can_view,
            "can_add": row.can_add,
            "can_edit": row.can_edit,
            "can_delete": row.can_delete,
        }
    return permission_map


def has_menu_permission(user, menu_key, action="view"):
    if is_super_admin(user):
        return True
    if get_user_permission_category(user) != "blf":
        return True
    if action not in ACTION_NAMES:
        action = "view"
    permission_map = get_permission_map(user)
    menu_permission = permission_map.get(menu_key, _disabled_permission())
    if action != "view" and not menu_permission.get("can_view", False):
        return False
    return bool(menu_permission.get("can_%s" % action, False))


def can_access_configured_menu(user, menu_key, action="view"):
    if is_super_admin(user):
        return True
    if get_user_permission_category(user) == "blf":
        return has_menu_permission(user, menu_key, action)
    return False


def permission_for_url_name(url_name):
    return URL_PERMISSION_MAP.get(url_name)


def settings_redirect_url():
    return reverse("user_profile:user_permission_settings")
