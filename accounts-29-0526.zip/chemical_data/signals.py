
from django.db.models.signals import pre_save
from django.dispatch import receiver
from rest_framework.exceptions import APIException
from .models import ChemicalData, UseOfChemical
from user_profile.aggregator_api_models import Labour


DUPLICATE_CHEMICAL_MESSAGE = "This chemical has already been recorded for the selected date and chemical."
DUPLICATE_CHEMICAL_MASTER_MESSAGE = "Chemical name already exists for the selected chemical type."
DUPLICATE_LABOUR_MESSAGE = "This labour data already exists for the selected profile."


@receiver(pre_save, sender=UseOfChemical)
def chemical_data_validation(sender, instance, **kwargs):
    if not all([instance.date, instance.chemical_id]):
        return

    owner_filter = {}
    if instance.grower_id:
        owner_filter["grower_id"] = instance.grower_id
    elif instance.aggregator_id:
        owner_filter["aggregator_id"] = instance.aggregator_id
    elif instance.blf_id:
        owner_filter["blf_id"] = instance.blf_id
    elif instance.created_by_id:
        owner_filter["created_by_id"] = instance.created_by_id

    qs = UseOfChemical.cmobjects.filter(
        date=instance.date,
        chemical_id=instance.chemical_id,
        **owner_filter,
    )
    if instance.pk:
        qs = qs.exclude(pk=instance.pk)
    if qs.exists():
        raise APIException(DUPLICATE_CHEMICAL_MESSAGE)


@receiver(pre_save, sender=ChemicalData)
def chemical_master_duplicate_validation(sender, instance, **kwargs):
    chemical_name = (instance.chemical_name or "").strip()
    if instance.is_deleted or not instance.chemical_type_id or not chemical_name:
        return

    instance.chemical_name = chemical_name
    qs = ChemicalData.objects.filter(
        is_deleted=False,
        chemical_type_id=instance.chemical_type_id,
        chemical_name__iexact=chemical_name,
    )
    if instance.pk:
        qs = qs.exclude(pk=instance.pk)
    if qs.exists():
        raise APIException(DUPLICATE_CHEMICAL_MASTER_MESSAGE)


@receiver(pre_save, sender=Labour)
def labour_data_validation(sender, instance, **kwargs):
    if instance.is_deleted or not instance.name:
        return

    owner_filter = {}
    if instance.grower_id:
        owner_filter["grower_id"] = instance.grower_id
    elif instance.aggregator_id:
        owner_filter["aggregator_id"] = instance.aggregator_id
    elif instance.blf_id:
        owner_filter["blf_id"] = instance.blf_id
    else:
        return

    qs = Labour.cmobjects.filter(
        name__iexact=instance.name.strip(),
        **owner_filter,
    )
    if instance.pk:
        qs = qs.exclude(pk=instance.pk)
    if qs.exists():
        raise APIException(DUPLICATE_LABOUR_MESSAGE)
