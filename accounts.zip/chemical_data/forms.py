from django import forms
from django.db.models import Q
from django.core.exceptions import ValidationError
from django.forms import inlineformset_factory
from django.forms import ModelForm, Textarea
from .models import *
from user_profile.aggregator_api_models import *
from user_profile.grower_api_models import *
from gardens_managment.models import *

class DateInput(forms.DateInput):
    """
    Widgets support for date input
    """
    input_type = 'date'
    
class TimeInput(forms.TimeInput):
	"""
	Widgets support for Time input
	"""
	input_type = 'time'


class ChemicalDataForm(forms.ModelForm):
	""" Chemical Data Create Form @vivek"""

	def __init__(self, *args, **kwargs):
		self.is_fertilizer = kwargs.pop('is_fertilizer', False)
		super().__init__(*args, **kwargs)
		fertilizer_type = ChemicalType.objects.filter(id=1).first() or ChemicalType.objects.filter(
			name__iexact="Fertilizer"
		).first()

		# Styling
		self.fields['chemical_name'].widget.attrs = {
			'class': 'form-control', 'required': 'required', 'placeholder': "Chemical Name"
		}
		self.fields['manufacturer'].widget.attrs = {
			'class': 'form-control', 'placeholder': "Manufacturer Name"
		}
		self.fields['brand_local_name'].widget.attrs = {
			'class': 'form-control', 'placeholder': "Brand/Local Name"
		}
		self.fields['composition'].widget.attrs = {
			'class': 'form-control', 'placeholder': "Composition"
		}

		self.fields['chemical_type'].widget.attrs = {
			'class': 'select2_demo_1 form-control',
			'required': 'required',
			'id': 'select2-chemical_type'
		}

		# ✅ MAIN LOGIC
		if self.is_fertilizer:
			if fertilizer_type:
				self.fields['chemical_type'].initial = fertilizer_type
				self.fields['chemical_type'].queryset = ChemicalType.objects.filter(id=fertilizer_type.id)

				# 🔥 Hide dropdown (optional but recommended)
				self.fields['chemical_type'].widget = forms.HiddenInput()
			self.fields['chemical_type'].required = False
		else:
			chemical_type_qs = ChemicalType.objects.all()
			if fertilizer_type:
				chemical_type_qs = chemical_type_qs.exclude(id=fertilizer_type.id)
			self.fields['chemical_type'].queryset = chemical_type_qs.order_by('name')

	class Meta:
		model = ChemicalData
		fields = ('chemical_type','chemical_name', 'manufacturer','brand_local_name', 'composition', 
			
			)
		widgets = {
			'address': Textarea(attrs={'rows':80, 'cols':20}),
		}



class UseOfChemicalForm(forms.ModelForm):
	""" Chemical Data Create Form """

	def __init__(self, *args, **kwargs):
		type_id = kwargs.pop('chemical_type_pk', None)
		grower_pk = kwargs.pop('grower_pk', None)
		garden_pk = kwargs.pop('garden_pk', None)
		grower_details_id = kwargs.pop('grower_details_id', None)
		self.request_user = kwargs.pop("request_user", None)

		super(UseOfChemicalForm, self).__init__(*args, **kwargs)
		# for field in self.fields.values():
		# 	field.widget.attrs = {"class": "form-control"}

		self.fields['date'].required = True
		self.fields['chemical'].required = True
		self.fields['quantity'].required = True
		self.fields['unit'].required = True
		

		self.fields['date'].widget.attrs = {'class': 'form-control',}
		self.fields['chemical'].widget.attrs = {'class': 'form-control select2_chemical', }
		self.fields['labour'].widget.attrs = {'class': 'form-control select2_labour', 'placeholder' : "Labour"}
		self.fields['division'].widget.attrs = {'class': 'form-control select2_division'}
		self.fields['plot'].widget.attrs = {'class': 'form-control select2_plot',}
		self.fields['chemical'].queryset = ChemicalData.objects.filter(chemical_type_id=type_id).order_by('-id')
		self.fields['plot'].queryset = Plot.objects.filter(garden_id=garden_pk).order_by('-id')
		self.fields['labour'].queryset = Labour.cmobjects.filter(created_by_id=grower_pk).order_by('-id')
		self.fields['division'].queryset = Division.objects.filter(garden_id=garden_pk).order_by('-id')
		

		self.fields['labour'].queryset = Labour.cmobjects.filter(grower_id=grower_details_id).order_by('-id')

		print("TYPE ID", type_id)

		if type_id == 1:
			self.fields['quantity'].widget.attrs = {	
			'class': 'form-control', 'placeholder' : 'Quantity'}
		else:
			self.fields['quantity'].widget.attrs = {	
			'class': 'form-control', 'placeholder' : 'Quantity'}

	class Meta:	
		model = UseOfChemical
		fields = ('date','chemical', 'labour','plot', 'quantity', 'unit', 'grower', 'division' )
		widgets = {
			'date': DateInput(),

		}
	def clean(self):
		cleaned_data = super().clean()
		date = cleaned_data.get("date")
		chemical = cleaned_data.get("chemical")
		labour = cleaned_data.get("labour")
		plot = cleaned_data.get("plot")

		# use the logged-in user instead of cleaned_data.get("created_by")
		created_by = self.request_user

		if all([date, chemical, labour, plot, created_by]):
			qs = UseOfChemical.cmobjects.filter(
				date=date,
				chemical=chemical,
				labour=labour,
				created_by=created_by,
			)
			if self.instance.pk:
				qs = qs.exclude(pk=self.instance.pk)
			if qs.exists():
				raise forms.ValidationError(
					"This chemical has already been recorded for the selected Date, Labour, and Plot"
				)
		return cleaned_data








class PluckingDataForm(forms.ModelForm):
	""" Plucking Data Create Form """
	def __init__(self, *args, **kwargs):
		grower_pk = kwargs.pop('grower_pk', None)
		garden_pk = kwargs.pop('garden_pk', None)
		grower_details_id = kwargs.pop('grower_details_id', None)
		super(PluckingDataForm, self).__init__(*args, **kwargs)

		self.fields['date'].required = True
		self.fields['date'].widget.attrs = {'class': 'form-control',}
		self.fields['start_time'].widget.attrs = {'class': 'form-control', 'placeholder' : "Start Time", 'id' : 'start_time'}
		self.fields['end_time'].widget.attrs = {'class': 'form-control', 'placeholder' : "End Time", 'id' : 'end_time', 'onchange' : 'Compare()'}
		self.fields['division'].widget.attrs = {
            'class': 'select2_demo_1 form-control',}
		self.fields['plot'].widget.attrs = {'class': 'form-control', }
		self.fields['area_plucked'].widget.attrs = {
            'class': 'form-control', 'placeholder' : "Area Plucked"}
		self.fields['quantity_plucked'].widget.attrs = {
            'class': ' form-control', 'placeholder' : "Quantity Plucked"}
		self.fields['labour'].widget.attrs = {
            'class': ' form-control', 'placeholder' : "Labour"}
		
		self.fields['plot'].queryset = Plot.objects.filter(garden_id=garden_pk).order_by('-id')
		self.fields['labour'].queryset = Labour.cmobjects.filter(grower_id=grower_details_id).order_by('-id')


	
	class Meta:
		model = PluckingData
		fields = ('date','start_time', 'end_time','plot', 'division', 'area_plucked', 'quantity_plucked', 'labour')
		widgets = {
            'date': DateInput(),
	    	'start_time' : TimeInput(),
		    'end_time' : TimeInput(),
        }


class LabourDataForm(forms.ModelForm):
	""" Plucking Data Create Form """
	def __init__(self, *args, **kwargs):
		
		super(LabourDataForm, self).__init__(*args, **kwargs)

		self.fields['name'].required = True

		self.fields['name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Name"  }
		self.fields['type'].widget.attrs = {'class': 'form-control',}
		self.fields['gender'].widget.attrs = {'class': 'form-control', }
		self.fields['age'].widget.attrs = {'class': 'form-control', 'placeholder' : "Age" }
		
	class Meta:
		model = Labour
		fields = ('name','type', 'gender', 'age' )
		widgets = {
            # 'date': DateInput(),
        }


class MonthlyScheduleForm(forms.ModelForm):
	""" Monthly Schedule  Create Form """
	def __init__(self, *args, **kwargs):
		
		super(MonthlyScheduleForm, self).__init__(*args, **kwargs)

		self.fields['year'].required = True

		self.fields['year'].widget.attrs = {'class': 'form-control', 'placeholder' : "Name"  }
		self.fields['month'].widget.attrs = {'class': 'form-control',}
		self.fields['no_of_working_days'].widget.attrs = {'class': 'form-control', 'placeholder' : "Total no. of working days" }
		self.fields['monthly_wages'].widget.attrs = {'class': 'form-control', 'placeholder' : "Average monthly wages (INR)" }
		
		
	class Meta:
		model = MonthlySchedule
		fields = ('year','month', 'no_of_working_days', 'monthly_wages' )
		widgets = {
            # 'date': DateInput(),
        }



class MapAreaDetailsForm(forms.ModelForm):
	"""Map Area Details  Create Form """
	def __init__(self, *args, **kwargs):
		
		super(MapAreaDetailsForm, self).__init__(*args, **kwargs)

		self.fields['map_image'].required = True
		self.fields['water_source'].required = True
		self.fields['land_near_by'].required = True

		self.fields['map_image'].widget.attrs = {'class': 'form-control',}
		self.fields['water_source'].widget.attrs = {'class': 'form-control', }
		self.fields['land_near_by'].widget.attrs = {'class': 'form-control', }
		
	class Meta:
		model = MapAreaMaster
		fields = ('blf', 'grower', 'aggregator', 'map_image','water_source', 'land_near_by', 'is_image_upload', 'is_digital_upload')
		widgets = {
            # 'date': DateInput(),
        }
