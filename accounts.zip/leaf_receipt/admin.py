from django.contrib import admin
from .models import *
# Register your models here.
# admin.site.register(VehicleNumberTxnId)

class LeafAdmin(admin.ModelAdmin):
    search_fields = ['weighment_txn__weighment_txn_id', 'id',]
    
    list_display = ['id', 'weighment_txn', 'acknowledge_status','is_complete', 
                    'created_date', 'created_by_username','deduction', 'final_leaf_count', 
                     'quality_standard',
                      'rate', 'supply_date_value', 'net_leaf_weight']

    @admin.display(description='Created at')
    def created_date(self, obj):
        return obj.created_at.date() if obj.created_at else None

    @admin.display(description='Created by')
    def created_by_username(self, obj):
        return obj.created_by.username if obj.created_by else None

    @admin.display(description='Supply date')
    def supply_date_value(self, obj):
        return obj.supply_date


class LeafCollectionAdmin(admin.ModelAdmin):
    list_display = ['id', 'created_by', 'supply_date', 'weighment_supply_id', 'supply_id',
                     'supplier_type', 'supplier', 'aggregator', 'grower', 
                     'nt_wght', 'plucking_data_id' ]
    search_fields = ['supplier_type', 'weighment_supply_id__weighment_txn_id']


admin.site.register(LeafManagement, LeafAdmin)

admin.site.register(LeafCollection, LeafCollectionAdmin)

