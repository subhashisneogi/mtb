class SupplyManagementCreateView(FarmDiaryGrowerAccessMixin, LoginRequiredMixin, CommonMixin, CreateView):
	"""
	Use Of Chemical Create View  for BLF ADMIN
	"""
	model = SupplyManagement
	form_class = SupplyManagementForm
	template_name = 'farm_diary/plucking_data_form.html'

	def get(self, request, *args, **kwargs):
		
		return super(SupplyManagementCreateView, self).get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Data Updated Successfully')
		return reverse('chemical_data:plucking_data_view_list', kwargs={'grower_pk': self.kwargs['grower_pk']} )

	def get_context_data(self, **kwargs):
		context = super(SupplyManagementCreateView, self).get_context_data(**kwargs)
		context['grower_pk'] = self.kwargs['grower_pk']
		context['grower_details'] = GrowerProfile.cmobjects.filter(user_id=self.kwargs['grower_pk']).first()
		return context

	def get_form_kwargs(self, **kwargs):
		kwargs = super(SupplyManagementCreateView, self).get_form_kwargs()
		# kwargs['grower_pk'] = self.kwargs['grower_pk']
		# kwargs['garden_pk'] = garden_details.pk
		return kwargs

	def form_valid(self, form):
		with transaction.atomic():
			form.instance.created_by_id = self.request.user.id
			# grower_details = GrowerProfile.cmobjects.filter(user_id=self.kwargs['grower_pk']).first()
			# form.instance.grower_id = grower_details.pk
			self.object = form.save()
		return HttpResponseRedirect(self.get_success_url())