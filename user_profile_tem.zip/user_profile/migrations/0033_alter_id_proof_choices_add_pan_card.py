from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('user_profile', '0032_profile_email_unique_nullable'),
    ]

    operations = [
        migrations.AlterField(
            model_name='growerprofile',
            name='id_proof_type',
            field=models.CharField(
                blank=True,
                choices=[
                    ('AADHAR CARD', 'AADHAR CARD'),
                    ('VOTER ID', 'VOTER ID'),
                    ('PAN CARD', 'PAN CARD'),
                    ('TBOI CARD', 'TBOI CARD'),
                    ('RC ID', 'RC ID'),
                    ('DL ID', 'DL'),
                    ('Other', 'Other'),
                ],
                max_length=50,
                null=True,
            ),
        ),
        migrations.AlterField(
            model_name='userprofileattachments',
            name='attachment_name',
            field=models.CharField(
                blank=True,
                choices=[
                    ('AADHAR_CARD', 'AADHAR CARD'),
                    ('VOTER_ID', 'VOTER ID'),
                    ('PAN_CARD', 'PAN CARD'),
                    ('TBOI_CARD', 'TBOI CARD'),
                    ('RC_ID', 'RC ID'),
                    ('DL_ID', 'DL'),
                    ('Other', 'Other'),
                ],
                default='',
                max_length=250,
                null=True,
            ),
        ),
    ]
