from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('user_profile', '0028_profile_password_reset_audit'),
    ]

    operations = [
        migrations.AddField(
            model_name='growerprofile',
            name='enjoyment_certificate_no',
            field=models.CharField(blank=True, max_length=100, null=True),
        ),
    ]
