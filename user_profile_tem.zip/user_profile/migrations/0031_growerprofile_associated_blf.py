from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('user_profile', '0030_alter_profile_trustea_id'),
    ]

    operations = [
        migrations.AddField(
            model_name='growerprofile',
            name='associated_blf',
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.CASCADE,
                related_name='associated_blf_user',
                to='user_profile.blfprofile',
            ),
        ),
    ]
