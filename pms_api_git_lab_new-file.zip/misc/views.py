from django.core.paginator import Paginator
from django.db import transaction
from django.shortcuts import render
from knox.auth import TokenAuthentication
from rest_framework import status
from rest_framework.renderers import JSONRenderer
from rest_framework.exceptions import APIException
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from rest_framework.response import Response
from django.apps import apps
from datetime import date, timedelta
from procurement.helper import GroupConcat
from django.db.models.functions import Concat, Trim ,Coalesce
from django.db.models import Q, FloatField, CharField, Value, Case, When, Subquery, OuterRef, Count, Max, Avg, F, Value
from xhtml2pdf import pisa
import uuid
from collections import defaultdict


from django.http import HttpResponse , JsonResponse, FileResponse
import requests
import urllib3
from requests.auth import HTTPBasicAuth
import calendar
import json
import os
import random
import time
import base64
import shutil
import pandas as pd
import numpy as np
from django.http import HttpResponse
from django.views.generic import View
from bs4 import BeautifulSoup
from openpyxl import Workbook
from django.shortcuts import render
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import Workbook
import openpyxl.styles
from storages.backends.s3boto3 import S3Boto3Storage

import openpyxl
from .models import *
from .serializers import *

from procurement.helper import custom_filters,get_model_details,sync_user_project_hrms,text2tree,get_sap_plant_auth,sap_request ,handle_belsio_tax_master , sync_tax_master_from_belsio , fetch_all_account_master_items, trigger_notifications,calculate_quantity_on_uom,update_inventory,validate_financialyear,financialyear_id_by_date
from administrations.signals import sync_user_hrms,hrms_request
from administrations.utils import send_generic_mail,send_generic_sms,send_generic_push
from project_and_planning.views import sync_hrms_project
from project_and_planning.serializers import ProjectDataSerializer

from material_master.models import *
from vendor.models import *
from accounts.models import *
from user_profile.models import *
from procurement.models import *
from user_permissions.models import UserWiseModulePermissions
from procurement.serializers import CSTSerializer
from procurement.views import CSTMainAPIView

class TaxMasterSyncBelsioAPIView(APIView):
    """
    API to manually trigger syncing of Tax Master from Belsio
    """
    
    

    def get(self, request):
        try:
            sync_tax_master_from_belsio()
            return Response(
                {
                 'msg': 'Successfully sync.',
                 'status': status.HTTP_200_OK,
                 "request_status": 1})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class TaxHeadAPIView(APIView):
    """
    CRUD API for TaxHead model
    """
    
    

    def get(self, request):
        """
        Get a list of all TaxHeadMaster
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            tax_head_details = TaxHead.cmobjects.filter(id=id).first()
            serializer = TaxHeadSerializer(tax_head_details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])

        tax_head_list = TaxHead.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = TaxHeadSerializer(tax_head_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(tax_head_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TaxHeadSerializer(page, many=True)

        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Tax Head
        """
        request.data['created_by_id'] = request.user.id
        serializer = TaxHeadSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                instance=serializer.save()
                handle_belsio_tax_master(instance=instance,created=True)
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a TaxHead
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        tax_head_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a TaxHead
                """
                if TaxHead.cmobjects.filter(pk=tax_head_id, organization_id=organization_id).exists():
                    tax_head_details = TaxHead.cmobjects.filter(pk=tax_head_id).first()
                    serializer = TaxHeadSerializer(tax_head_details, data=request.data)

                    if serializer.is_valid():
                        try:
                            instance=serializer.save()
                            handle_belsio_tax_master(instance=instance,created=False)

                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a TaxHead
                """
                if TaxHead.cmobjects.filter(pk=tax_head_id, organization_id=organization_id).exists():
                    tax_head_details = TaxHead.cmobjects.get(
                        pk=tax_head_id, organization_id=organization_id)
                    tax_head_details.is_deleted = True
                    tax_head_details.save()

                    return Response({'results': {
                        'tax_head': TaxHead.objects.filter(pk=tax_head_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Tax Head',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountsHeadAPIView(APIView):
    """
    CRUD API for AccountsHead model
    """
    
    

    def get(self, request):
        """
        Get a list of all AccountsHead
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)

        if id:
            accounts_head_details = AccountsHead.cmobjects.select_related('organization', 'parent')\
                                                           .filter(id=id).first()
            serializer = AccountsHeadSerializer(accounts_head_details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])

        accounts_head_list = AccountsHead.cmobjects.select_related('organization', 'parent')\
                                                    .filter(*search)\
                                                    .order_by('-id')
        if all == 'true':
            serializer = AccountsHeadSerializer(accounts_head_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(accounts_head_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        

        serializer = AccountsHeadSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


    def post(self, request):
        """
        Create a new Accounts Head
        """
        request.data['created_by_id'] = request.user.id
        serializer = AccountsHeadSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a AccountsHead
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        accounts_head_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a AccountsHead
                """
                if AccountsHead.cmobjects.filter(pk=accounts_head_id, organization_id=organization_id).exists():
                    accounts_head_details = AccountsHead.cmobjects.filter(pk=accounts_head_id).first()

                    serializer = AccountsHeadSerializer(accounts_head_details, data=request.data)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a AccountsHead
                """
                if AccountsHead.cmobjects.filter(pk=accounts_head_id, organization_id=organization_id).exists():
                    accounts_head_details = AccountsHead.cmobjects.get(
                        pk=accounts_head_id, organization_id=organization_id)
                    accounts_head_details.is_deleted = True
                    accounts_head_details.save()

                    return Response({'results': {
                        'accounts_head': AccountsHead.objects.filter(pk=accounts_head_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Accounts Head',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class ExpenseHeadAPIView(APIView):
    """
    CRUD API for ExpenseHead model
    """
    
    

    def get(self, request):
        """
        Get a list of all ExpenseHead
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            expense_head_details = ExpenseHead.cmobjects.filter(id=id).first()
            serializer = ExpenseHeadSerializer(expense_head_details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])

        expense_head_list = ExpenseHead.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = ExpenseHeadSerializer(expense_head_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(expense_head_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = ExpenseHeadSerializer(page, many=True)

        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Expense Head
        """
        request.data['created_by_id'] = request.user.id
        serializer = ExpenseHeadSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a ExpenseHead
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        expense_head_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a ExpenseHead
                """
                if ExpenseHead.cmobjects.filter(pk=expense_head_id, organization_id=organization_id).exists():
                    expense_head_details = ExpenseHead.cmobjects.filter(pk=expense_head_id).first()

                    serializer = ExpenseHeadSerializer(expense_head_details, data=request.data)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a ExpenseHead
                """
                if ExpenseHead.cmobjects.filter(pk=expense_head_id, organization_id=organization_id).exists():
                    expense_head_details = ExpenseHead.cmobjects.get(
                        pk=expense_head_id, organization_id=organization_id)
                    expense_head_details.is_deleted = True
                    expense_head_details.save()

                    return Response({'results': {
                        'expense_head': ExpenseHead.objects.filter(pk=expense_head_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Expense Head',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class TermsAndConditionsMasterAPIView(APIView):
    """
    CRUD API for TermsAndConditionsMaster model
    """
    
    

    def get(self, request):
        """
        Get a list of all TermsAndConditionsMaster
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            _details = TermsAndConditionsMaster.cmobjects.filter(id=id).first()
            serializer = TermsAndConditionsMasterSerializer(_details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])

        terms_and_conditions_list = TermsAndConditionsMaster.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = TermsAndConditionsMasterSerializer(terms_and_conditions_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(terms_and_conditions_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TermsAndConditionsMasterSerializer(page, many=True)
        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Quotation
        """
        request.data['created_by_id'] = request.user.id
        serializer = TermsAndConditionsMasterSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': f'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Edit a TermsAndConditionsMaster
        """

        # id = request.data.get('id', None)
        id = self.request.query_params.get('id', None)
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        instance = TermsAndConditionsMaster.cmobjects.filter(pk=id).first()
        print("instance", instance)
        try:
            with transaction.atomic():
                if method.lower() == 'edit':
                    if instance:
                        request.data['updated_by_id'] = request.user.id
                        request.data['organization'] = organization_id
                        serializer = TermsAndConditionsMasterSerializer(instance, data=request.data)
                        # print(serializer)
                        if serializer.is_valid():
                            try:
                                serializer.save()
                            except Exception as e:
                                print(f"ERROR {e}")
                                error_message = str(e.args[0]) if e.args else str(e)
                                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                            return Response(
                                {'results': {
                                    'Data': serializer.data,
                                },
                                    'msg': f'Successfully created.',
                                    'status': status.HTTP_202_ACCEPTED,
                                    "request_status": 1})
                        else:
                            raise APIException({'request_status': 0, 'msg': serializer.errors})
                elif method.lower() == 'delete':
                    instance.is_deleted = True
                    instance.save()

                    return Response({'results': {
                        'data': instance.id,
                    },
                    'msg': 'Successfully deleted terms and conditions',
                    "request_status": 1})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})


class TermsAndConditionsMasterChildAPIView(APIView):
    """
    CRUD API for TermsAndConditionsMasterChild model
    """
    
    

    def get(self, request):
        """
        Get a list of all TermsAndConditionsMaster
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            _details = TermsAndConditionsChild.cmobjects.filter(id=id).first()
            serializer = TermsAndConditionsChildSerializer(_details)
            return Response(serializer.data)

        if all == 'true':
            _details = TermsAndConditionsChild.cmobjects.all()
            serializer = TermsAndConditionsChildSerializer(_details, many=True)
            return Response({'results': serializer.data})
        raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})

    def post(self, request):
        """
        Create a new Terms And ConditionsMaster Child
        """
        request.data['created_by_id'] = request.user.id
        serializer = TermsAndConditionsChildSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': f'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})


    def put(self, request, *args, **kwargs):
        """
        Edit a TermsAndConditions Child
        """

        # id = request.data.get('id', None)
        id = self.request.query_params.get('id', None)
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        instance = TermsAndConditionsChild.cmobjects.filter(pk=id).first()
        print("instance", instance)
        try:
            with transaction.atomic():
                if method.lower() == 'edit':
                    if instance:
                        instance.organization_id = organization_id
                        serializer = TermsAndConditionsChildSerializer(instance, data=request.data)
                        # print(serializer)
                        if serializer.is_valid():
                            try:
                                serializer.save()
                            except Exception as e:
                                print(f"ERROR {e}")
                                error_message = str(e.args[0]) if e.args else str(e)
                                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                            return Response(
                                {'results': {
                                    'Data': serializer.data,
                                },
                                    'msg': f'Successfully created.',
                                    'status': status.HTTP_202_ACCEPTED,
                                    "request_status": 1})
                        else:
                            raise APIException({'request_status': 0, 'msg': serializer.errors})
                elif method.lower() == 'delete':
                    instance.is_deleted = True
                    instance.save()
                    # instance.delete()

                    return Response({'results': {
                        'data': instance.id,
                    },
                    'msg': 'Successfully deleted terms and conditions child',
                    "request_status": 1})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})



class VendorCurrencyMasterAPIView(APIView):
    """
    CRUD API for Currency model
    """
    
    

    def get(self, request):
        """
        Get a list of all Currency
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            location_details = VendorCurrencyMaster.cmobjects.filter(id=id).first()
            serializer = VendorCurrencyMasterSerializer(location_details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])

        currency_list = VendorCurrencyMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = VendorCurrencyMasterSerializer(currency_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(currency_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = VendorCurrencyMasterSerializer(page, many=True)

        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Currency
        """
        serializer = VendorCurrencyMasterSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': f'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Currency
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        currency_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Location
                """
                if VendorCurrencyMaster.cmobjects.filter(pk=currency_id,
                                                      organization_id=organization_id).exists():
                    currency_details = VendorCurrencyMaster.cmobjects.filter(pk=currency_id).first()
                    serializer = VendorCurrencyMasterSerializer(currency_details, data=request.data)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Location Child
                """
                if VendorCurrencyMaster.cmobjects.filter(pk=currency_id,
                                                      organization_id=organization_id).exists():
                    currency_details = VendorCurrencyMaster.cmobjects.get(
                        pk=currency_id, organization_id=organization_id)
                    currency_details.is_deleted = True
                    currency_details.save()

                    return Response({'results': {
                        'site': VendorCurrencyMaster.objects.filter(pk=currency_id,
                                                                 organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted currency',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class MergeDataAPIView(APIView):
    
    

    def post(self, request):
        type_map = {
            "uom": "UnitOfMesurement",
            "material_group": "MaterialType",
            "material": "VendorMaterialMaster",
            "vendor": "VendorMasterV2",
            "chainage": "AccountChainageMaster",
            "activity": "AccountActivityMaster",
            "sub_activity": "AccountSubActivityMaster",
            "project_budget": "AccountProjectBudget",
            "budget_breakdown": "BudgetBreakdown",
            "consumption_breakdown": "AccountConsumptionBreakdown",
            "project": "ProjectMaster",
        }
        try:
            current_user_id = request.user.id
            with transaction.atomic():
                success_msg = []
                error_msg = []
                request_datas = []
                if isinstance(request.data, list):
                    request_datas = request.data
                else:
                    request_datas = [request.data]
                for request_data in request_datas:
                    organization = request_data.get('organization', None)
                    type = request_data.get('type', None)
                    from_id_list = request_data.get('from_id_list', None)
                    to_id = request_data.get('to_id', None)
                    if type is None:
                        error_msg.append([type,from_id_list,to_id,f"type not provided"])
                    if from_id_list is None:
                        error_msg.append([type,from_id_list,to_id,f"from_id_list is required"])
                    if to_id is None:
                        error_msg.append([type,from_id_list,to_id,f"to_id is required"])
                    to_id = str(to_id)
                    from_id_list = [str(element) for element in from_id_list]
                    if type in type_map:
                        if isinstance(from_id_list, list):
                            if to_id in from_id_list:
                                error_msg.append([type,from_id_list,to_id,f"to_id: {to_id} found in from_id_list: {from_id_list}"])
                            else:
                                links = eval(f'{type_map[type]}._meta.related_objects')
                                details_to = eval(f'{type_map[type]}.cmobjects.filter(pk=to_id).first()')
                                if details_to:
                                    for from_id in from_id_list:
                                        details_from = eval(f'{type_map[type]}.cmobjects.filter(pk=from_id).first()')
                                        if details_from:
                                            for relation in links:
                                                if not relation.related_model._meta.model_name in ['vendormasterdata']:
                                                    search = { relation.field.name: from_id }
                                                    update = { relation.field.name: to_id, 'updated_by_id': current_user_id }
                                                    if relation.field.many_to_many:
                                                        for records in relation.related_model.objects.filter(**search):
                                                            eval(f'records.{relation.field.name}.add(to_id)')
                                                            eval(f'records.{relation.field.name}.remove(from_id)')
                                                            search1 = { "pk": records.id }
                                                            update1 = { "updated_by_id": current_user_id }
                                                            relation.related_model.objects.filter(**search1).update(**update1)
                                                    else:
                                                        relation.related_model.objects.filter(**search).update(**update)
                                            details_from.updated_by_id = current_user_id
                                            details_from.is_deleted = 1
                                            details_from.save()
                                            MergeLog.cmobjects.create(
                                                type=type,
                                                from_id=from_id,
                                                to_id=to_id,
                                                created_by_id=current_user_id,
                                            )
                                        else:
                                            error_msg.append([type,from_id_list,to_id,f"Record not found from_id: {from_id}"])
                                    success_msg.append([type,from_id_list,to_id])
                                else:
                                    error_msg.append([type,from_id_list,to_id,f"Record not found to_id: {to_id}"])
                        else:
                            error_msg.append([type,from_id_list,to_id,f"Invalid from_id_list"])
                    else:
                        error_msg.append([type,from_id_list,to_id,f"Invalid type"])
                return Response(
                    {
                        'success_msg': success_msg,
                        'error_msg': error_msg,
                        'status': status.HTTP_202_ACCEPTED,
                        "request_status": 1
                    }
                )
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class UsedDataAPIView(APIView):
    
    

    def get(self, request):
        type_map = {
            "uom": "UnitOfMesurement",
            "material_group": "MaterialType",
            "material": "VendorMaterialMaster",
            "vendor": "VendorMasterV2",
        }
        type = self.request.query_params.get('type', None)
        id = self.request.query_params.get('id', None)
        try:
            if type is None:
                raise APIException({'request_status': 0, 'msg': "type not provided"})
            if id is None:
                raise APIException({'request_status': 0, 'msg': "id is required"})
            if type in type_map:
                details = eval(f'{type_map[type]}.cmobjects.filter(pk=id).first()')
                if details:
                    links = eval(f'{type_map[type]}._meta.related_objects')
                    data = []
                    for relation in links:
                        search = { relation.field.name: id }
                        count = relation.related_model.cmobjects.filter(**search).count()
                        data.append({
                            'name': relation.related_model._meta.verbose_name,
                            'field': relation.field.name,
                            'count': count,
                        })
                    return Response(
                        {
                            'results': data,
                            "request_status": 1
                        }
                    )
                else:
                    raise APIException({'request_status': 0, 'msg': 'Record not found'})
            else:
                raise APIException({'request_status': 0, 'msg': 'Invalid type'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class CleanRequestLogAPIView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        today = date.today()
        date_before_one_week = today - timedelta(days=7)

        return Response(
            {'results': {
                'Data': None,
            },
                'msg': 'Successfully delete',
                'status': status.HTTP_202_ACCEPTED,
                "request_status": 1
            })


class CommentsAPIView(APIView):
    """
    CRUD API for Comments model
    """
    
    

    def get(self, request):
        """
        Get a list of all Comments
        """
        ref_type = self.request.query_params.get('ref_type', None)
        ref_id = self.request.query_params.get('ref_id', None)
        all= self.request.query_params.get('all', None)

        if ref_type and ref_id:
            comments_details = Comments.cmobjects.filter(ref_type=ref_type, ref_id=ref_id).order_by('-id')
            serializer = CommentsSerializer(comments_details, many=True)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        # comments_list = Comments.cmobjects.values()
        comments_list = Comments.cmobjects.select_related('organization', 'created_by').all()

        show_list = []
        if search:
            show_list = []
            ref_data_cache = {}

            for comment in comments_list:
                ref_key = (comment.ref_type, comment.ref_id)
                if ref_key not in ref_data_cache:
                    fixed_data = get_model_details(comment.ref_type)
                    model_name = fixed_data['model_name']
                    model = apps.get_model('procurement', model_name)
                    ref_data_cache[ref_key] = model.cmobjects.filter(*search, pk=comment.ref_id).exists()

                if ref_data_cache[ref_key]:
                    show_list.append(comment.id)

        comments_list = Comments.cmobjects.filter(id__in=show_list).select_related('organization', 'created_by').order_by('-id')
        if all == 'true':
            serializer = CommentsSerializer(comments_list, many=True)
            return Response({'results': serializer.data})   
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(comments_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
         
        serializer = CommentsSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        """
        Create a new Tax Head
        """
        request.data['created_by_id'] = request.user.id
        serializer = CommentsSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Comments
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        comments_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Comments
                """
                if Comments.cmobjects.filter(pk=comments_id, organization_id=organization_id).exists():
                    comments_details = Comments.cmobjects.filter(pk=comments_id).first()

                    serializer = CommentsSerializer(comments_details, data=request.data)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Comments
                """
                if Comments.cmobjects.filter(pk=comments_id, organization_id=organization_id).exists():
                    comments_details = Comments.cmobjects.get(
                        pk=comments_id, organization_id=organization_id)
                    comments_details.is_deleted = True
                    comments_details.save()

                    return Response({'results': {
                        'comments': Comments.objects.filter(pk=comments_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Tax Head',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class ConvertPDFAPIView(APIView):
    
    

    def post(self, request):
        try:
            content = self.request.data.get('content', '')
            size = self.request.data.get('size', 'letter landscape')
            margin = self.request.data.get('margin', '2cm')
            decoded_content = str(base64.b64decode(str(content).encode("utf-8")).decode("utf-8"))
            decoded_content = """<style>
                    @page {
                        size: """+size+""";
                        margin: """+margin+""";
                    }
                    @font-face {
                    font-family: Roboto;
                    src: url("static/fonts/Roboto-Regular.ttf");
                    }

                    body {
                    font-family: Roboto;
                    }
                </style>""" + decoded_content
            
            result = pisa.CreatePDF(decoded_content, dest=BytesIO())
            if result.err:
                raise APIException({'request_status': 0, 'msg': str(result.err)})
            response = HttpResponse(content_type='application/pdf')
            response.write(result.dest.getvalue())
            response['Content-Disposition'] = 'attachment; filename="foo.pdf"'
            return response
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': ''})
        
class ConvertURLToPDFAPIView(APIView):
    
    

    def post(self, request):
        try:
            url = request.data.get('url', '')
            response = requests.get(url)
            if response.status_code != 200:
                raise APIException({'request_status': 0, 'msg': 'Failed to fetch URL content'})

            html_content = response.text

            pdf_dir = os.path.join(settings.MEDIA_ROOT, 'pdfs')

            if not os.path.exists(pdf_dir):
                os.makedirs(pdf_dir, exist_ok=True)

            pdf_filename = f"{uuid.uuid4().hex}.pdf"
            pdf_path = os.path.join(pdf_dir, pdf_filename)

            pdf_file = BytesIO()
            pisa_status = pisa.CreatePDF(html_content, dest=pdf_file)
            print(pisa_status)
            if pisa_status.err:
                raise APIException({'request_status': 0, 'msg': 'Error generating PDF'})

            with open(pdf_path, "wb") as f:
                f.write(pdf_file.getvalue())

            file_url = f"{settings.MEDIA_URL}pdfs/{pdf_filename}"
            return Response({'request_status': 1, 'pdf_url': request.build_absolute_uri(file_url)})

        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': 'Error generating PDF'})
class ExcelManipulationAPIView(APIView):
    
    

    def get(self, request):
        try:
            file_path = 'media/storage/save.xlsx'
            if os.path.exists(file_path):
                with open(file_path, "rb") as excel:
                    data = excel.read()
                response = HttpResponse(data,content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                return response
            else:
                raise APIException({'request_status': 0, 'msg': 'FileNotFound'})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e)})

    def post(self, request):
        try:
            decoded_content = request.FILES['content'].read()
            directory = 'media/storage/'
            file_path = f'{directory}save.xlsx'
            old_file_path = f'{directory}old_save.xlsx'
            if not os.path.exists(directory):
                os.makedirs(directory)
            if os.path.exists(file_path):
                shutil.copy(file_path, old_file_path)
            with open(file_path, "wb+") as destination:
                destination.write(decoded_content)
            return Response({'msg': 'Saved successfully', "request_status": 1})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e)})


class DynamicFormAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                data = []
                model_map = {
                    'PlantMachineryMaster': {
                        'app_name': 'plant_machinery',
                        'data_model_name': 'PlantMachineryData',
                        'parent_field': 'plantmachinery_id',
                    }
                }
                file_name = request.data.get('file_name', None)
                fields = request.data.get('fields', {}) # fields is required to search in excel file
                organization_id = self.request.query_params.get('organization_id', None)
                model_name = request.data.get('model_name', None)
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException({'request_status': 0, 'msg': "file not found"})
                sheet_xlsx = pd.read_excel(path)
                columns = list(fields.keys())
                for column in columns:
                    sheet_xlsx[column] = sheet_xlsx[column].ffill(axis=0)
                    if fields[column]['type'] == 'number':
                        sheet_xlsx[column] = np.where(sheet_xlsx[column] == '-', 0, sheet_xlsx[column])
                        sheet_xlsx[column] = sheet_xlsx[column].astype(float)
                sheet_xlsx = sheet_xlsx.replace(np.nan, None)
                model = apps.get_model(model_map[model_name]['app_name'], model_name)
                data_model = apps.get_model(model_map[model_name]['app_name'], model_map[model_name]['data_model_name'])
                master_list = []
                for index, row in sheet_xlsx.iterrows():
                    temp = model.objects.create(organization_id=organization_id)
                    master_list.append(temp.id)
                for index, row in sheet_xlsx.iterrows():
                    for key,value in row.items():
                        # if fields[key]['field'] == 'number'
                        temp_dict = {
                            model_map[model_name]['parent_field']: master_list[index],
                            'form_id': fields[key]['field'],
                            'value': value,
                        }
                        data.append(data_model(**temp_dict))
                data_model.objects.bulk_create(data, batch_size=100, ignore_conflicts=False)
                return Response(
                    {'results': {
                        'Data': len(master_list),
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})




class ExportHierarchicalDataView(APIView):
    
    permission_classes = (AllowAny,)

    def flatten_json(self, json_data):
        flat_data = []
        
        for project in json_data['projects']:
            project_name = project['project_name']
            
            for result in project['results']:
                chainage_name = result['name']
                
                for activity in result['activity_master']:
                    activity_name = activity['name']
                    
                    for sub_activity in activity['sub_activity_master']:
                        sub_activity_name = sub_activity['name']
                        
                        for item in sub_activity['activity_items']:
                            item_data = {
                                'Project Name': project_name,
                                'Chainage Name': chainage_name,
                                'Activity Name': activity_name,
                                'Sub-Activity Name': sub_activity_name,
                                # 'Item ID': item['id'],
                                'Activity': item['activity'],
                                'Activity Group': item['activity_group'],
                                'Qty Left': item['qty_left'],
                                'Budget Left': item['budget_left'],
                                'Entry Date': item['entry_date'],
                            }
                            
                            budget_breakdown = item.get('budget_breakdown', [])
                            consumption_breakdown = item.get('consumption_breakdown', [])
                            
                        
                            for i, budget_entry in enumerate(budget_breakdown):
                                budget_data = item_data.copy()
                                budget_data.update({
                                    f'Budget (Entry Date {i+1})': budget_entry.get('amount', ''),
                                    f'Budget Qty (Entry Date {i+1})': budget_entry.get('qty', ''),
                                    f'Budget Rate (Entry Date {i+1})': budget_entry.get('rate', ''),
                                })
                                flat_data.append(budget_data)
                            
                            
                            for i, consumption_entry in enumerate(consumption_breakdown):
                                consumption_data = item_data.copy()
                                consumption_data.update({
                                    f'Consumption (Entry Date {i+1})': consumption_entry.get('amount', ''),
                                    f'Consumption Qty (Entry Date {i+1})': consumption_entry.get('qty', ''),
                                    f'Consumption Rate (Entry Date {i+1})': consumption_entry.get('rate', ''),
                                })
                                flat_data.append(consumption_data)
        
        return flat_data
    def get(self, request):
       
        with open('response.json') as file:
            json_data = json.load(file)
        
        flat_data = self.flatten_json(json_data)
        
        df = pd.DataFrame(flat_data)
        print(df)
        grouped_df = df.groupby(['Project Name', 'Chainage Name', 'Activity Name', 'Sub-Activity Name']).sum().reset_index()
        
        grouped_df = grouped_df[['Project Name', 'Chainage Name', 'Activity Name', 'Sub-Activity Name',
                                'Qty Left', 'Budget Left',
                                *[col for col in grouped_df.columns if 'Budget' in col or 'Consumption' in col]]]
        
        print(grouped_df.columns)
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=exported_data.xlsx'
        
        with pd.ExcelWriter(response, engine='openpyxl') as writer:
            df.to_excel(writer, index=False)
        
        return response


    




class HTMLToExcelView(APIView):
    permission_classes = (AllowAny,)

    def parse_html_table(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        table = soup.find('table')
        
        workbook = openpyxl.Workbook()
        sheet = workbook.active

        for row_idx, row in enumerate(table.find_all('tr'), start=1):
            col_idx = 1
            row_style = row.get('style')
            row_bg_color = self.extract_background_color(row_style)

            for cell in row.find_all(['td', 'th']):
                rowspan = int(cell.get('rowspan', 1))
                colspan = int(cell.get('colspan', 1))
                value = cell.get_text(strip=True)

                cell_style = cell.get('style')
                cell_bg_color = self.extract_background_color(cell_style)

                while True:
                    cell_obj = sheet.cell(row=row_idx, column=col_idx)
                    if isinstance(cell_obj, openpyxl.cell.MergedCell):
                        col_idx += 1
                    elif cell_obj.value is not None:
                        col_idx += 1
                    else:
                        break

                cell = sheet.cell(row=row_idx, column=col_idx, value=value)
                fill_color = cell_bg_color or row_bg_color
                if fill_color:
                    fill_color = fill_color.lstrip('#')
                    if len(fill_color) == 3:
                        fill_color = ''.join([2 * c for c in fill_color])
                    cell.fill = openpyxl.styles.PatternFill(
                        start_color=fill_color, end_color=fill_color, fill_type='solid'
                    )

                if row_idx == 1:
                    cell.font = openpyxl.styles.Font(bold=True)

                if rowspan > 1 or colspan > 1:
                    sheet.merge_cells(start_row=row_idx, start_column=col_idx, 
                                      end_row=row_idx + rowspan - 1, end_column=col_idx + colspan - 1)

                col_idx += colspan

        return workbook

    def extract_background_color(self, style):
        if not style:
            return None
        for part in style.split(';'):
            if 'background' in part:
                color_part = part.split(':')[1].strip()
                if color_part:
                    return color_part
        return None

    def get(self, request):
        html_file_path = 'a.html'

        with open(html_file_path, 'r', encoding='utf-8') as file:
            html_content = file.read()
            workbook = self.parse_html_table(html_content)

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename=activity_budget_summary.xlsx'
        workbook.save(response)
        return response


class SAPVendorFetch(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        current_start_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        current_end_date = (datetime.now() - timedelta(days=0)).strftime('%Y-%m-%d')
        start_date = self.request.query_params.get('start_date', current_start_date)
        end_date = self.request.query_params.get('end_date', current_end_date)
        company_code = self.request.query_params.get('company_code', None)
        check_blocked = self.request.query_params.get('check_blocked', None)

        error_msg = []
        count_data = {'valid': 0, 'created': 0, 'total': 0}
        try:
            search = []
            if company_code:
                search.append(Q(sap_code=company_code))
            else:
                search.append(Q(sap_auth_key__isnull=False))
                search.append(~Q(sap_auth_key=''))
            company_code_records = Company.cmobjects.filter(*search).values('id','sap_code','sap_auth_key')
            organization_id = 1
            payload_data = { 'Record': [] }
            blocked_indicator_list = {
                'PostingBlock': ['X',],
                'PurchaseBlock': ['X',],
                'PaymentBlock': ['*','A','B','G','I','N','P','Q','R','V','W','X','Y',],
            }
            for company_code_record in company_code_records:
                temp_list = {
                    "CompanyCode": company_code_record['sap_code'],
                    "AuthorizationKey": company_code_record['sap_auth_key'],
                }
                if check_blocked:
                    for blocked_indicator_key, blocked_indicator_value in blocked_indicator_list.items():
                        for blocked_indicator in blocked_indicator_value:
                            temp_list_update = temp_list.copy()
                            temp_list_update[blocked_indicator_key] = blocked_indicator
                            payload_data["Record"].append(temp_list_update)
                else:
                    temp_list['CreatedOnFrom'] = start_date
                    temp_list['CreatedOnTo'] = end_date
                    payload_data["Record"].append(temp_list)
            sap_resp,error_msg = sap_request(type='post',url=os.getenv('SAP_VENDOR', ''),data=payload_data,data_type='json')
            if sap_resp:
                if 'Result' in sap_resp:
                    company_list_temp = Company.cmobjects.filter(organization_id=organization_id).values('id','sap_code',)
                    company_list = {str(k['sap_code']).lower().strip(): k['id'] for k in company_list_temp}
                    account_group_list_temp = AccountsHead.cmobjects.filter(organization_id=organization_id).values('id','name',)
                    account_group_list = {str(k['name']).lower().strip(): k['id'] for k in account_group_list_temp}
                    if not isinstance(sap_resp['Result'], list):
                        sap_resp['Result'] = [sap_resp['Result']]
                    
                    for data in sap_resp.get('Result', []):
                        count_data['total'] += 1
                        if 'VendorCode' in data:
                            count_data['valid'] += 1
                            vendor_code = str(data['VendorCode']).strip()
                            search_term1 = str(data.get('SearchTerm1','')).strip()
                            vendor_id = None
                            if search_term1.startswith("PMS-"):
                                vendor_id = int(search_term1.replace("PMS-", ""))
                               
                            vendor_data = {
                                'organization_id': organization_id,
                                'is_created_through_sap': True,
                                'vendor_name': str(data.get('Name', '')).strip(),
                                'name_2': str(data.get('Name2', '')).strip(),
                                'vendor_contact_no': str(data.get('MobileNo', '')).strip(),
                                'vendor_email_id': str(data.get('EMail', '')).strip(),
                                'street': str(data.get('Street1', '')).strip(),
                                'street2': str(data.get('Street2', '')).strip(),
                                'street3': str(data.get('Street3', '')).strip(),
                                'vendor_address': str(data['Street1'] if 'Street1' in data else '')+' '+str(data['Street2'] if 'Street2' in data else '')+' '+str(data['Street3'] if 'Street3' in data else ''),
                                'postal_code': str(data.get('PostalCode', '')).strip(),
                                'district': str(data.get('District', '')).strip(),
                                'pan_no': str(data.get('PAN', '')).strip(),
                                'region': str(data.get('Region', '')).strip(),
                                'location': str(data.get('City', '')).strip(),
                                'created_on': str(data.get('CreatedOn', '')).strip(),
                                # 'company_code': str(data.get('CompanyCode', '')).strip(),
                                'company_code_id': (company_list[str(data['CompanyCode']).lower().strip()] if str(data['CompanyCode']).lower().strip() in company_list.keys() else None) if 'CompanyCode' in data else None,
                                'search_term2': str(data.get('SearchTerm2', '')).strip(),
                                'tax_number': str(data.get('GSTNo', '')).strip(),
                                'account_group_id': (account_group_list[str(data['AccountGroup']).lower().strip()] if str(data['AccountGroup']).lower().strip() in account_group_list.keys() else None) if 'AccountGroup' in data else None,
                                'status':'approved',
                                'posting_blocked_indicator': data.get('PostingBlock', None),
                                'purchase_blocked_indicator': data.get('PurchaseBlock', None),
                                'payment_blocked_indicator': data.get('PaymentBlock', None),
                            }
                            search={}
                            if vendor_id:
                                search['pk']= vendor_id
                                vendor_data['vendor_code']=vendor_code
                            else :
                                search['vendor_code'] = vendor_code   
                            try:
                                instance, created = VendorMasterV2.cmobjects.update_or_create(
                                    **search,
                                    defaults=vendor_data
                                )
                                if created:
                                    count_data['created'] += 1
                            except Exception as e:
                                error_msg.append(str(e))

                if 'Message' in sap_resp:
                    error_msg.append(sap_resp)
        except Exception as e:
            error_msg.append(str(e))
        return Response({'count_data': count_data, 'error_msg': error_msg})



class SAPMaterialFetch(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        current_start_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        current_end_date = (datetime.now() - timedelta(days=0)).strftime('%Y-%m-%d')
        start_date = self.request.query_params.get('start_date', current_start_date)
        end_date = self.request.query_params.get('end_date', current_end_date)
        check_blocked = self.request.query_params.get('check_blocked', None)

        error_msg = []
        count_data = {'valid': 0, 'update_or_create': 0, 'total': 0}
        try:
            organization_id = 1
            unit_of_mesurement_id = 1
            formatted_details = get_sap_plant_auth('material')
            if formatted_details:
                payload_data = { "Record": [] }
                blocked_indicator_list = {
                    'BlockInd': ['01','02',],
                }
                for detail_key,detail_value in formatted_details.items():
                    temp_list = {
                        "Plant": detail_key,
                        "AuthorizationKey": detail_value['sap_auth_key'],
                    }
                    if check_blocked:
                        for blocked_indicator_key, blocked_indicator_value in blocked_indicator_list.items():
                            for blocked_indicator in blocked_indicator_value:
                                temp_list_update = temp_list.copy()
                                temp_list_update[blocked_indicator_key] = blocked_indicator
                                payload_data["Record"].append(temp_list_update)
                    else:
                        temp_list['CreatedOnFrom'] = start_date
                        temp_list['CreatedOnTo'] = end_date
                        payload_data["Record"].append(temp_list)
                sap_resp,error_msg = sap_request(type='post',url=os.getenv('SAP_MATERIAL', ''),data=payload_data,data_type='json')
                if sap_resp:
                    if 'Result' in sap_resp:
                        group_list_temp = MaterialType.cmobjects.filter(organization_id=organization_id).values('id','name',)
                        group_list = {str(k['name']).lower().strip(): k['id'] for k in group_list_temp}
                        uom_list_temp = UnitOfMesurement.cmobjects.filter(organization_id=organization_id).values('id','symbol',)
                        uom_list = {str(k['symbol']).lower().strip(): k['id'] for k in uom_list_temp}
                        if not isinstance(sap_resp['Result'], list):
                            sap_resp['Result'] = [sap_resp['Result']]
                        for data in sap_resp['Result']:
                            count_data['total'] += 1
                            if 'Material' in data:
                                plant_code = str(data['Plant']).strip() if 'Plant' in data else ''
                                if str(data['Material']).lower().strip().startswith(tuple(formatted_details[plant_code]['sap_start_codes'].lower().strip().split(','))):
                                    count_data['valid'] += 1
                                    sap_code = str(data['Material']).strip()
                                    vendor_data = {
                                        'organization_id': organization_id,
                                        'is_created_through_sap': True,
                                        'material_name': str(data.get('Description', '')).strip(),
                                        'material_descriptions': str(data.get('Description', '')).strip(),
                                        'created_on': str(data.get('CreatedOn', '')).strip(),
                                        'plant': plant_code,
                                        'hsncode': str(data.get('HSN', '')).strip(),
                                        'materialtype': str(data.get('MaterialType', '')).strip(),
                                        'material_type_id': (group_list[str(data['MaterialGroupDescription']).lower().strip()] if str(data['MaterialGroupDescription']).lower().strip() in group_list.keys() else None) if 'MaterialGroupDescription' in data else None,
                                        'unit_of_mesurement_id': (uom_list[str(data['UoM']).lower().strip()] if str(data['UoM']).lower().strip() in uom_list.keys() else unit_of_mesurement_id) if 'UoM' in data else unit_of_mesurement_id,
                                        'blocked_indicator': data.get('BlockedInd', None),
                                    }
                                    try:
                                        VendorMaterialMaster.cmobjects.update_or_create(sap_code=sap_code, defaults=vendor_data)
                                        count_data['update_or_create'] += 1
                                    except Exception as e:
                                        error_msg.append(str(e))
                    else:
                        error_msg.append(sap_resp)
        except Exception as e:
            error_msg.append(str(e))
        return Response({'count_data': count_data, 'error_msg': error_msg})

class SAPGRNFetch(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        error_msg = []
        count_data = {'valid': 0, 'update_or_create': 0, 'total': 0}
        try:
            current_start_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
            current_end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = request.query_params.get('start_date', current_start_date)
            end_date = request.query_params.get('end_date', current_end_date)
            type=request.query_params.get('type', None)
        
            organization_id = 1
            formatted_details = get_sap_plant_auth('grn')  
            print(formatted_details)
            sap_request_data = {"Record": []}
            for plant_code, auth in formatted_details.items():
                for movement_type in [101, 102, 122]:
                    sap_request_data["Record"].append({
                        "Plant": plant_code,
                        "AuthorizationKey": auth['sap_auth_key'],
                        "CreatedOnFrom": start_date,
                        "CreatedOnTo": end_date,
                        "MovementType": movement_type
                    })
                    
            sap_resp, error_msg_resp = sap_request(type='get', url=os.getenv('SAP_GRN', ''), 
                                                 data=sap_request_data, data_type='json')
            # print('sap_resp',sap_resp)
            if error_msg_resp:
                error_msg.extend(error_msg_resp)

            if not sap_resp or 'Result' not in sap_resp:
                error_msg.append('No result returned from SAP.')
                return Response({'count_data': count_data, 'error_msg': error_msg})

            po_items_qs = PurchaseOrderItems.cmobjects.filter(organization_id=organization_id,purchase_order__sap_code__isnull=False,item__sap_code__isnull=False).select_related('purchase_order','item','uom'             
            ).prefetch_related('purchase_order__material_requests','purchase_order__indents'
            ).values(
                'id', 
                'purchase_order_id',
                'item_id',
                'purchase_order__sap_code',
                'purchase_order__site_id',
                'purchase_order__store_id', 
                'purchase_order__project_id',
                'purchase_order__financialyear_id',
                'purchase_order__rfq_vendor_id',
                'purchase_order__enquiry_at_once_id',
                'purchase_order__quotation_id',
                'purchase_order__cst_id',
                'purchase_order__vendor_id',
                'purchase_order__indent_id',
                'purchase_order__material_request_id',
                'item__sap_code',
                'item__unit_of_mesurement_id',
                # 'uom__symbol',
                'material_request_item_id',
                'indent_item_id',
                'rfq_vendor_item_id', 
                'enquiry_at_once_item_id',
                'quotation_item_id',
                'cst_item_id'
            ).annotate(
                material_requests_ids=GroupConcat("purchase_order__material_requests__pk"),
                indents_ids=GroupConcat("purchase_order__indents__pk")
            )
            
            po_map = {}
            for item in po_items_qs:
                if not str(item['purchase_order__sap_code']).strip().lower() in po_map:
                    po_map[str(item['purchase_order__sap_code']).strip().lower()] = {}
                po_map[str(item['purchase_order__sap_code']).strip().lower()][str(item['item__sap_code']).strip().lower()] = item
            # print(po_map)
            vendor_qs = VendorMasterV2.cmobjects.filter(organization_id=organization_id
            ).values('id', 'vendor_code')
            vendor_map = {str(v['vendor_code']).lower().strip(): v['id'] for v in vendor_qs}
            uom_qs = UnitOfMesurement.cmobjects.filter(organization_id=organization_id).values('id', 'symbol')
            uom_map = {str(u['symbol']).lower().strip(): u['id'] for u in uom_qs}
            grn_items_qs = GRNItems.cmobjects.filter(grn__is_deleted=False,organization_id=organization_id).values(
                'id','received_quantity', 'return_quantity'
            )
            grn_items_map = {
                item['id']: {
                    'received_quantity': item['received_quantity'],
                    'return_quantity': item['return_quantity']
                }
                for item in grn_items_qs
            }

            for row in sap_resp['Result']:
                count_data['total'] += 1
                material_code = str(row.get('Material', '')).strip().lower()
                po_number = str(row.get('PONumber', '')).strip().lower()
                # print("material_code",material_code)
                # print("po_number",po_number)
                ref = None
                if po_number in po_map:
                    if material_code in po_map[po_number]:
                        ref=po_map[po_number][material_code]
                # print(ref)
                if ref:
                    sap_document = str(row.get('MaterialDocument', '')).strip()
                    vendor_code = str(row.get('Vendor', '')).strip().lower()
                    vendor_id = vendor_map.get(vendor_code,None)
                    base_unit = str(row.get('BaseUnit', '')).strip().lower()
                    uom_id = uom_map.get(base_unit,None)
                    movement_type = str(row.get('MovementType', '')).strip()
                    quantity = float(row.get('Quantity', 0))
                    amount = float(row.get('Amount', 0))
                    rate = float(amount / quantity) if quantity != 0 else 0
                    received_quantity = quantity if movement_type in ['101'] else 0
                    return_quantity = quantity if movement_type in ['102', '122'] else 0
                    grn_data = {
                        'organization_id': organization_id,
                        'bill_date': row.get('DocumentDate',None),
                        'date': row.get('PostingDate',None),
                        'created_on': row.get('CreatedOn',None),
                        'reference': str(row.get('Reference', '')).strip(),
                        'header_text': str(row.get('HeaderText', '')).strip(),
                        'movement_type': movement_type,
                        'sap_code': sap_document,
                        'batch_no': str(row.get('BatchNo', '')).strip(),
                        'plant': str(row.get('Plant', '')).strip(),
                        'storage_location': str(row.get('StorageLocation', '')).strip(),
                        'purchase_order_id': ref.get('purchase_order_id',None),
                        'site_id': ref.get('purchase_order__site_id',None),
                        'store_id': ref.get('purchase_order__store_id',None),
                        'project_id': ref.get('purchase_order__project_id',None),
                        'financialyear_id': ref.get('purchase_order__financialyear_id',None),
                        'rfq_vendor_id': ref.get('purchase_order__rfq_vendor_id',None),
                        'enquiry_at_once_id': ref.get('purchase_order__enquiry_at_once_id',None),
                        'quotation_id': ref.get('purchase_order__quotation_id',None),
                        'cst_id': ref.get('purchase_order__cst_id',None),
                        'vendor_id': vendor_id,
                        'total_amount': amount,
                        'total_received_quantity': received_quantity,
                        'total_return_quantity': return_quantity,
                    }
                    grn_obj, created = GRN.cmobjects.update_or_create(
                        organization_id=organization_id,
                        sap_code=sap_document,
                        defaults=grn_data
                    )
                    if ref.get('material_requests_ids'):
                        grn_obj.material_requests.set(ref['material_requests_ids'].split(","))
                    if ref.get('indents_ids'):
                        grn_obj.indents.set(ref['indents_ids'].split(","))
                    grn_item_data = {
                        'organization_id': organization_id,
                        'quantity': quantity,
                        'received_quantity': received_quantity,
                        'return_quantity': return_quantity,
                        'rate': rate,
                        'item_amount': amount,
                        'item_id': ref.get('item_id',None),
                        'uom_id': uom_id,
                        'purchase_order_item_id': ref.get('id',None),
                        'material_request_item_id': ref.get('material_request_item_id',None),
                        'indent_item_id': ref.get('indent_item_id',None),
                        'rfq_vendor_item_id': ref.get('rfq_vendor_item_id',None),
                        'enquiry_at_once_item_id': ref.get('enquiry_at_once_item_id',None),
                        'quotation_item_id': ref.get('quotation_item_id',None),
                        'cst_item_id': ref.get('cst_item_id',None),
                        'is_auto_approved': True,
                    }
                    
                    grn_item_obj, item_created = GRNItems.cmobjects.update_or_create(
                        grn=grn_obj,
                        item_id= ref.get('item_id',None),
                        defaults=grn_item_data
                    )                    
                    if not item_created:
                        old_item_data = grn_items_map.get(grn_item_obj.id, {})
                        if old_item_data:
                            received_quantity = old_item_data['received_quantity'] - received_quantity 
                            return_quantity = old_item_data['return_quantity'] - return_quantity  
                    final_received_quantity = calculate_quantity_on_uom(ref.get('item_id',None), ref.get('item__unit_of_mesurement_id',None),uom_id, received_quantity)
                    final_return_quantity = calculate_quantity_on_uom(ref.get('item_id',None), ref.get('item__unit_of_mesurement_id',None),uom_id, return_quantity)         
                    update_inventory(
                        organization_id,
                        ref.get('item_id',None),
                        None,
                        ref.get('store_id'),
                        ref.get('site_id'),
                        float(final_received_quantity - final_return_quantity),
                        rate,
                        "GRN Approve",
                        grn_obj.id,
                        validate_financialyear(grn_obj)
                    )
                    count_data['update_or_create'] += 1
                    
        except Exception as e:
            error_msg.append(str(e))

        return Response({'count_data': count_data, 'error_msg': error_msg})
    
class SAPGRNMaterialIssueFetch(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        check_list = []
        processed_list = []
        error_msg = []
        count_data = {'valid': 0, 'update_or_create': 0, 'total': 0}
        try:
            current_start_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
            current_end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = request.query_params.get('start_date', current_start_date)
            end_date = request.query_params.get('end_date', current_end_date)
            pk__in = request.query_params.get('pk__in', None)
            project_id__in = request.query_params.get('project_id__in', None)
            pk__in = str(pk__in).strip().split(',') if pk__in else None
            project_id__in = str(project_id__in).strip().split(',') if project_id__in else None
            type=str(request.query_params.get('type', 'grn')).strip()
            organization_id = 1
            type_config = {
                'material_issue': {
                    'movement_types': [[201, 281, 541, 601, 641, 653], [202, 282, 542, 602, 642, 654]],
                    'model': MaterialIssue,
                    'item_model': MaterialIssueItems,
                    'item_foreign_key': 'material_issue',
                    'material_match_field': 'requested_material_id',
                    'amount_field':'amount',
                    'transaction_type': 'Issue Item Approve',
                },
                'grn': {
                    'movement_types': [[101, 122, 501, 701], [102, 123, 502, 702]],
                    'model': GRN,
                    'item_model': GRNItems,
                    'item_foreign_key': 'grn',
                    'material_match_field': 'item_id',
                    'amount_field':'item_amount',
                    'transaction_type': 'GRN Approve',

                }
            }
            config = type_config.get(type)
            formatted_details = get_sap_plant_auth(type='grn',pk__in=pk__in,project_id__in=project_id__in)  
            sap_request_data = {"Record": []}
            for plant_code, auth in formatted_details.items():
                for movement_type in [x for xs in config['movement_types'] for x in xs]:
                    sap_request_data["Record"].append({
                        "Plant": plant_code,
                        "AuthorizationKey": auth['sap_auth_key'],
                        "FromDate": start_date,
                        "ToDate": end_date,
                        "MovementType": movement_type
                    })
            sap_resp, error_msg_resp = sap_request(type='get', url=os.getenv('SAP_GRN', ''), 
                                                 data=sap_request_data, data_type='json')
            if error_msg_resp:
                error_msg.extend(error_msg_resp)
            if not sap_resp or 'Result' not in sap_resp:
                error_msg.append('No result returned from SAP.')
                return Response({'count_data': count_data, 'error_msg': error_msg})
            po_map = {}
            material_master_map = {}
            if type == 'grn': 
                po_items_qs = PurchaseOrderItems.cmobjects.filter(
                    organization_id=organization_id, purchase_order__sap_code__isnull=False, item__sap_code__isnull=False
                ).select_related('purchase_order', 'item', 'uom').prefetch_related(
                    'purchase_order__material_requests', 'purchase_order__indents'
                ).values(
                    'id', 'purchase_order_id', 'item_id', 'purchase_order__sap_code',
                    'purchase_order__site_id', 'purchase_order__store_id', 'purchase_order__project_id',
                    'purchase_order__financialyear_id', 'purchase_order__rfq_vendor_id',
                    'purchase_order__enquiry_at_once_id', 'purchase_order__quotation_id',
                    'purchase_order__cst_id', 'purchase_order__vendor_id', 'purchase_order__indent_id',
                    'purchase_order__material_request_id', 'item__sap_code', 'item__unit_of_mesurement_id',
                    'material_request_item_id', 'indent_item_id', 'rfq_vendor_item_id', 'enquiry_at_once_item_id',
                    'quotation_item_id', 'cst_item_id', 'sap_item_no',
                ).annotate(
                    material_requests_ids=GroupConcat("purchase_order__material_requests__pk"),
                    indents_ids=GroupConcat("purchase_order__indents__pk")
                )
                for item in po_items_qs:
                    if not str(item['purchase_order__sap_code']).strip().lower() in po_map:
                        po_map[str(item['purchase_order__sap_code']).strip().lower()] = {}

                    # po_map[str(item['purchase_order__sap_code']).strip().lower()][str(item['item__sap_code']).strip().lower()] = item
                    po_map[str(item['purchase_order__sap_code']).strip().lower()][str(item['sap_item_no']).strip().lower()] = item
            else:
                material_master_map = {
                    str(v['sap_code']).strip().lower(): v
                    for v in VendorMaterialMaster.cmobjects.filter(organization_id=organization_id,sap_code__isnull=False).annotate(
                    item_id=F('pk'),
                    item__unit_of_mesurement_id = F('unit_of_mesurement_id')
                ).values(
                    'item_id','sap_code','item__unit_of_mesurement_id',
                )
                }     
            vendor_map = {
                str(v['vendor_code']).strip().lower(): v['id']
                for v in VendorMasterV2.cmobjects.filter(organization_id=organization_id).values('id', 'vendor_code')
            }
            uom_map = {
                str(u['symbol']).strip().lower(): u['id']
                for u in UnitOfMesurement.cmobjects.filter(organization_id=organization_id).values('id', 'symbol')
            }
            item_model_class = config['item_model']
            foreign_key_field = config['item_foreign_key']
            material_match_field = config['material_match_field']
            amount_field = config['amount_field']
            # items_map = {
            #     i['id']: i for i in item_model_class.cmobjects.filter(organization_id=organization_id).values('id', 'received_quantity', 'return_quantity')
            # }
            for row in sap_resp['Result']:
                count_data['total'] += 1
                material_code = str(row.get('Material', '')).strip().lower()
                po_number = str(row.get('PONumber', '')).strip().lower()
                plant_code_ref = str(row.get('Plant', '')).strip().lower()
                sap_item_no = str(int(str(row.get('POItem', '0')).strip().lower()))

                site_id = formatted_details.get(plant_code_ref, {}).get('site_id',None)
                store_id = formatted_details.get(plant_code_ref, {}).get('id',None)
                project_id = formatted_details.get(plant_code_ref, {}).get('site__project_id',None)
                ref = None
                if type == 'grn':
                    if po_number in po_map:
                        if sap_item_no in po_map[po_number]:
                            # ref=po_map[po_number][material_code]
                            ref=po_map[po_number][sap_item_no]
                else:
                    if material_code in material_master_map:
                        ref=material_master_map[material_code]            
                if ref:
                    sap_document = str(row.get('MaterialDocument', '')).strip()
                    vendor_code = str(row.get('Supplier', '')).strip().lower()
                    vendor_id = vendor_map.get(vendor_code,None)
                    base_unit = str(row.get('BaseUnit', '')).strip().lower()
                    uom_id = uom_map.get(base_unit,None)
                    movement_type = str(row.get('MovementType', '')).strip()
                    quantity = float(row.get('Quantity', 0))
                    amount = float(row.get('Amount', 0))
                    rate = float(amount / quantity) if quantity != 0 else 0
                    received_quantity = quantity if int(movement_type) in config['movement_types'][0] else 0
                    return_quantity = quantity if int(movement_type) in config['movement_types'][1] else 0
                    financial_year_id = financialyear_id_by_date(row.get('DocumentDate', None))
                    item_id = ref.get('item_id',None) 
                    # item_uom_id = ref.get('item__unit_of_mesurement_id',None)
                    master_data = {
                        'organization_id': organization_id,
                        'bill_date': row.get('DocumentDate',None),
                        'date': row.get('PostingDate',None),
                        'reference': str(row.get('Reference', '')).strip(),
                        'header_text': str(row.get('HeaderText', '')).strip(),
                        'movement_type': movement_type,
                        'sap_code': sap_document,
                        'plant': str(row.get('Plant', '')).strip(),
                        'storage_location': str(row.get('StorageLocation', '')).strip(),
                        'site_id': site_id,
                        'store_id': store_id, 
                        'project_id': project_id,
                        'financialyear_id': financial_year_id if financial_year_id else None,
                        'total_amount': amount,
                        'total_received_quantity': received_quantity,
                        'total_return_quantity': return_quantity,
                        # Additional SAP fields
                        'company_code': str(row.get('ComapnyCode', '')).strip(),
                        'material_year': str(row.get('MaterialYear', '')).strip(),
                        'batch': str(row.get('Batch', '')).strip(),
                        'currency': str(row.get('Currency', '')).strip(),
                        'event_type': str(row.get('EventType', '')).strip(),
                        'valuation_type': str(row.get('ValuationType', '')).strip(),
                        'entered_on': row.get('EnteredOn', None),
                        'user_name': str(row.get('UserName', '')).strip(),
                        'name1': str(row.get('Name1', '')).strip(),
                        'name2': str(row.get('Name2', '')).strip(),
                        'pur_org': str(row.get('PurOrg', '')).strip(),
                        'movement_type_text': str(row.get('MovementTypeText', '')).strip(),
                        'doc_header_text': str(row.get('DocHeaderText', '')).strip(),
                        'time': str(row.get('Time', '')).strip(),
                        'reason_movement': str(row.get('ReasonMovement', '')).strip(),
                        'movement_indicator': str(row.get('MovementIndicator', '')).strip(),

                        'cost_center': str(row.get('CostCenter', '')).strip(),
                        'gl': str(row.get('GL', '')).strip(),
                        'text': str(row.get('Text', '')).strip(),

                        'sales_order': str(row.get('SalesOrder', '')).strip(),
                        'salesorder': str(row.get('Salesorder', '')).strip(),
                        'customer': str(row.get('Customer', '')).strip(),
                        'receipt_indicator': str(row.get('ReceiptIndicator', '')).strip(),
                        'gate_entry_no': str(row.get('GateEntryNo', '')).strip(),
                        'vehicle_no': str(row.get('VehicleNo', '')).strip(),
                        'name3': str(row.get('Name3', '')).strip(),
                        'name4': str(row.get('Name4', '')).strip(),
                        'confirmation_no': str(row.get('ConfirmationNo', '')).strip(),
                        'confirmation_text1': str(row.get('ConfirmationText1', '')).strip(),
                        'confirmation_text2': str(row.get('ConfirmationText2', '')).strip(),
                        'confirmation_text3': str(row.get('ConfirmationText3', '')).strip(),
                        'confirmation_text4': str(row.get('ConfirmationText4', '')).strip(),
                        'gate_entry_date':str(row.get('GateEntryDate', '')).strip(),
                        
                        

                    }  
                    if type == 'grn':
                        master_data.update({
                            'purchase_order_id': ref.get('purchase_order_id',None),
                            'rfq_vendor_id': ref.get('purchase_order__rfq_vendor_id',None),
                            'enquiry_at_once_id': ref.get('purchase_order__enquiry_at_once_id',None),
                            'quotation_id': ref.get('purchase_order__quotation_id',None),
                            'cst_id': ref.get('purchase_order__cst_id',None),
                            'vendor_id': vendor_id,
                        })                      
                    obj, created = config['model'].cmobjects.update_or_create(
                        organization_id=organization_id,
                        sap_code=sap_document,
                        defaults=master_data
                    )
                    if type == 'grn':
                        if ref.get('material_requests_ids'):
                            obj.material_requests.set(ref['material_requests_ids'].split(","))
                        if ref.get('indents_ids'):
                            obj.indents.set(ref['indents_ids'].split(","))
                    item_data = {
                        'organization_id': organization_id,
                        'quantity': quantity,
                        'received_quantity': received_quantity,
                        'return_quantity': return_quantity,
                        'rate': rate,
                        amount_field: amount,
                        'uom_id': uom_id,
                        material_match_field:item_id,
                        'is_auto_approved': True,
                        ##additional fields
                        'unit_of_entry': str(row.get('UnitOfEntry', '')).strip(),
                        'material_description': str(row.get('MaterialDescription', '')).strip(),
                        'qty_unit_entry': str(row.get('QtyUnitEntry', '')).strip(),
                        'po_item': str(row.get('POItem', '')).strip(),
                        'material_doc_item': str(row.get('MaterialDocItem', '')).strip(),
                        'asset': str(row.get('Asset', '')).strip(),
                        'order': str(row.get('Order', '')).strip(),
                        'order_price_unit': str(row.get('OrderPriceUnit', '')).strip(),
                        'order_unit': str(row.get('OrderUnit', '')).strip(),
                        'qty_order_unit': str(row.get('QtyOrderUnit', '')).strip(),
                        'ext_amount': str(row.get('ExtAmount', '')).strip(),
                        'sales_value': str(row.get('SalesValue', '')).strip(),
                        'sales_order_schedule': str(row.get('SalesOrderSchedule', '')).strip(),
                        'sales_order_item': str(row.get('SalesOrderItem', '')).strip(),
                        'del_note_quantity': str(row.get('DelNoteQuantity', '')).strip(),
                        'salesorderitem': str(row.get('Salesorderitem', '')).strip(),
                        'wbs_element': str(row.get('WBSElement', '')).strip(),
                        'network': str(row.get('Network', '')).strip(),
                        'reservation': str(row.get('Reservation', '')).strip(),
                        'item_no_reservation': str(row.get('ItemNoReservation', '')).strip(),
                        'debit_credit_ind': str(row.get('DebitCreditInd', '')).strip(),
                        'sales_value_vat': str(row.get('SalesValueVAT', '')).strip(),
                        'original_line_item': str(row.get('OriginalLineItem', '')).strip(),

                        'delivery_note_unit': str(row.get('DeliveryNoteUnit', '')).strip(),
                        'qty_op_unit': str(row.get('QtyOPU', '')).strip(),

                        'routing_no_operations': str(row.get('RoutingNoOperations', '')).strip(),
                        'smart_number': str(row.get('SmartNumber', '')).strip(),
                        'activity': str(row.get('Activity', '')).strip(),
                        'wbselement': str(row.get('WBSelement', '')).strip(),
                        'stock_segment': str(row.get('StockSegment', '')).strip(),
                        'issue_slip': str(row.get('IssueSlip', '')).strip(),
                        'item_auto_created': str(row.get('ItemAutoCreated', '')).strip(),
                        'multiple_account_assignment': str(row.get('MultipleAccountAssignment', '')).strip(),#currently not in response of sap
                        'consumption': str(row.get('Consumption', '')).strip(),
                        'sub_number': str(row.get('SubNumber', '')).strip(),
                        'counter': str(row.get('Counter', '')).strip(),
                        'rr_text': str(row.get('RRText', '')).strip(),

                    }   
                    if type == 'grn':
                        item_data.update({
                            'purchase_order_item_id': ref.get('id',None),
                            'material_request_item_id': ref.get('material_request_item_id',None),
                            'indent_item_id': ref.get('indent_item_id',None),
                            'rfq_vendor_item_id': ref.get('rfq_vendor_item_id',None),
                            'enquiry_at_once_item_id': ref.get('enquiry_at_once_item_id',None),
                            'quotation_item_id': ref.get('quotation_item_id'),
                            'cst_item_id': ref.get('cst_item_id',None),
                        })
                    filter_kwargs = {
                        foreign_key_field: obj,
                        material_match_field: item_id
                    }
                    if type == 'grn':
                        filter_kwargs['purchase_order_item_id'] = item_data['purchase_order_item_id']
                    item_obj, item_created = item_model_class.cmobjects.update_or_create(
                        defaults=item_data,
                        **filter_kwargs
                    )
                    count_data['update_or_create'] += 1
                    processed_list.append(row)
                else:
                    check_list.append(row)
        except Exception as e:
            error_msg.append(str(e))
        return Response({'count_data': count_data, 'error_msg': error_msg, 'check_list': check_list, 'processed_list': processed_list})


class SAPFinalPOFetch(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        search = {
            'store__sap_plant_id__isnull': False,
            'store__sap_auth_key_po__isnull': False,
            'sap_code__isnull': False,
            'status': 'pending',
        }
        error_msg = []
        count_data = {'count': 0, 'sap_code_list': []}
        sap_code = self.request.query_params.get('sap_code', None)
        pk__in=self.request.query_params.get('pk__in',None)
        store_list = []
        if pk__in:
            store_list = str(pk__in).strip().split(',')
            search['store__in'] = store_list
        if sap_code:
            search['sap_code'] = sap_code
        try:
            po_lists = PurchaseOrder.cmobjects.filter(**search).values('sap_code','store__sap_plant_id','store__sap_auth_key_po',)
            if po_lists:
                data = { "Record": [] }
                for po_list in po_lists:
                    data["Record"].append({
                        "Plant": po_list['store__sap_plant_id'],
                        "AuthorizationKey": po_list['store__sap_auth_key_po'],
                        "PONumber": po_list['sap_code'],
                    })
                sap_resp,error_msg = sap_request(type='get',url=os.getenv('SAP_FINAL_PO', ''),data=data,data_type='json')
                if sap_resp:
                    if 'Result' in sap_resp:
                        if not isinstance(sap_resp['Result'], list):
                            sap_resp['Result'] = [sap_resp['Result']]
                        for data in sap_resp['Result']:
                            if 'PurchasingDocument' in data and 'ReleaseIndicator' in data:
                                if data['ReleaseIndicator'] == 'R':
                                    instance = PurchaseOrder.cmobjects.filter(
                                        sap_code=data['PurchasingDocument'],
                                    ).first()
                                    instance.status = 'approved'
                                    instance.final_releaser_from_sap = data['FinalReleaser']
                                    instance.final_release_date_from_sap = data['FinalReleaseDate']
                                    instance.final_release_time_from_sap = data['FinalReleaseTime']
                                    instance.release_strategy_from_sap = data['ReleaseStrategy']
                                    instance.document_date_from_sap = data['DocumentDate']
                                    instance.purchasing_group_from_sap = data['PurchasingGroup']
                                    instance.attachment_from_sap.save(f"{data['PurchasingDocument']}.pdf",process_attachments({'mime_type': 'application/pdf', 'file_data': data['Attachment_base64']}))
                                    instance.save()
                                    count_data['sap_code_list'].append(data['PurchasingDocument'])
                                    count_data['count'] += 1
                    else:
                        error_msg.append(sap_resp)
        except Exception as e:
            error_msg.append(str(e))
        return Response({'count_data': count_data, 'error_msg': error_msg})


class SAPPRFetch(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        current_start_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        current_end_date = (datetime.now() - timedelta(days=0)).strftime('%Y-%m-%d')
        start_date = self.request.query_params.get('start_date', current_start_date)
        end_date = self.request.query_params.get('end_date', current_end_date)

        error_msg = []
        count_data = {'valid': 0, 'update_or_create': 0, 'total': 0}
        try:
            organization_id = 1
            formatted_details = get_sap_plant_auth('pr')
            if formatted_details:
                data = { "Record": [] }
                for detail_key,detail_value in formatted_details.items():
                    data["Record"].append({
                        "Plant": detail_key,
                        "AuthorizationKey": detail_value['sap_auth_key'],
                        "ChangedOnFrom": start_date,
                        "ChangedOnTo": end_date,
                    })
                sap_resp,error_msg = sap_request(type='get',url=os.getenv('SAP_PR', ''),data=data,data_type='json')
                if sap_resp:
                    if 'Result' in sap_resp:
                        material_list_temp = VendorMaterialMaster.cmobjects.filter(organization_id=organization_id).values('id','sap_code',)
                        material_list = {str(k['sap_code']).lower().strip(): k['id'] for k in material_list_temp}
                        if not isinstance(sap_resp['Result'], list):
                            sap_resp['Result'] = [sap_resp['Result']]
                        for data in sap_resp['Result']:
                            count_data['total'] += 1
                            if 'Material' in data:
                                plant_code = str(data['Plant']).strip() if 'Plant' in data else ''
                                count_data['valid'] += 1
                                pr_no = str(data['PRNo']).strip()
                                requested_material_id = (material_list[str(data['Material']).lower().strip()] if str(data['Material']).lower().strip() in material_list.keys() else None) if 'Material' in data else None
                                site_id = (formatted_details[plant_code]['site_id'] if plant_code in formatted_details.keys() else None) if 'Plant' in data else None
                                store_id = (formatted_details[plant_code]['id'] if plant_code in formatted_details.keys() else None) if 'Plant' in data else None
                                project_id = (formatted_details[plant_code]['site__project_id'] if plant_code in formatted_details.keys() else None) if 'Plant' in data else None
                                vendor_data = {
                                    'organization_id': organization_id,
                                    'pr_no': str(data['PRNo']).strip() if 'PRNo' in data else '',
                                    'pr_item': str(data['PRItem']).strip() if 'PRItem' in data else '',
                                    'material': str(data['Material']).strip() if 'Material' in data else '',
                                    'short_text': str(data['ShortText']).strip() if 'ShortText' in data else '',
                                    'pr_quantity': str(data['PRQuantity']).strip() if 'PRQuantity' in data else '',
                                    'order_quantity': str(data['OrderQuantity']).strip() if 'OrderQuantity' in data else '',
                                    'doc_type': str(data['DocType']).strip() if 'DocType' in data else '',
                                    'purchase_group': str(data['PurchaseGroup']).strip() if 'PurchaseGroup' in data else '',
                                    'plant': str(data['Plant']).strip() if 'Plant' in data else '',
                                    'storage_location': str(data['StorageLocation']).strip() if 'StorageLocation' in data else '',
                                    'matrial_group': str(data['MatrialGroup']).strip() if 'MatrialGroup' in data else '',
                                    'uom': str(data['UoM']).strip() if 'UoM' in data else '',
                                    'requisition_date': str(data['RequisitionDate']).strip() if 'RequisitionDate' in data else '',
                                    'purchase_org': str(data['PurchaseOrg']).strip() if 'PurchaseOrg' in data else '',
                                    'account_assignment_category': str(data['AccountAssignmentCategory']).strip() if 'AccountAssignmentCategory' in data else '',
                                    'valuation_type': str(data['ValuationType']).strip() if 'ValuationType' in data else '',
                                    'wbs_element': str(data['WBSElement']).strip() if 'WBSElement' in data else '',
                                    'gl_account': str(data['GLAccount']).strip() if 'GLAccount' in data else '',
                                    'controlling_area': str(data['ControllingArea']).strip() if 'ControllingArea' in data else '',
                                    'requested_material_id': requested_material_id,
                                    'site_id': site_id,
                                    'store_id': store_id,
                                    'project_id': project_id,
                                    'is_active': True,
                                }
                                
                                filter_data = {
                                    'organization_id': organization_id,
                                    'requested_material_id': requested_material_id,
                                    'site_id': site_id,
                                    'store_id': store_id,
                                    'project_id': project_id,
                                }
                                try:
                                    # print(vendor_data)
                                    SAPPR.cmobjects.filter(**filter_data).exclude(pr_no=pr_no).update(is_active=False)
                                    SAPPR.cmobjects.update_or_create(**filter_data, pr_no=pr_no, defaults=vendor_data)
                                    count_data['update_or_create'] += 1
                                except Exception as e:
                                    error_msg.append(str(e))
                    else:
                        error_msg.append(sap_resp)
        except Exception as e:
            error_msg.append(str(e))
        return Response({'count_data': count_data, 'error_msg': error_msg})


class CSTDailyTrigger(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        request.user=PmsUser.objects.filter(id=1).first()
        error_msg = []
        try:
            status_lists = {
                'pending': { 'search': { 'status': 'pending', 'current_stage': '0', }, 'users': [], 'cc_users': [], 'count': 0, },
                'stage_0': { 'search': { 'status': 'checked', 'current_stage': '0', }, 'users': [], 'cc_users': [], 'count': 0, },
            }
            details = MultiStageSettingStages.cmobjects.filter(
                multi_stage_setting__from_name='cst',
                multi_stage_setting__is_deleted=False,
                multi_stage_setting__is_archived=False,
            ).annotate(
                user_id=GroupConcat('employee', distinct=True)
            ).values(
                'stage','user_id',
            )
            max_stage = max(details, key=lambda x: x['stage'])['stage'] if details else 0
            status_lists['pending']['users'].extend(list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-cst-checker'],
                level_permission=True,
            ).values_list('user_id',flat=True)))
            cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-cst-tag'],
                level_permission=True,
            ).values_list('user_id',flat=True))
            for detail in details:
                stage = detail['stage']
                # status_lists['stage_'+str(stage)] = { 'search': { 'status': 'checked', 'current_stage': str(stage), }, 'users': [], 'cc_users': (detail['user_id'].split(',') if max_stage-1 == stage else []), 'count': 0, }
                status_lists['stage_'+str(stage)] = { 'search': { 'status': 'checked', 'current_stage': str(stage), }, 'users': [], 'cc_users': [], 'count': 0, }
                status_lists['stage_'+str(stage-1)]['users'] = detail['user_id'].split(',')
            if not request.GET._mutable:
                request.GET._mutable = True
            request.GET['all'] = 'true'
            request.GET['latest'] = 'true'
            request.GET['is_direct_po'] = 'false'
            request.GET['site__isnull'] = 'false'
            request.GET['store__isnull'] = 'false'
            for status_list_key, status_list_value in status_lists.items():
                if status_list_value['users']:
                    ref_link = str(os.getenv('FE_ALL_CST', '#')).format(**status_list_value['search'])
                    print(status_list_key)
                    for filter_key,filter_value in status_list_value['search'].items():
                        request.GET[filter_key] = filter_value
                    resp = CSTMainAPIView().get(request)
                    _list = resp.data['results']
                    if _list:
                        status_lists[status_list_key]['count'] = len(_list)
                        status_list_value['cc_users'].extend(cc_users_list)
                        context = {
                            'data': _list,
                            'current_time': datetime.now().strftime('%d-%m-%Y %H:%M:%S'),
                            'ref_link': ref_link
                        }
                        trigger_notifications(action='CST-DAILY', user_list=status_list_value['users'], cc_user_list=status_list_value['cc_users'], context=context)

        except Exception as e:
            error_msg.append(str(e))
        return Response({'status_lists': status_lists, 'error_msg': error_msg,})


class CSTDailyTriggerV2(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        error_msg = []
        status_lists = []
        try:
            cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-cst-tag'],
                level_permission=True,
            ).values_list('user_id',flat=True))
            target_user_list = list(MultiStageSettingStages.cmobjects.filter(
                multi_stage_setting__from_name__in=['cst'],
                multi_stage_setting__is_deleted=False,
                multi_stage_setting__is_archived=False,
            ).values_list('employee',flat=True))
            target_user_list.extend(list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-cst-checker'],
                level_permission=True,
            ).values_list('user_id',flat=True)))
            target_user_list = list(set(list(target_user_list)))
            print(target_user_list)
            if not request.GET._mutable:
                request.GET._mutable = True
            request.GET['all'] = 'true'
            request.GET['latest'] = 'true'
            request.GET['is_direct_po'] = 'false'
            request.GET['site__isnull'] = 'false'
            request.GET['store__isnull'] = 'false'
            request.GET['approval_applicable'] = 'true'
            for target_user in target_user_list:
                if target_user:
                    try:
                        ref_link = str(os.getenv('FE_APPROVAL_CST', '#'))
                        print('USER -> ',target_user)
                        request.user=PmsUser.objects.filter(id=target_user).first()
                        resp = CSTMainAPIView().get(request)
                        status_lists.append({target_user:len(resp.data['results'])})
                        _list = resp.data['results']
                        if _list:
                            context = {
                                'data': _list,
                                'current_time': datetime.now().strftime('%d-%m-%Y %H:%M:%S'),
                                'ref_link': ref_link
                            }
                            trigger_notifications(action='CST-DAILY', user_list=[target_user], cc_user_list=cc_users_list, context=context)
                    except Exception as e:
                        error_msg.append({target_user:str(e)})

        except Exception as e:
            error_msg.append(str(e))
        return Response({'status_lists': status_lists, 'error_msg': error_msg,})
    
class HRMSSync(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        current_datetime = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        resp = { 'user': 0, 'project': 0, 'user_project': 0 }
        organization_id = self.request.query_params.get('organization_id', None)
        reset_user = self.request.query_params.get('reset_user', None)
        reset_project = self.request.query_params.get('reset_project', None)
        if reset_user == 'true':
            user_list = PmsUser.objects.filter(Q(is_deleted=False))
        else:
            user_list = PmsUser.objects.filter(Q(is_deleted=False),Q(Q(hrms_user_id=0) | Q(hrms_user_id=-1) | Q(hrms_user_id__isnull=True)))
        user_list = user_list.annotate(
            phone_no=Subquery(
                UserProfile.objects.filter(
                    user_id=OuterRef('pk')
                ).values('user').annotate(value=GroupConcat('phone_no')).values('value')
            )
        )
        if reset_project == 'true':
            project_list = ProjectDataSerializer(
                ProjectMaster.cmobjects.filter(),
                many=True,
                context = {"organization_id": organization_id, "list_type" : True}
            )
        else:
            project_list = ProjectDataSerializer(
                ProjectMaster.cmobjects.filter(Q(hrms_project_id=0) | Q(hrms_project_id=-1) | Q(hrms_project_id__isnull=True)),
                many=True,
                context = {"organization_id": organization_id, "list_type" : True}
            )
        project_list_all = ProjectMaster.cmobjects.filter(~Q(hrms_project_id=0) & ~Q(hrms_project_id=-1))
        print('*'*100,'sync_user_hrms')
        for user in user_list:
            print(user.id,user.hrms_user_id)
            post_data = {
                'list_type': 'professional',
                'sap_personnel_no': str(random.randrange(1, 10**3)).zfill(3) + str(time.time()).replace(".", "")[:5],
                'retirement_date': '2050-01-11T10:39:07.936452Z',
                'daily_loginTime': '00:00:00',
                'daily_logoutTime': '00:00:00',
                'lunch_start': '13:15:00',
                'lunch_end': '13:45:00',
                'cu_punch_id': str(random.randrange(1, 10**3)).zfill(3) + str(time.time()).replace(".", "")[:3],
                'cu_phone_no': user.phone_no if user.phone_no else str(random.randrange(1, 10 ** 3)).zfill(3) + str(time.time()).replace(".", "")[:7],
                'joining_date': current_datetime,
                'cu_alt_email_id': user.email if user.email else '',
                'salary_type': int(os.getenv('HRMS_SALARY_TYPE', '')),
                'grade': os.getenv('HRMS_SALARY_GRAD', ''),
                'department': int(os.getenv('HRMS_DEPARTMENT', '')),
                'attendance_type': 'PMS',

                'username': user.email,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
            }
            hrms_user_add = hrms_request('post', os.getenv('HRMS_USER_ADD',''), post_data)
            hrms_user_id = hrms_user_add.get('id', -1)
            instance = PmsUser.objects.filter(pk=user.id).first()
            instance.hrms_user_id = hrms_user_id
            instance.save()
            resp['user'] += 1
        print('*'*100,'sync_hrms_project')
        for project in project_list.data:
            print(project['id'],project['hrms_project_id'])
            sync_hrms_project(project)
            resp['project'] += 1
        print('*'*100,'sync_user_project_hrms')
        for project in project_list_all:
            print(project.id,project.hrms_project_id)
            sync_user_project_hrms(project)
            resp['user_project'] += 1
        return Response(resp)

class CostCenterAPIView(APIView):
    """
    CRUD API for CostCenter
    """
    
    

    def get(self, request):
        """
        Get a list of CostCenter
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            cost_center = CostCenter.cmobjects.filter(id=id).first()
            serializer = CostCenterSerializer(cost_center)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        cost_centers = CostCenter.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = CostCenterSerializer(cost_centers, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(cost_centers, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = CostCenterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new CostCenter
        """
        request.data['created_by'] = request.user.id
        serializer = CostCenterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a CostCenter
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        cost_center_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if CostCenter.cmobjects.filter(pk=cost_center_id, organization_id=organization_id).exists():
                    details = CostCenter.objects.filter(pk=cost_center_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = CostCenterSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if CostCenter.cmobjects.filter(pk=cost_center_id, organization_id=organization_id).exists():
                    details = CostCenter.objects.get(pk=cost_center_id, organization_id=organization_id)
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'data': {}},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class GetModelStructureAPIView(APIView):
    
    

    def get(self, request):
        try:
            module = request.query_params.get('module', None)
            serializer = request.query_params.get('serializer', None)
            exec(f'from {module}.serializers import {serializer}')
            return Response(text2tree(eval(f'{serializer}().__repr__()')))
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class NotificationTestView(APIView):
    
    
    def get(self, request, format=None):
        resp = None
        from administrations.utils import send_generic_mail
        send_generic_mail(
            subject='Test E-mail Trigger',
            to_mail_list=['aminul.islam@shyamfuture.com'],
            processed_message='Hello&nbsp;<b>WORLD</b>',
        )
        # from plant_machinery.models import PlantMachineryFuelTransaction,PlantMachineryMachine
        # transactions = PlantMachineryFuelTransaction.cmobjects.filter(plant_machinery_machine__isnull=True)
        # for transaction in transactions:
        #     transaction.plant_machinery_machine = PlantMachineryMachine.cmobjects.filter(machine_number=transaction.data['equipment_code']).first()
        #     transaction.save()

        # from administrations.utils import schedule_generic_sms
        # resp = schedule_generic_sms(to_number_list=['35453455','3454656767566','79898987987'], context={'reset_link': "absurl"}, processed_message=None)
        return Response(resp)


class AccountFetchBelsioAPIView(APIView):
    """
    API to manually fetch account master from Belsio and return all items.
    """
    
    

    def get(self, request):
        try:
            items = fetch_all_account_master_items()
            return Response(
                {
                    'msg': 'Successfully fetched account master.',
                    'status': status.HTTP_200_OK,
                    'request_status': 1,
                    'results': items
                },
                status=status.HTTP_200_OK
            )
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})                  \
            
class MaterialRequestClosedQtyUpdateAPIView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        days_limit=self.request.query_params.get('days_limit', int(os.getenv('MATERIAL_REQUEST_DAYS_LIMIT', 90)))
        current_date = date.today()
        date_limit = current_date - timedelta(days=days_limit)
        error_msg = []
        count=None
        try:
            count = MaterialRequestMasterItems.cmobjects.filter(
                material_request__date__lt=date_limit,
                material_request__is_deleted=False
            ).exclude(
                status='rejected'
            ).annotate(
                close_qty=F('quantity_unit') - (
                    F('sanctioned_quantity') + F('rejected_quantity'))
                ).update(closed_quantity=F('close_qty'))
        except Exception as e:
            error_msg.append(str(e))

        return Response({'count': count, 'error_msg': error_msg})
    

class IndentClosedQtyUpdateAPIView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        days_limit=self.request.query_params.get('days_limit', int(os.getenv('INDENT_DAYS_LIMIT', 90)))
        current_date = date.today()
        date_limit = current_date - timedelta(days=days_limit)
        error_msg = []
        count=None
        try:
            count = IndentItems.cmobjects.filter(
                indent__date__lt=date_limit,
                indent__is_deleted=False
            ).exclude(
                status='rejected'
            ).annotate(
                close_qty=F('quantity') - (
                    F('sanctioned_quantity') + F('rejected_quantity'))
                ).update(closed_quantity=F('close_qty'))
        except Exception as e:
            error_msg.append(str(e))

        return Response({'count': count, 'error_msg': error_msg})    
    


class SAPStockFetch(APIView):

    
    

    def get(self, request):
        try:

            pk__in=self.request.query_params.get('pk__in',None)
            formatted_details = get_sap_plant_auth('stock',pk__in=str(pk__in).strip().split(',') if pk__in else None)
            if formatted_details:
                temp={}
                for item_key,item_value in request.query_params.items():
                    if not item_key == 'pk__in':
                        temp[item_key] = item_value
                data = { "Record": [] }
                for detail_key,detail_value in formatted_details.items():
                    temp_data=temp.copy()
                    temp_data['Plant']=detail_key
                    temp_data['AuthorizationKey'] = detail_value['sap_auth_key']
                    data["Record"].append(temp_data)

                sap_resp,error_msg = sap_request(type='get',url=os.getenv('SAP_STOCK', ''),data=data,data_type='json')
                return Response(
                    {
                    'sap_resp': sap_resp,
                    'error_msg':error_msg,
                    'status': status.HTTP_200_OK,
                    "request_status": 1
                    })
            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
           
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
class SAPStockFetchV2(APIView):

    
    

    def get(self, request):
        try:
            current_date = datetime.now().date()
            all = self.request.query_params.get('all', None)
            start_date = request.query_params.get('start_date', current_date.strftime('%Y-%m-%d'))
            end_date = request.query_params.get('end_date', current_date.strftime('%Y-%m-%d'))
            search = {'date__gte': start_date,'date__lte': end_date}
            search = custom_filters(request, search, ['start_date','end_date'])
            _list = SAPStockMaster.cmobjects.select_related('material','material__unit_of_mesurement','project').values('material','project','site','store').annotate(
                start_date_opening_stock=Coalesce(
                    Sum('opening_stock', filter=Q(date=start_date)), Value(0.0)
                ),
                start_date_opening_value=Coalesce(
                    Sum('opening_value', filter=Q(date=start_date)), Value(0.0)
                ),
                end_date_closing_stock=Coalesce(
                    Sum('closing_stock', filter=Q(date=end_date)), Value(0.0)
                ),
                end_date_closing_value=Coalesce(
                    Sum('closing_value', filter=Q(date=end_date)), Value(0.0)
                ),
                sum_total_receipt_qties=Coalesce(Sum('total_receipt_qties'), Value(0.0)),
                sum_total_receipt_value=Coalesce(Sum('total_receipt_value'), Value(0.0)),
                sum_total_issued_qty=Coalesce(Sum('total_issued_qty'), Value(0.0)),
                sum_total_issue_value=Coalesce(Sum('total_issue_value'), Value(0.0))
            ).values(
                'material_id',
                'material__material_name',
                'material__material_code',
                'material__sap_code',
                'material__unit_of_mesurement__symbol',
                'project__project_code',
                'start_date_opening_stock','start_date_opening_value',
                'end_date_closing_stock','end_date_closing_value',
                'sum_total_receipt_qties',
                'sum_total_receipt_value',
                'sum_total_issued_qty',
                'sum_total_issue_value'
            ).order_by('material','project','site','store').filter(*search).order_by('-material__material_name')

            if all == 'true':
                return Response({'results': _list})

            page_size = int(request.query_params.get('page_size',settings.MIN_PAGE_SIZE))
            paginator = Paginator(_list, page_size)
            page_number = request.query_params.get('page', 1)
            page = paginator.get_page(page_number)

            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': page.object_list,
            })

        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
        

class SAPStockFetchSave(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        def format_sap_float(n):
            n = str(n).strip().lower()
            if n.endswith('-'):
                n = '-'+n[:-1]
            return float(n)
        try:
            count = 0
            total = 0
            error_msg = None
            current_date = datetime.now().date()
            pk__in=self.request.query_params.get('pk__in',None)
            start_date = request.query_params.get('start_date', current_date.strftime('%Y-%m-%d'))
            end_date = request.query_params.get('end_date', current_date.strftime('%Y-%m-%d'))
            formatted_details = get_sap_plant_auth('stock',pk__in=str(pk__in).strip().split(',') if pk__in else None)
            if formatted_details:
                material_master_map = {
                    str(v['sap_code']).strip().lower(): v
                    for v in VendorMaterialMaster.cmobjects.filter(sap_code__isnull=False).values('id','sap_code',)
                }
                data = { "Record": [] }
                for detail_key,detail_value in formatted_details.items():
                    data["Record"].append({
                        'Plant': detail_key,
                        'AuthorizationKey': detail_value['sap_auth_key'],
                        'DateFrom': start_date,
                        'DateTo': end_date,
                    })

                sap_resp,error_msg = sap_request(type='get',url=os.getenv('SAP_STOCK', ''),data=data,data_type='json')
                if 'Result' in sap_resp:
                    for row in sap_resp['Result']:
                        total += 1
                        material_code = str(row.get('Material', '')).strip().lower()
                        plant_code = str(row.get('Plant', '')).strip().lower()
                        
                        site_id = formatted_details.get(plant_code, {}).get('site_id',None)
                        store_id = formatted_details.get(plant_code, {}).get('id',None)
                        project_id = formatted_details.get(plant_code, {}).get('site__project_id',None)
                        material_id = material_master_map.get(material_code, {}).get('id',None)
                        if material_id and project_id:
                            master_data = {
                                'closing_stock': format_sap_float(row.get('ClosingStock', '')),
                                'closing_value': format_sap_float(row.get('ClosingValue', '')),
                                'opening_stock': format_sap_float(row.get('OpeningStock', '')),
                                'opening_value': format_sap_float(row.get('OpeningValue', '')),
                                'total_issue_value': format_sap_float(row.get('TotalIssueValue', '')),
                                'total_issued_qty': format_sap_float(row.get('TotalIssuedQty', '')),
                                'total_receipt_qties': format_sap_float(row.get('TotalReceiptQties', '')),
                                'total_receipt_value': format_sap_float(row.get('TotalReceiptValue', '')),
                            }
                            obj, created = SAPStockMaster.cmobjects.update_or_create(
                                material_id=material_id,
                                project_id=project_id,
                                site_id=site_id,
                                store_id=store_id,
                                date=end_date,
                                defaults=master_data
                            )
                            count += 1
            return Response({
                'total': total,
                'count': count,
                'error_msg':error_msg,
                'status': status.HTTP_200_OK,
                "request_status": 1
            })
   
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
        

class SendNotifications(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        type_map = {
            '0': [EmailSend,send_generic_mail,'to_email'],
            '1': [SMSSend,send_generic_sms,'to_number'],
            '2': [PushSend,send_generic_push,None],
        }
        type = self.request.query_params.get('type', '0')

        error_msg = []
        resp = []
        try:
            if type in type_map:
                search = [
                    Q(is_sent=False),
                    Q(template__is_active_trigger=True),
                    Q(tried_count__lt=3),
                ]
                if type_map[type][2]:
                    search.append(eval(f"~(Q({type_map[type][2]}=None) | Q({type_map[type][2]}=''))"))
                unsent_instances = type_map[type][0].objects.filter(*search)

                for instance in unsent_instances:
                    try:
                        result = type_map[type][1](instance=instance)
                        if result:
                            resp.append(instance.id)
                            instance.is_sent = True
                        instance.tried_count = instance.tried_count + 1
                        instance.save()
                    except Exception as e:
                        error_msg.append(str(e))
            else:
                error_msg.append(f"Invalid Type: {type}")
        except Exception as e:
            error_msg.append(str(e))
        return Response({'resp': resp, 'error_msg': error_msg})
    
class GLAccountAPIView(APIView):
    """
    CRUD API for GLAccount
    """
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = GLAccount.cmobjects.filter(id=id).first()
            serializer = GLAccountSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = GLAccount.cmobjects.select_related("organization").filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = GLAccountSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = GLAccountSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = GLAccountSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created.',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
       
        method = request.query_params.get('method', '').lower()
        id = request.query_params.get('id', None)

        with transaction.atomic():
            details = GLAccount.cmobjects.filter(pk=id).first()
            if not details:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            if method == 'edit':
                request.data['updated_by'] = request.user.id
                serializer = GLAccountSerializer(details, data=request.data, partial=True, context={'request': request})
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})

                    return Response(
                        {'results': serializer.data,
                         'msg': 'Successfully updated.',
                         'status': status.HTTP_202_ACCEPTED,
                         "request_status": 1})
                raise APIException({'request_status': 0, 'msg': serializer.errors})

            elif method == 'delete': 
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()

                return Response({
                    'results': {'Data': GLAccount.objects.filter(pk=id).values()},
                    'msg': 'Successfully deleted.',
                    "request_status": 1
                })
            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})
    
class VendorDupAPIView(APIView):
    
    

    def get(self, request):
        linked_models = []
        query_list = []
        for relation in VendorMasterV2._meta.related_objects:
            tempo = relation.related_model._meta.object_name
            if not tempo.startswith('VendorMasterV2') and not tempo in ['VendorDatabase','VendorMasterHistory']:
                table_name = relation.related_model._meta.db_table
                field_name = relation.field.name+'_id'
                if relation.field.__class__.__name__ == 'ManyToManyField':
                    table_name = relation.through._meta.db_table
                    field_name = relation.field.m2m_reverse_name()
                linked_models.append({'table_name': table_name,'field_name': field_name})
        _list = VendorMasterV2.cmobjects.filter(is_archived=False).values('vendor_code').annotate(
            ids=GroupConcat(F('pk'), distinct=False, separator=','),
            count_ids=Count(F('pk')),
        ).order_by('vendor_code').distinct().filter(count_ids__gt=1)
        for data in _list:
            temp_vendor = data['ids'].split(',')
            keep_vendor = temp_vendor[0]
            remove_vendor = temp_vendor[1:]
            for linked_model in linked_models:
                query_list.append(f"update {linked_model['table_name']} set {linked_model['field_name']}={keep_vendor} where {linked_model['field_name']} in({','.join(remove_vendor)});")
            query_list.append(f"update vendor_vendormasterv2 set is_deleted=1 where id in({','.join(remove_vendor)});")
        return Response(''.join(query_list))


class S3FetchAPIView(APIView):
    
    
    renderer_classes = [JSONRenderer]

    def get(self, request, file_path):
        try:
            s3_storage = S3Boto3Storage(bucket_name=os.getenv('AWS_STORAGE_BUCKET_NAME', ''))
            return FileResponse(s3_storage._open(file_path))
        except Exception as e:
            print(e)
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class DBDataMigrationAPIView(APIView):
    
    

    def get(self, request):
        import os
        os.environ['DJANGO_COLORS'] = 'nocolor'
        from django.apps import apps
        from django.db import connection,connections
        from django.core.management.color import no_style
        resp = {}
        model_db_tables = [k._meta.db_table for k in apps.get_models()]
        extra_tables = []
        for target_db_table in connections['replica'].introspection.table_names():
            if not target_db_table in model_db_tables and not target_db_table == 'django_migrations':
                print(target_db_table)
                extra_tables.append(target_db_table)
        resp['extra_tables'] = {}
        with connections['replica'].cursor() as cursor:
            for model in apps.get_models():
                if model._meta.db_table in connection.introspection.table_names():
                    resp[f'{model._meta.app_label} - {model._meta.object_name}'] = {
                        'default': model.objects.using('default').count(),
                        'replica_initial': model.objects.using('replica').count(),
                    }
                    print(model,model.objects.using('default').count(),model.objects.using('replica').count())
                    cursor.execute(f'ALTER TABLE "{model._meta.db_table}" DISABLE TRIGGER ALL;')
                    cursor.execute(f'TRUNCATE TABLE "{model._meta.db_table}" RESTART IDENTITY CASCADE;')
                    cursor.execute(f'ALTER TABLE "{model._meta.db_table}" ENABLE TRIGGER ALL;')
            for extra_table in extra_tables:
                cursor.execute(f'ALTER TABLE "{extra_table}" DISABLE TRIGGER ALL;')
                cursor.execute(f'TRUNCATE TABLE "{extra_table}" RESTART IDENTITY CASCADE;')
                cursor.execute(f'ALTER TABLE "{extra_table}" ENABLE TRIGGER ALL;')
            for model in apps.get_models():
                if model._meta.db_table in connection.introspection.table_names():
                    print(model,model.objects.using('default').count(),model.objects.using('replica').count())
                    if not model.objects.using('default').count() == model.objects.using('replica').count():
                        cursor.execute(f'ALTER TABLE "{model._meta.db_table}" DISABLE TRIGGER ALL;')
                        if getattr(model, 'created_at', False):
                            model.created_at.field.auto_now_add = False
                        if getattr(model, 'updated_at', False):
                            model.updated_at.field.auto_now = False
                        model.objects.using('replica').bulk_create(model.objects.using('default'), batch_size=1000)
                        if getattr(model, 'created_at', False):
                            model.created_at.field.auto_now_add = True
                        if getattr(model, 'updated_at', False):
                            model.updated_at.field.auto_now = True
                        sequence_querys = connections['replica'].ops.sequence_reset_sql(no_style(), [model])
                        for sequence_query in sequence_querys:
                            print(sequence_query)
                            cursor.execute(sequence_query)
                        cursor.execute(f'ALTER TABLE "{model._meta.db_table}" ENABLE TRIGGER ALL;')
                    resp[f'{model._meta.app_label} - {model._meta.object_name}']['replica_final'] = model.objects.using('replica').count()
            for extra_table in extra_tables:
                with connection.cursor() as old_cursor:
                    old_cursor.execute(f"SELECT * FROM {extra_table};")
                    results = old_cursor.fetchall()
                    resp['extra_tables'][extra_table] = len(results)
                    if len(results) > 0:
                        print(extra_table)
                        sql_query = f"INSERT INTO {extra_table} VALUES ({", ".join(["%s"] * len(results[0]))})"
                        sequence_sql_query = f'''SELECT setval(pg_get_serial_sequence('"{extra_table}"','id'), coalesce(max("id"), 1), max("id") IS NOT null) FROM "{extra_table}";'''
                        print(sequence_sql_query)
                        cursor.execute(f'ALTER TABLE "{extra_table}" DISABLE TRIGGER ALL;')
                        cursor.executemany(sql_query, results)
                        cursor.execute(sequence_sql_query)
                        cursor.execute(f'ALTER TABLE "{extra_table}" ENABLE TRIGGER ALL;')
        return Response(resp)


from django.template import loader
import qrcode
import threading
class StorageManagementAPIView(APIView):
    permission_classes = (AllowAny,)

    def process(self, request):
        filedir = f"{settings.MEDIA_ROOT}/tmp"
        expiry = 120
        context = {'expiry': expiry}
        try:
            if 'submit_btn' in request.data:
                file = request.data['file_field']
                if not file == '':
                    context['filename'] = f"{uuid.uuid4().hex}{file.name}"
                    filepath = f"{filedir}/{context['filename']}"
                    if not os.path.exists(filedir):
                        os.makedirs(filedir)
                    with open(filepath, 'wb+') as destination:
                        for chunk in file.chunks():
                            destination.write(chunk)
                    context['fileurl'] = f"{request.scheme}://{request.get_host()}{settings.MEDIA_URL}tmp/{context['filename']}"
                    def delete_file_after_delay():
                        time.sleep(expiry)
                        if os.path.exists(filepath):
                            os.remove(filepath)
                    deletion_thread = threading.Thread(target=delete_file_after_delay)
                    deletion_thread.start()
                else:
                    context['err_msg'] = 'File Missing!'
            if 'delete_btn' in request.data:
                file = f"{filedir}/{request.data['file_path']}"
                if os.path.exists(file):
                    os.remove(file)
                    context['success_msg'] = 'File Removed Successfully!'
                else:
                    context['err_msg'] = 'File Not Found!'
            if 'fileurl' in context:
                qr_code_img = qrcode.make(context['fileurl'])
                buffer = BytesIO()
                qr_code_img.save(buffer)
                buffer.seek(0)
                encoded_img = base64.b64encode(buffer.read()).decode()
                context['qr'] = f"data:image/png;base64,{encoded_img}"
        except Exception as e:
            context['err_msg'] = str(e)
        
        template = loader.get_template('storage.html')
        return HttpResponse(template.render(context=context))

    def get(self, request):
        return self.process(request)

    def post(self, request):
        return self.process(request)
    
class ConditionTagsAPIView(APIView):
    """
    CRUD API for ConditionTags
    """
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = ConditionTags.cmobjects.filter(id=id).first()
            serializer = ConditionTagsSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = ConditionTags.cmobjects.filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = ConditionTagsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = ConditionTagsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = ConditionTagsSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created.',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
       
        method = request.query_params.get('method', '').lower()
        id = request.query_params.get('id', None)

        with transaction.atomic():
            details = GLConditionTagsAccount.cmobjects.filter(pk=id).first()
            if not details:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            if method == 'edit':
                request.data['updated_by'] = request.user.id
                serializer = ConditionTagsSerializer(details, data=request.data, partial=True, context={'request': request})
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})

                    return Response(
                        {'results': serializer.data,
                         'msg': 'Successfully updated.',
                         'status': status.HTTP_202_ACCEPTED,
                         "request_status": 1})
                raise APIException({'request_status': 0, 'msg': serializer.errors})

            elif method == 'delete': 
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()

                return Response({
                    'results': {'Data': ConditionTags.objects.filter(pk=id).values()},
                    'msg': 'Successfully deleted.',
                    "request_status": 1
                })
            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

    
class MultiMigrationAPIView(APIView):
    def get(self, request):
        condition_tags = [
            {
                'name': 'Budget',
                'field': 'instance.is_budgeted',
                'module_type': 'cst',
                'operands': '==,!=',
                'options': 'True,False',
            },
            {
                'name': 'Quotation Selected',
                'field': 'instance.quotation_selected',
                'module_type': 'cst',
                'operands': '==,!=',
                'options': 'True,False',
            },
            {
                'name': 'Saving Amount',
                'field': 'instance.saving_amount',
                'module_type': 'cst',
                'operands': '>,<,==,!=,>=,<=',
                'options': '0',
            },
            {
                'name': 'Direct PO',
                'field': 'instance.is_direct_po',
                'module_type': 'cst',
                'operands': '==,!=',
                'options': 'True,False',
            },
            {
                'name': 'Budget',
                'field': 'instance.is_budgeted',
                'module_type': 'pnmcst',
                'operands': '==,!=',
                'options': 'True,False',
            },
            {
                'name': 'Quotation Selected',
                'field': 'instance.quotation_selected',
                'module_type': 'pnmcst',
                'operands': '==,!=',
                'options': 'True,False',
            },
            {
                'name': 'Saving Amount',
                'field': 'instance.saving_amount',
                'module_type': 'pnmcst',
                'operands': '>,<,==,!=,>=,<=',
                'options': '0',
            },
        ]
        ConditionTags.objects.all().delete()
        for condition_tag in condition_tags:
            ConditionTags.objects.create(**condition_tag)
        CST.objects.update(ref_stage_type=MultiStageSetting.objects.filter(from_name='cst').first())
        PaymentMaster.objects.update(ref_stage_type=MultiStageSetting.objects.filter(from_name='pm').first())
        PlantMachineryAssetRequisition.objects.update(ref_stage_type=MultiStageSetting.objects.filter(from_name='pnmar').first())
        PlantMachineryCST.objects.update(ref_stage_type=MultiStageSetting.objects.filter(from_name='pnmcst').first())
        PlantMachineryHireBillInvoice.objects.update(ref_stage_type=MultiStageSetting.objects.filter(from_name='pnmhbi').first())
        MultiStageSetting.objects.update(from_name='old')
        departments = Department.cmobjects.filter(department='IT')
        all_sites = SiteMaster.cmobjects.all()
        infra_sites = SiteMaster.cmobjects.filter(project__project_classification='Infra')
        noninfra_sites = SiteMaster.cmobjects.filter(project__project_classification='Non-Infra')
        multi_stage_data = [
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PURCHASE-CST-INFRA-BUDGETED',
                    'from_name': 'cst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.quotation_selected",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.saving_amount",
                            "options": "0",
                            "operands": ">="
                        },
                        {
                            "field": "instance.is_direct_po",
                            "options": "False",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': infra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com','tarun@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-CEO Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'CEO-Approved',
                            'ref_stage_name': 'CEO-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['amit.mokashi@shyamsteel.in'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PURCHASE-CST-INFRA-NON-BUDGETED',
                    'from_name': 'cst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "False",
                            "operands": "=="
                        },
                        {
                            "field": "instance.is_direct_po",
                            "options": "False",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': infra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com','tarun@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-CEO Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'CEO-Approved',
                            'ref_stage_name': 'CEO-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['amit.mokashi@shyamsteel.in'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PURCHASE-CST-INFRA-OVER-BUDGETED',
                    'from_name': 'cst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.quotation_selected",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.saving_amount",
                            "options": "0",
                            "operands": "<"
                        },
                        {
                            "field": "instance.is_direct_po",
                            "options": "False",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': infra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com','tarun@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-CEO Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'CEO-Approved',
                            'ref_stage_name': 'CEO Approved-Director Approval Pending',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['amit.mokashi@shyamsteel.in'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 4,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PURCHASE-CST-INFRA-DIRECT-PO',
                    'from_name': 'cst',
                    'conditions': [
                        {
                            "field": "instance.is_direct_po",
                            "options": "True",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': infra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com','tarun@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PURCHASE-CST-NON-INFRA-BUDGETED',
                    'from_name': 'cst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.quotation_selected",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.saving_amount",
                            "options": "0",
                            "operands": ">="
                        },
                        {
                            "field": "instance.is_direct_po",
                            "options": "False",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': noninfra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com','tarun@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PURCHASE-CST-NON-INFRA-NON-BUDGETED',
                    'from_name': 'cst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "False",
                            "operands": "=="
                        },
                        {
                            "field": "instance.is_direct_po",
                            "options": "False",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': noninfra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com','tarun@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PURCHASE-CST-NON-INFRA-OVER-BUDGETED',
                    'from_name': 'cst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.quotation_selected",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.saving_amount",
                            "options": "0",
                            "operands": "<"
                        },
                        {
                            "field": "instance.is_direct_po",
                            "options": "False",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': noninfra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com','tarun@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PURCHASE-CST-NON-INFRA-DIRECT-PO',
                    'from_name': 'cst',
                    'conditions': [
                        {
                            "field": "instance.is_direct_po",
                            "options": "True",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': noninfra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com','tarun@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PNM-CST-INFRA-BUDGETED',
                    'from_name': 'pnmcst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.quotation_selected",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.saving_amount",
                            "options": "0",
                            "operands": ">="
                        }
                    ],
                },
                'site_ids': infra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-CEO Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'CEO-Approved',
                            'ref_stage_name': 'CEO-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['amit.mokashi@shyamsteel.in'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PNM-CST-INFRA-NON-BUDGETED',
                    'from_name': 'pnmcst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "False",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': infra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-CEO Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'CEO-Approved',
                            'ref_stage_name': 'CEO-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['amit.mokashi@shyamsteel.in'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PNM-CST-INFRA-OVER-BUDGETED',
                    'from_name': 'pnmcst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.quotation_selected",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.saving_amount",
                            "options": "0",
                            "operands": "<"
                        }
                    ],
                },
                'site_ids': infra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-CEO Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'CEO-Approved',
                            'ref_stage_name': 'CEO Approved-Director Approval Pending',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['amit.mokashi@shyamsteel.in'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 4,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PNM-CST-NON-INFRA-BUDGETED',
                    'from_name': 'pnmcst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.quotation_selected",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.saving_amount",
                            "options": "0",
                            "operands": ">="
                        }
                    ],
                },
                'site_ids': noninfra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PNM-CST-NON-INFRA-NON-BUDGETED',
                    'from_name': 'pnmcst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "False",
                            "operands": "=="
                        }
                    ],
                },
                'site_ids': noninfra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PNM-CST-NON-INFRA-OVER-BUDGETED',
                    'from_name': 'pnmcst',
                    'conditions': [
                        {
                            "field": "instance.is_budgeted",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.quotation_selected",
                            "options": "True",
                            "operands": "=="
                        },
                        {
                            "field": "instance.saving_amount",
                            "options": "0",
                            "operands": "<"
                        }
                    ],
                },
                'site_ids': noninfra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PAYMENT-INFRA',
                    'from_name': 'pm',
                    'conditions': [],
                },
                'site_ids': infra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Finance-HOD Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Finance-HOD-Approved',
                            'ref_stage_name': 'Finance-HOD-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['gp@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PAYMENT-NON-INFRA',
                    'from_name': 'pm',
                    'conditions': [],
                },
                'site_ids': noninfra_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-HOD Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['rupesh.singh1@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-Director Approval Pending',
                            'stage': 2,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Director-Approved',
                            'ref_stage_name': 'Director-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['raghav@shyamsteel.com'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PLANT-MACHINERY-ASSET-REQUESTION',
                    'from_name': 'pnmar',
                    'conditions': [],
                },
                'site_ids': all_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Approved',
                            'ref_stage_name': 'Approved-Final Approval Pending',
                            'stage': 2,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['atanu.bhattacharya@shyamsteel.com','debashis.dutta@shyamsteel.in'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Final-Approved',
                            'ref_stage_name': 'Final-Approved',
                            'stage': 3,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['amit.mokashi@shyamsteel.in'],
                    },
                ]
            },
            {
                'payload': {
                    'organization_id': 1,
                    'multi_stage_name': 'PLANT-MACHINERY-HIRE-BILL',
                    'from_name': 'pnmhbi',
                    'conditions': [],
                },
                'site_ids': all_sites,
                'stages_data': [
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Verified',
                            'ref_stage_name': 'Verified-P&M HO-Approval Pending',
                            'stage': 1,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com','stores.krp@shyaminfra.com','sandip.paul@shyamsteel.com','stores.satna@shyaminfra.com','stores.pk3@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'PNM-HO-Verified',
                            'ref_stage_name': 'P&M HO-Approved-Planning (HO) Approval Pending',
                            'stage': 2,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['zeeshan.khan@shyaminfra.com','sandip.karak@shyaminfra.com','vineet.kumar@shyaminfra.com','animesh.ghosh@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Planning-HO-Approved',
                            'ref_stage_name': 'Planning (HO) Approved-HOD Approval Pending',
                            'stage': 3,
                            'remarks_required': True,
                        },
                        'department_ids': departments,
                        'employee_ids': ['atanu.bhattacharya@shyamsteel.com','debashis.dutta@shyamsteel.in'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'HOD-Approved',
                            'ref_stage_name': 'HOD Approved-CEO Approval Pending',
                            'stage': 4,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['shahbaz@shyaminfra.com'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'CEO-Approved',
                            'ref_stage_name': 'CEO-Approved-Finance HOD Approval Pending',
                            'stage': 5,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['amit.mokashi@shyamsteel.in'],
                    },
                    {
                        'payload': {
                            'organization_id': 1,
                            'stage_name': 'Finance-HOD-Approved',
                            'ref_stage_name': 'Finance-HOD-Approved',
                            'stage': 6,
                            'remarks_required': False,
                        },
                        'department_ids': departments,
                        'employee_ids': ['gp@shyamsteel.com'],
                    },
                ]
            },
        ]
        for multi_stage in multi_stage_data:
            instance = MultiStageSetting.objects.create(**multi_stage['payload'])
            instance.site.clear()
            for site in multi_stage['site_ids']:
                instance.site.add(site)
            for stage_data in multi_stage['stages_data']:
                instance_stage = MultiStageSettingStages.objects.create(multi_stage_setting=instance, **stage_data['payload'])
                for department in stage_data['department_ids']:
                    instance_stage.department.add(department)
                for username in stage_data['employee_ids']:
                    employee = PmsUser.objects.get(username=username)
                    instance_stage.employee.add(employee)
        
        return Response('ok')