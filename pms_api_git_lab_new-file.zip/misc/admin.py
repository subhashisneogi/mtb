from django.contrib import admin
from djangoql.admin import DjangoQLSearchMixin
from unfold.admin import ModelAdmin,StackedInline
from .models import *
from admin_list_charts.admin import ListChartMixin
from unfold.decorators import display
from import_export.admin import ImportExportModelAdmin
from unfold.contrib.import_export.forms import ImportForm,SelectableFieldsExportForm
from django.db.models import JSONField
from django_json_widget.widgets import JSONEditorWidget

label_dict = {}
label_dict.update({str(i): '' for i in range(100, 200)})
label_dict.update({str(i): 'success' for i in range(200, 300)})
label_dict.update({str(i): 'info' for i in range(300, 400)})
label_dict.update({str(i): 'warning' for i in range(400, 500)})
label_dict.update({str(i): 'danger' for i in range(500, 600)})

class ModelAdmin(DjangoQLSearchMixin,ModelAdmin,ImportExportModelAdmin):
    save_as = True
    list_filter_submit = True
    import_form_class = ImportForm
    export_form_class = SelectableFieldsExportForm
    formfield_overrides = {
        JSONField: {'widget': JSONEditorWidget},
    }
    def __init__(self, model, *args, **kwargs):
        _modify_class(self, model)
        super().__init__(model, *args, **kwargs)


class StackedInline(StackedInline):
    collapsible = True
    def __init__(self, model, *args, **kwargs):
        _modify_class(self, model)
        super().__init__(model, *args, **kwargs)


def _modify_class(model_admin_or_inline, model):
    try:
        if not model_admin_or_inline.search_fields:
            model_admin_or_inline.search_fields = ['id']
        if not model_admin_or_inline.autocomplete_fields:
            autocomplete_except = getattr(model_admin_or_inline, 'autocomplete_except', [])
            acf = []
            for fld in model._meta.get_fields():
                if (fld.many_to_one or fld.many_to_many) and (fld.name not in autocomplete_except):
                    if fld.related_model in admin.site._registry:
                        acf.append(fld.name)
            if acf:
                model_admin_or_inline.autocomplete_fields = acf
    except Exception as e:
        pass

class TermsAndConditionsChildAdmin(StackedInline):
    model = TermsAndConditionsChild
    fk_name = 'master'


@admin.register(TermsAndConditionsMaster)
class TermsAndConditionsMasterAdmin(ModelAdmin):
    list_display = ['name', 'slug', 'is_deleted']
    search_fields = ('name',)
    inlines = (TermsAndConditionsChildAdmin,)
     

@admin.register(Comments)
class CommentsAdmin(ModelAdmin):
    model = Comments
    list_display = ['ref_type','ref_id','comments']
     

@admin.register(NotifyUser)
class NotifyUserAdmin(ModelAdmin):
    model = NotifyUser
    list_display = ['user','type']
     

@admin.register(RequestLog)
class RequestLogAdmin(ListChartMixin,ModelAdmin):
    model = RequestLog
    date_hierarchy = 'created_at'
    search_fields = ('request_start_time','request_path',)
    list_filter = ['request_type', 'response_code']
    list_display = ['request_start_time','request_type','request_path','status_label','query_count','query_execution_time','duration','memory_used','response_size']
    
    @display(label=label_dict)
    def status_label(self, obj):
        return obj.response_code
     

@admin.register(TaxHead)
class TaxHeadAdmin(ModelAdmin):
    model = TaxHead
    list_display = ['name','short_name','percentage','amount','tax_type','is_deleted']
@admin.register(ExpenseHead)
class ExpenseHeadAdmin(ModelAdmin):
    model = ExpenseHead
    list_display = ['name','short_name','percentage','amount','is_deleted']
     

@admin.register(VendorCurrencyMaster)
class VendorCurrencyMasterAdmin(ModelAdmin):
    model = VendorCurrencyMaster
    list_display = ['name','slug','symbol','exchange_rate','is_default','is_deleted']

@admin.register(TermsAndConditionsChild)
class TermsAndConditionsChildAdmin(ModelAdmin):
    model = TermsAndConditionsChild
    # list_display = [field.name for field in TermsAndConditionsChild._meta.get_fields() if field.name not in ('description',)]
    list_display = [
        field.name for field in TermsAndConditionsChild._meta.get_fields()
        if field.concrete and not field.many_to_many and not field.one_to_many and field.name != 'description'
    ]
    search_fields = ['is_deleted', 'key']



@admin.register(MimeTypes)
class MimeTypesAdmin(ModelAdmin):
    model = MimeTypes
    list_display = ['mime_type','file_extension']

admin.site.register(MergeLog,ModelAdmin)
admin.site.register(AccountsHead,ModelAdmin)
admin.site.register(CodeRecord,ModelAdmin)



@admin.register(CostCenter)
class CostCenterAdmin(ModelAdmin):
    list_display = ['id','organization', 'name','is_deleted'] 
@admin.register(AllowedIP)
class AllowedIPAdmin(ModelAdmin):
    list_display = ['id','ip_address','is_active','is_deleted']
    list_filter = ['is_active', 'is_deleted']
    search_fields = ('ip_address',)
    list_editable = (
        'is_deleted',
        'is_active',
    )

admin.site.register(BelsioToken,ModelAdmin)

@admin.register(ExternalRequests)
class ExternalRequestsAdmin(ListChartMixin,ModelAdmin):
    date_hierarchy = 'created_at'
    list_display = ['url','status_label','created_at','elapsed']
    search_fields = ('url',)
    list_filter = ('status_code',)
    
    @display(label=label_dict)
    def status_label(self, obj):
        return obj.status_code

@admin.register(StateCode)
class StateCodeAdmin(ModelAdmin):
    list_display = ['id','numeric_code','state_code','is_deleted']
    list_filter = ['is_deleted']
    search_fields = ('numeric_code','state_code',)
    list_editable = (
        'numeric_code',
        'state_code',
        'is_deleted',
    )

@admin.register(GLAccount)
class GLAccountAdmin(ModelAdmin):
    list_display = ['id','name','is_infra','is_deleted']
    list_filter = ['name', 'is_deleted']
    search_fields = ('name',)
    list_editable = (
        'name',
        'is_deleted',
        'is_infra',

    )

@admin.register(ConditionTags)
class ConditionTagsAdmin(ModelAdmin):
    list_display = ['id','module_type','name','field','operands','options','is_deleted']
    list_filter = ['module_type', 'name', 'is_deleted']
    search_fields = ('name',)
    list_editable = (
        'module_type',
        'name',
        'field',
        'operands',
        'options',
        'is_deleted',
    )
