from django.db import models
from django.utils.text import slugify
from rest_framework.exceptions import ValidationError

from administrations.models import *
from vendor.models import VendorMasterV2

class TermsAndConditionsMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='misc_terms_and_conditions_master_organizations',
                                     on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=200)
    slug = models.SlugField(blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.slug and self.name:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "misc_terms_and_conditions_master"


class TermsAndConditionsChild(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='misc_terms_and_conditions_organizations',
                                     on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(TermsAndConditionsMaster, related_name='misc_terms_and_conditions',
                               on_delete=models.CASCADE, null=True, blank=True)
    key = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    order_id = models.IntegerField(default=0)
    is_fetch = models.BooleanField(default=False)
    remarks = models.TextField(max_length=500, null=True,
                               blank=True)

    work_category = models.CharField(max_length=200, null=True, blank=True)
    is_default = models.BooleanField(default=False)
    is_billing_format = models.BooleanField(default=False)

    def __str__(self):
        return self.key

    class Meta:
        db_table = "misc_terms_and_conditions_child"


class AccountsHead(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    TYPE = (
        ('bank', 'Bank'),
        ('cash', 'Cash'),
        ('stock', 'Stock'),
        ('tax', 'Tax'),
        ('chargable', 'Chargable'),
        ('fixed', 'Fixed'),
    )
    organization = models.ForeignKey(Organization, related_name='misc_accounts_head_organizations', on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    status = models.CharField(choices=APPROVE_STATUS, max_length=50, blank=True, null=True, default='pending')
    parent = models.ForeignKey('self', related_name='misc_accounts_head_parent', on_delete=models.CASCADE, blank=True, null=True)
    type = models.CharField(choices=TYPE, max_length=50, blank=True, null=True, default='cash')
    bp_grouping = models.CharField(max_length=255, blank=True, null=True)
    reconciliation_account_in_gen = models.CharField(max_length=255, blank=True, null=True)
    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = "misc_accounts_head"
        unique_together = ('organization', 'name')


class TaxHead(BaseAbstractStructure):
    TAX_TYPE = (
        ('vat_tax', 'vat_tax'),
        ('gst_tax', 'gst_tax'),
        ('excise_tax', 'excise_tax'),
    )
    APPLICABLE_TYPE = (
        ('amount_wise', 'amount_wise'),
        ('percent_wise', 'percent_wise')
    )

    organization = models.ForeignKey(Organization, related_name='misc_tax_head_organizations',
                                     on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=255)
    short_name = models.CharField(max_length=200, null=True, blank=True)
    percentage = models.FloatField(default=0, null=True, blank=True)
    amount = models.FloatField(default=0, null=True, blank=True)

    # new
    educational_cess = models.FloatField(default=0, null=True, blank=True)
    she_cess = models.FloatField(default=0, null=True, blank=True)
    swachh_bharat_cess = models.FloatField(default=0, null=True, blank=True)
    krishi_kalyan_cess = models.FloatField(default=0, null=True, blank=True)
    tax_rate = models.FloatField(default=0, null=True, blank=True)

    applicable_type = models.CharField(max_length=100, choices=APPLICABLE_TYPE, blank=True, null=True, default="percent_wise")
    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="gst_tax")
    gst_type = models.CharField(max_length=100, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True, max_length=300)

    #
    sgst_rate = models.FloatField(default=0, null=True, blank=True)
    ugst_rate = models.FloatField(default=0, null=True, blank=True)
    utgst_rate = models.FloatField(default=0, null=True, blank=True)
    cgst_rate = models.FloatField(default=0, null=True, blank=True)
    igst_rate = models.FloatField(default=0, null=True, blank=True)
    total_tax_rate = models.FloatField(default=0, null=True, blank=True)
    cess = models.FloatField(default=0, null=True, blank=True)

    # AccountsHead links
    sbc_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_sbc_account', on_delete=models.CASCADE, null=True, blank=True)
    krishi_kalyan_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_krishi_kalyan_account', on_delete=models.CASCADE, null=True, blank=True)
    sgst_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_sgst_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_sgst_pay_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_sgst_pay_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_sgst_input_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_sgst_input_account', on_delete=models.CASCADE, null=True, blank=True)
    utgst_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_utgst_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_utgst_pay_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    rmc_utgst_input_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_utgst_input_account', on_delete=models.CASCADE, null=True, blank=True)
    cgst_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_cgst_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_cgst_pay_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_cgst_pay_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_cgst_input_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_cgst_input_account', on_delete=models.CASCADE, null=True, blank=True)
    igst_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_igst_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_igst_pay_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_igst_pay_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_igst_input_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_igst_input_account', on_delete=models.CASCADE, null=True, blank=True)
    cess_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_cess_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_cess_pay_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_cess_pay_account', on_delete=models.CASCADE, null=True, blank=True)
    rmc_cess_input_account = models.ForeignKey(AccountsHead, related_name='misc_tax_head_rmc_cess_input_account', on_delete=models.CASCADE, null=True, blank=True)
    extra=models.JSONField(blank=True,null=True)

    # def clean(self):
    #     if self.percentage is None and self.amount is None:
    #         raise ValidationError("Either percentage or amount must be specified, but not both.")
    #     elif self.percentage is not None and self.amount is not None:
    #         raise ValidationError("Both percentage and amount cannot be specified simultaneously.")
    #     super().clean()

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    class Meta:
        db_table = "misc_tax_head"


class ExpenseHead(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='misc_expense_head_organizations', on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    short_name = models.CharField(max_length=200, null=True, blank=True)
    status = models.CharField(choices=APPROVE_STATUS, max_length=50, blank=True, null=True, default='pending')
    account = models.ForeignKey(AccountsHead, related_name='misc_expense_head_account', on_delete=models.CASCADE, null=True, blank=True)
    percentage = models.FloatField(default=0, null=True, blank=True)
    amount = models.FloatField(default=0, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='misc_expense_head_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = "misc_expense_head"
        unique_together = ('organization', 'name')


class VendorCurrencyMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='misc_vendor_currency_master_organizations',
                                     on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=200)
    slug = models.CharField(max_length=200, blank=True, null=True)
    symbol = models.CharField(max_length=200, null=True, blank=True)
    exchange_rate = models.FloatField(default=1)
    is_default = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if not self.slug and self.name:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name + ' ' + self.symbol

    class Meta:
        db_table = "misc_vendor_currency_master"


class MergeLog(BaseAbstractStructure):
    type = models.CharField(max_length=200)
    from_id = models.IntegerField(default=0)
    to_id = models.IntegerField(default=0)

    def __str__(self):
        return str(self.type) + ' ' + str(self.from_id) + ' -> ' + str(self.to_id)

    class Meta:
        db_table = "misc_merge_log"


class NotifyUser(BaseAbstractStructure):
    user = models.ForeignKey(PmsUser, related_name='misc_notify_user_user', on_delete=models.CASCADE)
    type = models.CharField(max_length=200)
    context = models.TextField(blank=True, null=True)
    link = models.IntegerField(default=0)

    def __str__(self):
        return str(self.type) + ' : ' + str(self.user)

    class Meta:
        db_table = "misc_notify_user"


class RequestLog(BaseAbstractStructure):
    request_type = models.CharField(max_length=200, null=True, blank=True)
    request_path = models.TextField(null=True, blank=True)
    request_params = models.TextField(null=True, blank=True)
    request_body = models.TextField(null=True, blank=True)
    request_start_time = models.CharField(max_length=200, null=True, blank=True)
    request_end_time = models.CharField(max_length=200, null=True, blank=True)
    query_count = models.CharField(max_length=200, null=True, blank=True)
    query_execution_time = models.CharField(max_length=200, null=True, blank=True)
    duration = models.CharField(max_length=200, null=True, blank=True)
    memory_used = models.CharField(max_length=200, null=True, blank=True)
    response_size = models.CharField(max_length=200, null=True, blank=True)
    response_code = models.CharField(max_length=200, null=True, blank=True)
    response_details = models.TextField(null=True, blank=True)

    def __str__(self):
        return str(self.request_type) + ' : ' + str(self.request_path)

    class Meta:
        db_table = "misc_request_log"


class CodeRecord(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='code_record_organization', on_delete=models.CASCADE)
    base = models.CharField(max_length=200)
    last_record = models.IntegerField(default=1)
    is_mat = models.BooleanField(default=False)

    def __str__(self):
        return str(self.base) + ' : ' + str(self.last_record)

    class Meta:
        db_table = "misc_code_record"


class Comments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='misc_comments_organization', on_delete=models.CASCADE)
    ref_type = models.CharField(max_length=200)
    ref_id = models.IntegerField(default=0)
    comments = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "misc_comments"


class MimeTypes(BaseAbstractStructure):
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_extension = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "mime_type"


class CostCenter(BaseAbstractStructure):
    """
    Cost Center Model
    """
 
    organization = models.ForeignKey(
        Organization,
        related_name='organizations_cost_center',
        on_delete=models.CASCADE
    )
    name = models.CharField(max_length=300, null=True, blank=True)

    class Meta:
        db_table = "cost_center"


class GLAccount(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,related_name='gl_account_organization',on_delete=models.CASCADE)
    name = models.CharField(max_length=300, null=True, blank=True)
    is_infra = models.BooleanField(default=True)

    class Meta:
        db_table = "gl_account"

class AllowedIP(BaseAbstractStructure):
    ip_address = models.CharField(max_length=255,unique=True,blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    is_active=models.BooleanField(default=True)
    
    class Meta:
        db_table = "misc_allowed_ip"

class BelsioToken(BaseAbstractStructure):
    username = models.CharField(max_length=200)
    token = models.TextField(blank=True,null=True)

    def __str__(self):
        return str(self.username)+' --> '+str(self.token)+' --> '+str(self.is_deleted)


class ExternalRequests(BaseAbstractStructure):
    type = models.CharField(max_length=200,blank=True,null=True)
    url = models.CharField(max_length=200,blank=True,null=True)
    data = models.TextField(blank=True,null=True)
    status_code = models.CharField(max_length=200,blank=True,null=True)
    elapsed = models.CharField(max_length=200,blank=True,null=True)
    response_details = models.TextField(null=True, blank=True)


class StateCode(BaseAbstractStructure):
    numeric_code = models.CharField(max_length=200,blank=True,null=True)
    state_code = models.CharField(max_length=200,blank=True,null=True)


class ConditionTags(BaseAbstractStructure):
    name = models.CharField(max_length=200,blank=True,null=True)
    field = models.CharField(max_length=200,blank=True,null=True)
    module_type = models.CharField(max_length=200,blank=True,null=True)
    operands = models.TextField(null=True, blank=True)
    options = models.TextField(null=True, blank=True)

