from django.db.models.signals import pre_save, post_save
from django.db import transaction
from django.dispatch import receiver
from rest_framework.exceptions import APIException
from .models import *
from procurement.helper import handle_trigger_notifications ,generate_all_code , handle_belsio_purchase_order

@receiver(pre_save)
def delete_check(sender, instance, **kwargs):
    # print(sender._meta.app_label)
    # print(sender._meta.model_name)
    # print(sender._meta.object_name)
    if hasattr(sender, '_meta'):
        if not sender._meta.app_label in ['accounts']:
            if hasattr(instance, 'is_deleted') and instance.is_deleted:
                if hasattr(instance, 'status'):
                    if not instance.status in ['pending']:
                        raise APIException({'request_status': 0, 'msg': 'Only pending records can be deleted'})
                    else:
                        if hasattr(instance, 'current_stage'):
                            if not instance.current_stage == 0:
                                raise APIException({'request_status': 0, 'msg': 'Only pending records can be deleted'})
                links = sender._meta.related_objects
                total_count = 0
                for relation in links:
                    if not relation.related_model._meta.object_name.startswith(sender._meta.object_name) and not relation.related_model._meta.object_name in ['VendorDatabase','VendorMasterHistory']:
                        # print(relation.related_model._meta.object_name)
                        search = { relation.field.name: instance.id,'is_deleted': False}
                        total_count += relation.related_model.objects.filter(**search).count()
                if total_count > 0:
                    raise APIException({'request_status': 0, 'msg': 'This record is linked with other active records. Please unlink first.'})


@receiver(post_save, sender=VendorCurrencyMaster)
def update_default(sender, instance, **kwargs):
    if instance.is_default:
        VendorCurrencyMaster.cmobjects.exclude(pk=instance.id).update(is_default=False)


@receiver(post_save)
def trigger_notifications_created(sender, instance, created, **kwargs):
    with transaction.atomic():
        if created:
            code_map={
                'CST': ['CST','request_code'],
                'ScheduleH':['Schedule-H','code'],
                'PlantMachineryJobSheet':['JS','jobsheet_number'],
                'PlantMachineryLogBook':['LB','request_code'],
                'PlantMachineryAssetRequisition':['AR','request_code'],
                'PlantMachineryRFQVendors':['PNMENQUIRY','request_code'],
                'PlantMachineryCST':['PNMCST','request_code'],
                'PlantMachineryQuotation':['PNMQUOTATION','request_code'],
                'MaterialRequestMaster':['MR','request_code'],
                'Indent':['INDENT','request_code'],
                'RFQVendors':['ENQUIRY','request_code'],
                'MaterialIssue':['ISSUE','request_code'],
                'Quotation':['QUOTATION','request_code'],
                'PurchaseOrder':['PO','request_code'],
                'GRN':['GRN','request_code'],
                'BillReceive':['BR','request_code'],
                'GatePass':['GP','request_code'],
                'LabReportEntry':['LRE','request_code'],
                'WorkIndent':['WI','request_code'],
                'WorkOrder':['WO','request_code'],
                'FabricationWork':['FW','request_code'],
                'Purchase':['PB','request_code'],
                'PlantProduction':['PP','request_code'],
                'GeneralAdministrationExpenses':['GAE','request_code'],
                'RawMaterialSales':['RMS','request_code'],
                'PurchaseReturn':['PR','voucher_no'],
                'EnquiryAtOnce':['ENQUIRY','request_code'],
                'InvoiceSchedule':['IS','request_code'],
                'PlantMachineryWorkOrder':['PNMWO','request_code'],
                'PaymentMaster':['PM','request_code'],
                'PlantMachineryTaxInvoice':['PNMTI','request_code'],
                'PlantMachineryHireBillInvoice':['PNMHBI','request_code'],
                'PlantMachineryHSDApproval':['PNMHSDA','request_code'],
            }
            if sender._meta.object_name in code_map:
                is_direct_po = getattr(instance, 'is_direct_po', False)
                if is_direct_po:
                    code_map[sender._meta.object_name][0] = 'DIRECT-PO'
                code_list = [code_map[sender._meta.object_name][0]]
        
                previous_version = getattr(instance,'previous_version',None)
                if previous_version:
                    old_instance = sender.objects.filter(pk=instance.previous_version_id).first()
                    setattr(instance, code_map[sender._meta.object_name][1],getattr(old_instance,code_map[sender._meta.object_name][1]))
                    instance.version = int(old_instance.version if old_instance.version else 1)+1
                    old_instance.latest = False
                    old_instance.save()
                else:
                    is_repeat_order = getattr(instance,'is_repeat_order',False)
                    if is_repeat_order:
                        code_list.insert(0, 'RO')
                    print(instance,code_map[sender._meta.object_name][1])   
                    setattr(instance, code_map[sender._meta.object_name][1],generate_all_code(instance,code_list))
                instance.save()
            handle_trigger_notifications(type=sender._meta.model_name,details=instance,created=created)

