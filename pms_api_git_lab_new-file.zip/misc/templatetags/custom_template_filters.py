from django import template
from dateutil import parser

register = template.Library()
@register.filter(name="str_to_date")
def str_to_date(value, format="%Y-%m-%d"):
    try:
        return parser.parse(value).date().strftime(format)
    except ValueError:
        return value
