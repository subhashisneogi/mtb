from django.db import transaction
from rest_framework import serializers
from django.apps import apps

from procurement.helper import process_attachments,get_model_details , get_details_from_instance
from .models import *
from procurement.models import Communication, CommunicationType

class CommonFilterListSerializer(serializers.ListSerializer):
    """
    ListSerializer
    cmobject: is_deleted=False
    """
    def to_representation(self, data):
        data = data.filter(is_deleted=False)
        return super(CommonFilterListSerializer, self).to_representation(data)

class TermsAndConditionsChildSerializer(serializers.ModelSerializer):
    """"
    Procurement TermsAndConditionsChild Serializer
    """
    id = serializers.IntegerField(required=False)
    master_slug = serializers.SerializerMethodField()

    def get_master_slug(self, instance):
        _master = None
        if instance.master and instance.master_id:
            _master = TermsAndConditionsMaster.cmobjects.filter(pk=instance.master_id).values('id', 'name', 'slug')
        return _master
    class Meta:
        model = TermsAndConditionsChild
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TermsAndConditionsMasterSerializer(serializers.ModelSerializer):
    """"
    Procurement TermsAndConditionsMaster Serializer
    """
    terms_and_conditions_child = TermsAndConditionsChildSerializer(many=True, source="misc_terms_and_conditions")

    @transaction.atomic()
    def create(self, validated_data):
        items = validated_data.pop('misc_terms_and_conditions')
        instance = TermsAndConditionsMaster.objects.create(**validated_data)

        # insert items ✅
        for item in items:
            [item.pop(k, None) for k in
             ('organization', 'created_by', 'master', 'id',)]
            TermsAndConditionsChild.objects.create(
                master=instance,
                organization=instance.organization,
                created_by=instance.created_by,
                **item
            )

        instance.save()
        return instance

    @transaction.atomic()
    def update(self, instance, validated_data):
        items = validated_data.pop('misc_terms_and_conditions', [])
        instance = super().update(instance, validated_data)

        for key, value in validated_data.items():
            setattr(instance, key, value)

            # update/insert items ✅
            old_item_ids = [item.pk for item in instance.misc_terms_and_conditions.filter(is_deleted=False)]
            updated_item_ids = []
            for item in items:
                id = item.get('id')
                [item.update(kv) for kv in ({'organization': instance.organization},
                                            {'updated_by': instance.updated_by},
                                            {'is_deleted': False},
                                            {'master': instance},)]
                if not id:
                    _obj = TermsAndConditionsChild.objects.create(**item)
                    id = _obj.pk
                    print(f"item added {_obj.pk} {50 * '*'} ")
                else:
                    _obj, created = TermsAndConditionsChild.objects.update_or_create(pk=id, defaults=item)
                    print(f"item update {id} {50 * '*'}")

                updated_item_ids.append(id)
            # soft remove excluded items
            excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
            _ = TermsAndConditionsChild.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                                    updated_by=instance.updated_by)
            print('deleted TermsAndConditionsChild', _)

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        terms_and_conditions_child = representation.pop('terms_and_conditions_child', [])
        representation['terms_and_conditions_child'] = terms_and_conditions_child

        return representation


    class Meta:
        model = TermsAndConditionsMaster
        fields = '__all__'


class TaxHeadSerializer(serializers.ModelSerializer):
    """"
    Procurement TaxHead Serializer
    """

    class Meta:
        model = TaxHead
        fields = '__all__'


class AccountsHeadSerializer(serializers.ModelSerializer):
    """"
    Procurement AccountsHead Serializer
    """

    class Meta:
        model = AccountsHead
        fields = '__all__'


class ExpenseHeadSerializer(serializers.ModelSerializer):
    """"
    Procurement ExpenseHead Serializer
    """

    class Meta:
        model = ExpenseHead
        fields = '__all__'


class VendorCurrencyMasterSerializer(serializers.ModelSerializer):
    """"
    Procurement VendorCurrency Serializer
    """

    class Meta:
        model = VendorCurrencyMaster
        fields = '__all__'


class CommentsSerializer(serializers.ModelSerializer):
    """"
    Procurement Comments Serializer
    """
    created_by_details = serializers.SerializerMethodField()
    ref_details = serializers.SerializerMethodField()
    def get_created_by_details(self, instance):
        _details = None
        if instance.created_by and instance.created_by_id:
            _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
        return _details
    def get_ref_details(self, instance):
        details = None
        if instance.ref_type and instance.ref_id:
            fixed_data = get_model_details(instance.ref_type)
            model_name = fixed_data['model_name']
            model = apps.get_model('procurement', model_name)
            details = model.cmobjects.filter(pk=instance.ref_id).values()
        return details

    class Meta:
        model = Comments
        fields = '__all__'


class CostCenterSerializer(serializers.ModelSerializer):
    """"
     CostCenter Serializer
    """
 
    class Meta:
        model = CostCenter
        fields = '__all__'


class GLAccountSerializer(serializers.ModelSerializer):
    """"
     GLAccount Serializer
    """
 
    class Meta:
        model = GLAccount
        fields = '__all__'


class ConditionTagsSerializer(serializers.ModelSerializer):
    """"
     ConditionTags Serializer
    """
 
    class Meta:
        model = ConditionTags
        fields = '__all__'

