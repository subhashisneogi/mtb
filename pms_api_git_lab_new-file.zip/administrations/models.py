
import datetime
from PIL import Image
import sys
import os
from io import BytesIO

from django.db import models, connection
from datetime import datetime
from django.contrib.auth.models import AbstractUser

from django.utils.text import slugify
from django.core.validators import EmailValidator, RegexValidator
from django.core.files.uploadedfile import InMemoryUploadedFile

from django.conf import settings
from adminpanel.models import *

from django.db.models.signals import pre_save
from django.dispatch import receiver

# from procurement.models import FinancialYear

# Create your models here.


class CustomManager(models.Manager):
    def lock(self):
        cursor = connection.cursor()
        table = self.model._meta.db_table
        cursor.execute("LOCK TABLES %s WRITE" % table)
        row = cursor.fetchone()
        return row

    def unlock(self):
        cursor = connection.cursor()
        table = self.model._meta.db_table
        cursor.execute("UNLOCK TABLES")
        row = cursor.fetchone()
        return row

    def get_queryset(self):
        return super(__class__, self).get_queryset().filter(is_deleted=False)


class BaseAbstractStructure(models.Model):
    is_deleted = models.BooleanField(default=False)
    created_by = models.ForeignKey('administrations.PmsUser', on_delete=models.CASCADE, blank=True, null=True, related_name='+')
    updated_by = models.ForeignKey('administrations.PmsUser', on_delete=models.CASCADE, blank=True, null=True, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = models.Manager()
    cmobjects = CustomManager()

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        self.updated_at = datetime.now()
        super(__class__, self).save(*args, **kwargs)

class Organization(models.Model):
    """
    Main Organisation Model
    """
    name = models.CharField(max_length=255)
    code = models.CharField(max_length=200)
    org_country = models.ForeignKey(Country, related_name='organization_country',on_delete=models.CASCADE)
    org_state = models.ForeignKey(State, related_name='organization_state',on_delete=models.CASCADE)
    org_city = models.ForeignKey(City, related_name='organization_city',on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class OrganizationAttachment(models.Model):
    organization = models.ForeignKey(Organization, related_name='organization_attachment_organization',on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    image = models.ImageField(upload_to='organization/image', null=True, blank=True)

    def __str__(self):
        return self.name


class Company(BaseAbstractStructure):
    """ Companies under a organisations"""
    COMPANY_CLASSIFICATION_CHOICES = (
        ('Infra', 'Infra'),
        ('Non-Infra', 'Non-Infra'),
    )
    name = models.CharField(max_length=255)
    organization = models.ForeignKey(Organization, related_name='company_organization',on_delete=models.CASCADE)
    party_address = models.TextField(blank=True, null=True)
    lead_member_name = models.CharField(max_length=255, blank=True, null=True)
    pan_no = models.CharField(max_length=200, blank=True, null=True)
    gst_no = models.CharField(max_length=200, blank=True, null=True)
    email_id = models.EmailField(validators=[EmailValidator()], blank=True, null=True)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{6,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    phone_no = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True) # validators should be a list

    ##################### Contact Person Info ##################

    contact_person_name = models.CharField(max_length=255, blank=True, null=True)
    contact_person_phone_no = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True) # validators should be a list
    contact_person_email_id = models.EmailField(validators=[EmailValidator()], blank=True, null=True)

    ##################### Technical Eligibilities ##################

    available_threshold = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    value_of_similar_works = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    maximum_span_length_of_bridge_avail = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    
    ##################### Financial Eligibilities ##################

    average_annual_turn_over = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    net_worth = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    users = models.ManyToManyField("administrations.PmsUser", related_name="company", null=True, blank=True)
    is_default = models.BooleanField(default=False)
    sap_code = models.CharField(max_length=255, blank=True, null=True)
    sap_auth_key = models.CharField(max_length=300, blank=True, null=True)
    company_classification = models.CharField(max_length=255, choices=COMPANY_CLASSIFICATION_CHOICES, blank=True, null=True) 

    def __str__(self):
        return f"{self.name} -> {self.sap_code}"

class UserType(BaseAbstractStructure):
    """ User Type Model"""
    user_type = models.CharField(max_length=200)
    organization = models.ForeignKey(Organization, related_name='user_type_organization',on_delete=models.CASCADE)

    def __str__(self):
        return self.user_type


class Role(BaseAbstractStructure):
    """ 
    Role Model(previous designation)"""
    parent_id=models.IntegerField(default=0)
    designation = models.CharField(max_length=200)
    organization = models.ForeignKey(Organization, related_name='organization_designation',on_delete=models.CASCADE)
    company = models.ForeignKey(Company, related_name='company_designation',on_delete=models.CASCADE, blank=True, null=True)
    share_to_peer=models.BooleanField(default=False)
    description = models.TextField(blank=True, null=True)
    def __str__(self):
        return self.designation


class Department(BaseAbstractStructure):
    """ Department Model"""
    department = models.CharField(max_length=200)
    organization = models.ForeignKey(Organization, related_name='organization_department',on_delete=models.CASCADE)
    department_head = models.ForeignKey('administrations.PmsUser', related_name='organization_department_head', on_delete=models.DO_NOTHING, blank=True, null=True)

    def __str__(self):
        return self.department



class Profile(BaseAbstractStructure):
    """ Profile  Model(previous organizationrole)"""
    role_name = models.CharField(max_length=200)
    is_active = models.BooleanField(default=False)
    permissions_added = models.BooleanField(default=False)
    description = models.TextField(blank=True, null=True)
    organization = models.ForeignKey(Organization, related_name='organization_role',on_delete=models.CASCADE)

    def __str__(self):
        return self.role_name


class PmsUser(AbstractUser):
    """
    Extending User Model Using a Custom Model Extending AbstractUser
    """
    GENDER_TYPE = (
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    )
    MARATIAL_TYPE = (
        ('Married', 'Married'),
        ('Single', 'Single'),
    )
    BLOOD_GROUP_TYPE = (
        ('A+', 'A+'),
        ('A-', 'A-'),
        ('B+', 'B+'),
        ('B-', 'B-'),
        ('O+', 'O+'),
        ('O-', 'O-'),
        ('AB+', 'AB+'),
        ('AB-', 'AB-'),
    )
    organization = models.ForeignKey(Organization, related_name='user_organization',on_delete=models.CASCADE, blank=True, null=True)
    mothers_name = models.CharField(max_length=255, blank=True, null=True)
    fathers_name = models.CharField(max_length=255, blank=True, null=True)
    emergency_contact_relation = models.CharField(max_length=255, blank=True, null=True)
    emergency_contact_name = models.CharField(max_length=255, blank=True, null=True)
    emergency_contact_phone_no = models.CharField(max_length=255, blank=True, null=True)
    ############################## For HR Purpose ################################

    employe_code = models.CharField(max_length=200, blank=True, null=True)
    employement_type = models.ForeignKey(UserType, related_name='user_types',on_delete=models.CASCADE, blank=True, null=True)
    company_name = models.ForeignKey(Company, related_name='user_companies',on_delete=models.CASCADE, blank=True, null=True)
    department = models.ForeignKey(Department, related_name='departments',on_delete=models.CASCADE, blank=True, null=True)
    reporting_manager = models.ForeignKey('self', related_name='user_reporting_manager', on_delete=models.CASCADE, blank=True, null=True)
    notice_period = models.CharField(max_length=200, blank=True, null=True)
    joining_date = models.DateField(blank=True, null=True)
    last_working_date = models.DateField(blank=True, null=True)
    aadhar_number = models.CharField(max_length=200, blank=True, null=True)
    pan_number = models.CharField(max_length=200, blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)

    ############################## Profile Permissions ################################

    designation = models.ForeignKey(Role, related_name='designations',on_delete=models.DO_NOTHING, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='roles',on_delete=models.DO_NOTHING, blank=True, null=True)
    
    ############################## Address Info ################################

    address_line_1 = models.CharField(max_length=255, blank=True, null=True)
    address_line_2 = models.CharField(max_length=255, blank=True, null=True)
    country = models.ForeignKey(Country, related_name='user_country',on_delete=models.DO_NOTHING, blank=True, null=True)
    state = models.ForeignKey(State, related_name='user_state',on_delete=models.DO_NOTHING, blank=True, null=True)
    city = models.ForeignKey(City, related_name='user_city',on_delete=models.DO_NOTHING, blank=True, null=True)
    zone = models.ForeignKey(Zone, related_name='user_zone',on_delete=models.DO_NOTHING, blank=True, null=True)

    
    gender = models.CharField(max_length=15,choices=GENDER_TYPE, blank=True, null=True)
    blood_group = models.CharField(max_length=15,choices=BLOOD_GROUP_TYPE, blank=True, null=True)
    maratial_status = models.CharField(max_length=15,choices=MARATIAL_TYPE, blank=True, null=True)
    
    image = models.ImageField(
        upload_to='user/profile_image', null=True, blank=True, help_text='Image Size 130 x 130')
    deleted_by = models.ForeignKey('self', related_name='deleted_by_user', on_delete=models.CASCADE, blank=True, null=True)
    is_deleted =  models.BooleanField(default=False)
    deleted_on = models.DateTimeField("Deleted on", auto_now=False, auto_now_add=False, blank=True, null=True)
    created_by = models.ForeignKey('self', related_name='created_by_user', on_delete=models.CASCADE, blank=True, null=True)
    created_on = models.DateTimeField(auto_now_add=True)

    # HRMS SSO
    hrms_user_id = models.IntegerField(blank=True, null=True)
    sap_personnel_no = models.CharField(max_length=200, blank=True, null=True)
    is_allow_multiple_device = models.BooleanField(default=False)
    password_expiry_date=models.DateField(blank=True,null=True)
    is_allow_otp_login = models.BooleanField(default=False)
    is_allow_two_factor = models.BooleanField(default=True)
    @property
    def user_full_name(self):
        " Returns the person's full name. "
        return '%s %s' % (self.first_name, self.last_name)
            
    def save(self, *args, **kwargs):
        if self.email:
            self.username = self.email
        if self.image:
            if os.path.exists(str(self.image)):
                temp_image = Image.open(self.image).convert('RGB')
                output_io_stream = BytesIO()
                temp_resized_image = temp_image.resize((500, 500))
                temp_resized_image.save(
                    output_io_stream, format='JPEG', quality=60)
                output_io_stream.seek(0)
                self.image = InMemoryUploadedFile(output_io_stream,
                                                    'ImageField', "%s.jpg" % self.image.name.split('.')[0], 'image/jpeg', sys.getsizeof(output_io_stream), None)
                
        return super().save(*args, **kwargs)
class UserDeviceToken(BaseAbstractStructure):
    """
    UserDeviceToken
    """
    user = models.ForeignKey(PmsUser, related_name='user_device_token_user', on_delete=models.CASCADE,blank=True, null=True)
    token = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)


class UserOTP(BaseAbstractStructure):
    user = models.ForeignKey(PmsUser, related_name='user_otp_user', on_delete=models.CASCADE,blank=True, null=True)
    otp_secret = models.CharField(max_length=200)
    expiry = models.DateTimeField(blank=True,null=True)
    is_used = models.BooleanField(default=False)


class AcademicQualification(BaseAbstractStructure):
    """
    Academic Qualification
    """
    user = models.ForeignKey(PmsUser, related_name='academic_user', on_delete=models.CASCADE,blank=True, null=True)
    qualifications = models.ForeignKey(AcademicQualificationType, related_name='academic_type', on_delete=models.CASCADE,blank=True, null=True)
    details = models.TextField(blank=True, null=True)
    file = models.FileField(
        upload_to='qualification/document', null=True, blank=True, help_text='file')
    
    def __str__(self):
        return str(self.user.username) + " qualification " + str(self.qualifications.name)
    

class LicenseAndCertificate(BaseAbstractStructure):
    """
    Academic Qualification
    """
    user = models.ForeignKey(PmsUser, related_name='license_user', on_delete=models.CASCADE,blank=True, null=True)
    license_name = models.CharField(max_length=255)
    file = models.FileField(
        upload_to='license/document', null=True, blank=True, help_text='file')
    
    def __str__(self):
        return str(self.user.username) + " qualification " + str(self.license_name)
    

class WorkExperience(BaseAbstractStructure):
    """
    Academic Qualification
    """
    user = models.ForeignKey(PmsUser, related_name='work_user', on_delete=models.CASCADE,blank=True, null=True)
    organization_name = models.CharField(max_length=255)
    file = models.FileField(
        upload_to='work/document', null=True, blank=True, help_text='file')
    
    def __str__(self):
        return str(self.user.username) + " - qualification - " + str(self.organization_name)
    

class OtherDocuments(BaseAbstractStructure):
    """
    Other Documents
    """
    user = models.ForeignKey(PmsUser, related_name='other_document_user', on_delete=models.CASCADE,blank=True, null=True)
    document_name = models.CharField(max_length=255)
    file = models.FileField(
        upload_to='other/document', null=True, blank=True, help_text='file')
    
    def __str__(self):
        return str(self.document_name)

class LoginLogoutLoggedTable(models.Model):
    user = models.ForeignKey(PmsUser, on_delete=models.CASCADE,blank=True, null=True)
    token=models.CharField(max_length=255, blank=True, null=True)
    ip_address=models.CharField(max_length=255, blank=True, null=True)
    login_time=models.DateTimeField(auto_now_add=True)
    logout_time=models.DateTimeField(auto_now=False, blank=True, null=True)
    browser_name=models.CharField(max_length=255, blank=True, null=True)
    os_name=models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(PmsUser, related_name='lg_created_by',on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return str(self.id)
    class Meta:
        db_table = 't_log_signin_signout'


class MenuMaster(BaseAbstractStructure):
    """ Menu Master Model"""
    menu_name = models.CharField(max_length=200)
    form_type_name = models.CharField(max_length=200, blank=True, null=True)  # TODO: unique=True after stable
    description = models.TextField(blank=True, null=True)
    is_shown = models.BooleanField(default=False)
    is_menu_show = models.BooleanField(default=False)
    slug = models.SlugField(unique=False, blank=True) # TODO: unique=True after stable

    def save(self, *args, **kwargs):
        if not self.slug and self.form_type_name:
            self.slug = slugify(self.form_type_name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.menu_name


@receiver(pre_save, sender=MenuMaster)
def create_menu_master_slug(sender, instance, **kwargs):
    if not instance.slug:
        instance.slug = slugify(instance.menu_name)


class SubMenuMaster(BaseAbstractStructure):
    sub_menu_name = models.CharField(max_length=200)
    menu = models.ForeignKey(MenuMaster, related_name='menus',on_delete=models.DO_NOTHING, blank=True, null=True)
    form_type_name = models.CharField(max_length=200, blank=True, null=True)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.sub_menu_name
    
class FormMenuMaster(BaseAbstractStructure):
    form_name = models.CharField(max_length=200)
    menu = models.ForeignKey(MenuMaster, related_name='menu_form',on_delete=models.DO_NOTHING, blank=True, null=True)
    form_type_name = models.CharField(max_length=200, blank=True, null=True, unique=True)  # TODO NOTE: --- one2many-> Form Group Mastr/form_type  ---
    description = models.TextField(blank=True, null=True)
    is_post = models.BooleanField(default=False)
    sort_order = models.FloatField(default=0)
    is_display = models.BooleanField(default=False)
    project_creation_after_submission = models.BooleanField(default=False)
    
    def __str__(self):
        return self.form_name + ' [' + self.form_type_name + ']'


class AdministrativeMaster(BaseAbstractStructure):
    """ Administrative Master Module"""
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name
    

class ModulePermissionsMaster(BaseAbstractStructure):
    """
    Module Permissions
    """
    name = models.CharField(max_length=255)
    permission_for = models.CharField(max_length=255)
    unique_id = models.CharField(max_length=255)

    def __str__(self):
        return self.name
    
    # def save(self, *args, **kwargs):    
    #     self.unique_id = slugify(self.name)
    #     super(ModulePermissionsMaster, self).save(*args, **kwargs)


class SettingsGroupMaster(BaseAbstractStructure):
    """  Settings Group Master """

    organization = models.ForeignKey(Organization, related_name='settings_organization',on_delete=models.CASCADE, blank=True, null=True)
    name = models.CharField(max_length=200)
    icon_image = models.ImageField(
        upload_to='settings_image', null=True, blank=True, help_text='Image Size 64 x 64')


    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):    

        if self.icon_image:
            temp_image = Image.open(self.icon_image).convert('RGBA')
            output_stream = BytesIO()
            temp_resized_image = temp_image.resize((64, 64))
            temp_resized_image.save(output_stream, format='PNG', quality=90)
            output_stream.seek(0)
            self.icon_image = InMemoryUploadedFile(
                output_stream,
                'ImageField',
                "%s.png" % self.icon_image.name.split(
                    '.')[0],  # need revision for file name
                'image/png',
                sys.getsizeof(output_stream),
                None)

        super(SettingsGroupMaster, self).save(*args, **kwargs)



class SettingsMaster(BaseAbstractStructure):
    """ Administrative Master Module"""

    settings_group = models.ForeignKey(SettingsGroupMaster, related_name='settings_group',on_delete=models.CASCADE, blank=True, null=True )
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, null=True, blank=True)  # as request by Front End
    settings_for = models.CharField(max_length=200, null=True, blank=True)
    icon_image = models.ImageField(
        upload_to='settings_image', null=True, blank=True, help_text='Image Size 64 x 64')
    ordering = models.IntegerField(default=0, blank=True, null=True)


    class Meta:
        ordering = ('ordering', 'settings_group', 'id')
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):    
        # self.slug = slugify(self.name)

        if self.icon_image:
            temp_image = Image.open(self.icon_image).convert('RGBA')
            output_stream = BytesIO()
            temp_resized_image = temp_image.resize((64, 64))
            temp_resized_image.save(output_stream, format='PNG', quality=90)
            output_stream.seek(0)
            self.icon_image = InMemoryUploadedFile(
                output_stream,
                'ImageField',
                "%s.png" % self.icon_image.name.split(
                    '.')[0],  # need revision for file name
                'image/png',
                sys.getsizeof(output_stream),
                None)

        super(SettingsMaster, self).save(*args, **kwargs)
        
        
class NoticeBoard(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='notice_organization',on_delete=models.CASCADE, blank=True, null=True)
    subject = models.CharField(max_length=100)
    notice_date = models.DateField(auto_now=False, auto_now_add=False)
    content = models.TextField()
    signature = models.ImageField(upload_to='notice_signatures', blank=True, null=True)

    def __str__(self):
        return str(self.subject) + " - by - " + str(self.created_by)
    

class JVMASTER(BaseAbstractStructure):
    """
    JV Master Model
    """
    organization = models.ForeignKey(Organization, related_name='jv_organization',on_delete=models.CASCADE, blank=True, null=True)
    party_name = models.CharField(max_length=255)
    party_address = models.TextField(blank=True, null=True)
    lead_member_name = models.CharField(max_length=255, blank=True, null=True)
    pan_no = models.CharField(max_length=200, blank=True, null=True)
    gst_no = models.CharField(max_length=200, blank=True, null=True)
    email_id = models.EmailField(validators=[EmailValidator()], blank=True, null=True)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{6,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    phone_no = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True) # validators should be a list
    address = models.TextField(blank=True, null=True)
    ##################### Contact Person Info ##################
    contact_person_name = models.CharField(max_length=255, blank=True, null=True)
    contact_person_phone_no = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True) # validators should be a list
    contact_person_email_id = models.EmailField(validators=[EmailValidator()], blank=True, null=True)
    ##################### Technical Eligibilities ##################
    available_threshold = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    value_of_similar_works = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    maximum_span_length_of_bridge_avail = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    
    ##################### Financial Eligibilities ##################

    average_annual_turn_over = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)
    net_worth = models.DecimalField(
        max_digits=50, decimal_places=2, blank=True, null=True)

    def __str__(self):
        return str(self.party_name)
    
class JVMASTERDocument(BaseAbstractStructure):
    BIFURCATION_TYPE = (
        ('Profile', 'Profile'),
        ('Certificate', 'Certificate'),
    )
    organization = models.ForeignKey(Organization, related_name='jv_master_organization', on_delete=models.CASCADE)
    jv_master = models.ForeignKey(JVMASTER, related_name='jv_master_document', on_delete=models.CASCADE,
        blank=True,
        null=True
    )
    file_name=models.CharField(max_length=200, null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(
        upload_to='jv_master/document/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    bifurcation = models.CharField(max_length=200,choices=BIFURCATION_TYPE, blank=True, null=True, default='Profile')
    class Meta:
        db_table = "jv_master_document"

class JVMASTERFinancialDetails(BaseAbstractStructure):
    jv_master = models.ForeignKey(JVMASTER, related_name='jv_master_financial_details', on_delete=models.CASCADE,
        blank=True,
        null=True
    )
    financial_year = models.ForeignKey('procurement.FinancialYear', related_name='financial_year', on_delete=models.CASCADE, null=True, blank=True)
    turn_over_value = models.FloatField(default=0, null=True, blank=True)
    net_worth_value = models.FloatField(default=0, null=True, blank=True)
    class Meta:
        db_table = "jv_master_financial_details"

class JVMASTERWorkExperienceCategoryMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='jv_master_work_experience_category_master_organization', on_delete=models.CASCADE)
    name = models.CharField(max_length=250, null=True, blank=True)
    class Meta:
        db_table = "jv_master_work_experience_category_master"

class JVMASTERWorkExperience(BaseAbstractStructure):
    jv_master = models.ForeignKey(JVMASTER, related_name='jv_master_work_experience', on_delete=models.CASCADE,
        blank=True,
        null=True
    )
    category = models.CharField(max_length=250, null=True, blank=True)
    working_category = models.ForeignKey(JVMASTERWorkExperienceCategoryMaster, related_name='jv_master_work_experience_category_master_organization', 
                                 on_delete=models.CASCADE, null=True, blank=True)
    client = models.CharField(max_length=250, null=True, blank=True)
    value = models.FloatField(default=0, null=True, blank=True)
    work_summary = models.TextField(null=True, blank=True)
    type = models.TextField(null=True, blank=True)
    pavement_type = models.TextField(null=True, blank=True)
    length =  models.TextField(null=True, blank=True)
    max_span = models.CharField(max_length=250, null=True, blank=True)
    foundation_type = models.TextField(null=True, blank=True)
    height = models.TextField(null=True, blank=True)
    storey = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "jv_master_work_experience"

class STANDALONEMASTER(BaseAbstractStructure):
    """
    JV Master Model
    """
    organization = models.ForeignKey(Organization, related_name='standalone_organization',on_delete=models.CASCADE, blank=True, null=True)
    party_name = models.CharField(max_length=255)
    party_address = models.TextField(blank=True, null=True)
    lead_member_name = models.CharField(max_length=255, blank=True, null=True)
    pan_no = models.CharField(max_length=200, blank=True, null=True)
    gst_no = models.CharField(max_length=200, blank=True, null=True)
    email_id = models.EmailField(validators=[EmailValidator()], blank=True, null=True)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{6,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    phone_no = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True) # validators should be a list
    address = models.TextField(blank=True, null=True)

    def __str__(self):
        return str(self.party_name)
    

class EMPLOYEEMASTER(BaseAbstractStructure):
    """
    EMPLOYEE Master Model
    """
    organization = models.ForeignKey(Organization, related_name='employee_organization',on_delete=models.CASCADE, blank=True, null=True)
    employee_name = models.CharField(max_length=255)
    pan_no = models.CharField(max_length=200, blank=True, null=True)
    gst_no = models.CharField(max_length=200, blank=True, null=True)
    email_id = models.EmailField(validators=[EmailValidator()], blank=True, null=True)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{6,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    phone_no = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True) # validators should be a list
    address = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return str(self.employee_name)
    

class NotificationMaster(BaseAbstractStructure):
    """
    Notification Master
    """
    organization = models.ForeignKey(Organization, related_name='notification_organization',on_delete=models.CASCADE, blank=True, null=True)
    notification = models.TextField(blank=True, null=True)
    context = models.TextField(default='')
    notified_users = models.ForeignKey(PmsUser, related_name='notifier', on_delete=models.CASCADE,blank=True, null=True)
    is_read = models.BooleanField(default=False)
    is_universal = models.BooleanField(default=False)

    is_manual = models.BooleanField(default=False)

    def __str__(self):
        return str(self.notification)
    

class Obligations(BaseAbstractStructure):
    """
    Obligations Model
    """
    obligations = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return str(self.obligations)

class DelayReasons(BaseAbstractStructure):
    """
    Delay Reason Master Table    
    """
    RISK_TYPE = (
        ('FINANCIAL', 'FINANCIAL'),
        ('NORMAL', 'NORMAL'),
    )
    organization = models.ForeignKey(Organization, related_name='delay_organization',on_delete=models.CASCADE, blank=True, null=True)
    reasons = models.TextField(blank=True, null=True)
    delay_code = models.CharField(max_length=100, null=True, blank=True)
    is_universal = models.BooleanField(default=False)
    obligations = models.ManyToManyField(
        Obligations, related_name='delay_obligations_by', blank=True, null=True)
    risk_type = models.CharField(max_length=15,choices=RISK_TYPE, default='NORMAL')
    color_code = models.CharField(max_length=200, blank=True, null=True)
    

    def __str__(self):
        return str(self.reasons)
    

class DelayBreakUps(BaseAbstractStructure):
    """
    Delay Break UPs from Delay Reason
    """
    delay = models.ForeignKey(DelayReasons, related_name='delay_reasons',on_delete=models.CASCADE, blank=True, null=True)
    name = models.CharField(max_length=200)

    def __str__(self):
        return str(self.name)
    

class HRMSToken(BaseAbstractStructure):
    username = models.CharField(max_length=200)
    token = models.CharField(max_length=200)

    def __str__(self):
        return str(self.username)+' --> '+str(self.token)+' --> '+str(self.is_deleted)
    

class Holiday(BaseAbstractStructure):
    organization = models.ForeignKey('administrations.Organization', on_delete=models.CASCADE)
    state = models.ForeignKey(State, on_delete=models.CASCADE)
    country = models.ForeignKey(Country, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    date = models.DateField()
