from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from django.contrib.auth.admin import UserAdmin
from unfold.forms import AdminPasswordChangeForm, UserChangeForm, UserCreationForm
from administrations.models import *

# Register your models here.

@admin.register(LoginLogoutLoggedTable)
class LoginLogoutLoggedTable(ModelAdmin):
    list_display = [field.name for field in LoginLogoutLoggedTable._meta.fields]
    search_fields = ('user__username', 'ip_address', 'browser_name','os_name')

@admin.register(Role)
class RoleTable(ModelAdmin):
    list_display = [field.name for field in Role._meta.fields]
    search_fields = ('designation', 'parent_id')


class DelayBreakUpsAdmin(StackedInline):
	"""
	DelayBreakUps Admin
	"""
	model = DelayBreakUps
	fk_name = 'delay'
     

class DelayReasonsAdmin(ModelAdmin):
    model = DelayReasons
    list_display = ['reasons','organization','delay_code','risk_type','color_code']
    search_fields = ['reasons','delay_code','risk_type','color_code']
    inlines = (DelayBreakUpsAdmin,) 
     

@admin.register(MenuMaster)
class MenuMasterAdmin(ModelAdmin):
    model = MenuMaster
    list_display = ['menu_name','is_shown','is_menu_show','is_deleted']
     

@admin.register(SubMenuMaster)
class SubMenuMasterAdmin(ModelAdmin):
    model = SubMenuMaster
    list_display = ['sub_menu_name','menu','is_deleted']
    search_fields = ['menu__menu_name']
     

@admin.register(SettingsGroupMaster)
class SettingsGroupMasterAdmin(ModelAdmin):
    model = SettingsGroupMaster
    list_display = ['name','is_deleted']
     

@admin.register(SettingsMaster)
class SettingsMasterAdmin(ModelAdmin):
    model = SettingsMaster
    search_fields = ('name', 'slug','settings_group__name','settings_for')
    list_display = ['name','slug','settings_group','settings_for', 'ordering', 'is_deleted']
     

@admin.register(Profile)
class ProfileAdmin(ModelAdmin):
    model = Profile
    search_fields = ('role_name',)
    list_display = ['role_name','permissions_added','is_active','is_deleted']
     

@admin.register(ModulePermissionsMaster)
class ModulePermissionsMasterAdmin(ModelAdmin):
    model = ModulePermissionsMaster
    search_fields = ('name',)
    list_display = ['name','permission_for','unique_id','is_deleted']
     

@admin.register(HRMSToken)
class HRMSTokenAdmin(ModelAdmin):
    model = HRMSToken
    search_fields = ('username',)
    list_display = ['username','token','is_deleted']
@admin.register(Holiday)
class HolidayAdmin(ModelAdmin):
    model = Holiday
    search_fields = ('name',)
    list_display = ['id','name','date','country','state','is_deleted']

class OrganizationAttachmentAdmin(StackedInline):
    model = OrganizationAttachment
    fk_name = 'organization'
@admin.register(Organization)
class OrganizationAdmin(ModelAdmin):
    list_display = ['name', 'code']
    search_fields = ['name', 'code']
    inlines = (OrganizationAttachmentAdmin,)

class CompanyAdmin(ModelAdmin):
    model = Company
    list_display = ['id','name','sap_code','sap_auth_key','is_default', 'is_deleted']
admin.site.register(Company,CompanyAdmin)

@admin.register(Department)
class DepartmentAdmin(ModelAdmin):
    search_fields=['department']
    list_display = ['id','department', 'is_deleted']

admin.site.register(UserType,ModelAdmin)
class PmsUserAdmin(UserAdmin,ModelAdmin):
    form = UserChangeForm
    add_form = UserCreationForm
    change_password_form = AdminPasswordChangeForm
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal Info', {'fields': (
            'first_name', 'last_name', 'email',
            'gender', 'date_of_birth', 'maratial_status', 'blood_group',
            'mothers_name', 'fathers_name', 'emergency_contact_relation',
            'emergency_contact_name', 'emergency_contact_phone_no','password_expiry_date'
        )}),
        ('HR Details', {'fields': (
            'employe_code', 'notice_period', 'joining_date', 
            'last_working_date', 'aadhar_number', 'pan_number', 
            'hrms_user_id', 'sap_personnel_no'
        )}),
        ('Address Info', {'fields': ('address_line_1', 'address_line_2')}),
        ('Permissions', {'fields': ('is_active', 'is_superuser', 'user_permissions')}),
        ('Deletion', {'fields': ('is_deleted', 'deleted_by', 'deleted_on')}),
        ('Profile Settings', {'fields': ('is_allow_multiple_device', 'image','is_allow_otp_login')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'password1', 'password2'),
        }),
    )

    list_display = ('id', 'username', 'email','password_expiry_date','is_active','is_allow_multiple_device','is_allow_otp_login' ,'is_deleted')
    list_filter = ('is_allow_multiple_device','is_allow_otp_login','is_active', 'is_deleted')
    search_fields = ('username', 'email','first_name', 'last_name')
    ordering = ('username',)

admin.site.register(PmsUser, PmsUserAdmin)

@admin.register(UserDeviceToken)
class UserDeviceTokenAdmin(ModelAdmin):
    model = UserDeviceToken
    list_display = ['id','user','is_active','token','is_deleted']
admin.site.register(FormMenuMaster,ModelAdmin)
admin.site.register(AdministrativeMaster,ModelAdmin)
admin.site.register(AcademicQualification,ModelAdmin)
admin.site.register(LicenseAndCertificate,ModelAdmin)
admin.site.register(WorkExperience,ModelAdmin)
admin.site.register(OtherDocuments,ModelAdmin)
admin.site.register(NoticeBoard,ModelAdmin)   

class JVMASTERAdmin(ModelAdmin):
    model = JVMASTER
    list_display = ['id','party_name', 'is_deleted']
admin.site.register(JVMASTER, JVMASTERAdmin)
admin.site.register(STANDALONEMASTER,ModelAdmin)

class EMPLOYEEMASTERAdmin(ModelAdmin):
    list_display = ['id','employee_name', 'is_deleted']
    search_fields = ['id', 'employee_name']
admin.site.register(EMPLOYEEMASTER, EMPLOYEEMASTERAdmin)

admin.site.register(NotificationMaster,ModelAdmin)
admin.site.register(DelayReasons, DelayReasonsAdmin)
admin.site.register(Obligations,ModelAdmin)

@admin.register(UserOTP)
class UserOTPAdmin(ModelAdmin):
    model = UserOTP
    list_display = ['id','user','expiry','otp_secret','is_used','is_deleted']
    search_fields = ['user']
    list_filter = ('is_used', 'is_deleted')

@admin.register(JVMASTERFinancialDetails)
class JVMASTERFinancialDetailsAdmin(ModelAdmin):
    model = JVMASTERFinancialDetails
    list_display = ['id', 'jv_master', 'is_deleted', 'financial_year', 'turn_over_value', ]
    list_filter = ('jv_master', 'financial_year')

@admin.register(JVMASTERWorkExperience)
class JVMASTERWorkExperienceAdmin(ModelAdmin):
    model = JVMASTERWorkExperience
    list_display = ['id', 'jv_master', 'category', 'client', 'value', 'is_deleted']
    list_filter = ('jv_master',)


@admin.register(JVMASTERDocument)
class JVMASTERDocumentAdmin(ModelAdmin):
    model = JVMASTERDocument
    list_display = ['id', 'jv_master', 'attachment_name', 'attachment_name', 'file_name', 'attachment', 'is_deleted']
    list_filter = ('jv_master',)


@admin.register(JVMASTERWorkExperienceCategoryMaster)
class JVMASTERWorkExperienceCategoryMasterAdmin(ModelAdmin):
    model = JVMASTERWorkExperienceCategoryMaster
    list_display = ['id', 'name']