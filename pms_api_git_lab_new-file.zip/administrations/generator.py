


def generate_large_list_with_start_index(start, end, chainage):
    for i in range(start, end, chainage):
        yield i