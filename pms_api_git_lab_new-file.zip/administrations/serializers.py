
from rest_framework import serializers
from django.contrib.auth.models import *
from django.contrib.auth import authenticate

from django.contrib import auth
from rest_framework.exceptions import AuthenticationFailed,PermissionDenied,APIException
""" Reset password and send link with token"""
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.encoding import smart_str, force_str, smart_bytes, DjangoUnicodeDecodeError
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
import pyotp
from .models import *
from rest_framework import status
from django.db.models import Q
from user_profile.models import UserProfile
from misc.models import AllowedIP
from colorama import Back, Style
from django.http import JsonResponse
from rest_framework.response import Response
from administrations.utils import detectBrowser,send_login_otp
from procurement.helper import password_expiry_date_reset, process_attachments, get_details_from_instance
from django.db import transaction


class CommonFilterListSerializer(serializers.ListSerializer):
    """
    ListSerializer
    cmobject: is_deleted=False
    """
    def to_representation(self, data):
        # if isinstance(data, Page):
        #     data.object_list = data.object_list.filter(is_deleted=False)
        if hasattr(data, 'object_list'):
            # print("check with object list")
            data.object_list = [item for item in data.object_list if not item.is_deleted]
        else:
            # print("check without pagination")
            data = data.filter(is_deleted=False)
        
        return super().to_representation(data)

class CompanySerializer(serializers.ModelSerializer):
    """ Company Model Serializer"""
    party_name_percentage_share = serializers.SerializerMethodField() # For Tender Dynamic Share details 

    def get_party_name_percentage_share(self, instance):
        if instance.name:
            details = instance.name
            return details
        else:
            return ""
        

    class Meta:
        model = Company
        fields = '__all__'


class EmployeementypeSerializer(serializers.ModelSerializer):
    """ Employee Type Model Serializer"""

    class Meta:
        model = UserType
        fields = '__all__'


class DesignationSerializer(serializers.ModelSerializer):
    """ Role Model Serializer"""

    class Meta:
        model = Role
        fields = '__all__'


class DepartmentSerializer(serializers.ModelSerializer):
    """ Department Model Serializer"""

    department_head_name = serializers.SerializerMethodField()

    class Meta:
        model = Department
        fields = '__all__'
  
    def get_department_head_name(self, instance):
        if instance.department_head_id:
            details = PmsUser.objects.filter(id=instance.department_head_id).first()
            return f"{details.first_name} {details.last_name}" if details else ""
        return ""
    




class OrganisationRoleSerializer(serializers.ModelSerializer):
    """ Organisation Role Model Serializer"""

    class Meta:
        model = Profile
        fields = '__all__'


class LoginLogoutSerializer(serializers.ModelSerializer):
    """ LoginLogout Model Serializer"""

    username = serializers.SerializerMethodField()

    def get_username(self, instance):
        if instance.user_id:
            details = PmsUser.objects.filter(id=instance.user_id).values('username', 'email', 'first_name',
                                                                         'last_name')
            return details
        else:
            return None

    class Meta:
        model = LoginLogoutLoggedTable
        fields = '__all__'


class MenuSerializer(serializers.ModelSerializer):
    """ Menu Serializer"""
    sub_menu_details = serializers.SerializerMethodField()
    form_details = serializers.SerializerMethodField()

    def get_sub_menu_details(self, instance):
        if instance.id:
            details = SubMenuMaster.cmobjects.filter(
                menu_id=instance.id).values()
            return details
        else:
            return None

    def get_form_details(self, instance):
        if instance.id:
            details = FormMenuMaster.cmobjects.filter(
                menu_id=instance.id, is_display=True).values()
            return details
        else:
            return None

    class Meta:
        model = MenuMaster
        fields = "__all__"


class AdministrativeMasterSerializer(serializers.ModelSerializer):
    """ AdministrativeMaster Model Serializer"""

    class Meta:
        model = AdministrativeMaster
        fields = '__all__'


class ModuleMasterSerializer(serializers.ModelSerializer):
    """ ModuleMaster Model Serializer"""

    class Meta:
        model = ModulePermissionsMaster
        fields = '__all__'


class SettingsMasterSerializer(serializers.ModelSerializer):
    """ SettingsMaster Model Serializer"""

    class Meta:
        model = SettingsMaster
        fields = '__all__'


class FormMenuMasterSerializer(serializers.ModelSerializer):
    """ FormMenuMaster Model Serializer"""
    button_name = serializers.SerializerMethodField()
    form_name = serializers.SerializerMethodField()
    is_active = serializers.SerializerMethodField()
    is_deactive = serializers.SerializerMethodField()


    def get_is_active(self, instance):
        tender_id = self.context.get("tender_id", None)
        if tender_id:
            from tender.models import TenderMaster
            tender_details = TenderMaster.objects.filter(id=tender_id).first()
            if instance.form_type_name == 'tender_eligibility':
                is_active = True
            elif tender_details.is_percentage_share_active == True and instance.form_type_name == 'percentage_share_analytics':
                is_active = True
            elif tender_details.is_compliance_active == True and instance.form_type_name == 'tender_compliances':
                is_active = True
            elif tender_details.is_executive_summary_active == True and instance.form_type_name == 'tender_executive_summary':
                is_active = True
            elif tender_details.is_approval_active == True and instance.form_type_name == 'tender_executive_commitee':
                is_active = True
            elif tender_details.is_assignment_active == True and instance.form_type_name == 'tender_pre_feasibility_assignments':
                is_active = True
            elif tender_details.is_survey_active == True and instance.form_type_name == 'tender_survey_details':
                is_active = True
            elif tender_details.is_top_sheet_active == True and instance.form_type_name == 'tender_top_sheet':
                is_active = True
            elif tender_details.is_final_approval_active == True and instance.form_type_name == 'tender_final_approval':
                is_active = True
            elif tender_details.is_submission_active == True and instance.form_type_name == 'tender_submission_status':
                is_active = True
            elif tender_details.is_technical_open_active == True and instance.form_type_name == 'tender_open_status':
                is_active = True
            elif tender_details.is_evaluation_active == True and instance.form_type_name == 'tender_evaluation_status':
                is_active = True
            elif tender_details.is_lmpi_active == True and instance.form_type_name == 'tender_lmpi_group':
                is_active = True
            elif tender_details.is_l1 == True and instance.form_type_name == 'tender_l1_selection':
                is_active = True
            elif tender_details.is_not_l1 == True and instance.form_type_name == 'tender_l1_not_selected':
                is_active = True
            else:
                is_active = False
        else:
            if instance.form_type_name == 'tender_eligibility':
                is_active = True
            else:
                is_active = False
        
        return is_active


    def get_is_deactive(self, instance):
        tender_id = self.context.get("tender_id", None)
        if tender_id:
            from tender.models import TenderMaster
            tender_details = TenderMaster.objects.filter(id=tender_id).first()
            if tender_details.is_eligibility_complete == True and \
                tender_details.is_eligibility_complete_for_proposer == True and instance.form_type_name == 'tender_eligibility':
                is_active = True
            elif tender_details.is_percentage_share_complete == True and instance.form_type_name == 'percentage_share_analytics':
                is_active = True
            elif tender_details.is_compliance_complete == True and instance.form_type_name == 'tender_compliances':
                is_active = True
            elif tender_details.is_executive_summary_complete == True and instance.form_type_name == 'tender_executive_summary':
                is_active = True
            elif tender_details.is_vga_approved == True and instance.form_type_name == 'tender_executive_commitee':
                is_active = True
            elif tender_details.is_assignment_complete == True and instance.form_type_name == 'tender_pre_feasibility_assignments':
                is_active = True
            elif tender_details.is_survey_complete == True and instance.form_type_name == 'tender_survey_details':
                is_active = True
            elif tender_details.is_top_sheet_complete == True and instance.form_type_name == 'tender_top_sheet':
                is_active = True
            elif tender_details.is_approved == True and instance.form_type_name == 'tender_final_approval':
                is_active = True
            elif tender_details.is_submission_complete == True and instance.form_type_name == 'tender_submission_status':
                is_active = True
            elif tender_details.is_technical_open_complete == True and instance.form_type_name == 'tender_open_status':
                is_active = True
            elif tender_details.is_evaluation_complete == True and instance.form_type_name == 'tender_evaluation_status':
                is_active = True
            elif tender_details.is_lmpi_complete == True and instance.form_type_name == 'tender_lmpi_group':
                is_active = True
            elif tender_details.is_l1_complete == True and instance.form_type_name == 'tender_l1_selection':
                is_active = True
            elif tender_details.is_not_l1_complete == True and instance.form_type_name == 'tender_l1_not_selected':
                is_active = True
            else:
                is_active = False
        else:
            is_active = False
        return is_active


    def get_form_name(self, instance):
        tender_id = self.context.get("tender_id", None)
        if tender_id:
            from tender.models import TenderMaster
            tender_details = TenderMaster.objects.filter(id=tender_id).first()
            if tender_details.is_approved == True and instance.form_type_name == 'tender_final_approval':
                name = "Tender Approved"
            elif tender_details.is_reject == True and instance.form_type_name == 'tender_final_approval':
                name = "Tender Rejected"
            elif tender_details.is_sent_for_final_approval == True and instance.form_type_name == 'tender_final_approval':
                name = "Awaiting Final Approval From Executive Commitee"
            elif tender_details.is_vga_approved == True and instance.form_type_name == 'tender_executive_commitee':
                name = "Tender VGA Done"
            elif tender_details.is_vga_reject == True and instance.form_type_name == 'tender_executive_commitee':
                name = "Tender VGA Rejected"
            elif tender_details.is_sent_for_approval == True and instance.form_type_name == 'tender_executive_commitee':
                name = "Awaiting VGA Approval From Executive Commitee"
            else:
                name = instance.form_name
        else:
            name = instance.form_name

        return name


    def get_button_name(self, instance):
        max = self.context.get("max_s", 0)
        if int(max) == int(instance.sort_order):
            return "Submit"
        else:
            return "Next"

    class Meta:
        model = FormMenuMaster
        fields = '__all__'


class FormMenuMasterForPlanningSerializer(serializers.ModelSerializer):
    """ FormMenuMaster Model Serializer"""
    button_name = serializers.SerializerMethodField()


    def get_button_name(self, instance):
        max = self.context.get("max_s", 0)
        if float(max) == float(instance.sort_order):
            return "Submit"
        else:
            return "Next"

    class Meta:
        model = FormMenuMaster
        fields = '__all__'


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(required=False, allow_blank=True)
    otp = serializers.CharField(required=False, allow_blank=True)
    device_id = serializers.CharField(required=False, allow_blank=True)
    ip = serializers.CharField(required=False, allow_blank=True)
    def validate(self, data):
        if not data.get('password') and not data.get('otp'):
            raise serializers.ValidationError("Either 'password' or 'otp' is required.")
        device_id = data.get('device_id', None)
        ip = data.get('ip', None)
        if not device_id and bool(int(str(os.getenv('IP_CHECK','0')))):
            if not AllowedIP.cmobjects.filter(ip_address=ip, is_active=True).exists():
                raise PermissionDenied(f'Unauthorized Access Requested IP: {ip}')
        user = None
        if data.get('password'):
            user = authenticate(
                username=data['username'], password=data['password'], active_check=True)
        if data.get('otp'):
            user_hotp = UserOTP.cmobjects.filter(user__username=data['username'],is_used=False,expiry__gt=datetime.now()).order_by('-expiry').first()
            if user_hotp:
                hotp = pyotp.HOTP(user_hotp.otp_secret,digits=int(os.getenv('OTP_LENGTH', '6')))
                otp_rand = int(os.getenv('OTP_RAND', '1234'))
                if hotp.verify(data['otp'],otp_rand):
                    user = user_hotp.user
                    user_hotp.is_used = True
                    user_hotp.save()
                else:
                    raise PermissionDenied('Invalid OTP!')
            else:
                raise APIException('Invalid Action!')
        if user is not None:
            if user.is_active:
                # if data.get('password') and user.is_allow_two_factor:
                #     send_login_otp(user)
                #     return Response({'success': 'We have sent you an OTP to your email id'}, status=status.HTTP_200_OK)
                
                # if device_id:
                #     if not user.is_allow_multiple_device:
                #         x = UserDeviceToken.cmobjects.filter(user_id=user.id,is_active=True)
                #         if x.count() > 0 and (not x.filter(token=device_id).exists()):
                #             raise APIException("Unauthorized login attempt from a different device!")
                #     UserDeviceToken.cmobjects.update_or_create(user=user,token=device_id, defaults={'is_active':True})  
                return user
            else:
                raise APIException('The account has been disabled!')
        else:
            raise APIException('Please check the credentials!')


'''
    #END
'''


class SendPasswordLinkSerializer(serializers.Serializer):
    """@vivek jaiswal
      Send reset password link serializer"""
    email = serializers.EmailField(max_length=100)

    class Meta:
        model = PmsUser
        fields = ['email']


class SetNewPasswordSerializer(serializers.Serializer):
    """ @vivek jaiswal 
    Set a new password serializer after email and token validation"""
    password = serializers.CharField(
        min_length=8, max_length=50, write_only=True)
    password2 = serializers.CharField(
        min_length=8, max_length=50, write_only=True)
    token = serializers.CharField(
        min_length=1, write_only=True)
    uidb64 = serializers.CharField(
        min_length=1, write_only=True)

    class Meta:
        fields = ['password', 'password2', 'token', 'uidb64']

    def validate(self, attrs):
        password = attrs.get('password')
        password2 = attrs.get('password2')
        if password != password2:
            raise serializers.ValidationError(
                {"error": "password and confirm password doesn't match"})

        try:
            password = attrs.get('password')
            token = attrs.get('token')
            uidb64 = attrs.get('uidb64')

            id = force_str(urlsafe_base64_decode(uidb64))
            user = PmsUser.objects.get(id=id)

            if not PasswordResetTokenGenerator().check_token(user, token):
                raise AuthenticationFailed(
                    {'msg': 'The reset link is invalid'}, 401)

            user.set_password(password)
            user.password_expiry_date=password_expiry_date_reset()
            user.save()
            return (user)

        except Exception as e:

            raise AuthenticationFailed(
                {'msg': 'The reset link is invalid'}, 401)
        return super().validate(attrs)


# class CompanyWiseRoleTreeSerializer(serializers.Serializer):
#     """ Company Wise Role Tree View serializer  """

#     role_tree_details = serializers.SerializerMethodField()


#     def get_role_tree_details(self,instance):
        # from .utils import get_node
        # if instance.id:
        #     roles = Role.cmobjects.filter(company_id=instance.id, \
        #                                 organization_id=instance.organization_id)
        #     role_dict = {}

        #     for role in roles:
        #         role_dict[role.id] = role

        #     child_roles_dict = {}
        #     for role in roles:
        #         parent_id = role.parent_id
        #         if parent_id in child_roles_dict:
        #             child_roles_dict[parent_id].append(role.id)
        #         else:
        #             child_roles_dict[parent_id] = [role.id]

        #     tree = []
        #     for role in roles:
        #         if role.parent_id == 0:
        #             node = get_node(role, role_dict, child_roles_dict)
        #             tree.append(node)

        #     return tree

        # else:
        #     return None
#     class Meta:
#         model=Company
#         fields = ['id', 'name','role_tree_details']


class CompanyWiseRoleTreeSerializer(serializers.ModelSerializer):
    """ Menu Serializer"""
    role_tree_details = serializers.SerializerMethodField()
    # form_details = serializers.SerializerMethodField()

    def get_role_tree_details(self, instance):
        from .utils import get_node
        if instance.id:
            roles = Role.cmobjects.filter(company_id=instance.id,
                                          organization_id=instance.organization_id)
            role_dict = {}

            for role in roles:
                role_dict[role.id] = role

            child_roles_dict = {}
            for role in roles:
                parent_id = role.parent_id
                if parent_id in child_roles_dict:
                    child_roles_dict[parent_id].append(role.id)
                else:
                    child_roles_dict[parent_id] = [role.id]

            tree = []
            for role in roles:
                if role.parent_id == 0:
                    node = get_node(role, role_dict, child_roles_dict)
                    tree.append(node)

            return tree

        else:
            return None

    # def get_form_details(self,instance):
    #     if instance.id:
    #         details = FormMenuMaster.objects.filter(menu_id=instance.id).values()
    #         return details
    #     else:
    #         return None

    class Meta:
        model = Company
        fields = "__all__"


class SettingsGroupMasterSerializer(serializers.ModelSerializer):
    """
        Settings Group masterb API
    """

    settings_details = serializers.SerializerMethodField()
    icon_image = serializers.SerializerMethodField()

    def get_settings_details(self, instance):

        if instance.id:
            settings_for = self.context['settings_for']
            settings_details = SettingsMaster.cmobjects.filter(Q(settings_group_id=instance.id),
                                                               Q(settings_for=settings_for) | Q(settings_for='Universal')).order_by('ordering', 'name', '-id').values()
            return settings_details
        else:
            return None

    def get_icon_image(self, instance):
        if instance.icon_image:
            self.request = self.context.get('request')
            current_host = self.request.get_host()
            protocol = 'http' if settings.DEBUG or self.request.is_secure() or current_host.startswith(
                'localhost') else 'https'

            dynamic_url_value = f"{protocol}://{current_host}"
            image_url = f"{dynamic_url_value}/media/" + \
                str(instance.icon_image)
        else:
            image_url = ""

        return image_url

    class Meta:
        model = SettingsGroupMaster
        fields = '__all__'


class NewJoinerSerializer(serializers.ModelSerializer):
    designation = serializers.SerializerMethodField()
    department = serializers.CharField(source='department.department')

    class Meta:
        model = PmsUser
        fields = ['id', 'first_name', 'last_name',
                  'joining_date', 'designation', 'department', 'image']

    def get_designation(self, obj):
        if obj.designation:
            return obj.designation.designation
        return None
    
class NoticeBoardSerializer(serializers.ModelSerializer):
    class Meta:
        model = NoticeBoard
        fields = '__all__'

class JVMASTERFinancialDetailsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    financial_year_details = serializers.SerializerMethodField()
    def get_financial_year_details(self, instance):
        return get_details_from_instance(instance.financial_year)
        # return get_details_from_instance(instance.financial_year, type="dict")
    
    class Meta:
        model = JVMASTERFinancialDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class JVMASTERWorkExperienceCategoryMasterSerializer(serializers.ModelSerializer):
    class Meta:
        model = JVMASTERWorkExperienceCategoryMaster
        fields = '__all__'

class JVMASTERWorkExperienceSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    working_category_details = serializers.SerializerMethodField()

    def get_working_category_details(self, instance):
        return get_details_from_instance(instance.working_category)

    class Meta:
        model = JVMASTERWorkExperience
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class JVMASTERDocumentSerializer(serializers.ModelSerializer):
    """ Serializer for JVMASTERDocument model """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = JVMASTERDocument
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class JVMASTERSerializer(serializers.ModelSerializer):
    """ JVMASTER Model Serializer """
    party_name_percentage_share = serializers.SerializerMethodField()
    financial_details = JVMASTERFinancialDetailsSerializer(many=True, required=False, source="jv_master_financial_details")
    work_experience = JVMASTERWorkExperienceSerializer(many=True, source="jv_master_work_experience")
    attachments = JVMASTERDocumentSerializer(many=True, source="jv_master_document")

    def get_party_name_percentage_share(self, instance):
        return instance.party_name if instance.party_name else ""
    
    def create(self, validated_data):
        financial_details_data = validated_data.pop("jv_master_financial_details", [])
        work_experience_data = validated_data.pop("jv_master_work_experience", [])
        attachments_data = validated_data.pop("jv_master_document", [])

        instance = JVMASTER.objects.create(**validated_data)
        current_user = instance.created_by if instance.created_by else None

        for fd in financial_details_data:
            JVMASTERFinancialDetails.objects.create(jv_master=instance, **fd)
        for we in work_experience_data:
            JVMASTERWorkExperience.objects.create(jv_master=instance, **we)

        for att in attachments_data:
            JVMASTERDocument.objects.create(
                organization=instance.organization,
                jv_master=instance,
                created_by=current_user,
                attachment=process_attachments(att),
                file_name=att.get("file_name"),
                mime_type=att.get("mime_type", ""),
                file_data=att.get("file_data", ""),
                bifurcation=att.get("bifurcation", ""),
            )   
        return instance
    
    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by or None

        # Financial Details --
        financial_details_data = validated_data.get("jv_master_financial_details", [])
        existing_financial_details = instance.jv_master_financial_details.filter(is_deleted=False)
        for item_data in financial_details_data:
            item_id = item_data.get("id")
            existing_item = next((item for item in existing_financial_details if item.id == item_id), None)
            print("existing_item ", existing_item)
            if not existing_item:
                existing_item = JVMASTERFinancialDetails.objects.create(jv_master=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        # Delete records not in payload
        for existing_item in existing_financial_details:
            if existing_item.id not in [data.get('id') for data in financial_details_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        # Work Experience ---
        work_experience_data = validated_data.get("jv_master_work_experience", [])
        existing_work_experience = instance.jv_master_work_experience.filter(is_deleted=False)
        for item_data in work_experience_data:
            item_id = item_data.get("id")
            existing_item = next((item for item in existing_work_experience if item.id == item_id), None)
            if not existing_item:
                JVMASTERWorkExperience.objects.create(
                    jv_master=instance, created_by=current_user, **item_data
                )
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                existing_item.updated_by = current_user
                existing_item.save()
        # Delete records not in payload
        for existing_item in existing_work_experience:
            if existing_item.id not in [data.get('id') for data in work_experience_data]:
                existing_item.is_deleted = True
                existing_item.updated_by = current_user
                existing_item.save()

        # attachement ---
        attachments_data = validated_data.get('jv_master_document', [])
        existing_attachments = instance.jv_master_document.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = JVMASTERDocument.objects.create(
                        organization=instance.organization,
                        jv_master=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="",
                        file_name=attachment_data.get('file_name', None),
                        created_by=current_user,
                        bifurcation=attachment_data.get("bifurcation", ""),
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'file_name', attachment_data.get('file_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                setattr(existing_attachment, 'bifurcation', attachment_data.get("bifurcation", ""))
                existing_attachment.save()

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation["financial_details"] = representation.pop("financial_details", [])
        representation["work_experience"] = representation.pop("work_experience", [])
        return representation
    
    class Meta:
        model = JVMASTER
        fields = '__all__'


















class STANDALONEMASTERSerializer(serializers.ModelSerializer):
    """ STANDALONEMASTER Model Serializer"""

    class Meta:
        model = STANDALONEMASTER
        fields = '__all__'


class EMPLOYEEMASTERSerializer(serializers.ModelSerializer):
    """ EMPLOYEEMASTER Model Serializer"""

    class Meta:
        model = EMPLOYEEMASTER
        fields = '__all__'


class NotificationMasterSerializer(serializers.ModelSerializer):
    """ NotificationMaster Model Serializer"""

    class Meta:
        model = NotificationMaster
        fields = '__all__'



class DelayReasonSerializer(serializers.ModelSerializer):
    """ Delay Reason Model Serializer"""
    obligations = serializers.SerializerMethodField()
    breakup_details = serializers.SerializerMethodField()

    def get_obligations(self, instance):
        if instance.obligations:
            ob_list =  list(instance.obligations.all().values_list('obligations', flat=True))
            ob_str = '/'.join(ob_list)
            return ob_str
        else:
            return ""
        
    def get_breakup_details(self, instance):
        breakup_list = DelayBreakUps.cmobjects.filter(delay_id=instance.id).values('name', 'id')
        return breakup_list

    class Meta:
        model = DelayReasons
        fields = '__all__'


class PmsUserSerializer(serializers.ModelSerializer):
    """ PmsUser Model Serializer"""

    class Meta:
        model = PmsUser
        fields = '__all__'


class HolidaySerializer(serializers.ModelSerializer):
    """ Holiday Model Serializer"""

    class Meta:
        model = Holiday
        fields = '__all__'        


        