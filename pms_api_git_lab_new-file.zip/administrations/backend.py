
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.models import User
from django.db.models import Q
from django.contrib.auth.backends import ModelBackend

from .models import *

class EmailBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        try:
            user = PmsUser.objects.get(Q(username__iexact=username) | Q(email__iexact=username))
        except PmsUser.DoesNotExist:
            PmsUser().set_password(password)
            return
        except PmsUser.MultipleObjectsReturned:
            user = PmsUser.objects.filter(Q(username__iexact=username) | Q(email__iexact=username)).order_by('id').first()

        if user.check_password(password) and self.user_can_authenticate(user):
            return user