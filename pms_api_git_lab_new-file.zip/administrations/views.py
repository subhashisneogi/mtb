import smtplib

import colorama
from django.conf import settings

from user_profile.serializers import *
from user_profile.models import *
# from .models import *
# from rest_framework.permissions import AllowAny
from django.contrib.auth import login
from knox.views import LoginView as KnoxLoginView
from knox.models import AuthToken
# from rest_framework import permissions
from knox.auth import TokenAuthentication
import collections
from django.db.models import Prefetch
from django.db.models import Count
# from django.shortcuts import render
from rest_framework.views import APIView
# from rest_framework import status
# from django.db import transaction
# permission checking
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from rest_framework.response import Response
from procurement.models import FinancialYear

""" @vivek jaiswal
send unique link(with unique token and uidb64) to user for rest password
"""

# from django.contrib.auth.tokens import default_token_generator
# from django.http import HttpResponseRedirect
#
# from django.utils.encoding import force_bytes
# from django.template import loader
# from django.contrib.auth.tokens import PasswordResetTokenGenerator
# from django.utils.encoding import smart_str, force_str, smart_bytes, DjangoUnicodeDecodeError
# from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
# from django.contrib.sites.shortcuts import get_current_site
from django.core.paginator import Paginator
# from django.urls import reverse
from administrations.utils import *
# from django.shortcuts import redirect
# from django.http import HttpResponsePermanentRedirect
from datetime import date, timedelta
# import os
from .serializers import *
from procurement.helper import custom_filters
from administrations.utils import create_dependent_formvalues_on_master_crud_operations,detectBrowser,send_login_otp
'''
    New Token Authentication [knox] 
    Reason : Multiple token generated every time on login and store on Knox Auth Token Table as digest
    Author : Niladry Kar 
    Date : [09.02.2023] 
'''
# from AuthTokenSerializer import *

from django.conf import settings
from colorama import Fore, Back, Style
import pprint
pp = pprint.PrettyPrinter(indent=2)

from django.db.models import Value as V
from django.db.models.functions import Concat
# Create your views here.


class LoginView(KnoxLoginView):
    permission_classes = (AllowAny,)

    # serializer_class = LoginSerializer

    def post(self, request, *args, **kwargs):
        request = detectBrowser(request)
        if 'id' in request.data:
            user = User.objects.get(pk=request.data['id'])
            odict = self.getUserDetails(user, request)
            return Response(odict)

        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data
        update_last_login(None, user)

        login_data = login(request, user)
        if user:
            odict = self.getUserDetails(user, request)
            return Response(odict)

    def getUserDetails(self, user, request):
        applications = self.getApplicationsDetails(request, user)
        profile_pic = ''
        user_details = UserProfile.objects.filter(user=user).first()
        try:
            if user_details:
                if user_details.image:
                    with user_details.image.open('rb') as opened_file:
                        file_content = opened_file.read()
                    profile_pic = 'data:image/png;base64,'+base64.b64encode(file_content).decode('utf-8')
        except Exception as e:
            print(e)
        odict = collections.OrderedDict()

        odict['user_id'] = user.pk
        odict['token'] = AuthToken.objects.create(user)[1]
        odict['username'] = user.username
        odict['first_name'] = user.first_name
        odict['last_name'] = user.last_name
        odict['email'] = user.email
        odict['is_admin'] = user.is_superuser
        odict['aadhar_number'] = user.aadhar_number if user.aadhar_number else None
        odict['pan_number'] = user.pan_number if user.pan_number else None
        odict['gender'] = user.gender if user.gender else None
        odict['blood_group'] = user.blood_group if user.blood_group else None
        odict['is_superuser'] = user.is_superuser
        odict['cu_phone_no'] = user_details.phone_no if user_details else ""
        odict['cu_profile_img'] = profile_pic
        odict['request_status'] = 1
        odict['msg'] = "Logged in successfully .."
        odict['switchUser'] = ''
        odict['password_expiry_date'] = user.password_expiry_date
        odict['login_mode'] = 'normal' if request.data.get('password') else 'otp'
        # odict['organisation_details'] = Organization.objects.filter(
        #     id=user.organization_id).values()
        odict['organisation_details'] = Organization.objects.filter(
            id=user.organization_id
        ).annotate(
            address=Concat(
                'org_city__name', V(', '), 'org_state__name', V(', '), 'org_country__name',
                output_field=models.CharField()
            )
        ).values()
        odict['organisation_attachments'] = []
        try:
            organisation_files = OrganizationAttachment.objects.filter(organization_id=user.organization_id).all()
            for organisation_file in organisation_files:
                if organisation_file.image:
                    with organisation_file.image.open('rb') as opened_file:
                        file_content = opened_file.read()
                    odict['organisation_attachments'].append({
                        'name': organisation_file.name,
                        'image': 'data:image/png;base64,'+base64.b64encode(file_content).decode('utf-8')
                    })
        except Exception as e:
            print(e)
        odict['zone_details'] = Zone.objects.filter(
            id=user.zone_id).values() if user.zone_id else ""
        odict['company_details'] = Company.objects.filter(
            id=user.company_name_id).values() if user.company_name_id else ""
        odict['designation_details'] = Role.objects.filter(
            id=user.designation_id).values() if user.designation_id else ""
        odict['department_details'] = Role.objects.filter(
            id=user.department_id).values() if user.department_id else ""
        odict['user_role_details'] = applications

        odict['country'] = Country.objects.filter(
            id=user.country_id).values() if user.country_id else ""
        odict['state'] = State.objects.filter(
            state_id=user.state_id).values() if user.state_id else ""
        odict['city'] = City.objects.filter(
            city_id=user.city_id).values() if user.city_id else ""
        today = date.today()
        odict['financial_year'] = FinancialYear.cmobjects.filter(start_date__lte=today,end_date__gte=today).values()
        odict['vendor_currency'] = VendorCurrencyMaster.cmobjects.filter(is_default=True).values()

        odict['user_permissions'] = list(UserWiseModulePermissions.cmobjects.filter(user=user, level_permission=True).values_list('module_item__unique_id', flat=True))

        odict['hrms_login'] = None
        try:
            if bool(int(str(os.getenv('HRMS_SYNC','0')))):
                odict['hrms_login'] = hrms_login_request(request.user.username)
        except Exception as e:
            print('ERROR', e)

        log = LoginLogoutLoggedTable.objects.create(
            user=user, token=odict['token'], ip_address=request.data['ip'], browser_name=request.data['browser'], os_name=request.data['os_name'])

        # print('log',log)
        return odict

    def getApplicationsDetails(self, request, user):
        """ Function To Get User Roles and Permission Data"""
        from user_profile.serializers import RoleUserWiseSerilizer

        user_details = PmsUser.objects.filter(id=user.id).first()

        serializer = RoleUserWiseSerilizer(user_details)

        return serializer.data


class LogoutView(APIView):
    
    

    '''
    Changes made by Niladry Kar 
    Response edited as per requirements 
    '''

    def get(self, request, format=None):
        import datetime
        device_id = request.query_params.get('device_id', None)
        token = request.META.get('HTTP_AUTHORIZATION').replace('Token ', '')
        LoginLogoutLoggedTable.objects.filter(
            user=request.user, token=token).update(
            logout_time=datetime.datetime.now())
        
        request._auth.delete()
        UserDeviceToken.cmobjects.filter(user=request.user,token=device_id).update(is_active=False) 
        GCMDevice.objects.filter(user=request.user,application_id=device_id).update(active=False) 

        return Response({'request_status': 1, 'msg': "Logout Success..."}, status=status.HTTP_200_OK)


class UserValidateView(APIView):
    
    
    def get(self, request, format=None):
        resp = None
        try:
            resp = PmsUser.objects.filter(id=request.user.id).values()
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        return Response(resp)


class AutoLogoutView(APIView):
    permission_classes = (AllowAny,)
    def get(self, request, pk, format=None):
        # from knox.models import AuthToken
        try:
            if pk == 0:
                AuthToken.objects.all().delete()
            else:
                AuthToken.objects.filter(user_id=pk).delete()
            return Response({'request_status': 1, 'msg': "Auto Logout Success..."})
        except Exception as e:
            print(e)
            APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class RequestOTPAPIView(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, *args, **kwargs):
        username = request.data['username']
        user = PmsUser.objects.filter(username=username,is_allow_otp_login=True).first()
        if user:
            send_login_otp(user)
        else:
            raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
        return Response({'success': 'We have sent you an OTP to your email id'},
                            status=status.HTTP_200_OK)


class SendResetPasswordLinkAPIView(APIView):
    """ @Vivek Jaiswal
        End point to send reset password link(token with uidb64) to valid user
    """
    permission_classes = (AllowAny,)
    serializer_class = SendPasswordLinkSerializer

    def post(self, request):
        email = request.data.get('email', '')

        if PmsUser.objects.filter(email=email).exists():
            """if your email id is existing get the query of your specific email id """
            user = PmsUser.objects.get(email=email)
            uidb64 = urlsafe_base64_encode(smart_bytes(user.id))
            token = PasswordResetTokenGenerator().make_token(user)
            token_expiry_time=human_time(settings.PASSWORD_RESET_TIMEOUT)
            absurl = str(os.getenv('FE_FORGET_PASSWORD',''))+uidb64 + "/" + token
         
            temp = trigger_notifications(action='RESET-PASSWORD', user_list=[user.id], context={'reset_link': absurl,'user_full_name':user.user_full_name,'token_expiry_time':token_expiry_time})
            if temp:
                if 'email' in temp:
                    if not temp['email'].is_sent:
                        result = send_generic_mail(temp['email'])
                        if result:
                            temp['email'].is_sent = True
                        temp['email'].tried_count = temp['email'].tried_count + 1
                        temp['email'].save()
            # schedule_generic_mail(subject='Reset your passsword', to_mail_list=[user.email], context={'reset_link': absurl}, template_name='RESET-PASSWORD')
            return Response({'success': 'We have sent you a link to your email id to reset password'},
                            status=status.HTTP_200_OK)
        else:
            return Response({'message': 'Email id does not exist, Please re-enter valid email id',
                             }, status=status.HTTP_400_BAD_REQUEST)


class PasswordTokenCheckApi(APIView):
    permission_classes = (AllowAny,)
    """@vivek jaiswal
    validate token and uidb64 for particular user
    """

    def get(self, request, uidb64, token):

        try:
            id = smart_str(urlsafe_base64_decode(uidb64))
            user = PmsUser.objects.get(id=id)
            if not PasswordResetTokenGenerator().check_token(user, token):
                return Response({'error': 'Token is not valid,please request new one'},
                                status=status.HTTP_401_UNAUTHORIZED)
            return Response({'success': True, 'message': 'Credential is valid',
                             'uidb64': uidb64, 'token': token},
                            status=status.HTTP_200_OK)

        except DjangoUnicodeDecodeError as identifier:
            if not PasswordResetTokenGenerator().check_token(user):
                return Response({'error': 'Token is not valid, please request a new one'},
                                status=status.HTTP_400_BAD_REQUEST)


class SetNewPassWordAPIView(APIView):
    """ @vivek jaiswal
    Set a new password 
    """
    permission_classes = (AllowAny,)
    serializer_class = SetNewPasswordSerializer

    def put(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)

        return Response({'success': True, "message": "Password reset successfully!"},
                        status=status.HTTP_200_OK)


class LoginLogoutAPIView(APIView):
    """
    API To Track LoginLogout Activity Of User
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all zones
        """
        user_id = self.request.query_params.get('user_id', None)

        log_list = LoginLogoutLoggedTable.objects.all().order_by('-id')

        if user_id:
            log_list = LoginLogoutLoggedTable.objects.filter(
                user_id=user_id).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(log_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = LoginLogoutSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


class CompanyAPIView(APIView):
    """  CRUD API for Company model """
    def get(self, request, format=None):
        """
        Get a list of all zones
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = {}
        has_permission = UserWiseModulePermissions.objects.filter(
            user=request.user,
            module_item__unique_id__in=['company-manager'],
            level_permission=True,
            is_deleted=False
        ).exists()
        if not has_permission:
            search = { 'users__in': [request.user] }
        search = custom_filters(self.request, search, [])
        if id:
            company = Company.cmobjects.filter(id=id).first()
            serializer = CompanySerializer(company)
            return Response(serializer.data)

        list_data = Company.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        print("list_data", list_data)
        if all == 'true':
            serializer = CompanySerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = CompanySerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request, format=None):
        """
        Create a new company
        """

        serializer = CompanySerializer(data=request.data)
        if Company.cmobjects.filter(name=request.data['name'].strip(),          
                                    organization=request.data['organization']).exists():
            raise APIException({'request_status': 0, 'msg': "Company name already exist"})

        if serializer.is_valid():
            serializer.save()
            company_id = serializer.data.get('id', None)
            role_create = Role.objects.create(parent_id=0, designation='Administration', organization_id=request.data['organization'],
                                              company_id=company_id)
            role_create.save()

            role_child = Role.objects.create(parent_id=role_create.id, designation='CEO', organization_id=request.data['organization'],
                                             company_id=company_id)
            role_child.save()

            return Response({'results': {
                'Data': serializer.data,
            },
                'msg': 'Successfully created company',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a company
                """
                if Company.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                    company = Company.cmobjects.get(pk=id)
                    old_name = company.name
                    if Company.cmobjects.filter(name=request.data['name'].strip(),          
                                                organization=request.data['organization']).exclude(\
                            name=company.name).exists():
                        raise APIException({'request_status': 0, 'msg': "Company name already exist"})

                    serializer = CompanySerializer(company, data=request.data)
                    if serializer.is_valid():
                        serializer.save()

                        from administrations.utils import create_dependent_formvalues_on_master_crud_operations, change_tender_percentage_analysis_company_data_on_master_change
                        create_dependent_formvalues_on_master_crud_operations('company', company.name, company.id)

                        change_tender_percentage_analysis_company_data_on_master_change(old_name, \
                                                                                        request.data.get('name', None), \
                                                                                            company.id)

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated company",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_400_BAD_REQUEST,
                                     "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a company
                """                
                if Company.cmobjects.filter(pk=id, organization=organization_id).exists():
                    company = Company.cmobjects.get(
                        pk=id, organization=organization_id)
                    company.is_deleted = True
                    company.save()

                    return Response({'results': {
                        'company': Company.objects.filter(pk=id, organization=organization_id).values(),
                    },
                        'msg': 'Sucessfully deleted',
                        'status': status.HTTP_202_ACCEPTED,
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})


class EmployeementypeAPIView(APIView):
    """
    CRUD API for Employeementype model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all Employeementype
        """
        id = self.request.query_params.get('id', None)
        if id:
            user_type = UserType.cmobjects.filter(id=id).first()
            serializer = EmployeementypeSerializer(user_type)
            return Response(serializer.data)

        organization_id = self.request.query_params.get(
            'organization_id', None)
        employeement_type = UserType.cmobjects.filter(
            organization_id=organization_id).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(employeement_type, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = EmployeementypeSerializer(page, many=True)
        # serializer = EmployeementypeSerializer(employeement_type, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Employeementype
        """
        serializer = EmployeementypeSerializer(data=request.data)
        if UserType.cmobjects.filter(user_type=request.data['user_type'].strip(),
                                     organization=request.data['organization']).exists():
            raise APIException({'request_status': 0, 'msg': "Employee Type already exist"})

        if serializer.is_valid():
            serializer.save()
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a company
                """
                if UserType.cmobjects.filter(pk=id,
                                             organization_id=organization_id).exists():

                    user_type_details = UserType.cmobjects.get(pk=id)

                    if UserType.cmobjects.filter(user_type=request.data['user_type'].strip(),
                                                 organization=request.data['organization']).exclude(
                            user_type=user_type_details.user_type).exists():
                        raise APIException({'request_status': 0, 'msg': "Employment Type already exist"})

                    serializer = EmployeementypeSerializer(
                        user_type_details, data=request.data)
                    if serializer.is_valid():
                        serializer.save()

                        from administrations.utils import create_dependent_formvalues_on_master_crud_operations
                        create_dependent_formvalues_on_master_crud_operations('employee_type', user_type_details.user_type, user_type_details.id)

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response(
                        {'results': {
                            'Data': serializer.errors,
                        },
                            'msg': "Something went wrong. If the problem persists, please contact support.",
                            'status': status.HTTP_400_BAD_REQUEST,
                            "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a UserType
                """
                if UserType.cmobjects.filter(pk=id, organization=organization_id).exists():
                    user_type = UserType.cmobjects.get(
                        pk=id, organization=organization_id)
                    user_type.is_deleted = True
                    user_type.save()

                    return Response({'results': {
                        'employee_type': UserType.objects.filter(pk=id, organization=organization_id).values(),
                    },
                        'msg': 'Successfully deleted user type',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})


class DesignationAPIView(APIView):
    """
    CRUD API for designation model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all designation
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)

        organization_id = self.request.query_params.get(
            'organization_id', None)
        designation = Role.cmobjects.filter(
            organization_id=organization_id).order_by('parent_id')

        company_id = self.request.query_params.get('company_id', None)
        edit = self.request.query_params.get('edit', None)

        if company_id:
            designation = Role.cmobjects.filter(organization_id=organization_id,
                                                company_id=company_id).order_by('parent_id')

        if edit == 'true' and id:
            designation = Role.cmobjects.filter(organization_id=organization_id,
                                                company_id=company_id, parent_id__lt=id).exclude(id=id).order_by('parent_id')

        if all == 'true':
            serializer = DesignationSerializer(designation, many=True)
            return Response({'results': serializer.data})

        elif id:
            designation = Role.cmobjects.filter(id=id).first()
            serializer = DesignationSerializer(designation)
            return Response(serializer.data)


        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(designation, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = DesignationSerializer(page, many=True)
        # serializer = DesignationSerializer(designation, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new designation
        """
        serializer = DesignationSerializer(data=request.data)
        if Role.cmobjects.filter(designation=request.data['designation'].strip(),  # validate existing desgination
                                 organization=request.data['organization'], company=request.data['company']).exists():
            raise APIException({'request_status': 0, 'msg': "Role already exist"})

        if serializer.is_valid():
            serializer.save()
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a company
                """

                if Role.cmobjects.filter(pk=id,
                                         organization_id=organization_id).exists():

                    designation_details = Role.cmobjects.get(pk=id)

                    if Role.cmobjects.filter(designation=request.data['designation'].strip(),  # validate existing desgination name
                                             organization=request.data['organization'], company=request.data['company']).exclude(\
                            designation=designation_details.designation).exists():
                        raise APIException({'request_status': 0, 'msg': "Role already exist"})

                    serializer = DesignationSerializer(
                        designation_details, data=request.data)
                    if serializer.is_valid():
                        serializer.save()

                        from administrations.utils import create_dependent_formvalues_on_master_crud_operations
                        create_dependent_formvalues_on_master_crud_operations('role', designation_details.designation, designation_details.id)

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated company",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response({'results': {
                        'Data': serializer.errors,
                    },
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})

            elif method.lower() == 'delete':
                """
                Delete a designation
                """
                with transaction.atomic():
                    if Role.cmobjects.filter(pk=id, organization=organization_id).exists():
                        designation = Role.cmobjects.get(
                            pk=id, organization=organization_id)
                        designation.is_deleted = True
                        j_designation_list = Role.cmobjects.filter(organization=organization_id,
                                                                   parent_id=designation.id)
                        for item in j_designation_list:
                            item.is_deleted = True
                            item.save()
                        designation.save()

                        return Response({'results': {
                            'designation': Role.objects.filter(pk=id, organization=organization_id).values(),
                        },
                            'msg': 'Successfully deleted the designation',
                            "request_status": 1})
                    else:
                        return Response({'results': [],
                                        'msg': "Selected Role Not Found",
                                         'status': status.HTTP_404_NOT_FOUND,
                                         "request_status": 0})


class DepartmentAPIView(APIView):
    """
    CRUD API for Department model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all role
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            roll = Department.cmobjects.filter(id=id).first()
            serializer = DepartmentSerializer(roll)
            return Response(serializer.data)
        search = {}
        for filters in self.request.query_params:
            if filters not in ['id', 'all', 'page_size', 'page'] and self.request.query_params.get(filters, None):
                search[filters] = self.request.query_params.get(filters, None)


        roll = Department.cmobjects.filter(**search).order_by('-id')

        if all == 'true':
            serializer = DepartmentSerializer(roll, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(roll, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = DepartmentSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Department
        """
        serializer = DepartmentSerializer(data=request.data)
        if Department.cmobjects.filter(department=request.data['department'].strip(),  # validate existing department
                                       organization=request.data['organization']).exists():
            raise APIException({'request_status': 0, 'msg': "Department already exist"})

        if serializer.is_valid():
            serializer.save()
            return Response({'results': {
                'Data': serializer.data,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a department
                """

                if Department.cmobjects.filter(pk=id,
                                               organization_id=organization_id).exists():

                    department_details = Department.cmobjects.get(pk=id)

                    if Department.cmobjects.filter(department=request.data['department'].strip(),  # validate existing department name
                                                   organization=request.data['organization']).exclude(\
                            department=department_details.department).exists():
                        raise APIException({'request_status': 0, 'msg': "Department already exist"})

                    serializer = DepartmentSerializer(
                        department_details, data=request.data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        create_dependent_formvalues_on_master_crud_operations('department', department_details.department, \
                                                                              department_details.id)
                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated department",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response({'results': {
                        'Data': serializer.errors,
                    },
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a Department
                """
                if Department.cmobjects.filter(pk=id, organization=organization_id).exists():
                    department = Department.cmobjects.get(
                        pk=id, organization=organization_id)
                    department.is_deleted = True
                    department.save()

                    return Response({'results': {
                        'department': Department.objects.filter(pk=id, organization=organization_id).values(),
                    },
                        'msg': 'Success',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})


class UserRoleAPIView(APIView):
    """
    CRUD API for organisation role model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all role
        """
        id = self.request.query_params.get('id', None)
        if id:
            role = Profile.cmobjects.filter(id=id).first()
            serializer = RoleSerilizer(role)
            return Response(serializer.data)

        organization_id = self.request.query_params.get(
            'organization_id', None)
        is_active = self.request.query_params.get('is_active', None)
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))

        if is_active:
            if is_active == "true":
                role = Profile.cmobjects.filter(organization_id=organization_id,
                                                is_active=True, permissions_added=True).order_by('-id')
            elif is_active == "false":
                role = Profile.cmobjects.filter(organization_id=organization_id,
                                                is_active=False, permissions_added=True).order_by('-id')
            else:
                role = Profile.cmobjects.filter(organization_id=organization_id,
                                                is_active=is_active, permissions_added=True).order_by('-id')

            paginator = Paginator(role, page_size)
            page_number = self.request.query_params.get('page', 1)
            page = paginator.get_page(page_number)
            serializer = RoleSerilizer(page, many=True)
            is_active_true_count = Profile.cmobjects.filter(
                organization_id=organization_id,
                is_active=True,
                permissions_added=True
            ).count()
            is_active_false_count = Profile.cmobjects.filter(
                organization_id=organization_id,
                is_active=False,
                permissions_added=True
            ).count()
            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': serializer.data,
                'is_active_true_count': is_active_true_count,
                'is_active_false_count': is_active_false_count
            })
        is_active_true_count = Profile.cmobjects.filter(
            organization_id=organization_id,
            is_active=True,
            permissions_added=True
        ).count()
        is_active_false_count = Profile.objects.filter(
            organization_id=organization_id,
            is_active=False,
            permissions_added=True
        ).count()
        role = Profile.cmobjects.filter(organization_id=organization_id,
                                        permissions_added=True).order_by('-id')
        paginator = Paginator(role, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = RoleSerilizer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
            'is_active_true_count': is_active_true_count,
            'is_active_false_count': is_active_false_count
        })

    def post(self, request, format=None):
        """
        Create a new role
        """
        serializer = OrganisationRoleSerializer(data=request.data)
        if Profile.cmobjects.filter(role_name=request.data['role_name'].strip(), organization=request.data['organization'], permissions_added=True).exists():
            raise APIException({'request_status': 0, 'msg': "Profile Name already exist"})

        if serializer.is_valid():

            serializer.save()
            return Response({'results': {
                'Data': serializer.data,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a organisation role model
                """

                if Profile.cmobjects.filter(pk=id,
                                            organization_id=organization_id).exists():

                    role = Profile.cmobjects.get(pk=id)

                    if Profile.cmobjects.filter(role_name=request.data['role_name'].strip(),
                                                organization=request.data['organization'], permissions_added=True).exclude(
                            role_name=role.role_name,).exists():
                        raise APIException({'request_status': 0, 'msg': "Profile Name already exist"})

                    serializer = OrganisationRoleSerializer(
                        role, data=request.data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': 'Successfully updated organisation role model',
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response({'results': {
                        'Data': serializer.errors,
                    },
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a Organisation role
                """
                if Profile.cmobjects.filter(pk=id, organization=organization_id).exists():
                    role = Profile.cmobjects.get(
                        pk=id, organization=organization_id)
                    role.is_deleted = True
                    role.save()

                    return Response({'results': {
                        'role': Profile.objects.filter(pk=id, organization=organization_id).values(),
                    },
                        'msg': 'Success',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})


class MenuListAPIView(APIView):
    """ Menu List API   """

    
    

    def get(self, request, format=None):
        """
        Get a list of all Menu List
        """
        show_module = request.query_params.get('shown', False)
        menu_list = MenuMaster.objects.filter(is_menu_show=True)

        if show_module == 'true':
            menu_list = MenuMaster.objects.filter(is_shown=True)

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(menu_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MenuSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


class FormMenuListAPIView(APIView):
    """ FormMenuMaster List API   """

    
    

    def get(self, request, format=None):
        """
        Get a list of all FormMenuMaster List
        """
        from custom_management.models import FormGroupMastr
        from tender.models import TenderData

        menu_id = self.request.query_params.get('menu_id', None)

        tender_id = self.request.query_params.get('tender_id', None)

        user_permissions_module_ids = list(UserWiseModulePermissions.objects.filter(user=request.user, \
                                                                                    level_permission=True).values_list('module_item_id', flat=True))

        frm_group_qs = FormGroupMastr.cmobjects.filter(organization_id = request.user.organization_id, \
                                                              permissible_user_types__in=user_permissions_module_ids).order_by('form_type').values('form_type').distinct()


        frm_group_list = [item['form_type'] for item in frm_group_qs]

        from custom_management.models import FormDependentChoices


        if tender_id:
            from tender.models import TenderMaster
            tender_l1_check = TenderData.cmobjects.filter(\
                form__form_internal_name="selected_as_l1", tender_id=tender_id).first()
            
            tender_data_form = TenderData.cmobjects.filter(form__form_internal_name='select_members',\
                                                       tender_id=tender_id).first()
            material_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_material',\
                                                    tender_id=tender_id).first()
    
            taxation_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_taxation',\
                                                    tender_id=tender_id).first()
    
            liason_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_liason',\
                                                    tender_id=tender_id).first()
    

            if tender_data_form:
                import ast
                form_ids = ast.literal_eval(tender_data_form.value)
                physical_user_ids = list(FormDependentChoices.cmobjects.filter(id__in=form_ids, \
                                                                    form__form_internal_name='select_members').values_list('option_id', flat=True))
            else:
                physical_user_ids = []

            if material_rate_data:
                import ast
                form_ids = ast.literal_eval(material_rate_data.value)
                material_user_ids = list(FormDependentChoices.cmobjects.filter(id__in=form_ids, \
                                                                    form__form_internal_name='select_members_material').values_list('option_id', flat=True))
            else:
                material_user_ids = []


            if taxation_rate_data:
                import ast
                form_ids = ast.literal_eval(taxation_rate_data.value)
                taxation_user_ids = list(FormDependentChoices.cmobjects.filter(id__in=form_ids, \
                                                                    form__form_internal_name='select_members_taxation').values_list('option_id', flat=True))
            else:
                taxation_user_ids = []

            if liason_rate_data:
                import ast
                form_ids = ast.literal_eval(liason_rate_data.value)
                liason_user_ids = list(FormDependentChoices.cmobjects.filter(id__in=form_ids, \
                                                                    form__form_internal_name='select_members_liason').values_list('option_id', flat=True))
            else:
                liason_user_ids = []

            if request.user.id in physical_user_ids:
                frm_group_list.append('tender_survey_details')

            if request.user.id in material_user_ids:
                frm_group_list.append('tender_survey_details')

            if request.user.id in taxation_user_ids:
                frm_group_list.append('tender_survey_details')

            if request.user.id in liason_user_ids:
                frm_group_list.append('tender_survey_details')
        else:
            tender_l1_check = None
        
        if menu_id:
            if tender_id and tender_l1_check:
                menu_master_obj = MenuMaster.cmobjects.get(pk=menu_id)
                if menu_master_obj.form_type_name == 'tender' and tender_l1_check.value == 'true':
                    menu_list = FormMenuMaster.objects.filter(
                        menu_id=menu_id,
                        is_display=True,
                        form_type_name__in=frm_group_list
                    ).exclude(
                        form_type_name='tender_l1_not_selected'
                    ).order_by('sort_order')
                
                elif menu_master_obj.form_type_name == 'tender' and tender_l1_check.value == 'false':
                    menu_list = FormMenuMaster.objects.filter(
                        menu_id=menu_id,
                        is_display=True,
                        form_type_name__in=frm_group_list
                    ).exclude(
                        form_type_name__in=['tender_l1_selection', 'tender_lmpi_group']
                    ).order_by('sort_order')
                else:
                    menu_list = FormMenuMaster.objects.filter(
                        menu_id=menu_id, is_display=True, \
                            form_type_name__in=frm_group_list).exclude(form_type_name__in=['tender_l1_selection', \
                                                                                        'tender_l1_not_selected']).order_by('sort_order')


            else:
                menu_list = FormMenuMaster.objects.filter(
                        menu_id=menu_id, is_display=True, \
                            form_type_name__in=frm_group_list).order_by('sort_order')

        else:
            menu_list = FormMenuMaster.objects.filter(is_display=True, \
                                                      form_type_name__in=frm_group_list).order_by('sort_order')

        from django.db.models import Max

        max_s = menu_list.aggregate(max_s = Max('sort_order'))['max_s']

        serializer = FormMenuMasterSerializer(menu_list, many=True, context = {"max_s": max_s, "tender_id" : tender_id})

        return Response({
            'results': serializer.data
        })
    

class FormMenuListForPlanningAPIView(APIView):
    """ FormMenuMaster List API For Planning"""

    
    

    def get(self, request, format=None):
        """
        Get a list of all FormMenuMaster List
        """
        from custom_management.models import FormGroupMastr
        from project_and_planning.models import ProjectMaster
        from tender.models import TenderData

        menu_id = self.request.query_params.get('menu_id', None)

        project_id = self.request.query_params.get('project_id', None)

        project_details = ProjectMaster.cmobjects.filter(id=project_id).first()

        is_jv_check = None

        if project_details:
            is_jv_check = TenderData.cmobjects.filter(tender_id=project_details.tender_id, \
                                                    form__form_internal_name='participations_mode', \
                                                        value='JV').first()

        user_permissions_module_ids = list(UserWiseModulePermissions.objects.filter(user=request.user, \
                                                                                    level_permission=True).values_list('module_item_id', flat=True))

        frm_group_list = list(FormGroupMastr.cmobjects.filter(organization_id = request.user.organization_id, \
                                                              permissible_user_types__in=user_permissions_module_ids).values_list('form_type', flat=True))

        
        if menu_id:
            # if is_jv_check:
            #     menu_list = FormMenuMaster.objects.filter(
            #                 menu_id=menu_id, is_display=True, \
            #                     form_type_name__in=frm_group_list).order_by('sort_order')
            # else:
            menu_list = FormMenuMaster.objects.filter(
                        menu_id=menu_id, is_display=True, \
                            form_type_name__in=frm_group_list).exclude(\
                                form_type_name='planning_jv_details').order_by('sort_order')
        else:
            menu_list = FormMenuMaster.objects.filter(is_display=True, \
                                                      form_type_name__in=frm_group_list).order_by('sort_order')

        from django.db.models import Max

        max_s = menu_list.aggregate(max_s = Max('sort_order'))['max_s']

        serializer = FormMenuMasterForPlanningSerializer(menu_list, many=True, context = {"max_s": max_s, "project_id" : project_id})

        return Response({
            'results': serializer.data
        })


class AdministrativeMasterListAPIView(APIView):
    """ Administrative Master List API   """

    
    

    def get(self, request, format=None):
        """
        Get a list of all Administrative Master
        """
        administrative_list = AdministrativeMaster.objects.all()
        serializer = AdministrativeMasterSerializer(
            administrative_list, many=True)
        return Response(serializer.data)
    

class ModuleMasterListAPIView(APIView):
    """ Module Master List API   """

    
    

    def get(self, request, format=None):
        """
        Get a list of all ModulePermissions Master
        """
        module_list = ModulePermissionsMaster.objects.all()
        serializer = ModuleMasterSerializer(
            module_list, many=True)
        return Response(serializer.data)


class SettingsMasterListAPIView(APIView):
    """ Settings Master List API   """

    
    

    def get(self, request, format=None):
        """
        Get a list of all Settings Master
        """
        setting_list = SettingsMaster.objects.all()
        serializer = SettingsMasterSerializer(setting_list, many=True)
        return Response(serializer.data)


class RolesPermissionCreate(APIView):
    
    

    def post(self, request, format=None):
        from user_permissions.models import UserPermissions, UserSubModulePermissions, UserAdministrativePermissions
        try:
            with transaction.atomic():
                for data in self.request.data:
                    organization_id = data.get('organization_id', None)
                    role_id = data.get('id', None)
                    menu_list = data.get('menu_list', None)
                    setting_list = data.get('setting_list', None)
                    administrative_list = data.get('administrative_list', None)
                    module_list = data.get('module_list', None)

                    role_details = Profile.objects.filter(id=role_id).first()

                    if UserPermissions.objects.filter(organization_id=organization_id, role=role_details).exists():
                        return Response({'request_status': 1, 'msg': 'Menu Permission For The Selected Role is Already Added'}, status=status.HTTP_400_BAD_REQUEST)

                    if UserSubModulePermissions.objects.filter(organization_id=organization_id, role=role_details).exists():
                        return Response({'request_status': 1, 'msg': 'Sub Menu Permission For The Selected Role is Already Added'}, status=status.HTTP_400_BAD_REQUEST)

                    if UserAdministrativePermissions.objects.filter(organization_id=organization_id, role=role_details).exists():
                        return Response({'request_status': 1, 'msg': 'Administrative Permission For The Selected Role is Already Added'}, status=status.HTTP_400_BAD_REQUEST)

                    if UserSettingsPermissions.objects.filter(organization_id=organization_id, role=role_details).exists():
                        return Response({'request_status': 1, 'msg': 'Settings For The Selected Role is Already Added'}, status=status.HTTP_400_BAD_REQUEST)
                    
                    if UserModulePermissions.objects.filter(organization_id=organization_id, role=role_details).exists():
                        return Response({'request_status': 1, 'msg': 'Module  For The Selected Role is Already Added'}, status=status.HTTP_400_BAD_REQUEST)

                    for item in menu_list:
                        menu_id = item.get('id', None)
                        menu_view = item.get('view', True)
                        menu_add = item.get('add', True)
                        menu_edit = item.get('edit', True)
                        menu_delete = item.get('delete', True)
                        menu_export = item.get('export', True)
                        menu_level_permission = item.get(
                            'level_permission', True)
                        sub_menu_list = item.get('sub_menu_list', None)

                        menu_perm_create = UserPermissions.objects.create(
                            organization_id=organization_id, role=role_details,
                            menu_id=menu_id, has_view_permission=menu_view, has_add_permission=menu_add,
                            has_edit_permission=menu_edit, has_delete_permission=menu_delete, has_export_permission=menu_export,
                            level_permission=menu_level_permission
                        )

                        menu_perm_create.save()

                        for obj in sub_menu_list:
                            sub_menu_id = obj.get('id', None)
                            view = obj.get('view', True)
                            add = obj.get('add', True)
                            edit = obj.get('edit', True)
                            delete = obj.get('delete', True)
                            level_permission = obj.get(
                                'level_permission', True)
                            export = obj.get('export', True)

                            sub_menu_perm_create = UserSubModulePermissions.objects.create(
                                organization_id=organization_id, role=role_details,
                                menu_id=menu_id, sub_menu_id=sub_menu_id, has_view_permission=view, has_add_permission=add,
                                has_edit_permission=edit, has_delete_permission=delete, has_export_permission=export,
                                level_permission=level_permission
                            )

                            sub_menu_perm_create.save()

                            if sub_menu_perm_create.has_view_permission == True:
                                menu_perm_create.has_view_permission = True
                            if sub_menu_perm_create.has_add_permission == True:
                                menu_perm_create.has_add_permission = True
                            if sub_menu_perm_create.has_edit_permission == True:
                                menu_perm_create.has_edit_permission = True
                            if sub_menu_perm_create.has_delete_permission == True:
                                menu_perm_create.has_delete_permission = True
                            if sub_menu_perm_create.has_export_permission == True:
                                menu_perm_create.has_export_permission = True
                            menu_perm_create.level_permission = True
                            menu_perm_create.save()

                    for adm in administrative_list:
                        admin_id = adm.get('id', None)
                        import_adm = adm.get('import', True)
                        approval = adm.get('approval', True)
                        approval_submit = adm.get('approval_submit', True)
                        export = adm.get('export', True)
                        adm_level_permission = adm.get(
                            'level_permission', True)

                        adm_perm_create = UserAdministrativePermissions.objects.create(
                            organization_id=organization_id, role=role_details,
                            admin_item_id=admin_id, has_import_permission=import_adm, has_approval_permission=approval,
                            has_approval_submit_permission=approval_submit, has_export_permission=export,
                            level_permission=adm_level_permission
                        )

                        adm_perm_create.save()

                    for setn in setting_list:
                        set_id = setn.get('id', None)
                        set_view = setn.get('view', True)
                        set_add = setn.get('add', True)
                        set_edit = setn.get('edit', True)
                        set_delete = setn.get('delete', True)
                        set_level_permission = setn.get(
                            'level_permission', True)
                        set_export = setn.get('export', True)

                        setting_perm_create = UserSettingsPermissions.objects.create(
                            organization_id=organization_id, role=role_details,
                            setting_item_id=set_id, has_view_permission=set_view, has_add_permission=set_add,
                            has_edit_permission=set_edit, has_delete_permission=set_delete, has_export_permission=set_export,
                            level_permission=set_level_permission
                        )

                        setting_perm_create.save()

                    for mdv in module_list:
                        mdv_id = mdv.get('id', None)
                        mdv_level_permission = mdv.get(
                            'level_permission', True)

                        mdv_perm_create = UserModulePermissions.objects.create(
                            organization_id=organization_id, role=role_details,
                            module_item_id=mdv_id, level_permission=mdv_level_permission
                        )

                        mdv_perm_create.save()

                    role_details.permissions_added = True
                    role_details.save()

            return Response({'request_status': 0, 'msg': "Role Permission Added successfully"})
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

    def put(self, request, *args, **kwargs):
        from user_permissions.models import UserPermissions, UserSubModulePermissions, UserAdministrativePermissions
        try:
            for data in self.request.data:
                organization_id = data.get('organization_id', None)
                role_id = data.get('id', None)
                menu_list = data.get('menu_list', None)
                setting_list = data.get('setting_list', None)
                administrative_list = data.get('administrative_list', None)
                module_list = data.get('module_list', None)

                with transaction.atomic():
                    role_details = Profile.objects.filter(id=role_id).first()

                    for item in menu_list:
                        menu_id = item.get('menu_id', None)
                        menu_view = item.get('view', True)
                        menu_add = item.get('add', True)
                        menu_edit = item.get('edit', True)
                        menu_delete = item.get('delete', True)
                        menu_export = item.get('export', True)
                        menu_level_permission = item.get(
                            'level_permission', True)
                        sub_menu_list = item.get('sub_menu_list', None)

                        menu_perm_create = UserPermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                                          menu_id=menu_id).update(
                            has_view_permission=menu_view, has_add_permission=menu_add,
                            has_edit_permission=menu_edit, has_delete_permission=menu_delete, has_export_permission=menu_export,
                            level_permission=menu_level_permission
                        )

                        for obj in sub_menu_list:
                            sub_menu_id = obj.get('sub_menu_id', None)
                            view = obj.get('view', True)
                            add = obj.get('add', True)
                            edit = obj.get('edit', True)
                            delete = obj.get('delete', True)
                            level_permission = obj.get(
                                'level_permission', True)
                            export = obj.get('export', True)

                            sub_menu_perm_create = UserSubModulePermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                                                           menu_id=menu_id, sub_menu_id=sub_menu_id).update(
                                has_view_permission=view, has_add_permission=add,
                                has_edit_permission=edit, has_delete_permission=delete, has_export_permission=export,
                                level_permission=level_permission
                            )

                            if view == True:
                                UserPermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                               menu_id=menu_id).update(has_view_permission=True)

                            if add == True:
                                UserPermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                               menu_id=menu_id).update(has_add_permission=True)

                            if edit == True:
                                UserPermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                               menu_id=menu_id).update(has_edit_permission=True)

                            if delete == True:
                                UserPermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                               menu_id=menu_id).update(has_delete_permission=True)
                            if export == True:
                                UserPermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                               menu_id=menu_id).update(has_export_permission=True)
                            UserPermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                           menu_id=menu_id).update(level_permission=True)

                    for adm in administrative_list:
                        admin_id = adm.get('admin_item_id', None)
                        import_adm = adm.get('import', True)
                        approval = adm.get('approval', True)
                        approval_submit = adm.get('approval_submit', True)
                        export = adm.get('export', True)
                        adm_level_permission = adm.get(
                            'level_permission', True)

                        adm_perm_create = UserAdministrativePermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                                                       admin_item_id=admin_id).update(
                            has_import_permission=import_adm, has_approval_permission=approval,
                            has_approval_submit_permission=approval_submit, has_export_permission=export,
                            level_permission=adm_level_permission
                        )

                    for setn in setting_list:
                        set_id = setn.get('setting_item_id', None)
                        set_view = setn.get('view', True)
                        set_add = setn.get('add', True)
                        set_edit = setn.get('edit', True)
                        set_delete = setn.get('delete', True)
                        set_level_permission = setn.get(
                            'level_permission', True)
                        set_export = setn.get('export', True)

                        settings_perm_create = UserSettingsPermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                                                      setting_item_id=set_id).update(
                            has_view_permission=set_view, has_add_permission=set_add,
                            has_edit_permission=set_edit, has_delete_permission=set_delete, has_export_permission=set_export,
                            level_permission=set_level_permission
                        )

                    for mdv in module_list:
                        mdv_id = mdv.get('module_item_id', None)
                        mdv_level_permission = mdv.get(
                            'level_permission', True)

                        mdv_perm_create = UserModulePermissions.objects.filter(organization_id=organization_id, role=role_details,
                                                                                       module_item_id=mdv_id).update(
                            level_permission=mdv_level_permission
                        )

            return Response({'request_status': 0, 'msg': "Role Permission Updated successfully"})
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class UserWiseProfilePermissionCreate(APIView):
    
    

    def put(self, request, *args, **kwargs):
        try:
            for data in self.request.data:
                organization_id = data.get('organization_id', None)
                role_id = data.get('id', None)
                user_id = data.get('user_id', None)
                menu_list = data.get('menu_list', None)
                setting_list = data.get('setting_list', None)
                administrative_list = data.get('administrative_list', None)
                module_list = data.get('module_list', None)

                with transaction.atomic():
                    role_details = Profile.objects.filter(id=role_id).first()

                    for item in menu_list:
                        menu_id = item.get('menu_id', None)
                        menu_view = item.get('view', True)
                        menu_add = item.get('add', True)
                        menu_edit = item.get('edit', True)
                        menu_delete = item.get('delete', True)
                        menu_export = item.get('export', True)
                        menu_level_permission = item.get(
                            'level_permission', True)
                        sub_menu_list = item.get('sub_menu_list', None)

                        UserWisePermissions.objects.update_or_create(organization_id=organization_id,
                                                                     user_id=user_id,
                                                                     menu_id=menu_id, defaults={'has_view_permission': menu_view,
                                                                                                'has_add_permission': menu_add, 'has_edit_permission': menu_edit,
                                                                                                'has_delete_permission': menu_delete, 'has_export_permission': menu_export,
                                                                                                'level_permission': menu_level_permission})

                        for obj in sub_menu_list:
                            sub_menu_id = obj.get('sub_menu_id', None)
                            view = obj.get('view', True)
                            add = obj.get('add', True)
                            edit = obj.get('edit', True)
                            delete = obj.get('delete', True)
                            level_permission = obj.get(
                                'level_permission', True)
                            export = obj.get('export', True)

                            UserWiseSubModulePermissions.objects.update_or_create(organization_id=organization_id,
                                                                                  user_id=user_id, menu_id=menu_id, sub_menu_id=sub_menu_id,
                                                                                  defaults={'has_view_permission': view,
                                                                                            'has_add_permission': add, 'has_edit_permission': edit,
                                                                                            'has_delete_permission': delete, 'has_export_permission': export,
                                                                                            'level_permission': level_permission})

                            if view == True:
                                UserWisePermissions.objects.filter(organization_id=organization_id,
                                                                   menu_id=menu_id, user_id=user_id).update(has_view_permission=True)

                            if add == True:
                                UserWisePermissions.objects.filter(organization_id=organization_id,
                                                                   menu_id=menu_id, user_id=user_id).update(has_add_permission=True)

                            if edit == True:
                                UserWisePermissions.objects.filter(organization_id=organization_id,
                                                                   menu_id=menu_id, user_id=user_id).update(has_edit_permission=True)

                            if delete == True:
                                UserWisePermissions.objects.filter(organization_id=organization_id,
                                                                   menu_id=menu_id, user_id=user_id).update(has_delete_permission=True)
                            if export == True:
                                UserWisePermissions.objects.filter(organization_id=organization_id,
                                                                   menu_id=menu_id, user_id=user_id).update(has_export_permission=True)
                            if level_permission == True:
                                UserWisePermissions.objects.filter(organization_id=organization_id,
                                                                   menu_id=menu_id, user_id=user_id).update(level_permission=True)

                    for adm in administrative_list:
                        admin_id = adm.get('id', None)
                        import_adm = adm.get('import', True)
                        approval = adm.get('approval', True)
                        approval_submit = adm.get('approval_submit', True)
                        export = adm.get('export', True)
                        adm_level_permission = adm.get(
                            'level_permission', True)

                        UserWiseAdministrativePermissions.objects.update_or_create(organization_id=organization_id,
                                                                                   user_id=user_id,
                                                                                   admin_item_id=admin_id, defaults={'has_import_permission': import_adm,
                                                                                                                     'has_approval_permission': approval, 'has_approval_submit_permission': approval_submit,
                                                                                                                     'has_export_permission': export, 'level_permission': adm_level_permission})

                    for setn in setting_list:
                        set_id = setn.get('id', None)
                        set_view = setn.get('view', True)
                        set_add = setn.get('add', True)
                        set_edit = setn.get('edit', True)
                        set_delete = setn.get('delete', True)
                        set_level_permission = setn.get(
                            'level_permission', True)
                        set_export = setn.get('export', True)

                        UserWiseSettingPermissions.objects.update_or_create(organization_id=organization_id,
                                                                            user_id=user_id,
                                                                            setting_item_id=set_id, defaults={'has_view_permission': set_view,
                                                                                                              'has_add_permission': set_add, 'has_edit_permission': set_edit,
                                                                                                              'has_delete_permission': set_delete, 'has_export_permission': set_export,
                                                                                                              'level_permission': set_level_permission})
                        

                    for mdv in module_list:
                        mdv_unique_id = mdv.get('unique_id', None)
                        mdv_level_permission = mdv.get(
                            'level_permission', True)
                        
                        module_master = ModulePermissionsMaster.objects.filter(unique_id=mdv_unique_id).first()

                        UserWiseModulePermissions.objects.update_or_create(organization_id=organization_id,
                                                                            user_id=user_id,
                                                                            module_item=module_master, defaults={'level_permission': mdv_level_permission})    

            return Response({'request_status': 0, 'msg': "Permissions Updated successfully"})
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class RoleTreeAPIView(APIView):
    def get(self, request, *args, **kwargs):
        organization_id = self.request.query_params.get('organization_id')
        roles = Role.cmobjects.filter(organization_id=organization_id)
        role_dict = {}

        # Create a dictionary of roles, with the role id as the key and the role object as the value
        for role in roles:
            role_dict[role.id] = role

        # Create a dictionary of child roles, with the parent role id as the key and a list of child role ids as the value
        child_roles_dict = {}
        for role in roles:
            parent_id = role.parent_id
            if parent_id in child_roles_dict:
                child_roles_dict[parent_id].append(role.id)
            else:
                child_roles_dict[parent_id] = [role.id]

        # Create the tree structure
        tree = []
        for role in roles:
            if role.parent_id == 0:
                node = self.get_node(role, role_dict, child_roles_dict)
                tree.append(node)

        return Response(tree)

    def get_node(self, role, role_dict, child_roles_dict):
        node = {
            "id": role.id,
            "designation": role.designation,
            "organization": role.organization.name,
            "share_to_peer": role.share_to_peer,
            "children": []
        }

        if role.id in child_roles_dict:
            child_ids = child_roles_dict[role.id]
            for child_id in child_ids:
                child = role_dict[child_id]
                # if not child.is_deleted: # Check if the child role is not deleted
                child_node = self.get_node(child, role_dict, child_roles_dict)
                node["children"].append(child_node)

        return node


class CompanyWiseRoleTreeAPI(APIView):
    """
        Company Wise Role Tree View
    """
    def get(self, request, *args, **kwargs):
        organization_id = self.request.query_params.get('organization_id')
        company_list = Company.cmobjects.filter(
            organization_id=organization_id, users__in=[request.user]).order_by('-id')
        print("company_list ###", company_list)
        serializer = CompanyWiseRoleTreeSerializer(company_list, many=True)
        return Response(serializer.data)


class SettingsGroupMasterAPIView(APIView):
    """ 
        Settings Group master API VIEW
    """
    def get(self, request, *args, **kwargs):
        organization_id = self.request.query_params.get('organization_id')
        settings_for = self.request.query_params.get('settings_for')

        settings_list = SettingsGroupMaster.cmobjects.filter(
            organization_id=organization_id).order_by('id')
        serializer = SettingsGroupMasterSerializer(settings_list, many=True, context={
                                                   "settings_for": settings_for, 'request': request})
        return Response(serializer.data)

class UpcomingBirthdaysAPIView(APIView):
    def get(self, request, format=None):
        today = date.today()
        end_date = today + timedelta(days=30)

        organization_id = request.GET.get('organization_id')
        upcoming_birthdays = PmsUser.objects.filter(
            organization_id=organization_id,
            date_of_birth__month=today.month,
            date_of_birth__day__gte=today.day,
        ) | PmsUser.objects.filter(
            organization_id=organization_id,
            date_of_birth__month=end_date.month,
            date_of_birth__day__lte=end_date.day,
        ).order_by('date_of_birth')

        birthdays_data = []
        for user in upcoming_birthdays:
            birthday_data = {
                'name': user.get_full_name(),
                'date_of_birth': user.date_of_birth,
            }
            if user.department:
                birthday_data['department'] = user.department.department
            if user.image:
                image_url = request.build_absolute_uri(user.image.url)
                birthday_data['image_url'] = image_url

            birthdays_data.append(birthday_data)

        return Response({'success': True, "result": birthdays_data},
                        status=status.HTTP_200_OK)

class NewJoinersView(APIView):
    def get(self, request):
        # Assuming you pass the organization ID as a query parameter
        organization_id = request.GET.get('organization_id')
        today = datetime.today().date()
        start_of_month = today.replace(day=1)

        new_joiners = PmsUser.objects.select_related('designation','department').filter(
            organization_id=organization_id,
            joining_date__range=[start_of_month, today]
        )

        serializer = NewJoinerSerializer(new_joiners, many=True)

        return Response({'success': True, "result": serializer.data},
                        status=status.HTTP_200_OK)



class NoticeBoardListAPIView(APIView):
    def get(self, request):
        organization_id = request.query_params.get('organization_id')
        
        if organization_id is not None:
            try:
                organization_id = int(organization_id)
            except ValueError:
                raise APIException({'request_status': 0, 'msg': "Invalid organization ID"})
            notices = NoticeBoard.objects.filter(organization_id=organization_id)
        else:
            raise APIException({'request_status': 0, 'msg': "organization_id is mandatory parameters."})
        
        serializer = NoticeBoardSerializer(notices, many=True)
        return Response(serializer.data)
    def post(self, request):
        organization_id = request.query_params.get('organization_id')

        if organization_id is not None:
            try:
                organization_id = int(organization_id)
            except ValueError:
                raise APIException({'request_status': 0, 'msg': "Invalid organization ID"})
        user = request.user
        if not user.is_authenticated:
            return Response({'detail': 'Authentication credentials were not provided.'},
                            status=status.HTTP_401_UNAUTHORIZED)
        data = request.data.copy()
        data['created_by'] = user.pk
        if organization_id is not None:
            data['organization'] = organization_id

        serializer = NoticeBoardSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, *args, **kwargs):
        method = request.query_params.get('method').lower()
        organization_id = request.query_params.get('organization_id')
        notice_id = request.query_params.get('id')

        if organization_id is not None:
            try:
                organization_id = int(organization_id)
            except ValueError:
                return Response({'msg': 'Invalid organization ID.'}, status=status.HTTP_400_BAD_REQUEST)

        if method == 'edit':
            try:
                notice = NoticeBoard.objects.get(pk=notice_id, organization_id=organization_id)
            except NoticeBoard.DoesNotExist:
                return Response({'msg': 'Notice not found.'}, status=status.HTTP_404_NOT_FOUND)

            notice.updated_by = request.user
            serializer = NoticeBoardSerializer(notice, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        elif method == 'delete':
            try:
                notice = NoticeBoard.objects.get(pk=notice_id, organization_id=organization_id)
            except NoticeBoard.DoesNotExist:
                return Response({'msg': 'Notice not found.'}, status=status.HTTP_404_NOT_FOUND)

            notice.is_deleted = True
            notice.save()

            return Response({'msg': 'Notice marked as deleted.'}, status=status.HTTP_200_OK)

        return Response({'msg': 'Invalid method.'}, status=status.HTTP_400_BAD_REQUEST)
    


class UserTypePermissions(APIView):
    """
    User Type Permissions API View
    """
    
    

    def get(self, request, *args, **kwargs):
        user = request.user
        tender_id = self.request.query_params.get('tender_id', None)
        user_permissions_list = list(UserWiseModulePermissions.cmobjects.filter(user=user, \
                                                                              level_permission=True).values_list(\
                                                                                'module_item__unique_id', flat=True))


        current_host = request.get_host()
        protocol = 'http' if settings.DEBUG or request.is_secure() or current_host.startswith('localhost') else 'https'
        dynamic_url_value = f"{protocol}://{current_host}"

        results = []
        data_dict = collections.OrderedDict()
        data_dict['username'] = user.username
        data_dict['id'] = user.id
        data_dict['user_permissions'] = user_permissions_list
        tabular_enabled = False
        evaluation_summary_visible = False
        is_resend_enabled = False

        # if int(len(user_permissions_list)) == 1 and "pre-tender-identifier" in user_permissions_list:
        #     tabular_enabled = True
        if ("pre-tender-identifier" in user_permissions_list and
                ('pre-tender-approver' not in user_permissions_list
                 or 'pre-tender-proposer' not in user_permissions_list
                 or 'pre-tender-recommender' not in user_permissions_list)):
            tabular_enabled = True

        if "pre-tender-recommender" in user_permissions_list:
            evaluation_summary_visible =  True 
        elif "pre-tender-approver" in user_permissions_list:
            evaluation_summary_visible =  True

        data_dict['tabular_enabled'] = tabular_enabled

        data_dict['evaluation_summary_visible'] = evaluation_summary_visible

        if tender_id:
            from tender.models import TenderMaster
            tender_details = TenderMaster.cmobjects.filter(id=tender_id).first()

            if tender_details.is_approved == True and "pre-tender-recommender" in user_permissions_list:
                data_dict['is_resend_enabled'] = False
            elif tender_details.is_reject == True and "pre-tender-recommender" in user_permissions_list:
                data_dict['is_resend_enabled'] = False
            elif tender_details.is_vga_approved == True and "pre-tender-recommender" in user_permissions_list:
                data_dict['is_resend_enabled'] = False
            elif tender_details.is_vga_reject == True and "pre-tender-recommender" in user_permissions_list:
                data_dict['is_resend_enabled'] = False
            elif tender_details.is_sent_for_approval == True and "pre-tender-recommender" in user_permissions_list:
                data_dict['is_resend_enabled'] = True
            elif tender_details.is_sent_for_final_approval == True and "pre-tender-recommender" in user_permissions_list:
                data_dict['is_resend_enabled'] = True
            else:
                data_dict['is_resend_enabled'] = False

            if tender_details.is_sent_for_approval == True:
                data_dict['form_editable'] = False
            else:
                data_dict['form_editable'] = True

            if tender_details.is_sent_for_recommendation == True \
                and tender_details.is_recommended == False \
                    and "pre-tender-recommender" in user_permissions_list:
                data_dict['form_type'] = "tender_executive_commitee"
                data_dict['button_text'] = "Submit and Send for VGA Approval"
                data_dict['api_url'] = f"{dynamic_url_value}/tender-approval-sent/?organization_id=" + str(user.organization_id) +  "&tender_id=" + str(tender_id) + "&is_sent_for_approval=true"
                data_dict['api_method'] = "PUT"

                data_dict['reverse_form_type'] = "tender_eligibility"
                data_dict['reverse_button_text'] = "Re-send Tender For Proposal"
                data_dict['reverse_api_url'] = f"{dynamic_url_value}/tender-reversed-for-proposal/?organization_id=" + str(user.organization_id) +  "&tender_id=" + str(tender_id) + "&is_reverse_for_proposal=true"
                data_dict['reverse_api_method'] = "PUT"

            elif tender_details.is_sent_for_recommendation == False \
                and tender_details.is_compliance_complete == True and "pre-tender-proposer" in user_permissions_list:
                data_dict['form_type'] = "last"
                data_dict['button_text'] = "Submit and Send for Recommendation"
                data_dict['api_url'] = f"{dynamic_url_value}/tender-recommendation/?organization_id=" + str(user.organization_id) +  "&tender_id=" + str(tender_id) + "&is_recommended=true"

                data_dict['api_method'] = "PUT"

            if ((tender_details.is_physical_survey_complete==True and
                    tender_details.is_material_survey_complete==True and
                    tender_details.is_taxation_survey_complete==True and
                    tender_details.is_liason_survey_complete==True and
                    tender_details.is_survey_complete==False)
                and ("pre-tender-recommender" in user_permissions_list or
                     "pre-tender-approver" in user_permissions_list)):

                # pp.pprint(tender_details.__dict__)
                data_dict['survey_form_type'] = "tender_top_sheet"
                data_dict['survey_button_text'] = "Complete Survey"
                data_dict['survey_api_url'] = f"{dynamic_url_value}/tender-start-completed/"
                data_dict['survey_api_method'] = "PUT"
                data_dict['survey_form_data_json'] = "{'tender_id' : " + str(tender_id) + "}"

            # elif tender_details.is_physical_survey_complete == True and tender_details.is_material_survey_complete == True and \
            #     tender_details.is_taxation_survey_complete == True and tender_details.is_liason_survey_complete == True \
            #     and tender_details.is_survey_complete == False \
            #     and "pre-tender-approver" in user_permissions_list:
            #     data_dict['survey_form_type'] = "tender_top_sheet"
            #     data_dict['survey_button_text'] = "Complete Survey"
            #     data_dict['survey_api_url'] = f"{dynamic_url_value}/tender-start-completed/"
            #     data_dict['survey_api_method'] = "PUT"
            #     data_dict['survey_form_data_json'] = "{'tender_id' : " + str(tender_id) + "}"

            # if tender_details.ex_summary_recommend_requested == True and tender_details.ex_summary_approval_requested == False and "pre-tender-recommender" in user_permissions_list:
            #     data_dict['form_type_ex'] = "tender_executive_commitee"
            #     data_dict['button_tex_ext'] = "Submit and Send for Approval"
            #     data_dict['api_url_ex'] = "http://3.109.115.146:8000/tender-ex-summary-approval-sent/?organization_id=" + str(user.organization_id) +  "&tender_id=" + str(tender_id) + "&ex_summary_approval_requested=true"
            #     data_dict['api_method_ex'] = "PUT"
            # elif tender_details.ex_summary_recommend_requested == False and "pre-tender-proposer" in user_permissions_list:
            #     data_dict['form_type_ex'] = "last"
            #     data_dict['button_tex_ext'] = "Submit and Send for Reccomendation"
            #     data_dict['api_url_ex'] = "http://3.109.115.146:8000/tender-ex-summary-recommendation/?organization_id=" + str(user.organization_id) +  "&tender_id=" + str(tender_id) + "&ex_summary_recommend_requested=true"
            #     data_dict['api_method_ex'] = "PUT"

        results.append(data_dict)

        return Response({'results': results,
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
    



class JVMASTERAPIView(APIView):
    """
    CRUD API for JVMASTER model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all JVMASTER
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        organization_id = self.request.query_params.get('organization_id', None)
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = JVMASTER.cmobjects.filter(id=id).first()
            serializer = JVMASTERSerializer(list_data)
            return Response(serializer.data)

        list_data = JVMASTER.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = JVMASTERSerializer(list_data, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = JVMASTERSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Employeementype
        """
        serializer = JVMASTERSerializer(data=request.data)
        if JVMASTER.cmobjects.filter(party_name=request.data['party_name'].strip(),
                                     organization=request.data['organization']).exists():
            raise APIException({'request_status': 0, 'msg': "JV Master Data already exist"})
        
        if serializer.is_valid():
            serializer.save()
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'edit':
                """
                    Update a company
                """
                if JVMASTER.cmobjects.filter(pk=id,
                                             organization_id=organization_id).exists():

                    user_type_details = JVMASTER.cmobjects.get(pk=id)

                    old_name = user_type_details.party_name

                    if JVMASTER.cmobjects.filter(party_name=request.data['party_name'].strip(),
                                                 organization=request.data['organization']).exclude(
                            party_name=user_type_details.party_name).exists():
                        raise APIException("JV Master Data already exist")

                    serializer = JVMASTERSerializer(
                        user_type_details, data=request.data)
                    if serializer.is_valid():
                        serializer.save()

                        from administrations.utils import create_dependent_formvalues_on_master_crud_operations, change_tender_percentage_analysis_jv_data_on_master_change
                        create_dependent_formvalues_on_master_crud_operations('jv_master', user_type_details.party_name, user_type_details.id)
                        change_tender_percentage_analysis_jv_data_on_master_change(old_name, request.data.get('party_name', None), user_type_details.id)
                        
                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response(
                        {'results': {
                            'Data': serializer.errors,
                        },
                            'msg': "Something went wrong. If the problem persists, please contact support.",
                            'status': status.HTTP_400_BAD_REQUEST,
                            "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
                
            elif method.lower() == 'delete':
                """
                Delete a UserType
                """
                import ast
                from tender.models import TenderData
                from custom_management.models import FormDependentChoices
                tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='party_name')

                jv_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='party_name', \
                                                               option_id=id).values_list('id', flat=True))

                jv_tender_ids = []

                for item1 in tender_data_list:
                    try:
                        res = ast.literal_eval(item1.value)
                    except Exception as ex:
                        res = []
                    for obj in res:
                        if obj in jv_ids:
                            jv_tender_ids.append(item1.tender_id)

                if jv_tender_ids:
                    raise APIException({'request_status': 0, 'msg': "Selected JV Partner cannot be deleted, as a tender is already present under it!"})

                if JVMASTER.cmobjects.filter(pk=id, organization=organization_id).exists():
                    user_type = JVMASTER.cmobjects.get(
                        pk=id, organization=organization_id)
                    user_type.is_deleted = True
                    user_type.save()

                    return Response({'results': {
                        'jw_master': JVMASTER.objects.filter(pk=id, organization=organization_id).values(),
                    },
                        'msg': 'Successfully deleted jw master',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
                



class STANDALONEMASTERAPIView(APIView):
    """
    CRUD API for STANDALONEMASTER model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all STANDALONEMASTER
        """
        id = self.request.query_params.get('id', None)
        if id:
            user_type = STANDALONEMASTER.cmobjects.filter(id=id).first()
            serializer = STANDALONEMASTERSerializer(user_type)
            return Response(serializer.data)

        organization_id = self.request.query_params.get(
            'organization_id', None)
        employeement_type = STANDALONEMASTER.cmobjects.filter(
            organization_id=organization_id).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(employeement_type, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = STANDALONEMASTERSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Employeementype
        """
        serializer = STANDALONEMASTERSerializer(data=request.data)
        if STANDALONEMASTER.cmobjects.filter(party_name=request.data['party_name'].strip(),
                                     organization=request.data['organization']).exists():
            raise APIException("STANDALONE MASTER Data already exist")

        if serializer.is_valid():
            serializer.save()
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a company
                """
                if STANDALONEMASTER.cmobjects.filter(pk=id,
                                             organization_id=organization_id).exists():

                    user_type_details = STANDALONEMASTER.cmobjects.get(pk=id)

                    if STANDALONEMASTER.cmobjects.filter(party_name=request.data['party_name'].strip(),
                                                 organization=request.data['organization']).exclude(
                            party_name=user_type_details.party_name).exists():
                        raise APIException("STANDALONE MASTER Dats Already Exist")

                    serializer = STANDALONEMASTERSerializer(
                        user_type_details, data=request.data)
                    if serializer.is_valid():
                        serializer.save()

                        from administrations.utils import create_dependent_formvalues_on_master_crud_operations
                        create_dependent_formvalues_on_master_crud_operations('standalone_master', user_type_details.party_name, user_type_details.id)


                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response(
                        {'results': {
                            'Data': serializer.errors,
                        },
                            'msg': "Something went wrong. If the problem persists, please contact support.",
                            'status': status.HTTP_400_BAD_REQUEST,
                            "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a UserType
                """
                if STANDALONEMASTER.cmobjects.filter(pk=id, organization=organization_id).exists():
                    user_type = STANDALONEMASTER.cmobjects.get(
                        pk=id, organization=organization_id)
                    user_type.is_deleted = True
                    user_type.save()

                    return Response({'results': {
                        'standalone_master': STANDALONEMASTER.objects.filter(pk=id, organization=organization_id).values(),
                    },
                        'msg': 'Successfully deleted standalone master',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
                


class EMPLOYEEMASTERAPIView(APIView):
    """
    CRUD API for STANDALONEMASTER model
    """
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        # organization_id = self.request.query_params.get('organization_id', 1)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = EMPLOYEEMASTER.cmobjects.filter(id=id).first()
            serializer = EMPLOYEEMASTERSerializer(list_data)
            return Response(serializer.data)
        
        list_data = EMPLOYEEMASTER.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = EMPLOYEEMASTERSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = EMPLOYEEMASTERSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Employeementype
        """
        form_id = request.data.get('form_id', None)
        query_name = request.data.get('query_name', None)

        serializer = EMPLOYEEMASTERSerializer(data=request.data)
        if EMPLOYEEMASTER.cmobjects.filter(employee_name=request.data['employee_name'].strip(),
                                     organization=request.data['organization']).exists():
            raise APIException("EMPLOYEE MASTER Data already exist")

        if serializer.is_valid():
            serializer.save()

            employee_details = serializer.data

            if form_id:
                from custom_management.models import FormDependentChoices

                dependent_choise_create = FormDependentChoices.objects.create(form_id=form_id, name=employee_details.get('employee_name', None),\
                                                                                            option_id=employee_details.get('id', None),\
                                                                                                query_name=query_name,\
                                                                                                    created_by=request.user)
                
                dependent_choise_create.save()


            return Response(
                {'results': {
                    'Data': serializer.data,
                    'dependent_id' : dependent_choise_create.id if form_id else "",
                    },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a company
                """
                if EMPLOYEEMASTER.cmobjects.filter(pk=id,
                                             organization_id=organization_id).exists():

                    user_type_details = EMPLOYEEMASTER.cmobjects.get(pk=id)

                    if EMPLOYEEMASTER.cmobjects.filter(employee_name=request.data['employee_name'].strip(),
                                                 organization=request.data['organization']).exclude(
                            employee_name=user_type_details.employee_name).exists():
                        raise APIException("EMPLOYEE MASTER Dats Already Exist")

                    serializer = EMPLOYEEMASTERSerializer(
                        user_type_details, data=request.data)
                    if serializer.is_valid():
                        serializer.save()

                        from administrations.utils import create_dependent_formvalues_on_master_crud_operations
                        create_dependent_formvalues_on_master_crud_operations('employee_master', user_type_details.employee_name, user_type_details.id)


                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response(
                        {'results': {
                            'Data': serializer.errors,
                        },
                            'msg': "Something went wrong. If the problem persists, please contact support.",
                            'status': status.HTTP_400_BAD_REQUEST,
                            "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a UserType
                """
                if EMPLOYEEMASTER.cmobjects.filter(pk=id, organization=organization_id).exists():
                    user_type = EMPLOYEEMASTER.cmobjects.get(
                        pk=id, organization=organization_id)
                    user_type.is_deleted = True
                    user_type.save()

                    from custom_management.models import FormDependentChoices

                    dependent_choise_details = FormDependentChoices.objects.filter(option_id=id, \
                                                                                   query_name='employee_master').first()
                    if dependent_choise_details:
                        dependent_choise_details.is_deleted = True
                        dependent_choise_details.save()

                    return Response({'results': {
                        'employee_master': EMPLOYEEMASTER.objects.filter(pk=id, organization=organization_id).values(),
                    },
                        'msg': 'Successfully deleted employee master',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
                



class NotificationMasterAPIView(APIView):
    """
    CRUD API for NotificationMaster model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all NotificationMaster
        """
        id = self.request.query_params.get('id', None)
        data_filter = self.request.query_params.get('data_filter', None)
        if id:
            notification_list = NotificationMaster.cmobjects.filter(id=id).first()
            serializer = NotificationMasterSerializer(notification_list)
            return Response(serializer.data)
        
        organization_id = self.request.query_params.get(
            'organization_id', None)
        
        if data_filter == "last_week":
            from datetime import timedelta
            from django.utils import timezone
            some_day_last_week = timezone.now().date() - timedelta(days=7)
            monday_of_last_week = some_day_last_week - timedelta(days=(some_day_last_week.isocalendar()[2] - 1))
            monday_of_this_week = monday_of_last_week + timedelta(days=7)

            notification_list = NotificationMaster.cmobjects.filter(
            Q(organization_id=organization_id), Q(created_at__gte=monday_of_last_week),\
                    Q(created_at__lt=monday_of_this_week), Q(is_universal=True) | \
                        Q(notified_users=request.user)).order_by('-id')[:10]
            
            serializer = NotificationMasterSerializer(notification_list, many=True)
            
            return Response({
                'results': serializer.data,
            })
            

        
        notification_list = NotificationMaster.cmobjects.filter(
            Q(organization_id=organization_id), Q(is_universal=True) | \
                Q(notified_users=request.user)).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(notification_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = NotificationMasterSerializer(page, many=True)
        # serializer = EmployeementypeSerializer(employeement_type, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    




class DelayReasonAPIView(APIView):
    """
    CRUD API for Delay Reason model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all Delay Reason
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)

        if id:
            delay_details = DelayReasons.cmobjects.filter(id=id).first()
            serializer = DelayReasonSerializer(delay_details)
            return Response(serializer.data)

        organization_id = self.request.query_params.get(
            'organization_id', None)
        
        delay_list = DelayReasons.cmobjects.filter(
            organization_id=organization_id).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(delay_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)


        serializer = DelayReasonSerializer(page, many=True)

        if all == 'true':
            serializer = DelayReasonSerializer(delay_list, many=True)

            return Response({
                'results': serializer.data
            })



        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Delay Reason
        """
        serializer = DelayReasonSerializer(data=request.data)
        if DelayReasons.cmobjects.filter(reasons=request.data['reasons'].strip(),
                                     organization=request.data['organization']).exists():
            raise APIException("Delay Reason already exist")
        

        delay_breakups = request.data.get("delay_breakups", None)

        if serializer.is_valid():
            serializer.save()

            for item in delay_breakups:
                breakup_create = DelayBreakUps.objects.create(delay_id=serializer.data.get("id", None),\
                                                              name=item)
                breakup_create.save()


            return Response(
                {'results': {
                    'Data': DelayReasonSerializer(DelayReasons.cmobjects.filter(id=serializer.data.get("id", None)).first()).data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a delay reasons
                """
                if DelayReasons.cmobjects.filter(pk=id,
                                             organization_id=organization_id).exists():

                    delay_reason_details = DelayReasons.cmobjects.get(pk=id)

                    if DelayReasons.cmobjects.filter(reasons=request.data['reasons'].strip(),
                                                        organization_id=organization_id).exclude(
                                                            reasons=delay_reason_details.reasons).exists():
                        raise APIException("Delay Reason already exist")

                    serializer = DelayReasonSerializer(
                        delay_reason_details, data=request.data)
                    

                    delay_breakups = request.data.get("delay_breakups", None)

                    breakup_names = []
                    

                    if serializer.is_valid():
                        serializer.save()

                        # if DelayBreakUps.cmobjects.filter(delay_id=delay_reason_details.id).exists():
                        #     DelayBreakUps.cmobjects.filter(delay_id=delay_reason_details.id).delete()

                        for item in delay_breakups:
                            if item.get('id', None) == "":
                                breakup_create = DelayBreakUps.objects.create(delay_id=delay_reason_details.id, \
                                                                       name=item.get('name', None))
                                breakup_create.save()
                            else:
                                breakup_create = DelayBreakUps.objects.update_or_create(delay_id=delay_reason_details.id,\
                                                              id=item.get('id', None), defaults={'name':item.get('name', None)})

                            breakup_names.append(item.get('name', None))

                        
                        DelayBreakUps.cmobjects.filter(delay_id=delay_reason_details.id).exclude(\
                            name__in=breakup_names).update(is_deleted=True)


                        create_dependent_formvalues_on_master_crud_operations("delay_reason", \
                                                                            delay_reason_details.reasons, delay_reason_details.id)

                        return Response({'results': {
                                        'Data': DelayReasonSerializer(DelayReasons.cmobjects.filter(id=serializer.data.get("id", None)).first()).data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response(
                        {'results': {
                            'Data': serializer.errors,
                        },
                            'msg': "Something went wrong. If the problem persists, please contact support.",
                            'status': status.HTTP_400_BAD_REQUEST,
                            "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a Delay Reason
                """
                if DelayReasons.cmobjects.filter(pk=id, organization=organization_id).exists():
                    delay_details = DelayReasons.cmobjects.get(
                        pk=id, organization=organization_id)
                    delay_details.is_deleted = True
                    delay_details.save()

                    return Response({'results': {
                        'delay_reason_master': DelayReasons.objects.filter(pk=id, organization=organization_id).values(),
                    },
                        'msg': 'Successfully deleted selected delay reason',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
                

class UpdateNewPermissionsAPIView(APIView):
    """
    CRUD API for UpdateNewPermissions
    """
    permission_classes = (AllowAny,)

    def put(self, request, format=None):
        try:
            with transaction.atomic():
                modules_all = {
                    "administratives": ["AdministrativeMaster","UserAdministrativePermissions","UserWiseAdministrativePermissions","admin_item_id",["id"]],
                    "module_permissions": ["ModulePermissionsMaster","UserModulePermissions","UserWiseModulePermissions","module_item_id",["id"]],
                    "settings": ["SettingsMaster","UserSettingsPermissions","UserWiseSettingPermissions","setting_item_id",["id"]],
                    "menus": ["MenuMaster","UserPermissions","UserWisePermissions","menu_id",["id"]],
                    "sub_menus": ["SubMenuMaster","UserSubModulePermissions","UserWiseSubModulePermissions","sub_menu_id",["id","menu_id"]],
                }
                category_all = {
                    "profiles": ["Profile","role_id"],
                    "users": ["PmsUser","user_id"],
                }
                modules = {key: modules_all[key] for key in request.data['modules_keys'] if key in modules_all}
                category = {key: category_all[key] for key in request.data['category_keys'] if key in category_all}
                modules_data = {}
                category_data = {}
                for key, value in modules.items():
                    modules_data[key] = {}
                    search = {}
                    if key == "settings":
                        search["settings_group__is_deleted"] = 0
                    modules_data[key][value[0]] = eval(f'({value[0]}.cmobjects.filter(**search).values(*{value[4]}))')
                for key, value in category.items():
                    object_type = "cmobjects"
                    index = 1
                    search = {"is_active": True}
                    search1 = {}
                    search2 = {}
                    if key == "users":
                        object_type = "objects"
                        index = 2
                    category_data[key] = eval(f'list({value[0]}.{object_type}.filter(**search).values_list("id",flat=True))')
                    for key1, value1 in modules.items():
                        modules_data[key1][value1[index]] = eval(f'({value1[index]}.cmobjects.filter(**search1).values("{value1[3]}","{value[1]}"))')
                update_datas = {}
                for key1, value1 in modules_data.items():
                    update_datas[modules[key1][1]] = []
                    update_datas[modules[key1][2]] = []
                    for data1 in value1[modules[key1][0]]:
                        counter = 1 if "profiles" in request.data['category_keys'] else 2
                        for key2, value2 in category_data.items():
                            for data2 in value2:
                                temp_dict = {modules[key1][3]: data1["id"], category[key2][1]: data2}
                                if not temp_dict in value1[modules[key1][counter]]:
                                    for key3, value3 in data1.items():
                                        if key3 != "id":
                                            temp_dict[key3] = value3
                                    temp_dict['organization_id'] = 1
                                    update_datas[modules[key1][counter]].append(eval(f'{modules[key1][counter]}(**temp_dict)'))
                            counter += 1
                count = { "total": 0 }
                for update_data_key,update_data_value in update_datas.items():
                    count[update_data_key] = 0
                    if update_data_value:
                        count[update_data_key] += len(update_data_value)
                        count["total"] += len(update_data_value)
                        eval(f'({update_data_key}.objects.bulk_create(update_data_value, batch_size=100))')

                return Response({'results': count,
                    'msg': 'Successfully Updated ',
                    "request_status": 1})
            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e)})

    

        
class UserRoleNewAPIView(APIView):
    """
    CRUD API for organization role model
    """
    
    

    def get(self, request, format=None):
        id = self.request.query_params.get('id', None)
        if id:
            role = Profile.cmobjects.select_related('organization').filter(id=id).first()
            serializer = RoleSerilizer(role)
            return Response(serializer.data)

        organization_id = self.request.query_params.get('organization_id', None)
        is_active = self.request.query_params.get('is_active', None)
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))

        role_query =  Profile.cmobjects.select_related('organization').filter(permissions_added=True)

        if organization_id:
            role_query = role_query.filter(organization_id=organization_id)

        if is_active is not None:
            is_active_bool = is_active.lower() == 'true'
            role_query = role_query.filter(is_active=is_active_bool)

        role_query = role_query.order_by('-id')
        # Prefetch related objects
        related_objects = [
            Prefetch('permission_roles', queryset=UserPermissions.objects.all()),
            Prefetch('administrative_roles', queryset=UserAdministrativePermissions.objects.all()),
            Prefetch('sub_permission_roles', queryset=UserModulePermissions.objects.all()),
            Prefetch('setting_roles', queryset=UserSettingsPermissions.objects.all()),
        ]
        role_query = role_query.prefetch_related(*related_objects)
        paginator = Paginator(role_query, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = RoleSerilizer(page, many=True)

        is_active_true_count = role_query.filter(is_active=True).count()
        is_active_false_count = role_query.filter(is_active=False).count()

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
            'is_active_true_count': is_active_true_count,
            'is_active_false_count': is_active_false_count
        })

class PmsUserStatsAPIView(APIView):
    """
    API View to get counts of total users, active users, and inactive users.
    """
    def get(self, request):
            organization_id = self.request.query_params.get('organization_id', None)
            user_counts = PmsUser.objects.filter(organization_id=organization_id).aggregate(
                total_count=Count('id'),
                active_count=Count('id', filter=Q(is_active=True)),
                inactive_count=Count('id', filter=Q(is_active=False))
            )
            
            return Response({
                "total_users": user_counts.get("total_count", 0),
                "active_users": user_counts.get("active_count", 0),
                "inactive_users": user_counts.get("inactive_count", 0)
            }, status=status.HTTP_200_OK)
       
class HolidayCalendarAPIView(APIView):
    """
    CRUD API for Holiday
    """
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            holiday = Holiday.cmobjects.filter(id=id).first()
            serializer = HolidaySerializer(holiday)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = Holiday.cmobjects.select_related(
            'organization', 'state', 'country'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = HolidaySerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = HolidaySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = HolidaySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response({'results': {'Data': serializer.data},
                             'msg': 'Successfully created',
                             'status': status.HTTP_201_CREATED,
                             "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        holiday_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if Holiday.cmobjects.filter(pk=holiday_id, organization_id=organization_id).exists():
                    details = Holiday.cmobjects.filter(pk=holiday_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = HolidaySerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if Holiday.cmobjects.filter(pk=holiday_id, organization_id=organization_id).exists():
                    details = Holiday.cmobjects.filter(pk=holiday_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'Data': Holiday.objects.filter(pk=holiday_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class JVMASTERDocumentAPIView(APIView):
    """
        CRUD API for JVMASTERDocument model
    """
    
    
    def get(self, request):
        """
        Get a list of all communication
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            queryset = JVMASTERDocument.cmobjects.filter(id=id).first()
            serializer = JVMASTERDocumentSerializer(queryset)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])
       
        queryset = JVMASTERDocument.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = JVMASTERDocumentSerializer(queryset, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = JVMASTERDocumentSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create one or more records
        """
        data = request.data if isinstance(request.data, list) else [request.data]
        created_objects = []
        errors = []
        for item in data:
            item['created_by'] = request.user.id
            serializer = JVMASTERDocumentSerializer(data=item, context={'request': request})
            if serializer.is_valid():
                try:
                    instance = serializer.save()
                    created_objects.append(JVMASTERDocumentSerializer(instance).data)
                except Exception as e:
                    errors.append({'data': item, 'error': str(e)})
            else:
                errors.append({'data': item, 'error': serializer.errors})
        if errors:
            return Response({
                'request_status': 0,
                'msg': 'Some records failed to create',
                'errors': errors,
                'created': created_objects
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'results': {'Data': created_objects},
            'msg': 'Successfully created',
            'status': status.HTTP_201_CREATED,
            'request_status': 1
        }, status=status.HTTP_201_CREATED)

    def put(self, request):
        """
        Edit a ProjectJVIncorporation
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a ProjectJVIncorporation
                """
                if JVMASTERDocument.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = JVMASTERDocument.cmobjects.filter(pk=id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = JVMASTERDocumentSerializer(details, data=request.data,partial=True,)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                """
                Delete a ProjectJVIncorporation
                """
                if JVMASTERDocument.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = JVMASTERDocument.cmobjects.filter(
                        pk=id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': JVMASTERDocument.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted communication',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class JVMASTERWorkExperienceCategoryMasterAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = JVMASTERWorkExperienceCategoryMaster.cmobjects.filter(id=id).first()
            serializer = JVMASTERWorkExperienceCategoryMasterSerializer(list_data)
            return Response(serializer.data)
        
        list_data = JVMASTERWorkExperienceCategoryMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = JVMASTERWorkExperienceCategoryMasterSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = JVMASTERWorkExperienceCategoryMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = JVMASTERWorkExperienceCategoryMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        details = JVMASTERWorkExperienceCategoryMaster.cmobjects.filter(pk=id).first()

        with transaction.atomic():
            if method.lower() == 'edit':
                if JVMASTERWorkExperienceCategoryMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = JVMASTERWorkExperienceCategoryMaster.cmobjects.filter(pk=id).first()
                    serializer = JVMASTERWorkExperienceCategoryMasterSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if JVMASTERWorkExperienceCategoryMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = JVMASTERWorkExperienceCategoryMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': JVMASTERWorkExperienceCategoryMaster.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})