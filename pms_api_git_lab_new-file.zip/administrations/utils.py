import threading
from functools import wraps
import requests
import urllib3
from collections import OrderedDict
from colorama import Back, Style
from django.core.mail import EmailMessage
from django.db import transaction
from django.core.validators import URLValidator
from django.core.exceptions import ValidationError

from django.template.loader import get_template
from django.core.mail import EmailMultiAlternatives
from django.template import Template, Context
from sms import send_sms
import pyotp
from datetime import date, datetime, timedelta

from email_config.models import EmailTemplates,SmsTemplate

from administrations.models import *
from user_profile.models import UserProfile
from material_master.models import UnitOfMesurement
from tender.models import *
from user_permissions.models import *
from procurement.models import *
from push_notifications.models import GCMDevice
from firebase_admin import messaging
from pathlib import Path
from storages.backends.s3boto3 import S3Boto3Storage

def all_odd_saturdays(year, month):
    import calendar
    from datetime import date, timedelta
    cal = calendar.monthcalendar(year, month)
    first_week = cal[0]
    third_week = cal[2]
    fifth_week = cal[4]

    # If a Saturday presents in the first week, the second Saturday
    # is in the second week.  Otherwise, the second Saturday must
    # be in the third week.
    if first_week[calendar.SATURDAY]:
        first_saturday = first_week[calendar.SATURDAY]
    else:
        first_saturday = None

    if third_week[calendar.SATURDAY]:
        third_saturday = third_week[calendar.SATURDAY]
    else:
        third_saturday = None

    if fifth_week[calendar.SATURDAY]:
        fifth_saturday = fifth_week[calendar.SATURDAY]
    else:
        fifth_saturday = None

    result = {"first_saturday": date(year, month, first_saturday) if first_saturday else None, \
              "third_saturday": date(year, month, third_saturday) if third_saturday else None, \
              "fifth_saturday": date(year, month, fifth_saturday) if fifth_saturday else None}

    return result


def all_even_saturdays(year, month):
    import calendar
    from datetime import date, timedelta
    cal = calendar.monthcalendar(year, month)
    second_week = cal[1]
    fourth_week = cal[3]

    # If a Saturday presents in the first week, the second Saturday
    # is in the second week.  Otherwise, the second Saturday must
    # be in the third week.
    if second_week[calendar.SATURDAY]:
        second_saturday = second_week[calendar.SATURDAY]
    else:
        second_saturday = None

    if fourth_week[calendar.SATURDAY]:
        fourth_saturday = fourth_week[calendar.SATURDAY]
    else:
        fourth_saturday = None

    result = {"second_saturday": date(year, month, second_saturday) if second_saturday else None, \
              "fourth_saturday": date(year, month, fourth_saturday) if fourth_saturday else None}

    return result


def get_fortnights_for_double(year, month, first_fortnight_start, second_fortnight_end, first_fortnight_days, \
                              financial_year_start, financial_year_end):
    """
    Fortnight Calculation By Month and Year if double selected
    """
    from datetime import date, timedelta
    if financial_year_start.month == month and financial_year_start.year == year:
        first_fortnight_start = financial_year_start
        second_fortnight_start = first_fortnight_start + timedelta(days=first_fortnight_days + 1)
        second_fortnight_end = date(year, month, second_fortnight_end)
        first_fortnight_end = second_fortnight_start - timedelta(days=1)

    elif financial_year_end.month == month and financial_year_end.year == year:
        first_fortnight_start = date(year, month, first_fortnight_start)
        second_fortnight_start = first_fortnight_start + timedelta(days=first_fortnight_days + 1)
        second_fortnight_end = financial_year_end
        first_fortnight_end = second_fortnight_start - timedelta(days=1)

    else:
        print(month)
        first_fortnight_start = date(year, month, first_fortnight_start)
        second_fortnight_start = first_fortnight_start + timedelta(days=first_fortnight_days + 1)
        second_fortnight_end = date(year, int(month) + 1 if int(month) != 12 else month, second_fortnight_end)
        # if second_fortnight_end.day < second_fortnight_days:
        #     second_fortnight_end = datetime.date(year, month, 1) + datetime.timedelta(days=16)
        first_fortnight_end = second_fortnight_start - timedelta(days=1)

    result = {"first_fortnight_start": first_fortnight_start, "first_fortnight_end": first_fortnight_end, \
              "second_fortnight_start": second_fortnight_start, "second_fortnight_end": second_fortnight_end}
    return result


def get_fortnight_for_double_datewise(start_date, end_date, first_fortnight_days):
    """
    Get Fortnight For Double Datewise
    """
    from datetime import date, timedelta

    first_fortnight_start = start_date
    second_fortnight_start = first_fortnight_start + timedelta(days=first_fortnight_days)
    second_fortnight_end = end_date
    first_fortnight_end = second_fortnight_start - timedelta(days=1)

    result = {"first_fortnight_start": first_fortnight_start, "first_fortnight_end": first_fortnight_end, \
              "second_fortnight_start": second_fortnight_start, "second_fortnight_end": second_fortnight_end}
    return result


def get_fortnights_for_single(year, month, first_fortnight_start_day, financial_year_start, financial_year_end):
    """
    Fortnight Calculation By Month and Year if single selected
    """
    from datetime import date, timedelta
    if financial_year_start.month == month and financial_year_start.year == year:
        first_fortnight_start = financial_year_start
        first_fortnight_end = first_fortnight_start + timedelta(days=first_fortnight_start_day - 2)

    elif financial_year_end.month == month and financial_year_end.year == year:
        first_fortnight_start = date(year, month - 1, first_fortnight_start_day)
        first_fortnight_end = financial_year_end

    else:
        first_fortnight_start = date(year, month, first_fortnight_start_day)

        first_fortnight_end = first_fortnight_start + timedelta(days=30)

        if first_fortnight_start.day >= 20 and first_fortnight_end.day > first_fortnight_start.day:
            first_fortnight_end = date(year, month + 1, first_fortnight_start_day - 1)
        else:
            first_fortnight_end = first_fortnight_start + timedelta(days=30)

    result = {"first_fortnight_start": first_fortnight_start, "first_fortnight_end": first_fortnight_end}
    return result


def calculate_leave_pro_data_basis(organization_id, start_date, financial_year_end_date):
    """
    Calculate Leave As per user joining in an organization
    """
    from attendance.models import HrmsMaster
    from datetime import date
    from dateutil import rrule

    hr_master_details = HrmsMaster.objects.filter(organization_id=organization_id).first()

    result = []

    for dt in rrule.rrule(rrule.MONTHLY, dtstart=start_date, until=financial_year_end_date):
        result_dict = {}
        result_dict['Month'] = dt.month
        result_dict['leave_eligibility'] = hr_master_details.monthly_leave_alocation
        result_dict['Year'] = dt.year
        result.append(result_dict)

    sum = 0.0

    for item in result:
        sum = sum + float(item.get('leave_eligibility', 0))

    return sum


def calculate_leave_balance_pro_data_basis(organization_id, financial_year_start_date, end_date):
    """
    Calculate Leave As per user joining in an organization
    """
    from attendance.models import HrmsMaster
    from datetime import date
    from dateutil import rrule

    hr_master_details = HrmsMaster.objects.filter(organization_id=organization_id).first()

    result = []

    for dt in rrule.rrule(rrule.MONTHLY, dtstart=financial_year_start_date, until=end_date):
        result_dict = {}
        result_dict['Month'] = dt.month
        result_dict['leave_eligibility'] = hr_master_details.monthly_leave_alocation
        result_dict['Year'] = dt.year

        result.append(result_dict)

    print(result)

    sum = 0.0

    for item in result:
        sum = sum + float(item.get('leave_eligibility', 0))

    return sum


def find_between(s, first, last):
    try:
        start = s.index(first) + len(first)
        end = s.index(last, start)
        return s[start:end]
    except ValueError:
        return ""


class EmailThread(threading.Thread):
    """@vivek jaiswal
       Send email via anymail(sendinblue)
    """

    def __init__(self, email):
        self.email = email
        threading.Thread.__init__(self)

    def run(self):
        self.email.send()


class Util:
    @staticmethod
    def send_email(data):
        email = EmailMessage(
            subject=data['email_subject'], body=data['email_body'], to=[data['to_email']],
            headers={'Content-Type': 'text/html'})
        EmailThread(email).start()


def is_string_an_url(url_string: str) -> bool:
    validate_url = URLValidator()

    try:
        validate_url(url_string)
    except ValidationError as e:
        return False

    return True


def get_node(role, role_dict, child_roles_dict):
    """
    Get All Child Nodes Under Parent ID
    """
    node = {
        "id": role.id,
        "designation": role.designation,
        "organization": role.organization.name,
        "share_to_peer": role.share_to_peer,
        "children": []
    }

    if role.id in child_roles_dict:
        child_ids = child_roles_dict[role.id]
        for child_id in child_ids:
            child = role_dict[child_id]
            # if not child.is_deleted: # Check if the child role is not deleted
            child_node = get_node(child, role_dict, child_roles_dict)
            node["children"].append(child_node)

    return node


def trigger_notifications(action='GENERIC', subject=None, user_list=[], cc_user_list=[], context={}, attachments=[]):
    user_list = list(set(list(user_list)))
    cc_user_list = list(set(list(cc_user_list)))
    attachments = list(set(list(attachments)))
    context = json.loads(json.dumps(context,default=str))
    resp = {'email': None,'sms': None,'push': None,'error': None}
    with transaction.atomic():
        try:
            instance = NotificationMap.cmobjects.filter(action=action).first()
            if instance:
                if instance.email_is_active:
                    user_instance = PmsUser.objects.filter(id__in=user_list,is_active=True,email__isnull=False).values_list('email',flat=True)
                    if user_instance:
                        cc_user_instance = PmsUser.objects.filter(id__in=cc_user_list,is_active=True,email__isnull=False).values_list('email',flat=True)
                        if not cc_user_instance:
                            cc_user_instance = []
                        if instance.email_template.allow_cc_tag:
                            cc_user_instance.extend(list(PmsUser.objects.filter(id__in=user_list,is_active=True,reporting_manager__isnull=False,reporting_manager__is_active=True,reporting_manager__email__isnull=False).values_list('reporting_manager__email',flat=True)))
                        resp['email'] = schedule_generic_mail(subject=subject, to_mail_list=list(set(list(user_instance))), cc_mail_list=list(set(list(cc_user_instance))), context=context, template=instance.email_template, attachments=attachments)
                if instance.sms_is_active:
                    user_instance = PmsUser.objects.filter(id__in=user_list,is_active=True,user_profile__phone_no__isnull=False).values_list('user_profile__phone_no',flat=True)
                    if user_instance:
                        resp['sms'] = schedule_generic_sms(to_number_list=list(set(list(user_instance))), context=context, template=instance.sms_template)
                if instance.push_is_active:
                    tags = str(instance.push_template.tags).split(',')
                    push_context = {'action': action}
                    for tag in tags:
                        tag_parts = str(tag).split('__')
                        result = [f"[{element}]" if element.isdigit() else f"['{element}']" for element in tag_parts]
                        push_context[tag] = eval(f"context{''.join(result)}")
                    message = Template(instance.push_template.body).render(Context(context))
                    user_instance = GCMDevice.objects.filter(user_id__in=user_list,active=True).values_list('user_id',flat=True)
                    if user_instance:
                        resp['push'] = schedule_generic_push(title=subject,user_list=list(set(list(user_instance))), template=instance.push_template, processed_message=message, extra=push_context)
                    for users in user_list:
                        NotificationMaster.objects.create(
                            organization_id=instance.organization.id,
                            notified_users_id=users,
                            notification=message,
                            context=json.dumps(push_context),
                        )
        except Exception as e:
            resp['error'] = e
    # print(resp)
    return resp


def schedule_generic_mail(subject=None, to_mail_list=[], bcc_mail_list=[], cc_mail_list=[], context={}, template=None, template_name='GENERIC', processed_message=None, attachments=[]):
    instance = EmailSend.cmobjects.create(
        template = template if template else EmailTemplates.objects.filter(template_name=template_name).first(),
        to_email = ','.join(map(str, to_mail_list)) if isinstance(to_mail_list,list) else to_mail_list,
        bcc_mail_list = ','.join(map(str, bcc_mail_list)) if isinstance(bcc_mail_list,list) else bcc_mail_list,
        cc_mail_list = ','.join(map(str, cc_mail_list)) if isinstance(cc_mail_list,list) else cc_mail_list,
        subject = subject,
        context = context,
        processed_message = processed_message,
        attachments = ','.join(map(str, attachments)) if isinstance(attachments,list) else attachments,
    )
    return instance


def schedule_generic_sms(to_number_list=[], context={}, template=None, template_name='GENERIC', processed_message=None):
    instance = SMSSend.cmobjects.create(
        template = template if template else SmsTemplate.objects.filter(sms_template_name=template_name).first(),
        to_number = ','.join(map(str, to_number_list)) if isinstance(to_number_list,list) else to_number_list,
        context = context,
        processed_message = processed_message,
    )
    return instance


def schedule_generic_push(title=None,user_list=[], template=None, template_name='GENERIC', processed_message=None, extra={}):
    instance = PushSend.cmobjects.create(
        title = title,
        template = template if template else PushTemplate.objects.filter(template_name=template_name).first(),
        user_list = ','.join(map(str, user_list)) if isinstance(user_list,list) else user_list,
        processed_message = processed_message,
        extra = extra,
    )
    return instance


def send_generic_mail(instance=None):
    subject = '' if not instance.subject else instance.subject
    from_email = os.getenv('ADMIN_EMAIL','')
    to_mail_list = str(instance.to_email).split(',')
    bcc_mail_list = str(instance.bcc_mail_list).split(',')
    cc_mail_list = str(instance.cc_mail_list).split(',')
    reply_to = [os.getenv('ADMIN_EMAIL','')]
    context = instance.context
    template = instance.template
    body = html_content = instance.processed_message
    attachments = str(instance.attachments).split(',')

    if not body:
        if template:
            subject = template.subject if not subject else subject
            plaintext = Template(template.body)
            htmly = Template(template.body)
            body = plaintext.render(Context(context))
            html_content = htmly.render(Context(context))
            header_template = instance.template.header_template
            footer_template = instance.template.footer_template
            if header_template:
                header_plaintext = Template(header_template.body)
                header_htmly = Template(header_template.body)
                body = header_plaintext.render(Context(context))+body
                html_content = header_htmly.render(Context(context))+html_content
            if footer_template:
                footer_plaintext = Template(footer_template.body)
                footer_htmly = Template(footer_template.body)
                body += footer_plaintext.render(Context(context))
                html_content += footer_htmly.render(Context(context))
    msg = EmailMultiAlternatives(subject=subject, body=body, from_email=from_email, to=to_mail_list, bcc=bcc_mail_list, cc=cc_mail_list, reply_to=reply_to)
    for attachment in attachments:
        if attachment:
            ref_attachment = str(attachment).split('|')
            filename = None
            filepath = None
            filesuffix = None
            if len(ref_attachment)>1:
                filename = ref_attachment[0]
                filepath = ref_attachment[1]
            else:
                filepath = ref_attachment[0]
            temp = filepath.split('.')
            temp0 = temp[0].split('/')
            filesuffix = temp[-1]
            filename = filename if filename else temp0[-1]
            try:
                s3_storage = S3Boto3Storage(bucket_name=os.getenv('AWS_STORAGE_BUCKET_NAME', ''))
                msg.attach(f"{filename}.{filesuffix}", s3_storage._open(filepath).read())
            except Exception as e:
                print(e)

    msg.attach_alternative(html_content, "text/html")
    msg.send(fail_silently=False)
    print(Back.GREEN,"*"*100)
    print('MAIL --> SENT')
    print("subject -> ",subject)
    print("from_email -> ",from_email)
    print('to_mail_list ->', to_mail_list)
    print("bcc_mail_list -> ",bcc_mail_list)
    print("cc_mail_list -> ",cc_mail_list)
    print("reply_to -> ",reply_to)
    print("context -> ",context)
    print("template -> ",template)
    print("body -> ",body)
    print("attachments -> ",attachments)
    print("*"*100,Style.RESET_ALL)
    return msg


def send_generic_sms(instance=None):
    from_number = os.getenv('ADMIN_SMS','')
    to_number_list = str(instance.to_number).split(',')
    context = instance.context
    template = instance.template
    body = instance.processed_message
    
    if not body:
        if template:
            plaintext = Template(template.body)
            body = plaintext.render(Context(context))
    msg = send_sms(
        body,
        from_number,
        to_number_list,
        fail_silently=False
    )
    print(Back.GREEN,"*"*100)
    print('SMS --> SENT')
    print("from_number -> ",from_number)
    print("to_number_list -> ",to_number_list)
    print("context -> ",context)
    print("template -> ",template)
    print("body -> ",body)
    print("msg -> ",msg)
    print("*"*100,Style.RESET_ALL)
    return msg


def send_generic_push(instance=None):
    user_list = str(instance.user_list).split(',')
    processed_message = instance.processed_message
    extra = {str(k): str(v) for k, v in instance.extra.items()}
    title = instance.template.title if not instance.title else instance.title
    
    msg = None
    user_instance = GCMDevice.objects.filter(user_id__in=user_list,active=True)
    if user_instance:
        msg = user_instance.send_message(messaging.Message(
            data=extra,
            notification=messaging.Notification(
                title=title,
                body=processed_message
            )
        ))
    print(Back.GREEN,"*"*100)
    print('PUSH --> SENT')
    print("user_list -> ",user_list)
    print("processed_message -> ",processed_message)
    print("extra -> ",extra)
    print("msg -> ",msg)
    print("*"*100,Style.RESET_ALL)
    return msg


def send_login_otp(user):
    expiry_time = int(os.getenv('OTP_EXPIRY', '5'))
    hotp = pyotp.HOTP(pyotp.random_base32(),digits=int(os.getenv('OTP_LENGTH', '6')))
    otp_rand = int(os.getenv('OTP_RAND', '1234'))
    expiry = datetime.now() + timedelta(minutes=expiry_time)
    UserOTP.objects.create(user=user,otp_secret=hotp.secret,expiry=expiry)
    temp = trigger_notifications(action='SEND-OTP', user_list=[user.id], context={'otp': hotp.at(otp_rand),'user_full_name':user.user_full_name,'expiry_time':expiry_time})
    if temp:
        if 'email' in temp:
            if not temp['email'].is_sent:
                result = send_generic_mail(temp['email'])
                if result:
                    temp['email'].is_sent = True
                temp['email'].tried_count = temp['email'].tried_count + 1
                temp['email'].save()

def create_userwise_permissions(role_id, user_id, organization_id):
    """
    This function will automatically create userwise permissions as per role added
    """
    role_details = Profile.objects.filter(id=role_id).first()

    with transaction.atomic():
        user_perm = UserPermissions.objects.filter(organization_id=organization_id, \
                                                   role=role_details)

        user_admin_items = UserAdministrativePermissions.objects.filter(organization_id=organization_id, \
                                                                        role=role_details)

        user_settings_items = UserSettingsPermissions.objects.filter(organization_id=organization_id, \
                                                                     role=role_details)

        user_module_items = UserModulePermissions.objects.filter(organization_id=organization_id, \
                                                                 role=role_details)

        for mdv in user_module_items:
            if ModulePermissionsMaster.objects.filter(id=mdv.module_item_id).exists():
                UserWiseModulePermissions.objects.update_or_create(organization_id=organization_id, \
                                                                   user_id=user_id, \
                                                                   module_item=mdv.module_item,
                                                                   defaults={'role': role_details,
                                                                             'level_permission': mdv.level_permission})

        for item in user_perm:
            if MenuMaster.objects.filter(id=item.menu_id).exists():
                UserWisePermissions.objects.update_or_create(organization_id=organization_id, \
                                                             user_id=user_id, \
                                                             menu=item.menu, defaults={'role': role_details,
                                                                                       'has_view_permission': item.has_view_permission, \
                                                                                       'has_add_permission': item.has_add_permission,
                                                                                       'has_edit_permission': item.has_edit_permission, \
                                                                                       'has_delete_permission': item.has_delete_permission,
                                                                                       'has_export_permission': item.has_export_permission, \
                                                                                       'level_permission': item.level_permission})

            user_sub_menu_perm = UserSubModulePermissions.objects.filter(organization_id=organization_id, \
                                                                         role=role_details, menu=item.menu)

            for obj in user_sub_menu_perm:
                if SubMenuMaster.objects.filter(id=obj.sub_menu_id, menu_id=item.menu_id).exists():
                    UserWiseSubModulePermissions.objects.update_or_create(organization_id=organization_id, \
                                                                          user_id=user_id, menu=item.menu,
                                                                          sub_menu=obj.sub_menu, \
                                                                          defaults={'role': role_details,
                                                                                    'has_view_permission': obj.has_view_permission, \
                                                                                    'has_add_permission': obj.has_add_permission,
                                                                                    'has_edit_permission': item.has_edit_permission, \
                                                                                    'has_delete_permission': obj.has_delete_permission,
                                                                                    'has_export_permission': item.has_export_permission, \
                                                                                    'level_permission': obj.level_permission})

        for adv in user_admin_items:
            if AdministrativeMaster.objects.filter(id=adv.admin_item_id).exists():
                UserWiseAdministrativePermissions.objects.update_or_create(organization_id=organization_id, \
                                                                           user_id=user_id, \
                                                                           admin_item=adv.admin_item,
                                                                           defaults={'role': role_details,
                                                                                     'has_import_permission': adv.has_import_permission, \
                                                                                     'has_approval_permission': adv.has_approval_permission,
                                                                                     'has_approval_submit_permission': adv.has_approval_submit_permission, \
                                                                                     'has_export_permission': adv.has_export_permission,
                                                                                     'level_permission': adv.level_permission})

        for setn in user_settings_items:
            if SettingsMaster.objects.filter(id=setn.setting_item_id).exists():
                UserWiseSettingPermissions.objects.update_or_create(organization_id=organization_id, \
                                                                    user_id=user_id, \
                                                                    setting_item=setn.setting_item,
                                                                    defaults={'role': role_details,
                                                                              'has_view_permission': setn.has_view_permission, \
                                                                              'has_add_permission': setn.has_add_permission,
                                                                              'has_edit_permission': setn.has_edit_permission, \
                                                                              'has_delete_permission': setn.has_delete_permission,
                                                                              'has_export_permission': setn.has_export_permission, \
                                                                              'level_permission': setn.level_permission})


def executive_summary_create_for_project(tender_id, project_id):
    """
    Utility Function To Create Planning Executive Summary from tender
    """
    from tender.models import ExecutiveSummeryData
    from project_and_planning.models import PlanningExecutiveSummeryData
    from custom_management.models import FormMaster

    tender_summary_list = ExecutiveSummeryData.cmobjects.filter(tender_id=tender_id).order_by('id')

    for item in tender_summary_list:
        form_master = FormMaster.cmobjects.filter(form_label=item.form.form_label, \
                                                  form_type='planning_executive_summary').first()

        PlanningExecutiveSummeryData.objects.update_or_create(project_id=project_id, tender_id=tender_id, \
                                                              wbs=item.wbs,
                                                              defaults={'form': form_master, 'value': item.value})


def risk_create_for_project(tender_id, project_id):
    """
    Utility Function To Create Planning Executive Summary from tender
    """
    from tender.models import Riskdetails, RiskdetailsData
    from project_and_planning.models import PlanningRiskdetails, PlanningRiskdetailsData
    from custom_management.models import FormMaster

    risk_list = Riskdetails.cmobjects.filter(tender_id=tender_id).order_by('id')

    for item in risk_list:
        # form_master = FormMaster.cmobjects.filter(form_label=item.form.form_label,
        #                                           form_type='planning_risk_evaluation').first()

        # TODO: debugging done. required to discuss and test!  bug->"item.form.form_label"
        form_master = FormMaster.cmobjects.filter(form_type='planning_risk_evaluation',
                                                  form_internal_name__icontains='risk_details_planning').first()

        risk_data = RiskdetailsData.cmobjects.filter(risk_details=item).order_by('id')

        instance, created = PlanningRiskdetails.objects.get_or_create(tender_id=tender_id, \
                                                                      project_id=project_id)
        for obj in risk_data:
            PlanningRiskdetailsData.objects.update_or_create(risk_details=instance, \
                                                             defaults={'form': form_master, 'value': obj.value, \
                                                                       'table_id': obj.table_id})


def date_range_list(start_date, end_date):
    from datetime import timedelta
    # Return generator for a list datetime.date objects (inclusive) between start_date and end_date (inclusive).
    curr_date = start_date
    while curr_date <= end_date:
        yield curr_date
        curr_date += timedelta(days=1)


def get_dependent_values(qryname, organization_id, option_id):
    """
    Function To get all dependent values from desired query name(**** Required in dynamic form in dependent and condition dropdown fields)
    """

    if qryname == 'department':
        departments = Department.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from administrations.serializers import DepartmentSerializer
        serializer = DepartmentSerializer(departments, many=True)
        return serializer.data

    elif qryname == 'pmsuser':
        pms_users = PmsUser.objects.select_related("country", "state", "city").filter(organization_id=organization_id, \
                                                                                      is_deleted=False, is_active=True,
                                                                                      id__in=option_id)

        result = []

        for pms_user in pms_users:
            data = {'id': pms_user.id, 'name': pms_user.first_name + " " + pms_user.last_name, 'email': pms_user.email, \
                    'username': pms_user.username, 'address_line_1': pms_user.address_line_1,
                    'address_line_2': pms_user.address_line_2, \
                    'country': pms_user.country.name, 'state': pms_user.state.name, 'city': pms_user.city.name}
            result.append(data)

        return result

    elif qryname == 'zone':

        zone = Zone.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from adminpanel.serializers import ZoneSerializer
        serializer = ZoneSerializer(zone, many=True)

        return serializer.data

    elif qryname == 'company':
        company = Company.cmobjects.filter(organization_id=organization_id, \
                                           id__in=option_id)

        from administrations.serializers import CompanySerializer
        serializer = CompanySerializer(company, many=True)
        return serializer.data


    elif qryname == 'employee_type':
        employee_type = UserType.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from administrations.serializers import EmployeementypeSerializer
        serializer = EmployeementypeSerializer(employee_type, many=True)

        return serializer.data

    elif qryname == 'role':
        role_details = Role.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from administrations.serializers import DesignationSerializer
        serializer = DesignationSerializer(role_details, many=True)

        return serializer.data

    elif qryname == 'state':
        state_details = State.objects.filter(country_name__is_default=True, state_id__in=option_id)
        from adminpanel.serializers import StateSerializer
        serializer = StateSerializer(state_details, many=True)

        return serializer.data

    elif qryname == 'sector':
        state_details = TenderSector.cmobjects.filter(organization_id=organization_id, pk__in=option_id)
        from tender.serializers import TenderSectorSerializer
        serializer = TenderSectorSerializer(state_details, many=True)

        return serializer.data

    elif qryname == 'sub_sector':
        state_details = TenderSubSector.cmobjects.filter(organization_id=organization_id, pk__in=option_id)
        from tender.serializers import TenderSubSectorSerializer
        serializer = TenderSubSectorSerializer(state_details, many=True)

        return serializer.data

    elif qryname == 'sitelocation':
        siteLocation = SiteLocation.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from adminpanel.serializers import SiteLocationSerializer
        serializer = SiteLocationSerializer(siteLocation, many=True)

        return serializer.data

    elif qryname == 'site':
        site = SiteMaster.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from procurement.serializers import SiteMasterSerializer
        serializer = SiteMasterSerializer(site, many=True)

        return serializer.data

    elif qryname == 'city':
        city = City.objects.filter(country__is_default=True, city_id__in=option_id)
        from adminpanel.serializers import CitySerializer
        serializer = CitySerializer(city, many=True)

        return serializer.data

    elif qryname == 'account_group':
        account_group = AccountsHead.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from misc.serializers import AccountsHeadSerializer
        serializer = AccountsHeadSerializer(account_group, many=True)

        return serializer.data

    elif qryname == 'currency':
        currency = VendorCurrencyMaster.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from misc.serializers import VendorCurrencyMasterSerializer
        serializer = VendorCurrencyMasterSerializer(currency, many=True)

        return serializer.data

    elif qryname == 'executive_commitee':
        from user_profile.models import Group
        from user_profile.serializers import GroupSerializer
        group = Group.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        serializer = GroupSerializer(group, many=True)

        return serializer.data

    elif qryname == 'jv_master':

        jv_details = JVMASTER.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from administrations.serializers import JVMASTERSerializer
        serializer = JVMASTERSerializer(jv_details, many=True)

        return serializer.data

    elif qryname == 'standalone_master':

        stand_alone_details = STANDALONEMASTER.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from administrations.serializers import STANDALONEMASTERSerializer
        serializer = STANDALONEMASTERSerializer(stand_alone_details, many=True)

        return serializer.data

    elif qryname == 'employee_master':
        employee_master_details = EMPLOYEEMASTER.cmobjects.filter(organization_id=organization_id, id__in=option_id)
        from administrations.serializers import EMPLOYEEMASTERSerializer
        serializer = EMPLOYEEMASTERSerializer(employee_master_details, many=True)

        return serializer.data

    elif qryname == 'unit_of_mesurement':
        unit_of_mesurement_details = UnitOfMesurement.cmobjects.filter(organization_id=organization_id,
                                                                       id__in=option_id)
        from material_master.serializers import UnitOfMesurementSerializer
        serializer = UnitOfMesurementSerializer(unit_of_mesurement_details, many=True)
        return serializer.data

    elif qryname == 'material_master':
        vendor_materialmaster_details = VendorMaterialMaster.cmobjects.filter(organization_id=organization_id,
                                                                              id__in=option_id)
        from material_master.serializers import VendorMaterialMasterSerializer
        serializer = VendorMaterialMasterSerializer(vendor_materialmaster_details, many=True)
        return serializer.data

    elif qryname == 'plant_machinery_master':
        plant_machinery_master_details = PlantMachineryMaster.cmobjects.filter(organization_id=organization_id,
                                                                               id__in=option_id)
        from plant_machinery.serializers import PlantMachineryMasterSerializer
        serializer = PlantMachineryMasterSerializer(plant_machinery_master_details, many=True,
                                                    context={"organization_id": organization_id})
        return serializer.data


def get_dependent_values_details(qryname, organization_id, option_id):
    """
    Function To get all dependent values from desired query name(**** Required in dynamic form in dependent and condition dropdown fields)
    """

    if qryname == 'department':
        departments = Department.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from administrations.serializers import DepartmentSerializer
        serializer = DepartmentSerializer(departments)

        new_dict = {'display_name': departments.department if departments else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'pmsuser':
        pms_user = PmsUser.objects.select_related("country", "state", "city").filter(organization_id=organization_id, \
                                                                                     is_deleted=False, is_active=True,
                                                                                     id=option_id).first()

        if pms_user:
            result = [
                {'id': pms_user.id, 'name': pms_user.first_name + " " + pms_user.last_name, 'email': pms_user.email, \
                 'username': pms_user.username, 'address_line_1': pms_user.address_line_1,
                 'address_line_2': pms_user.address_line_2, \
                 'country': pms_user.country.name if pms_user.country else '',
                 'state': pms_user.state.name if pms_user.state else '',
                 'city': pms_user.city.name if pms_user.city else ''}]
        else:
            result = []

        return result

    elif qryname == 'zone':

        zone = Zone.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from adminpanel.serializers import ZoneSerializer
        serializer = ZoneSerializer(zone)

        new_dict = {'display_name': zone.zone_name if zone else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'company':
        company = Company.cmobjects.filter(organization_id=organization_id, \
                                           id=option_id).first()

        from administrations.serializers import CompanySerializer
        serializer = CompanySerializer(company)

        new_dict = {'display_name': company.name if company else ''}
        new_dict.update(serializer.data)

        return new_dict


    elif qryname == 'employee_type':
        employee_type = UserType.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from administrations.serializers import EmployeementypeSerializer
        serializer = EmployeementypeSerializer(employee_type)

        new_dict = {'display_name': employee_type.user_type if employee_type else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'role':
        role_details = Role.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from administrations.serializers import DesignationSerializer
        serializer = DesignationSerializer(role_details)

        new_dict = {'display_name': role_details.designation if role_details else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'state':
        state_details = State.objects.filter(country_name__is_default=True, state_id=option_id).first()
        from adminpanel.serializers import StateSerializer
        serializer = StateSerializer(state_details)

        new_dict = {'display_name': state_details.name if state_details else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'sector':
        state_details = TenderSector.cmobjects.filter(organization_id=organization_id, pk=option_id).first()
        from tender.serializers import TenderSectorSerializer
        serializer = TenderSectorSerializer(state_details)

        new_dict = {'display_name': state_details.name+' ('+state_details.domain+')' if state_details else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'sub_sector':
        state_details = TenderSubSector.cmobjects.filter(organization_id=organization_id, pk=option_id).first()
        from tender.serializers import TenderSubSectorSerializer
        serializer = TenderSubSectorSerializer(state_details)

        new_dict = {'display_name': state_details.name if state_details else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'sitelocation':
        siteLocation = SiteLocation.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from adminpanel.serializers import SiteLocationSerializer
        serializer = SiteLocationSerializer(siteLocation)

        new_dict = {'display_name': siteLocation.site_name if siteLocation else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'site':
        site = SiteMaster.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from procurement.serializers import SiteMasterSerializer
        serializer = SiteMasterSerializer(site)

        new_dict = {'display_name': site.site_name if site else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'city':
        city = City.objects.filter(country__is_default=True, city_id=option_id).first()
        from adminpanel.serializers import CitySerializer
        serializer = CitySerializer(city)

        new_dict = {'display_name': city.name if city else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'account_group':
        account_group = AccountsHead.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from misc.serializers import AccountsHeadSerializer
        serializer = AccountsHeadSerializer(account_group)

        new_dict = {'display_name': account_group.name if account_group else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'currency':
        currency = VendorCurrencyMaster.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from misc.serializers import VendorCurrencyMasterSerializer
        serializer = VendorCurrencyMasterSerializer(currency)

        new_dict = {'display_name': currency.name if currency else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'executive_commitee':
        from user_profile.models import Group
        from user_profile.serializers import GroupSerializer
        group = Group.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        serializer = GroupSerializer(group)

        new_dict = {'display_name': group.group_name if group else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'jv_master':

        jv_details = JVMASTER.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from administrations.serializers import JVMASTERSerializer
        serializer = JVMASTERSerializer(jv_details)

        new_dict = {'display_name': jv_details.party_name if jv_details else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'standalone_master':

        stand_alone_details = STANDALONEMASTER.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from administrations.serializers import STANDALONEMASTERSerializer
        serializer = STANDALONEMASTERSerializer(stand_alone_details)

        new_dict = {'display_name': stand_alone_details.party_name if stand_alone_details else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'employee_master':
        employee_master_details = EMPLOYEEMASTER.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from administrations.serializers import EMPLOYEEMASTERSerializer
        serializer = EMPLOYEEMASTERSerializer(employee_master_details)

        new_dict = {'display_name': employee_master_details.employee_name if employee_master_details else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'unit_of_mesurement':
        unit_of_mesurement = UnitOfMesurement.cmobjects.filter(organization_id=organization_id, id=option_id).first()
        from material_master.serializers import UnitOfMesurementSerializer
        serializer = UnitOfMesurementSerializer(unit_of_mesurement)

        new_dict = {'display_name': unit_of_mesurement.formal_name if unit_of_mesurement else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'material_master':
        vendor_materialmaster = VendorMaterialMaster.cmobjects.filter(organization_id=organization_id,
                                                                      id=option_id).first()
        from material_master.serializers import VendorMaterialMasterSerializer
        serializer = VendorMaterialMasterSerializer(vendor_materialmaster)

        new_dict = {'display_name': vendor_materialmaster.material_name if vendor_materialmaster else ''}
        new_dict.update(serializer.data)

        return new_dict

    elif qryname == 'plant_machinery_master':
        plant_machinery_master = PlantMachineryMaster.cmobjects.filter(organization_id=organization_id,
                                                                       id=option_id).first()
        from plant_machinery.serializers import PlantMachineryMasterSerializer
        serializer = PlantMachineryMasterSerializer(plant_machinery_master,
                                                    context={"organization_id": organization_id})
        plantmachinerydata = PlantMachineryData.cmobjects.filter(
            plantmachinery=plant_machinery_master,
            form__form_internal_name='plant___equipment',
            is_deleted=False
        ).order_by('by_order').first() if plant_machinery_master else ''
        new_dict = {'display_name': plantmachinerydata.value if plantmachinerydata else ''}
        new_dict.update(serializer.data)

        return new_dict


def create_dependent_formvalues_on_master_crud_operations(qryname, name, option_id):
    """
    Function To create dependent values on master table crud operations
    """
    from custom_management.models import FormDependentChoices

    FormDependentChoices.cmobjects.filter(option_id=option_id, \
                                          query_name=qryname).update(name=name)


def create_or_update_dependent_formvalues_on_master_crud_operations(qryname, name, option_id):
    """
    Function To create dependent values on master table crud operations
    """
    from custom_management.models import FormDependentChoices

    if option_id:
        FormDependentChoices.cmobjects.update_or_create(option_id=option_id, \
                                                        query_name=qryname, defaults={'name': name})
    else:
        created = FormDependentChoices.objects.create(query_name=qryname, name=name)
        created.save()


def create_tender_opportunity_default_datas(tender_id):
    """
    Utility Function To Create Tender Opportunity Datas on Each Tender Create
    """
    from custom_management.models import FormMaster
    from tender.models import Opportunitydetails, OpportunitydetailsData

    form_details = FormMaster.cmobjects.filter(form_internal_name="opportunity_details", \
                                               form_group__form_type='tender_executive_summary').first()

    with transaction.atomic():
        create_1 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_1.save()
        data_create_1 = OpportunitydetailsData.objects.create(opportunity_details=create_1, form=form_details, \
                                                              value='Value Engineering',
                                                              table_id=form_details.form_group_id)
        data_create_1.save()

        create_2 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_2.save()
        data_create_2 = OpportunitydetailsData.objects.create(opportunity_details=create_2, form=form_details, \
                                                              value='GST Inputs', table_id=form_details.form_group_id)
        data_create_2.save()

        create_3 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_3.save()
        data_create_3 = OpportunitydetailsData.objects.create(opportunity_details=create_3, form=form_details, \
                                                              value='Usages of PPC in lieu of OPC', \
                                                              table_id=form_details.form_group_id)
        data_create_3.save()

        create_4 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_4.save()
        data_create_4 = OpportunitydetailsData.objects.create(opportunity_details=create_4, form=form_details, \
                                                              value='Use of Steel Slags',
                                                              table_id=form_details.form_group_id)
        data_create_4.save()

        create_5 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_5.save()
        data_create_5 = OpportunitydetailsData.objects.create(opportunity_details=create_5, form=form_details, \
                                                              value='Usages of Fly Ash',
                                                              table_id=form_details.form_group_id)
        data_create_5.save()

        create_6 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_6.save()
        data_create_6 = OpportunitydetailsData.objects.create(opportunity_details=create_6, form=form_details, \
                                                              value='Steel Wastage Minimizing',
                                                              table_id=form_details.form_group_id)
        data_create_6.save()

        create_7 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_7.save()
        data_create_7 = OpportunitydetailsData.objects.create(opportunity_details=create_7, form=form_details, \
                                                              value='Reclaimed Asphalt Pavement',
                                                              table_id=form_details.form_group_id)
        data_create_7.save()

        create_8 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_8.save()
        data_create_8 = OpportunitydetailsData.objects.create(opportunity_details=create_8, form=form_details, \
                                                              value='Extra Claims', table_id=form_details.form_group_id)
        data_create_8.save()

        create_9 = Opportunitydetails.objects.create(tender_id=tender_id)
        create_9.save()
        data_create_9 = OpportunitydetailsData.objects.create(opportunity_details=create_9, form=form_details, \
                                                              value='Change of Scope',
                                                              table_id=form_details.form_group_id)
        data_create_9.save()


def create_tender_compliance_derivatives_default_datas(tender_id):
    """
    Utility Function To Create Tender Compliance Derivative Datas on Each Tender Create
    """
    from custom_management.models import FormMaster
    from tender.models import TenderComplianceDerivatives, TenderCompliancesData

    form_details = FormMaster.cmobjects.filter(form_internal_name="time_&_compliance_derivitives", \
                                               form_group__form_type='tender_executive_summary').first()

    with transaction.atomic():
        create_1 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_1.save()
        data_create_1 = TenderCompliancesData.objects.create(compliances=create_1, form=form_details, \
                                                             value='LoA Date -Likely/Actual',
                                                             table_id=form_details.form_group_id)
        data_create_1.save()

        create_2 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_2.save()
        data_create_2 = TenderCompliancesData.objects.create(compliances=create_2, form=form_details, \
                                                             value='Agreement Date-Likely/Actual',
                                                             table_id=form_details.form_group_id)
        data_create_2.save()

        create_3 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_3.save()
        data_create_3 = TenderCompliancesData.objects.create(compliances=create_3, form=form_details, \
                                                             value='PBG Due Date-Likely/Actual',
                                                             table_id=form_details.form_group_id)
        data_create_3.save()

        create_4 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_4.save()
        data_create_4 = TenderCompliancesData.objects.create(compliances=create_4, form=form_details, \
                                                             value='Land Acquisition /Procurement of Site',
                                                             table_id=form_details.form_group_id)
        data_create_4.save()

        create_5 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_5.save()
        data_create_5 = TenderCompliancesData.objects.create(compliances=create_5, form=form_details, \
                                                             value='Forest Land Diversions',
                                                             table_id=form_details.form_group_id)
        data_create_5.save()

        create_6 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_6.save()
        data_create_6 = TenderCompliancesData.objects.create(compliances=create_6, form=form_details, \
                                                             value='Tree Cutting', table_id=form_details.form_group_id)
        data_create_6.save()

        create_7 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_7.save()
        data_create_7 = TenderCompliancesData.objects.create(compliances=create_7, form=form_details, \
                                                             value='Utility Shiftings',
                                                             table_id=form_details.form_group_id)
        data_create_7.save()

        create_8 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_8.save()
        data_create_8 = TenderCompliancesData.objects.create(compliances=create_8, form=form_details, \
                                                             value='CAR/WCP Policy',
                                                             table_id=form_details.form_group_id)
        data_create_8.save()

        create_9 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_9.save()
        data_create_9 = TenderCompliancesData.objects.create(compliances=create_9, form=form_details, \
                                                             value='Indemnity Bond',
                                                             table_id=form_details.form_group_id)
        data_create_9.save()

        create_10 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_10.save()
        data_create_10 = TenderCompliancesData.objects.create(compliances=create_10, form=form_details, \
                                                              value='Applicable Permits',
                                                              table_id=form_details.form_group_id)
        data_create_10.save()

        create_11 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_11.save()
        data_create_11 = TenderCompliancesData.objects.create(compliances=create_11, form=form_details, \
                                                              value='Conditions Precedent',
                                                              table_id=form_details.form_group_id)
        data_create_11.save()

        create_12 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_12.save()
        data_create_12 = TenderCompliancesData.objects.create(compliances=create_12, form=form_details, \
                                                              value='Commencement/Appointment',
                                                              table_id=form_details.form_group_id)
        data_create_12.save()

        create_13 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_13.save()
        data_create_13 = TenderCompliancesData.objects.create(compliances=create_13, form=form_details, \
                                                              value='Mile Stone :-I-with content as per RFP Contract',
                                                              table_id=form_details.form_group_id)
        data_create_13.save()

        create_14 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_14.save()
        data_create_14 = TenderCompliancesData.objects.create(compliances=create_14, form=form_details, \
                                                              value='Mile Stone :-II-with content as per RFP Contract',
                                                              table_id=form_details.form_group_id)
        data_create_14.save()

        create_15 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_15.save()
        data_create_15 = TenderCompliancesData.objects.create(compliances=create_15, form=form_details, \
                                                              value='Mile Stone :-III-with content as per RFP Contract',
                                                              table_id=form_details.form_group_id)
        data_create_15.save()

        create_16 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_16.save()
        data_create_16 = TenderCompliancesData.objects.create(compliances=create_16, form=form_details, \
                                                              value='Mile Stone :-IV-with content as per RFP Contract',
                                                              table_id=form_details.form_group_id)
        data_create_16.save()

        create_17 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_17.save()
        data_create_17 = TenderCompliancesData.objects.create(compliances=create_17, form=form_details, \
                                                              value='Commercial Operation Dates',
                                                              table_id=form_details.form_group_id)
        data_create_17.save()

        create_18 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_18.save()
        data_create_18 = TenderCompliancesData.objects.create(compliances=create_18, form=form_details, \
                                                              value='Defect Liability Period',
                                                              table_id=form_details.form_group_id)
        data_create_18.save()

        create_19 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_19.save()
        data_create_19 = TenderCompliancesData.objects.create(compliances=create_19, form=form_details, \
                                                              value='O&M Period', table_id=form_details.form_group_id)
        data_create_19.save()

        create_20 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_20.save()
        data_create_20 = TenderCompliancesData.objects.create(compliances=create_20, form=form_details, \
                                                              value='Billing Cycle',
                                                              table_id=form_details.form_group_id)
        data_create_20.save()

        create_21 = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
        create_21.save()
        data_create_21 = TenderCompliancesData.objects.create(compliances=create_21, form=form_details, \
                                                              value='Audit Reports Submissions',
                                                              table_id=form_details.form_group_id)
        data_create_21.save()


def change_tender_percentage_analysis_company_data_on_master_change(old_name, new_name, company_id):
    """
    Change Tender Percentage Analysis Company Data On Master Change
    """
    from tender.models import TenderData
    tender_value_details = TenderData.cmobjects.filter(value=old_name, \
                                                       form__form_internal_name='party_name_percentage_share')

    company_details = Company.cmobjects.filter(id=company_id).first()

    with transaction.atomic():
        if tender_value_details:
            tender_value_details.update(value=new_name)

            for item in tender_value_details:
                by_order_id = item.by_order

                TenderData.cmobjects.filter(form__form_internal_name='party_address', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=company_details.party_address)

                TenderData.cmobjects.filter(form__form_internal_name='lead_member_name', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=company_details.lead_member_name)

                TenderData.cmobjects.filter(form__form_internal_name='email_id', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=company_details.email_id)

                TenderData.cmobjects.filter(form__form_internal_name='phone_no', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=company_details.phone_no)

                TenderData.cmobjects.filter(form__form_internal_name='available_threshold', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=company_details.available_threshold)

                TenderData.cmobjects.filter(form__form_internal_name='value_of_similar_works', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=company_details.value_of_similar_works)

                TenderData.cmobjects.filter(form__form_internal_name='maximum_span_length_of_bridge_avail',
                                            tender_id=item.tender_id, \
                                            by_order=by_order_id).update(
                    value=company_details.maximum_span_length_of_bridge_avail)

                TenderData.cmobjects.filter(form__form_internal_name='average_annual_turn_over',
                                            tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=company_details.average_annual_turn_over)

                TenderData.cmobjects.filter(form__form_internal_name='net_worth', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=company_details.net_worth)


def change_tender_percentage_analysis_jv_data_on_master_change(old_name, new_name, jv_id):
    """
    Change Tender Percentage Analysis JV Data On Master Change
    """
    from tender.models import TenderData
    tender_value_details = TenderData.cmobjects.filter(value=old_name, \
                                                       form__form_internal_name='party_name_percentage_share')

    jv_details = JVMASTER.cmobjects.filter(id=jv_id).first()

    with transaction.atomic():
        if tender_value_details:
            tender_value_details.update(value=new_name)

            for item in tender_value_details:
                by_order_id = item.by_order

                TenderData.cmobjects.filter(form__form_internal_name='party_address', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=jv_details.party_address)

                TenderData.cmobjects.filter(form__form_internal_name='lead_member_name', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=jv_details.lead_member_name)

                TenderData.cmobjects.filter(form__form_internal_name='email_id', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=jv_details.email_id)

                TenderData.cmobjects.filter(form__form_internal_name='phone_no', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=jv_details.phone_no)

                TenderData.cmobjects.filter(form__form_internal_name='available_threshold', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=jv_details.available_threshold)

                TenderData.cmobjects.filter(form__form_internal_name='value_of_similar_works', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=jv_details.value_of_similar_works)

                TenderData.cmobjects.filter(form__form_internal_name='maximum_span_length_of_bridge_avail',
                                            tender_id=item.tender_id, \
                                            by_order=by_order_id).update(
                    value=jv_details.maximum_span_length_of_bridge_avail)

                TenderData.cmobjects.filter(form__form_internal_name='average_annual_turn_over',
                                            tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=jv_details.average_annual_turn_over)

                TenderData.cmobjects.filter(form__form_internal_name='net_worth', tender_id=item.tender_id, \
                                            by_order=by_order_id).update(value=jv_details.net_worth)


def dumping_survey_objects_in_json_file():
    """
    Utility Function to dump objects as json from uat to dev
    """
    import json
    from custom_management.models import FormMaster, FormGroupMastr

    form_obj_list = FormMaster.cmobjects.filter(form_type='tender_survey_details').order_by('id')

    form_group_list = FormGroupMastr.cmobjects.filter(form_type='tender_survey_details').order_by('id')

    group_list = []

    form_list = []

    for item in form_group_list:
        group_dict = {}
        fields_dict = {}
        group_dict['model'] = "custom_management.formgroupmastr"
        group_dict['pk'] = item.id

        fields_dict['is_deleted'] = False
        fields_dict['created_by'] = item.created_by_id if item.created_by else None
        fields_dict['updated_by'] = item.updated_by_id if item.updated_by else None
        fields_dict['created_at'] = "2023-05-29T07:06:51.813Z"
        fields_dict['updated_at'] = "2023-05-29T07:06:51.814Z"
        fields_dict['organization'] = item.organization_id
        fields_dict['form_type'] = item.form_type
        fields_dict['name'] = item.name
        fields_dict['group_category'] = item.group_category
        fields_dict['is_skipable'] = item.is_skipable
        fields_dict['is_post'] = item.is_post
        fields_dict['is_multiple'] = item.is_multiple

        group_dict['fields'] = fields_dict

        group_list.append(group_dict)

    with open("form_group_data.json", "w") as outfile:
        json.dump(group_list, outfile)

    for obj in form_obj_list:
        form_dict = {}
        form_fields_dict = {}

        form_dict['model'] = "custom_management.formmaster"
        form_dict['pk'] = obj.id

        form_fields_dict['is_deleted'] = False
        form_fields_dict['created_by'] = obj.created_by_id if obj.created_by else None
        form_fields_dict['updated_by'] = obj.updated_by_id if obj.updated_by else None
        form_fields_dict['created_at'] = "2023-05-29T07:06:51.813Z"
        form_fields_dict['updated_at'] = "2023-05-29T07:06:51.814Z"
        form_fields_dict['organization'] = obj.organization_id
        form_fields_dict['form_group'] = obj.form_group_id
        form_fields_dict['form_type'] = obj.form_type
        form_fields_dict['form_depended_id'] = obj.form_depended_id
        form_fields_dict['form_input_type'] = obj.form_input_type
        form_fields_dict['form_label'] = obj.form_label
        form_fields_dict['form_internal_name'] = obj.form_internal_name
        form_fields_dict['form_description'] = obj.form_description
        form_fields_dict['is_required'] = obj.is_required
        form_fields_dict['is_export'] = obj.is_export
        form_fields_dict['form_category'] = obj.form_category
        form_fields_dict['sort_orders'] = obj.sort_orders
        form_fields_dict['formula_field'] = obj.formula_field

        form_dict['fields'] = form_fields_dict

        form_list.append(form_dict)

    with open("form_data.json", "w") as form_file:
        json.dump(form_list, form_file)


def generate_large_list(length, chainage):
    for i in range(0, length, chainage):
        yield i


def timer_wrapper(route_name):
    from time import time
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time()
            result = func(*args, **kwargs)
            end_time = time()
            execution_time = end_time - start_time
            print(Back.LIGHTMAGENTA_EX)
            print(f"{route_name}: {func.__name__} took {execution_time:.4f} seconds to execute.")
            print(Style.RESET_ALL)
            return result

        return wrapper

    return decorator


def hrms_request(type='get',url='',data=None,data_type='json',login=False):
    try:
        urllib3.disable_warnings()
        resp = None
        headers = {
            'Accept': 'application/json',
        }
        if not login:
            token = HRMSToken.objects.filter(username=str(os.getenv('HRMS_MASTER_USERNAME',''))).first()
            if token:
                headers['Authorization'] = 'token '+token.token
        print('-'*100)
        print('url --> ',url)
        print('data --> ',data)
        print('headers --> ',headers)
        response = eval(f'requests.{type}(url=url, {data_type}=data, headers=headers, verify=False)')
        ExternalRequests.objects.create(type=type,url=url,data=data,status_code=response.status_code,elapsed=response.elapsed)
        try:
            resp = json.loads(response.content)
            if 'detail' in resp:
                if resp['detail'] == 'Authentication credentials were not provided.':
                    login_resp = hrms_login_request()
                    if login_resp['token']:
                        hrms_request(type,url,data,data_type,login)
        except Exception as e:
            resp = response.content
        return resp
    except Exception as e:
        print('ERROR', e)
    return None


def hrms_login_request(username=None):
    try:
        username = username if username else str(os.getenv('HRMS_MASTER_USERNAME',''))
        post_data = {}
        user_instance = PmsUser.objects.filter(username=str(username)).first()
        if user_instance:
            post_data['id'] = user_instance.hrms_user_id
        response = hrms_request('post',str(os.getenv('HRMS_URL','')),post_data,'data',True)
        try:
            token = response['token']
            HRMSToken.objects.filter(username=username).update(is_deleted=True)
            HRMSToken.objects.create(username=username,token=token)
        except Exception as e:
            print('ERROR', e)
        return response
    except Exception as e:
        print('ERROR', e)
    return None


def detectBrowser(request):
    import httpagentparser
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    remote_addr = request.META.get('REMOTE_ADDR')
    user_ip = x_forwarded_for.split(',')[0] if x_forwarded_for else remote_addr

    agent = request.META.get('HTTP_USER_AGENT')
    browser = httpagentparser.detect(agent)
    browser_name = agent.split('/')[0] if not "browser" in browser.keys() else browser['browser']['name']
    os = "" if not "os" in browser.keys() else browser['os']['name']
    request.data['browser'] = browser_name
    request.data['ip'] = user_ip
    request.data['os_name'] = os
    return request


def human_time(seconds, decimals=1):
    '''Human-readable time from seconds (ie. 5 days and 2 hours).

    Examples:
        >>> human_time(15)
        '15 seconds'
        >>> human_time(3600)
        '1 hour'
        >>> human_time(3720)
        '1 hour and 2 minutes'
        >>> human_time(266400)
        '3 days and 2 hours'
        >>> human_time(-1.5)
        '-1.5 seconds'
        >>> human_time(0)
        '0 seconds'
        >>> human_time(0.1)
        '100 milliseconds'
        >>> human_time(1)
        '1 second'
        >>> human_time(1.234, 2)
        '1.23 seconds'

    Args:
        seconds (int or float): Duration in seconds.
        decimals (int): Number of decimals.

    Returns:
        str: Human-readable time.
    '''
    INTERVALS = OrderedDict([
        ('millennium', 31536000000),  # 60 * 60 * 24 * 365 * 1000
        ('century', 3153600000),      # 60 * 60 * 24 * 365 * 100
        ('year', 31536000),           # 60 * 60 * 24 * 365
        ('month', 2627424),           # 60 * 60 * 24 * 30.41 (assuming 30.41 days in a month)
        ('week', 604800),             # 60 * 60 * 24 * 7
        ('day', 86400),               # 60 * 60 * 24
        ('hour', 3600),               # 60 * 60
        ('minute', 60),
        ('second', 1)
    ])
    input_is_int = isinstance(seconds, int)
    if seconds < 0:
        return str(seconds if input_is_int else round(seconds, decimals)) + ' seconds'
    elif seconds == 0:
        return '0 seconds'
    elif 0 < seconds < 1:
        # Return in milliseconds.
        ms = int(seconds * 1000)
        return '%i millisecond%s' % (ms, 's' if ms != 1 else '')
    elif 1 < seconds < INTERVALS['minute']:
        return str(seconds if input_is_int else round(seconds, decimals)) + ' seconds'

    res = []
    for interval, count in INTERVALS.items():
        quotient, remainder = divmod(seconds, count)
        if quotient >= 1:
            seconds = remainder
            if quotient > 1:
                # Plurals.
                if interval == 'millennium':
                    interval = 'millennia'
                elif interval == 'century':
                    interval = 'centuries'
                else:
                    interval += 's'
            res.append('%i %s' % (int(quotient), interval))
        if remainder == 0:
            break

    if len(res) >= 2:
        # Only shows 2 most important intervals.
        return '{} and {}'.format(res[0], res[1])
    return res[0]