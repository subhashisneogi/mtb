from django.urls import path
from administrations import views
from django.contrib.auth import views as auth_views
# from rest_framework_simplejwt.views import (
#     TokenRefreshView,
# )


urlpatterns = [
    path('login/', views.LoginView.as_view(), name='knox_login'),
    path('logout/', views.LogoutView.as_view(), name='knox_logout'),
    path('auto-logout/<pk>', views.AutoLogoutView.as_view()),
    path('request-otp/', views.RequestOTPAPIView.as_view()),
    path('user-validate/', views.UserValidateView.as_view()),
    path('request-reset-email/', views.SendResetPasswordLinkAPIView.as_view(),  # validate email of existing users
         name="request-reset-email"),
    path('password-reset/<uidb64>/<token>/',
         views.PasswordTokenCheckApi.as_view(), name='password-reset-confirm'),  # validate link or token
    # path('forgetPassword/reset/<uidb64>/<token>/',
    #      views.PasswordTokenCheckApi.as_view(), name='password-reset-confirm'),
    path('password-reset-complete/', views.SetNewPassWordAPIView.as_view(),
         name='password-reset-complete'),  # set new password


    path('company_crud/', views.CompanyAPIView.as_view()),
    path('employee_type_crud/', views.EmployeementypeAPIView.as_view()),
    path('designation_crud/', views.DesignationAPIView.as_view()),
    path('department_crud/', views.DepartmentAPIView.as_view()),
    path('user_role_crud/', views.UserRoleAPIView.as_view()),
    path('user_role_crud_new/', views.UserRoleNewAPIView.as_view()),

    path('role_permission_create/', views.RolesPermissionCreate.as_view()),

    path('role_permission_create_user_wise/',
         views.UserWiseProfilePermissionCreate.as_view()),

    path('menu_list/', views.MenuListAPIView.as_view()),
    path('form_menu_list/', views.FormMenuListAPIView.as_view()),
    path('form_menu_list_for_planning/', views.FormMenuListForPlanningAPIView.as_view()),
    path('administrative_list/', views.AdministrativeMasterListAPIView.as_view()),
    path('module_permission_list/', views.ModuleMasterListAPIView.as_view()),
    path('setting_list/', views.SettingsMasterListAPIView.as_view()),

    path('log_activity_track/', views.LoginLogoutAPIView.as_view()),

    path('RoleTreeAPIView/', views.RoleTreeAPIView.as_view()),

    path('comapny_wise_role_tree/', views.CompanyWiseRoleTreeAPI.as_view()),

    path('settings_group_master_api/', views.SettingsGroupMasterAPIView.as_view()),

    path('coming_birthday/', views.UpcomingBirthdaysAPIView.as_view()),

    path('new_joiners/', views.NewJoinersView.as_view()),
    path('noticeboard/', views.NoticeBoardListAPIView.as_view()),

    path('user_permission_list/', views.UserTypePermissions.as_view()),

    path('jv_master_work-experience-category-master/', views.JVMASTERWorkExperienceCategoryMasterAPIView.as_view()), 
    path('jw_master_crud/', views.JVMASTERAPIView.as_view()), 
    path('jv-master-documents/', views.JVMASTERDocumentAPIView.as_view()), 
    path('standalone_master_crud/', views.STANDALONEMASTERAPIView.as_view()), 

    path('employee_master_crud/', views.EMPLOYEEMASTERAPIView.as_view()), 

    path('notification_master/', views.NotificationMasterAPIView.as_view()),

    path('delay_reason_master/', views.DelayReasonAPIView.as_view()),

    path('update_new_permissions/', views.UpdateNewPermissionsAPIView.as_view()),
    path('pms_user_stats/', views.PmsUserStatsAPIView.as_view()),
    path('holiday-calendar/', views.HolidayCalendarAPIView.as_view()),
     


]
