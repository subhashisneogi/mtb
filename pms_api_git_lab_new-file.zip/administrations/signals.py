import pprint
import random
import time
from datetime import date, datetime


import colorama
from django.db import transaction
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import *
from .utils import hrms_request


def json_serial(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    elif isinstance(obj, dict):
        # Serialize dictionaries by converting them to JSON-compatible strings
        return {str(key): str(value) for key, value in obj.items()}
    raise TypeError(f"{'--'*20}\n", f"Type {type(obj)} not serializable", f"\n{'--'*20}")

def sync_user_hrms(instance, type='add'):
    user_dict = {}
    for field in instance._meta.fields:
        user_dict[field.name] = getattr(instance, field.name)

    pp = pprint.PrettyPrinter(indent=1)
    pp.pprint(user_dict)

    email = user_dict.get('email', None)
    first_name = user_dict.get('first_name', None)
    last_name = user_dict.get('last_name', None)
    organization_id = user_dict.get('organization', None)
    zone_id = user_dict.get('zone', None)
    employement_type_id = user_dict.get('employement_type', None)
    company_name_id = user_dict.get('company_name', None)
    designation_id = user_dict.get('designation', None)
    department_id = user_dict.get('department', None)
    reporting_manager_id = user_dict.get('reporting_manager', None)
    role_id = user_dict.get('role', None)
    country_id = user_dict.get('country', None)
    state_id = user_dict.get('state', None)
    city_id = user_dict.get('city', None)
    aadhar_number = user_dict.get('aadhar_number', None)
    pan_number = user_dict.get('pan_number', None)
    gender = user_dict.get('gender', None)
    blood_group = user_dict.get('blood_group', None)
    phone_no = user_dict.get('phone_no', None)
    notice_period = user_dict.get('notice_period', None)
    employe_code = user_dict.get('employe_code', None)
    joining_date = user_dict.get('joining_date', None)
    last_working_date = user_dict.get('last_working_date', None)
    date_of_birth = user_dict.get('date_of_birth', None)
    address_line_1 = user_dict.get('address_line_1', None)
    address_line_2 = user_dict.get('address_line_2', None)
    hrms_user_id = user_dict.get('hrms_user_id', None)


    if type == 'add':
        current_datetime = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        try:
            if not hrms_user_id:
                # STEP - 1
                post_data = {
                    'list_type': 'professional',
                    'sap_personnel_no': str(random.randrange(1, 10**3)).zfill(3) + str(time.time()).replace(".", "")[:5],
                    'retirement_date': '2050-01-11T10:39:07.936452Z',
                    'daily_loginTime': '00:00:00',
                    'daily_logoutTime': '00:00:00',
                    'lunch_start': '13:15:00',
                    'lunch_end': '13:45:00',
                    'cu_punch_id': str(random.randrange(1, 10**3)).zfill(3) + str(time.time()).replace(".", "")[:3],
                    'cu_phone_no': phone_no if phone_no else str(random.randrange(1, 10 ** 3)).zfill(3) + str(time.time()).replace(".", "")[:7],
                    'joining_date': current_datetime,
                    'cu_alt_email_id': email if email else '',
                    'salary_type': int(os.getenv('HRMS_SALARY_TYPE', '')),
                    'grade': os.getenv('HRMS_SALARY_GRAD', ''),
                    'department': int(os.getenv('HRMS_DEPARTMENT', '')),
                    'attendance_type': 'PMS',

                    'username': email,
                    'email': email,
                    'first_name': first_name,
                    'last_name': last_name,
                }
                if reporting_manager_id:
                    if reporting_manager_id.hrms_user_id and not (reporting_manager_id.hrms_user_id == -1):
                        post_data['reporting_head'] = reporting_manager_id.hrms_user_id
                hrms_user_add = hrms_request('post', os.getenv('HRMS_USER_ADD',''), post_data)

                print('url', os.getenv('HRMS_USER_ADD',''))
                print(colorama.Back.GREEN, 'hrms_user_add', colorama.Style.RESET_ALL)
                print(hrms_user_add)

                # STEP - 2
                # Add PmsUser.hrms_user_id
                hrms_user_id = hrms_user_add.get('id', -1)
                print('hrms_user_id', hrms_user_id)
                instance.hrms_user_id = hrms_user_id
                instance.save()
        except Exception as e:
            print('ADD ERROR', e)

    if type == 'edit':
        # get data
        print(f'{"-"*20}')
        print('---GET DATA---')
        hrms_user_dict = {}

        try:
            end_point = f"{os.getenv('HRMS_USER_EDIT','')}{instance.hrms_user_id}/?list_type=personal"
            print('edit point url: ', end_point)
            hrms_user_edit_get = hrms_request('get', end_point, None)
            hrms_user_dict = hrms_user_edit_get.get("result") if hrms_user_edit_get and hasattr(hrms_user_edit_get, 'result') else user_dict
            print('edit response: ', hrms_user_dict)
            entries_to_remove = ('id', 'password', 'image', 'organization', 'employement_type', 'company_name', 'department', 'reporting_manager', 'designation', 'role', 'country', 'state', 'city', 'zone', 'deleted_by', 'created_by',)
            for k in entries_to_remove:
                hrms_user_dict.pop(k, None)
        except Exception as e:
            print('ERROR', e)

        # set data
        try:
            print(f'{"+" * 20}')
            print('SET DATA')
            post_data = {
                'username': email,
                'email': email,
                'first_name': first_name,
                'last_name': last_name,
                'cu_phone_no': phone_no if phone_no else str(random.randrange(1, 10 ** 3)).zfill(3) + str(
                    time.time()).replace(".", "")[:7],
            }
            if reporting_manager_id:
                if reporting_manager_id.hrms_user_id and not (reporting_manager_id.hrms_user_id == -1):
                    post_data['reporting_head'] = reporting_manager_id.hrms_user_id
            hrms_user_dict.update(post_data)

            hrms_user_dict = json_serial(hrms_user_dict)
            print('1... UPDATED `hrms_user_dict`', hrms_user_dict)
            end_point = f"{os.getenv('HRMS_USER_EDIT','')}{instance.hrms_user_id}/?list_type=personal"
            print('hrm_user/edit/set_data/end_point: ', end_point)
            hrms_user_edit = hrms_request('put', end_point, hrms_user_dict)
            print('hrms_user_edit/set data/response:')
            print(hrms_user_edit)
        except Exception as e:
            print('EDIT ERROR: ', e)


@receiver(post_save, sender=PmsUser)
def signal_pms_user(sender, instance, created, **kwargs):
    with transaction.atomic():
        if bool(int(str(os.getenv('HRMS_SYNC','0')))) and instance:
            if created:
                print(colorama.Back.CYAN, "in signal PmsUser created", colorama.Style.RESET_ALL)
                sync_user_hrms(instance, 'add')
            if not created:
                print(colorama.Back.BLUE, "in signal PmsUser updated", colorama.Style.RESET_ALL)
                sync_user_hrms(instance, 'edit')

