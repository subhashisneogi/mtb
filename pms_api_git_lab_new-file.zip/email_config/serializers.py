from rest_framework import serializers
from .models import *


class EmailTagSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmailTag
        fields = '__all__'

class SmsTagSerializer(serializers.ModelSerializer):
    class Meta:
        model = SmsTag
        fields = '__all__'



class EmailLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmailLog
        fields = '__all__'



class EmailtemplateTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmailtemplateType
        fields = '__all__'

class SmstemplateTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = SmstemplateType
        fields = '__all__'

class SmsTemplateSerializer(serializers.ModelSerializer):
    template_type=SmstemplateTypeSerializer()
    
    class Meta:
        model = SmsTemplate
        fields = '__all__'

class EmailTemplatesSerializer(serializers.ModelSerializer):
    tags = EmailTagSerializer(many=True)
    email_template_type = EmailtemplateTypeSerializer()
    body = serializers.SerializerMethodField()

    def get_body(self,instance):
        if instance.body:
            import base64
            details = base64.b64encode(bytes(instance.body, 'utf-8')) # bytes
            return details
        else:
            return None
    class Meta:
        model = EmailTemplates
        fields = '__all__'
