import base64
from django.core.files.base import ContentFile
from django.utils.text import slugify
from rest_framework.views import APIView
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.exceptions import APIException
from .models import EmailTemplates,EmailTag
from .serializers import *
from django.core.paginator import Paginator
from administrations.models import  Organization
from django.conf import settings
from datetime import datetime, timedelta
from procurement.models import *
from tender.models import TenderChecklistMaster, TenderDepartmentMaster
class EmailTemplatesView(generics.CreateAPIView):
    """
    View to create new EmailTemplates
    """
    
    def post(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            template_name = request.data.get('template_name', None)
            subject = request.data.get('subject', None)
            base64_data = request.data.get('body', None)
            from_name = request.data.get('from_name', None)
            from_email = request.data.get('from_email', None)
            tags = list(request.data.get('tags', []))
            template_type = request.data.get('template_type', None)
            if not base64_data:
                return Response({"error": "Please provide a base64 encoded data in 'body' field."}, status=status.HTTP_400_BAD_REQUEST)

            # decode base64 data to string
            decoded_data = base64.b64decode(base64_data).decode("utf-8")
            # print(decoded_data)
            # convert string to HTML
            html_data = decoded_data
            
            # generate unique template_name and slugify it
            if not template_name:
                template_name = subject
                template_name = template_name + '-' + slugify(template_name)
            print(template_name )
            #create and save instance
            email_template_qry = EmailTemplates.cmobjects.filter(template_name=template_name,organization_id=organization_id)
            if email_template_qry.exists():
                raise APIException({'request_status': 0, 'msg': "Template name already exists "})

            else:
                email_template  = EmailTemplates.objects.create(template_name=template_name,
                                                                organization_id=organization_id,email_template_type_id=template_type,
                                                                subject=subject,body=html_data,from_name=from_name,from_email=from_email,
                                                                created_by=request.user)
                email_template.save()
                for data in tags:
                    # print(EmailTag.objects.get(id=data))
                    email_template.tags.add(EmailTag.objects.get(id=data))
                # return serialized data
                serializer = EmailTemplatesSerializer(email_template)
                return Response({'results':{
                                            'Data':serializer.data ,
                                            },
                                            'msg': 'Successfully created Template',
                                            'status':status.HTTP_201_CREATED,
                                            "request_status": 1})
        except Exception as e:
             return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
         
    """
    View to create new EmailTemplates
    """

    def get(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            template_id = self.request.query_params.get('template_id', None)
            print(template_id)
            if template_id:
                email_template = EmailTemplates.objects.get(id=template_id,organization_id=organization_id,is_deleted=False)
                serializer = EmailTemplatesSerializer(email_template)
                return Response({'results': serializer.data,
                    'msg': 'Successfully retrieved template',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})
            else:
                email_templates = EmailTemplates.objects.filter(organization_id=organization_id,\
                                                                is_deleted=False).order_by('-id')
                page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
                paginator = Paginator(email_templates, page_size)
                page_number = self.request.query_params.get('page', 1)
                page = paginator.get_page(page_number)
                serializer = EmailTemplatesSerializer(page, many=True)
                return Response({
                    'count': paginator.count,
                    'next': page.next_page_number() if page.has_next() else None,
                    'previous': page.previous_page_number() if page.has_previous() else None,
                    'results': serializer.data,
                })

        except EmailTemplates.DoesNotExist:
            return Response({'results': {
                'Data': {},
            },
                'msg': 'Email template does not exist',
                'status': status.HTTP_404_NOT_FOUND,
                "request_status": 0})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
    def put(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            template_id = self.request.query_params.get('template_id', None)
            if not template_id:
                return Response({"error": "Please provide a template id."}, status=status.HTTP_400_BAD_REQUEST)
            
            method = self.request.query_params.get('method', None)
            if not method:
                return Response({"error": "Please provide a method in query parameters (either 'edit' or 'delete' of 'status' for status change)."}, status=status.HTTP_400_BAD_REQUEST)

            email_template = EmailTemplates.cmobjects.get(id=template_id,\
                                                        organization_id=organization_id)

            if method.lower() == 'edit':
                template_name = request.data.get('template_name')
                email_template_qry = EmailTemplates.cmobjects.filter(template_name=template_name,\
                                                                   organization_id=organization_id).exclude(id=email_template.id)
                # print("email_template_qry",email_template_qry)
                if email_template_qry.exists():
                    raise APIException({'request_status': 0, 'msg': "Template name already exists "})
                else:
                # update the email template with the new data
                    template_name = request.data.get('template_name', email_template.template_name)
                    subject = request.data.get('subject', email_template.subject)
                    base64_data = request.data.get('body', None)
                    from_name = request.data.get('from_name', email_template.from_name)
                    from_email = request.data.get('from_email', email_template.from_email)
                    template_type = request.data.get('template_type', email_template.email_template_type_id)
                    tags = list(request.data.get('tags', []))
                    if base64_data:
                        decoded_data = base64.b64decode(base64_data).decode("utf-8")
                        html_data = decoded_data
                        email_template.body = html_data

                    email_template.template_name = template_name
                    email_template.subject = subject
                    email_template.from_name = from_name
                    email_template.from_email = from_email
                    email_template.email_template_type_id = template_type
                    email_template.updated_by=request.user
                    email_template.tags.clear()
                    for tag_id in tags:
                        email_template.tags.add(tag_id)

                    email_template.save()

                    serializer = EmailTemplatesSerializer(email_template)
                    return Response({'results': {
                        'Data': serializer.data,
                    },
                        'msg': 'Successfully updated email template',
                        'status': status.HTTP_200_OK,
                        "request_status": 1})
            elif method.lower() == 'status':
                set_status = request.data.get('status', email_template.is_active)
                email_template.updated_by=request.user
                email_template.is_active = set_status
                email_template.save()
                serializer = EmailTemplatesSerializer(email_template)
                return Response({'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully updated status for email template',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})
            elif method.lower() == 'delete':
                email_template = EmailTemplates.objects.get(id=template_id,organization_id=organization_id)
                email_template.is_deleted = True
                email_template.save()
                serializer = EmailTemplatesSerializer(email_template)
                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Successfully deleted email template',
                                        'status':status.HTTP_202_ACCEPTED,
                                        "request_status": 1})
            else:
                return Response({"error": "Invalid method provided. Please provide 'edit' or 'delete'."}, status=status.HTTP_400_BAD_REQUEST)

        except EmailTemplates.DoesNotExist:
            return Response({'results': {
                'Data': {},
            },
                'msg': 'Email template does not exist',
                'status': status.HTTP_404_NOT_FOUND,
                "request_status": 0})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        
class EmailTagView(APIView):
    """
    View to handle EmailTag objects.
    """

    def get(self, request):
        """
        Retrieve all EmailTag objects.
        """
        organization_id = self.request.query_params.get('organization_id', None)
        tags = EmailTag.objects.filter(organization_id=organization_id)
                   
        try:
            page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
            paginator = Paginator(tags, page_size)
            page_number = self.request.query_params.get('page', 1)
            page = paginator.get_page(page_number)
            serializer = EmailTagSerializer(page, many=True)
            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': serializer.data,
            })
        except Organization.DoesNotExist:
                return Response(status=status.HTTP_404_NOT_FOUND)
    def post(self, request):
        """
        Create a new EmailTag object.
        """
        organization_id = self.request.query_params.get('organization_id', None)
        serializer = EmailTagSerializer(data=request.data)
        if serializer.is_valid():
            
            organization = Organization.objects.get(id=organization_id)
            serializer.save(organization=organization)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, *args, **kwargs):
        """
        Edit or delete an existing EmailTag object.
        """
        try:
            organization_id = request.query_params.get('organization_id')
            tag_id = self.request.query_params.get('tag_id', None)
            if not tag_id:
                return Response({"error": "Please provide a tag id."}, status=status.HTTP_400_BAD_REQUEST)
            
            method = self.request.query_params.get('method', None)
            if not method:
                return Response({"error": "Please provide a method in query parameters (either 'edit' or 'delete')."}, status=status.HTTP_400_BAD_REQUEST)

            email_tag = EmailTag.objects.get(id=tag_id,organization_id=organization_id)

            if method.lower() == 'edit':
                # update the email template with the new data
                name = request.data.get('name', email_tag.name)
                email_tag.organization_id = organization_id
                email_tag.name = name
                email_tag.save()

                serializer = EmailTagSerializer(email_tag)
                return Response({'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully updated email tag',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})

            elif method.lower() == 'delete':
                email_tag.delete()
                serializer = EmailTagSerializer(email_tag)
                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Successfully deleted email tag',
                                        'status':status.HTTP_202_ACCEPTED,
                                        "request_status": 1})
            else:
                return Response({"error": "Invalid method provided. Please provide 'edit' or 'delete'."}, status=status.HTTP_400_BAD_REQUEST)

        except EmailTag.DoesNotExist:
            return Response({'results': {
                'Data': {},
            },
                'msg': 'Email tag does not exist',
                'status': status.HTTP_404_NOT_FOUND,
                "request_status": 0})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        
class SmsTagView(APIView):
    """
    View to handle SmsTag objects.
    """

    def get(self, request):
        """
        Retrieve all SmsTag objects.
        """
        organization_id = self.request.query_params.get('organization_id', None)
        tags = SmsTag.objects.filter(organization_id=organization_id)

        try:
            page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
            paginator = Paginator(tags, page_size)
            page_number = self.request.query_params.get('page', 1)
            page = paginator.get_page(page_number)
            serializer = SmsTagSerializer(page, many=True)
            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': serializer.data,
            })
        except Organization.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

    def post(self, request):
        """
        Create a new SmsTag object.
        """
        organization_id = self.request.query_params.get('organization_id', None)
        serializer = SmsTagSerializer(data=request.data)
        if serializer.is_valid():
            organization = Organization.objects.get(id=organization_id)
            serializer.save(organization=organization)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, *args, **kwargs):
        """
        Edit or delete an existing SmsTag object.
        """
        try:
            organization_id = request.query_params.get('organization_id')
            tag_id = self.request.query_params.get('tag_id', None)
            if not tag_id:
                return Response({"error": "Please provide a tag id."}, status=status.HTTP_400_BAD_REQUEST)

            method = self.request.query_params.get('method', None)
            if not method:
                return Response({"error": "Please provide a method in query parameters (either 'edit' or 'delete')."}, status=status.HTTP_400_BAD_REQUEST)

            sms_tag = SmsTag.objects.get(id=tag_id, organization_id=organization_id)

            if method.lower() == 'edit':
                # update the SMS tag with the new data
                name = request.data.get('name', sms_tag.name)
                sms_tag.organization_id = organization_id
                sms_tag.name = name
                sms_tag.save()

                serializer = SmsTagSerializer(sms_tag)
                return Response({'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully updated SMS tag',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})

            elif method.lower() == 'delete':
                sms_tag.delete()
                serializer = SmsTagSerializer(sms_tag)
                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Successfully deleted SMS tag',
                                        'status':status.HTTP_202_ACCEPTED,
                                        "request_status": 1})
            else:
                return Response({"error": "Invalid method provided. Please provide 'edit' or 'delete'."}, status=status.HTTP_400_BAD_REQUEST)

        except SmsTag.DoesNotExist:
            return Response({'results': {
                'Data': {},
            },
                'msg': 'SMS tag does not exist',
                'status': status.HTTP_404_NOT_FOUND,
                "request_status": 0})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class SmsTemplateView(APIView):
    """
    SMS template view
    """
    def get(self, request):
        organization_id = request.query_params.get('organization_id')
        if organization_id:
            try:
                organization = Organization.objects.get(pk=organization_id)
                sms_templates = SmsTemplate.objects.filter(organization=organization).order_by('-id')
                page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
                paginator = Paginator(sms_templates, page_size)
                page_number = self.request.query_params.get('page', 1)
                page = paginator.get_page(page_number)
                serializer = SmsTemplateSerializer(page, many=True)
                return Response({
                    'count': paginator.count,
                    'next': page.next_page_number() if page.has_next() else None,
                    'previous': page.previous_page_number() if page.has_previous() else None,
                    'results': serializer.data,
                })

            except Organization.DoesNotExist:
                return Response(status=status.HTTP_404_NOT_FOUND)
        else:
            return Response({'results': {
                'Data': {},
            },
                'msg': 'Something went wrong. If the problem persists, please contact support., Please provide valid organization_id',
                'status': status.HTTP_404_NOT_FOUND,
                "request_status": 0})

    def post(self, request):
        """
        Create a new SMS Template object.
        """
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            sms_template_name=request.data.get('sms_template_name', None)
            tags = list(request.data.get('tags', []))
            template_type = request.data.get('template_type', None)
            body= request.data.get('body', None)
            #create and save instance
            sms_template_qry = SmsTemplate.objects.filter(sms_template_name=sms_template_name,organization_id=organization_id)
            if sms_template_qry.exists():
                raise APIException({'request_status': 0, 'msg': "Sms Template name already exists "})
            else:
                sms_template  = SmsTemplate.objects.create(
                                                            organization_id=organization_id,template_type_id=template_type,
                                                            sms_template_name=sms_template_name,body=body)
                sms_template.save()
                for data in tags:
                    sms_template.tags.add(SmsTag.objects.get(id=data))
                # return serialized data
                serializer = SmsTemplateSerializer(sms_template)
                return Response({'results':{
                                    'Data':serializer.data ,
                                    },
                                    'msg': 'Successfully created Sms Template',
                                    'status':status.HTTP_201_CREATED,
                                    "request_status": 1})
        except Exception as e:
             return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request):
        """_summary_

        Edit and delete method for SmsTemplate
        """
        sms_template_id = request.query_params.get('template_id')
        organization_id = self.request.query_params.get('organization_id', None)
        if sms_template_id:
            try:
                sms_template = SmsTemplate.objects.get(id=sms_template_id,organization_id=organization_id)
                method = request.query_params.get('method')
                if method == 'edit':
                    sms_template_name = request.data.get('sms_template_name')
                    try:
                        sms_template_qry = SmsTemplate.objects.filter(sms_template_name=sms_template_name,\
                                                                      organization_id=organization_id).exclude(sms_template_name=sms_template.sms_template_name)
                        if sms_template_qry.exists():
                            raise APIException({'request_status': 0, 'msg': "Sms Template name already exists "})
                        else:
                            sms_template_name = sms_template_name
                            body = request.data.get('body', sms_template.body)
                            template_type = request.data.get('template_type', sms_template.template_type)
                            tags = list(request.data.get('tags', []))

                            sms_template.sms_template_name = sms_template_name
                            sms_template.body = body
                            sms_template.template_type_id = template_type
                            sms_template.tags.clear()
                            for tag_id in tags:
                                sms_template.tags.add(tag_id)

                            sms_template.save()
                            serializer = SmsTemplateSerializer(sms_template)
                            return Response({'results': {
                                    'Data': serializer.data,
                                                },
                                'msg': 'Updated successfully',
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                    except Exception as e:
                        return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
                elif method == 'delete':
                    sms_template.delete()
                    return Response({'results': {
                        'Data': {},
                                    },
                    'msg': 'Deleted successfully',
                    'status': status.HTTP_204_NO_CONTENT,
                    "request_status": 1})
                else:
                    return Response({'msg': 'Invalid method parameter.'}, status=status.HTTP_400_BAD_REQUEST)
                
            except SmsTemplate.DoesNotExist:
                return Response(status=status.HTTP_404_NOT_FOUND)
        else:
            return Response({'msg': 'SMS template ID not provided.'}, status=status.HTTP_400_BAD_REQUEST)
        
        
        
class EmailtemplateTypeView(APIView):
    """
    View to handle EmailtemplateType objects.
    """

    def get(self, request):
        """
        Retrieve all EmailtemplateType objects.
        """
        organization_id = self.request.query_params.get('organization_id', None)
        templates = EmailtemplateType.objects.filter(organization_id=organization_id)
                   
        try:
            page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
            paginator = Paginator(templates, page_size)
            page_number = self.request.query_params.get('page', 1)
            page = paginator.get_page(page_number)
            serializer = EmailtemplateTypeSerializer(page, many=True)
            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': serializer.data,
            })
        except Organization.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def post(self, request):
        """
        Create a new EmailtemplateType object.
        """
        organization_id = self.request.query_params.get('organization_id', None)
        serializer = EmailtemplateTypeSerializer(data=request.data)
        if serializer.is_valid():
            emtp_type_name = serializer.validated_data.get('emtp_type_name')
            organization = Organization.objects.get(id=organization_id)
            if EmailtemplateType.objects.filter(emtp_type_name=emtp_type_name, organization=organization).exists():
                return Response({'msg': 'An EmailtemplateType object with the same emtp_type_name already exists for this organization.'}, status=status.HTTP_400_BAD_REQUEST)
            serializer.save(organization=organization)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, *args, **kwargs):
        """
        Edit or delete an existing EmailtemplateType object.
        """
        try:
            organization_id = request.query_params.get('organization_id')
            template_id = self.request.query_params.get('template_id', None)
            if not template_id:
                return Response({"msg": "Please provide a template id."}, status=status.HTTP_400_BAD_REQUEST)
            
            method = self.request.query_params.get('method', None)
            if not method:
                return Response({"msg": "Please provide a method in query parameters (either 'edit' or 'delete')."}, status=status.HTTP_400_BAD_REQUEST)

            email_template = EmailtemplateType.objects.get(id=template_id, organization_id=organization_id)

            if method.lower() == 'edit':
                # update the email template with the new data
                name = request.data.get('emtp_type_name', email_template.emtp_type_name)
                email_template.organization_id = organization_id
                email_template.emtp_type_name = name
                email_template.updated_by=request.user
                email_template.save()

                serializer = EmailtemplateTypeSerializer(email_template)
                return Response({'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully updated email template type name',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})

            elif method.lower() == 'delete':
                email_template = EmailtemplateType.objects.get(id=template_id,organization_id=organization_id)
                email_template.is_deleted = True
                email_template.save()
                serializer = EmailtemplateTypeSerializer(email_template)
                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Successfully deleted email template type',
                                        'status':status.HTTP_202_ACCEPTED,
                                        "request_status": 1})
            else:
                return Response({"msg": "Invalid method provided. Please provide 'edit' or 'delete'."}, status=status.HTTP_400_BAD_REQUEST)

        except EmailtemplateType.DoesNotExist:
            return Response({'results': {
                'Data': {},
            },
                'msg': 'Email template type does not exist',
                'status': status.HTTP_404_NOT_FOUND,
                "request_status": 0})
        except Exception as e:
            return Response({"msg": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        
class SmstemplateTypeView(APIView):
    """
    View to handle SmstemplateType objects.
    """

    def get(self, request):
        """
        Retrieve all SmstemplateType objects.
        """
        organization_id = self.request.query_params.get('organization_id', None)
        templates = SmstemplateType.objects.filter(organization_id=organization_id)
                   
        try:
            page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
            paginator = Paginator(templates, page_size)
            page_number = self.request.query_params.get('page', 1)
            page = paginator.get_page(page_number)
            serializer = SmstemplateTypeSerializer(page, many=True)
            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': serializer.data,
            })
        except Organization.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def post(self, request):
        """
        Create a new SmstemplateType object.
        """
        organization_id = self.request.query_params.get('organization_id', None)
        serializer = SmstemplateTypeSerializer(data=request.data)
        if serializer.is_valid():
            smtp_type_name = serializer.validated_data.get('smtp_type_name')
            organization = Organization.objects.get(id=organization_id)
            if SmstemplateType.objects.filter(smtp_type_name=smtp_type_name, organization=organization).exists():
                return Response({'msg': 'An SmstemplateType object with the same smtp_type_name already exists for this organization.'}, status=status.HTTP_400_BAD_REQUEST)
            serializer.save(organization=organization,created_by=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, *args, **kwargs):
        """
        Edit or delete an existing SmstemplateType object.
        """
        try:
            organization_id = request.query_params.get('organization_id')
            template_id = self.request.query_params.get('template_id', None)
            if not template_id:
                return Response({"msg": "Please provide a template id."}, status=status.HTTP_400_BAD_REQUEST)
            
            method = self.request.query_params.get('method', None)
            if not method:
                return Response({"msg": "Please provide a method in query parameters (either 'edit' or 'delete')."}, status=status.HTTP_400_BAD_REQUEST)

            sms_template = SmstemplateType.objects.get(id=template_id, organization_id=organization_id)

            if method.lower() == 'edit':
                # update the sms template with the new data
                name = request.data.get('smtp_type_name', sms_template.smtp_type_name)
                sms_template.organization_id = organization_id
                sms_template.smtp_type_name = name
                sms_template.updated_by=request.user
                sms_template.save()

                serializer = SmstemplateTypeSerializer(sms_template)
                return Response({'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully updated sms template type name',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})

            elif method.lower() == 'delete':
                sms_template = SmstemplateType.objects.get(id=template_id,organization_id=organization_id)
                sms_template.is_deleted = True
                sms_template.save()
                serializer = SmstemplateTypeSerializer(sms_template)
                return Response({'results':{
                                        'Data':serializer.data ,
                                        },  
                                        'msg': 'Successfully deleted SMS template type',
                                        'status':status.HTTP_202_ACCEPTED,
                                        "request_status": 1})
            else:
                return Response({"msg": "Invalid method provided. Please provide 'edit' or 'delete'."}, status=status.HTTP_400_BAD_REQUEST)

        except SmstemplateType.DoesNotExist:
            return Response({'results': {
                'Data': {},
            },
                'msg': 'Sms template type does not exist',
                'status': status.HTTP_404_NOT_FOUND,
                "request_status": 0})
        except Exception as e:
            return Response({"msg": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        

from django.shortcuts import render, HttpResponse
from tender.models import TenderMasterNew, TenderMasterNewPartyDetails
from user_permissions.models import UserWiseModulePermissions


def tender_recomended_email_template(request, id):
    tender_id = id
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values(
        'id', 'tender_id', 'name', 'proposed_by_date', 'tender_organization__employee_name', 'proposed_tender',
        'state__name', 'project_cost', 'emd_amount', 'performance_security', 'tender_fee_cost',
        'pre_bid_meeting_date', 'schedule_durations', 'bid_submission_date',
        'tender_type', 'tender_qualification_technical_criteria_amount', 'sinpl_qualification_technical_criteria_amount',
        'jv_partner_qualification_technical_criteria_amount', 'tender_qualification_financial_criteria_amount',
        'sinpl_qualification_financial_criteria_amount', 'jv_partner_qualification_financial_criteria_amount',
        'tender_qualification_bid_capacity_criteria_amount', 'sinpl_qualification_bid_capacity_criteria_amount',
        'jv_partner_qualification_bid_capacity_criteria_amount', 'tender_qualification_others_criteria_amount',
        'sinpl_qualification_others_criteria_amount', 'jv_partner_qualification_others_criteria_amount',
        'similar_work_definition', 'tender_jv_name', 'bank_guarantee_ref_page_no',
        'finance_department_timeline', 'finance_remarks', 'board_resolution_ref_page_no',
        'secretarial_department_timeline', 'secretarial_remarks', 'ca_certificate_ref_page_no',
        'accounts_department_timeline', 'accounts_remarks', 'poa_for_signing_of_tender_ref_page_no',
        'tender_department_timeline', 'tender_remarks', 'poa_of_lead_member_ref_page_no', 'price_escalation',
    )

    if not tender_details:
        return HttpResponse("Tender not found.", status=404)

    tender_data = tender_details[0]

    # Format proposed_by_date
    if tender_data['proposed_by_date']:
        date = tender_data['proposed_by_date'].strftime('%d-%m-%Y')
        proposed_by_date = tender_data['proposed_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        date = ""
        proposed_by_date = ""

    if tender_data['bid_submission_date']:
        bid_submission_date = tender_data['bid_submission_date'].strftime('%d-%m-%Y')
    else:
        bid_submission_date = ""

    if tender_data['pre_bid_meeting_date']:
        pre_bid_meeting_date = tender_data['pre_bid_meeting_date'].strftime('%d-%m-%Y')
    else:
        pre_bid_meeting_date = ""

    # Email subject
    subject = f"Approval for Proposed Tender ID {tender_data['tender_id']} - {tender_data['name']} (Proposed Date: {date})"

    # Fetch party details with related data (jvmaster__party_name, company__name)
    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender_id=tender_id).select_related(
        'jvmaster', 'company'
    ).values(
        'jvmaster__party_name',
        'company__name',
        'jv_share_percent',
    )

    # Calculate sums
    technical_criteria_sum = (
        tender_data['sinpl_qualification_technical_criteria_amount'] +
        tender_data['jv_partner_qualification_technical_criteria_amount']
    )
    financial_criteria_sum = (
        tender_data['sinpl_qualification_financial_criteria_amount'] +
        tender_data['jv_partner_qualification_financial_criteria_amount']
    )
    bid_capacity_criteria_sum = (
        tender_data['sinpl_qualification_bid_capacity_criteria_amount'] +
        tender_data['jv_partner_qualification_bid_capacity_criteria_amount']
    )
    qualification_others_criteria_sum = (
        tender_data['sinpl_qualification_others_criteria_amount'] +
        tender_data['jv_partner_qualification_others_criteria_amount']
    )

    parties = [p['jvmaster__party_name'] for p in party_details if p['jvmaster__party_name']]
    companies = [p['company__name'] for p in party_details if p['company__name']]
    jv_shares = [str(p['jv_share_percent']) for p in party_details if p['jv_share_percent']]

    party_names_str = ", ".join(parties) if parties else ""
    company_names_str = ", ".join(companies) if companies else ""

    jv_share_list = []
    for p in party_details:
        party_name = p.get('jvmaster__party_name')
        share = p.get('jv_share_percent')
        if party_name and share is not None:
            jv_share_list.append(f"{party_name} - {share:.1f}%")

    jv_share_str = ", ".join(jv_share_list) if jv_share_list else ""

    context = {
        'tender_details': tender_data,
        'party_details': party_details,
        'jv_share_str' : jv_share_str,
        'pre_bid_meeting_date' : pre_bid_meeting_date,
        'bid_submission_date' : bid_submission_date,

        "technical_criteria_sum": technical_criteria_sum,
        "financial_criteria_sum": financial_criteria_sum,
        "bid_capacity_criteria_sum": bid_capacity_criteria_sum,
        "qualification_technical_criteria_sum": qualification_others_criteria_sum,  

        "party_names_str": party_names_str,
        "company_names_str": company_names_str,

        "id": tender_data['id'],
        "tender_id": tender_data['tender_id'],
        "name": tender_data['name'],
        "proposed_by_date": proposed_by_date,
        "tender_organization__employee_name": tender_data['tender_organization__employee_name'],
        "proposed_tender": tender_data['proposed_tender'],
        "state__name": tender_data['state__name'],
        "project_cost": tender_data['project_cost'],
        "emd_amount": tender_data['emd_amount'],
        "performance_security": tender_data['performance_security'],
        "tender_fee_cost": tender_data['tender_fee_cost'],
        "pre_bid_meeting_date": pre_bid_meeting_date,
        "schedule_durations": tender_data['schedule_durations'],
        "bid_submission_date": bid_submission_date,

        "tender_type": tender_data['tender_type'],
        "tender_jv_name": tender_data['tender_jv_name'],

        "tender_qualification_technical_criteria_amount": tender_data['tender_qualification_technical_criteria_amount'],
        "sinpl_qualification_technical_criteria_amount": tender_data['sinpl_qualification_technical_criteria_amount'],
        "jv_partner_qualification_technical_criteria_amount": tender_data['jv_partner_qualification_technical_criteria_amount'],

        "tender_qualification_financial_criteria_amount": tender_data['tender_qualification_financial_criteria_amount'],
        "sinpl_qualification_financial_criteria_amount": tender_data['sinpl_qualification_financial_criteria_amount'],
        "jv_partner_qualification_financial_criteria_amount": tender_data['jv_partner_qualification_financial_criteria_amount'],

        "tender_qualification_bid_capacity_criteria_amount": tender_data['tender_qualification_bid_capacity_criteria_amount'],
        "sinpl_qualification_bid_capacity_criteria_amount": tender_data['sinpl_qualification_bid_capacity_criteria_amount'],
        "jv_partner_qualification_bid_capacity_criteria_amount": tender_data['jv_partner_qualification_bid_capacity_criteria_amount'],

        "tender_qualification_others_criteria_amount": tender_data['tender_qualification_others_criteria_amount'],
        "sinpl_qualification_others_criteria_amount": tender_data['sinpl_qualification_others_criteria_amount'],
        "jv_partner_qualification_others_criteria_amount": tender_data['jv_partner_qualification_others_criteria_amount'],

        "similar_work_definition": tender_data['similar_work_definition'],

        "bank_guarantee_ref_page_no": tender_data['bank_guarantee_ref_page_no'],
        "board_resolution_ref_page_no": tender_data['board_resolution_ref_page_no'],
        "ca_certificate_ref_page_no": tender_data['ca_certificate_ref_page_no'],
        "poa_for_signing_of_tender_ref_page_no": tender_data['poa_for_signing_of_tender_ref_page_no'],
        "poa_of_lead_member_ref_page_no": tender_data['poa_of_lead_member_ref_page_no'],

        "finance_department_timeline": tender_data['finance_department_timeline'],
        "finance_remarks": tender_data['finance_remarks'],

        "secretarial_department_timeline": tender_data['secretarial_department_timeline'],
        "secretarial_remarks": tender_data['secretarial_remarks'],

        "accounts_department_timeline": tender_data['accounts_department_timeline'],
        "accounts_remarks": tender_data['accounts_remarks'],

        "tender_department_timeline": tender_data['tender_department_timeline'],
        "tender_remarks": tender_data['tender_remarks'],

        "price_escalation" : tender_data['price_escalation'],
    }

    return render(request, 'send_tender_recomdended_email.html', context)



def tender_approval_email_template(request, id):
    tender_id = id
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values(
        'id', 'tender_id', 'name', 'proposed_by_date', 'recommended_by_date', 'tender_organization__employee_name', 'proposed_tender',
        'state__name', 'project_cost', 'emd_amount', 'performance_security', 'tender_fee_cost',
        'pre_bid_meeting_date', 'schedule_durations', 'bid_submission_date',
        'tender_type', 'tender_qualification_technical_criteria_amount', 'sinpl_qualification_technical_criteria_amount',
        'jv_partner_qualification_technical_criteria_amount', 'tender_qualification_financial_criteria_amount',
        'sinpl_qualification_financial_criteria_amount', 'jv_partner_qualification_financial_criteria_amount',
        'tender_qualification_bid_capacity_criteria_amount', 'sinpl_qualification_bid_capacity_criteria_amount',
        'jv_partner_qualification_bid_capacity_criteria_amount', 'tender_qualification_others_criteria_amount',
        'sinpl_qualification_others_criteria_amount', 'jv_partner_qualification_others_criteria_amount',
        'similar_work_definition', 'tender_jv_name', 'bank_guarantee_ref_page_no',
        'finance_department_timeline', 'finance_remarks', 'board_resolution_ref_page_no',
        'secretarial_department_timeline', 'secretarial_remarks', 'ca_certificate_ref_page_no',
        'accounts_department_timeline', 'accounts_remarks', 'poa_for_signing_of_tender_ref_page_no',
        'tender_department_timeline', 'tender_remarks', 'poa_of_lead_member_ref_page_no', 'price_escalation',
    )

    if not tender_details:
        return HttpResponse("Tender not found.", status=404)

    tender_data = tender_details[0]

    # Format proposed_by_date
    if tender_data['recommended_by_date']:
        date = tender_data['recommended_by_date'].strftime('%d-%m-%Y')
        recommended_by_date = tender_data['recommended_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        date = ""
        recommended_by_date = ""
    if tender_data['bid_submission_date']:
        bid_submission_date = tender_data['bid_submission_date'].strftime('%d-%m-%Y')
    else:
        bid_submission_date = ""

    if tender_data['pre_bid_meeting_date']:
        pre_bid_meeting_date = tender_data['pre_bid_meeting_date'].strftime('%d-%m-%Y')
    else:
        pre_bid_meeting_date = ""

    # Email subject
    subject = f"Approval for Recommended Tender ID {tender_data['tender_id']} - {tender_data['name']}, Recommended Date - {date}"

    # Fetch party details with related data (jvmaster__party_name, company__name)
    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender_id=tender_id).select_related(
        'jvmaster', 'company'
    ).values(
        'jvmaster__party_name',
        'company__name',
        'jv_share_percent',
    )

    # Calculate sums
    technical_criteria_sum = (
        tender_data['sinpl_qualification_technical_criteria_amount'] +
        tender_data['jv_partner_qualification_technical_criteria_amount']
    )
    financial_criteria_sum = (
        tender_data['sinpl_qualification_financial_criteria_amount'] +
        tender_data['jv_partner_qualification_financial_criteria_amount']
    )
    bid_capacity_criteria_sum = (
        tender_data['sinpl_qualification_bid_capacity_criteria_amount'] +
        tender_data['jv_partner_qualification_bid_capacity_criteria_amount']
    )
    qualification_others_criteria_sum = (
        tender_data['sinpl_qualification_others_criteria_amount'] +
        tender_data['jv_partner_qualification_others_criteria_amount']
    )

    parties = [p['jvmaster__party_name'] for p in party_details if p['jvmaster__party_name']]
    companies = [p['company__name'] for p in party_details if p['company__name']]
    jv_shares = [str(p['jv_share_percent']) for p in party_details if p['jv_share_percent']]

    party_names_str = ", ".join(parties) if parties else ""
    company_names_str = ", ".join(companies) if companies else ""

    jv_share_list = []
    for p in party_details:
        party_name = p.get('jvmaster__party_name')
        company_name = p.get('company__name')
        share = p.get('jv_share_percent')
        if share is not None:
            name = party_name or company_name  
            if name:
                jv_share_list.append(f"{name} - {share:.1f}%")
    jv_share_str = ", ".join(jv_share_list) if jv_share_list else ""
    context = {
        'tender_details': tender_data,
        'party_details': party_details,
        'jv_share_str' : jv_share_str,

        "technical_criteria_sum": technical_criteria_sum,
        "financial_criteria_sum": financial_criteria_sum,
        "bid_capacity_criteria_sum": bid_capacity_criteria_sum,
        "qualification_technical_criteria_sum": qualification_others_criteria_sum, 

        "party_names_str": party_names_str,
        "company_names_str": company_names_str,

        "id": tender_data['id'],
        "tender_id": tender_data['tender_id'],
        "name": tender_data['name'],
        "recommended_by_date": recommended_by_date,
        "tender_organization__employee_name": tender_data['tender_organization__employee_name'],
        "proposed_tender": tender_data['proposed_tender'],
        "state__name": tender_data['state__name'],
        "project_cost": tender_data['project_cost'],
        "emd_amount": tender_data['emd_amount'],
        "performance_security": tender_data['performance_security'],
        "tender_fee_cost": tender_data['tender_fee_cost'],
        "pre_bid_meeting_date": pre_bid_meeting_date,
        "schedule_durations": tender_data['schedule_durations'],
        "bid_submission_date": bid_submission_date,

        "tender_type": tender_data['tender_type'],
        "tender_jv_name": tender_data['tender_jv_name'],

        "tender_qualification_technical_criteria_amount": tender_data['tender_qualification_technical_criteria_amount'],
        "sinpl_qualification_technical_criteria_amount": tender_data['sinpl_qualification_technical_criteria_amount'],
        "jv_partner_qualification_technical_criteria_amount": tender_data['jv_partner_qualification_technical_criteria_amount'],

        "tender_qualification_financial_criteria_amount": tender_data['tender_qualification_financial_criteria_amount'],
        "sinpl_qualification_financial_criteria_amount": tender_data['sinpl_qualification_financial_criteria_amount'],
        "jv_partner_qualification_financial_criteria_amount": tender_data['jv_partner_qualification_financial_criteria_amount'],

        "tender_qualification_bid_capacity_criteria_amount": tender_data['tender_qualification_bid_capacity_criteria_amount'],
        "sinpl_qualification_bid_capacity_criteria_amount": tender_data['sinpl_qualification_bid_capacity_criteria_amount'],
        "jv_partner_qualification_bid_capacity_criteria_amount": tender_data['jv_partner_qualification_bid_capacity_criteria_amount'],

        "tender_qualification_others_criteria_amount": tender_data['tender_qualification_others_criteria_amount'],
        "sinpl_qualification_others_criteria_amount": tender_data['sinpl_qualification_others_criteria_amount'],
        "jv_partner_qualification_others_criteria_amount": tender_data['jv_partner_qualification_others_criteria_amount'],

        "similar_work_definition": tender_data['similar_work_definition'],

        "bank_guarantee_ref_page_no": tender_data['bank_guarantee_ref_page_no'],
        "board_resolution_ref_page_no": tender_data['board_resolution_ref_page_no'],
        "ca_certificate_ref_page_no": tender_data['ca_certificate_ref_page_no'],
        "poa_for_signing_of_tender_ref_page_no": tender_data['poa_for_signing_of_tender_ref_page_no'],
        "poa_of_lead_member_ref_page_no": tender_data['poa_of_lead_member_ref_page_no'],

        "finance_department_timeline": tender_data['finance_department_timeline'],
        "finance_remarks": tender_data['finance_remarks'],

        "secretarial_department_timeline": tender_data['secretarial_department_timeline'],
        "secretarial_remarks": tender_data['secretarial_remarks'],

        "accounts_department_timeline": tender_data['accounts_department_timeline'],
        "accounts_remarks": tender_data['accounts_remarks'],

        "tender_department_timeline": tender_data['tender_department_timeline'],
        "tender_remarks": tender_data['tender_remarks'],
        'price_escalation' : tender_data['price_escalation'],
    }
    return render(request, 'send_tender_approval_email.html', context)


def tender_documentation_email_template(request, id):
    # Email trigger when tender is on documentation status
    tender_details = TenderMasterNew.cmobjects.filter(id=id).first()
    if not tender_details:
        return HttpResponse("Tender not found.", status=404)
    
    subject = f"Request for Proposed Tender Documentation Update – Tender Id# {tender_details.tender_id} –  Tender Name - {tender_details.name}"

    context = {
        'tender_details': tender_details,
    }
    return render(request, 'send_tender_ducumentation_email.html', context)


def tender_proposed_auto_reminder_email_template(request, id):
    tender_details = TenderMasterNew.cmobjects.filter(id=id).first()
    if not tender_details:
        return HttpResponse("Tender not found.", status=404)
    
    subject = f"Approval Request for Pending Tender – Tender Id# {tender_details.tender_id} –  Tender Name - {tender_details.name}"
    documentation_users = UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__exact="pre-tender-send-for-recommender"
    )
    if not documentation_users:
        return HttpResponse("No recommended users found.", status=404)
    
    to_emails = [item.user.email for item in documentation_users if item.user.email]
    if not to_emails:
        return HttpResponse("No email addresses found for recommended users.", status=400)
    
    context = {
        'tender_details': tender_details,
    }
    return render(request, 'tender_proposed_auto_reminder_email.html', context)


def tender_ongoing_email_template(request, id):
    # Email trigger when tender is on ongoing status
    tender_details = TenderMasterNew.cmobjects.filter(id=id).first()
    if not tender_details:
        return
    subject = f"Supportive documents - Tender Id# {tender_details.tender_id} –  Tender Name - {tender_details.name}"
    on_going_users = UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__exact="pre-tender-send-for-recommender"
    )
    if not on_going_users:
        return HttpResponse("No recommended users found.", status=404)
    to_emails = [item.user.email for item in on_going_users if item.user.email]

    context = {
        'tender_details': tender_details,
    }
    return render(request, 'tender_on_going_email.html', context)


def tender_import_email_template(request):
    sector_data = [
            {
                "sector_id": 40,
                "sector_val": "psu",
                "count": 1
            },
            {
                "sector_id": 36,
                "sector_val": "railways zonal",
                "count": 1
            }
        ]
    context = {
        "items_created": 0,
        "items_updated": 2,
        "date" : datetime.now().strftime("%Y-%m-%d"),
        "time_stamp" : datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
        "sector_data" : sector_data,
    }
    return render(request, 'tender-tmport_email.html', context)

from django.db.models import Sum
def send_payment_director_approval_email_template(request):
    approved_item_ids = [1, 2]
    payment_list = PaymentMaster.cmobjects.filter(id__in=approved_item_ids).order_by('-id')
    total_amount = payment_list.aggregate(total=Sum('amount'))['total']
    print("payment_list ####", payment_list)

    context = {
        "date" : datetime.now().strftime("%Y-%m-%d"),
        "total_amount" : total_amount,
        "payment_list" : payment_list,
    }
    return render(request, 'payment/payment_director_approval_email.html', context)


from vendor.models import VendorMasterV2
def send_vendor_request_approval_email_template(request, id):
    subject = "Vendor code creation"
    vendor_details = VendorMasterV2.cmobjects.filter(id=id).first()
    context = {
        "date" : datetime.now().strftime("%Y-%m-%d"),
        "vendor_details" : vendor_details,
    }
    return render(request, 'vendor/send_vendor_request_approval_email.html', context)




def send_cst_approval_director_email_template(request, id):
    cst_details = CST.cmobjects.filter(id=id).first()
    if not cst_details:
        context = {
            "error": "CST not found."
        }
        return render(request, 'cst/send_cst_approval_director_email.html', context)

    rfq_vendors = cst_details.rfq_vendor
    if not rfq_vendors:
        context = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "cst_details": cst_details,
            "cumulativeTotalVendorAmount": 0,
            "error": "No RFQ Vendor linked to this CST."
        }
        return render(request, 'cst/send_cst_approval_director_email.html', context)

    quotation_details = Quotation.cmobjects.filter(rfq_vendor=rfq_vendors)
    cumulativeTotalVendorAmount = 0
    for quotation in quotation_details:
        total_basic_amount = 0
        quotation_items = QuotationItems.cmobjects.filter(quotation=quotation, is_selected_by_cst=True)

        for item in quotation_items:
            rate = item.rate or 0
            qty = item.quantity_by_cst or 0
            disc_percent = item.disc_percentage or 0
            net_rate = rate * (1 - disc_percent / 100)
            total_basic_amount += net_rate * qty

        packing_forwarding = quotation.packing_forwarding_by_cst or 0
        transportation_charges = quotation.transportaion_charges_by_cst or 0 
        other_charges = quotation.other_charges_by_cst or 0
        total_before_gst = total_basic_amount + packing_forwarding + transportation_charges + other_charges

        total_gst_amount = 0
        gst_components = {"cgst": 0, "sgst": 0, "igst": 0, "cess": 0}

        for item in quotation_items:
            cgst_p = item.cgst_percentage or 0
            sgst_p = item.sgst_percentage or 0
            igst_p = item.igst_percentage or 0
            cess_p = item.cess_percentage or 0

            item_share = 0
            if total_basic_amount > 0:
                item_total_net = (item.rate or 0) * (item.quantity_by_cst or 0) * (1 - (item.disc_percentage or 0)/100)
                item_share = item_total_net / total_basic_amount

            item_gst_base = total_before_gst * item_share
            cgst_amt = (item_gst_base * cgst_p) / 100
            sgst_amt = (item_gst_base * sgst_p) / 100
            igst_amt = (item_gst_base * igst_p) / 100
            cess_amt = (item_gst_base * cess_p) / 100

            total_gst_amount += cgst_amt + sgst_amt + igst_amt + cess_amt
            gst_components["cgst"] += cgst_amt
            gst_components["sgst"] += sgst_amt
            gst_components["igst"] += igst_amt
            gst_components["cess"] += cess_amt

        extra_expense_gst = 0
        expense_details = QuotationExpenseDetails.cmobjects.filter(quotation=quotation)

        for exp in expense_details:
            exp_amount = exp.expense_amount or 0
            if exp.expense_condition == 'after_gst':
                total_percentage = (exp.cgst_percentage or 0) + (exp.sgst_percentage or 0) + (exp.igst_percentage or 0)
                extra_expense_gst += (exp_amount * total_percentage) / 100

        total_gst_amount += extra_expense_gst

        grand_total = total_before_gst + total_gst_amount
        cumulativeTotalVendorAmount += grand_total

    context = {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "cst_details": cst_details,
        "cumulativeTotalVendorAmount": round(cumulativeTotalVendorAmount, 2),
    }

    return render(request, 'cst/send_cst_approval_director_email.html', context)


def send_payment_update_by_account_email_template(request, id):
    """ 
    Payment Module: Once the same gets updated by Accounts, an auto email should be shared with (To: procurement@shyaminfra.com).
    """

    subject = "Vendor Payment Confirmation"
    payment_details = PaymentMaster.cmobjects.filter(id=id).first()
    
    
    context = {
        "payment_details" : payment_details,
    }


    return render(request, 'payment/send_payment_update_by_account_email_template.html', context)


from email_config.utils import *
def po_live_status_email(request):
    send_purchase_order_items_delivered_status_email()
    context = {
        
    }
    return render(request, 'payment/send_payment_update_by_account_email_template.html', context)


def send_checklist_doc_notify(request, id):
    tender_id = id
    tender_details = TenderMasterNew.cmobjects.filter(id=id).select_related('sector', 'tender_organization').values(
        'id', 'tender_id', 'name', 'tender_organization__employee_name', 'tender_jv_name', 'tender_fee_cost',
        'approved_by__first_name', 'approved_by__last_name', 'created_at', 'project_cost', 'proposed_tender',
        'bid_submission_date', 'pre_bid_meeting_date', 'tender_type', 'price_variation_clause', 
        'finance_remarks', 'secretarial_remarks', 'accounts_remarks', 'tender_remarks', 'finance_department_timeline',
        'secretarial_department_timeline', 'accounts_department_timeline', 'tender_department_timeline'
    )
    if not tender_details:
        return
    
    tender_data = tender_details[0]
    if tender_data['bid_submission_date']:
        bid_submission_date = tender_data['bid_submission_date'].strftime('%d-%m-%Y')
    else:
        bid_submission_date = ""

    if tender_data['pre_bid_meeting_date']:
        pre_bid_meeting_date = tender_data['pre_bid_meeting_date'].strftime('%d-%m-%Y')
    else:
        pre_bid_meeting_date = ""

    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender_id=tender_id).select_related(
        'jvmaster', 'company'
    ).values(
        'jvmaster__party_name',
        'company__name',
        'jv_share_percent',
    )

    parties = [p['jvmaster__party_name'] for p in party_details if p['jvmaster__party_name']]
    companies = [p['company__name'] for p in party_details if p['company__name']]

    party_names_str = ", ".join(parties) if parties else ""
    company_names_str = ", ".join(companies) if companies else ""

    jv_share_list = []
    for p in party_details:
        party_name = p.get('jvmaster__party_name')
        company_name = p.get('company__name')
        share = p.get('jv_share_percent')
        if share is not None:
            name = party_name or company_name  
            if name:
                jv_share_list.append(f"{name} - {share:.1f}%")
    jv_share_str = ", ".join(jv_share_list) if jv_share_list else ""

    # checklist 
    tender_dept_list = TenderDepartmentMaster.cmobjects.all().values('id', 'name')
    checklist_doc_list = []
    for item in tender_dept_list:
        tender_department_name = item['name']
        for obj in TenderChecklistMaster.cmobjects.filter(tender_department_id=item['id']).values('id', 'name'):
            checklist_name = obj['name']
            for doc_item in TenderMasterNewQualificationDocuments.cmobjects.filter(
                checklist_id=obj['id']
            ).values('reference_page_no', 'tender_department__name'):
                reference_page_no = doc_item.doc_item

    print("checklist_doc_list ###### ", checklist_doc_list)


    # from django.db.models import F
    # checklist_doc_list = (
    #     TenderMasterNewQualificationDocuments.cmobjects
    #     .select_related('checklist__tender_department')  
    #     .values(
    #         'reference_page_no',
    #         checklist_name=F('checklist__name'),
    #         tender_department_name=F('checklist__tender_department__name')
    #     )
    # )
    # # Convert to desired dict format (if needed)
    # checklist_doc_list = [
    #     {
    #         "name": item['checklist_name'],
    #         "reference_page_no": item['reference_page_no'],
    #         "tender_department": item['tender_department_name'],
    #     }
    #     for item in checklist_doc_list
    # ]

    # print("checklist_doc_list ###### ", checklist_doc_list)

    #attachment
    checklist_docs = TenderMasterNewQualificationDocuments.cmobjects.filter(
        tender_id=tender_id,
        doc_type = "checklist_document",
    )
    file_paths = [doc.attachment.path for doc in checklist_docs if doc.attachment]
    
    context = {
        'tender_details': tender_details[0],
        "tender_organization__employee_name": tender_data['tender_organization__employee_name'],
        'tender_id' : tender_data['tender_id'],
        "proposed_tender": tender_data['proposed_tender'],
        "id" : tender_id,
        "created_at" : tender_data['created_at'].strftime("%d-%m-%Y %H:%M:%S"),
        "bid_submission_date" : bid_submission_date,
        "pre_bid_meeting_date" : pre_bid_meeting_date,
        'tender_type' : tender_data['tender_type'],
        "checklist_list" : checklist_doc_list,
        "price_variation_clause" : tender_data['price_variation_clause'],
        "jv_share_str" : jv_share_str,
        "party_names_str" : party_names_str,
    }
    return render(request, 'tender/checklist_doc_update_notify_email.html', context)



def send_pnm_daily_ar_email(request):

    context = {

    }





    return render(request, 'pnm/pnm_pending_ar_daily.html', context)
