from django import template
from datetime import datetime
from datetime import date
import re
from datetime import timedelta

register = template.Library()

@register.filter
def indian_format(value):
    try:
        value = float(value)
        str_value = f"{value:.2f}"
        if '.' in str_value:
            integer_part, decimal_part = str_value.split('.')
        else:
            integer_part, decimal_part = str_value, '00'
        
        reversed_integer = integer_part[::-1]
        formatted_parts = []
        formatted_parts.append(reversed_integer[:3])
        
        for i in range(3, len(reversed_integer), 2):
            formatted_parts.append(reversed_integer[i:i+2])
        
        result = ','.join(formatted_parts)[::-1]
        return f"{result}.{decimal_part}"
    except (ValueError, TypeError):
        return value
    
@register.filter
def datetime_format(value):
    """
    Simple datetime formatter - use this if you know the input format
    """
    if not value:
        return ''
    
    try:
        if isinstance(value, str):
            # If it's already in the right format, return as is
            if re.match(r'\d{2}-\d{2}-\d{4} \d{2}:\d{2}:\d{2}', value):
                return value
            # Otherwise try to parse common formats
            dt = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
            return dt.strftime('%d-%m-%Y %H:%M:%S')
        else:
            # Assume it's a datetime object
            return value.strftime('%d-%m-%Y %H:%M:%S')
    except Exception:
        return value
    

@register.filter
def subtract(ordered, delivered):
    """
    Usage: {{ ordered|subtract:delivered }}
    Safely subtracts two values, treating None or empty as 0.
    """
    try:
        ordered = float(ordered) if ordered not in [None, ''] else 0.0
        delivered = float(delivered) if delivered not in [None, ''] else 0.0
        return round(ordered - delivered, 2)
    except (ValueError, TypeError):
        return 0.0

@register.filter
def default_float(value, default='0.00'):
    """
    Convert value to float with 2 decimal places, or return default.
    """
    try:
        return f"{float(value):.2f}" if value not in (None, '') else default
    except (ValueError, TypeError):
        return default

@register.filter
def qty_default_float(value, default='0.000'):
    """
    Convert value to float with 3 decimal places, or return default.
    """
    try:
        return f"{float(value):.3f}" if value not in (None, '') else default
    except (ValueError, TypeError):
        return default
    

@register.filter
def days_until(value):
    if not value:
        return ""
    try:
        if isinstance(value, date) and not isinstance(value, datetime):
            value_date = value
        elif isinstance(value, datetime):
            value_date = value.date()
        elif isinstance(value, str):
            value = value.strip()
            if '-' in value:
                if len(value.split('-')[0]) == 4:
                    value_date = datetime.strptime(value, "%Y-%m-%d").date()
                else:
                    value_date = datetime.strptime(value, "%d-%m-%Y").date()
            else:
                return ""
        else:
            return ""
    except (ValueError, TypeError):
        return ""
    today = date.today()
    delta = (today - value_date).days
    return delta

from django import template

register = template.Library()

@register.filter
def extract_vendor_names_list(value):
    if not value or not isinstance(value, str):
        return ""
    vendors = []
    parts = value.split(',')
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if " [" in part:
            vendor_name = part.split(" [", 1)[0].strip()
            vendors.append(vendor_name)
        else:
            vendor_name = part.split('|', 1)[0].strip()
            vendors.append(vendor_name)
    return ", ".join(vendors)





@register.filter
def indian_format_cst(value):
    try:
        if value is None:
            return "0.00"
        value = float(value)
        str_value = f"{value:.2f}"
        if '.' in str_value:
            integer_part, decimal_part = str_value.split('.')
        else:
            integer_part, decimal_part = str_value, '00'

        if integer_part == '0':
            return f"0.{decimal_part}"

        reversed_integer = integer_part[::-1]
        formatted_parts = []
        formatted_parts.append(reversed_integer[:3])  # last 3 digits (hundreds)

        # Then take pairs (thousands, lakhs, crores...)
        for i in range(3, len(reversed_integer), 2):
            formatted_parts.append(reversed_integer[i:i+2])

        # Join parts and reverse back to correct order
        result = ','.join(formatted_parts)[::-1]
        return f"{result}.{decimal_part}"

    except (ValueError, TypeError):
        return value  # or return "0.00" for strict mode
    
    



@register.filter
def indian_format_po_data(value):
    """
    Format number in Indian numbering system (lakhs, crores) with 2 decimal places.
    Example: 26944.0 → "26,944.00"
    """
    try:
        if value is None:
            return "0.00"
        value = float(value)
        str_value = f"{value:.2f}"
        if '.' in str_value:
            integer_part, decimal_part = str_value.split('.')
        else:
            integer_part, decimal_part = str_value, '00'

        if integer_part == '0':
            return f"0.{decimal_part}"

        reversed_integer = integer_part[::-1]
        formatted_parts = []
        formatted_parts.append(reversed_integer[:3])  # Last 3 digits

        for i in range(3, len(reversed_integer), 2):
            formatted_parts.append(reversed_integer[i:i+2])

        result = ','.join(formatted_parts)[::-1]
        return f"{result}.{decimal_part}"

    except (ValueError, TypeError):
        return "0.00"

@register.filter
def str_to_date_obj(value, input_format="%Y-%m-%d"):
    """
    Convert string to date object.
    """
    try:
        return datetime.strptime(value, input_format).date()
    except (ValueError, TypeError):
        return None
    
@register.filter
def po_estimated_days_value(date_obj, days):
    """
    Add days to a date object. Returns unchanged if invalid.
    """
    if not date_obj or not isinstance(days, int):
        return date_obj
    try:
        return date_obj + timedelta(days=days)
    except (ValueError, TypeError):
        return date_obj


@register.filter
def pending_qty_value(value, arg):
    """
    Subtract arg (GRN quantity) from value (PO quantity) to get pending quantity.
    """
    try:
        if value is None:
            value = 0.0
        if arg is None:
            arg = 0.0
        return float(value) - float(arg)
    except (ValueError, TypeError):
        return 0.0


@register.filter
def sum_gst_components(item):
    """
    Compute total GST from SGST, CGST, IGST, UTGST components.
    Accepts a dict-like object (e.g., model instance or dict from values()).
    """
    if not isinstance(item, dict):
        # Try to convert to dict if it's a model instance or similar
        try:
            item = item.__dict__
        except AttributeError:
            return 0.0

    try:
        sgst = float(item.get('total_item_sgst_amount', 0) or 0)
        cgst = float(item.get('total_item_cgst_amount', 0) or 0)
        igst = float(item.get('total_item_igst_amount', 0) or 0)
        utgst = float(item.get('total_item_utgst_amount', 0) or 0)

        total = sgst + cgst + igst + utgst
        return round(total, 2)
    except (ValueError, TypeError, AttributeError):
        return 0.0


@register.filter
def add_values_misc_charges(value, arg):
    """
    Adds two values (e.g., expense + tax) for misc charges.
    """
    try:
        val = float(value or 0)
        arg_val = float(arg or 0)
        return val + arg_val
    except (ValueError, TypeError):
        return 0.0



@register.filter
def calculate_total(item):
    try:
        a = float(item.get('total_item_amount_with_gst', 0))
        b = float(item.get('required_duration', 0))
        c = float(item.get('total_expense_amount_with_gst', 0))
        d = float(item.get('total_item_quantity', 0))
        return round((a * b) + (c * d), 2)
    except (TypeError, ValueError, AttributeError):
        return 0.0

@register.filter
def pending_days(financial_bid_open_date):
    if not financial_bid_open_date:
        return ""
    bid_date = datetime.strptime(financial_bid_open_date, "%Y-%m-%d").date()
    today = datetime.now().date()
    pending_days = (today - bid_date).days
    return pending_days