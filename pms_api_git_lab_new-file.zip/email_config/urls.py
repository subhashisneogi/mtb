from django.urls import path
from email_config import views


urlpatterns = [
     path('EmailTemplatesView_POST/', views.EmailTemplatesView.as_view(),name="EmailTemplatesView_POST"),
     path('EmailTagView/', views.EmailTagView.as_view(),name="EmailTagView"),
     path('SmsTemplateView/', views.SmsTemplateView.as_view(),name="SmsTemplateView"),
     path('EmailtemplateType/', views.EmailtemplateTypeView.as_view(),name="EmailtemplateType"),
     path('SmstemplateType/', views.SmstemplateTypeView.as_view(),name="SmstemplateType"),
     path('SmsTagView/', views.SmsTagView.as_view(),name="SmsTagView"),


     path('tender-recomended-email-template/<int:id>', views.tender_recomended_email_template, 
          name='tender_approval_email_template'),
     path('tender-approval-email-template/<int:id>', views.tender_approval_email_template, 
          name='tender_approval_email_template'),
     path('tender-documentation-email-template/<int:id>', views.tender_documentation_email_template, 
          name='tender_documentation_email_template'),
     path('tender-proposed-auto-reminder-template/<int:id>', views.tender_proposed_auto_reminder_email_template, 
          name='tender_proposed_auto_reminder_email_template'),
     path('tender-ongoing-email-template/<int:id>', views.tender_ongoing_email_template, 
          name='tender_ongoing_email_template'),


     # path('payment_approval_director_email_template/<int:id>', views.payment_approval_director_email_template, 
     #      name='payment_approval_director_email_template'),

     path('tender_import_email_template/', views.tender_import_email_template, 
          name='tender_import_email_template'),

     path('send_payment_director_approval_email_template/', views.send_payment_director_approval_email_template, 
          name='send_payment_director_approval_email_template'),

     path('send_vendor_request_approval_email_template/<int:id>/', views.send_vendor_request_approval_email_template, 
          name='send_vendor_request_approval_email_template'),
     path('send_cst_approval_director_email_template/<int:id>/', views.send_cst_approval_director_email_template, 
          name='send_cst_approval_director_email_template'),
     path('send_payment_update_by_account_email_template/<int:id>/', views.send_payment_update_by_account_email_template, 
          name='send_payment_update_by_account_email_template'),

     path('po-live-satus-email/', views.po_live_status_email),
     path('send_checklist_doc_notify/<int:id>/', views.send_checklist_doc_notify, 
          name='send_checklist_doc_notify'),

     
     path('pnm-daily-pending-ar-email/', views.send_pnm_daily_ar_email, 
          name='send_pnm_daily_ar_email'),


]