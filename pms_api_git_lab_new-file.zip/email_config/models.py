from django.db import models
from django.core.validators import EmailValidator
from administrations.models import  BaseAbstractStructure , Organization

# Create your models here.


class MailTemplates(models.Model):
    """
    Model To Keep All Mail templates
    """
    sample = models.CharField(max_length=200)
    template = models.TextField(blank=True, null=True)
    text_content = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.sample
    
    
class EmailTag(models.Model):
    name = models.CharField(max_length=100)
    organization = models.ForeignKey(Organization, related_name='emailtag_organization',on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return self.name
    
class SmsTag(models.Model):
    name = models.CharField(max_length=100)
    organization = models.ForeignKey(Organization, related_name='smstag_organization',on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return self.name
class EmailtemplateType (BaseAbstractStructure):
    emtp_type_name = models.CharField(max_length=200)
    organization = models.ForeignKey(Organization, related_name='emailtemplatetype_organization',on_delete=models.CASCADE, blank=True, null=True)
    def __str__(self):
        return self.emtp_type_name
    
class SmstemplateType (BaseAbstractStructure):
    smtp_type_name = models.CharField(max_length=200)
    organization = models.ForeignKey(Organization, related_name='smstemplatetype_organization',on_delete=models.CASCADE, blank=True, null=True)
    def __str__(self):
        return self.smtp_type_name
    
    
class EmailTemplates(BaseAbstractStructure):
    """
    Model To Keep All Mail templates created by user
    """
    # TEMPLATE_TYPE_CHOICES = [
    # ("general", "General"),
    # ("systemdefine", "System Defined"),
    # ]
    organization = models.ForeignKey(Organization, related_name='emailtp_organization',on_delete=models.CASCADE, blank=True, null=True)
    template_name = models.CharField(max_length=100)
    subject = models.CharField(max_length=200)
    body = models.TextField()
    from_name = models.CharField(max_length=200)
    from_email = models.EmailField(validators=[EmailValidator()])
    tags = models.ManyToManyField('EmailTag')
    email_template_type = models.ForeignKey('EmailtemplateType', on_delete=models.DO_NOTHING, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_active_trigger = models.BooleanField(default=False)
    allow_cc_tag = models.BooleanField(default=False)
    header_template = models.ForeignKey('self', related_name='email_template_header_template', on_delete=models.DO_NOTHING, blank=True, null=True)
    footer_template = models.ForeignKey('self', related_name='email_template_footer_template', on_delete=models.DO_NOTHING, blank=True, null=True)

    def __str__(self):
        tag_names = self.tags.values_list('name', flat=True)
        tag_names_str = ', '.join(tag_names)
        # return f"{self.template_name}  ~ {self.subject} ~ {self.from_name} ~ {tag_names_str}"
        return self.template_name
    
class EmailLog(BaseAbstractStructure):
    """
    Model To Keep Track of Sent Emails
    """
    organization = models.ForeignKey(Organization, related_name='emaillog_organization',on_delete=models.CASCADE, blank=True, null=True)
    template_name = models.ForeignKey('EmailTemplates', on_delete=models.SET_DEFAULT, default=None)
    to_email = models.CharField(max_length=200)
    cc_email = models.CharField(max_length=200, blank=True)
    bcc_email = models.CharField(max_length=200, blank=True)
    sent_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.template.name} sent to {self.to_email} on {self.sent_date} "


class SmsTemplate(BaseAbstractStructure):
    """
    Sms template class
    """
    organization = models.ForeignKey(Organization, related_name='smstp_organization',on_delete=models.CASCADE, blank=True, null=True)
    sms_template_name = models.CharField(max_length=100)
    template_type = models.ForeignKey('SmstemplateType', on_delete=models.DO_NOTHING, blank=True, null=True)
    body = models.TextField()
    tags = models.ManyToManyField('SmsTag')
    is_active = models.BooleanField(default=True)
    is_active_trigger = models.BooleanField(default=False)
    def __str__(self):
        return self.sms_template_name


class PushTemplate(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='push_template_organization',on_delete=models.CASCADE, blank=True, null=True)
    template_name = models.CharField(max_length=100)
    title = models.CharField(max_length=255)
    body = models.TextField()
    tags = models.TextField(default='')
    is_active = models.BooleanField(default=True)
    is_active_trigger = models.BooleanField(default=False)
    def __str__(self):
        return self.template_name


class EmailSend(BaseAbstractStructure):
    """
    Model To Keep Track of Cron Emails
    """
    organization = models.ForeignKey(Organization, related_name='email_cron_organization', on_delete=models.CASCADE, blank=True, null=True)
    template = models.ForeignKey(EmailTemplates, on_delete=models.SET_DEFAULT, default=None)
    to_email = models.CharField(max_length=255)
    bcc_mail_list = models.CharField(max_length=255, default='')
    cc_mail_list = models.CharField(max_length=255, default='')
    subject = models.CharField(max_length=255, null=True, blank=True)
    context = models.JSONField(null=True, blank=True)
    processed_message = models.TextField(null=True, blank=True)
    attachments = models.TextField(null=True, blank=True)
    is_sent = models.BooleanField(default=False)
    tried_count = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.template}  mail to {self.to_email}"

    class Meta:
        db_table = "email_config_send_email"


class SMSSend(BaseAbstractStructure):
    """
    Model To Keep Track of Cron SMSs
    """
    organization = models.ForeignKey(Organization, related_name='sms_cron_organization', on_delete=models.CASCADE, blank=True, null=True)
    template = models.ForeignKey(SmsTemplate, on_delete=models.SET_DEFAULT, default=None)
    to_number = models.CharField(max_length=255)
    context = models.JSONField(null=True, blank=True)
    processed_message = models.TextField(null=True, blank=True)
    is_sent = models.BooleanField(default=False)
    tried_count = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.template}  sms to {self.to_number}"

    class Meta:
        db_table = "email_config_send_sms"


class PushSend(BaseAbstractStructure):
    """
    Model To Keep Track of Cron Pushs
    """
    organization = models.ForeignKey(Organization, related_name='push_cron_organization', on_delete=models.CASCADE, blank=True, null=True)
    template = models.ForeignKey(PushTemplate, on_delete=models.SET_DEFAULT, default=None)
    user_list = models.CharField(max_length=255)
    extra = models.JSONField(null=True, blank=True)
    title = models.CharField(max_length=255, null=True, blank=True)
    processed_message = models.TextField(null=True, blank=True)
    is_sent = models.BooleanField(default=False)
    tried_count = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.template}  push to {self.user_list}"

    class Meta:
        db_table = "email_config_send_push"


class NotificationMap(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='email_config_notification_map_organization', on_delete=models.CASCADE)
    action = models.CharField(max_length=255)
    email_template = models.ForeignKey(EmailTemplates, on_delete=models.SET_NULL, null=True, blank=True)
    email_is_active = models.BooleanField(default=True)
    sms_template = models.ForeignKey(SmsTemplate, on_delete=models.SET_NULL, null=True, blank=True)
    sms_is_active = models.BooleanField(default=True)
    # wa_template = models.ForeignKey(SmsTemplate, on_delete=models.SET_NULL, null=True, blank=True)
    # wa_is_active = models.BooleanField(default=True)
    push_template = models.ForeignKey(PushTemplate, on_delete=models.SET_NULL, null=True, blank=True)
    push_is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.action}"

    class Meta:
        db_table = "email_config_notification_map"
