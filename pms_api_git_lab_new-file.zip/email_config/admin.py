from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from django_summernote.widgets import SummernoteWidget
from .models import *
from administrations.utils import send_generic_mail,send_generic_push
from unfold.sections import BaseSection
from django.template import Template, Context
# Register your models here.


class MailTemplatesAdmin(ModelAdmin):  # instead of ModelAdmin
    readonly_fields = ('sample',)
    formfield_overrides = {
        models.TextField: {
            "widget": SummernoteWidget(),
        }
    }


class EmailTemplatesAdmin(ModelAdmin):  # instead of ModelAdmin
    list_filter = ['is_active', 'is_active_trigger', 'is_deleted']
    list_display = ['template_name', 'is_active', 'is_active_trigger', 'is_deleted']
    search_fields = ('template_name', )
    list_editable = (
        'is_active',
        'is_active_trigger',
        'is_deleted',
    )
    formfield_overrides = {
        models.TextField: {
            "widget": SummernoteWidget(),
        }
    }

class SmsTemplateAdmin(ModelAdmin):  # instead of ModelAdmin
    
    list_filter = ['is_active', 'is_active_trigger', 'is_deleted']
    list_display = ['sms_template_name', 'is_active', 'is_active_trigger', 'is_deleted']
    list_editable = (
        'is_active',
        'is_active_trigger',
        'is_deleted',
    )
    formfield_overrides = {
        models.TextField: {
            "widget": SummernoteWidget(),
        }
    }


admin.site.register(MailTemplates, MailTemplatesAdmin)
admin.site.register(SmsTemplate, SmsTemplateAdmin)
admin.site.register(EmailTemplates, EmailTemplatesAdmin)
admin.site.register(EmailLog,ModelAdmin)
admin.site.register(EmailTag,ModelAdmin)
admin.site.register(SmsTag,ModelAdmin)
admin.site.register(EmailtemplateType,ModelAdmin)
admin.site.register(SmstemplateType,ModelAdmin)
admin.site.register(SMSSend,ModelAdmin)

class CustomTableSection(BaseSection):
    def render(self) -> str:
        try:
            email_template = self.instance.template
            htmly = Template(email_template.body if email_template else '')
            processed_message = self.instance.processed_message if self.instance.processed_message else htmly.render(Context(self.instance.context))
            return Template("""<iframe style="width: 100%; height: 50vh;" srcdoc='{{ref_processed_message}}'></iframe>""").render(Context({'ref_processed_message': processed_message}))
        except Exception as e:
            print(e)
@admin.register(EmailSend)
class EmailSendAdmin(ModelAdmin):
    list_filter = ['is_sent', 'is_deleted']
    list_display = ['template', 'created_at', 'to_email', 'bcc_mail_list', 'cc_mail_list', 'subject', 'is_sent', 'tried_count', 'is_deleted',]
    search_fields = ('template__template_name', 'to_email', 'bcc_mail_list', 'cc_mail_list', 'subject',)
    actions = ("send_email",)
    list_sections = [CustomTableSection,]

    def send_email(self, request, queryset):
        count = 0
        for instance in queryset:
            result = send_generic_mail(instance)
            if result:
                count += 1
                instance.is_sent = True
            instance.tried_count = instance.tried_count + 1
            instance.save()
        msg = f"All messages were sent: {count}"
        self.message_user(request, msg)

@admin.register(PushTemplate)
class PushTemplateAdmin(ModelAdmin):
    list_filter = ['is_active', 'is_active_trigger', 'is_deleted']
    list_display = ['template_name', 'is_active', 'is_active_trigger', 'is_deleted',]
    search_fields = ('template_name',)
    list_editable = (
        'is_active',
        'is_active_trigger',
        'is_deleted',
    )

@admin.register(PushSend)
class PushSendAdmin(ModelAdmin):
    list_filter = ['is_sent', 'is_deleted']
    list_display = ['template', 'user_list', 'is_sent', 'tried_count', 'is_deleted',]
    search_fields = ('template__template_name', 'user_list',)
    actions = ("send_push",)

    def send_push(self, request, queryset):
        count = 0
        for instance in queryset:
            result = send_generic_push(instance)
            if result:
                count += 1
                instance.is_sent = True
            instance.tried_count = instance.tried_count + 1
            instance.save()
        msg = f"All messages were sent: {count}"
        self.message_user(request, msg)


@admin.register(NotificationMap)
class NotificationMapAdmin(ModelAdmin):
    list_filter = ['email_is_active', 'sms_is_active', 'push_is_active', 'is_deleted']
    list_display = ['action', 'email_is_active', 'email_template', 'sms_is_active', 'sms_template', 'push_is_active', 'push_template', 'is_deleted',]
    search_fields = ('action',)
    list_editable = (
        'email_is_active',
        'sms_is_active',
        'push_is_active',
        'is_deleted',
    )