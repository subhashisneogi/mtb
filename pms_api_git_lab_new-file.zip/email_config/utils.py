import json
import os
import django
import logging
from colorama import Back, Style
from django.core.mail import EmailMultiAlternatives
from django.template import Template, Context
# from django.apps import apps
django.setup()  # Fix for App Load Error
from email_config.models import EmailTemplates
from django.template.loader import get_template
from user_permissions.models import UserWiseModulePermissions
from procurement.models import *
import mimetypes
from tender.models import TenderMasterNew, TenderMasterNewPartyDetails, TenderMasterNewQualificationDocuments, TenderChecklistMaster, TenderMasterNewSurveyMaster
from datetime import datetime
from django.utils import timezone
logger = logging.getLogger(__name__)
from django.conf import settings
from django.db.models import Q, Subquery, OuterRef, CharField, Value
from django.db.models.functions import Coalesce, Concat
from administrations.utils import trigger_notifications
from django.utils import timezone
from datetime import timedelta
from django.test import RequestFactory
from rest_framework.test import force_authenticate
from rest_framework.request import Request
from administrations.models import PmsUser
from procurement.views import PurchaseOrderItemsSearchAPIView, PaymentMasterMainAPIView
from itertools import chain
from django.http import QueryDict
from collections import defaultdict
import base64
from procurement.helper import GroupConcat

def send_notification_mail_to(to_mail_list, template_name, processed_message, subject):
    """
    Send Notification Email
    """
    try:
        email_template = EmailTemplates.objects.filter(template_name=template_name).first()

        if not email_template:
            print(f"Email template '{template_name}' not found.")
            return False
        if subject == '':
            subject = email_template.subject

        from_email = email_template.from_email

        # msg = EmailMultiAlternatives(
        #     subject=subject,
        #     body=processed_message,
        #     from_email=f'{email_template.from_name} <{from_email}>',
        #     to=to_mail_list,
        # )
        # msg.attach_alternative(processed_message, "text/html")
        # print(Back.GREEN, "From email ", from_email)
        # print("To email ", to_mail_list)
        # print("content ", processed_message)
        # print("message", msg, Style.RESET_ALL)
        # msg.send()

        print(f'@send_notification_mail_to: mail sent triggered to {to_mail_list}')
        if bool(int(str(os.getenv('LOGGING_ENABLED','0')))):
            logger.info(f'@send_notification_mail_to: mail sent triggered to {to_mail_list}')

        return True
    except Exception as e:
        print(f"@send_notification_mail_to: Email sending failed: {e}")
        if bool(int(str(os.getenv('LOGGING_ENABLED','0')))):
            logger.error(f"@send_notification_mail_to: Email sending failed: {e}")
        return False


# TENDER APPROVAL EMAIL
def send_tender_excel_import_email(created_count, sector_list):
    """ 
        Tender Identified but not Proposed, Frequency : On upload basis, To - Mr Rajendra Nath Ray,
        CC - Gajendra Sir, Kousik Bhoumik Sir
    """
    current_date = datetime.now().strftime("%Y-%m-%d")
    subject = f"Identified Tender Dated : {current_date}"
    context = {
        "created_count" : created_count,
        "date" : current_date,
        "time_stamp" : datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
        "sector_data": sector_list,
        "fe_base" : str(os.getenv('FE_BASE','')),
    }
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-import-to'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-import-cc'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-IMPORT', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)

def send_tender_proposed_approval_email(tender_id):
    """ 
        Tender Proposed but not Recommended, Frequency : On Proposed, 
        Email To - Kousik Bhoumik Sir and Email CC: Gajendra Sir  
    """
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values(
        'id', 'tender_id', 'name', 'proposed_by_date', 'tender_organization__employee_name', 'proposed_tender',
        'state__name', 'project_cost', 'emd_amount', 'performance_security', 'tender_fee_cost',
        'pre_bid_meeting_date', 'schedule_durations', 'bid_submission_date',
        'tender_type', 'tender_qualification_technical_criteria_amount', 'sinpl_qualification_technical_criteria_amount',
        'jv_partner_qualification_technical_criteria_amount', 'tender_qualification_financial_criteria_amount',
        'sinpl_qualification_financial_criteria_amount', 'jv_partner_qualification_financial_criteria_amount',
        'tender_qualification_bid_capacity_criteria_amount', 'sinpl_qualification_bid_capacity_criteria_amount',
        'jv_partner_qualification_bid_capacity_criteria_amount', 'tender_qualification_others_criteria_amount',
        'sinpl_qualification_others_criteria_amount', 'jv_partner_qualification_others_criteria_amount',
        'similar_work_definition', 'tender_jv_name', 'bank_guarantee_ref_page_no',
        'finance_department_timeline', 'finance_remarks', 'board_resolution_ref_page_no',
        'secretarial_department_timeline', 'secretarial_remarks', 'ca_certificate_ref_page_no',
        'accounts_department_timeline', 'accounts_remarks', 'poa_for_signing_of_tender_ref_page_no',
        'tender_department_timeline', 'tender_remarks', 'poa_of_lead_member_ref_page_no', 'price_escalation',
    )
    if not tender_details:
        return   
    tender_data = tender_details[0]
    if tender_data['proposed_by_date']:
        date = tender_data['proposed_by_date'].strftime('%d-%m-%Y')
        proposed_by_date = tender_data['proposed_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        date = ""
        proposed_by_date = ""

    if tender_data['bid_submission_date']:
        bid_submission_date = tender_data['bid_submission_date'].strftime('%d-%m-%Y')
    else:
        bid_submission_date = ""

    if tender_data['pre_bid_meeting_date']:
        pre_bid_meeting_date = tender_data['pre_bid_meeting_date'].strftime('%d-%m-%Y')
    else:
        pre_bid_meeting_date = ""

    finance_department_timeline = tender_data['finance_department_timeline'].strftime('%d-%m-%Y') if tender_data['finance_department_timeline'] else ""
    secretarial_department_timeline = tender_data['secretarial_department_timeline'].strftime('%d-%m-%Y') if tender_data['secretarial_department_timeline'] else ""
    accounts_department_timeline = tender_data['accounts_department_timeline'].strftime('%d-%m-%Y') if tender_data['accounts_department_timeline'] else ""
    tender_department_timeline = tender_data['tender_department_timeline'].strftime('%d-%m-%Y') if tender_data['tender_department_timeline'] else ""

    subject = f"Approval required for Proposed Tender ID {tender_data['tender_id']} - {tender_data['name']} (Proposed Date: {date})"
    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender_id=tender_id).select_related(
        'jvmaster', 'company'
    ).values(
        'jvmaster__party_name',
        'company__name',
        'jv_share_percent',
    )
    technical_criteria_sum = (
        tender_data['sinpl_qualification_technical_criteria_amount'] +
        tender_data['jv_partner_qualification_technical_criteria_amount']
    )
    financial_criteria_sum = (
        tender_data['sinpl_qualification_financial_criteria_amount'] +
        tender_data['jv_partner_qualification_financial_criteria_amount']
    )
    bid_capacity_criteria_sum = (
        tender_data['sinpl_qualification_bid_capacity_criteria_amount'] +
        tender_data['jv_partner_qualification_bid_capacity_criteria_amount']
    )
    qualification_others_criteria_sum = (
        tender_data['sinpl_qualification_others_criteria_amount'] +
        tender_data['jv_partner_qualification_others_criteria_amount']
    )

    parties = [p['jvmaster__party_name'] for p in party_details if p['jvmaster__party_name']]
    companies = [p['company__name'] for p in party_details if p['company__name']]

    party_names_str = ", ".join(parties) if parties else ""
    company_names_str = ", ".join(companies) if companies else ""

    jv_share_list = []
    for p in party_details:
        party_name = p.get('jvmaster__party_name')
        company_name = p.get('company__name')
        share = p.get('jv_share_percent')
        if share is not None:
            name = party_name or company_name  
            if name:
                jv_share_list.append(f"{name} - {share:.1f}%")
    jv_share_str = ", ".join(jv_share_list) if jv_share_list else ""
    context = {
        'tender_details': tender_data,
        'party_details': party_details,
        'jv_share_str' : jv_share_str,

        'pre_bid_meeting_date' : pre_bid_meeting_date,
        'bid_submission_date' : bid_submission_date,

        "technical_criteria_sum": technical_criteria_sum,
        "financial_criteria_sum": financial_criteria_sum,
        "bid_capacity_criteria_sum": bid_capacity_criteria_sum,
        "qualification_technical_criteria_sum": qualification_others_criteria_sum,  

        "party_names_str": party_names_str,
        "company_names_str": company_names_str,

        "id": tender_data['id'],
        "tender_id": tender_data['tender_id'],
        "name": tender_data['name'],
        "proposed_by_date": proposed_by_date,
        "tender_organization__employee_name": tender_data['tender_organization__employee_name'],
        "proposed_tender": tender_data['proposed_tender'],
        "state__name": tender_data['state__name'],
        "project_cost": tender_data['project_cost'],
        "emd_amount": tender_data['emd_amount'],
        "performance_security": tender_data['performance_security'],
        "tender_fee_cost": tender_data['tender_fee_cost'],
        "schedule_durations": tender_data['schedule_durations'],

        "tender_type": tender_data['tender_type'],
        "tender_jv_name": tender_data['tender_jv_name'],

        "tender_qualification_technical_criteria_amount": tender_data['tender_qualification_technical_criteria_amount'],
        "sinpl_qualification_technical_criteria_amount": tender_data['sinpl_qualification_technical_criteria_amount'],
        "jv_partner_qualification_technical_criteria_amount": tender_data['jv_partner_qualification_technical_criteria_amount'],

        "tender_qualification_financial_criteria_amount": tender_data['tender_qualification_financial_criteria_amount'],
        "sinpl_qualification_financial_criteria_amount": tender_data['sinpl_qualification_financial_criteria_amount'],
        "jv_partner_qualification_financial_criteria_amount": tender_data['jv_partner_qualification_financial_criteria_amount'],

        "tender_qualification_bid_capacity_criteria_amount": tender_data['tender_qualification_bid_capacity_criteria_amount'],
        "sinpl_qualification_bid_capacity_criteria_amount": tender_data['sinpl_qualification_bid_capacity_criteria_amount'],
        "jv_partner_qualification_bid_capacity_criteria_amount": tender_data['jv_partner_qualification_bid_capacity_criteria_amount'],

        "tender_qualification_others_criteria_amount": tender_data['tender_qualification_others_criteria_amount'],
        "sinpl_qualification_others_criteria_amount": tender_data['sinpl_qualification_others_criteria_amount'],
        "jv_partner_qualification_others_criteria_amount": tender_data['jv_partner_qualification_others_criteria_amount'],

        "similar_work_definition": tender_data['similar_work_definition'],

        "bank_guarantee_ref_page_no": tender_data['bank_guarantee_ref_page_no'],
        "board_resolution_ref_page_no": tender_data['board_resolution_ref_page_no'],
        "ca_certificate_ref_page_no": tender_data['ca_certificate_ref_page_no'],
        "poa_for_signing_of_tender_ref_page_no": tender_data['poa_for_signing_of_tender_ref_page_no'],
        "poa_of_lead_member_ref_page_no": tender_data['poa_of_lead_member_ref_page_no'],

        "finance_department_timeline":finance_department_timeline,
        "finance_remarks": tender_data['finance_remarks'],

        "secretarial_department_timeline": secretarial_department_timeline,
        "secretarial_remarks": tender_data['secretarial_remarks'],

        "accounts_department_timeline": accounts_department_timeline,
        "accounts_remarks": tender_data['accounts_remarks'],

        "tender_department_timeline": tender_department_timeline,
        "tender_remarks": tender_data['tender_remarks'],
        "price_escalation" : tender_data['price_escalation'],
        "ref_url" : f"{str(os.getenv('FF_TENDER_RECOMENDED_URL',''))}{tender_data['id']}",
        "fe_logo" : str(os.getenv('FE_LOGO','')),
    }
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-proposed-to'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-proposed-cc'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-PROPOSED', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)


def send_tender_recommended_approval_email(tender_id):
    """ 
        Tender Recommended but Documentation Pending, Frequency : On Recommend, 
        Email To - Ms Lisa Panja, Ms Sangeeta Mukherjee and Email CC: Gajendra Sir, Kousik Bhoumik Sir 
    """
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values(
        'id', 'tender_id', 'name', 'proposed_by_date', 'recommended_by_date', 'recommended_by__first_name', 'recommended_by__last_name', 'tender_organization__employee_name', 'proposed_tender',
        'state__name', 'project_cost', 'emd_amount', 'performance_security', 'tender_fee_cost',
        'pre_bid_meeting_date', 'schedule_durations', 'bid_submission_date',
        'tender_type', 'tender_qualification_technical_criteria_amount', 'sinpl_qualification_technical_criteria_amount',
        'jv_partner_qualification_technical_criteria_amount', 'tender_qualification_financial_criteria_amount',
        'sinpl_qualification_financial_criteria_amount', 'jv_partner_qualification_financial_criteria_amount',
        'tender_qualification_bid_capacity_criteria_amount', 'sinpl_qualification_bid_capacity_criteria_amount',
        'jv_partner_qualification_bid_capacity_criteria_amount', 'tender_qualification_others_criteria_amount',
        'sinpl_qualification_others_criteria_amount', 'jv_partner_qualification_others_criteria_amount',
        'similar_work_definition', 'tender_jv_name', 'bank_guarantee_ref_page_no',
        'finance_department_timeline', 'finance_remarks', 'board_resolution_ref_page_no',
        'secretarial_department_timeline', 'secretarial_remarks', 'ca_certificate_ref_page_no',
        'accounts_department_timeline', 'accounts_remarks', 'poa_for_signing_of_tender_ref_page_no',
        'tender_department_timeline', 'tender_remarks', 'poa_of_lead_member_ref_page_no', 'price_escalation',
    )

    if not tender_details:
        return 

    tender_data = tender_details[0]

    if tender_data['recommended_by_date']:
        date = tender_data['recommended_by_date'].strftime('%d-%m-%Y')
        recommended_by_date = tender_data['recommended_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        date = ""
        recommended_by_date = ""
    if tender_data['bid_submission_date']:
        bid_submission_date = tender_data['bid_submission_date'].strftime('%d-%m-%Y')
    else:
        bid_submission_date = ""

    if tender_data['pre_bid_meeting_date']:
        pre_bid_meeting_date = tender_data['pre_bid_meeting_date'].strftime('%d-%m-%Y')
    else:
        pre_bid_meeting_date = ""

    if tender_data['recommended_by__first_name']:
        first_name = tender_data['recommended_by__first_name']
        last_name = tender_data['recommended_by__last_name']
        recommended_by = f"{first_name} {last_name}"
    else:
        recommended_by = ""

    # Email subject
    subject = f"Approval of Recommended Tender ID {tender_data['tender_id']} - {tender_data['name']}, Recommended Date - {date}"

    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender_id=tender_id).select_related(
        'jvmaster', 'company'
    ).values(
        'jvmaster__party_name',
        'company__name',
        'jv_share_percent',
    )

    technical_criteria_sum = (
        tender_data['sinpl_qualification_technical_criteria_amount'] +
        tender_data['jv_partner_qualification_technical_criteria_amount']
    )
    financial_criteria_sum = (
        tender_data['sinpl_qualification_financial_criteria_amount'] +
        tender_data['jv_partner_qualification_financial_criteria_amount']
    )
    bid_capacity_criteria_sum = (
        tender_data['sinpl_qualification_bid_capacity_criteria_amount'] +
        tender_data['jv_partner_qualification_bid_capacity_criteria_amount']
    )
    qualification_others_criteria_sum = (
        tender_data['sinpl_qualification_others_criteria_amount'] +
        tender_data['jv_partner_qualification_others_criteria_amount']
    )

    parties = [p['jvmaster__party_name'] for p in party_details if p['jvmaster__party_name']]
    companies = [p['company__name'] for p in party_details if p['company__name']]

    party_names_str = ", ".join(parties) if parties else ""
    company_names_str = ", ".join(companies) if companies else ""

    jv_share_list = []
    for p in party_details:
        party_name = p.get('jvmaster__party_name')
        company_name = p.get('company__name')
        share = p.get('jv_share_percent')
        if share is not None:
            name = party_name or company_name  
            if name:
                jv_share_list.append(f"{name} - {share:.1f}%")
    jv_share_str = ", ".join(jv_share_list) if jv_share_list else ""

    finance_department_timeline = tender_data['finance_department_timeline'].strftime('%d-%m-%Y') if tender_data['finance_department_timeline'] else ""
    secretarial_department_timeline = tender_data['secretarial_department_timeline'].strftime('%d-%m-%Y') if tender_data['secretarial_department_timeline'] else ""
    accounts_department_timeline = tender_data['accounts_department_timeline'].strftime('%d-%m-%Y') if tender_data['accounts_department_timeline'] else ""
    tender_department_timeline = tender_data['tender_department_timeline'].strftime('%d-%m-%Y') if tender_data['tender_department_timeline'] else ""
    context = {
        'tender_details': tender_data,
        'party_details': party_details,
        'jv_share_str' : jv_share_str,

        "technical_criteria_sum": technical_criteria_sum,
        "financial_criteria_sum": financial_criteria_sum,
        "bid_capacity_criteria_sum": bid_capacity_criteria_sum,
        "qualification_technical_criteria_sum": qualification_others_criteria_sum,  
        "party_names_str": party_names_str,
        "company_names_str": company_names_str,

        "id": tender_data['id'],
        "tender_id": tender_data['tender_id'],
        "name": tender_data['name'],
        "recommended_by_date": recommended_by_date,
        "tender_organization__employee_name": tender_data['tender_organization__employee_name'],
        "proposed_tender": tender_data['proposed_tender'],
        "state__name": tender_data['state__name'],
        "project_cost": tender_data['project_cost'],
        "emd_amount": tender_data['emd_amount'],
        "performance_security": tender_data['performance_security'],
        "tender_fee_cost": tender_data['tender_fee_cost'],
        "pre_bid_meeting_date": pre_bid_meeting_date,
        "schedule_durations": tender_data['schedule_durations'],
        "bid_submission_date": bid_submission_date,

        "tender_type": tender_data['tender_type'],
        "tender_jv_name": tender_data['tender_jv_name'],

        "tender_qualification_technical_criteria_amount": tender_data['tender_qualification_technical_criteria_amount'],
        "sinpl_qualification_technical_criteria_amount": tender_data['sinpl_qualification_technical_criteria_amount'],
        "jv_partner_qualification_technical_criteria_amount": tender_data['jv_partner_qualification_technical_criteria_amount'],

        "tender_qualification_financial_criteria_amount": tender_data['tender_qualification_financial_criteria_amount'],
        "sinpl_qualification_financial_criteria_amount": tender_data['sinpl_qualification_financial_criteria_amount'],
        "jv_partner_qualification_financial_criteria_amount": tender_data['jv_partner_qualification_financial_criteria_amount'],

        "tender_qualification_bid_capacity_criteria_amount": tender_data['tender_qualification_bid_capacity_criteria_amount'],
        "sinpl_qualification_bid_capacity_criteria_amount": tender_data['sinpl_qualification_bid_capacity_criteria_amount'],
        "jv_partner_qualification_bid_capacity_criteria_amount": tender_data['jv_partner_qualification_bid_capacity_criteria_amount'],

        "tender_qualification_others_criteria_amount": tender_data['tender_qualification_others_criteria_amount'],
        "sinpl_qualification_others_criteria_amount": tender_data['sinpl_qualification_others_criteria_amount'],
        "jv_partner_qualification_others_criteria_amount": tender_data['jv_partner_qualification_others_criteria_amount'],

        "similar_work_definition": tender_data['similar_work_definition'],

        "bank_guarantee_ref_page_no": tender_data['bank_guarantee_ref_page_no'],
        "board_resolution_ref_page_no": tender_data['board_resolution_ref_page_no'],
        "ca_certificate_ref_page_no": tender_data['ca_certificate_ref_page_no'],
        "poa_for_signing_of_tender_ref_page_no": tender_data['poa_for_signing_of_tender_ref_page_no'],
        "poa_of_lead_member_ref_page_no": tender_data['poa_of_lead_member_ref_page_no'],

        "finance_department_timeline": finance_department_timeline,
        "finance_remarks": tender_data['finance_remarks'],

        "secretarial_department_timeline": secretarial_department_timeline,
        "secretarial_remarks": tender_data['secretarial_remarks'],

        "accounts_department_timeline": accounts_department_timeline,
        "accounts_remarks": tender_data['accounts_remarks'],

        "tender_department_timeline": tender_department_timeline,
        "tender_remarks": tender_data['tender_remarks'],
        "price_escalation" : tender_data['price_escalation'],
        "recommended_by" : recommended_by, 
        "ref_url" : f"{str(os.getenv('FF_TENDER_APPROVE_URL',''))}{tender_data['id']}",
        "fe_logo" : str(os.getenv('FE_LOGO','')),
    }
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-recommend-to'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-recommend-cc'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-RECOMMEND', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)

def send_tender_documentation_approval_email(tender_id):
    """ 
        Tender Documentation Completed but not Approved, Frequency : On Documentation Completed, 
        Email To - Gajendra Sir and Email CC: Kousik Bhoumik Sir, Mr Rajendra Nath Ray, Ms Lisa Panja, Ms Sangeeta Mukherjee 
    """
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values(
        'id', 'tender_id', 'name', 'documentation_by_date', 'tender_organization__employee_name', 'proposed_by__email', 'proposed_by_date',
        'proposed_by__first_name', 'proposed_by__last_name', 
    )
    if not tender_details:
        return
    tender = tender_details[0]
    subject = f"Request for Recommended Tender Documentation Update – Tender Id# {tender_details[0]['tender_id']} – Tender Name - {tender_details[0]['name']}"
    nit_doc = TenderMasterNewQualificationDocuments.cmobjects.filter(
        tender_id=tender_id,
        file_name__in=['NIT', 'RFP/Tender Documents']
    )
    is_doc_file = 1 if nit_doc else 0
    file_paths = []
    file_link = {
        'organization_id': 1,
        'tender_id': tender['id'],
        'all': 'true',
        'is_default_file__or__file_name__in': 'true__or__NIT,RFP/Tender Documents'
    }
    file_link_str = json.dumps(file_link)             
    file_link_bytes = file_link_str.encode('utf-8')   
    file_link_b64 = base64.urlsafe_b64encode(file_link_bytes).decode('utf-8') 
    doc_file_url = f"{str(os.getenv('FE_TENDER_DOC', '#'))}{file_link_b64}"
    if tender['documentation_by_date']:
        documentation_by_date = tender['documentation_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        documentation_by_date = ""
    if tender['proposed_by_date']:
        proposed_by_date = tender['proposed_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        proposed_by_date = ""
    proposed_by__first_name = tender['proposed_by__first_name']
    proposed_by__last_name = tender['proposed_by__last_name']
    proposed_by_name = f"{proposed_by__first_name} {proposed_by__last_name}"
    doc_view_url=f"{str(os.getenv('FF_TENDER_QUALIFICATION_DOC_DETAILS_URL',''))}{tender_id}"
    context = {
        'tender_details': tender_details[0],
        "id" : tender_id,
        "documentation_by_date" : documentation_by_date,
        "tender_id" : tender['tender_id'],
        "name" : tender['name'],
        "tender_organization__employee_name" : tender['tender_organization__employee_name'],
        "proposed_by__email" : tender['proposed_by__email'],
        "proposed_by_date" : proposed_by_date,
        'has_attachments': len(file_paths) > 0,
        'attachment_count': len(file_paths),
        'proposed_by_name' : proposed_by_name,
        "doc_file_url" : doc_file_url,
        "is_doc_file" : is_doc_file,
        "doc_view_url" : doc_view_url,
    }
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-documentation-to'],
        user__company__tender_master_new_company_deatils__tender_id=tender_id,
        level_permission=True,
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-documentation-cc'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-DOCUMENTATION', subject=subject, attachments=file_paths, 
        user_list=to_users_list, cc_user_list=cc_users_list, context=context)


def send_tender_director_approval_email(tender_id):
    """ 
        Tender Approved but "CHECK LIST" documentation pending,  Frequency : On Tender Approval
        Email To - Ms Lisa Panja, Ms Sangeeta Mukherjee and 
        Email CC: Gajendra Sir, Kousik Bhoumik Sir, Mr Rajendra Nath Ray 
    """
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values(
        'id', 'tender_id', 'name', 'tender_organization__employee_name', 'approved_by__email', 'approved_by_date',
        'approved_by__first_name', 'approved_by__last_name', 
    )
    if not tender_details:
        return
    
    tender = tender_details[0]
    subject = f"Request for Director Approval – Tender Id# {tender_details[0]['tender_id']} – Tender Name - {tender_details[0]['name']}"

    if tender['approved_by_date']:
        approved_by_date = tender['approved_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        approved_by_date = ""

    approved_by__first_name = tender['approved_by__first_name']
    approved_by__last_name = tender['approved_by__last_name']
    approved_by_name = f"{approved_by__first_name} {approved_by__last_name}"
    context = {
        'tender_details': tender_details[0],
        "id" : tender_id,
        "approved_by_date" : approved_by_date,
        "tender_id" : tender['tender_id'],
        "name" : tender['name'],
        'approved_by_name' : approved_by_name,
    }
    to_users_email = []
    cc_users_email = []

    to_users_list = list(PmsUser.objects.filter(email__in=to_users_email).values_list('id', flat=True))
    cc_users_list = list(PmsUser.objects.filter(email__in=cc_users_email).values_list('id', flat=True))
    trigger_notifications(action='TENDER-APPROVAL', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)

import os
def calculate_total_file_size(file_paths):
    total_size = 0
    for file_path in file_paths:
        try:
            if os.path.exists(file_path):
                total_size += os.path.getsize(file_path)
        except OSError as e:
            continue
    return total_size

# CHECKLIST
def send_tender_is_notify_department_email(tender_id):
    """ 
        Documentation Completed (including Check List) but not Approved
        Click on Notify Department, then click on YES (from the Pop-up message) then the email should be triggered
        To Users - gp@shyamsteel.com
        cc users - Kousik Bhoumik Sir,Mr Rajendra Nath Ray,Ms Lisa Panja,Ms Sangeeta Mukherjee
    """
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values(
        'id', 'tender_id', 'name', 'proposed_by_date', 'recommended_by_date', 'tender_organization__employee_name', 'proposed_tender',
        'state__name', 'project_cost', 'emd_amount', 'performance_security', 'tender_fee_cost',
        'pre_bid_meeting_date', 'schedule_durations', 'bid_submission_date',
        'tender_type', 'tender_qualification_technical_criteria_amount', 'sinpl_qualification_technical_criteria_amount',
        'jv_partner_qualification_technical_criteria_amount', 'tender_qualification_financial_criteria_amount',
        'sinpl_qualification_financial_criteria_amount', 'jv_partner_qualification_financial_criteria_amount',
        'tender_qualification_bid_capacity_criteria_amount', 'sinpl_qualification_bid_capacity_criteria_amount',
        'jv_partner_qualification_bid_capacity_criteria_amount', 'tender_qualification_others_criteria_amount',
        'sinpl_qualification_others_criteria_amount', 'jv_partner_qualification_others_criteria_amount',
        'similar_work_definition', 'tender_jv_name', 'bank_guarantee_ref_page_no',
        'finance_department_timeline', 'finance_remarks', 'board_resolution_ref_page_no',
        'secretarial_department_timeline', 'secretarial_remarks', 'ca_certificate_ref_page_no',
        'accounts_department_timeline', 'accounts_remarks', 'poa_for_signing_of_tender_ref_page_no',
        'tender_department_timeline', 'tender_remarks', 'poa_of_lead_member_ref_page_no', 'price_escalation',
    )
    if not tender_details:
        return 
    tender_data = tender_details[0]

    if tender_data['recommended_by_date']:
        date = tender_data['recommended_by_date'].strftime('%d-%m-%Y')
        recommended_by_date = tender_data['recommended_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        date = ""
        recommended_by_date = ""
    if tender_data['bid_submission_date']:
        bid_submission_date = tender_data['bid_submission_date'].strftime('%d-%m-%Y')
    else:
        bid_submission_date = ""

    if tender_data['pre_bid_meeting_date']:
        pre_bid_meeting_date = tender_data['pre_bid_meeting_date'].strftime('%d-%m-%Y')
    else:
        pre_bid_meeting_date = ""
    # Email subject
    subject = f"Final Approval required for Tender ID {tender_data['tender_id']} - {tender_data['name']}"
    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender_id=tender_id).select_related(
        'jvmaster', 'company'
    ).values(
        'jvmaster__party_name',
        'company__name',
        'jv_share_percent',
    )
    technical_criteria_sum = (
        tender_data['sinpl_qualification_technical_criteria_amount'] +
        tender_data['jv_partner_qualification_technical_criteria_amount']
    )
    financial_criteria_sum = (
        tender_data['sinpl_qualification_financial_criteria_amount'] +
        tender_data['jv_partner_qualification_financial_criteria_amount']
    )
    bid_capacity_criteria_sum = (
        tender_data['sinpl_qualification_bid_capacity_criteria_amount'] +
        tender_data['jv_partner_qualification_bid_capacity_criteria_amount']
    )
    qualification_others_criteria_sum = (
        tender_data['sinpl_qualification_others_criteria_amount'] +
        tender_data['jv_partner_qualification_others_criteria_amount']
    )
    parties = [p['jvmaster__party_name'] for p in party_details if p['jvmaster__party_name']]
    companies = [p['company__name'] for p in party_details if p['company__name']]

    party_names_str = ", ".join(parties) if parties else ""
    company_names_str = ", ".join(companies) if companies else ""

    jv_share_list = []
    for p in party_details:
        party_name = p.get('jvmaster__party_name')
        company_name = p.get('company__name')
        share = p.get('jv_share_percent')
        if share is not None:
            name = party_name or company_name  
            if name:
                jv_share_list.append(f"{name} - {share:.1f}%")
    jv_share_str = ", ".join(jv_share_list) if jv_share_list else ""
    finance_department_timeline = tender_data['finance_department_timeline'].strftime('%d-%m-%Y') if tender_data['finance_department_timeline'] else ""
    secretarial_department_timeline = tender_data['secretarial_department_timeline'].strftime('%d-%m-%Y') if tender_data['secretarial_department_timeline'] else ""
    accounts_department_timeline = tender_data['accounts_department_timeline'].strftime('%d-%m-%Y') if tender_data['accounts_department_timeline'] else ""
    tender_department_timeline = tender_data['tender_department_timeline'].strftime('%d-%m-%Y') if tender_data['tender_department_timeline'] else ""
    context = {
        'tender_details': tender_data,
        'party_details': party_details,
        'jv_share_str' : jv_share_str,

        "technical_criteria_sum": technical_criteria_sum,
        "financial_criteria_sum": financial_criteria_sum,
        "bid_capacity_criteria_sum": bid_capacity_criteria_sum,
        "qualification_technical_criteria_sum": qualification_others_criteria_sum,  
        "party_names_str": party_names_str,
        "company_names_str": company_names_str,

        "id": tender_data['id'],
        "tender_id": tender_data['tender_id'],
        "name": tender_data['name'],
        "recommended_by_date": recommended_by_date,
        "tender_organization__employee_name": tender_data['tender_organization__employee_name'],
        "proposed_tender": tender_data['proposed_tender'],
        "state__name": tender_data['state__name'],
        "project_cost": tender_data['project_cost'],
        "emd_amount": tender_data['emd_amount'],
        "performance_security": tender_data['performance_security'],
        "tender_fee_cost": tender_data['tender_fee_cost'],
        "pre_bid_meeting_date": pre_bid_meeting_date,
        "schedule_durations": tender_data['schedule_durations'],
        "bid_submission_date": bid_submission_date,

        "tender_type": tender_data['tender_type'],
        "tender_jv_name": tender_data['tender_jv_name'],

        "tender_qualification_technical_criteria_amount": tender_data['tender_qualification_technical_criteria_amount'],
        "sinpl_qualification_technical_criteria_amount": tender_data['sinpl_qualification_technical_criteria_amount'],
        "jv_partner_qualification_technical_criteria_amount": tender_data['jv_partner_qualification_technical_criteria_amount'],

        "tender_qualification_financial_criteria_amount": tender_data['tender_qualification_financial_criteria_amount'],
        "sinpl_qualification_financial_criteria_amount": tender_data['sinpl_qualification_financial_criteria_amount'],
        "jv_partner_qualification_financial_criteria_amount": tender_data['jv_partner_qualification_financial_criteria_amount'],

        "tender_qualification_bid_capacity_criteria_amount": tender_data['tender_qualification_bid_capacity_criteria_amount'],
        "sinpl_qualification_bid_capacity_criteria_amount": tender_data['sinpl_qualification_bid_capacity_criteria_amount'],
        "jv_partner_qualification_bid_capacity_criteria_amount": tender_data['jv_partner_qualification_bid_capacity_criteria_amount'],

        "tender_qualification_others_criteria_amount": tender_data['tender_qualification_others_criteria_amount'],
        "sinpl_qualification_others_criteria_amount": tender_data['sinpl_qualification_others_criteria_amount'],
        "jv_partner_qualification_others_criteria_amount": tender_data['jv_partner_qualification_others_criteria_amount'],

        "similar_work_definition": tender_data['similar_work_definition'],

        "bank_guarantee_ref_page_no": tender_data['bank_guarantee_ref_page_no'],
        "board_resolution_ref_page_no": tender_data['board_resolution_ref_page_no'],
        "ca_certificate_ref_page_no": tender_data['ca_certificate_ref_page_no'],
        "poa_for_signing_of_tender_ref_page_no": tender_data['poa_for_signing_of_tender_ref_page_no'],
        "poa_of_lead_member_ref_page_no": tender_data['poa_of_lead_member_ref_page_no'],

        "finance_department_timeline": finance_department_timeline,
        "finance_remarks": tender_data['finance_remarks'],

        "secretarial_department_timeline": secretarial_department_timeline,
        "secretarial_remarks": tender_data['secretarial_remarks'],

        "accounts_department_timeline": accounts_department_timeline,
        "accounts_remarks": tender_data['accounts_remarks'],

        "tender_department_timeline": tender_department_timeline,
        "tender_remarks": tender_data['tender_remarks'],
        "price_escalation" : tender_data['price_escalation'],
        "fe_logo" : str(os.getenv('FE_LOGO','')),
        "ref_url" : f"{str(os.getenv('FF_TENDER_APPROVE_URL',''))}{tender_data['id']}",
    }
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-checklist-notify-to'],
        level_permission=True,
        user__company__tender_master_new_company_deatils__tender_id=tender_data['id'],
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-checklist-notify-cc'],
        level_permission=True,
        user__company__tender_master_new_company_deatils__tender_id=tender_data['id'],
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-CHECKLIST-NOTIFY-DEPARTMENT', subject=subject, user_list=to_users_list, 
                          cc_user_list=cc_users_list, context=context)

def send_tender_director_approval_checklist_attached(tender_id):
    """
        Director Approved
        Click on On Tender Approval Triggered
        To Users - tender.documents@shyaminfra.com
        cc users - Gajendra Sir, Kousik Bhoumik Sir, Mr Rajendra Nath Ray, Ms Lisa Panja, Ms Sangeeta Mukherjee
    """
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values(
        'id', 'tender_id', 'name', 'proposed_by_date', 'recommended_by_date', 'approved_by__first_name', 'approved_by__last_name', 
        'tender_organization__employee_name', 'proposed_tender',
        'state__name', 'project_cost', 'emd_amount', 'performance_security', 'tender_fee_cost',
        'pre_bid_meeting_date', 'schedule_durations', 'bid_submission_date',
        'tender_type', 'tender_qualification_technical_criteria_amount', 'sinpl_qualification_technical_criteria_amount',
        'jv_partner_qualification_technical_criteria_amount', 'tender_qualification_financial_criteria_amount',
        'sinpl_qualification_financial_criteria_amount', 'jv_partner_qualification_financial_criteria_amount',
        'tender_qualification_bid_capacity_criteria_amount', 'sinpl_qualification_bid_capacity_criteria_amount',
        'jv_partner_qualification_bid_capacity_criteria_amount', 'tender_qualification_others_criteria_amount',
        'sinpl_qualification_others_criteria_amount', 'jv_partner_qualification_others_criteria_amount',
        'similar_work_definition', 'tender_jv_name', 'bank_guarantee_ref_page_no',
        'finance_department_timeline', 'finance_remarks', 'board_resolution_ref_page_no',
        'secretarial_department_timeline', 'secretarial_remarks', 'ca_certificate_ref_page_no',
        'accounts_department_timeline', 'accounts_remarks', 'poa_for_signing_of_tender_ref_page_no',
        'tender_department_timeline', 'tender_remarks', 'poa_of_lead_member_ref_page_no', 'price_escalation', 'approved_by_date'
    )
    if not tender_details:
        return 

    tender_data = tender_details[0]

    if tender_data['approved_by__first_name'] and tender_data['approved_by__last_name']:
        first_name = tender_data['approved_by__first_name']
        last_name = tender_data['approved_by__last_name']
        approved_by = f"{first_name} {last_name}"
    else:
        approved_by = ""

    if tender_data['recommended_by_date']:
        date = tender_data['recommended_by_date'].strftime('%d-%m-%Y')
        recommended_by_date = tender_data['recommended_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        date = ""
        recommended_by_date = ""

    if tender_data['approved_by_date']:
        approved_by_date = tender_data['approved_by_date'].strftime('%d-%m-%Y %H:%M:%S')
    else:
        approved_by_date = ""

    if tender_data['bid_submission_date']:
        bid_submission_date = tender_data['bid_submission_date'].strftime('%d-%m-%Y')
    else:
        bid_submission_date = ""

    if tender_data['pre_bid_meeting_date']:
        pre_bid_meeting_date = tender_data['pre_bid_meeting_date'].strftime('%d-%m-%Y')
    else:
        pre_bid_meeting_date = ""

    # Email subject
    subject = f"Final Approval Granted for Tender ID {tender_data['tender_id']} - {tender_data['name']}"

    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender_id=tender_id).select_related(
        'jvmaster', 'company'
    ).values(
        'jvmaster__party_name',
        'company__name',
        'jv_share_percent',
    )

    technical_criteria_sum = (
        tender_data['sinpl_qualification_technical_criteria_amount'] +
        tender_data['jv_partner_qualification_technical_criteria_amount']
    )
    financial_criteria_sum = (
        tender_data['sinpl_qualification_financial_criteria_amount'] +
        tender_data['jv_partner_qualification_financial_criteria_amount']
    )
    bid_capacity_criteria_sum = (
        tender_data['sinpl_qualification_bid_capacity_criteria_amount'] +
        tender_data['jv_partner_qualification_bid_capacity_criteria_amount']
    )
    qualification_others_criteria_sum = (
        tender_data['sinpl_qualification_others_criteria_amount'] +
        tender_data['jv_partner_qualification_others_criteria_amount']
    )

    parties = [p['jvmaster__party_name'] for p in party_details if p['jvmaster__party_name']]
    companies = [p['company__name'] for p in party_details if p['company__name']]

    party_names_str = ", ".join(parties) if parties else ""
    company_names_str = ", ".join(companies) if companies else ""

    jv_share_list = []
    for p in party_details:
        party_name = p.get('jvmaster__party_name')
        company_name = p.get('company__name')
        share = p.get('jv_share_percent')
        if share is not None:
            name = party_name or company_name  
            if name:
                jv_share_list.append(f"{name} - {share:.1f}%")
    jv_share_str = ", ".join(jv_share_list) if jv_share_list else ""

    finance_department_timeline = tender_data['finance_department_timeline'].strftime('%d-%m-%Y') if tender_data['finance_department_timeline'] else ""
    secretarial_department_timeline = tender_data['secretarial_department_timeline'].strftime('%d-%m-%Y') if tender_data['secretarial_department_timeline'] else ""
    accounts_department_timeline = tender_data['accounts_department_timeline'].strftime('%d-%m-%Y') if tender_data['accounts_department_timeline'] else ""
    tender_department_timeline = tender_data['tender_department_timeline'].strftime('%d-%m-%Y') if tender_data['tender_department_timeline'] else ""

    #attachment
    checklist_docs = TenderMasterNewQualificationDocuments.cmobjects.filter(
        Q(tender_id=tender_id) &
        (
            Q(doc_type="checklist_document") |
            Q(is_default_file=True) |
            Q(file_name__in=['NIT', 'RFP/Tender Documents'])
        )
    )
    is_checklist_docs = 1 if checklist_docs else 0

    # file_paths = [str(doc.attachment) for doc in checklist_docs if doc.attachment]

    file_link = {
        'organization_id': 1,
        'tender_id': tender_data['id'],
        'all': 'true',
        'doc_type__exact__or__is_default_file__or__file_name__in': 'checklist_document__or__true__or__NIT,RFP/Tender Documents'
    }
    file_link_str = json.dumps(file_link)             
    file_link_bytes = file_link_str.encode('utf-8')   
    file_link_b64 = base64.urlsafe_b64encode(file_link_bytes).decode('utf-8') 
    doc_file_url = f"{str(os.getenv('FE_TENDER_DOC', '#'))}{file_link_b64}"
    context = {
        'tender_details': tender_data,
        'party_details': party_details,
        'jv_share_str' : jv_share_str,

        "technical_criteria_sum": technical_criteria_sum,
        "financial_criteria_sum": financial_criteria_sum,
        "bid_capacity_criteria_sum": bid_capacity_criteria_sum,
        "qualification_technical_criteria_sum": qualification_others_criteria_sum,  
        "party_names_str": party_names_str,
        "company_names_str": company_names_str,

        "id": tender_data['id'],
        "tender_id": tender_data['tender_id'],
        "name": tender_data['name'],
        "recommended_by_date": recommended_by_date,
        "approved_by_date" : approved_by_date,
        "tender_organization__employee_name": tender_data['tender_organization__employee_name'],
        "proposed_tender": tender_data['proposed_tender'],
        "state__name": tender_data['state__name'],
        "project_cost": tender_data['project_cost'],
        "emd_amount": tender_data['emd_amount'],
        "performance_security": tender_data['performance_security'],
        "tender_fee_cost": tender_data['tender_fee_cost'],
        "pre_bid_meeting_date": pre_bid_meeting_date,
        "schedule_durations": tender_data['schedule_durations'],
        "bid_submission_date": bid_submission_date,

        "tender_type": tender_data['tender_type'],
        "tender_jv_name": tender_data['tender_jv_name'],

        "tender_qualification_technical_criteria_amount": tender_data['tender_qualification_technical_criteria_amount'],
        "sinpl_qualification_technical_criteria_amount": tender_data['sinpl_qualification_technical_criteria_amount'],
        "jv_partner_qualification_technical_criteria_amount": tender_data['jv_partner_qualification_technical_criteria_amount'],

        "tender_qualification_financial_criteria_amount": tender_data['tender_qualification_financial_criteria_amount'],
        "sinpl_qualification_financial_criteria_amount": tender_data['sinpl_qualification_financial_criteria_amount'],
        "jv_partner_qualification_financial_criteria_amount": tender_data['jv_partner_qualification_financial_criteria_amount'],

        "tender_qualification_bid_capacity_criteria_amount": tender_data['tender_qualification_bid_capacity_criteria_amount'],
        "sinpl_qualification_bid_capacity_criteria_amount": tender_data['sinpl_qualification_bid_capacity_criteria_amount'],
        "jv_partner_qualification_bid_capacity_criteria_amount": tender_data['jv_partner_qualification_bid_capacity_criteria_amount'],

        "tender_qualification_others_criteria_amount": tender_data['tender_qualification_others_criteria_amount'],
        "sinpl_qualification_others_criteria_amount": tender_data['sinpl_qualification_others_criteria_amount'],
        "jv_partner_qualification_others_criteria_amount": tender_data['jv_partner_qualification_others_criteria_amount'],

        "similar_work_definition": tender_data['similar_work_definition'],

        "bank_guarantee_ref_page_no": tender_data['bank_guarantee_ref_page_no'],
        "board_resolution_ref_page_no": tender_data['board_resolution_ref_page_no'],
        "ca_certificate_ref_page_no": tender_data['ca_certificate_ref_page_no'],
        "poa_for_signing_of_tender_ref_page_no": tender_data['poa_for_signing_of_tender_ref_page_no'],
        "poa_of_lead_member_ref_page_no": tender_data['poa_of_lead_member_ref_page_no'],

        "finance_department_timeline": finance_department_timeline,
        "finance_remarks": tender_data['finance_remarks'],

        "secretarial_department_timeline": secretarial_department_timeline,
        "secretarial_remarks": tender_data['secretarial_remarks'],

        "accounts_department_timeline": accounts_department_timeline,
        "accounts_remarks": tender_data['accounts_remarks'],

        "tender_department_timeline": tender_department_timeline,
        "tender_remarks": tender_data['tender_remarks'],
        "price_escalation" : tender_data['price_escalation'],
        "approved_by" : approved_by,
        "doc_file_url" : doc_file_url,
        "is_checklist_docs" : is_checklist_docs,
        "fe_logo" : str(os.getenv('FE_LOGO','')),
    }
    file_paths = []
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-director-approved-to'],
        level_permission=True,
        user__company__tender_master_new_company_deatils__tender_id=tender_data['id'],
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-director-approved-cc'],
        level_permission=True,
        user__company__tender_master_new_company_deatils__tender_id=tender_data['id'],
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-DIR-APPROVAL-WITH-CHECKLIST-DOC', attachments=file_paths, subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)

def send_tender_checklist_doc_update_email(tender_id):
    """
        Tender  "CHECK LIST" documentation doneg,  Frequency : On CHECK LIST Done
        Email To - tender.documents@shyaminfra.com
        Email CC: Gajendra Sir, Kousik Bhoumik Sir, Mr Rajendra Nath Ray
    """
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).select_related('sector', 'tender_organization').values(
        'id', 'tender_id', 'name', 'tender_organization__employee_name', 'tender_jv_name', 'tender_fee_cost',
        'approved_by__first_name', 'approved_by__last_name', 'created_at', 'project_cost', 'proposed_tender',
        'bid_submission_date', 'pre_bid_meeting_date', 'tender_type', 'price_variation_clause', 
    )
    if not tender_details:
        return
    tender_data = tender_details[0]
    if tender_data['bid_submission_date']:
        bid_submission_date = tender_data['bid_submission_date'].strftime('%d-%m-%Y')
    else:
        bid_submission_date = ""

    if tender_data['pre_bid_meeting_date']:
        pre_bid_meeting_date = tender_data['pre_bid_meeting_date'].strftime('%d-%m-%Y')
    else:
        pre_bid_meeting_date = ""

    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender_id=tender_id).select_related(
        'jvmaster', 'company'
    ).values(
        'jvmaster__party_name',
        'company__name',
        'jv_share_percent',
    )
    parties = [p['jvmaster__party_name'] for p in party_details if p['jvmaster__party_name']]
    companies = [p['company__name'] for p in party_details if p['company__name']]
    party_names_str = ", ".join(parties) if parties else ""
    company_names_str = ", ".join(companies) if companies else ""

    jv_share_list = []
    for p in party_details:
        party_name = p.get('jvmaster__party_name')
        company_name = p.get('company__name')
        share = p.get('jv_share_percent')
        if share is not None:
            name = party_name or company_name  
            if name:
                jv_share_list.append(f"{name} - {share:.1f}%")
    jv_share_str = ", ".join(jv_share_list) if jv_share_list else ""

    # checklist
    checklist_list = TenderChecklistMaster.cmobjects.values('id', 'name')
    checklist_doc_list = []
    for item in checklist_list:
        name = item['name']
        for doc_item in TenderMasterNewQualificationDocuments.cmobjects.filter(
            checklist_id=item['id']
        ).values('reference_page_no', 'tender_department__name'):
            # timeline =  doc_item['timeline'].strftime("%d-%m-%Y") if doc_item['timeline'] else ""
            data = {
                "name": name,
                "reference_page_no": doc_item['reference_page_no'],
                "tender_department": doc_item['tender_department__name'],
            }
            checklist_doc_list.append(data)

    #attachment
    checklist_docs = TenderMasterNewQualificationDocuments.cmobjects.filter(
        tender_id=tender_id,
        doc_type = "checklist_document",
    )
    file_paths = [doc.attachment.path for doc in checklist_docs if doc.attachment]
    
    total_size_bytes = calculate_total_file_size(file_paths)

    print("total_size_bytes ###", total_size_bytes)
    context = {
        'tender_details': tender_details[0],
        "tender_organization__employee_name": tender_data['tender_organization__employee_name'],
        'tender_id' : tender_data['tender_id'],
        "proposed_tender": tender_data['proposed_tender'],
        "id" : tender_id,
        "created_at" : tender_data['created_at'].strftime("%d-%m-%Y %H:%M:%S"),
        "bid_submission_date" : bid_submission_date,
        "pre_bid_meeting_date" : pre_bid_meeting_date,
        'tender_type' : tender_data['tender_type'],
        "checklist_list" : checklist_doc_list,
        "price_variation_clause" : tender_data['price_variation_clause'],
        "jv_share_str" : jv_share_str,
        "party_names_str" : party_names_str,
    }

    to_users_email = []
    cc_users_email = []

    subject = f"Tender Documentation Update – Tender Id# {tender_data['tender_id']} – Tender Name - {tender_data['name']}"

    to_users_list = list(PmsUser.objects.filter(email__in=to_users_email).values_list('id', flat=True))
    cc_users_list = list(PmsUser.objects.filter(email__in=cc_users_email).values_list('id', flat=True))
    trigger_notifications(action='TENDER-CHECKLIST-DOC-UPDATE', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)


def send_purchase_order_items_delivered_status_email():
    eight_days_ago = (timezone.now().date() - timedelta(days=8)).isoformat()

    factory = RequestFactory()
    user = PmsUser.objects.first()
    if not user:
        raise Exception("No PmsUser found to authenticate the API request.")

    query_params = {
        'organization_id': '1',
        'is_delivered__or__delivered_date__gte': f'false__or__{eight_days_ago}',
        'page_size': 100000,
        'order_by': '-id'
    }

    django_request = factory.get('/procurement-purchase-order-items-search/', query_params)
    force_authenticate(django_request, user=user)
    django_request.user = user

    api_view = PurchaseOrderItemsSearchAPIView()
    response = api_view.dispatch(django_request)
    response.render() 

    data = response.data.get('results', {})
    purchase_order_items = data if isinstance(data, list) else data.get('Data', [])

    items_by_site = defaultdict(list)
    for item in purchase_order_items:
        site_name = item.get('purchase_order__delivery_site__site_name', 'Unknown Site')
        items_by_site[site_name].append(item)

    to_emails = []
    cc_emails = []

    to_users_list = list(PmsUser.objects.filter(email__in=to_emails).values_list('id', flat=True))
    cc_users_list = list(PmsUser.objects.filter(email__in=cc_emails).values_list('id', flat=True))

    if not to_users_list:
        raise Exception("No recipient users found for the notification.")

    print("TOT Count ###", len(purchase_order_items))
    current_date = timezone.now()
    for site_name, items in items_by_site.items():
        print(f"items TYPE={type(items)}")
        context = {
            "report_date": current_date.strftime('%d-%m-%Y %H:%M:%S'),
            "current_date": current_date.date(),
            "site_name": site_name,
            "purchase_items_list": items,
            "tot_count" : len(purchase_order_items),
        }
        subject = f"INFRA : {site_name} // PO Tracker"
        try:
            trigger_notifications(
                action='PO-DELIVERED-STATUS',
                subject=subject,
                user_list=to_users_list,
                cc_user_list=cc_users_list,
                context=context
            )
        except Exception as e:
            print(f"Failed to send notification for site {site_name}: {str(e)}")




### Auto Reminder Email **

def send_tender_proposer_reminder_email():
    """ 
        Reminder Email for Proposer, if no action taken, every 24 Hours
        Email To - Mr Rajendra Nath Ray
        Email CC: Gajendra Sir, Kousik Bhoumik Sir 
    """
    tender_list = [
        {
            'id': t['id'],
            'tender_id': t['tender_id'],
            'tender_name': t['name'],
            'created_at': t['created_at'].strftime('%d-%m-%Y %H:%M:%S') if t['created_at'] else ''
        }
        for t in TenderMasterNew.cmobjects.filter(
            status="live", is_archived=False
        ).values(
            'id', 'tender_id', 'name', 'created_at'
        )
    ]
    if not tender_list:
        return
    tender = tender_list[0]
    subject = f"Reminder – Action Required for following tender list"
    context = {
        'subject' : subject,
        'tender_list' : tender_list,
        'tender_count': len(tender_list),   
        'date': datetime.now().strftime("%Y-%m-%d"),
    }
    to_users_email  = []
    cc_users_email = []
    
    to_users_list = list(PmsUser.objects.filter(email__in=to_users_email).values_list('id', flat=True))
    cc_users_list = list(PmsUser.objects.filter(email__in=cc_users_email).values_list('id', flat=True))
    trigger_notifications(action='TENDER-PROPOSER-REMINDER', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)






def send_tender_recommender_reminder_email(id, tender_id, tender_name, proposed_by_date):
    """ 
        Reminder Email for Recommender, if no action taken, every 24 Hours
        Email To - Kousik Bhoumik Sir
        Email CC: Gajendra Sir
    """
    subject = f": Reminder – Action Required on Tender ID# {tender_id}"  
    context = {
        "id" : id,
        "tender_id" : tender_id,
        "tender_name" : tender_name,
        "proposed_by_date" : proposed_by_date,
        "date" : datetime.now().strftime("%Y-%m-%d"),
    }
    to_users_email  = []
    cc_users_email = []
    
    to_users_list = list(PmsUser.objects.filter(email__in=to_users_email).values_list('id', flat=True))
    cc_users_list = list(PmsUser.objects.filter(email__in=cc_users_email).values_list('id', flat=True))
    trigger_notifications(action='TENDER-RECOMMENDER-REMINDER', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)



def send_tender_documentation_reminder_email(id, tender_id, tender_name, recommended_by_date):
    """ 
        Reminder Email for Documentation, if no action taken, every 24 Hours
        Email To - Ms Lisa Panja, Ms Sangeeta Mukherjee
        Email CC: Gajendra Sir, Kousik Bhoumik Sir
    """
    subject = f": Reminder – Action Required on Tender ID# {tender_id}"
    context = {
        "id" : id,
        "tender_id" : tender_id,
        'tender_name':tender_name,
        "recommended_by_date" : recommended_by_date,
        "date" : datetime.now().strftime("%Y-%m-%d"),
    }
    to_users_email  =  []
    cc_users_email = []
    
    to_users_list = list(PmsUser.objects.filter(email__in=to_users_email).values_list('id', flat=True))
    cc_users_list = list(PmsUser.objects.filter(email__in=cc_users_email).values_list('id', flat=True))
    trigger_notifications(action='TENDER-DOCUMENTATION-REMINDER', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)



def send_tender_approval_reminder_email(tender_id, tender_name, documentation_by_date):
    """ 
        Reminder Email  for Approval, if no action taken, every 24 Hours
        Email To - Gajendra Sir
        Email CC: Kousik Bhoumik Sir, Mr Rajendra Nath Ray, Ms Lisa Panja, Ms Sangeeta Mukherjee
    """
    subject = f": Reminder – Action Required on Tender ID# {tender_id}"
    context = {
        "id" : id,
        "tender_id" : tender_id,
        'tender_name':tender_name,
        "documentation_by_date" : documentation_by_date,
        "date" : datetime.now().strftime("%Y-%m-%d"),
    }
    to_users_email  = []
    cc_users_email = []
    
    to_users_list = list(PmsUser.objects.filter(email__in=to_users_email).values_list('id', flat=True))
    cc_users_list = list(PmsUser.objects.filter(email__in=cc_users_email).values_list('id', flat=True))
    trigger_notifications(action='TENDER-APPROVAL-REMINDER', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)


##########################  OLD EMAIL FUNCTIONS ###################
def send_tender_approval_email(tender_id):
    tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).first()
    if not tender_details:
        return
    if tender_details.recommended_by_date:
        date = tender_details.recommended_by_date.strftime('%d-%m-%Y')
    else:
        date = ""
    subject = f"Approval for Recommended Tender ID {tender_details.tender_id}, Recommended Date - {date}"

    plaintext = get_template('send_tender_approval_email.txt')
    htmly = get_template('send_tender_approval_email.html')

    party_details = TenderMasterNewPartyDetails.cmobjects.filter(tender=tender_details)
    approval_users = UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__exact="pre-tender-send-for-approver", level_permission=True
    )

    technical_criteria_sum = tender_details.sinpl_qualification_technical_criteria_amount + tender_details.jv_partner_qualification_technical_criteria_amount
    financial_criteria_sum = tender_details.sinpl_qualification_financial_criteria_amount + tender_details.jv_partner_qualification_financial_criteria_amount
    bid_capacity_criteria_sum = tender_details.sinpl_qualification_bid_capacity_criteria_amount + tender_details.jv_partner_qualification_bid_capacity_criteria_amount
    qualification_technical_criteria_sum = tender_details.sinpl_qualification_others_criteria_amount + tender_details.tender_qualification_others_criteria_amount
    
    party_names = [
        item.jvmaster.party_name
        for item in party_details
        if item.jvmaster and item.jvmaster.party_name
    ]
    party_names_str = ", ".join(party_names)

    context = {
        'tender_details': tender_details,
        'party_details': party_details,
        "technical_criteria_sum" : technical_criteria_sum,
        "financial_criteria_sum" : financial_criteria_sum,
        "bid_capacity_criteria_sum" : bid_capacity_criteria_sum,
        "qualification_technical_criteria_sum" : qualification_technical_criteria_sum,
        "party_names_str" : party_names_str,
    }

    to_users_email  = []
    cc_users_email = []

def send_tender_proposed_auto_reminder_email():
    tender_details = TenderMasterNew.cmobjects.filter(id=id).first()
    if not tender_details:
        return
    subject = f"Approval Request for Pending Tender – Tender Id {tender_details.tender_id} –  Tender Name - {tender_details.name}"

    plaintext = get_template('tender_proposed_auto_reminder_email.txt')
    htmly = get_template('tender_proposed_auto_reminder_email.html')

    to_emails = []

    if not to_emails:
        return
    context = {
        'tender_details': tender_details,
    }
    from_email = "info@sftnirman.com"
    text_content = plaintext.render(context)
    html_content = htmly.render(context)

    # msg = EmailMultiAlternatives(subject, text_content, from_email, to_emails)
    # msg.attach_alternative(html_content, "text/html")
    # msg.send()

def send_tender_on_going_email():
    tender_details = TenderMasterNew.cmobjects.filter(id=id).first()
    if not tender_details:
        return
    subject = f"Supportive documents - Tender Id# {tender_details.tender_id} –  Tender Name - {tender_details.name}"

    plaintext = get_template('tender_on_going_email.txt')
    htmly = get_template('tender_on_going_email.html')

    to_emails = []

    if not to_emails:
        return
    context = {
        'tender_details': tender_details,
    }
    from_email = "info@sftnirman.com"
    text_content = plaintext.render(context)
    html_content = htmly.render(context)

    # msg = EmailMultiAlternatives(subject, text_content, from_email, to_emails)
    # msg.attach_alternative(html_content, "text/html")
    # msg.send()



#### Procurement Modules ...
from django.db.models import Sum
def send_payment_director_approval_email(payment_approval_ids):
    """ 
    After Final Approval (Director-Approval), an auto email should be shared with 
    (To: Accounts and CC: procurement@shyaminfra.com)-format of the same, already shared.
    """
    subject = " Payment Advice - Final Approval Notification"

    plaintext = get_template('payment/payment_director_approval_email.txt')
    htmly = get_template('payment/payment_director_approval_email.html')

    to_email = []
    to_cc = [
      
      
    ]
    
    payment_list = PaymentMaster.cmobjects.filter(id__in=payment_approval_ids).order_by('id')
    total_amount = payment_list.aggregate(total=Sum('amount'))['total']
    
    context = {
        "total_amount" : total_amount,
        "payment_list" : payment_list,
    } 
    from_email = "info@sftnirman.com"
    text_content = plaintext.render(context)
    html_content = htmly.render(context)

    # msg = EmailMultiAlternatives(subject, text_content, from_email, to_email, to_cc)
    # msg.attach_alternative(html_content, "text/html")
    # msg.send()


def send_indent_director_approval_email(approved_item_ids):
    """ 
    In CST (Both), on Director Approval, an auto email should be shared with "procurement@shyaminfra.com"
    """
    subject = ""
    plaintext = get_template('indent/send_indent_director_approval_email.txt')
    htmly = get_template('indent/send_indent_director_approval_email.html')

    to_email = [
        
    ]
    to_cc = [
    ]
    context = {

    }   
    from_email = "info@sftnirman.com"
    text_content = plaintext.render(context)
    html_content = htmly.render(context)

    # msg = EmailMultiAlternatives(subject, text_content, from_email, to_email, to_cc)
    # msg.attach_alternative(html_content, "text/html")
    # msg.send()


def send_payment_module_update_email(id):
    subject = ""
    plaintext = get_template('indent/send_indent_director_approval_email.txt')
    htmly = get_template('indent/send_indent_director_approval_email.html')
    
    to_email = []
    to_cc = [
       
       
    ]
    context = {

    }   
    from_email = "info@sftnirman.com"
    text_content = plaintext.render(context)
    html_content = htmly.render(context)

    # msg = EmailMultiAlternatives(subject, text_content, from_email, to_email, to_cc)
    # msg.attach_alternative(html_content, "text/html")
    # msg.send()


def send_vendor_request_approval_email(vaendor_approval_ids):
    """  
    Vendor Master-On completion of vendor request approval , please share bank details along with all the 
    attached documents via auto email to 
    Mr Tamojit Paul tamojit.paul@shyamsteel.com and CC : @Procurement-INFRA HO.
    """

    subject = "Vendor code creation"
    plaintext = get_template('vendor/send_vendor_request_approval_email.txt')
    htmly = get_template('vendor/send_vendor_request_approval_email.html')

    to_email = []
    to_cc = [
    ]
    context = {}
        
       
    from_email = "info@sftnirman.com"
    text_content = plaintext.render(context)
    html_content = htmly.render(context)

    # msg = EmailMultiAlternatives(subject, text_content, from_email, to_email, to_cc)
    # msg.attach_alternative(html_content, "text/html")
    # msg.send()


# Tender
def send_tender_reject_request_email(tender_id):
    """ 
        Tender Reject Request Email
    """
    tender_details = (
        TenderMasterNew.cmobjects
        .select_related('reject_request_by')
        .filter(id=tender_id)
        .annotate(
            reject_request_by_user_full_name=Concat(
                'reject_request_by__first_name',
                Value(' '),
                'reject_request_by__last_name',
                output_field=CharField()
            )
        )
        .values(
            'id',
            'tender_id',
            'name',
            'reject_request_by_user_full_name',
            'reject_request_date',
            'reject_request_remarks',
        )
    ).first()
    if not tender_details:
        return
    reject_doc = TenderMasterNewQualificationDocuments.cmobjects.filter(
        tender_id=tender_id,
        doc_type__exact = 'reject_document',
    )
    is_doc_file = 1 if reject_doc else 0
    file_link = {
        'organization_id': 1,
        'tender_id': tender_id,
        'all': 'true',
        'doc_type__exact': 'reject_document',
    }
    file_link_str = json.dumps(file_link)             
    file_link_bytes = file_link_str.encode('utf-8')   
    file_link_b64 = base64.urlsafe_b64encode(file_link_bytes).decode('utf-8') 
    doc_file_url = f"{str(os.getenv('FE_TENDER_DOC', '#'))}{file_link_b64}"
    context = tender_details
    context['doc_file_url'] = doc_file_url
    context['is_doc_file'] = is_doc_file
    context['current_datetime'] = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    context['ref_url'] = f"{str(os.getenv('FF_TENDER_REJECT_REQUEST_URL', '#'))}{tender_id}"
    subject = f"Request for Reject – Tender Id {tender_details['tender_id']} – Tender Name - {tender_details['name']}"
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-reject-request-to'],
        level_permission=True,
        user__company__tender_master_new_company_deatils__tender_id=tender_id,
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-reject-request-cc'],
        level_permission=True,
        user__company__tender_master_new_company_deatils__tender_id=tender_id,
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-REJECT-REQUEST', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)

def send_tender_rejected_trigger_email(tender_id):
    """ 
        Tender Rejected Trigger Request Email
    """
    tender_details = (
        TenderMasterNew.cmobjects
        .select_related('rejected_by')
        .filter(id=tender_id)
        .annotate(
            rejected_by_user_full_name=Concat(
                'rejected_by__first_name',
                Value(' '),
                'rejected_by__last_name',
                output_field=CharField()
            )
        )
        .values(
            'id',
            'tender_id',
            'name',
            'rejected_by_user_full_name',
            'rejected_by_date',
            'rejected_remarks',
        )
    ).first()
    if not tender_details:
        return
    context = tender_details
    context['current_datetime'] = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    subject = f"Tender - {tender_details['tender_id']} Rejected"
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-rejected-to'],
        user__company__tender_master_new_company_deatils__tender_id=tender_id,
        level_permission=True,
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-rejected-cc'],
        user__company__tender_master_new_company_deatils__tender_id=tender_id,
        level_permission=True,
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-REJECTED', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)

def send_tender_site_survey_submission_email(survey_id, user):
    """Tender Site Survey Final Submission Email Triggered"""
    survey_data = TenderMasterNewSurveyMaster.cmobjects.select_related('tender').filter(pk=survey_id).values(
        'id', 'tender__tender_id', 'tender_id').first()
    if not survey_data:
        return
    context = survey_data
    context['current_datetime'] = datetime.now().strftime("%d-%m-%Y")
    context['user'] = f"{user.first_name} {user.last_name}"
    context['ref_url'] = f"{str(os.getenv('FE_TENDER_SURVEY_URL', '#'))}{survey_data['tender_id']}"
    subject = f"Tender Site Survey Checklist Update – Approval Required_({survey_data['tender__tender_id']})"
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-survey-approver'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(        
        module_item__unique_id__in=['tender-survey-submit-cc'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-SURVEY-FINAL-SUBMIT', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)

def send_tender_site_survey_checklist_assigned_email(users, data):
    """Tender Site Survey users assigned Email Triggered """
    if not users:
        return
    user_details = PmsUser.objects.filter(id__in=users).values('first_name', 'last_name', 'email').first()
    context={
        'tender_id' : data["tender_details"][0]["tender_id"],
        'users' : user_details,
        'current_datetime' : datetime.now().strftime("%d-%m-%Y"),
        'ref_url' : f"{str(os.getenv('FE_TENDER_SURVEY_URL', '#'))}{data["tender_details"][0]["id"]}",
    }
    subject = f"Tender Site Survey Checklist Update – Approval Required_({data["tender_details"][0]["tender_id"]})"
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-survey-assigned-users-cc'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    print("users", users)
    trigger_notifications(action='TENDER-SITE-SURVEY-CHECKLIST-ASSIGNED', subject=subject, user_list=users, cc_user_list=cc_users_list, context=context)

def trigger_emd_update_email(id, tender_id):
    """ EMD Deposition tab have been filled and the Next button is clicked"""
    context={
        'tender_id' : tender_id,
        'current_datetime' : datetime.now().strftime("%d-%m-%Y"),
        'ref_url' : f"{str(os.getenv('FE_TENDER_EMD_SUBMIT_URL', '#'))}{id}",
    }
    subject = f"EMD Deposition - Verification Pending-Action Required_({tender_id})"
    to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-emd-deposition-form-submit-to'],
        level_permission=True,
    ).values_list('user_id',flat=True))
    cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['tender-emd-deposition-form-submit-cc'],
        level_permission=True,
        user__company__tender_master_new_company_deatils__tender_id=tender_id,
    ).values_list('user_id',flat=True))
    trigger_notifications(action='TENDER-EMD-DEPOSITION-FORM-SUBMIT', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context)
