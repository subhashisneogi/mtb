import numpy as np
import pandas as pd
from colorama import Back, Style
from django.db.models import Q, F , Count , OuterRef , Exists
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException
from datetime import date

from procurement.helper import custom_filters, generate_all_mat_code ,sync_uoms_from_belsio ,handle_belsio_uom,handle_belsio_category ,sync_category_from_belsio , handle_belsio_item_master,sync_item_master_from_belsio ,fetch_all_account_master_items
from .models import *
from .serializers import *
# Create your views here.



class UnitOfMesurementAPI(APIView):
    """
    Unit Of Mesurement API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all Unit Of Mesurement
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')

        if id:
            uom_details = UnitOfMesurement.cmobjects.filter(id = id).first()
            serializer = UnitOfMesurementSerializer(uom_details)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])

        uom_list = UnitOfMesurement.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = UnitOfMesurementSerializer(uom_list, many=True)
            return Response({
                'results': serializer.data,
            })
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(uom_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = UnitOfMesurementSerializer(page, many=True)
        
        
        


        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request, format=None):
        try:
            with transaction.atomic():
                organization_id = self.request.data.get('organization_id', None)
                formal_name = self.request.data.get('formal_name', None)
                symbol = self.request.data.get('symbol', None)
                decimal_places = self.request.data.get('decimal_places', None)
                formula_for_qty_calculation = self.request.data.get('formula_for_qty_calculation', None)
                #second_uoms = self.request.data.get('second_uoms', None)

                if UnitOfMesurement.cmobjects.filter(symbol=symbol.strip(),
                                    organization_id=organization_id).exists():
                    raise APIException({'request_status': 0, 'msg': "Unit Of Measurement With Same Symbol Already Added"})

                uom_create = UnitOfMesurement.objects.create(organization_id=organization_id, \
                                                             formal_name=formal_name, symbol=symbol,
                                                             decimal_places=decimal_places,
                                                             formula_for_qty_calculation=formula_for_qty_calculation)
                handle_belsio_uom(instance=uom_create,created=True)
                uom_create.save()

                # for item in second_uoms:
                #     conversion_rate = item.get('conversion_rate', None)
                #     second_uom = item.get('second_uom', None)
                    
                #     created = SecondUnitOfMesurement.objects.create(uom=uom_create, conversion_rate=conversion_rate, \
                #                                                     second_uom=second_uom)
                    
                #     created.save()

            serializer = UnitOfMesurementSerializer(uom_create)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Added Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

    def put(self, request, *args, **kwargs):
        # try:
            method = self.request.query_params.get('method', None)
            uom_id = self.request.query_params.get('uom_id', None)

            if method.lower() == 'edit':
                with transaction.atomic():
                    organization_id = self.request.data.get('organization_id', None)
                    formal_name = self.request.data.get('formal_name', None)
                    symbol = self.request.data.get('symbol', None)
                    decimal_places = self.request.data.get('decimal_places', None)
                    formula_for_qty_calculation = self.request.data.get('formula_for_qty_calculation', None)
                    #second_uoms = self.request.data.get('second_uoms', None)

                    uom_details = UnitOfMesurement.cmobjects.filter(id=uom_id).first()

                    if UnitOfMesurement.cmobjects.filter(symbol=symbol.strip(),
                                    organization_id=organization_id).exclude(id=uom_id).exists():
                        raise APIException({'request_status': 0, 'msg': "Unit Of Mesurement With Same Symbol Already Added"})

                    uom_create = UnitOfMesurement.objects.update_or_create(organization_id=organization_id, id=uom_id, \
                                                                    defaults = {"formal_name" : formal_name, "symbol": symbol,
                                                                    'decimal_places': decimal_places,
                                                                    'formula_for_qty_calculation': formula_for_qty_calculation})
                    
                    uom_details = UnitOfMesurement.cmobjects.filter(id=uom_id).first()
                    handle_belsio_uom(instance=uom_details,created=False)
                    # if SecondUnitOfMesurement.cmobjects.filter(uom_id=uom_id).exists():
                    #     SecondUnitOfMesurement.cmobjects.filter(uom_id=uom_id).delete()

                    # for item in second_uoms:
                    #     conversion_rate = item.get('conversion_rate', None)
                    #     second_uom = item.get('second_uom', None)
                    
                    #     created = SecondUnitOfMesurement.objects.create(uom=uom_details, conversion_rate=conversion_rate, \
                    #                                                 second_uom=second_uom)
                    
                    #     created.save()

                    

            elif method.lower() == 'delete':
                uom_details = UnitOfMesurement.cmobjects.filter(id=uom_id).first()
                uom_details.is_deleted = True
                uom_details.save()

            

            serializer = UnitOfMesurementSerializer(uom_details)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Updated Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        # except Exception as e:
        #     raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        


class MaterialTypeAPI(APIView):
    """
    Material Type API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all Material Type
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            m_type_details = MaterialType.cmobjects.filter(id=id).first()
            serializer = MaterialTypeSerializer(m_type_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        m_type_list = MaterialType.cmobjects.filter(*search).distinct().order_by('name', '-id')
        if all == 'true':
            serializer = MaterialTypeSerializer(m_type_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(m_type_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        serializer = MaterialTypeSerializer(page, many=True)
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request, format=None):
        try:
            with transaction.atomic():
                organization_id = self.request.data.get('organization', None)
                name = self.request.data.get('name', None)
                code = self.request.data.get('code', None)
                # m_sub_types = self.request.data.get('m_sub_types', None)
                '''
                if MaterialType.cmobjects.filter(name=name.strip(),
                                    organization_id=organization_id).exists():
                    raise APIException({'request_status': 0, 'msg': "Material Group With Same Name Already Added"})
                '''
                '''
                if MaterialType.cmobjects.filter(code=code.strip(),
                                    organization_id=organization_id).exists():
                    raise APIException({'request_status': 0, 'msg': "Material Group With Same Code Already Added"})
                '''
                print("Data =--=-=== ", self.request.data)
                serializer = MaterialTypeSerializer(data=self.request.data)
                if serializer.is_valid():
                    instance=serializer.save()
                    handle_belsio_category(instance=instance, created=True)

                else:
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                # m_type_create = MaterialType.objects.create(organization_id=organization_id, name=name, code=code, **data)
                # m_type_create.save()

                # for item in m_sub_types:
                #     m_sub_name = item.get('name', None)
                #     m_sub_code = item.get('code', None)

                #     if MaterialSubType.cmobjects.filter(code=m_sub_code.strip(),).exists():
                #         raise APIException({'request_status': 0, 'msg': "Material Sub Group With Same Code Already Added"})

                #     created = MaterialSubType.objects.create(material_type=m_type_create, name=m_sub_name, code=m_sub_code)

                #     created.save()

            # serializer = MaterialTypeSerializer(m_type_create)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Added Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

    def put(self, request, *args, **kwargs):
        try:
            method = self.request.query_params.get('method', None)
            m_type_id = self.request.query_params.get('id', None)
            organization_id = self.request.query_params.get(
                'organization_id', None)
            if method.lower() == 'edit':
                with transaction.atomic():
                    if MaterialType.cmobjects.filter(pk=m_type_id, organization_id=organization_id).exists():
                        inventory_details = MaterialType.cmobjects.filter(pk=m_type_id).first()
                        serializer = MaterialTypeSerializer(inventory_details, data=request.data,
                                                            context={'request': request})
                        request.data['updated_by_id'] = request.user.id
                        name = request.data.get('name', None)
                        code = request.data.get('code', None)
                        name_exists = MaterialType.cmobjects.filter(~Q(pk=m_type_id), name=name,
                                                                    organization_id=organization_id).exists()
                        code_exists = MaterialType.cmobjects.filter(~Q(pk=m_type_id), code=code,
                                                                    organization_id=organization_id).exists()
                        # if name_exists:
                        #     raise APIException(
                        #         {'request_status': 0, 'msg': "Material Group With Same Name Already Added"})

                        # if code_exists:
                        #     raise APIException(
                        #         {'request_status': 0, 'msg': "Material Group With Same Code Already Added"})
                        if serializer.is_valid():
                            instance=serializer.save()
                            handle_belsio_category(instance=instance, created=False)
                        else:
                            raise APIException({'request_status': 0, 'msg': serializer.errors})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    else:
                        raise APIException({'request_status': 0, 'msg': "Invalid material type ID"})

                    m_type_details = MaterialType.cmobjects.filter(id=m_type_id).first()

            elif method.lower() == 'delete':
                m_type_details = MaterialType.cmobjects.filter(id=m_type_id).first()
                m_type_details.is_deleted = True
                m_type_details.save()

            

            serializer = MaterialTypeSerializer(m_type_details)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Updated Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class MaterialSubTypeAPI(APIView):
    """
        Material Sub Type API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all Material Type
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            m_sub_type_details = MaterialSubType.cmobjects.filter(id=id).first()
            serializer = MaterialSubTypeSerializer(m_sub_type_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        m_sub_type_list = MaterialSubType.cmobjects.filter(*search).order_by('name', '-id')
        if all == 'true':
            m_sub_type_details = MaterialSubType.cmobjects.order_by('-id')
            serializer = MaterialSubTypeSerializer(m_sub_type_details, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(m_sub_type_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = MaterialSubTypeSerializer(page, many=True)

        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new MaterialSubTyp
        """
        request.data['created_by_id'] = request.user.id
        serializer = MaterialSubTypeSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': f'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})


    def put(self, request, *args, **kwargs):
        """
        Edit MaterialSubTyp
        """
        id = self.request.query_params.get('id', None)
        instance = MaterialSubType.cmobjects.filter(pk=id).first()
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)

        if method.lower() == 'edit':
            if instance:
                serializer = MaterialSubTypeSerializer(instance, data=request.data)
                name = request.data.get('name', None)
                code = request.data.get('code', None)
                name_exists = MaterialSubType.cmobjects.filter(~Q(pk=id), name=name,
                                                            organization_id=organization_id).exists()
                code_exists = MaterialSubType.cmobjects.filter(~Q(pk=id), code=code,
                                                            organization_id=organization_id).exists()
                # if name_exists:
                #     raise APIException(
                #         {'request_status': 0, 'msg': "Material Group With Same Name Already Added"})

                # if code_exists:
                #     raise APIException(
                #         {'request_status': 0, 'msg': "Material Group With Same Code Already Added"})
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        print(f"ERROR {e}")
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
                else:
                    raise APIException({'request_status': 0, 'msg': serializer.errors})

                return Response(
                    {'results': {
                        'Data': serializer.data,
                    },
                        'msg': f'Successfully updated.',
                        'status': status.HTTP_202_ACCEPTED,
                        "request_status": 1})

        if method.lower() == 'delete':
            if instance:
                instance.is_deleted = True
                instance.save()

            return Response(
                {'results': {
                    'Data': id,
                },
                'msg': f'Successfully updated.',
                'status': status.HTTP_202_ACCEPTED,
                "request_status": 1})


class MaterialCostHeadAPI(APIView):
    """
    Material Type API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all Material Cost Head
        """
        id = self.request.query_params.get('id', None)
        if id:
            m_cost_details = MaterialCostHead.cmobjects.filter(id = id).first()
            serializer = MaterialCostHeadSerializer(m_cost_details)
            return Response(serializer.data)

        organization_id = self.request.query_params.get('organization_id', None)

        m_type_list = MaterialCostHead.cmobjects.filter(organization_id = organization_id).order_by('id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(m_type_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        serializer = MaterialCostHeadSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        try:
            with transaction.atomic():
                organization_id = self.request.data.get('organization_id', None)
                name = self.request.data.get('name', None)
                m_sub_cost_heads = self.request.data.get('m_sub_cost_heads', None)

                if MaterialCostHead.cmobjects.filter(name=name.strip(),
                                    organization_id=organization_id).exists():
                    raise APIException({'request_status': 0, 'msg': "Material Cost Head With Same Name Already Added"})

                m_type_create = MaterialCostHead.objects.create(organization_id=organization_id, \
                                                             name=name)
                m_type_create.save()

                for item in m_sub_cost_heads:
                    m_sub_name = item.get('name', None)

                    created = MaterialSubCostHead.objects.create(material_cost_head=m_type_create, name=m_sub_name)

                    created.save()

            serializer = MaterialCostHeadSerializer(m_type_create)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Added Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


    def put(self, request, *args, **kwargs):
        try:
            method = self.request.query_params.get('method', None)
            m_cost_id = self.request.query_params.get('m_sub_cost_head_id', None)

            if method.lower() == 'edit':
                with transaction.atomic():
                    organization_id = self.request.data.get('organization_id', None)
                    name = self.request.data.get('name', None)
                    m_sub_cost_heads = self.request.data.get('m_sub_cost_heads', None)

                    if MaterialCostHead.cmobjects.filter(name=name.strip(),
                                    organization_id=organization_id).exclude(id=m_cost_id).exists():
                        raise APIException({'request_status': 0, 'msg': "Material Cost Head With Same Name Already Added"})

                    m_type_create = MaterialCostHead.objects.update_or_create(organization_id=organization_id, id=m_cost_id, \
                                                                    defaults = {"name" : name})
                    
                    if MaterialSubCostHead.cmobjects.filter(material_cost_head_id=m_cost_id).exists():
                        MaterialSubCostHead.cmobjects.filter(material_cost_head_id=m_cost_id).delete()

                    for item in m_sub_cost_heads:
                        m_sub_name = item.get('name', None)
                    
                        created = MaterialSubCostHead.objects.create(material_cost_head_id=m_cost_id, name=m_sub_name)
                    
                        created.save()

                    m_type_details = MaterialCostHead.cmobjects.filter(id=m_cost_id).first()

            elif method.lower() == 'delete':
                m_type_details = MaterialCostHead.cmobjects.filter(id=m_cost_id).first()
                m_type_details.is_deleted = True
                m_type_details.save()

            

            serializer = MaterialCostHeadSerializer(m_type_details)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Updated Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        



class MaterialNatureAPIView(APIView):
    """
    CRUD API for MaterialNature model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all MaterialNature
        """
        id = self.request.query_params.get('id', None)
        if id:
            material_nature_details = MaterialNature.cmobjects.filter(id=id).first()
            serializer = MaterialNatureSerializer(material_nature_details)
            return Response(serializer.data)

        organization_id = self.request.query_params.get(
            'organization_id', None)
        material_nature_list = MaterialNature.cmobjects.filter(
            organization_id=organization_id).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(material_nature_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MaterialNatureSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Material Nature
        """
        serializer = MaterialNatureSerializer(data=request.data)
        if MaterialNature.cmobjects.filter(name=request.data['name'].strip(),
                                     organization=request.data['organization']).exists():
            raise APIException({'request_status': 0, 'msg': "Material Nature already exist"})

        if serializer.is_valid():
            serializer.save()

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        

        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Material Nature
                """
                if MaterialNature.cmobjects.filter(pk=id,
                                             organization_id=organization_id).exists():

                    material_nature_details = MaterialNature.cmobjects.filter(pk=id).first()

                    if MaterialNature.cmobjects.filter(name=request.data['name'].strip(),
                                                 organization_id=organization_id).exclude(
                                                        id=id).exists():
                        raise APIException({'request_status': 0, 'msg': "Material Nature already exist"})

                    serializer = MaterialNatureSerializer(material_nature_details, data=request.data)

                    if serializer.is_valid():
                        serializer.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response(
                        {'results': {
                            'Data': serializer.errors,
                        },
                            'msg': "Something went wrong. If the problem persists, please contact support.",
                            'status': status.HTTP_400_BAD_REQUEST,
                            "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a Material Nature
                """
                if MaterialNature.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    material_nature_details = MaterialNature.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    material_nature_details.is_deleted = True
                    material_nature_details.save()

                    return Response({'results': {
                        'material_nature': MaterialNature.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Material Nature',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
                

class VendorMaterialMasterAPIView(APIView):
    """
    CRUD API for VendorMaterialMaster model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all VendorMaterialMaster
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        is_warehouse_material = self.request.query_params.get('is_warehouse_material', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            material_master_details = VendorMaterialMaster.cmobjects.filter(id=id).first()
           
            serializer = VendorMaterialMasterSerializer(material_master_details)
            return Response(serializer.data)
        
        search = {}
        if not is_warehouse_material:
            search['is_warehouse_material'] = False
        search = custom_filters(self.request, search, [])

        material_master_list = VendorMaterialMaster.cmobjects.select_related(
            'organization', 'material_type', 'material_sub_type', 'material_cost_head',
            'material_sub_cost_head', 'unit_of_mesurement', 'hsn_code', 'gst_tax','material_type__parent'
        ).prefetch_related('material_type__parent','vendor_materials'
        ).filter(*search).order_by(*str(order_by).split(","))
       
        if all == 'true':

            serializer = VendorMaterialMasterSerializer(material_master_list, many=True)

            """ all_materials_of_material_type """
            material_type = self.request.query_params.get('material_type', None)
            all_materials_of_material_type = []
            lst_child = lst_materials = []
            if material_type:
                def recursive_func(_material_type: MaterialType, _material_list: list(), depth: int):
                    """
                    recursive function ✨
                    """
                    objs = VendorMaterialMaster.cmobjects.filter(
                        material_type_id=_material_type.id,
                    ).select_related('unit_of_mesurement').only(
                        'id',
                        'material_code',
                        'material_name',
                        'material_nature',
                        'unit_of_mesurement'
                    )
                    for item in objs:
                        _material_list.extend(
                            [{
                                'id': item.pk,
                                'material_code': item.material_code,
                                'material_name': item.material_name,
                                'material_nature_name': item.material_nature,
                                'unit_of_mesurement': item.unit_of_mesurement.id if item.unit_of_mesurement else None
                            }]
                        )
                    if _material_type.parent and depth > 0:
                        _material_list = recursive_func(_material_type.parent, _material_list, depth-1)

                    return _material_list
                #### end of recursive_func ✨

                ## recursive func 2
                def recursive_func_find_child_grp(_pk: int, _lst: list, depth: int):
                    """
                    recursive function to find all child of MaterialType ✨
                    """
                    child = MaterialType.cmobjects.filter(parent__id=_pk).only('id').values_list('id', flat=True)
                    if child and depth > 0:
                        _lst.extend(child)
                        _lst = list(set(_lst))
                        for i in _lst:
                            _lst = recursive_func_find_child_grp(i, _lst, depth - 1)
                    return _lst

                # material_type_obj = MaterialType.cmobjects.filter(pk=material_type).first()
                material_type_obj = None
                if material_type_obj:
                    all_materials_of_material_type = recursive_func(material_type_obj, all_materials_of_material_type, depth=20)  # ✨

                    lst_child = recursive_func_find_child_grp(material_type_obj.pk, lst_child, depth=20)  # ✨
                    lst_materials = (VendorMaterialMaster.cmobjects.select_related('unit_of_mesurement').
                                     filter(material_type__id__in=lst_child).
                                     annotate(
                                        material_nature_name=F('material_nature'),
                                     ).
                                     only('id',
                                          'material_code',
                                          'material_name',
                                          'unit_of_mesurement',
                                          'material_nature').
                                     values('id',
                                          'material_code',
                                          'material_name',
                                          'unit_of_mesurement',
                                          'material_nature_name'
                                    ))

                    for item in lst_materials:
                        all_materials_of_material_type.append(item)

            custom_data = {'all_materials_of_material_type': all_materials_of_material_type}
            return Response({'results': serializer.data, 'custom_data': custom_data})
            

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(material_master_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = VendorMaterialMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Material
        """
        import ast

        serializer = VendorMaterialMasterSerializer(data=request.data)
        second_uoms = self.request.data.get('second_uoms', None)

        second_list = []
        if second_uoms:
            second_list = ast.literal_eval(second_uoms) if second_uoms else []

        # if VendorMaterialMaster.cmobjects.filter(material_code=request.data['material_code'].strip(),
        #                              organization=request.data['organization']).exists():
        #     raise APIException({'request_status': 0, 'msg': "Material with the same material code already exist"})

        if 'sap_code' in request.data:
            if request.data['sap_code'] and request.data['sap_code'].strip() != '' and VendorMaterialMaster.cmobjects.filter(sap_code=request.data['sap_code'].strip(), organization_id=request.data['organization']).exists():
                raise APIException({'request_status': 0, 'msg': "Material with the same sap code already exist"})

        with transaction.atomic():
            if serializer.is_valid():
                instance=serializer.save()
                handle_belsio_item_master(instance=instance,created=True)

                for item in second_list:
                    conversion_rate = item.get('conversion_rate', None)
                    second_uom = item.get('second_uom', None)
                    primary_rate = item.get('primary_rate', None)
                    # TODO Debug required: "ValueError: Field 'primary_rate' expected a number but got ''."
                    # TODO: FRONT END FIX
                    created = SecondUnitOfMesurement.objects.create(material_id=serializer.data.get('id', None), \
                                                                    conversion_rate=conversion_rate, \
                                                                    second_uom=second_uom, primary_rate=primary_rate)

                    created.save()

                return Response(
                    {'results': {
                        'Data': serializer.data,
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})

        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        import ast
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Material
                """
                second_uoms = self.request.data.get('second_uoms', None)

                second_list = ast.literal_eval(second_uoms) if second_uoms else []

                if VendorMaterialMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():

                    material_details = VendorMaterialMaster.cmobjects.filter(pk=id).first()

                    # if VendorMaterialMaster.cmobjects.filter(material_code=request.data['material_code'].strip(),
                    #                              organization_id=organization_id).exclude(
                    #                                     id=id).exists():
                    #     raise APIException({'request_status': 0, 'msg': "Material with the same material code already exist"})

                    # if 'sap_code' in request.data:
                    #     if request.data['sap_code'] and request.data['sap_code'].strip() != '' and VendorMaterialMaster.cmobjects.filter(sap_code=request.data['sap_code'].strip(), organization_id=organization_id).exclude(id=id).exists():
                    #         raise APIException({'request_status': 0, 'msg': "Material with the same sap code already exist"})

                    serializer = VendorMaterialMasterSerializer(material_details, data=request.data)

                    if serializer.is_valid():
                        instance=serializer.save()
                        handle_belsio_item_master(instance=instance,created=False)
                        if SecondUnitOfMesurement.cmobjects.filter(material=material_details).exists():
                            SecondUnitOfMesurement.cmobjects.filter(material=material_details).delete()

                        for item in second_list:
                            conversion_rate = item.get('conversion_rate', None)
                            second_uom = item.get('second_uom', None)
                            primary_rate = item.get('primary_rate', None)
                            
                            created = SecondUnitOfMesurement.objects.create(material=material_details, \
                                                                            conversion_rate=conversion_rate, \
                                                                            second_uom=second_uom, primary_rate=primary_rate)
                            
                            created.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors })
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a Material Nature
                """
                if VendorMaterialMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    material_details = VendorMaterialMaster.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    material_details.is_deleted = True
                    material_details.save()

                    return Response({'results': {
                        'material': VendorMaterialMaster.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Material',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})


class BulkVendorMaterialMasterAPIView(APIView):
    """
    CRUD API for VendorMaterialMaster Bulk add/update
    """
    
    

    def post(self, request, format=None):
        """
        Create a new Materials
        """
        import ast
        materials = request.data.get('materials', [])
        if not materials:
            raise APIException({'request_status': 0, 'msg': "'materials' parameter is required"})
        err_dict = {}
        success_data = []
        for material in materials:
            material_name = material.get('material_name', '')
            serializer = VendorMaterialMasterSerializer(data=material)
            second_uoms = material.get('second_uoms', None)

            second_list = []
            if second_uoms:
                second_list = ast.literal_eval(second_uoms) if second_uoms else []

            '''
            if VendorMaterialMaster.cmobjects.filter(material_code=material['material_code'].strip(),
                                         organization=material['organization']).exists():
                err_dict[material_name] = "Material with the same material code already exists"
            '''

            with transaction.atomic():
                if serializer.is_valid():
                    serializer.save()

                    for item in second_list:
                        conversion_rate = item.get('conversion_rate', None)
                        second_uom = item.get('second_uom', None)
                        primary_rate = item.get('primary_rate', None)
                        # TODO Debug required: "ValueError: Field 'primary_rate' expected a number but got ''."
                        # TODO: FRONT END FIX
                        created = SecondUnitOfMesurement.objects.create(material_id=serializer.data.get('id', None), \
                                                                        conversion_rate=conversion_rate, \
                                                                        second_uom=second_uom, primary_rate=primary_rate)

                        created.save()
                    success_data.append(serializer.data)
                else:
                    err_dict[material_name] = serializer.errors
        if success_data:
            return Response(
                {'results': {
                    'Data': success_data,
                    'Errors': err_dict
                },
                    'msg': 'Successfully created materials',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        else:
            return Response(
                {'results': {
                    'Errors': err_dict,
                },
                    'msg': 'Failed to create Materials',
                    'status': status.HTTP_500_INTERNAL_SERVER_ERROR,
                    "request_status": 1})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        import ast

        materials = request.data.get('materials', [])
        if not materials:
            raise APIException({'request_status': 0, 'msg': "'materials' parameter is required"})
        err_dict = {}
        success_data = []
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        for material in materials:
            id = material.get('id', None)
            material_name = material.get('material_name', '')
            print("id ====== ", id)
            print("material_name ====== ", material_name)
            with transaction.atomic():
                if method.lower() == 'edit':
                    """
                    Update a Material
                    """
                    second_uoms = material.get('second_uoms', None)

                    second_list = ast.literal_eval(second_uoms) if second_uoms else []

                    if VendorMaterialMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():

                        material_details = VendorMaterialMaster.cmobjects.filter(pk=id).first()

                        '''
                        if VendorMaterialMaster.cmobjects.filter(material_code=material['material_code'].strip(),
                                                                 organization_id=organization_id).exclude(
                            id=id).exists():
                            err_dict[material_name] = "Material with the same material code already exist"
                        '''

                        serializer = VendorMaterialMasterSerializer(material_details, data=material)

                        if serializer.is_valid():
                            serializer.save()

                            if SecondUnitOfMesurement.cmobjects.filter(material=material_details).exists():
                                SecondUnitOfMesurement.cmobjects.filter(material=material_details).delete()

                            for item in second_list:
                                conversion_rate = item.get('conversion_rate', None)
                                second_uom = item.get('second_uom', None)
                                primary_rate = item.get('primary_rate', None)

                                created = SecondUnitOfMesurement.objects.create(material=material_details, \
                                                                                conversion_rate=conversion_rate, \
                                                                                second_uom=second_uom,
                                                                                primary_rate=primary_rate)

                                created.save()
                            success_data.append(serializer.data)
                        else:
                            err_dict[material_name] = serializer.errors
                    else:
                        err_dict[material_name] = "Something went wrong. If the problem persists, please contact support."
                elif method.lower() == 'delete':
                    """
                    Delete a Material Nature
                    """
                    if VendorMaterialMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                        material_details = VendorMaterialMaster.cmobjects.get(
                            pk=id, organization_id=organization_id)
                        material_details.is_deleted = True
                        material_details.save()

                        success_data.append(VendorMaterialMaster.objects.filter(pk=id,
                                                                                organization_id=organization_id).values())
                    else:
                        err_dict[material_name] = "Something went wrong. If the problem persists, please contact support."
        if success_data:
            return Response(
                {'results': {
                    'Data': success_data,
                    'Errors': err_dict
                },
                    'msg': 'Successfully Updated materials',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        else:
            return Response(
                {'results': {
                    'Errors': err_dict,
                },
                    'msg': 'Failed to update Materials',
                    'status': status.HTTP_500_INTERNAL_SERVER_ERROR,
                    "request_status": 1})



class VendorMaterialMasterImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                organization_id = self.request.query_params.get('organization_id', None)
                is_warehouse_material = self.request.query_params.get('is_warehouse_material', None)
                is_warehouse_material = True if is_warehouse_material == 'true' else False
                if not organization_id or organization_id == "null":
                    return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan

                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                count = sheet_xlsx.shape[0]

                vendormaterialmaster = list()
                vendormaterialmaster_to_be_update = list()
                for i, item in enumerate(sheet_xlsx.to_dict('records')):
                    def get_value(key):
                        return item.get(field_map.get(key), None)

                    print('i-> ', i)
                    material_name = get_value('material_name')  # unique=True
                    material_descriptions = get_value('material_descriptions')
                    material_lead_time = get_value('material_lead_time')
                    material_valuation = get_value('material_valuation')
                    material_tolerance = get_value('material_tolerance')
                    sap_code = get_value('sap_code')
                    part_no = get_value('part_no')
                    hsncode = get_value('hsncode')
                    remarks = get_value('remarks')
                    materialtype = get_value('materialtype')
                    material_nature = get_value('material_nature')


                    material_type = get_value('material_type')
                    unit_of_mesurement = get_value('unit_of_mesurement')
                    material_sub_type = get_value('material_sub_type')
                    gst_tax = get_value('gst_tax')
                    material_cost_head = get_value('material_cost_head')
                    material_sub_cost_head = get_value('material_sub_cost_head')

                    second_unit_of_mesurement_1 = get_value('second_unit_of_mesurement_1')
                    second_unit_of_mesurement_2 = get_value('second_unit_of_mesurement_2')


                    # material_type
                    _qs = MaterialType.cmobjects.filter(
                        Q(code=str(material_type).strip()) |
                        Q(name__iexact=str(material_type).strip()))
                    _material_type = _qs.first()
                    print('_material_type', _material_type)
                    if not _material_type:
                        raise APIException(
                            {'request_status': 0, 'msg': f"`{material_type}` is not a valid name!"})

                    # material_sub_type (not in use)
                    _qs = MaterialType.cmobjects.filter(
                        Q(code=str(material_sub_type).strip()) |
                        Q(name__iexact=str(material_sub_type).strip()))
                    material_sub_type = _qs.first()


                    # unit_of_mesurement
                    print('unit_of_mesurement', unit_of_mesurement)
                    _qs = UnitOfMesurement.cmobjects.filter(
                        symbol__iexact=str(unit_of_mesurement).strip()
                    )
                    _unit_of_mesurement = _qs.first()

                    print('_unit_of_mesurement', _unit_of_mesurement)
                    if not _unit_of_mesurement:
                        raise APIException({'request_status': 0, 'msg': f"`{unit_of_mesurement}` is not a valid Unit of Measurement!"})

                    # gst_tax
                    _qs = TaxHead.cmobjects.filter(
                        Q(name__iexact=str(gst_tax).strip()) or
                        Q(short_name__iexact=str(gst_tax).strip())
                    )
                    _gst_tax = _qs.first()

                    # material_cost_head
                    _qs = MaterialCostHead.cmobjects.filter(
                        name__iexact=str(material_cost_head).strip()
                    )
                    _material_cost_head = _qs.first()

                    # material_sub_cost_head
                    _qs = MaterialSubCostHead.cmobjects.filter(
                        name__iexact=str(material_sub_cost_head).strip()
                    )
                    _material_sub_cost_head = _qs.first()

                    if not VendorMaterialMaster.cmobjects.filter(material_name=material_name).exists():
                        """ CREATE """
                        # material_code = generate_material_code(_material_type)

                        vendormaterialmaster.append(
                            VendorMaterialMaster(
                                organization_id=organization_id,
                                is_warehouse_material=is_warehouse_material,
                                # material_code=material_code,
                                material_name=material_name,
                                material_descriptions=material_descriptions,
                                material_lead_time=material_lead_time,
                                material_valuation=material_valuation,
                                material_tolerance=material_tolerance,
                                sap_code=sap_code,
                                part_no=part_no,
                                hsncode=hsncode,
                                remarks=str(remarks or '')+f" ~",
                                materialtype=materialtype,
                                material_nature=material_nature,

                                material_type=_material_type,
                                unit_of_mesurement=_unit_of_mesurement,
                                gst_tax=_gst_tax,
                                material_cost_head=_material_cost_head,
                                material_sub_cost_head=_material_sub_cost_head
                            )
                        )
                    else:
                        print('UPDATE')
                        # material_code = generate_material_code(_material_type)

                        # vendormaterialmaster_to be_update
                        obj = VendorMaterialMaster.cmobjects.filter(material_name=material_name).first()
                        obj.organization_id = organization_id
                        obj.is_warehouse_material = is_warehouse_material
                        # obj.material_code = material_code
                        obj.material_descriptions = material_descriptions
                        obj.material_lead_time = material_lead_time
                        obj.material_valuation = material_valuation
                        obj.material_tolerance = material_tolerance
                        obj.sap_code = sap_code
                        obj.part_no = part_no
                        obj.hsncode = hsncode
                        obj.remarks = remarks
                        obj.materialtype = materialtype
                        obj.material_nature = material_nature
                        obj.part_no = part_no

                        obj.material_type = _material_type
                        obj.unit_of_mesurement = _unit_of_mesurement
                        obj.gst_tax = _gst_tax
                        obj.material_cost_head = _material_cost_head
                        obj.material_sub_cost_head = _material_sub_cost_head

                        vendormaterialmaster_to_be_update.append(obj)
                    print('--------')
                print('----x-----')

                created_data = []
                with transaction.atomic():
                    try:
                        # Bulk create
                        vendormaterialmasters = VendorMaterialMaster.cmobjects.bulk_create(vendormaterialmaster, batch_size=1000, ignore_conflicts=False)
                        created_data = VendorMaterialMasterSerializer2(vendormaterialmasters, many=True).data

                        # Bulk update
                        _fields = [i for i in field_map.keys() if i not in ('material_name',)]
                        VendorMaterialMaster.cmobjects.bulk_update(vendormaterialmaster_to_be_update, _fields, batch_size=1000)
                        updated_data = VendorMaterialMasterSerializer2(vendormaterialmaster_to_be_update, many=True).data

                    except Exception as e:
                        print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                        'created_data': created_data,
                        'updated_data': updated_data
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class HSNCodeAPIView(APIView):
    """
    CRUD API for HSNMaster model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all HSNMaster
        """
        id = self.request.query_params.get('id', None)
        if id:
            material_nature_details = HSNMaster.cmobjects.filter(id=id).first()
            serializer = HSNMasterSerializer(material_nature_details)
            return Response(serializer.data)
        
        material_nature_list = HSNMaster.cmobjects.order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(material_nature_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = HSNMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new HSNMaster
        """
        request.data['created_by_id'] = request.user.id
        serializer = HSNMasterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        

        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a HSNMaster
                """
                if HSNMaster.cmobjects.filter(pk=id).exists():
                    details = HSNMaster.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = HSNMasterSerializer(details, data=request.data)
                    if serializer.is_valid():
                        serializer.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    return Response(
                        {'results': {
                            'Data': serializer.errors,
                        },
                            'msg': "Something went wrong. If the problem persists, please contact support.",
                            'status': status.HTTP_400_BAD_REQUEST,
                            "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a HSNMaster
                """
                if HSNMaster.cmobjects.filter(pk=id).exists():
                    details = HSNMaster.cmobjects.get(pk=id)
                    details.updated_by_id = request.user.id
                    details.is_deleted = True
                    details.save()

                    return Response({'results': {
                        'hsn_code': HSNMaster.objects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})


class ItemTypeAPIView(APIView):
    """
    CRUD API for ItemType model
    """
    
    

    def get(self, request):
        """
        Get a list of all ItemType
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            item_type_details = ItemType.cmobjects.filter(id=id).first()
            serializer = ItemTypeSerializer(item_type_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        item_type_list = ItemType.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = ItemTypeSerializer(item_type_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(item_type_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = ItemTypeSerializer(page, many=True)

        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


class PrimaryGroupAPIView(APIView):
    """
    CRUD API for PrimaryGroup model
    """
    
    

    def get(self, request):
        """
        Get a list of all PrimaryGroup
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            primary_group_details = PrimaryGroup.cmobjects.filter(id=id).first()
            serializer = PrimaryGroupSerializer(primary_group_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        primary_group_list = PrimaryGroup.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = PrimaryGroupSerializer(primary_group_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(primary_group_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PrimaryGroupSerializer(page, many=True)

        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


class ProductionTypeAPIView(APIView):
    """
    CRUD API for ProductionType model
    """
    
    

    def get(self, request):
        """
        Get a list of all ProductionType
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            production_type_details = ProductionType.cmobjects.filter(id=id).first()
            serializer = ProductionTypeSerializer(production_type_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        production_type_list = ProductionType.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = ProductionTypeSerializer(production_type_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(production_type_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = ProductionTypeSerializer(page, many=True)

        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


class BrandAPIView(APIView):
    """
    CRUD API for Brand model
    """
    
    

    def get(self, request):
        """
        Get a list
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = Brand.cmobjects.filter(id=id).first()
            serializer = BrandSerializer(_details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = Brand.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = BrandSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BrandSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create
        """
        serializer = BrandSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print("Error-->", str(e) )
                raise APIException({"request_status": 0, "msg": e})
            return Response({
                'results': {
                    'Data': serializer.data,
                },
                'msg': f'Successfully created.',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        id = self.request.query_params.get('id', None)
        method = self.request.query_params.get('method', None)
        print("method->", method)

        if method == 'edit':
            try:
                instance = Brand.cmobjects.filter(pk=id).first()
                if instance:
                    serializer = BrandSerializer(instance, data=request.data)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            print(f"ERROR {e}")
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({
                            'results': {
                                'Data': serializer.data,
                            },
                            'msg': f'Successfully created.',
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': e })
        elif method == 'delete':
            try:
                instance = Brand.cmobjects.filter(pk=id).first()
                if instance:
                    instance.is_deleted = True
                    instance.save()
                return Response({
                    'results': {
                    'Data': instance.id,
                    },
                    'msg': f'Successfully deleted.',
                    'status': status.HTTP_202_ACCEPTED,
                    "request_status": 1})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        else:
            raise APIException({'request_status': 0, 'msg': 'wrong method' })


class ModelAPIView(APIView):
    """
    CRUD API for Model master
    """
    
    

    def get(self, request):
        """
        Get a list
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            _details = Model.cmobjects.filter(id=id).first()
            serializer = ModelSerializer(_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        _list = Model.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = ModelSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = ModelSerializer(page, many=True)
        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create
        """
        serializer = ModelSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response({
                'results': {
                'Data': serializer.data,
                },
                'msg': f'Successfully created.',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Edit
        """

        # id = request.data.get('id', None)
        id = self.request.query_params.get('id', None)
        method = self.request.query_params.get('method', None)
        print("method->", method)

        if method == 'edit':
            try:
                instance = Model.cmobjects.filter(pk=id).first()
                if instance:
                    serializer = ModelSerializer(instance, data=request.data)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            print(f"ERROR {e}")
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({
                            'results': {
                            'Data': serializer.data,
                            },
                            'msg': f'Successfully created.',
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': e })
        elif method == 'delete':
            try:
                instance = Model.cmobjects.filter(pk=id).first()
                if instance:
                    instance.is_deleted = True
                    instance.save()
                return Response({
                    'results': {
                    'Data': instance.id,
                    },
                    'msg': f'Successfully deleted.',
                    'status': status.HTTP_202_ACCEPTED,
                    "request_status": 1})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        else:
            raise APIException({'request_status': 0, 'msg': 'wrong method'})


class DeprecationGroupAPIView(APIView):
    """
        CRUD API for Deprecation Group master
    """
    
    

    def get(self, request):
        """
        Get a list
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            _details = DeprecationGroupMaster.cmobjects.filter(id=id).first()
            serializer = DeprecationGroupMasterSerializer(_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        _list = DeprecationGroupMaster.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = DeprecationGroupMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = DeprecationGroupMasterSerializer(page, many=True)
        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create
        """
        serializer = DeprecationGroupMasterSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response({
                'results': {
                'Data': serializer.data,
                },
                'msg': f'Successfully created.',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Edit
        """

        # id = request.data.get('id', None)
        id = self.request.query_params.get('id', None)
        method = self.request.query_params.get('method', None)
        print("method->", method)

        if method == 'edit':
            try:
                instance = DeprecationGroupMaster.cmobjects.filter(pk=id).first()
                if instance:
                    serializer = DeprecationGroupMasterSerializer(instance, data=request.data)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            print(f"ERROR {e}")
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({
                            'results': {
                            'Data': serializer.data,
                            },
                            'msg': f'Successfully created.',
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': e })
        elif method == 'delete':
            try:
                instance = DeprecationGroupMaster.cmobjects.filter(pk=id).first()
                if instance:
                    instance.is_deleted = True
                    instance.save()
                return Response({
                    'results': {
                    'Data': instance.id,
                    },
                    'msg': f'Successfully deleted.',
                    'status': status.HTTP_202_ACCEPTED,
                    "request_status": 1})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        else:
            raise APIException({'request_status': 0, 'msg': 'wrong method'})



class AssetMasterAPIView(APIView):
    """
        CRUD API for Asset Master
    """
    
    

    def get(self, request):
        """
        Get a list
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            _details = AssetMaster.cmobjects.filter(id=id).first()
            serializer = AssetMasterSerializer(_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        _list = (AssetMaster.
                 cmobjects.
                 select_related('item', 'vendor', 'asset_account').
                 prefetch_related('vendor__vendor_master',).
                 filter(*search).
                 order_by('-id'))
        if all == 'true':
            serializer = AssetMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AssetMasterSerializer(page, many=True)
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create
        """
        serializer = AssetMasterSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response({
                'results': {
                'Data': serializer.data,
                },
                'msg': f'Successfully created.',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Edit
        """

        # id = request.data.get('id', None)
        id = self.request.query_params.get('id', None)
        method = self.request.query_params.get('method', None)
        print("method->", method)

        if method == 'edit':
            try:
                instance = AssetMaster.cmobjects.filter(pk=id).first()
                if instance:
                    serializer = AssetMasterSerializer(instance, data=request.data)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            print(f"ERROR {e}")
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({
                            'results': {
                            'Data': serializer.data,
                            },
                            'msg': f'Successfully created.',
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': e })
        elif method == 'delete':
            try:
                instance = AssetMaster.cmobjects.filter(pk=id).first()
                if instance:
                    instance.is_deleted = True
                    instance.save()
                return Response({
                    'results': {
                    'Data': instance.id,
                    },
                    'msg': f'Successfully deleted.',
                    'status': status.HTTP_202_ACCEPTED,
                    "request_status": 1})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        else:
            raise APIException({'request_status': 0, 'msg': 'wrong method'})


class GenerateMaterialCodeAPIView2(APIView):
    '''
        While creating the Material master, Material code should auto generated with the prefix of Material Group code and Material sub Group code (like SM-PS-0001 ) here SM means Structure Material (as Material Group ) and PS means Pre stressing (as Material sub Group ) and 0001 as series
    '''

    
    

    def post(self, request):

        materialtypes = MaterialType.cmobjects.all()
        updated_material_masters = []

        for materialtype in materialtypes:
            for material_master in materialtype.material_types_master.all():
                # print('material_master.pk ---', material_master.pk)
                if not material_master.material_code:
                    print('material_master.pk ---', material_master.pk)
                    _material_type = material_master.material_type
                    if _material_type:
                        if _material_type.parent:
                            parent_material_type_name = _material_type.parent.name.replace(' ', '').upper()[:2] + '-'
                        else:
                            parent_material_type_name = ''
                        base_code = parent_material_type_name + _material_type.name.replace(' ', '').upper()[:2]
                        new_code = generate_all_mat_code(material_master, [base_code])

                        print('new_code', new_code)
                        material_master.material_code = new_code
                        updated_material_masters.append(material_master)

        VendorMaterialMaster.objects.bulk_update(updated_material_masters, ['material_code'])

        return Response({
            "message": "Material codes generated successfully.",
            "updated_count": len(updated_material_masters)
        })



class MaterialGstEntryAPIView(APIView):
    """
    CRUD API for Brand model
    """
    
    

    def get(self, request):
        """
        Get a list
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            detail = MaterialGstEntry.cmobjects.select_related('organization', 'material', 'tax').filter(id=id).first()
            serializer = MaterialGstEntrySerializer(detail)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        details = MaterialGstEntry.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = MaterialGstEntrySerializer(details, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(details, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MaterialGstEntrySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create
        """
        serializer = MaterialGstEntrySerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print("Error-->", str(e) )
                raise APIException({"request_status": 0, "msg": e})
            return Response({
                'results': {
                    'Data': serializer.data,
                },
                'msg': f'Successfully created.',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        id = self.request.query_params.get('id', None)
        method = self.request.query_params.get('method', None)
        print("method->", method)

        if method == 'edit':
            try:
                instance = MaterialGstEntry.cmobjects.filter(pk=id).first()
                if instance:
                    serializer = MaterialGstEntrySerializer(instance, data=request.data)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            print(f"ERROR {e}")
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({
                            'results': {
                                'Data': serializer.data,
                            },
                            'msg': f'Successfully created.',
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Record not found"})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': e })
        elif method == 'delete':
            try:
                instance = MaterialGstEntry.cmobjects.filter(pk=id).first()
                if instance:
                    instance.is_deleted = True
                    instance.save()
                    return Response({'results': {'Data': instance.id,},'msg': f'Successfully deleted.',
                        'status': status.HTTP_202_ACCEPTED,"request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Record not found"})
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e)})
        else:
            raise APIException({'request_status': 0, 'msg': 'wrong method' })





class BOIVendorMaterialMasterAPIView(APIView):
    """
    CRUD API for VendorMaterialMaster model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all VendorMaterialMaster
        """
        all = self.request.query_params.get('all', None)
        is_warehouse_material = self.request.query_params.get('is_warehouse_material', None)
        boi_projects_id = self.request.query_params.get('boi_projects_id', None)
        order_by = self.request.query_params.get('order_by', '-id')
        
        search = {'is_boi_material':True}
        if not is_warehouse_material:
            search['is_warehouse_material'] = False
        search = custom_filters(self.request, search, ['boi_projects_id'])

        material_master_list = VendorMaterialMaster.cmobjects.select_related(
            'organization', 'material_type', 'material_sub_type', 'material_cost_head',
            'material_sub_cost_head', 'unit_of_mesurement', 'hsn_code', 'gst_tax','material_type__parent'
        ).prefetch_related('material_type__parent','vendor_materials'
        ).order_by(*str(order_by).split(",")).values(
            'id','material_code','material_name',
            'material_descriptions','material_type_id','material_type__name',
            'unit_of_mesurement_id','unit_of_mesurement__symbol','sap_code','hsncode','materialtype'
        ).annotate(
            is_applicable=Exists(
                VendorMaterialMaster.boi_projects.through.objects.filter(
                    vendormaterialmaster_id=OuterRef('pk'),
                    projectmaster_id=boi_projects_id,
                )
            )
        ).filter(*search)
        # .annotate(
        #     boi_procurement_tracker_requested_material_count=Count('boi_procurement_tracker_requested_material')
        # )
        # if boi_projects_id:
        #     material_master_list = material_master_list.annotate(is_applicable =Exists(VendorMaterialMaster.boi_projects.through.objects.filter(
        #     vendormaterialmaster_id=OuterRef('pk'), projectmaster_id=boi_projects_id
        # )) )
        if all == 'true':
            return Response({'results': list(material_master_list)})
            

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(material_master_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            "results": list(page.object_list),
        })
    def put(self, request):
        """
        Add or Remove BOI Projects for VendorMaterialMaster
        """
        operation = request.query_params.get('operation', None)
        id = request.query_params.get('id', None)
        boi_projects_id = request.query_params.get('boi_projects_id', None)

        with transaction.atomic():
            try:
                details = VendorMaterialMaster.cmobjects.filter(pk=id).first()
                details.updated_by_id = request.user.id
                if operation.lower() == 'add':
                    details.boi_projects.add(boi_projects_id)
                elif  operation.lower() == 'remove':  
                    details.boi_projects.remove(boi_projects_id)  
                return Response({'msg': "Successfully updated", "request_status": 1})
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': e })
          
class UOMSyncBelsioAPIView(APIView):
    """
    API to manually trigger syncing of UOMs from Belsio
    """
    
    

    def get(self, request):
        try:
            sync_uoms_from_belsio()
            return Response(
                {
                 'msg': 'Successfully sync.',
                 'status': status.HTTP_200_OK,
                 "request_status": 1})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})

class CategorySyncBelsioAPIView(APIView):
    """
    API to manually trigger syncing of category from Belsio
    """
    
    

    def get(self, request):
        try:
            sync_category_from_belsio()
            return Response(
                {
                 'msg': 'Successfully sync.',
                 'status': status.HTTP_200_OK,
                 "request_status": 1})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})

class ItemMasterSyncBelsioAPIView(APIView):
    """
    API to manually trigger syncing of item master from Belsio
    """
    
    

    def get(self, request):
        try:
            sync_item_master_from_belsio()
            return Response(
                {
                 'msg': 'Successfully sync.',
                 'status': status.HTTP_200_OK,
                 "request_status": 1})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})        
                  
