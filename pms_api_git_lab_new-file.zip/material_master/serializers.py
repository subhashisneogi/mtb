import colorama
from colorama import Back, Style
from django.core.exceptions import ObjectDoesNotExist
from django.db import transaction
from rest_framework import serializers
from rest_framework.exceptions import APIException

from procurement.models import SiteMaster as Location
from .models import *
from .helper import *
from django.db.models import Subquery

from procurement.helper import get_details_from_instance

class UnitOfMesurementSerializer(serializers.ModelSerializer):
    """"
    Unit Of Mesurement Serializer
    """

    class Meta:
        model = UnitOfMesurement
        fields = '__all__'


class MaterialTypeSerializer(serializers.ModelSerializer):
    """"
    Material Type Serializer
    """
    material_sub_type = serializers.SerializerMethodField()
    material_master = serializers.SerializerMethodField()
    production_type_details = serializers.SerializerMethodField()
    item_type_details = serializers.SerializerMethodField()
    purchase_account_details = serializers.SerializerMethodField()
    sales_account_details = serializers.SerializerMethodField()
    all_materials_of_child = serializers.SerializerMethodField()

    def get_material_sub_type(self,instance):
        # key_list = MaterialSubType.cmobjects.filter(material_type_id=instance.id).values("id","name", "code")
        # resp = []
        # for data in key_list:
        #     data.update({'count': VendorMaterialMaster.cmobjects.filter(material_type_id=instance.id,material_sub_type=data['id']).count()})
        #     resp.append(data)
        # return resp
        return None

    def get_material_master(self, instance):
        key_list = VendorMaterialMaster.cmobjects.filter(material_type_id=instance.id).values()
        return key_list

    def get_item_type_details(self, instance):
        item_type_details = None
        if instance.item_type:
            try:
                item_type_details = {
                    'id': instance.item_type.id,
                    'name': instance.item_type.name
                }
            except ObjectDoesNotExist:
                pass
        return item_type_details

    def get_production_type_details(self, instance):
        production_type_details = None
        if instance.production_type:
            try:
                production_type_details = {
                    'id': instance.production_type.id,
                    'name': instance.production_type.name
                }
            except ObjectDoesNotExist:
                pass
        return production_type_details

    def get_purchase_account_details(self, instance):
        key_list = []
        if instance.purchase_account_id:
            key_list = AccountsHead.cmobjects.filter(pk=instance.purchase_account_id).values('id', 'name')
        return key_list

    def get_sales_account_details(self, instance):
        key_list = []
        if instance.sales_account_id:
            key_list = AccountsHead.cmobjects.filter(pk=instance.sales_account_id).values('id', 'name')
        return key_list

    def get_all_materials_of_child(self, instance):
        lst_child = []
        lst_materials = []
        def recursive_func(_pk, _lst, depth):
            # print('depth', depth, '_pk', _pk)
            child = MaterialType.cmobjects.filter(parent__id=_pk).values_list('id', flat=True)
            if child and depth > 0:
                _lst = _lst + list(child)
                _lst = list(set(_lst))
                for i in _lst:
                    # print('---', i)
                    _lst = recursive_func(i, _lst, depth-1)
            return _lst

        if instance:
            lst_child = recursive_func(instance.pk, lst_child, depth=20)
            lst_materials = VendorMaterialMaster.cmobjects.filter(material_type__id__in=lst_child).values('id', 'material_code', 'material_name')
        return lst_materials

    class Meta:
        model = MaterialType
        fields = '__all__'


class MaterialSubTypeSerializer(serializers.ModelSerializer):
    """"
    Material Type Serializer
    """

    material_type_details = serializers.SerializerMethodField()
    production_type_details = serializers.SerializerMethodField()
    item_type_details = serializers.SerializerMethodField()

    @transaction.atomic()
    def create(self, validated_data):
        code = validated_data.get('code')
        name = validated_data.get('name')

        if MaterialSubType.cmobjects.filter(code=code.strip(),).exists():
            raise APIException({'request_status': 0, 'msg': "Material Sub Group With Same Code Already Added"})
        if MaterialSubType.cmobjects.filter(name=name.strip(),).exists():
            raise APIException({'request_status': 0, 'msg': "Material Sub Group With Same Name Already Added"})

        material_sub_type = MaterialSubType.cmobjects.create(**validated_data)
        material_sub_type.save()
        return material_sub_type

    @transaction.atomic()
    def update(self, instance, validated_data):

        # code = validated_data.get('code')
        # name = validated_data.get('name')
        #
        # if MaterialSubType.cmobjects.filter(code=code.strip(), ).exists():
        #     raise APIException({'request_status': 0, 'msg': "Material Sub Group With Same Code Already Added"})
        # if MaterialSubType.cmobjects.filter(name=name.strip(), ).exists():
        #     raise APIException({'request_status': 0, 'msg': "Material Sub Group With Same Name Already Added"})

        instance = super().update(instance, validated_data)
        return instance

    def get_material_type_details(self, instance):
        key_list = MaterialType.cmobjects.filter(pk=instance.material_type_id).values()
        return key_list

    def get_item_type_details(self, instance):
        item_type_details = None
        if instance.item_type:
            try:
                item_type_details = {
                    'id': instance.item_type.id,
                    'name': instance.item_type.name
                }
            except ObjectDoesNotExist:
                pass
        return item_type_details

    def get_production_type_details(self, instance):
        production_type_details = None
        if instance.production_type:
            try:
                production_type_details = {
                    'id': instance.production_type.id,
                    'name': instance.production_type.name
                }
            except ObjectDoesNotExist:
                pass
        return production_type_details
    class Meta:
        model = MaterialSubType
        fields = '__all__'

class MaterialCostHeadSerializer(serializers.ModelSerializer):
    """"
    Material Cost Head Serializer
    """
    material_sub_cost_head = serializers.SerializerMethodField()

    def get_material_sub_cost_head(self,instance):
        key_list = MaterialSubCostHead.cmobjects.filter(material_cost_head_id=instance.id).values("id","name")
        return key_list
    

    class Meta:
        model = MaterialCostHead
        fields = '__all__'


class MaterialNatureSerializer(serializers.ModelSerializer):
    """"
    Material Nature Serializer
    """ 

    class Meta:
        model = MaterialNature
        fields = '__all__'


class HSNMasterSerializer(serializers.ModelSerializer):
    """"
    HSNMaster Serializer
    """ 

    class Meta:
        model = HSNMaster
        fields = '__all__'



class VendorMaterialMasterSerializer(serializers.ModelSerializer):
    """"
    Vendor Material Master Serializer
    """ 
    material_type_name = serializers.SerializerMethodField()
    # material_sub_type_name = serializers.SerializerMethodField()  # not in use
    material_cost_head_name = serializers.SerializerMethodField()
    material_sub_cost_head_name = serializers.SerializerMethodField()
    unit_of_mesurement_name = serializers.SerializerMethodField()
    second_uom = serializers.SerializerMethodField()
    material_nature_name = serializers.SerializerMethodField()
    second_unit_of_mesurement = serializers.SerializerMethodField()
    material_hsn_code = serializers.SerializerMethodField()
    material_type_details = serializers.SerializerMethodField()
    material_type_parent_details = serializers.SerializerMethodField()
    material_type_details_with_parent = serializers.SerializerMethodField()
    material_group_details = serializers.SerializerMethodField()
    gst_tax_details = serializers.SerializerMethodField()


    def get_second_unit_of_mesurement(self,instance):
        ''' currently in use by frontend '''
        key_list = SecondUnitOfMesurement.cmobjects.filter(material_id=instance.id).values("id","primary_rate","conversion_rate","second_uom")
        return key_list

    def get_material_type_name(self,instance):
        if instance.material_type and instance.material_type_id:
            # material_details = MaterialType.cmobjects.filter(id=instance.material_type_id).first()
            # if material_details:
            #     return material_details.name
            return instance.material_type.name
        return "" 
    
    '''
    def get_material_sub_type_name(self,instance):
        # if instance.material_sub_type_id and instance.material_sub_type:
        #     _details = MaterialSubType.cmobjects.filter(pk=instance.material_sub_type_id).first()
        #     if _details:
        #         return _details.name
        return ""
    '''
    
    def get_material_cost_head_name(self,instance):
        if instance.material_cost_head_id:
            # material_details = MaterialCostHead.cmobjects.filter(id=instance.material_cost_head_id).first()
            # return material_details.name
            return instance.material_cost_head.name
        return "" 
    
    def get_material_sub_cost_head_name(self,instance):
        if instance.material_sub_cost_head_id and instance.material_sub_cost_head:
            # material_details = MaterialSubCostHead.cmobjects.filter(id=instance.material_sub_cost_head_id).first()
            # return material_details.name
            return instance.material_sub_cost_head.name
        return ""
    
    def get_second_uom(self,instance):
        _details = SecondUnitOfMesurement.cmobjects.filter(material=instance).values()
        if _details:
            return _details
       
        return []
        # return get_details_from_instance(instance.vendor_materials,extras=[], type="list") 

    def get_unit_of_mesurement_name(self, instance):
        if instance.unit_of_mesurement and instance.unit_of_mesurement_id:
            # mesurement_details = UnitOfMesurement.cmobjects.filter(id=instance.unit_of_mesurement_id).first()
            # return mesurement_details.symbol if mesurement_details else ""
            # return instance.unit_of_mesurement.symbol
            return getattr(instance.unit_of_mesurement, 'symbol', '') or ''
        return ""

    
    def get_material_nature_name(self,instance):
        if instance.material_nature:
            # material_details = MaterialNature.cmobjects.filter(id=instance.material_nature_id).first()
            return instance.material_nature
        return ""

    def get_material_hsn_code(self, instance):
        if instance.hsn_code and instance.hsn_code_id:
            # material_details = HSNMaster.cmobjects.filter(pk=instance.hsn_code_id, is_deleted=False).values().first()
            # return material_details
            return get_details_from_instance(instance.hsn_code,extras=[], type="dict") 
        return ""

    def get_material_type_details(self, instance):
        material_type_details = []
        if instance.material_type and instance.material_type_id:
            # material_type_details = MaterialType.cmobjects.filter(id=instance.material_type_id).values()
            # if material_type_details:
            #     return material_type_details
            return get_details_from_instance(instance.material_type,extras=[], type="list") 
        return material_type_details

    def get_material_type_parent_details(self, instance):
        material_type_details = []
        if instance.material_type:
            if instance.material_type.parent and instance.material_type.parent_id:
                # material_type_details = MaterialType.cmobjects.filter(id=instance.material_type.parent_id).values()
                # if material_type_details:
                #     return material_type_details
                return get_details_from_instance(instance.material_type.parent, extras=[], type="list")

        return material_type_details

    def get_material_type_details_with_parent(self, instance):
        material_type_details = []
        if instance.material_type and instance.material_type_id:
            material_type_details = MaterialType.cmobjects.filter(parent_id=instance.material_type_id).values()
            if material_type_details:
                return material_type_details
        return material_type_details

    def get_material_group_details(self, instance):
        material_group_details = []
        if instance.material_type and instance.material_type_id:
            # material_group_details = MaterialType.cmobjects.filter(id=instance.material_type_id).values()
            return get_details_from_instance(instance.material_type,extras=[], type="list") 
            # if material_group_details:
            #     # Check if the material type has a parent
            #     parent_id = material_group_details[0].get('parent_id')
            #     if parent_id:
            #         # Get the details of the parent material type
            #         parent_material_group_details = MaterialType.cmobjects.filter(id=parent_id).values()
            #         material_group_details[0]['parent_details'] = parent_material_group_details[0]
            #         material_group_details[0]['top_parent_details'] = get_top_parent(parent_id)
            #     return material_group_details
        return material_group_details

    def get_gst_tax_details(self, instance):
        return get_details_from_instance(instance.gst_tax, type="dict")

    class Meta:
        model = VendorMaterialMaster
        fields = '__all__'


class VendorMaterialMasterSerializer2(serializers.ModelSerializer):
    """"
    Vendor Material Master Serializer 2
    """
    class Meta:
        model = VendorMaterialMaster
        fields = ['id', 'material_code', 'hsncode', 'material_name', 'material_descriptions', 'sap_code']
        read_only_fields = ['id']

class ItemTypeSerializer(serializers.ModelSerializer):
    """"
    ItemTypes Serializer
    """

    class Meta:
        model = ItemType
        fields = '__all__'


class PrimaryGroupSerializer(serializers.ModelSerializer):
    """"
    PrimaryGroup Serializer
    """

    class Meta:
        model = PrimaryGroup
        fields = '__all__'


class ProductionTypeSerializer(serializers.ModelSerializer):
    """"
    PrimaryGroup Serializer
    """

    class Meta:
        model = PrimaryGroup
        fields = '__all__'


class BrandSerializer(serializers.ModelSerializer):
    """
    Brand Serializer
    """
    material_type_names = serializers.SerializerMethodField()

    def get_material_type_names(self,instance):
        list = []
        for temp in instance.material_type.all():
            list.append(temp.name)
        return ",".join(list)

    class Meta:
        model = Brand
        fields = '__all__'


class ModelSerializer(serializers.ModelSerializer):
    """
    ModelMaster Serializer
    """

    brand_details = serializers.SerializerMethodField()
    item_details = serializers.SerializerMethodField()

    def get_brand_details(self, instance):
        _brand = []
        if instance.brand and instance.brand_id:
            _brand = Brand.cmobjects.filter(pk=instance.brand_id).values('code', 'type', 'name', 'material_type')
        return _brand

    def get_item_details(self, instance):
        _material = []
        if instance.item and instance.item_id:
            _material = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).values('id', 'material_code', 'material_name',)
        return _material

    class Meta:
        model = Model
        fields = '__all__'


class DeprecationGroupMasterSerializer(serializers.ModelSerializer):
    """
    DeprecationGroupMaster Serializer
    """

    class Meta:
        model = DeprecationGroupMaster
        fields = '__all__'


class AssetMasterSerializer(serializers.ModelSerializer):
    """
    DeprecationGroupMaster Serializer
    """
    location_details = serializers.SerializerMethodField()
    item_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    asset_account_head_details = serializers.SerializerMethodField()

    def get_location_details(self, instance):
        _details = None
        if instance.location:
            _id = -1
            try:
                _id = int(instance.location)
            except Exception as e:
                print("error", str(e))
            _details = Location.cmobjects.filter(pk=_id).values()
        return _details

    def get_item_details(self, instance):
        _details = []
        if instance.item and instance.item_id:
            _details = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).values('id', 'material_name', 'material_code')
        return _details

    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, type="dict")

    def get_asset_account_head_details(self, instance):
        _details = None
        if instance.asset_account and instance.asset_account_id:
            _details = AccountsHead.cmobjects.filter(pk=instance.asset_account_id).values('id', 'name')
        return _details


    class Meta:
        model = AssetMaster
        fields = '__all__'




class MaterialGstEntrySerializer(serializers.ModelSerializer):
    """
    MaterialGstEntry Serializer
    """
    material_details = serializers.SerializerMethodField()
    tax_details = serializers.SerializerMethodField()

    def get_material_details(self, instance):
        material_details = []
        if instance.material:
            material_details = VendorMaterialMaster.cmobjects.filter(pk=instance.material_id).values()
        return material_details
    
    def get_tax_details(self, instance):
        tax_details = []
        if instance.tax:
            tax_details = TaxHead.cmobjects.filter(pk=instance.tax_id).values()
        return tax_details

    class Meta:
        model = MaterialGstEntry
        fields = '__all__'