from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline

from .models import *


# Register your models here.

class SecondUnitOfMesurementAdmin(StackedInline):
    """
	SecondUnitOfMesurement Admin
	"""
    model = SecondUnitOfMesurement
    fk_name = 'material'


class MaterialSubCostHeadAdmin(StackedInline):
    """
	MaterialSubCostHead Admin
	"""
    model = MaterialSubCostHead
    fk_name = 'material_cost_head'


class VendorMaterialMasterAdmin(ModelAdmin):
    inlines = (SecondUnitOfMesurementAdmin,)
    list_filter = ['is_created_through_sap', 'is_warehouse_material', 'is_boi_material', 'is_asset_material', 'is_dsr_material', 'blocked_indicator', 'is_deleted']
    list_display = ['id','material_code', 'material_name', 'material_type', 'unit_of_mesurement', 'sap_code', 'blocked_indicator', 'is_created_through_sap', 'is_warehouse_material', 'is_boi_material', 'is_asset_material', 'is_dsr_material', 'is_deleted']
    search_fields = ('material_code', 'material_name', 'sap_code',)



class MaterialCostHeadAdmin(ModelAdmin):
    inlines = (MaterialSubCostHeadAdmin,)

@admin.register(UnitOfMesurement)
class UnitOfMesurementAdmin(ModelAdmin):
    list_display = ['formal_name', 'symbol', 'is_deleted']
    search_fields = ('formal_name', 'symbol',)


admin.site.register(MaterialCostHead, MaterialCostHeadAdmin)
admin.site.register(MaterialNature,ModelAdmin)
admin.site.register(VendorMaterialMaster, VendorMaterialMasterAdmin)

@admin.register(HSNMaster)
class HSNMasterAdmin(ModelAdmin):
    list_display = ['schedule', 's_no', 'hsn_code', 'cgst_percentage', 'sgst_percentage', 'igst_percentage',
                    'is_deleted']
    search_fields = ('hsn_code',)


@admin.register(MaterialSubType)
class MaterialSubTypeAdmin(ModelAdmin):
    list_display = ['name', 'material_type', 'is_deleted', 'code', 'tolerance_level', 'purchase_account',
                    'sales_account', 'item_type', 'primary_group', 'gst_tax', 'is_production_type', 'production_type']
    search_fields = ('code',)
    readonly_fields = ('id',)

class MaterialSubTypeInline(StackedInline):
    model = MaterialSubType
    extra = 1

class MaterialTypeAdmin(ModelAdmin):
    list_display = ['name', 'code', 'is_deleted', 'tolerance_level', 'purchase_account', 'sales_account', 'item_type',
                    'primary_group', 'gst_tax', 'is_production_type', 'production_type']
    search_fields = ('code',)
    inlines = [MaterialSubTypeInline]

admin.site.register(MaterialType, MaterialTypeAdmin)

admin.site.register(ItemType,ModelAdmin)
admin.site.register(PrimaryGroup,ModelAdmin)
admin.site.register(ProductionType,ModelAdmin)
admin.site.register(Brand,ModelAdmin)
admin.site.register(Model,ModelAdmin)
admin.site.register(DeprecationGroupMaster,ModelAdmin)
admin.site.register(AssetMaster,ModelAdmin)


@admin.register(MaterialGstEntry)
class MaterialGstEntryAdmin(ModelAdmin):
    list_display = ['hsn_code', 'material', 'tax', 'is_deleted']
    search_fields = ('hsn_code',)

