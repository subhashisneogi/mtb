from django.urls import path
from material_master import views


urlpatterns = [

    path('unit-of-mesurement/', views.UnitOfMesurementAPI.as_view()),
    path('material-type/', views.MaterialTypeAPI.as_view()),
    # path('material-sub-type/', views.MaterialSubTypeAPI.as_view()),
    path('material-cost-head/', views.MaterialCostHeadAPI.as_view()),
    path('material-nature/', views.MaterialNatureAPIView.as_view()),
    path('material-master/', views.VendorMaterialMasterAPIView.as_view()),
    path('bulk-material-master/', views.BulkVendorMaterialMasterAPIView.as_view()),
    path('material-master-import/', views.VendorMaterialMasterImportAPIView.as_view()),
    path('hsn-code/', views.HSNCodeAPIView.as_view()),
    path('item-type/', views.ItemTypeAPIView.as_view()),
    path('primary-group/', views.PrimaryGroupAPIView.as_view()),
    path('production-type/', views.ProductionTypeAPIView.as_view()),
    path('material-brand/', views.BrandAPIView.as_view()),
    path('material-model/', views.ModelAPIView.as_view()),
    path('material-deprecation-group/', views.DeprecationGroupAPIView.as_view()),
    path('material-asset/', views.AssetMasterAPIView.as_view()),
    path('generate-material-code/', views.GenerateMaterialCodeAPIView2.as_view()),
    path('material-gst-entry/', views.MaterialGstEntryAPIView.as_view()),
    path('boi-material-master/', views.BOIVendorMaterialMasterAPIView.as_view()),
    path('uom-sync-belsio/', views.UOMSyncBelsioAPIView.as_view()),
    path('category-sync-belsio/', views.CategorySyncBelsioAPIView.as_view()),
    path('item-master-sync-belsio/', views.ItemMasterSyncBelsioAPIView.as_view()),
   

]