from django.db import models

from administrations.models import *
from misc.models import *
from vendor.models import *

# Create your models here.


class UnitOfMesurement(BaseAbstractStructure):
    """
    UOM Model
    """
    organization = models.ForeignKey(Organization, related_name='uom_organization', on_delete=models.CASCADE)
    formal_name = models.CharField(max_length=255)
    symbol = models.CharField(max_length=100)
    decimal_places = models.IntegerField(null=True, blank=True)
    formula_for_qty_calculation = models.CharField(max_length=200, null=True, blank=True)
    extra=models.JSONField(blank=True,null=True)
    def __str__(self):
        return str(self.formal_name) + " (" + str(self.symbol) + ")"


class ItemType(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='material_item_type_organization',
                                     on_delete=models.CASCADE)
    name = models.CharField(max_length=200)


class PrimaryGroup(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='material_primary_group_organization',
                                     on_delete=models.CASCADE)
    name = models.CharField(max_length=200)


class ProductionType(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='material_production_type_organization',
                                     on_delete=models.CASCADE)
    name = models.CharField(max_length=200)


class MaterialType(BaseAbstractStructure):
    """
    Material Type Model
    """
    organization = models.ForeignKey(Organization, related_name='material_type_organization', on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    code = models.CharField(max_length=200, null=True, blank=True, unique=True)  # TODO unique True
    order_id = models.IntegerField(default=0)
    tolerance_level = models.FloatField(default=0, null=True, blank=True)
    purchase_account = models.ForeignKey(AccountsHead, on_delete=models.CASCADE,
                             related_name='material_type_purchase_account', null=True, blank=True)
    sales_account = models.ForeignKey(AccountsHead, on_delete=models.CASCADE,
                             related_name='material_type_sales_account', null=True, blank=True)
    item_type = models.ForeignKey(ItemType, related_name='material_type_item_type',
                                  on_delete=models.CASCADE, null=True, blank=True)
    primary_group = models.ForeignKey(PrimaryGroup, related_name='material_type_primary_group_pgr',
                                      on_delete=models.CASCADE, null=True, blank=True)
    gst_tax = models.ForeignKey(TaxHead, related_name='material_type_primary_group_gst_tax',
                                null=True, blank=True, on_delete=models.CASCADE)
    is_production_type = models.BooleanField(default=False, null=True, blank=True)
    production_type = models.ForeignKey(ProductionType, related_name="material_type_production_type",
                                        on_delete=models.CASCADE, null=True, blank=True)
    parent = models.ForeignKey('self', related_name='material_type_primary_group_parent', on_delete=models.DO_NOTHING,
                               null=True, blank=True)
    extra=models.JSONField(null=True,blank=True)
    mr_approver=models.ManyToManyField(PmsUser,related_name="material_mr_approver", null=True, blank=True)
    def __str__(self):
        return str(self.id) + '/' + str(self.name) + '/' + str(self.code)


class MaterialSubType(BaseAbstractStructure):
    """
    Material Type Model
    """
    organization = models.ForeignKey(Organization, related_name='material_types_organization',
                                     on_delete=models.CASCADE)
    material_type = models.ForeignKey(MaterialType, related_name='material_types', on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    code = models.CharField(max_length=200, null=True, blank=True, unique=True)
    tolerance_level = models.FloatField(default=200, null=True, blank=True)
    # purchase_account = models.CharField(max_length=200, null=True, blank=True)
    # sales_account = models.CharField(max_length=200, null=True, blank=True)
    purchase_account = models.ForeignKey(AccountsHead, on_delete=models.CASCADE,
                             related_name='material_sub_type_purchase_account', null=True, blank=True)
    sales_account = models.ForeignKey(AccountsHead, on_delete=models.CASCADE,
                             related_name='material_sub_type_sales_account', null=True, blank=True)
    item_type = models.ForeignKey(ItemType, related_name='material_sub_type_item_type',
                                  on_delete=models.CASCADE, null=True, blank=True)
    primary_group = models.ForeignKey(PrimaryGroup, related_name='material_sub_type_primary_group',
                                      on_delete=models.CASCADE, null=True, blank=True)
    gst_tax = models.ForeignKey(TaxHead, related_name='material_sub_type_primary_group',
                                null=True, blank=True, on_delete=models.CASCADE)
    is_production_type = models.BooleanField(default=False, null=True, blank=True)
    production_type = models.ForeignKey(ProductionType, related_name="material_sub_type_production_type",
                                        on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        if self.material_type and self.material_type.code:
            return str(self.id) + '/' + str(self.name) + '/' + str(self.code) + ' |' + str(self.material_type.code)
        return str(self.id) + '/' + str(self.name) + '/' + str(self.code) + ' |' + str(None)


class MaterialCostHead(BaseAbstractStructure):
    """
    Material Cost Head Model
    """
    organization = models.ForeignKey(Organization, related_name='material_cost_head_organization',
                                     on_delete=models.CASCADE)
    name = models.CharField(max_length=200)

    def __str__(self):
        return str(self.name)


class MaterialSubCostHead(BaseAbstractStructure):
    """
    Material Sub Cost Head
    """
    material_cost_head = models.ForeignKey(MaterialCostHead, related_name='material_cost_heads',
                                           on_delete=models.CASCADE)
    name = models.CharField(max_length=200)

    def __str__(self):
        return str(self.name)


class MaterialNature(BaseAbstractStructure):
    """
    Material Nature Model
    """
    organization = models.ForeignKey(Organization, related_name='material_nature_organization',
                                     on_delete=models.CASCADE)
    name = models.CharField(max_length=200)

    def __str__(self):
        return str(self.name)


class HSNMaster(BaseAbstractStructure):
    """
    Material HSN Model
    """
    TYPE = (
        ('goods', 'Goods'),
        ('services', 'Services'),
    )
    schedule = models.CharField(max_length=200, null=True, blank=True)
    s_no = models.CharField(max_length=200, null=True, blank=True)
    hsn_code = models.CharField(max_length=200, null=True, blank=True)
    cgst_percentage = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    details = models.TextField(max_length=500, null=True, blank=True)
    hsn_type = models.CharField(max_length=100, choices=TYPE, default='goods')

    def __str__(self):
        return str(self.hsn_code) + " (" + str(self.cgst_percentage) + " | " + str(self.sgst_percentage) + " | " + str(
            self.igst_percentage) + ")"

    class Meta:
        unique_together = ('schedule', 's_no', 'hsn_code',)
        db_table = "hsn_codes"


class VendorMaterialMaster(BaseAbstractStructure):
    """
    Vendor Material Master
    """
    VALUATIONS = (
        ('FIFO', 'FIFO'),
        ('LIFO', 'LIFO'),
        ('Weighted Average Rate', 'Weighted Average Rate'),
        ('Average Rate', 'Average Rate'),
    )
    VALUE_TYPES = (
        ('Yes', 'Yes'),
        ('No', 'No'),
    )
    organization = models.ForeignKey(Organization, related_name='material_master_organization',on_delete=models.DO_NOTHING)
    material_code = models.CharField(max_length=200, blank=True, null=True)
    material_name = models.CharField(max_length=255)
    display_name = models.CharField(max_length=200, blank=True, null=True)
    order_id = models.IntegerField(default=0)
    material_descriptions = models.TextField(blank=True, null=True)
    material_type = models.ForeignKey(MaterialType, related_name='material_types_master', on_delete=models.DO_NOTHING, blank=True, null=True)
    material_sub_type = models.ForeignKey(MaterialSubType, related_name='material_sub_types_master', on_delete=models.DO_NOTHING, null=True, blank=True)
    material_cost_head = models.ForeignKey(MaterialCostHead, related_name='material_cost_head_master', on_delete=models.DO_NOTHING, null=True, blank=True)
    material_sub_cost_head = models.ForeignKey(MaterialSubCostHead, related_name='material_cost_head_master', on_delete=models.DO_NOTHING, null=True, blank=True)
    material_image = models.ImageField(
        upload_to='vendor_material/material_image', null=True, blank=True)
    unit_of_mesurement = models.ForeignKey(UnitOfMesurement, related_name='uom_master', on_delete=models.DO_NOTHING)
    second_unit_applicability = models.CharField(max_length=150, choices=VALUE_TYPES, blank=True, null=True)
    material_nature = models.TextField(null=True, blank=True)
    material_lead_time = models.IntegerField(default=1, blank=True, null=True)
    material_valuation = models.CharField(max_length=150, choices=VALUATIONS, blank=True, null=True)
    material_tolerance = models.FloatField(null=True, blank=True)
    material_wastage = models.FloatField(null=True, blank=True)
    material_short_close_required = models.CharField(max_length=10, blank=True, null=True)
    gst_applicable = models.CharField(max_length=10, blank=True, null=True)
    hsncode = models.CharField(max_length=200, blank=True, null=True)
    hsn_code = models.ForeignKey(HSNMaster, related_name='material_hsn_code', on_delete=models.CASCADE, blank=True, null=True)
    gst_tax = models.ForeignKey(TaxHead, related_name='material_gst_tax', on_delete=models.DO_NOTHING, blank=True, null=True)
    # TODO delete after linking with hsn_code
    # cgst_percentage = models.FloatField(null=True, blank=True)
    # sgst_percentage = models.FloatField(null=True, blank=True)
    # igst_percentage = models.FloatField(null=True, blank=True)
    # =========================
    sap_code = models.CharField(max_length=12, null=True, blank=True)
    part_no = models.CharField(max_length=200, null=True, blank=True)
    is_part_checked = models.BooleanField(blank=True, null=True, default=True)
    materialtype = models.CharField(max_length=200, blank=True, null=True)
    remarks = models.TextField(max_length=500, blank=True, null=True)
    is_created_through_sap = models.BooleanField(default=False)
    created_on = models.CharField(max_length=200, blank=True, null=True)
    plant = models.CharField(max_length=200, blank=True, null=True)
    is_warehouse_material = models.BooleanField(default=False)
    is_boi_material = models.BooleanField(default=False)
    is_dsr_material = models.BooleanField(default=False)
    is_major_material = models.BooleanField(default=False)
    boi_projects=models.ManyToManyField("project_and_planning.ProjectMaster",related_name="material_boi_projects", null=True, blank=True)
    extra = models.JSONField(null=True, blank=True)
    is_asset_material = models.BooleanField(default=False)
    is_project_material = models.BooleanField(default=False)
    is_expense_material= models.BooleanField(default=False)
    blocked_indicator = models.CharField(max_length=200, blank=True, null=True)
    shelf_life = models.FloatField(default=0)
    is_royalty = models.BooleanField(default=False)
    is_shelf_material = models.BooleanField(default=False)
    def __str__(self):
        return str(self.id) + ' ' + str(self.material_name) + " (" + str(self.material_code) + ")"


class SecondUnitOfMesurement(BaseAbstractStructure):
    """
    Second Unit Of Mesurement
    """
    material = models.ForeignKey(VendorMaterialMaster, related_name='vendor_materials', on_delete=models.CASCADE,
                                 blank=True, null=True)
    primary_rate = models.FloatField(null=True, blank=True)
    conversion_rate = models.FloatField(null=True, blank=True)
    second_uom = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return str(self.primary_rate if self.primary_rate else '') + str(
            self.material.unit_of_mesurement.symbol) + " = " + str(
            self.conversion_rate if self.conversion_rate else '') + " " + str(self.second_uom)


class Brand(BaseAbstractStructure):
    BRAND_TYPE = (
        ('for_battery', 'For Battery'),
        ('for_tyre', 'For Tyre'),
    )
    organization = models.ForeignKey(Organization, related_name='brand_material_organization', on_delete=models.CASCADE)
    code = models.CharField(max_length=200, null=True, blank=True, unique=True)
    type = models.CharField(max_length=150,choices=BRAND_TYPE, blank=True, null=True)
    name = models.CharField(max_length=200, null=True, blank=True,)
    # parent_material_type = models.ForeignKey(MaterialType, related_name='brand_parent_material_types', on_delete=models.CASCADE, null=True, blank=True)
    # material_type = models.ForeignKey(MaterialType, related_name='brand_material_types', on_delete=models.CASCADE, null=True, blank=True)
    material_type = models.ManyToManyField(MaterialType, null=True, blank=True)

    class Meta:
        db_table = "material_master_brand"


class Model(BaseAbstractStructure):
    BRAND_TYPE = (
        ('for_battery', 'for_battery'),
        ('for_tyre', 'for_tyre'),
    )

    organization = models.ForeignKey(Organization, related_name='master_model_organization', on_delete=models.CASCADE)
    code = models.CharField(max_length=200, null=True, blank=True, unique=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='uom_master_model', on_delete=models.CASCADE, null=True,
                            blank=True)
    brand = models.ForeignKey(Brand, related_name='brand_master_model', on_delete=models.CASCADE, null=True, blank=True)
    warranty_days = models.FloatField(null=True, blank=True, default=0)
    warranty_km = models.FloatField(null=True, blank=True, default=0)
    load_capacity = models.FloatField(null=True, blank=True, default=0)
    ply_rating = models.FloatField(null=True, blank=True, default=0)
    total_run = models.FloatField(null=True, blank=True, default=0)
    casing = models.CharField(max_length=200, null=True, blank=True)
    brand_type = models.CharField(max_length=150, choices=BRAND_TYPE, blank=True, null=True)
    item_type = models.ForeignKey(MaterialType, related_name='vendor_material_types_model', on_delete=models.CASCADE,
                             blank=True, null=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='vendor_materials_model', on_delete=models.CASCADE,
                             blank=True, null=True)
    tread = models.CharField(max_length=200, null=True, blank=True)
    tread_dpth = models.CharField(max_length=200, null=True, blank=True)
    size = models.FloatField(null=True, blank=True, default=0)
    grip = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "material_master_model"


class DeprecationGroupMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='deprecation_group_organization', on_delete=models.CASCADE)
    name = models.CharField(max_length=200, null=True, blank=True)
    depr_grp_per = models.FloatField(null=True, blank=True, default=0.0001)

    class Meta:
        db_table = "material_master_deprecation_group"


class AssetMaster(BaseAbstractStructure):
    STATUS = (
        ('active', 'ACTIVE'),
        ('inactive', 'INACTIVE'),
    )
    organization = models.ForeignKey(Organization, related_name='material_master_asset_organization',on_delete=models.CASCADE)
    item = models.ForeignKey(VendorMaterialMaster, related_name='material_master_asset_item', on_delete=models.CASCADE, blank=True, null=True)
    status = models.CharField(max_length=100, choices=STATUS, default='active')
    # Location  === Store
    # location = models.ForeignKey(Store, related_name='brand_master_model', on_delete=models.CASCADE, null=True, blank=True)
    location = models.IntegerField(blank=True, null=True) #  cyclic import issue: location-> site id
    use_full_life = models.CharField(max_length=200, null=True, blank=True)
    asset_no = models.CharField(max_length=200, null=True, blank=True)
    auto_assets_np = models.CharField(max_length=200, null=True, blank=True)
    depreciation_group = models.ForeignKey(DeprecationGroupMaster, related_name='material_master_deprecation_group', on_delete=models.CASCADE,blank=True, null=True)
    max_depreciation = models.FloatField(null=True, blank=True, default=0)

    #### Purchase / Sale Information
    vendor = models.ForeignKey(VendorMasterV2, related_name="vendor_master_asset_item", on_delete=models.CASCADE,blank=True, null=True)
    asset_account = models.ForeignKey(AccountsHead, on_delete=models.CASCADE,
                             related_name='material_master_asset_asset_account', null=True, blank=True)
    purchase_date = models.DateField(null=True, blank=True)
    pur_amt = models.FloatField(default=0)
    date = models.DateField(null=True, blank=True)
    sale_amt = models.FloatField(default=0)
    wdv = models.BooleanField(default=False)
    depreciation = models.FloatField(null=True, blank=True, default=0)

    class Meta:
        db_table = "material_master_asset"




class MaterialGstEntry(BaseAbstractStructure):
    
    organization = models.ForeignKey(Organization, related_name='material_master_material_gst_entry_organization', on_delete=models.CASCADE)
    material = models.ForeignKey(VendorMaterialMaster, related_name='material_gst_entry_material',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax = models.ForeignKey(TaxHead, related_name='material_gst_entry_tax', on_delete=models.CASCADE,
                            null=True, blank=True)
    hsn_code = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return f"material: {self.material},\
          tax_head: {self.tax}, hsn_code: {self.hsn_code}"




