from .models import *


def get_top_parent(id):
    details = MaterialType.cmobjects.filter(id=id).values()
    if details[0]['parent_id']:
        get_top_parent(details[0]['parent_id'])
    else:
        return details


def generate_material_code(material_type: MaterialType) -> str:
    code = ''
    if material_type:
        count = material_type.material_types_master.filter(is_deleted=False).count()
        material_type_name = material_type.name.replace(' ', '').upper()[:2]
        count = str(count).zfill(4)
        if material_type.parent:
            parent_material_type_name = material_type.parent.name.replace(' ', '').upper()[:2] + '-'
        else:
            parent_material_type_name = ''
        code = f'{parent_material_type_name}{material_type_name}-{count}'
    return code
