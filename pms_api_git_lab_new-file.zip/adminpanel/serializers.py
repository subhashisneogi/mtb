from rest_framework import serializers
from adminpanel.models import *


class CountrySerializer(serializers.ModelSerializer):
    """
    Serializer for Country objects
    """
    class Meta:
        model = Country
        fields = '__all__'


class StateSerializer(serializers.ModelSerializer):
    """
    Serializer for State objects
    """
    class Meta:
        model = State
        fields = '__all__'
        
    

class CitySerializer(serializers.ModelSerializer):
    """
    Serializer for City objects
    """
    class Meta:
        model = City
        fields = '__all__'


class ZoneSerializer(serializers.ModelSerializer):
    """
    Serializer for Zone objects
    """
    state_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)
    city_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)
    country_id = serializers.IntegerField(write_only=True)
    country = CountrySerializer(read_only=True)
    state_name_zone = StateSerializer(read_only=True, many=True, source='state')
    city_name_zone = CitySerializer(read_only=True, many=True, source='city')
    
    class Meta:
        model = Zone
        fields = ['id', 'zone_name', 'country_id', 'country', 'organization', 'state_ids', 'city_ids', 'state_name_zone', 'city_name_zone']

    def create(self, validated_data):
        state_ids = validated_data.pop('state_ids', [])
        city_ids = validated_data.pop('city_ids', [])
        country_id = validated_data.pop('country_id', None)
        # print("country_id",country_id)
        zone = Zone.objects.create(**validated_data)

        if country_id:
            country = Country.objects.filter(id=country_id).first()
            # print("country",country)
            zone.country = country
            zone.save()

        for state_id in state_ids:
            state = State.objects.get(state_id=state_id)
            zone.state.add(state)

        for city_id in city_ids:
            city = City.objects.get(city_id=city_id)
            zone.city.add(city)

        return zone

    def update(self, instance, validated_data):
        state_ids = validated_data.pop('state_ids', [])
        city_ids = validated_data.pop('city_ids', [])
        country_id = validated_data.pop('country_id', None)
        # print("country_id ssserialized",country_id)
        for key, value in validated_data.items():
            setattr(instance, key, value)

        if country_id:
            country = Country.objects.filter(pk=country_id).first()
            instance.country = country

        instance.state.clear()
        for state_id in state_ids:
            state = State.objects.filter(state_id=state_id).first()
            instance.state.add(state)

        instance.city.clear()
        for city_id in city_ids:
            city = City.objects.filter(city_id=city_id).first()
            instance.city.add(city)

        instance.save()
        return instance

class UserZoneLogSerializer(serializers.ModelSerializer):
    organization_name = serializers.ReadOnlyField(source='organization.name')
    user_username = serializers.ReadOnlyField(source='user.username')
    zone_name = serializers.ReadOnlyField(source='zone.zone_name')
    transfered_by_username = serializers.ReadOnlyField(source='transfered_by.username')

    class Meta:
        model = UserZoneLog
        fields = ['id', 'organization', 'organization_name', 'user', 'user_username', 'zone', 'zone_name',
                  'date', 'transfered_by', 'transfered_by_username']

class SiteLocationSerializer(serializers.ModelSerializer):
    """
    Serializer for Site location
    """
    class Meta:
        model = SiteLocation
        fields = '__all__'     


class AcademicTypeSerializer(serializers.ModelSerializer):
    """
    Serializer for AcademicType
    """
    class Meta:
        model = AcademicQualificationType
        fields = '__all__'
