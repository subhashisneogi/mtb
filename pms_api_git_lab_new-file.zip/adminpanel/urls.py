from django.urls import path,include
from adminpanel import views
from rest_framework import routers
router = routers.DefaultRouter()

urlpatterns = [
    path("zone/",views.ZoneAPIView.as_view(),name="Zone_list"),
    path("country/",views.ListCountryAPIView.as_view(),name="Country_list"),
    path('states/', views.ListStateAPIView.as_view(), name='State_list'),
    path('city/', views.ListCityAPIView.as_view(), name='City_list'),
    path('user_zone/', views.UserZone_assign.as_view(), name='User_zone'),
    path('user_zone_log/', views.UserZoneLogList.as_view(), name='user_zone_log'),
    path('site-location/', views.SiteLocationAPIView.as_view()),

    path('academic_type/', views.AcademicQualificationTypeAPIView.as_view()),
    path('MasterAPI/', views.MasterAPIView.as_view()),
    path('', include(router.urls)),

]