from adminpanel.models import *
import json
import os
from django.conf import settings

def import_country():
    """ import script for country"""
    try:
        Json_file = os.path.join(settings.BASE_DIR, 'countries+states+cities.json')
        with open(Json_file,encoding="utf-8") as json_file:
            data = json.load(json_file)

            for i in data:
                country_data = Country.objects.filter(name__iexact=i["name"])
                if not country_data.exists():
                    country = Country.objects.create(country_id=i["id"],name=i["name"],\
                        iso3=i["iso3"], iso2=i["iso2"], phone_code=i["phone_code"],\
                            numeric_code=i["numeric_code"], capital=i["capital"], currency=i["currency"],\
                                currency_name=i["currency_name"], region=i["region"], subregion=i["subregion"],\
                                    latitude=i["latitude"], longitude=i["longitude"])
                    country.save()

                else:
                    print("Country Already Exists- Country name "+ str(i["name"])) 

    except Exception as e:
        print("Error is "+ str(e))


def import_country_timezones():
    """ import script for country timezones """

    try:
        Json_file = os.path.join(settings.BASE_DIR, 'countries+states+cities.json')
        with open(Json_file,encoding="utf-8") as json_file:
            data = json.load(json_file)

            for i in data:
                country_data = Country.objects.filter(country_id=i["id"]).first()
                if country_data:
                    for item in i["timezones"]:
                        if not CountryTimezone.objects.filter(country_name=country_data, tzName=item['tzName']).exists():
                            timezone_data = CountryTimezone.objects.create(country_name=country_data,\
                                zoneName=item['zoneName'], gmtOffset=item['gmtOffset'],\
                                    gmtOffsetName=item['gmtOffsetName'], abbreviation=item['abbreviation'],\
                                        tzName=item['tzName'])
                            timezone_data.save()
                        else:
                            print("Timezone Already Exists- Country name "+ str(i["name"]))

                else:
                    print("Country Already Exists- Country name "+ str(country_data.name) + " timezone " + str(item['tzName'])) 

    except Exception as e:
        print("Error is "+ str(e))


def update_country_iso2():
    """ import script for update country iso2"""

    try:
        Json_file = os.path.join(settings.BASE_DIR, 'countries+states+cities.json')
        with open(Json_file,encoding="utf-8") as json_file:
            data = json.load(json_file)

            for i in data:
                country_data = Country.objects.filter(country_id=i["id"]).first()
                if country_data:
                    country_data.iso2 = i["iso2"]  
                    country_data.save()
                else:
                    print("Country Does'nt Exists") 

    except Exception as e:
        print("Error is "+ str(e))

def import_state():
    """ import script for State"""

    try:
        Json_file = os.path.join(settings.BASE_DIR, 'countries+states+cities.json')
        with open(Json_file,encoding="utf-8") as json_file:
            data = json.load(json_file)

            for i in data:
                country_data = Country.objects.filter(country_id=i["id"]).first()
                if country_data:
                    for item in i["states"]:
                        if not State.objects.filter(country_name=country_data, name=item['name']).exists():
                            state_data = State.objects.create(country_name=country_data,\
                                state_id=item['id'], name=item['name'],\
                                    state_code=item['state_code'], latitude=item['latitude'],\
                                        longitude=item['longitude'])
                            state_data.save()
                        else:
                            print("State Already Exists - State name - " + str(item["name"]))

                else:
                    print("Country Already Exists- Country name - " + str(country_data.name) + " state " + str(item['name'])) 

    except Exception as e:
        print("Error is "+ str(e))

from django.db import transaction
def import_city():
    """ import script for City"""

    try:
        Json_file = os.path.join(settings.BASE_DIR, 'countries+states+cities.json')
        with open(Json_file,encoding="utf-8") as json_file:
            data = json.load(json_file)
            for i in data:
                country_data = Country.objects.filter(country_id=i["id"]).first()
                if country_data:
                    for state_item in i['states']:
                        state_data = State.objects.filter(state_id=state_item["id"]).first()
                        if state_data:
                            for item in state_item["cities"]:
                                if not City.objects.filter(country=country_data,state=state_data, name=item['name']).exists():
                                    city_data = City.objects.create(country=country_data,\
                                        state=state_data, name=item['name'],\
                                            city_id=item['id'], latitude=item['latitude'],\
                                                longitude=item['longitude'])
                                    city_data.save()
                                else:
                                    print("City Already Exists - city name - " + str(item["name"]))
                        else:
                            print("State not found- State name - " + str(state_data.name) )             

                else:
                    print("Country not found- Country name - " + str(country_data.name) ) 
      
    except Exception as e:
        print("Error is "+ str(e))



def import_country_new():
    try:
        Json_file = os.path.join(settings.BASE_DIR, 'countries+states+cities.json')
        with open(Json_file, encoding="utf-8") as json_file:
            data = json.load(json_file)

            for i in data:
                country_data = Country.objects.filter(name__iexact=i["name"])
                if not country_data.exists():
                    country = Country.objects.create(country_id=i["id"],name=i["name"],\
                        iso3=i["iso3"], iso2=i["iso2"], phone_code=i["phone_code"],\
                            numeric_code=i["numeric_code"], capital=i["capital"], currency=i["currency"],\
                                currency_name=i["currency_name"], region=i["region"], subregion=i["subregion"],\
                                    latitude=i["latitude"], longitude=i["longitude"])
                    country.save()

                    for item in i["states"]:
                        state_data = State.objects.filter(state_id=item['id'],\
                            country_name=country)
                        if not state_data.exists():
                            state = State.objects.create(name=str(item["name"]),\
                                country_name=country, state_code=item['state_code'], state_id=item['id'],\
                                    latitude=item['latitude'],\
                                        longitude=item['longitude'])
                            state.save()

                            for obj in item["cities"]:
                                city_data = City.objects.filter(city_id=obj['id'],\
                                    state=state, country=country)
                                if not city_data.exists():
                                    city = City.objects.create(name=str(obj["name"]),\
                                        state=state, city_id=obj['id'], country=country, latitude=obj['latitude'],\
                                                longitude=obj['longitude'])
                                    city.save()
                                else:
                                    print("City Already Exists- City Name "+ str(obj["name"]))
                        else:
                            print("State Already Exists- State name "+ str(item["name"]))
                else:
                    print("Country Already Exists- Country name "+ str(i["name"])) 

    except Exception as e:
        print("Error is "+ str(e))



def forest_data_statewise():
    try:
        Json_file = os.path.join(settings.BASE_DIR, 'file.json')
        with open(Json_file, encoding="utf-8") as json_file:
            data = json.load(json_file)

        new_dict = {}

        for key, value in data.get('st_nm', None).items():
            for key1, value1, in data.get('geometry', None).items():
                if key == key1: 
                    new_dict['state'] = value
                    new_dict['geometry'] = value1

                    json_object = json.dumps(new_dict, indent=4)

                    with open("forest_data_india_statewise/" + str(value) + ".json", "w") as outfile:
                        outfile.write(json_object)


    except Exception as e:
        print("Error is "+ str(e))
