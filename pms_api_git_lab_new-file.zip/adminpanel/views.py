from datetime import date

from django.db.models import Count
from django.shortcuts import render, get_object_or_404
from django.utils import timezone
from django.db import transaction
from rest_framework import status, viewsets
from rest_framework.generics import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import APIException
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from knox.auth import TokenAuthentication
from adminpanel.models import *
from adminpanel.serializers import *
from django.core.paginator import Paginator
# Create your views here.
from administrations.models import *
from administrations.serializers import *
from material_master.models import VendorMaterialMaster
from plant_machinery.models import PlantMachineryMaster, PlantMachineryData
from tender.models import *
from tender.serializers import *
from tender_eligibility.models import *
from user_profile.models import *
from tender_eligibility.serializers import *
from tender_survey_details.models import *
from tender_survey_details.serializer import *
from procurement.models import *
import datetime
from procurement.helper import custom_filters

class ListCountryAPIView(ListAPIView):
    permission_classes = (AllowAny,)
    """This endpoint list all of the available Country from the database"""
    # queryset = Country.objects.all().order_by('-id')
    queryset = Country.objects.filter(is_default=True)
    serializer_class = CountrySerializer


class AcademicQualificationTypeAPIView(ListAPIView):
    permission_classes = (AllowAny,)
    """This endpoint list all of the available Country from the database"""
    # queryset = Country.objects.all().order_by('-id')
    queryset = AcademicQualificationType.objects.all()
    serializer_class = AcademicTypeSerializer


# class ListStateAPIView(ListCreateAPIView):
#     """This endpoint list specific state if country_id is provided otherwise list all of the available State from the database"""
#     serializer_class = StateSerializer
#     permission_classes = (AllowAny,)

#     def get_queryset(self):
#         country_id = self.request.query_params.get('country_id', None)
#         if country_id:
#             try:
#                 country = Country.objects.get(pk=country_id)
#                 queryset = State.objects.filter(
#                     country_name_id=country_id).order_by('-state_id')
#             except Country.DoesNotExist:
#                 queryset = State.objects.none()

#         # else:
#         #     queryset = State.objects.all().order_by('-id')
#         return queryset

#     def list(self, request, *args, **kwargs):
#         queryset = self.get_queryset()
#         if not queryset:
#             return Response([])
#         serializer = self.get_serializer(queryset, many=True)
#         return Response(serializer.data)


# class ListCityAPIView(ListAPIView):
#     permission_classes = (AllowAny,)
#     """
#     This class is used to retrieve list of cities based on the selected state 
#     """
#     serializer_class = CitySerializer

#     def get_queryset(self):
#         state_ids = self.request.query_params.getlist('state_id', [])
#         state_ids = [int(state_id) for state_id in state_ids]
#         country_ids = self.request.query_params.getlist('country_id', [])
#         country_ids = [int(country_id) for country_id in country_ids]
#         if state_ids:
#             queryset = City.objects.filter(
#                 state_id__in=state_ids).order_by('-city_id')
#         elif country_ids:
#             queryset = City.objects.filter(
#                 country_id__in=country_ids).order_by('-city_id')
#         else:
#             queryset = City.objects.none()
#         return queryset

#     def list(self, request, *args, **kwargs):
#         queryset = self.get_queryset()
#         if not queryset:
#             return Response({}, status=status.HTTP_404_NOT_FOUND)
#         serializer = self.get_serializer(queryset, many=True)
#         return Response(serializer.data)

class ListCityAPIView(ListAPIView):
    def get(self, request):
        city_id = self.request.query_params.get('city_id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-city_id')
        search = custom_filters(self.request, {}, [])
        if city_id:
            list_data = City.objects.filter(city_id=city_id).first()
            serializer = CitySerializer(list_data)
            return Response(serializer.data)
        
        list_data = City.objects.filter(*search).order_by(*str(order_by).split(",")).distinct()
        if all == 'true':
            serializer = CitySerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = CitySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
class ListStateAPIView(ListCreateAPIView):
    def get(self, request):
        state_id = self.request.query_params.get('state_id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-state_id')
        search = custom_filters(self.request, {}, [])
        
        if state_id:
            list_data = State.objects.filter(state_id=state_id).first()
            serializer = StateSerializer(list_data)
            return Response(serializer.data)
        
        list_data = State.objects.filter(*search).order_by(*str(order_by).split(",")).distinct()
        if all == 'true':
            serializer = StateSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = StateSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
		
class ZoneAPIView(APIView):
    """
    CRUD API for Zone model
    """
    
    
    
    # pagination_class = ZonePagination

    def get(self, request, format=None):
        """
        Get a list of all zones
        """
        id = self.request.query_params.get('id', None)
        is_deleted = self.request.query_params.get('is_deleted', 'false')
        organization_id = self.request.query_params.get(
            'organization_id', None)
        print(is_deleted)
        queryset = Zone.objects.select_related('country', 'organization').prefetch_related('state', 'city')
        if id:
            # zone = Zone.cmobjects.filter(
            #     id=id, organization_id=organization_id).first()
            zone = queryset.filter(id=id, organization_id=organization_id, is_deleted=False).first()
            if zone:
                serializer = ZoneSerializer(zone)
                return Response(serializer.data)
            else:
                return Response({'results': [],
                                 'msg': 'Zone not found ! Please try again.',
                                 'status': status.HTTP_404_NOT_FOUND,
                                 'request_status': 0})

        if is_deleted.lower() == 'true':
            # zones = Zone.objects.filter(
            #     organization_id=organization_id, is_deleted=True).order_by('-id')
            zones = queryset.filter(organization_id=organization_id, is_deleted=True).order_by('-id')
        else:
            # zones = Zone.cmobjects.filter(
            #     organization_id=organization_id, is_deleted=False).order_by('-id')
            zones = queryset.filter(organization_id=organization_id, is_deleted=False).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(zones, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = ZoneSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new zone
        """
        serializer = ZoneSerializer(data=request.data)
        if Zone.cmobjects.filter(zone_name=request.data['zone_name'],          # validate existing company name
                                 organization=request.data['organization']).exists():
            raise APIException({'request_status': 0, 'msg': "Zone name already exist"})

        if serializer.is_valid():
            country_id = request.data.get('country_id')
            print(country_id)
            country = Country.objects.filter(id=country_id).first()
            print(country)
            zone = serializer.save(country=country)
            return Response({'results': {
                'Data': serializer.data,
            },
                'msg': 'Successfully created zone',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        return Response({'results': {
            'Data': serializer.errors,
        },
            'msg': "Something went wrong. If the problem persists, please contact support.",
            'status': status.HTTP_400_BAD_REQUEST,
            "request_status": 0})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a zone
                """
                if Zone.cmobjects.filter(pk=id, organization=organization_id).exists():
                    zone = Zone.cmobjects.get(pk=id)

                    if Zone.cmobjects.filter(zone_name=request.data['zone_name'],          # validate existing company name
                                             organization=organization_id).exclude(\
                            zone_name=zone.zone_name).exists():
                        raise APIException({'request_status': 0, 'msg': "Zone name already exist"})

                    serializer = ZoneSerializer(zone, data=request.data)
                    if serializer.is_valid():
                        country_id = serializer.validated_data.get(
                            'country_id', None)

                        if country_id is not None:
                            country = Country.objects.get(id=country_id)
                            zone.country = country
                            print(zone.country)

                        # Update the Zone object with the new values
                        zone.zone_name = serializer.validated_data.get(
                            'zone_name', zone.zone_name)
                        # zone.country = serializer.validated_data.get('country', zone.country)
                        zone.save()

                        from administrations.utils import create_dependent_formvalues_on_master_crud_operations
                        create_dependent_formvalues_on_master_crud_operations('zone', zone.zone_name, zone.id)

                        # Get the list of state and city IDs from the request data
                        state_ids = serializer.validated_data.get(
                            'state_ids', [])
                        city_ids = serializer.validated_data.get(
                            'city_ids', [])

                        # Update the Zone's state and city relations
                        zone.state.clear()
                        for state_id in state_ids:
                            state = State.objects.get(state_id=state_id)
                            zone.state.add(state)

                        zone.city.clear()
                        for city_id in city_ids:
                            city = City.objects.get(city_id=city_id)
                            zone.city.add(city)

                        return Response({
                            'results': {
                                'Data': serializer.data,
                            },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1
                        })
                    return Response({
                        'results': {
                            'Data': serializer.errors,
                        },
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0
                    })
                else:
                    return Response({
                        'results': [],
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_404_NOT_FOUND,
                        "request_status": 0
                    })
            elif method.lower() == 'delete':
                """
                Delete a zone
                """
                print(id)
                if Zone.cmobjects.filter(pk=id, organization=organization_id).exists():
                    zone = Zone.cmobjects.get(
                        pk=id, organization=organization_id)
                    zone.is_deleted = True
                    zone.save()
                    serializer = ZoneSerializer(zone)
                    return Response({'results': {
                        'Data': serializer.data,
                    },
                        'msg': 'Successfully deleted zone',
                        'status': status.HTTP_202_ACCEPTED,
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})


class UserZone_assign(APIView):
    """
    Update Assigned zone to user and log it
    """
    
    
    

    def put(self, request, *args, **kwargs):
        method = self.request.query_params.get('method', None)

        if method.lower() == 'edit':
            zone_id = request.data.get('zone_id')
            user_id = request.data.get('user_id')
            organization_id = request.data.get('organization_id')
            try:
                organization = Organization.objects.get(id=organization_id)
                zone = Zone.objects.get(id=zone_id, organization=organization)
                user = PmsUser.objects.get(
                    id=user_id, organization=organization)

                # Update user's zone
                user.zone = zone
                user.save()

                # Create log entry for UserZoneLog
                log_entry = UserZoneLog(
                    organization=organization,
                    user=user,
                    zone=zone,
                    date=datetime.now(),
                    transfered_by=request.user
                )
                log_entry.save()

                return Response({
                    'status': 'success',
                    'message': f'Zone {zone.zone_name} assigned to user {user.username}'
                }, status=status.HTTP_200_OK)
            except (Organization.DoesNotExist, Zone.DoesNotExist, PmsUser.DoesNotExist):
                return Response({"error": "Invalid organization, zone, or user id."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"error": "Invalid method."}, status=status.HTTP_400_BAD_REQUEST)


class UserZoneLogList(APIView):
    """
    List all UserZoneLog instances
    """
    
    

    def get(self, request, format=None):
        # Get query parameters for pagination and filter by organization
        page = self.request.query_params.get('page', 1)
        page_size = self.request.query_params.get('page_size', settings.MIN_PAGE_SIZE)
        organization_id = self.request.query_params.get(
            'organization_id', None)

        user_zone_logs = UserZoneLog.objects.all().order_by('-date')
        if organization_id is not None:
            user_zone_logs = user_zone_logs.filter(
                organization_id=organization_id)

        # Paginate UserZoneLog instances
        paginator = Paginator(user_zone_logs, page_size)
        try:
            logs = paginator.page(page)
        except PageNotAnInteger:
            logs = paginator.page(1)
        except EmptyPage:
            logs = []

        # Serialize UserZoneLog instances and return response
        serializer = UserZoneLogSerializer(logs, many=True)
        return Response({
            'count': paginator.count,
            'next': logs.next_page_number() if logs.has_next() else None,
            'previous': logs.previous_page_number() if logs.has_previous() else None,
            'results': serializer.data,
        })


class SiteLocationAPIView(APIView):
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all site location
        """

        organization_id = self.request.query_params.get(
            'organization_id', None)
        zone_id = self.request.query_params.get('zone_id', None)

        site_location = SiteLocation.cmobjects.filter(
            organization_id=organization_id, zone_id=zone_id).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(site_location, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = SiteLocationSerializer(site_location, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)
            zone_id = request.data.get('zone', None)
            site_name = request.data.get('site_name', None)

            with transaction.atomic():

                if SiteLocation.cmobjects.filter(site_name=site_name.strip(),          # validate existing tender name
                                                 organization_id=organization_id, zone_id=zone_id).exists():
                    raise APIException({'request_status': 0, 'msg': "site location is  already exist "})

                created = SiteLocation.objects.create(
                    organization_id=organization_id, site_name=site_name, zone_id=zone_id, created_by=request.user)
                created.save()

                serializer = SiteLocationSerializer(created)

                return Response({'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Site Location Added SuccessFully',
                    'status': status.HTTP_200_OK,
                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        zone_id = self.request.query_params.get('zone_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                site_name = request.data.get('site_name', None)

                site_location_details = SiteLocation.cmobjects.filter(
                    pk=id).first()

                if not site_location_details:
                    return Response({'results': [],
                                    'msg': "Selected Site Location Does'nt exists!",
                                     "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)

                if SiteLocation.cmobjects.filter(site_name=site_name.strip(),          # validate existing tender name
                                                 organization_id=organization_id, zone_id=zone_id).exists():
                    raise APIException({'request_status': 0, 'msg': "site with  same name already exist "})

                site_location = SiteLocation.cmobjects.filter(id=id).first()

                update = SiteLocation.cmobjects.filter(id=id, organization=organization_id, zone_id=zone_id)\
                    .update(site_name=site_name, updated_by=request.user)
                return Response({'results': {
                    'Data': SiteLocation.objects.filter(pk=id, organization=organization_id, zone_id=zone_id).values(),
                },
                    'msg': 'Site Location  Updated SuccessFully',
                    'status': status.HTTP_200_OK,
                    "request_status": 0})

            elif method.lower() == 'delete':
                """
                Delete a Site Location
                """
                if SiteLocation.cmobjects.filter(id=id, organization_id=organization_id, zone_id=zone_id).exists():
                    site_location_details = SiteLocation.cmobjects.filter(
                        id=id, organization=organization_id, zone_id=zone_id).first()
                    site_location_details.is_deleted = True
                    site_location_details.save()

                    return Response({'results': {
                        'form_details': SiteLocation.objects.filter(pk=id, organization=organization_id, zone_id=zone_id).values(),
                    },
                        'msg': 'Selected Site Location  Deleted Successfully',
                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Selected Site Location Does'nt exists!",
                                     'status': status.HTTP_404_NOT_FOUND,
                                     "request_status": 0})
from django.forms.models import model_to_dict


class MasterAPIView(APIView):
    def get(self, request):
        organization = request.GET.get('organization_id')
        qryname = request.GET.get('qryname')

        if qryname is not None:
            qryname = qryname.lower()
        else:
            return Response({'msg': "qryname can't be None or empty !!"},status=status.HTTP_406_NOT_ACCEPTABLE)
        if qryname == 'department':
            departments = Department.cmobjects.filter(organization=organization)
            data = [{'id': department.id, 'name': department.department} for department in departments]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'pmsuser':
            pms_users = PmsUser.objects.filter(organization=organization, is_deleted=False, is_active=True)
            data = [{'id': pms_user.id, 'name': pms_user.first_name +" " +pms_user.last_name} for pms_user in pms_users]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'zone':
            zone = Zone.cmobjects.filter(organization=organization)
            data = [{'id': zone.id, 'name': zone.zone_name} for zone in zone]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'company':
            company = Company.cmobjects.filter(organization=organization, users__in=[request.user])
            data = [{'id': cmpy.id, 'name': cmpy.name} for cmpy in company]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'employee_type':
            employee_type = UserType.cmobjects.filter(organization=organization)
            data = [{'id': cmpy.id, 'name': cmpy.user_type} for cmpy in employee_type]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'role':
            role_list = Role.cmobjects.filter(organization=organization)
            data = [{'id': cmpy.id, 'name': cmpy.designation} for cmpy in role_list]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'profile':
            profile_list = Profile.cmobjects.filter(organization=organization)
            data = [{'id': cmpy.id, 'name': cmpy.role_name} for cmpy in profile_list]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'state':
            state_list = State.objects.filter(country_name__is_default=True).order_by('name')
            data = [{'id': cmpy.state_id, 'name': cmpy.name} for cmpy in state_list]
            return Response({'msg': data}, status=status.HTTP_200_OK)
        elif qryname == 'sector':
            state_list = TenderSector.cmobjects.filter(organization=organization).order_by('name')
            data = [{'id': cmpy.id, 'name': cmpy.name} for cmpy in state_list]
            return Response({'msg': data}, status=status.HTTP_200_OK)
        elif qryname == 'sub_sector':
            state_list = TenderSubSector.cmobjects.filter(organization=organization).order_by('name')
            data = [{'id': cmpy.id, 'name': cmpy.name} for cmpy in state_list]
            return Response({'msg': data}, status=status.HTTP_200_OK)
        elif qryname == 'delay_reason':
            delay_list = DelayReasons.cmobjects.filter(organization=organization).order_by('reasons')
            data = [{'id': cmpy.id, 'name': cmpy.reasons} for cmpy in delay_list]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'sitelocation':
            siteLocation = SiteLocation.cmobjects.filter(organization=organization)
            data = [{'id': siteLocation.id, 'name': siteLocation.site_name} for siteLocation in siteLocation]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'site':
            site = SiteMaster.cmobjects.filter(organization=organization)
            data = [{'id': site.id, 'name': site.site_name} for site in site]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'city':
            city = City.objects.filter(country__is_default=True).order_by('name')
            data = [{'id': city.city_id, 'name': city.name} for city in city]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'account_group':
            account_group = AccountsHead.cmobjects.filter(organization=organization)
            data = [{'id': account_group.id, 'name': account_group.name} for account_group in account_group]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'currency':
            currency = VendorCurrencyMaster.cmobjects.filter(organization=organization)
            data = [{'id': currency.id, 'name': currency.name} for currency in currency]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'executive_commitee':
            group = Group.cmobjects.filter(organization = organization)
            data = [{'id': group.id, 'name': group.group_name} for group in group]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'jv_master':
            group = JVMASTER.cmobjects.filter(organization = organization)
            data = [{'id': group.id, 'name': group.party_name} for group in group]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'standalone_master':
            group = STANDALONEMASTER.cmobjects.filter(organization = organization)
            data = [{'id': group.id, 'name': group.party_name} for group in group]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'employee_master':
            group = EMPLOYEEMASTER.cmobjects.filter(organization = organization)
            data = [{'id': group.id, 'name': group.employee_name} for group in group]
            return Response({'msg': data},status=status.HTTP_200_OK)
        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX UserZoneLog XXXXXXXXXXXXXXXXXXXXXXXX this model not include in this
        ##################### Tender #######################
        elif qryname == 'TenderWorkFlow'.lower():
            qry = TenderWorkFlow.cmobjects.filter(organization=organization)
            data = [{'id': qry.id, 'name': qry.step_name} for qry in qry]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'TenderNotifications'.lower():
            qry = TenderNotifications.cmobjects.filter(organization=organization)
            data = [{'id': qry.id, 'name': qry.title} for qry in qry]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'TenderEvents'.lower():
            qry = TenderEvents.cmobjects.filter(organization=organization)
            data = [{'id': qry.id, 'name': qry.event_name} for qry in qry]
            return Response({'msg': data},status=status.HTTP_200_OK)
        elif qryname == 'unit_of_mesurement'.lower():
            qry = UnitOfMesurement.cmobjects.filter(organization=organization)
            data = [{'id': qry.id, 'name': qry.symbol} for qry in qry]
            return Response({'msg': data}, status=status.HTTP_200_OK)
        elif qryname == 'material_master'.lower():
            qry = VendorMaterialMaster.cmobjects.filter(organization=organization)
            data = [{'id': qry.id, 'name': qry.material_name} for qry in qry]
            return Response({'msg': data}, status=status.HTTP_200_OK)
        elif qryname == 'plant_machinery_master'.lower():

            # qry = PlantMachineryData.objects.raw('SELECT * FROM plant_machinery_plantmachinerydata WHERE is_deleted !=1 GROUP BY plantmachinery_id')
            qry = PlantMachineryData.objects.filter(is_deleted=False, form__form_internal_name='plant___equipment')
            # print(Back.GREEN, qry.query, Back.CYAN, qry, Style.RESET_ALL)
            data = [{'id': qry.plantmachinery_id, 'name': qry.value} for qry in qry]
            return Response({'msg': data}, status=status.HTTP_200_OK)
        else:
            return Response({'msg': 'Invalid qryname'}, \
                            status=status.HTTP_451_UNAVAILABLE_FOR_LEGAL_REASONS)

