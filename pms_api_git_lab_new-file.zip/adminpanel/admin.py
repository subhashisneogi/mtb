from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline

# Register your models here.
from .models import *


class CountryTimezoneAdmin(StackedInline):
	"""
	Country Timezone Admin
	"""
	model = CountryTimezone
	fk_name = 'country_name'


class CountryAdmin(ModelAdmin):
    """ Country admin"""
    model = Country
    list_display = ['name','iso3','iso2','phone_code','capital','is_default']
    search_fields = ['name','iso3','iso2','phone_code','capital']
    inlines = (CountryTimezoneAdmin,) 
admin.site.register(Country, CountryAdmin)

class ZoneAdmin(ModelAdmin):
    """ Zone admin """
    model = Zone
    filter_horizontal = ('state','city')
admin.site.register(Zone,ZoneAdmin)   

@admin.register(State)
class StateAdmin(ModelAdmin):
    """ State admin """
    model = State
    list_display = ('name','state_code','country_name','is_ut')
    search_fields = ('country_name__name',)
   
class CityAdmin(ModelAdmin):
    """ City admin"""
    model = City
    list_display = ('name','state','country')
admin.site.register(City, CityAdmin)    

admin.site.register(UserZoneLog,ModelAdmin) 
admin.site.register(AcademicQualificationType,ModelAdmin)

class SiteLocationAdmin(ModelAdmin):
    """ Site location admin"""
    model = SiteLocation
    list_display = ['organization','site_name','zone',]
    search_fields = ['organization','site_name','zone',]
admin.site.register(SiteLocation, SiteLocationAdmin)
