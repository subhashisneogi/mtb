
from django.db import models
# Create your models here.
from locale import currency
from time import timezone
from datetime import datetime


class Country(models.Model):
    """ Country Model PMS """
    country_id = models.IntegerField('country_id')
    name = models.CharField('name', max_length=100)
    iso3 = models.CharField('iso3', max_length=100, null=True)
    iso2 = models.CharField('iso2', max_length=100, null=True)
    numeric_code = models.CharField('numeric_code', max_length=10)
    phone_code = models.CharField('phone_code', max_length=200)
    capital = models.CharField('capital', max_length=100)
    currency = models.CharField('currency', max_length=10)
    currency_name = models.CharField('currency_name', max_length=100)
    region = models.CharField('region', max_length=60)
    subregion = models.CharField('subregion', max_length=100)
    latitude = models.DecimalField(
        'latitude', max_digits=30, decimal_places=20)
    longitude = models.DecimalField(
        'longitude', max_digits=30, decimal_places=20)
    is_default = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class CountryTimezone(models.Model):
    """ 
    Country Timezone Model PMS
    """
    country_name = models.ForeignKey(
        'Country', related_name='country_zones', on_delete=models.CASCADE)
    zoneName = models.CharField(max_length=255)
    gmtOffset = models.CharField(max_length=255)
    gmtOffsetName = models.CharField(max_length=255)
    abbreviation = models.CharField(max_length=255)
    tzName = models.CharField(max_length=255)

    def __str__(self):
        return self.tzName


class State(models.Model):
    """ States Model PMS """
    country_name = models.ForeignKey(
        'Country', related_name='country_name', on_delete=models.CASCADE)
    state_id = models.PositiveIntegerField(primary_key=True)
    name = models.CharField('name', max_length=100)
    state_code = models.CharField('state_code', max_length=100)
    latitude = models.DecimalField(
        'latitude', max_digits=30, decimal_places=20, null=True)
    longitude = models.DecimalField(
        'longitude', max_digits=30, decimal_places=20, null=True)
    is_ut = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class City(models.Model):
    """ City Model PMS """
    country = models.ForeignKey(
        'Country', related_name='country_name_city', on_delete=models.CASCADE)
    state = models.ForeignKey(
        'State', related_name='state_name_city', on_delete=models.CASCADE)
    city_id = models.PositiveIntegerField(primary_key=True)
    name = models.CharField('name', max_length=100)
    latitude = models.DecimalField(
        'latitude', max_digits=30, decimal_places=20, null=True)
    longitude = models.DecimalField(
        'longitude', max_digits=30, decimal_places=20, null=True)

    def __str__(self):
        return self.name


class AcademicQualificationType(models.Model):
    """
    Academic Qualification Type
    """
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name


class CustomManager(models.Manager):
    def get_queryset(self):
        return super(__class__, self).get_queryset().filter(is_deleted=False)


class Zone(models.Model):
    """ Zone Model PMS """
    organization = models.ForeignKey(
        'administrations.Organization', related_name='zone_organization', on_delete=models.CASCADE, blank=True, null=True)
    zone_name = models.CharField('zone_name', max_length=100)
    country = models.ForeignKey(
        'Country', related_name='country_name_zone', on_delete=models.CASCADE)
    state = models.ManyToManyField(
        State, related_name='state_name_zone', blank=True, null=True)
    city = models.ManyToManyField(
        City, related_name='city_name_zone', blank=True, null=True)

    is_deleted = models.BooleanField(default=False)
    created_by = models.ForeignKey(
        'administrations.PmsUser', on_delete=models.CASCADE, blank=True, null=True, related_name='zone_created_by')
    updated_by = models.ForeignKey(
        'administrations.PmsUser', on_delete=models.CASCADE, blank=True, null=True, related_name='zone_updated_by')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = models.Manager()

    cmobjects = CustomManager()

    def __str__(self):
        return self.zone_name

    def save(self, *args, **kwargs):
        self.updated_at = datetime.now()
        super(__class__, self).save(*args, **kwargs)


class UserZoneLog(models.Model):
    organization = models.ForeignKey(
        'administrations.Organization', on_delete=models.CASCADE)
    user = models.ForeignKey('administrations.PmsUser',
                             on_delete=models.CASCADE)
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE)
    date = models.DateTimeField()
    transfered_by = models.ForeignKey(
        'administrations.PmsUser', on_delete=models.CASCADE, related_name='transfered_user')

    def __str__(self):
        return f"{self.organization.name}: {self.user.username} - {self.zone.zone_name} ({self.date})"


class SiteLocation(models.Model):
    """
          Site location model
    """
    organization = models.ForeignKey(
        'administrations.Organization', related_name='site_organization', on_delete=models.CASCADE, blank=True, null=True)
    site_name = models.CharField(max_length=200, blank=True, null=True)
    zone = models.ForeignKey(Zone, related_name='site_zone',
                             on_delete=models.CASCADE, blank=True, null=True)
    created_by = models.ForeignKey(
        'administrations.PmsUser', on_delete=models.CASCADE, blank=True, null=True, related_name='site_location_created_by')
    updated_by = models.ForeignKey(
        'administrations.PmsUser', on_delete=models.CASCADE, blank=True, null=True, related_name='site_location_updated_by')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_deleted = models.BooleanField(default=False)

    objects = models.Manager()

    cmobjects = CustomManager()
