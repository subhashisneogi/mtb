from django.urls import path
from attendance import views
from django.contrib.auth import views as auth_views


urlpatterns = [

    path('all_month_list/', views.GetMonthList.as_view()),
    path('attendence_summary/', views.AttendenceSummary.as_view()),
    path('employee_attendence_summary/',
         views.EmployeeAttendenceSummary.as_view()),

    path('attendence_deviations/', views.AttendenceDeviationApi.as_view()),

    path('leave_summary/', views.LeaveSummary.as_view()),
    path('FortniteYearView/', views.GetFortnightAndFinancialYear.as_view()),

    path('hrms_details/', views.HRMSMASTER.as_view()),

    path('employee_monthly_leave/', views.EmployeeLeaveMonthlyWise.as_view()),

]
