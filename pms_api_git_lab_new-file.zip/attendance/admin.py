from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from .models import *
# Register your models here.


admin.site.register(HrmsMaster,ModelAdmin)
admin.site.register(DeviceMaster,ModelAdmin)
admin.site.register(Attendance,ModelAdmin)
admin.site.register(AttendenceDeviation,ModelAdmin)
admin.site.register(AttendanceCarryForwardLeaveBalanceYearly,ModelAdmin)