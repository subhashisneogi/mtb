from rest_framework import serializers
from attendance.models import *


class AttendanceSerializer(serializers.ModelSerializer):
    """
    Serializer for Attendance objects
    """
    duration_of_work = serializers.SerializerMethodField()
    deviation_details = serializers.SerializerMethodField()


    def get_deviation_details(self,instance):
        if instance.id:
            details = AttendenceDeviation.objects.filter(attendence_id=instance.id).values()
        else:
            details = []

        return details

    def get_duration_of_work(self,instance):
        if instance.total_work_duration_in_seconds:
            minutes_completed, seconds_completed = divmod(instance.total_work_duration_in_seconds, 60)
            hours_completed, minutes_completed = divmod(minutes_completed, 60)
            formatted_time = str(hours_completed) + " hrs " + str(minutes_completed) + " mins"
        else:
            formatted_time = ""

        return formatted_time
        

    class Meta:
        model = Attendance
        fields = '__all__'