from django.db import models
from django.conf import settings
from django.utils import timezone

from django.db.models.signals import post_delete
from django.dispatch import receiver

from administrations.models import Organization


class HrmsMaster(models.Model):
    Type_of_deviation = (('single', 'single'), ('double', 'double'))
    saturday_choice = (('even', 'even'), ('odd', 'odd'), ('all', 'all'))
    organization = models.OneToOneField(
        Organization, related_name='hrms_organization', on_delete=models.CASCADE)
    fortnite_type = models.CharField(max_length=20,
                                     choices=Type_of_deviation, blank=True, null=True)
    first_fortnite_day = models.IntegerField()
    second_fortnite_end_day = models.IntegerField()
    fortnight_durations = models.IntegerField(blank=True, null=True)
    saturday_off_type = models.CharField(max_length=20,
                                         choices=saturday_choice, blank=True, null=True)
    total_leave_alocation = models.DecimalField(
        max_digits=5, decimal_places=3, default=0.0)
    monthly_leave_alocation = models.DecimalField(
        max_digits=4, decimal_places=3, default=0.0)
    
    total_working_hours_allocation_per_employee = models.DecimalField(
        max_digits=4, decimal_places=3, default=0.0)
    
    financial_year_start_month = models.IntegerField(default=1)

    financial_year_end_month = models.IntegerField(default=1)


    def save(self, *args, **kwargs):
        self.total_leave_alocation = float(self.monthly_leave_alocation) * 12

        super(__class__, self).save(*args, **kwargs)


class DeviceMaster(models.Model):
    DEVICE_TYPE_CHOICES = (
        ('mobile', 'Mobile'),
        ('tablet', 'Tablet'),
        ('pc', 'PC'),
        ('bot', 'Bot')
    )
    organization = models.ForeignKey(
        Organization, related_name='device_organization', on_delete=models.CASCADE)
    # Device Info ##########``
    owned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='devicemaster_owned_by_employee_id', on_delete=models.CASCADE)
    device_type = models.CharField(
        max_length=10, choices=DEVICE_TYPE_CHOICES)
    device_ip = models.GenericIPAddressField(blank=True, null=True)
    device_family = models.CharField(max_length=200, blank=True, null=True)
    ### Operating System properties ###
    os_family = models.CharField(max_length=200, blank=True, null=True)
    os_version = models.CharField(max_length=200, blank=True, null=True)
    ##  browser attributes  ##
    browser_family = models.CharField(max_length=100, blank=True, null=True)
    browser_version = models.CharField(max_length=100, blank=True, null=True)
    ## other ##
    last_seen = models.DateTimeField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return str(self.id)


class Attendance(models.Model):
    Type_of_deviation = (('HD', 'half day'), ('FD', 'full day'),
                         ('MP', 'mispunch'), ('OD', 'Off duty'))
    # employee identification ######################
    organization = models.ForeignKey(
        Organization, related_name='attendance_organization', on_delete=models.CASCADE)
    employee = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='attendance_employee', on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=False, blank=True, null=True)
    # login timestamp with adddress and co-ordinates  ######################
    login_latitude = models.CharField(
        max_length=200, blank=True, null=True)
    login_longitude = models.CharField(
        max_length=200, blank=True, null=True)
    login_address = models.TextField(blank=True, null=True)
    
    logout_latitude = models.CharField(
        max_length=200, blank=True, null=True)
    logout_longitude = models.CharField(
        max_length=200, blank=True, null=True)
    logout_address = models.TextField(blank=True, null=True)
    # Update fields for login timestamp #########################
    initial_login_time = models.TimeField(blank=True, null=True)
    initial_logout_time = models.TimeField(blank=True, null=True)
    updated_login_time = models.TimeField(blank=True, null=True)
    updated_logout_time = models.TimeField(blank=True, null=True)
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='attendance_updated_by_employee', \
            on_delete=models.CASCADE, blank=True, null=True)
    # attendance status ##################
    is_present = models.BooleanField(default=False)
    is_fullday = models.BooleanField(default=False)
    deviation_type = models.CharField(
        max_length=2, choices=Type_of_deviation, blank=True, null=True)
    attendance_remarks = models.TextField(blank=True, null=True)
    # Other #######################
    late_in_reason = models.TextField(blank=True, null=True)
    early_out_reason = models.TextField(blank=True, null=True)
    is_late_in = models.BooleanField(default=False)
    is_early_out = models.BooleanField(default=False)
    ############################################
    total_work_duration_in_seconds = models.IntegerField(default=0, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return str(self.id)


class AttendenceDeviation(models.Model):
    """
    Attendence Deviation
    """
    Type_of_deviation = (('HD', 'half day'), ('FD', 'full day'),
                         ('MP', 'mispunch'), ('OD', 'Office duty'))
    attendence = models.ForeignKey(
        Attendance, related_name='attendances', on_delete=models.CASCADE)
    deviation_type = models.CharField(
        max_length=2, choices=Type_of_deviation, blank=True, null=True)
    start_time = models.TimeField(blank=True, null=True)
    end_time = models.TimeField(blank=True, null=True)
    justifications = models.TextField(blank=True, null=True)
    STATUS_CHOICES = [
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('R', 'Rejected')
    ]
    status = models.CharField(max_length=1, choices=STATUS_CHOICES)
    requested_on = models.DateTimeField(auto_now_add=True)
    approver = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='deviation_approver', on_delete=models.CASCADE, blank=True, null=True)
    total_work_duration_in_seconds = models.IntegerField(default=0, blank=True, null=True)
    leave_calc = models.FloatField(null=True, blank=True, default=0.0)

    def __str__(self):
        return str(self.attendence.employee.username) + " deviation type " + str(self.deviation_type)


    # def save(self, *args, **kwargs):
    #     from dateutil.relativedelta import relativedelta
    #     from datetime import datetime
        

    #     start_time = self.start_time.strftime("%H:%M:%S")
    #     end_time = self.end_time.strftime("%H:%M:%S")

    #     start_time_formatted = datetime.strptime(start_time, "%H:%M:%S")
    #     end_time_formatted = datetime.strptime(end_time, "%H:%M:%S")

    #     timedelta_obj = relativedelta(end_time_formatted, start_time_formatted)
    #     result = int(timedelta_obj.hours) * 3600 + int(timedelta_obj.minutes) * 60 + int(timedelta_obj.seconds)

    #     # m, second = divmod(result, 60)

    #     # hours, minutes = divmod(m, 60)

    #     self.total_work_duration_in_seconds = result

    #     final_result = self.attendence.total_work_duration_in_seconds + result

    #     self.attendence.update(total_work_duration_in_seconds=final_result)

    #     super(__class__, self).save(*args, **kwargs)


class AttendanceCarryForwardLeaveBalanceYearly(models.Model):
    year_start_date = models.DateTimeField(blank=True, null=True)
    year_end_date = models.DateTimeField(blank=True, null=True)
    employee = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='employee_leave_carry_forward',
                                   on_delete=models.CASCADE, blank=True, null=True)
    leave_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    is_deleted = models.BooleanField(default=False)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='att_leave_carry_forward_created_by',
                                   on_delete=models.CASCADE, blank=True, null=True)
    owned_by = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='att_leave_carry_forward_owned_by',
                                 on_delete=models.CASCADE, blank=True, null=True)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='att_leave_carry_forward_updated_by',
                                   on_delete=models.CASCADE, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return str(self.employee.username) + " start " + str(self.year_start_date) + " end " + str(self.year_end_date)
    


@receiver(post_delete, sender=AttendenceDeviation)
def time_change(sender, instance, **kwargs):
    attendence_details = Attendance.objects.filter(id=instance.attendence_id).first()
    attendence_details.total_work_duration_in_seconds = attendence_details.total_work_duration_in_seconds - instance.total_work_duration_in_seconds
    attendence_details.save()