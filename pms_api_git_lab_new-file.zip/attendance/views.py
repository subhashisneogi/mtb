import calendar
from django.shortcuts import render
import numpy as np
from dateutil import rrule
import pandas as pd
from rest_framework.views import APIView
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from knox.auth import TokenAuthentication
from rest_framework.response import Response
from datetime import date, timedelta, datetime
from dateutil.relativedelta import relativedelta
from rest_framework.exceptions import APIException
from django.db.models import Sum, Value, Case, When, FloatField
from django.db.models.functions import Coalesce

from administrations.utils import *
from attendance.models import *
from attendance.serializers import *
# Create your views here.



class HRMSMASTER(APIView):
    """
    HRMS MASTER LIST
    """
    
    

    def get(self, request, format=None):
        organization_id = self.request.query_params.get(
            'organization_id', None)
        
        master_details = HrmsMaster.objects.filter(organization_id=organization_id).values()

        return Response({'success': True, "result": master_details.values()},
                            status=status.HTTP_200_OK)
    
class GetMonthList(APIView):
    """
    Get List Of All Month in a Year
    """
    
    

    def get(self, request, format=None):
        organization_id = self.request.query_params.get(
            'organization_id', None)
        year = self.request.query_params.get('year', None)

        hr_master_details = HrmsMaster.objects.filter(
            organization_id=organization_id).first()
        
        current_date = date.today()

        print(current_date.year)


        financial_year_start_date = date(int(year), int(
            hr_master_details.financial_year_start_month), 1)
        financial_year_end_date = date(
            int(year) + 1, int(hr_master_details.financial_year_end_month), 31)

        result = []

        if hr_master_details.fortnite_type == 'single':
            for dt in rrule.rrule(rrule.MONTHLY, dtstart=financial_year_start_date, \
                                  until=current_date if int(year) == int(current_date.year) else financial_year_end_date):
                result_dict = {}
                dates_dict = get_fortnights_for_single(dt.year, dt.month, hr_master_details.first_fortnite_day,
                                                       financial_year_start_date, financial_year_end_date)
                result_dict['fortnight_start_date'] = dates_dict.get(
                    'first_fortnight_start', None)
                result_dict['fortnight_end_date'] = dates_dict.get(
                    'first_fortnight_end', None)
                result_dict['second_fortnight_start'] = ""
                result_dict['second_fortnight_end'] = ""
                result_dict['start_month'] = calendar.month_abbr[dates_dict.get(
                    'first_fortnight_start', None).month]
                result_dict['end_month'] = calendar.month_abbr[dates_dict.get(
                    'first_fortnight_end', None).month]
                result_dict['end_month_number'] = dates_dict.get(
                    'first_fortnight_end', None).month
                result_dict['start_month_number'] = dates_dict.get(
                    'first_fortnight_start', None).month
                result_dict['end_month_year'] = dates_dict.get(
                    'first_fortnight_end', None).year
                result_dict['start_month_year'] = dates_dict.get(
                    'first_fortnight_start', None).year

                current_date = date.today()
                if result_dict['fortnight_start_date'] <= current_date <= result_dict['fortnight_end_date']:
                    result_dict['current_fortnight'] = True
                else:
                    result_dict['current_fortnight'] = False

                result.append(result_dict)

            new_dict = {}
            new_dict['fortnight_start_date'] = date(financial_year_start_date.year, financial_year_start_date.month,
                                                    hr_master_details.first_fortnite_day)
            new_dict['fortnight_end_date'] = new_dict['fortnight_start_date'] + \
                timedelta(days=30 - 1)
            new_dict['second_fortnight_start'] = ""
            new_dict['second_fortnight_end'] = ""
            new_dict['start_month'] = calendar.month_abbr[financial_year_start_date.month]
            new_dict['end_month'] = calendar.month_abbr[financial_year_start_date.month + 1]
            new_dict['end_month_number'] = financial_year_start_date.month + 1
            new_dict['end_month_year'] = new_dict['fortnight_end_date'].year
            new_dict['start_month_number'] = financial_year_start_date.month
            new_dict['start_month_year'] = financial_year_start_date.year

            current_date = date.today()
            if new_dict['fortnight_start_date'] <= current_date <= new_dict['fortnight_end_date']:
                new_dict['current_fortnight'] = True
            else:
                new_dict['current_fortnight'] = False

            result.append(new_dict)

        else:
            for dt in rrule.rrule(rrule.MONTHLY, dtstart=financial_year_start_date, \
                                  until=current_date if int(year) == int(current_date.year) else financial_year_end_date):
                result_dict = {}
                dates_dict = get_fortnights_for_double(dt.year, dt.month, hr_master_details.first_fortnite_day,
                                                       hr_master_details.second_fortnite_end_day,
                                                       hr_master_details.fortnight_durations, financial_year_start_date, financial_year_end_date)
                
                print(dates_dict.get('second_fortnight_end', None))

                result_dict['fortnight_start_date'] = dates_dict.get(
                    'first_fortnight_start', None)
                result_dict['fortnight_end_date'] = dates_dict.get(
                    'first_fortnight_end', None)
                result_dict['second_fortnight_start'] = dates_dict.get(
                    'second_fortnight_start', None)
                result_dict['second_fortnight_end'] = dates_dict.get(
                    'second_fortnight_end', None)
                result_dict['start_month'] = calendar.month_abbr[dates_dict.get(
                    'first_fortnight_start', None).month]
                result_dict['end_month'] = calendar.month_abbr[dates_dict.get(
                    'first_fortnight_end', None).month]
                result_dict['end_month_number'] = dates_dict.get(
                    'first_fortnight_end', None).month
                result_dict['end_month_year'] = dates_dict.get(
                    'first_fortnight_end', None).year
                result_dict['start_month_number'] = dates_dict.get(
                    'first_fortnight_start', None).month
                result_dict['start_month_year'] = dates_dict.get(
                    'first_fortnight_start', None).year

                current_date = date.today()

                if result_dict['fortnight_start_date'] <= current_date <= result_dict['fortnight_end_date']:
                    result_dict['current_fortnight'] = True
                else:
                    result_dict['current_fortnight'] = False

                result.append(result_dict)

            new_dict = {}
            new_dict['fortnight_start_date'] = date(financial_year_start_date.year, financial_year_start_date.month,
                                                    hr_master_details.first_fortnite_day)
            new_dict['fortnight_end_date'] = new_dict['fortnight_start_date'] + \
                timedelta(days=hr_master_details.fortnight_durations - 1)
            new_dict['second_fortnight_start'] = new_dict['fortnight_end_date'] + \
                timedelta(days=1)
            new_dict['second_fortnight_end'] = new_dict['second_fortnight_start'] + \
                timedelta(days=15)
            new_dict['start_month'] = calendar.month_abbr[financial_year_start_date.month]
            new_dict['end_month'] = calendar.month_abbr[financial_year_start_date.month + 1]
            new_dict['end_month_number'] = financial_year_start_date.month + 1
            new_dict['end_month_year'] = new_dict['fortnight_end_date'].year
            new_dict['start_month_number'] = financial_year_start_date.month
            new_dict['start_month_year'] = financial_year_start_date.year

            current_date = date.today()
            if new_dict['fortnight_start_date'] <= current_date <= new_dict['second_fortnight_end']:
                new_dict['current_fortnight'] = True
            else:
                new_dict['current_fortnight'] = False

            result.append(new_dict)

        sorted_list = sorted(result, key=lambda x: (
            int(x['end_month_year']), int(x['end_month_number'])))

        if hr_master_details.fortnite_type == 'single':
            return Response({'success': True, "result": list({v['end_month_number']: v for v in sorted_list}.values())},
                            status=status.HTTP_200_OK)
        else:
            return Response({'success': True, "result": sorted_list},
                            status=status.HTTP_200_OK)


class AttendenceSummary(APIView):
    """
    Attendence Summary API View
    """
    
    

    def get(self, request, format=None):
        organization_id = self.request.query_params.get(
            'organization_id', None)
        year = self.request.query_params.get('year', None)
        start_date = self.request.query_params.get('start_date', None)
        end_date = self.request.query_params.get('end_date', None)

        hr_master_details = HrmsMaster.objects.filter(
            organization_id=organization_id).first()

        financial_year_start_date = date(int(year), int(
            hr_master_details.financial_year_start_month), 1)
        financial_year_end_date = date(
            int(year) + 1, int(hr_master_details.financial_year_end_month), 31)

        start_date_formatted = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_formatted = datetime.strptime(end_date, '%Y-%m-%d')

        result = []

        if hr_master_details.fortnite_type == 'single':
            if hr_master_details.saturday_off_type == 'even':
                start_days_sat = all_even_saturdays(
                    start_date_formatted.year, start_date_formatted.month)
                end_days_sat = all_even_saturdays(
                    end_date_formatted.year, end_date_formatted.month)
                sat_list = [start_days_sat.get('second_saturday', None), start_days_sat.get('fourth_saturday', None),
                            end_days_sat.get('second_saturday', None), end_days_sat.get('fourth_saturday', None)]

                no_of_days = np.busday_count(
                    start_date, end_date, weekmask='Mon Tue Wed Thu Fri Sat', holidays=sat_list)

            elif hr_master_details.saturday_off_type == 'odd':
                start_days_sat = all_odd_saturdays(
                    start_date_formatted.year, start_date_formatted.month)
                end_days_sat = all_odd_saturdays(
                    end_date_formatted.year, end_date_formatted.month)
                sat_list = [start_days_sat.get('first_saturday', None), start_days_sat.get('third_saturday', None),
                            start_days_sat.get('fifth_saturday', None), end_days_sat.get(
                                'first_saturday', None),
                            end_days_sat.get('third_saturday', None), end_days_sat.get('fifth_saturday', None)]

                no_of_days = np.busday_count(
                    start_date, end_date, weekmask='Mon Tue Wed Thu Fri Sat', holidays=sat_list)

            else:

                no_of_days = np.busday_count(
                    start_date, end_date, weekmask='Mon Tue Wed Thu Fri')

            total_time = hr_master_details.total_working_hours_allocation_per_employee * no_of_days
            hours = int(total_time)
            minutes = (total_time*60) % 60
            seconds = (total_time*3600) % 60

            attendence_sumation = Attendance.objects.filter(organization_id=organization_id, employee=request.user,
                                                            date__date__gte=start_date_formatted,
                                                            date__date__lte=end_date_formatted).aggregate(
                the_sum=Coalesce(Sum('total_work_duration_in_seconds'), Value(0)))['the_sum']

            minutes_completed, seconds_completed = divmod(
                attendence_sumation, 60)
            hours_completed, minutes_completed = divmod(minutes_completed, 60)

            result_one = int(hours) * 3600 + int(minutes) * 60 + int(seconds)
            result_two = int(hours_completed) * 3600 + \
                int(minutes_completed) * 60 + int(seconds_completed)

            if result_one == 0 or result_two > result_one:
                percentage = 100
            else:
                percentage = (result_two / result_one) * 100

            result_dict = {}
            result_dict['fortnight_start_date'] = start_date
            result_dict['fortnight_end_date'] = end_date
            result_dict['second_fortnight_start'] = ""
            result_dict['second_fortnight_end'] = ""
            result_dict['no_of_working_days'] = no_of_days
            result_dict['no_of_working_days_second'] = ""
            result_dict['total_time'] = str(
                hours) + " hours " + str(round(minutes, 0)) + " minute"
            result_dict['total_time_second'] = ""
            result_dict['total_time_completed'] = str(
                hours_completed) + " hours " + str(round(minutes_completed, 0)) + " minute"
            result_dict['total_time_completed_second'] = ""
            result_dict['completion_percentage'] = str(round(percentage, 2))
            result_dict['completion_percentage_second'] = ""
            result.append(result_dict)

        else:
            call_func = get_fortnight_for_double_datewise(
                start_date_formatted, end_date_formatted, hr_master_details.fortnight_durations)
            fortnight_start_date = call_func.get('first_fortnight_start', None)
            fortnight_end_date = call_func.get('first_fortnight_end', None)
            second_fortnight_start = call_func.get(
                'second_fortnight_start', None)
            second_fortnight_end = call_func.get('second_fortnight_end', None)

            fortnight_start_date_formatted = fortnight_start_date.strftime(
                '%Y-%m-%d')
            fortnight_end_date_formatted = fortnight_end_date.strftime(
                '%Y-%m-%d')
            second_fortnight_start_formatted = second_fortnight_start.strftime(
                '%Y-%m-%d')
            second_fortnight_end_formatted = second_fortnight_end.strftime(
                '%Y-%m-%d')

            if hr_master_details.saturday_off_type == 'even':
                ################ For First Fortnight ######################
                start_days_sat_for_first = all_even_saturdays(
                    fortnight_start_date.year, fortnight_start_date.month)
                end_days_sat_for_first = all_even_saturdays(
                    fortnight_end_date.year, fortnight_end_date.month)
                sat_list_first = [start_days_sat_for_first.get('second_saturday', None), start_days_sat_for_first.get('fourth_saturday', None),
                                  end_days_sat_for_first.get('second_saturday', None), end_days_sat_for_first.get('fourth_saturday', None)]

                no_of_days_first = np.busday_count(
                    fortnight_start_date_formatted, fortnight_end_date_formatted, weekmask='Mon Tue Wed Thu Fri Sat', holidays=sat_list_first)

                ################ For Second Fortnight ######################
                start_days_sat_for_second = all_even_saturdays(
                    second_fortnight_start.year, second_fortnight_start.month)
                end_days_sat_for_second = all_even_saturdays(
                    second_fortnight_end.year, second_fortnight_end.month)
                sat_list_second = [start_days_sat_for_second.get('second_saturday', None), start_days_sat_for_second.get('fourth_saturday', None),
                                   end_days_sat_for_second.get('second_saturday', None), end_days_sat_for_second.get('fourth_saturday', None)]

                no_of_days_second = np.busday_count(
                    second_fortnight_start_formatted, second_fortnight_end_formatted, weekmask='Mon Tue Wed Thu Fri Sat', holidays=sat_list_second)

            elif hr_master_details.saturday_off_type == 'odd':
                ################ For First Fortnight ######################
                start_days_sat_for_first = all_odd_saturdays(
                    fortnight_start_date.year, fortnight_start_date.month)
                end_days_sat_for_first = all_odd_saturdays(
                    fortnight_end_date.year, fortnight_end_date.month)
                sat_list_first = [start_days_sat_for_first.get('first_saturday', None), start_days_sat_for_first.get('third_saturday', None),
                                  start_days_sat_for_first.get(
                                      'fifth_saturday', None), end_days_sat_for_first.get('first_saturday', None),
                                  end_days_sat_for_first.get('third_saturday', None), end_days_sat_for_first.get('fifth_saturday', None)]

                no_of_days_first = np.busday_count(
                    fortnight_start_date_formatted, fortnight_end_date_formatted, weekmask='Mon Tue Wed Thu Fri Sat', holidays=sat_list_first)

                ################ For Second Fortnight ######################
                start_days_sat_for_second = all_odd_saturdays(
                    second_fortnight_start.year, second_fortnight_start.month)
                end_days_sat_for_second = all_odd_saturdays(
                    second_fortnight_end.year, second_fortnight_end.month)
                sat_list_second = [start_days_sat_for_second.get('first_saturday', None), start_days_sat_for_second.get('third_saturday', None),
                                   start_days_sat_for_second.get(
                                       'fifth_saturday', None), end_days_sat_for_second.get('first_saturday', None),
                                   end_days_sat_for_second.get('third_saturday', None), end_days_sat_for_second.get('fifth_saturday', None)]

                no_of_days_second = np.busday_count(
                    second_fortnight_start_formatted, second_fortnight_end_formatted, weekmask='Mon Tue Wed Thu Fri Sat', holidays=sat_list_second)

            else:
                no_of_days_first = np.busday_count(
                    fortnight_start_date_formatted, fortnight_end_date_formatted, weekmask='Mon Tue Wed Thu Fri')

                no_of_days_second = np.busday_count(
                    second_fortnight_start_formatted, second_fortnight_end_formatted, weekmask='Mon Tue Wed Thu Fri')

            ############################ For First Fortnight ##########################

            total_time_first = hr_master_details.total_working_hours_allocation_per_employee * no_of_days_first
            hours_first = int(total_time_first)
            minutes_first = (total_time_first*60) % 60
            seconds_first = (total_time_first*3600) % 60

            attendence_sumation_first = Attendance.objects.filter(organization_id=organization_id, employee=request.user,
                                                                  date__date__gte=fortnight_start_date,
                                                                  date__date__lte=fortnight_end_date).aggregate(
                the_sum=Coalesce(Sum('total_work_duration_in_seconds'), Value(0)))['the_sum']

            minutes_completed_first, seconds_completed_first = divmod(
                attendence_sumation_first, 60)
            hours_completed_first, minutes_completed_first = divmod(
                minutes_completed_first, 60)

            result_one_first = int(hours_first) * 3600 + \
                int(minutes_first) * 60 + int(seconds_first)
            result_two_first = int(hours_completed_first) * 3600 + int(
                minutes_completed_first) * 60 + int(seconds_completed_first)

            if result_one_first == 0 or result_two_first > result_one_first:
                percentage_first = 100
            else:
                percentage_first = (result_two_first / result_one_first) * 100

            ############################ For Second Fortnight ##########################

            total_time_second = hr_master_details.total_working_hours_allocation_per_employee * no_of_days_second
            hours_second = int(total_time_second)
            minutes_second = (total_time_second*60) % 60
            seconds_second = (total_time_second*3600) % 60

            attendence_sumation_second = Attendance.objects.filter(organization_id=organization_id, employee=request.user,
                                                                   date__date__gte=second_fortnight_start,
                                                                   date__date__lte=second_fortnight_end).aggregate(
                the_sum=Coalesce(Sum('total_work_duration_in_seconds'), Value(0)))['the_sum']

            minutes_completed_second, seconds_completed_second = divmod(
                attendence_sumation_second, 60)
            hours_completed_second, minutes_completed_second = divmod(
                minutes_completed_second, 60)

            result_one_second = int(hours_second) * 3600 + \
                int(minutes_second) * 60 + int(seconds_second)
            result_two_second = int(hours_completed_second) * 3600 + int(
                minutes_completed_second) * 60 + int(seconds_completed_second)

            if result_one_second == 0 or result_two_second > result_one_second:
                percentage_second = 100
            else:
                percentage_second = (result_two_second /
                                     result_one_second) * 100

            result_dict = {}
            result_dict['fortnight_start_date'] = fortnight_start_date
            result_dict['fortnight_end_date'] = fortnight_end_date
            result_dict['second_fortnight_start'] = second_fortnight_start
            result_dict['second_fortnight_end'] = second_fortnight_end
            result_dict['no_of_working_days'] = no_of_days_first
            result_dict['no_of_working_days_second'] = no_of_days_second
            result_dict['total_time'] = str(
                hours_first) + " hours " + str(round(minutes_first, 0)) + " minute"
            result_dict['total_time_second'] = str(
                hours_second) + " hours " + str(round(minutes_second, 0)) + " minute"
            result_dict['total_time_completed'] = str(
                hours_completed_first) + " hours " + str(round(minutes_completed_first, 0)) + " minute"
            result_dict['total_time_completed_second'] = str(
                hours_completed_second) + " hours " + str(round(minutes_completed_second, 0)) + " minute"
            result_dict['completion_percentage'] = str(
                round(percentage_first, 2))
            result_dict['completion_percentage_second'] = str(
                round(percentage_second, 2))
            result.append(result_dict)

        return Response({'success': True, "result": result},
                        status=status.HTTP_200_OK)


class EmployeeAttendenceSummary(APIView):
    """
    Employee Attendence Summary API View
    """
    
    

    def get(self, request, format=None):
        organization_id = self.request.query_params.get(
            'organization_id', None)
        start_date = self.request.query_params.get('start_date', None)
        end_date = self.request.query_params.get('end_date', None)

        start_date_formatted = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_formatted = datetime.strptime(end_date, '%Y-%m-%d')

        attendance_list = Attendance.objects.filter(organization_id=organization_id, employee=request.user,
                                                    date__date__gte=start_date_formatted, \
                                                        date__date__lte=end_date_formatted).order_by('date')

        serializer = AttendanceSerializer(attendance_list, many=True)

        return Response({'success': True, "result": serializer.data},
                        status=status.HTTP_200_OK)


class AttendenceDeviationApi(APIView):
    """
    Attendence Deviation API
    """
    
    

    def post(self, request, format=None):
        try:
            attendence_id = request.data.get('attendence_id', None)
            deviation_type = request.data.get('deviation_type', None)
            start_time = request.data.get('start_time', None)
            end_time = request.data.get('end_time', None)
            justifications = request.data.get('justifications', None)

            with transaction.atomic():
                start_time_formatted = datetime.strptime(
                    start_time, "%H:%M:%S")
                
                end_time_formatted = datetime.strptime(end_time, "%H:%M:%S")

                timedelta_obj = relativedelta(
                    end_time_formatted, start_time_formatted)
                
                result = int(timedelta_obj.hours) * 3600 + \
                    int(timedelta_obj.minutes) * 60 + \
                    int(timedelta_obj.seconds)

                if deviation_type == 'HD':
                    leave_calc = 0.5
                elif deviation_type == 'FD':
                    leave_calc = 1
                else:
                    leave_calc = 0

                created = AttendenceDeviation.objects.create(attendence_id=attendence_id, deviation_type=deviation_type,
                                                             start_time=start_time, end_time=end_time,
                                                             total_work_duration_in_seconds=result,
                                                             justifications=justifications, leave_calc=leave_calc)
                created.save()

                attendence_details = Attendance.objects.filter(
                    id=attendence_id).first()

                hr_master_details = HrmsMaster.objects.filter(
                    organization_id=attendence_details.organization_id).first()

                if deviation_type in ['MP', 'OD']:

                    # total_deviation = AttendenceDeviation.objects.filter(attendence_id=attendence_id,
                    #                                                      deviation_type__in=['MP', 'OD']).aggregate(
                    #     the_sum=Coalesce(Sum('total_work_duration_in_seconds'), Value(0)))['the_sum']

                    final_result = attendence_details.total_work_duration_in_seconds + result

                elif deviation_type == 'HD':
                    half_time = (
                        hr_master_details.total_working_hours_allocation_per_employee) / 2
                    hours_half = int(half_time)
                    minutes_half = (half_time*60) % 60
                    seconds_half = (half_time*3600) % 60

                    final_result = int(hours_half) * 3600 + \
                        int(minutes_half) * 60 + int(seconds_half)

                else:

                    total_time = hr_master_details.total_working_hours_allocation_per_employee
                    hours = int(total_time)
                    minutes = (total_time*60) % 60
                    seconds = (total_time*3600) % 60
                    final_result = int(hours) * 3600 + \
                        int(minutes) * 60 + int(seconds)

                Attendance.objects.filter(id=attendence_id).update(
                    total_work_duration_in_seconds=final_result)

                serializer_data = Attendance.objects.filter(
                    id=attendence_id).first()
                serializer = AttendanceSerializer(serializer_data)

            return Response({'results': {'Data': serializer.data},
                             'msg': 'Deviation Added Successfully',
                             'status': status.HTTP_201_CREATED,
                             "request_status": 1})
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class LeaveSummary(APIView):
    """
    Leave Summary API VIew
    """
    
    

    def get(self, request, format=None):
        from hrms_leave.models import EmployeeLeave

        organization_id = self.request.query_params.get(
            'organization_id', None)
        year = self.request.query_params.get('year', None)

        hr_master_details = HrmsMaster.objects.filter(
            organization_id=organization_id).first()

        financial_year_start_date = date(int(year), int(
            hr_master_details.financial_year_start_month), 1)
        financial_year_end_date = date(
            int(year) + 1, int(hr_master_details.financial_year_end_month), 31)

        final_dict = {}

        carry_forward_leave = AttendanceCarryForwardLeaveBalanceYearly.objects.filter(
            employee=request.user,
            is_deleted=False,
            year_start_date__date=financial_year_start_date,
            year_end_date__date=financial_year_end_date
        ).first()

        carry_forward_al = carry_forward_leave.leave_balance if carry_forward_leave else 0.0

        user_details = PmsUser.objects.filter(id=request.user.id).first()

        eligibility = 0

        if financial_year_start_date <= user_details.joining_date <= financial_year_end_date:
            eligibility = calculate_leave_pro_data_basis(organization_id, user_details.joining_date,
                                                         financial_year_end_date)
        else:
            eligibility = float(carry_forward_al) + \
                float(hr_master_details.total_leave_alocation)

        total_leaves_taken_till_date = AttendenceDeviation.objects.filter(attendence__date__date__gte=financial_year_start_date,
                                                                          attendence__date__date__lte=date.today(),
                                                                          status__in=['P', 'A']).aggregate(
            the_sum=Coalesce(Sum('leave_calc'), Value(0), output_field=FloatField()))['the_sum']

        leave_balance = float(carry_forward_al) + float(calculate_leave_balance_pro_data_basis(organization_id,
                                                                                               financial_year_start_date,
                                                                                               date.today()))

        final_leave_balance = float(leave_balance) - float(total_leaves_taken_till_date) \
            if float(total_leaves_taken_till_date) < float(leave_balance) else 0

        accumulation = float(final_leave_balance) + \
            float(total_leaves_taken_till_date)

        final_dict = {
            "carry_forward": carry_forward_al,
            "eligibility": eligibility,
            "consumption": total_leaves_taken_till_date,
            "leave_balance": final_leave_balance,
            "accumulation": accumulation,

        }

        return Response({'success': True, "result": final_dict},
                        status=status.HTTP_200_OK)


class GetFortnightAndFinancialYear(APIView):
    """
    Get Fortnight and Financial Year information for the current date
    """
    
    

    def get(self, request, format=None):
        current_date = timezone.now().date()

        hrms_master = HrmsMaster.objects.first()
        fortnight_start_day = hrms_master.first_fortnite_day
        fortnight_duration = hrms_master.fortnight_durations

        financial_year_start_month = hrms_master.financial_year_start_month
        financial_year_end_month = hrms_master.financial_year_end_month

        financial_year_start_date = date(
            current_date.year, financial_year_start_month, 1)
        financial_year_end_date = date(
            current_date.year + 1, financial_year_end_month, 31)

        fortnight_start_dates = list(rrule.rrule(
            rrule.DAILY,
            dtstart=financial_year_start_date.replace(day=fortnight_start_day),
            until=current_date,
            interval=fortnight_duration
        ))
        print(fortnight_start_dates)
        running_fortnight = len(fortnight_start_dates)
        response_data = {
            'fortnight_start_date': fortnight_start_dates[0] if fortnight_start_dates else None,
            'fortnight_end_date': fortnight_start_dates[1] if fortnight_start_dates else None,
            'start_month_financial_year': financial_year_start_date.year,
            'end_month_financial_year': financial_year_end_date.year,
            'second_fortnight_start': "",
            'second_fortnight_end': "",
        }

        if hrms_master.fortnite_type == 'double':
            second_fortnight_start_date = (
                fortnight_start_dates[0] +
                timedelta(days=fortnight_duration + 1)
            )
            second_fortnight_end_date = (
                second_fortnight_start_date +
                timedelta(days=fortnight_duration - 1)
            )
            response_data['second_fortnight_start'] = second_fortnight_start_date
            response_data['second_fortnight_end'] = second_fortnight_end_date

        return Response(response_data)



class EmployeeLeaveMonthlyWise(APIView):
    """
    Employee Leave Montly Wise For Graph in Dashboard
    """
    
    

    def get(self, request, format=None):
        from hrms_leave.models import EmployeeLeave

        organization_id = self.request.query_params.get(
            'organization_id', None)
        year = self.request.query_params.get('year', None)

        hr_master_details = HrmsMaster.objects.filter(
            organization_id=organization_id).first()

        financial_year_start_date = date(int(year), int(
            hr_master_details.financial_year_start_month), 1)
        
        financial_year_end_date = date(
            int(year) + 1, int(hr_master_details.financial_year_end_month), 31)
        
        date_list = []

        emp_date_list = []

        monthly_list = []
        
        employee_deviation_list = AttendenceDeviation.objects.select_related('attendence').filter(attendence__employee=request.user, \
                                                                     attendence__date__gte=financial_year_start_date,\
                                                                        attendence__date__lte=financial_year_end_date,\
                                                                            deviation_type='FD').order_by('attendence__date')
        
        employee_advance_leaves = EmployeeLeave.objects.filter(employee=request.user, \
                                                               leave_type__in=['AL', 'AB', 'MT', 'BT','CO']).order_by('start_date')
        
        for item in employee_deviation_list:
            result_dict = {}
            result_dict['date'] = item.attendence.date.strftime("%Y-%m-%d")
            date_list.append(result_dict)

        for obj in employee_advance_leaves:
            if hr_master_details.saturday_off_type == 'even':
                start_days_sat = all_even_saturdays(
                        obj.start_date.year, obj.start_date.month)
                end_days_sat = all_even_saturdays(
                        obj.end_date.year, obj.end_date.month)

                sat_list = [start_days_sat.get('second_saturday', None), start_days_sat.get('fourth_saturday', None),
                                    end_days_sat.get('second_saturday', None), end_days_sat.get('fourth_saturday', None)]
                
            elif hr_master_details.saturday_off_type == 'odd':
                start_days_sat_for_first = all_odd_saturdays(
                    obj.start_date.year, obj.start_date.month)
                end_days_sat_for_first = all_odd_saturdays(
                    obj.end_date.year, obj.end_date.month)

                sat_list = [start_days_sat_for_first.get('first_saturday', None), start_days_sat_for_first.get('third_saturday', None),
                                  start_days_sat_for_first.get(
                                      'fifth_saturday', None), end_days_sat_for_first.get('first_saturday', None),
                                  end_days_sat_for_first.get('third_saturday', None), end_days_sat_for_first.get('fifth_saturday', None)]
                
            
            date_list_panda = pd.bdate_range(obj.start_date.strftime("%Y/%m/%d"), obj.end_date.strftime("%Y/%m/%d"), \
                                       freq='C', weekmask= 'Mon Tue Wed Thu Fri Sat', \
                                        holidays=sat_list).strftime("%Y-%m-%d").tolist()
            
            print(date_list_panda)

            for jfk in date_list_panda:
                jfk_dict = {}
                jfk_dict['date'] = jfk
                emp_date_list.append(jfk_dict)

            
        print("******************************")
        print(emp_date_list)
            


        for etc in emp_date_list:
            new_result_dict = {}
            new_result_dict['date'] = etc.get('date', None)
            date_list.append(new_result_dict)

        for dt in rrule.rrule(rrule.MONTHLY, dtstart=financial_year_start_date, until=financial_year_end_date):
            sum = 0
            data_dict = {}
            for emv in date_list:
                en_date = datetime.strptime(emv.get('date', None), "%Y-%m-%d").date()
                if dt.month == en_date.month:
                    sum = sum + 1

            data_dict['month'] = calendar.month_abbr[dt.month]
            data_dict['sum'] = sum
            monthly_list.append(data_dict)
        
        return Response({'success': True, "result": monthly_list},
                        status=status.HTTP_200_OK)

        
