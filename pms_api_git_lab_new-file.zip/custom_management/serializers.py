from rest_framework import serializers
from django.db.models import F
from .models import *


from tender.models import *

import base64
import re


class FormMasterDependentDropdownChoisesSerializer(serializers.ModelSerializer):
    """
    Form Master Dependent Dropdown Choises Serializer
    """
    dependent_drowndown_values = serializers.SerializerMethodField()
    itemName = serializers.SerializerMethodField()


    def get_itemName(self,instance):
        if instance.id:
            return instance.name
        else:
            return ""


    def get_dependent_drowndown_values(self,instance):
        organization_id = self.context.get("organization_id", None)
        from administrations.utils import get_dependent_values_details
            
        return get_dependent_values_details(instance.query_name, organization_id, instance.option_id)

        
    class Meta:
        model = FormDependentChoices
        fields = '__all__'


class FormMasterSerializer(serializers.ModelSerializer):
    """ FormMaster Model Serializer"""
    dropdown_choices = serializers.SerializerMethodField()
    dependent_dropdown_choices = serializers.SerializerMethodField()
    # dependent_drowndown_values = serializers.SerializerMethodField()
    conditional_choises = serializers.SerializerMethodField()
    conditinal_on = serializers.SerializerMethodField()
    choise_counter = serializers.SerializerMethodField()
    formula_field = serializers.SerializerMethodField()
    all_formulas = serializers.SerializerMethodField()
    hidden_param = serializers.SerializerMethodField()
    form_input_type = serializers.SerializerMethodField()
    api_url = serializers.SerializerMethodField()
    api_payload = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()



    # def get_dependent_drowndown_values(self,instance):
    #     organization_id = self.context.get("organization_id", None)
    #     from administrations.utils import get_dependent_values
    #     if instance.form_input_type == 'condition' and instance.condition_input_type == 'dropdown':
    #         dependent_choise_details = FormDependentChoices.cmobjects.filter(form_id=instance.id).first()
    #         query_name = dependent_choise_details.query_name

    #         dependent_dropdown_list = list(FormDependentChoices.cmobjects.filter(\
    #                                     form_id=instance.id).values_list('option_id', flat=True))
            
    #         return get_dependent_values(query_name, organization_id, dependent_dropdown_list)
        
    #     elif instance.form_input_type == 'reference':
    #         dependent_choise_details = FormDependentChoices.cmobjects.filter(form_id=instance.id).first()
    #         query_name = dependent_choise_details.query_name

    #         dependent_dropdown_list = list(FormDependentChoices.cmobjects.filter(\
    #                                     form_id=instance.id).values_list('option_id', flat=True))
            
    #         return get_dependent_values(query_name, organization_id, dependent_dropdown_list)

    #     else:

    #         return []

    def get_country(self,instance):
        from adminpanel.models import Country
        if instance.country_id and instance.country_id != 0:
            country_details = Country.objects.filter(id=instance.country_id).values()
        else:
            country_details = []
        return country_details
    

    def get_api_url(self,instance):
        if instance.form_internal_name == 'employer':
            url = "employee_master_crud"
        else:
            url = ""
        return url
    
    def get_api_payload(self,instance):
        if instance.form_internal_name == 'employer':
            payload = {"organization", "employee_name"}
        else:
            payload = ""
        return payload

    def get_form_input_type(self,instance):
        if instance.form_input_type == 'condition':
            details = instance.condition_input_type
        else:
            details = instance.form_input_type
        return details


    def get_hidden_param(self,instance):
        if instance.form_input_type == 'condition':
            details = False
        else:
            details = True
        return details


    def get_all_formulas(self,instance):
        formula_list = []
        organization_id = self.context.get("organization_id", None)
        all_formulas = FormMaster.cmobjects.filter(formula_field__isnull=False,\
                                                 organization_id=organization_id).values(\
                                                    'formula_field','form_internal_name')
        for item in all_formulas:
            formula = base64.b64decode(item.get('formula_field', None)).decode('utf-8')
            f_list = re.findall(r'{{(.*?)\}}', formula)
            for obj in f_list:
                if obj.strip() == instance.form_internal_name:
                    formula_dict = {}
                    formula_dict['internal_name'] = item.get('form_internal_name', None)
                    formula_dict['formula'] = item.get('formula_field', None)
                    formula_list.append(formula_dict)

        return formula_list



    def get_dropdown_choices(self,instance):
        organization_id = self.context.get("organization_id", None)
        if instance.form_depended_id:
            details = TenderData.cmobjects.filter(\
                form_id=instance.form_depended_id, \
                    tender__organization_id=organization_id).annotate(itemName=F('value')).values('id','itemName')
        else:
            details = FormDropdownChoices.cmobjects.filter(\
                form_id=instance.id).annotate(itemName=F('option')).values()
        return details
    

    def get_conditional_choises(self,instance):
        details = FormConditionalField.cmobjects.filter(\
            form_id=instance.id).annotate(itemName=F('on_field')).values()
        return details
    
    def get_conditinal_on(self,instance):
        details = FormConditionalField.cmobjects.filter(\
            dependent_on_id=instance.id).annotate(itemName=F('on_field')).values()
        return details
    

    def get_dependent_dropdown_choices(self,instance):
        is_config = self.context.get("is_config", False)
        organization_id = self.context.get("organization_id", None)

        from user_profile.models import UsersGroup
        from administrations.utils import get_dependent_values_details
        if instance.form_type == "tender_executive_commitee" and is_config == False:
            group_ids = list(FormDependentChoices.cmobjects.filter(\
                                    form_id=instance.id).values_list("option_id", flat=True))
            user_ids = list(UsersGroup.objects.filter(group_id__in=group_ids).values_list("user_id", flat=True))

            details = []

            user_list = PmsUser.objects.filter(id__in=user_ids).order_by('id')

            for item in user_list:
                user_dict = {}
                user_dict['name'] = str(item.first_name) + " " + str(item.last_name)
                user_dict['itemName'] = str(item.first_name) + " " + str(item.last_name) + " - " + str(item.role.role_name)
                user_dict['id'] = item.id
                user_dict['query_name'] = "executive_commitee"
                user_dict['dependent_drowndown_values'] = get_dependent_values_details('pmsuser', organization_id, item.id)
                details.append(user_dict)
        else:
            dependent_data = FormDependentChoices.cmobjects.filter(\
                form_id=instance.id).annotate(itemName=F('name')).order_by('id')
            
            serializer = FormMasterDependentDropdownChoisesSerializer(dependent_data, \
                                                                      many=True, context = {"organization_id": organization_id})

            details = serializer.data
            
        return details


    def get_choise_counter(self,instance):
        if instance.id:
            details = FormDropdownChoices.cmobjects.filter(\
                form_id=instance.id).count()
            return details
        else:
            return None
        
    def get_formula_field(self, obj):
        if obj.formula_field:
            return obj.formula_field
        else:
            return None
    

    class Meta:
        model = FormMaster
        fields = '__all__'
    
class FormGroupMasterSerializer(serializers.ModelSerializer):
    """ FormMaster Model Serializer"""
    form_fields = serializers.SerializerMethodField()
    permissible_user_types = serializers.SerializerMethodField()
    is_active = serializers.SerializerMethodField() # Only Feasible for Mobile APp for Survey
    active_tracker = serializers.SerializerMethodField() # Only Feasible for Mobile APp for Survey

    def get_form_fields(self,instance):
        if instance.id:
            is_config = self.context.get("is_config", False)
            form_type = self.context.get("form_type", None)

            if form_type:
                details = FormMaster.cmobjects.filter(form_group_id=instance.id, form_type=form_type).order_by('sort_orders')
            else:
                details = FormMaster.cmobjects.filter(form_group_id=instance.id).order_by('sort_orders')

            if is_config == 'true':
                config = True
            else:
                config = False

            serializer = FormMasterSerializer(details, many=True, \
                                              context = {"organization_id": self.context.get("organization_id", None),\
                                                         "is_config": config})
            return serializer.data
        else:
            return None
        
    def get_permissible_user_types(self, instance):
        ps = []
        if instance.permissible_user_types:
            for item in instance.permissible_user_types.all():
                t_dict = {}
                t_dict['id'] = item.id
                t_dict['name'] = item.name
                ps.append(t_dict)
            return ps
        else:
            return []
        
    def get_is_active(self, instance):
        tender_id = self.context.get("tender_id", None)
        if tender_id:
            active_status = TenderSurveyFormGroupCompletion.cmobjects.filter(tender_id=tender_id, \
                                                                         form_group_id=instance.id).first()
        
            is_active = True if active_status and active_status.is_completed == True else False
        else:
            is_active = False
        
        return is_active
    
    def get_active_tracker(self, instance):
        tender_id = self.context.get("tender_id", None)
        ps = []
        if tender_id:
            active_status = TenderSurveyFormGroupCompletion.cmobjects.filter(tender_id=tender_id, \
                                                                         form_group_id=instance.id).first()
            if active_status:
                t_dict = {}
                t_dict['is_completed'] = active_status.is_completed
                t_dict['completion_date'] = active_status.completion_date
                user_details = PmsUser.objects.filter(id=active_status.completed_by_id).first()

                name = str(user_details.first_name) + " " + str(user_details.last_name) if user_details else ""
                t_dict['completed_by'] = name
                ps.append(t_dict)
                return ps
            else:
                return []
        else:
            return []

    class Meta:
        model = FormGroupMastr
        fields = '__all__'