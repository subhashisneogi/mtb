from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline

from .models import *
# Register your models here.


class FormDropdownChoicesAdmin(StackedInline):
	"""
	FormDropdownChoices Admin
	"""
	model = FormDropdownChoices
	fk_name = 'form'

class FormDependentChoicesAdmin(StackedInline):
	"""
	FormDependentChoices Admin
	"""
	model = FormDependentChoices
	fk_name = 'form'

class FormMasterAdmin(ModelAdmin):
	"""
	FormMaster Admin Model
	"""
	inlines = (FormDropdownChoicesAdmin, FormDependentChoicesAdmin,)

	model = FormMaster
	list_display = ['id', 'form_group', 'form_type', 'form_input_type', 'form_label', 'form_internal_name', 'form_category' ]
	search_fields = ['form_group__name', 'form_type',  ]


class FormDropdownChoicesAdmin(ModelAdmin):
	"""
	FormMaster Admin Model
	"""
	model = FormDropdownChoices
	list_display = ['id', 'form', 'option', 'option_category' ]
	search_fields = ['id', ]

class FormGrpMasterAdmin(ModelAdmin):
	filter_horizontal = ('permissible_user_types',)


admin.site.register(FormMaster, FormMasterAdmin)
admin.site.register(FormGroupMastr, FormGrpMasterAdmin)
admin.site.register(FormDropdownChoices, FormDropdownChoicesAdmin)
admin.site.register(FormConditionalField,ModelAdmin)

class FormDependentChoicesAdminNew(ModelAdmin):
	"""
	FormMaster Admin Model
	"""
	model = FormDependentChoices
	list_display = ['id', 'form', 'name','option_id', 'query_name' ]
	search_fields = ['id', ]

admin.site.register(FormDependentChoices,FormDependentChoicesAdminNew)




