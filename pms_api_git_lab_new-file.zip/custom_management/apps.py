from django.apps import AppConfig


class CustomManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'custom_management'
