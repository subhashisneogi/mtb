from django.urls import path
from custom_management import views
from django.views.decorators.cache import cache_page


urlpatterns = [
    # path('dynamic_form_group_crud/', views.FormGroupMasterAPIView.as_view()),
    path('dynamic_form_group_crud/',  cache_page(60 * 1)( views.FormGroupMasterAPIView.as_view() )),
    path('dynamic_form_group_crud_new/',  cache_page(60 * 1)( views.FormGroupMasterNewAPIView.as_view() )),
    path('dynamic_form_crud/', views.FormListAPIView.as_view()),

    path('form_data_counter_update/', views.FormSortOrderDisplay.as_view()),

    #path('form_depended_fileds/', views.DependedFormListAPIView.as_view()),

]