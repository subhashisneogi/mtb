from django.db import models

from administrations.models import Organization, BaseAbstractStructure, ModulePermissionsMaster

# Create your models here.




class FormGroupMastr(BaseAbstractStructure):
    """
        Form Group master Model
    """
    CATEGORY_CHOICES = [
        ("general", "General"),
        ("systemdefine", "System Defined"),
    ]
    VALUE_CHOISES = [
        ("NORMAL", "NORMAL"),
        ("TABULAR", "TABULAR"),
    ]
    GROUP_TYPE = [
        ("physical", "PHYSICAL"),
        ("material", "MATERIAL"),
        ("taxation", "TAXATION"),
        ("liaisoning", "LIAISONING"),
    ]
    organization = models.ForeignKey(Organization, related_name='form_group_organization',on_delete=models.CASCADE, blank=True, null=True)
    form_type = models.CharField(max_length=200)  # TODO NOTE: --- relation(many2one) with Form-Menu-Master/form_type_name, Form-Master/form_type ---
    name = models.CharField(max_length=200, unique=False)  # TODO : make unique=True after stable  'name' as 'slug'
    group_category = models.CharField(choices=CATEGORY_CHOICES, default="general", max_length=20)
    is_skipable = models.BooleanField(default=False)
    is_post = models.BooleanField(default=False)
    is_multiple = models.BooleanField(default=False)
    sort_orders = models.IntegerField(default=0)
    permissible_user_types = models.ManyToManyField(ModulePermissionsMaster)
    show_on_edit = models.BooleanField(default=False)
    value_type = models.CharField(choices=VALUE_CHOISES, default="NORMAL", max_length=20)
    group_type = models.CharField(choices=GROUP_TYPE, default="physical", max_length=20)
    is_hidden = models.BooleanField(default=False)
    deletion_status = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return self.name + ' form_type->[' + self.form_type + ']'


class FormMaster(BaseAbstractStructure):
    """
        Form Master Model
    """
    CATEGORY_CHOICES = [
        ("general", "General"),
        ("systemdefine", "System Defined"),
    ]
    organization = models.ForeignKey(Organization, related_name='form_organization',on_delete=models.CASCADE, blank=True, null=True)
    form_group = models.ForeignKey(FormGroupMastr, related_name='form_group_master', on_delete=models.CASCADE, blank=True, null=True)
    form_type = models.CharField(max_length=200)
    form_depended_id = models.IntegerField(blank=True, null=True)
    form_input_type = models.CharField(max_length=200)
    form_label = models.CharField(max_length=200)
    form_internal_name = models.CharField(max_length=200)
    form_description = models.TextField(blank=True, null=True)
    is_required = models.BooleanField(default=False)
    is_export = models.BooleanField(default=False)
    is_searchable = models.BooleanField(default=False)
    form_category = models.CharField(choices=CATEGORY_CHOICES, default="general", max_length=20)
    sort_orders = models.IntegerField(default=0)
    formula_field = models.TextField(blank=True, null=True)
    condition_input_type = models.CharField(max_length=255, blank=True, null=True)
    is_other = models.BooleanField(default=False)
    show_on_edit = models.BooleanField(default=False)
    is_disabled = models.BooleanField(default=False)
    is_hidden = models.BooleanField(default=False)
    maximum_character = models.IntegerField(default=200, blank=True, null=True)
    deletion_status = models.CharField(max_length=200, blank=True, null=True)
    on_key_avail = models.BooleanField(default=False)
    country_id = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return str(self.form_type)+" -> "+str(self.form_internal_name)
    


class FormDropdownChoices(BaseAbstractStructure):
    """
        Form DropDown Choices
    """
    CATEGORY_CHOICES = [
        ("general", "General"),
        ("systemdefine", "System Defined"),
    ]
    form = models.ForeignKey(FormMaster, related_name='form_masters',on_delete=models.CASCADE, blank=True, null=True)
    option = models.CharField(max_length=200, blank=True, null=True)
    option_category = models.CharField(choices=CATEGORY_CHOICES, default="general", max_length=20)

    def __str__(self):
        return self.option
    

class FormDependentChoices(BaseAbstractStructure):
    """
        Form Dependent Choices
    """
    form = models.ForeignKey(FormMaster, related_name='form_masters_dependent',on_delete=models.CASCADE, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    option_id = models.IntegerField(default=0)
    query_name = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.name
    

class FormConditionalField(BaseAbstractStructure):
    """
    Form Conditional Fields
    """
    form = models.ForeignKey(FormMaster, related_name='form_masters_conditional',on_delete=models.CASCADE, blank=True, null=True)
    dependent_on = models.ForeignKey(FormMaster, related_name='form_masters_parent_dependency',on_delete=models.CASCADE, blank=True, null=True)
    on_field = models.CharField(max_length=255, blank=True, null=True)
    option_id = models.IntegerField(default=0)


    def __str__(self):
        return self.on_field