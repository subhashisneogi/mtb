import ast
import base64
import json

from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from rest_framework.response import Response
from django.core.paginator import Paginator
from rest_framework import status
from django.db import transaction
from rest_framework.exceptions import APIException
from django.core.cache import cache
from django.db.models import Prefetch
from knox.auth import TokenAuthentication

from administrations.utils import timer_wrapper
from custom_management.models import *
from custom_management.serializers import *
import ast

from colorama import Fore, Back, Style
# Create your views here.


class FormGroupMasterAPIView(APIView):
    """
    CRUD API for organisation dynamic form model group master
    """
    
    

    

    @timer_wrapper(route_name='dynamic_form_group_crud  GET')
    def get(self, request, format=None):
        """
        Get a list of all dynamic forms group master
        """
        from user_permissions.models import UserWiseModulePermissions

        id = self.request.query_params.get('id', None)
        # print("FormGroupMasterAPIView  id->", id)

        organization_id = self.request.query_params.get('organization_id', None)
        is_config = self.request.query_params.get('is_config', None)
        tender_id = self.request.query_params.get('tender_id', None)  # Specifically For Survey Mobile APP For Group Completion Track
        form_type = self.request.query_params.get('form_type', None)
        # print(Back.GREEN, form_type, Style.RESET_ALL)
        fetch_type = self.request.query_params.get('fetch_type', None)

        user_permissions_module_ids = list(
            UserWiseModulePermissions.objects.filter(user=request.user, level_permission=True)
            .values_list('module_item_id', flat=True)
        )

        if id:
            form_details = FormGroupMastr.cmobjects.select_related('organization').filter(id=id).first()
            serializer = FormGroupMasterSerializer(form_details, context={
                "organization_id": organization_id,
                "form_type": form_type,
                "is_config": is_config,
                "tender_id": tender_id
            })
            return Response(serializer.data)

        form_group_ids = list(
            FormMaster.cmobjects.filter(organization_id=organization_id, form_type=form_type)
            .values_list('form_group_id', flat=True)
        )

        if not form_type == "tender_survey_details":
            frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                id__in=form_group_ids, organization_id=organization_id, form_type=form_type,
                permissible_user_types__in=user_permissions_module_ids
            ).distinct().order_by('sort_orders')
            # print("user_permissions_module_ids", user_permissions_module_ids)
            # print("frm_group_list", frm_group_list)
            if fetch_type == 'all':
                frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                    organization_id=organization_id, form_type=form_type,
                    permissible_user_types__in=user_permissions_module_ids
                ).distinct().order_by('sort_orders')
        else:
            user_permissions_module_name = list(
                UserWiseModulePermissions.objects.filter(user=request.user, level_permission=True)
                .values_list('module_item__unique_id', flat=True)
            )
            if tender_id:
                tender_data_form = TenderData.cmobjects.select_related('form').filter(
                    form__form_internal_name='select_members', tender_id=tender_id
                ).first()
                material_rate_data = TenderData.cmobjects.select_related('form').filter(
                    form__form_internal_name='select_members_material', tender_id=tender_id
                ).first()
                taxation_rate_data = TenderData.cmobjects.select_related('form').filter(
                    form__form_internal_name='select_members_taxation', tender_id=tender_id
                ).first()
                liason_rate_data = TenderData.cmobjects.select_related('form').filter(
                    form__form_internal_name='select_members_liason', tender_id=tender_id
                ).first()
                ##added new ids list to remove else condition in below code
                physical_user_ids = []
                material_user_ids = []
                taxation_user_ids = []
                liason_user_ids = []

                if tender_data_form:
                    form_ids = ast.literal_eval(tender_data_form.value)
                    physical_user_ids = list(
                        FormDependentChoices.cmobjects.select_related('form').filter(
                            id__in=form_ids, form__form_internal_name='select_members'
                        ).values_list('option_id', flat=True)
                    )

                if material_rate_data:
                    form_ids = ast.literal_eval(material_rate_data.value)
                    material_user_ids = list(
                        FormDependentChoices.cmobjects.select_related('form').filter(
                            id__in=form_ids, form__form_internal_name='select_members_material'
                        ).values_list('option_id', flat=True)
                    )

                if taxation_rate_data:
                    form_ids = ast.literal_eval(taxation_rate_data.value)
                    taxation_user_ids = list(
                        FormDependentChoices.cmobjects.select_related('form').filter(
                            id__in=form_ids, form__form_internal_name='select_members_taxation'
                        ).values_list('option_id', flat=True)
                    )

                if liason_rate_data:
                    form_ids = ast.literal_eval(liason_rate_data.value)
                    liason_user_ids = list(
                        FormDependentChoices.cmobjects.select_related('form').filter(
                            id__in=form_ids, form__form_internal_name='select_members_liason'
                        ).values_list('option_id', flat=True)
                    )

                if 'pre-tender-recommender' in user_permissions_module_name or \
                   'pre-tender-approver' in user_permissions_module_name:
                    frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                        id__in=form_group_ids, organization_id=organization_id, form_type=form_type
                    ).distinct().order_by('sort_orders')
                    if fetch_type == 'all':
                        frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                            organization_id=organization_id, form_type=form_type
                        ).distinct().order_by('sort_orders')
                elif request.user.id in physical_user_ids:
                    frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                        id__in=form_group_ids, organization_id=organization_id, form_type=form_type, group_type='physical'
                    ).distinct().order_by('sort_orders')
                    if fetch_type == 'all':
                        frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                            organization_id=organization_id, form_type=form_type, group_type='physical'
                        ).distinct().order_by('sort_orders')
                elif request.user.id in material_user_ids:
                    frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                        id__in=form_group_ids, organization_id=organization_id, form_type=form_type, group_type='material'
                    ).distinct().order_by('sort_orders')
                    if fetch_type == 'all':
                        frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                            organization_id=organization_id, form_type=form_type, group_type='material'
                        ).distinct().order_by('sort_orders')
                elif request.user.id in taxation_user_ids:
                    frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                        id__in=form_group_ids, organization_id=organization_id, form_type=form_type, group_type='taxation'
                    ).distinct().order_by('sort_orders')
                    if fetch_type == 'all':
                        frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                            organization_id=organization_id, form_type=form_type, group_type='taxation'
                        ).distinct().order_by('sort_orders')
                elif request.user.id in liason_user_ids:
                    frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                        id__in=form_group_ids, organization_id=organization_id, form_type=form_type, group_type='liaisoning'
                    ).distinct().order_by('sort_orders')
                    if fetch_type == 'all':
                        frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                            organization_id=organization_id, form_type=form_type, group_type='liaisoning'
                        ).distinct().order_by('sort_orders')
            else:
                frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                    id__in=form_group_ids, organization_id=organization_id, form_type=form_type
                ).distinct().order_by('sort_orders')
                if fetch_type == 'all':
                    frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                        organization_id=organization_id, form_type=form_type
                    ).distinct().order_by('sort_orders')

        # page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        # paginator = Paginator(frm_group_list, page_size)
        # page_number = self.request.query_params.get('page', 1)
        # page = paginator.get_page(page_number)
                    
        serializer = FormGroupMasterSerializer(
            frm_group_list, many=True,
            context={"organization_id": organization_id, 
                     "form_type": form_type, 
                     "is_config": is_config, 
                     "tender_id": tender_id}
        )

        return Response({
            'results': serializer.data,
        })



    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)
            form_type = request.data.get('form_type', None)
            name = request.data.get('name', None)
            is_skipable = request.data.get('is_skipable', None)
            is_multiple = request.data.get('is_multiple', False)
            value_type = request.data.get('value_type', "NORMAL")

            permissible_user_types = request.data.get('permissible_user_types', [])

            with transaction.atomic(): 
                
                if FormGroupMastr.objects.filter(organization_id=organization_id, form_type=form_type,\
                                                name=name.strip()).exists():
                    
                    return Response({'results': [],
                                    'msg': "Form Group Name Already Exists!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                
                from django.db.models import Max
                max_value = FormGroupMastr.objects.filter(organization_id=organization_id, \
                                                    form_type=form_type).aggregate(Max('sort_orders'))

                max_sort_order = max_value.get('sort_orders__max', 0)

                if max_sort_order != None:
                    if max_sort_order >= 0:
                        new_sort_order = int(max_sort_order) + 1
                    else:
                        new_sort_order = 0
                else:
                    new_sort_order = 0
                
                created = FormGroupMastr.objects.create(organization_id=organization_id, form_type = form_type, name=name, is_skipable=is_skipable, \
                                                        group_category='general', created_by=request.user, \
                                                            is_multiple=is_multiple, sort_orders=new_sort_order, value_type=value_type)
                
                for item in permissible_user_types:
                    module_item = ModulePermissionsMaster.objects.filter(id=item).first()
                    created.permissible_user_types.add(module_item)

                created.save()

                

                serializer = FormGroupMasterSerializer(created, context={
                    "organization_id": organization_id,
                    "form_type": form_type,
                    "is_config": False,
                    "tender_id": None})

                return Response({
                    'results': {'Data':serializer.data ,},
                    'msg': 'Form Created SuccessFully',
                    'status': status.HTTP_200_OK,
                    "request_status": 0})

        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)


        form_type = request.data.get('form_type', None)
        name = request.data.get('name', None)
        is_skipable = request.data.get('is_skipable', None)
        is_multiple = request.data.get('is_multiple', False)
        value_type = request.data.get('value_type', "NORMAL")

        permissible_user_types = request.data.get('permissible_user_types', [])

        with transaction.atomic():
            if method.lower() == 'edit':

                form_grp_details = FormGroupMastr.objects.get(pk=id)
                
                if FormGroupMastr.objects.filter(organization_id=organization_id, form_type=form_type,\
                                                name=name.strip()).exclude(name=form_grp_details.name.strip()).exists():
                    return Response({'results': [],
                                    'msg': "Form Group Name Already Exists!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                

                if form_grp_details.group_category == "systemdefine":

                    FormGroupMastr.objects.filter(id=id, organization_id=organization_id, form_type=form_type).update(name=name,\
                                            is_skipable=is_skipable, group_category='systemdefine', \
                                                updated_by=request.user, is_multiple=is_multiple, value_type=value_type)
                else:

                    FormGroupMastr.objects.filter(id=id, organization_id=organization_id, form_type=form_type).update(name=name,\
                                            is_skipable=is_skipable, group_category='general', \
                                                updated_by=request.user, is_multiple=is_multiple, value_type=value_type)


                form_details = FormGroupMastr.objects.filter(id=id).first()

                for item in form_details.permissible_user_types.all():
                    form_details.permissible_user_types.remove(item)
                    form_details.save()

                for obj in permissible_user_types:
                    module_item_add = ModulePermissionsMaster.objects.filter(id=obj).first()
                    form_details.permissible_user_types.add(module_item_add)
                    form_details.save()

                serializer = FormGroupMasterSerializer(form_details, context={
                    "organization_id": organization_id,
                    "form_type": form_type,
                    "is_config": False,
                    "tender_id": None})

                return Response({
                    'results': {'Data': serializer.data },
                    'msg': 'Form Group Updated SuccessFully',
                    'status': status.HTTP_200_OK,
                    "request_status": 0
                })
            
            elif method.lower() == 'delete':
                """
                Delete a Organisation role
                """
                if FormGroupMastr.objects.filter(id=id, organization_id=organization_id).exists():
                    form_details = FormGroupMastr.cmobjects.filter(id=id, organization=organization_id).first()
                    form_details.is_deleted = True
                    form_details.save()
                    
                    return Response({'results':{
                                        'form_details':FormGroupMastr.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Form Data Deleted Successfully',
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': 'Form Data Not Found',
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})


class FormListAPIView(APIView):
    """
    CRUD API for organisation dynamic form model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all dynamic forms
        """
        id = self.request.query_params.get('id', None)
        organization_id = self.request.query_params.get('organization_id', None)
        is_config = self.request.query_params.get('is_config', False)

        if is_config == 'true':
            config = True
        else:
            config = False


        if id:
            form_details = FormMaster.cmobjects.filter(id = id).first()
            serializer = FormMasterSerializer(form_details, context = {"organization_id": organization_id,\
                                                                       "is_config" : config})
            return Response(serializer.data)

        
        form_group_id = self.request.query_params.get('form_group_id', None)
        form_type = self.request.query_params.get('form_type', None)

        form_input_type = self.request.query_params.get('form_input_type', None)

        is_condition = self.request.query_params.get('is_condition', False)

        all_list = self.request.query_params.get('list', False)

        search_for = self.request.query_params.get('search_for', None)
        
        company_list = FormMaster.cmobjects.filter(organization_id = organization_id,\
                                                   form_group_id=form_group_id, form_type=form_type).order_by('-id')


        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(company_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        serializer = FormMasterSerializer(page, many=True, \
                                          context = {"organization_id": organization_id, "is_config" : config})
        
        if form_input_type == 'number':
            company_list = FormMaster.cmobjects.filter(organization_id = organization_id,\
                                                   form_group_id=form_group_id, \
                                                    form_type=form_type, form_input_type__in=['number', 'formulla']).order_by('-id')
            
            serializer = FormMasterSerializer(company_list, many=True, \
                                          context = {"organization_id": organization_id, "is_config" : config})
            
        if is_condition:
            company_list = FormMaster.cmobjects.filter(organization_id = organization_id,\
                                                   form_group_id=form_group_id, \
                                                    form_type=form_type, \
                                                        form_input_type__in=['dropdown', 'radio', 'multiselect']).order_by('-id')
            
            serializer = FormMasterSerializer(company_list, many=True, \
                                          context = {"organization_id": organization_id, "is_config" : config})
            
        if all_list == 'true' and search_for == 'tender':
            menu_type_list = list(FormMenuMaster.cmobjects.filter(\
                menu__form_type_name='tender').values_list('form_type_name', flat=True))
            
            form_group_ids = list(FormGroupMastr.cmobjects.filter(\
                form_type__in=menu_type_list).values_list('id', flat=True))
            
            company_list = FormMaster.cmobjects.filter(form_group_id__in=form_group_ids, \
                                                       is_export=True)
            
            serializer = FormMasterSerializer(company_list, many=True, \
                                          context = {"organization_id": organization_id, "is_config" : config})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    

    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)
            form_group_id = request.data.get('form_group', None)
            form_type = request.data.get('form_type', None)
            form_input_type = request.data.get('form_input_type', None)
            form_label = request.data.get('form_label', None)
            form_internal_name = request.data.get('form_internal_name', None)
            form_description = request.data.get('form_description', True)
            is_required = request.data.get('is_required', False)
            is_hidden = request.data.get('is_hidden', False)
            is_export = request.data.get('is_export', False)
            is_searchable = request.data.get('is_searchable', False)
            choise_list = request.data.get('choise_list', [])
            form_dependent_choise_list = request.data.get('form_dependent_choise_list', [])
            form_depended_id = request.data.get('form_depended_id', None)
            form_group_name = request.data.get('form_group_name', None)
            formula_field = request.data.get('formula_field', None)
            condition_input_type = request.data.get('condition_input_type', None)
            is_other = request.data.get('is_other', False)
            maximum_character = request.data.get('maximum_character', 200)
            country_id = request.data.get('country_id', 0)
            on_key_avail = request.data.get('on_key_avail', False)

            form_conditional_choise = request.data.get('form_conditional_choise', [])
            # if not formula_field:
            #     return Response({"error": "Please provide a base64 encoded data in 'formula' field."}, status=status.HTTP_400_BAD_REQUEST)

            # decode base64 data to string
            formula_decoded_data = base64.b64decode(formula_field).decode("utf-8")
            try:
                ast.parse(formula_decoded_data, mode='eval')

                with transaction.atomic(): 
                    # if FormMaster.objects.filter(organization_id=organization_id, form_type=form_type,\
                    #                              form_label=form_label.strip()).exists():
                    #     return Response({'results': [],
                    #                     'msg': "Form Label Already Exists!",
                    #                     "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                    import re
                    space_length = len(re.findall(r'\s', str(form_internal_name)))

                    if space_length != 0:
                        return Response({'results': [],
                                        'msg': "Invalid Form Internal Name! There Should Not Be any Spaces in Internal Name!",
                                        "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                    
                    if FormMaster.cmobjects.filter(organization_id=organization_id, form_group_id=form_group_id, form_type=form_type,\
                                                form_internal_name=form_internal_name.strip()).exists():
                        return Response({'results': [],
                                        'msg': "Form Internal Name Already Exists!",
                                        "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                    
                    if form_group_name:
                        group_create = FormGroupMastr.objects.create(organization_id=organization_id, form_type=form_type,\
                                                                    name=form_group_name)
                        group_create.save()

                        form_group_id = group_create.id

                    from django.db.models import Max
                    max_value = FormMaster.objects.filter(organization_id=organization_id, \
                                                        form_group_id=form_group_id, form_type=form_type).aggregate(Max('sort_orders'))

                    max_sort_order = max_value.get('sort_orders__max', 0)

                    print(max_sort_order)

                    if max_sort_order != None:
                        if max_sort_order >= 0:
                            new_sort_order = int(max_sort_order) + 1
                        else:
                            new_sort_order = 0
                    else:
                        new_sort_order = 0

                    # try: 
                    #     new_sort_order = int(max_sort_order) + 1
                    # except ValueError:
                    #     new_sort_order = 0
                    # else:
                    #     new_sort_order = 0
                    
                    created = FormMaster.objects.create(organization_id=organization_id, form_group_id = form_group_id,
                                                        form_type=form_type,form_input_type=form_input_type,
                                                        form_label=form_label, form_internal_name=form_internal_name,
                                                        form_description=form_description, is_export=is_export,
                                                        is_required=is_required, created_by=request.user,
                                                        form_depended_id=form_depended_id,form_category='general',
                                                        sort_orders=new_sort_order,formula_field=formula_field,
                                                        is_searchable=is_searchable, condition_input_type=condition_input_type,
                                                        is_other=is_other, maximum_character=maximum_character,country_id=country_id,
                                                        on_key_avail=on_key_avail)
                    created.save()

                    if choise_list:
                        for item in choise_list:
                            choise_create = FormDropdownChoices.objects.create(form=created, option=item,\
                                                                            created_by=request.user)
                            choise_create.save()


                    if form_dependent_choise_list:
                        for obj in form_dependent_choise_list:
                            dependent_choise_create = FormDependentChoices.objects.create(form=created, name=obj.get('name', None),\
                                                                                          option_id=obj.get('id', None),\
                                                                                            query_name=obj.get('query', None),\
                                                                                                created_by=request.user)
                            
                            dependent_choise_create.save()

                    if form_conditional_choise:
                        for dir in form_conditional_choise:
                            conditional_create = FormConditionalField.objects.create(form=created, dependent_on_id=dir.get('dependent_id', None),\
                                                                                     on_field=dir.get('on_field', None),\
                                                                                        option_id=dir.get('option_id', None))
                            
                            conditional_create.save()

                    serializer = FormMasterSerializer(created, context = {"organization_id": organization_id, "is_config" : False})

                    return Response({'results':{
                                            'Data':serializer.data ,
                                            },
                                            'msg': 'Form Created SuccessFully',
                                            'status':status.HTTP_200_OK,
                                            "request_status": 0})
            except SyntaxError :
                raise APIException({'request_status': 0, 'msg': "Please Provide a valid formula"})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        form_group_id = self.request.query_params.get('form_group_id', None)

        id = self.request.query_params.get('id', None)


    
        with (transaction.atomic()):
            if method.lower() == 'edit':

                form_type = request.data.get('form_type', None)
                form_input_type = request.data.get('form_input_type', None)
                form_label = request.data.get('form_label', None)
                form_internal_name = request.data.get('form_internal_name', None)
                form_description = request.data.get('form_description', True)
                is_export = request.data.get('is_export', False)
                is_required = request.data.get('is_required', False)
                is_hidden = request.data.get('is_hidden', False)
                is_searchable = request.data.get('is_searchable', False)
                choise_list = request.data.get('choise_list', [])
                form_dependent_choise_list = request.data.get('form_dependent_choise_list', [])
                form_depended_id = request.data.get('form_depended_id', None)
                form_group_name = request.data.get('form_group_name', None)
                formula_field = request.data.get('formula_field', None)
                condition_input_type = request.data.get('condition_input_type', None)
                is_other = request.data.get('is_other', False)
                maximum_character = request.data.get('maximum_character', 200)
                country_id = request.data.get('country_id', 0)
                on_key_avail = request.data.get('on_key_avail', False)

                form_conditional_choise = request.data.get('form_conditional_choise', [])

                # if FormMaster.objects.filter(organization_id=organization_id, form_type=form_type,\
                #                              form_label=form_label.strip()).exclude(form_label=form_label).exists():
                #     raise APIException("Form Label Already Exists!")
                formula_decoded_data = base64.b64decode(formula_field).decode("utf-8")
                print(Back.GREEN, "formula_decoded_data", formula_decoded_data, Style.RESET_ALL)
                try:
                    ast.parse(formula_decoded_data, mode='eval')
                except SyntaxError :
                    raise APIException({'request_status': 0, 'msg': "Please Provide a valid formula"})
                import re
                space_length = len(re.findall(r'\s', str(form_internal_name)))

                form_details = FormMaster.cmobjects.get(pk=id)


                if space_length != 0:
                    return Response({'results': [],
                                    'msg': "Invalid Form Internal Name! There Should Not Be any Spaces in Internal Name!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                
                if FormMaster.cmobjects.filter(organization_id=organization_id, form_group_id=form_group_id, form_type=form_type,\
                                            form_internal_name=form_internal_name.strip()).exclude(\
                                                form_internal_name=form_details.form_internal_name.strip()).exists():
                    return Response({'results': [],
                                    'msg': "Form Internal Name Already Exists!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                
                if form_group_name:
                    group_create = FormGroupMastr.objects.create(organization_id=organization_id, form_type=form_type,\
                                                                name=form_group_name)
                    group_create.save()

                    form_group_id = group_create.id
                
                rows_updated = FormMaster.objects.filter(id=id, organization_id=organization_id, form_type=form_type)
                rows_updated.update(form_label=form_label,\
                                    form_internal_name=form_internal_name, form_group_id=form_group_id,\
                                    form_description=form_description, is_export=is_export, is_required=is_required,\
                                    updated_by=request.user, form_input_type=form_input_type, \
                                    form_depended_id=form_depended_id,\
                                    formula_field=formula_field, is_searchable=is_searchable,\
                                    condition_input_type=condition_input_type, is_other=is_other,
                                    maximum_character=maximum_character, country_id = country_id,
                                    on_key_avail=on_key_avail, is_hidden=is_hidden
                                    )

                
                if choise_list:
                    if FormDropdownChoices.objects.filter(form_id=id, option_category='general').exists():
                        FormDropdownChoices.objects.filter(form_id=id, option_category='general').delete()

                    for item in choise_list:
                        if not FormDropdownChoices.objects.filter(form_id=id, option=item, option_category='systemdefine').exists():
                            choise_create = FormDropdownChoices.objects.create(form_id=id, option=item,\
                                                                            created_by=request.user, updated_by=request.user)
                            choise_create.save()

                if form_dependent_choise_list:
                    if FormDependentChoices.objects.filter(form_id=id).exists():
                        FormDependentChoices.objects.filter(form_id=id).delete()

                    for obj in form_dependent_choise_list:
                        dependent_choise_create = FormDependentChoices.objects.create(form_id=id, name=obj.get('name', None),\
                                                                                          option_id=obj.get('id', None),\
                                                                                            query_name=obj.get('query', None),\
                                                                                                created_by=request.user)
                            
                        dependent_choise_create.save()

                if form_conditional_choise:
                    if FormConditionalField.objects.filter(form_id=id).exists():
                        FormConditionalField.objects.filter(form_id=id).delete()


                    for dir in form_conditional_choise:
                        conditional_create = FormConditionalField.objects.create(form_id=id, dependent_on_id=dir.get('dependent_id', None),\
                                                                                    on_field=dir.get('on_field', None),\
                                                                                    option_id=dir.get('option_id', None))
                        
                        conditional_create.save()
                
                form_details = FormMaster.objects.filter(id=id).first()

                serializer = FormMasterSerializer(form_details, context = {"organization_id": organization_id,\
                                                                           "is_config" : False})

                return Response({'results':{
                                        'Data':serializer.data,
                                        },
                                        'msg': 'Form Updated SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})

            elif method.lower() == 'delete':
                """
                Delete a Organisation role
                """
                if FormMaster.objects.filter(id=id, organization_id=organization_id).exists():
                    form_details = FormMaster.cmobjects.filter(id=id, organization=organization_id).first()
                    form_details.is_deleted = True
                    form_details.save()
                    
                    return Response({'results':{
                                        'form_details':FormMaster.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Form Data Deleted Successfully',
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': 'Form Data Not Found',
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
                
            elif method.lower() == 'update':
                """
                Update an Organisation role
                """

                is_export = request.data.get('is_export', True)
                is_required = request.data.get('is_required', True)
                is_hidden = request.data.get('is_hidden', True)
                is_searchable = request.data.get('is_searchable', True)

                FormMaster.cmobjects.filter(id=id).update(is_export=is_export, \
                                                is_required=is_required, is_hidden=is_hidden, is_searchable=is_searchable,updated_by=request.user)
                    
                return Response({'results':{
                                        'form_details':FormMaster.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Form Data Updated Successfully',
                                        "request_status": 1})
            


class FormSortOrderDisplay(APIView):
    """
    API for Form Sort Order Display
    """
    
    

    def post(self, request, format=None):
        """
        Get a list of all dynamic forms and update their sort orders
        """
        form_fields = request.data.get('form_fields', [])

        with transaction.atomic():
            count = 0
            for item in form_fields:
                id = item.get('id', None)
                count = count + 1
                form_details = FormMaster.objects.filter(id=id).first()
                form_details.sort_orders = count
                form_details.save()

        return Response({'msg': 'Form Data Sorted Successfully',
                                        "request_status": 1})
    



class FormGroupMasterNewAPIView(APIView):
    """
    CRUD API for organisation dynamic form model group master
    """
    
    

    @timer_wrapper(route_name='dynamic_form_group_crud_new  GET')
    def get(self, request, format=None):
        """
        Get a list of all dynamic forms group master
        """
        from user_permissions.models import UserWiseModulePermissions
        from django.db.models import Prefetch

        id = self.request.query_params.get('id', None)
        organization_id = self.request.query_params.get('organization_id', None)
        is_config = self.request.query_params.get('is_config', None)
        tender_id = self.request.query_params.get('tender_id', None)
        form_type = self.request.query_params.get('form_type', None)
        fetch_type = self.request.query_params.get('fetch_type', None)

        user_permissions_module_ids = list(
            UserWiseModulePermissions.objects.filter(user=request.user, level_permission=True)
            .values_list('module_item_id', flat=True)
        )

        if id:
            form_details = FormGroupMastr.cmobjects.select_related('organization').filter(id=id).first()
            serializer = FormGroupMasterSerializer(form_details, context={
                "organization_id": organization_id,
                "form_type": form_type,
                "is_config": is_config,
                "tender_id": tender_id
            })
            return Response(serializer.data)

        form_group_ids = list(
            FormMaster.cmobjects.filter(organization_id=organization_id, form_type=form_type)
            .values_list('form_group_id', flat=True)
        )

        frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
            id__in=form_group_ids, organization_id=organization_id, form_type=form_type,
            permissible_user_types__in=user_permissions_module_ids
        ).distinct().order_by('sort_orders')

        if fetch_type == 'all':
            frm_group_list = FormGroupMastr.cmobjects.select_related('organization').filter(
                organization_id=organization_id, form_type=form_type,
                permissible_user_types__in=user_permissions_module_ids
            ).distinct().order_by('sort_orders')

        if form_type == "tender_survey_details":
            user_permissions_module_name = list(
                UserWiseModulePermissions.objects.filter(user=request.user, level_permission=True)
                .values_list('module_item__unique_id', flat=True)
            )

            if tender_id:
                tender_data_prefetch = Prefetch(
                    'formdependentchoices_set',
                    queryset=FormDependentChoices.cmobjects.select_related('form').filter(
                        form__form_internal_name__in=[
                            'select_members', 'select_members_material', 
                            'select_members_taxation', 'select_members_liason'
                        ]
                    ),
                    to_attr='dependent_choices'
                )

                tender_data = TenderData.cmobjects.select_related('form').prefetch_related(tender_data_prefetch).filter(
                    tender_id=tender_id,
                    form__form_internal_name__in=[
                        'select_members', 'select_members_material', 
                        'select_members_taxation', 'select_members_liason'
                    ]
                )

                physical_user_ids = []
                material_user_ids = []
                taxation_user_ids = []
                liason_user_ids = []

                for data in tender_data:
                    form_ids = ast.literal_eval(data.value)
                    for choice in data.dependent_choices:
                        if choice.form.form_internal_name == 'select_members':
                            physical_user_ids.extend(form_ids)
                        elif choice.form.form_internal_name == 'select_members_material':
                            material_user_ids.extend(form_ids)
                        elif choice.form.form_internal_name == 'select_members_taxation':
                            taxation_user_ids.extend(form_ids)
                        elif choice.form.form_internal_name == 'select_members_liason':
                            liason_user_ids.extend(form_ids)

                if 'pre-tender-recommender' in user_permissions_module_name or \
                   'pre-tender-approver' in user_permissions_module_name:
                    frm_group_list = frm_group_list.filter(
                        id__in=form_group_ids, organization_id=organization_id, form_type=form_type
                    )
                elif request.user.id in physical_user_ids:
                    frm_group_list = frm_group_list.filter(group_type='physical')
                elif request.user.id in material_user_ids:
                    frm_group_list = frm_group_list.filter(group_type='material')
                elif request.user.id in taxation_user_ids:
                    frm_group_list = frm_group_list.filter(group_type='taxation')
                elif request.user.id in liason_user_ids:
                    frm_group_list = frm_group_list.filter(group_type='liaisoning')

                if fetch_type == 'all':
                    frm_group_list = frm_group_list.filter(
                        organization_id=organization_id, form_type=form_type
                    )

        serializer = FormGroupMasterSerializer(
            frm_group_list, many=True,
            context={"organization_id": organization_id, 
                     "form_type": form_type, 
                     "is_config": is_config, 
                     "tender_id": tender_id}
        )

        return Response({
            'results': serializer.data,
        })



