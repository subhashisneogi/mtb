import base64
import uuid

from colorama import Back, Style
from django.core.files.base import ContentFile

from project_and_planning.models import PlanningAttachments
import mimetypes

def multiplexers ():
  
    return [lambda n1: index * n1 for index in range (4)]  
  
print([m1(5) for m1 in multiplexers()])



def process_attachments(file_data):
    mime_type = file_data.get('mime_type', '')
    file_content = file_data.get('file_data', '')
    try:
        attachment_content = base64.b64decode(file_content)
        file_name = f"{uuid.uuid4().hex}"
        file_extension = mimetypes.guess_extension(mime_type)
        file_extension = file_extension if file_extension else '.bin'
        file_name_with_extension = f"{file_name}{file_extension}"
        return ContentFile(attachment_content, name=file_name_with_extension)
    except Exception as e:
        print(f"Exception while adding new attachments: {str(e)}")
    return None


def save_attachment(model, attachments):
    """
    add data in PlanningAttachments
    """
    # print(Back.GREEN, model._meta.model.__name__, Style.RESET_ALL)
    model_name = model._meta.model.__name__
    if model_name == 'PlanningPeaconStatsSrtip':
        for attachment_data in attachments:
            planned_strip_id = model.pk

            order = attachment_data.get('order', None)
            mime_type = attachment_data.get('mime_type', None)

            print(planned_strip_id, model_name, order, mime_type,)
            '''
            if PlanningAttachments.cmobjects.filter(planned_strip_id=planned_strip_id, model_name=model_name, order=order).exists():
                _ = PlanningAttachments.cmobjects.filter(planned_strip_id=planned_strip_id, model_name=model_name, order=order)
                _.update(
                    mime_type=mime_type, attachment=process_attachments(attachment_data),
                    planned_strip_id=planned_strip_id, model_name=model_name, order=order
                )
                print("===")
            else:
                created = PlanningAttachments.cmobjects.create(
                    attachment=process_attachments(attachment_data),
                    planned_strip_id=planned_strip_id,
                    model_name=model_name,
                    order=order,
                    mime_type=mime_type
                )
                print("---")
            '''
            created = PlanningAttachments.cmobjects.create(
                attachment=process_attachments(attachment_data),
                planned_strip_id=planned_strip_id,
                model_name=model_name,
                order=order,
                mime_type=mime_type
            )
            print(created, 'PlanningPeaconStatsSrtip', 'file')

    elif model_name == 'ActualPeaconStatsStrip':
        for attachment_data in attachments:
            resolved_strip_id = model.pk

            order = attachment_data.get('order', None)
            mime_type = attachment_data.get('mime_type', None)

            print(resolved_strip_id, model_name, order, mime_type, )
            '''
            if PlanningAttachments.cmobjects.filter(resolved_strip_id=resolved_strip_id, model_name=model_name,
                                                    order=order).exists():
                _ = PlanningAttachments.cmobjects.filter(resolved_strip_id=resolved_strip_id, model_name=model_name,
                                                         order=order)
                _.update(
                    mime_type=mime_type, attachment=process_attachments(attachment_data),
                    resolved_strip_id=resolved_strip_id, model_name=model_name, order=order
                )
                print("^^^^^")
            else:
                created = PlanningAttachments.cmobjects.create(
                    attachment=process_attachments(attachment_data),
                    resolved_strip_id=resolved_strip_id,
                    model_name=model_name,
                    order=order,
                    mime_type=mime_type
                )
                print("++++++")
            '''
            created = PlanningAttachments.cmobjects.create(
                attachment=process_attachments(attachment_data),
                resolved_strip_id=resolved_strip_id,
                model_name=model_name,
                order=order,
                mime_type=mime_type
            )
            print(created, 'ActualPeaconStatsStrip', 'file')

    return True


def delete_attachments(model_name: str, pk: int):
    pass