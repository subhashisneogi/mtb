from colorama import Back, Style
import copy

from django.db.models import Q
from rest_framework import serializers

from django.db import transaction

from django.db.models import Value as V
from django.db.models.functions import Concat
from administrations.models import PmsUser

from tender.models import WbsAttribute, TenderData
from .models import *
from administrations.models import *
from custom_management.models import FormGroupMastr, FormDropdownChoices
from procurement.models import SiteMaster
from procurement.helper import process_attachments, get_tender_data_from_project2, get_project_data2,get_details_from_instance


def represents_int(s):
    try: 
        int(s)
    except ValueError:
        return False
    else:
        return True

class ProjectMasterNewSerializer(serializers.ModelSerializer):
    tender__tender_id = serializers.SerializerMethodField()
    tender__state = serializers.SerializerMethodField()
    tender__tender_organization = serializers.SerializerMethodField()
    planning_head_details = serializers.SerializerMethodField()
    project_head_details = serializers.SerializerMethodField()
    # users_details = serializers.SerializerMethodField()

    class Meta:
        model = ProjectMaster
        fields = '__all__'   
    def get_tender__tender_id(self, instance):
        return instance.tender.tender_id if instance.tender else None

    def get_tender__state(self, instance):
        return instance.tender.state.name if instance.tender and instance.tender.state else None

    def get_tender__tender_organization(self, instance):
        return instance.tender.tender_organization.employee_name if instance.tender and instance.tender.tender_organization else None

    def get_planning_head_details(self, instance):
        if instance.planning_head:
            full_name = f"{instance.planning_head.first_name} {instance.planning_head.last_name}".strip()
            return full_name
        return None

    def get_project_head_details(self, instance):
        if instance.project_head:
            full_name = f"{instance.project_head.first_name} {instance.project_head.last_name}".strip()
            return full_name
        return None
    # def get_users_details(self, instance):
    #     return get_details_from_instance(instance.users,extras=[], type="list")
    
    @transaction.atomic
    def create(self, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')
        users = validated_data.pop('users', [])
        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
        else:
            processed_attachment = None

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        project_entry = ProjectMaster.objects.create(**validated_data)
        if users:
            project_entry.users.set(users)
        if processed_attachment:
            project_entry.attachment = processed_attachment
        project_entry.save()

        return project_entry

    @transaction.atomic
    def update(self, instance, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')
        users = validated_data.pop('users', []) 
        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
            if processed_attachment:
                instance.attachment = processed_attachment

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        for field, value in validated_data.items():
            setattr(instance, field, value)
        if users:
            instance.users.set(users)
        instance.save()
        return instance

     
class ProjectDataSerializer(serializers.ModelSerializer):
    project_data = serializers.SerializerMethodField()
    corresponding_tender_id = serializers.SerializerMethodField()
    is_executive_commitee_member = serializers.SerializerMethodField()
    is_planning_active = serializers.SerializerMethodField()
    planning_head_details = serializers.SerializerMethodField()
    project_head_details = serializers.SerializerMethodField()
    is_jv = serializers.SerializerMethodField()
    is_risk_approval_user = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    # tender_data=serializers.SerializerMethodField()
    tender_state=serializers.SerializerMethodField()
    tender_employer=serializers.SerializerMethodField()

    # def get_tender_data(self, instance):
    #     data = {}
    #     if instance:
    #         data = get_tender_data_from_project2(instance.pk)
    #     return data
    def get_tender_state(self, instance):
        state_data = None
        if instance:
            _data = get_tender_data_from_project2(instance.pk, 'state_tender')
            try:
                state_data = State.objects.filter(pk=_data['state_tender']).values().first() if 'state_tender' in _data else None
            except ValueError as e:
                print("Error:", e)
        return state_data
    def get_tender_employer(self, instance):
        employer_data = None
        if instance:
            _data = get_tender_data_from_project2(instance.pk, 'employer')
            try:
                if 'employer' in _data:
                    # print(_data['employer'])
                  
                    # employer_data = (
                    #     PmsUser.objects.filter(id=_data['employer'])
                    #     .annotate(full_name=Concat('first_name', V(' '), 'last_name'))
                    #     .values('id', 'full_name')
                    #     .first()
                    # )
                    employer_data = (
                        EMPLOYEEMASTER.cmobjects.filter(id=_data['employer'])
                        .values('id', 'employee_name')
                        .first()
                    )
            except ValueError as e:
                print("Error:", e)

        return employer_data
    def get_site_details(self, instance):
        record = None
        if instance:
            record = SiteMaster.cmobjects.filter(project_id=instance.id).values()
        return record


    def get_is_risk_approval_user(self, obj):
        user_id = self.context.get("user_id", None) 
        if obj.planning_head and obj.planning_head.id == user_id and obj.is_planning_risk_approved_by_planning_head == False:
            return True
        elif obj.project_head and obj.project_head.id == user_id and obj.is_planning_risk_approved_by_planning_head == True:
            return True
        else:
            return False


    def get_is_jv(self, instance):
        from tender.models import TenderData
        from custom_management.models import FormDropdownChoices
        if instance.tender:
            # tender_data_details = TenderData.cmobjects.filter(tender_id=instance.tender_id,\
            #                                                   form__form_internal_name='participations_mode').first()
            
            # jv_details = FormDropdownChoices.cmobjects.filter(id=int(tender_data_details.value)).first()
            if instance.tender.tender_type == 'JV':
                return True
            else:
                return False
        else:
            return False


    def get_is_executive_commitee_member(self, instance):
        from tender.models import TenderExecutiveCommitee, TenderCommiteeMembers
        user_id = self.context.get("user_id", None)

        if instance.tender:
            ex_ids = list(TenderExecutiveCommitee.cmobjects.filter(tender_id=instance.tender_id).values_list('id', flat=True))
            user_ids = list(TenderCommiteeMembers.cmobjects.filter(ex_commitee_id__in=ex_ids).values_list('users_id', flat=True))
            if user_id in user_ids:
                return True
            else:
                return False
        else:
            return False
        
    def get_is_planning_active(self, instance):
        if instance.is_project_head_selected == True and \
            instance.is_planning_head_selected == True:
            return True
        else:
            return False
        
    def get_planning_head_details(self, instance):
        from django.db.models import Value as V
        from django.db.models.functions import Concat
        from administrations.models import PmsUser

        if instance.planning_head:
            user_details = PmsUser.objects.filter(id=instance.planning_head_id).annotate(\
                full_name=Concat('first_name', V(' '), 'last_name')).values('id', 'full_name')
        else:
            user_details = []

        return user_details
    

    def get_project_head_details(self, instance):
        from django.db.models import Value as V
        from django.db.models.functions import Concat
        from administrations.models import PmsUser

        if instance.project_head:
            user_details = PmsUser.objects.filter(id=instance.project_head_id).annotate(\
                full_name=Concat('first_name', V(' '), 'last_name')).values('id', 'full_name')
        else:
            user_details = []

        return user_details


    def get_corresponding_tender_id(self, instance):
        from tender.models import TenderData
        if instance.tender:
            # tender_data_details = TenderData.cmobjects.filter(tender=instance.tender, \
            #                                                   form__form_internal_name="tender_id").first()
            tender_id = instance.tender.id
        else:
            tender_id = ""

        return tender_id

    def get_project_data(self, instance):
        form_menu_type = self.context.get("form_menu_type", None)
        form_group_id = self.context.get("form_group_id", None)
        list_type = self.context.get("list_type", None)
        organization_id = self.context.get("organization_id", None)
        master_list = list(FormMenuMaster.objects.filter(is_display=True, menu_id=4).values_list('form_type_name', flat=True))

        group_list_ids = list(FormGroupMastr.cmobjects.filter(form_type__in=master_list).values_list('id', flat=True))

        form_types_without_display = list(FormMenuMaster.objects.filter(is_display=True, \
                                                                        menu__form_type_name__in=['planning', \
                                                                                                  'project']).values_list('form_type_name', flat=True))

        if list_type:
            if form_menu_type and form_group_id:
                form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id, \
                                                        organization_id=organization_id, \
                                                            form_type='project_details', is_export=True).order_by('form_group_id', \
                                                                                                                  'sort_orders')
            elif form_menu_type:
                group_ids = list(FormGroupMastr.cmobjects.filter(form_type=form_menu_type).values_list('id', flat=True))
                form_datas = FormMaster.cmobjects.filter(form_group_id__in=group_ids, \
                                                        organization_id=organization_id, \
                                                            form_type='project_details', is_export=True).order_by('form_group_id', \
                                                                                                    'sort_orders')
            elif form_group_id:
                form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id, \
                                                        organization_id=organization_id, \
                                                        form_type='project_details', is_export=True).order_by('form_group_id', \
                                                                                                'sort_orders')
            else:
                form_datas = FormMaster.cmobjects.filter(organization_id=organization_id, \
                                                        form_group_id__in=group_list_ids,\
                                                                form_type='project_details', is_export=True).order_by('form_group_id', \
                                                                                                        'sort_orders')
        else:
            if form_menu_type and form_group_id:
                form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id, \
                                                        organization_id=organization_id, \
                                                            form_type__in=form_types_without_display).order_by('form_group_id', \
                                                                                                                                                    'sort_orders')
            elif form_menu_type:
                group_ids = list(FormGroupMastr.cmobjects.filter(form_type=form_menu_type).values_list('id', flat=True))
                form_datas = FormMaster.cmobjects.filter(form_group_id__in=group_ids, \
                                                        organization_id=organization_id, \
                                                            form_type__in=form_types_without_display).order_by('form_group_id', \
                                                                                                    'sort_orders')
            elif form_group_id:
                form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id, \
                                                        organization_id=organization_id, \
                                                        form_type__in=form_types_without_display).order_by('form_group_id', \
                                                                                                'sort_orders')
            else:
                form_datas = FormMaster.cmobjects.filter(organization_id=organization_id, \
                                                        form_group_id__in=group_list_ids,\
                                                                form_type__in=form_types_without_display).order_by('form_group_id', \
                                                                                                        'sort_orders')

        project_datas = []
        for item in form_datas:
            if item.form_group.is_multiple == False:
                project_details = ProjectData.cmobjects.select_related('form').filter(form_id=item.id, \
                                                                                        project_id=instance.id).first()
                project_dict = dict()
                project_dict['id'] = project_details.id if project_details else ""
                project_dict['form_label'] = item.form_label
                if project_details:
                    if project_details.value and represents_int(project_details.value):
                        final_value = FormDropdownChoices.objects.filter(id=int(project_details.value),\
                                                                        form__form_type='project_details').first()
                        
                        if final_value and project_details.form.form_input_type == 'dropdown':
                            project_dict['value'] = final_value.option
                            project_dict['value_id'] = final_value.id
                        elif final_value and project_details.form.form_input_type == 'radio':
                            project_dict['value'] = final_value.option
                            project_dict['value_id'] = final_value.id
                        else:
                            project_dict['value'] = project_details.value
                            project_dict['value_id'] = ""
                    else:
                        project_dict['value'] = project_details.value
                        project_dict['value_id'] = ""
                else:
                    project_dict['value'] = ""
                    project_dict['value_id'] = ""
                project_dict['document'] = project_details.document.url if project_details and project_details.document else ""
                project_dict['internal_name'] = item.form_internal_name
                project_dict['form_group_id'] = item.form_group_id
                project_dict['is_multiple'] = False
                project_dict['by_order'] = project_details.by_order if project_details else ""
                project_datas.append(project_dict)

            else:
                project_details = ProjectData.cmobjects.select_related('form').filter(form_id=item.id, \
                                                project_id=instance.id).order_by('by_order')
                
                for obj in project_details:
                    project_dict = dict()
                    project_dict['id'] = obj.id if obj else ""
                    project_dict['form_label'] = item.form_label
                    if obj:
                        if obj.value and represents_int(obj.value):
                            final_value = FormDropdownChoices.objects.filter(id=int(obj.value),\
                                                                            form__form_type='project_details').first()
                            
                            if final_value and obj.form.form_input_type == 'dropdown':
                                project_dict['value'] = final_value.option
                                project_dict['value_id'] = final_value.id
                            elif final_value and obj.form.form_input_type == 'radio':
                                project_dict['value'] = final_value.option
                                project_dict['value_id'] = final_value.id
                            else:
                                project_dict['value'] = obj.value
                                project_dict['value_id'] = ""
                        else:
                            project_dict['value'] = obj.value
                            project_dict['value_id'] = ""
                    else:
                        project_dict['value'] = ""
                        project_dict['value_id'] = ""
                    project_dict['document'] = obj.document.url if obj and obj.document else ""
                    project_dict['internal_name'] = item.form_internal_name
                    project_dict['form_group_id'] = item.form_group_id
                    project_dict['is_multiple'] = True
                    project_dict['by_order'] = obj.by_order if obj else ""
                    project_datas.append(project_dict)

        return project_datas

    class Meta:
        model = ProjectMaster
        fields = '__all__'


class ProjectDataSerializer2(serializers.ModelSerializer):
    site_details = serializers.SerializerMethodField()
    is_risk_approval_user = serializers.SerializerMethodField()
    is_jv = serializers.SerializerMethodField()
    project_data = serializers.SerializerMethodField()
    tender_data = serializers.SerializerMethodField()
    project_value = serializers.SerializerMethodField()
    project_end_date = serializers.SerializerMethodField()
    project_start_date = serializers.SerializerMethodField()
    tender_state = serializers.SerializerMethodField()
    def get_site_details(self, instance):
        record = None
        if instance:
            record = SiteMaster.cmobjects.filter(project_id=instance.id).values().first()
        return record

    def get_is_risk_approval_user(self, instance):
        user_id = self.context.get("user_id", None)
        if instance.planning_head and instance.planning_head.id == user_id and instance.is_planning_risk_approved_by_planning_head == False:
            return True
        elif instance.project_head and instance.project_head.id == user_id and instance.is_planning_risk_approved_by_planning_head == True:
            return True
        else:
            return False

    def get_is_jv(self, instance):
        is_jv = False
        if instance.tender:
            # _data = get_tender_data_from_project2(instance.pk, 'participations_mode')
            # jv_details = FormDropdownChoices.cmobjects.filter(id=int(_data['participations_mode'])).first() if 'participations_mode' in _data else None
            # if jv_details.option == 'JV':
            if instance.tender.tender_type == 'JV':    
                is_jv = True
        return is_jv

    def get_project_data(self, instance):
        data = {}
        if instance:
            data = get_project_data2(instance.pk)
        return data
    def get_tender_data(self, instance):
        data = {}
        if instance:
            data = get_tender_data_from_project2(instance.pk)
        return data

    def get_project_value(self, instance):
        value = None
        if instance and instance.tender:
            _data = get_tender_data_from_project2(instance.pk, 'tender_project_cost__eligibility')
            value = _data['tender_project_cost__eligibility'] if 'tender_project_cost__eligibility' in _data else None
        return value

    def get_project_end_date(self, instance):
        datetime_object = None
        if instance:
            _data = get_project_data2(instance.pk, 'expected_end_date')
            try:
                datetime_object = datetime.strptime(_data['expected_end_date'], "%Y-%m-%d") if 'expected_end_date' in _data else None
            except ValueError as e:
                print("Error:", e)
        return datetime_object

    def get_project_start_date(self, instance):
        datetime_object = None
        if instance:
            _data = get_project_data2(instance.pk, 'project_start_date')
            try:
                datetime_object = datetime.strptime(_data['project_start_date'],"%Y-%m-%d") if 'project_start_date' in _data else None
            except ValueError as e:
                print("Error:", e)
        return datetime_object

    def get_tender_state(self, instance):
        state_data = None
        if instance:
            _data = get_tender_data_from_project2(instance.pk, 'state_tender')
            # print('_data',   _data)
            try:
                state_data = State.objects.filter(pk=_data['state_tender']).values().first() if 'state_tender' in _data else None
            except ValueError as e:
                print("Error:", e)
        return state_data



    class Meta:
        model = ProjectMaster
        fields = '__all__'


class PlanningExecutiveSummeryDataSerializer(serializers.ModelSerializer):
    wbs = serializers.SerializerMethodField()
    wbskey = serializers.SerializerMethodField()
    wbs_id = serializers.SerializerMethodField()
    wbs_key_id = serializers.SerializerMethodField()

    class Meta:
        model = PlanningExecutiveSummeryData
        fields = '__all__'

    def get_wbs(self, obj):
        if obj.wbs:
            return obj.wbs.wbs_name
        return None

    def get_wbskey(self, obj):
        if obj.wbskey:
            return obj.wbskey.keyscope
        return None
    
    def get_wbs_id(self, obj):
        if obj.wbs:
            return obj.wbs_id
        return None

    def get_wbs_key_id(self, obj):
        if obj.wbskey:
            return obj.wbskey_id
        return None


class PlanningRiskdetailsSerializer(serializers.ModelSerializer):
    risk_details_obj = serializers.SerializerMethodField()

    class Meta:
        model = PlanningRiskdetails
        fields = '__all__'

    def get_risk_details_obj(self, obj):
        if obj.id:
            details = PlanningRiskdetailsData.objects.filter(risk_details_id=obj.id).values()
            return details
        return []
    


class PlanningCommiteeApprovalMatrixSerializer(serializers.ModelSerializer):
    """
    PlanningCommiteeApprovalMatrix Serializers
    """
    status = serializers.SerializerMethodField()

    
    class Meta:
        model = PlanningCommiteeApprovalMatrix
        fields = '__all__'

    
    def get_status(self, obj):
        if obj.is_risk_approved == True:
            status = "Risk Matrix Approved"
        elif obj.is_risk_rejected == True:
            status = "Risk Matrix Rejected"
        else:
            status = "Waiting For Approval"
        return status
    



class PlanningRiskDiarySerializer(serializers.ModelSerializer):
    """ Planning Risk Diary Model Serializer"""
    class Meta:
        model = PlanningRiskDiary
        fields = '__all__'


class PlanningActivitySerializer(serializers.ModelSerializer):
    """ Planning Activity Model Serializer"""
    class Meta:
        model = PlanningActivity
        fields = '__all__'


class PlanningSectionSerializer(serializers.ModelSerializer):
    """ Planning Section Model Serializer"""
    class Meta:
        model = PlanningSection
        fields = '__all__'


######################################## Serializers For Peacon Strip Views #######################

from administrations.models import DelayBreakUps, DelayReasons


class PlanningPeaconStatsSrtipAttachmentsSerializer(serializers.ModelSerializer):
    """"
    Procurement Material Attachments Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PlanningPeaconStatsSrtipAttachments
        fields = '__all__'
        read_only_fields = ['id']


class PlanningPeaconStatsSrtipSerializer(serializers.ModelSerializer):
    """
    Planning Peacon Strip VIew For Color Representations Of Affected Areas
    """
    attachments = PlanningPeaconStatsSrtipAttachmentsSerializer(many=True, required=False, source='planning_peacon_stats_srtip_attachments_master')

    class Meta:
        model = PlanningPeaconStatsSrtip
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        details = None
        validated_data_list = []
        attachments = validated_data.pop('planning_peacon_stats_srtip_attachments_master')
        if validated_data['side'] == 'BHS':
            validated_data_lhs = copy.deepcopy(validated_data)
            validated_data_rhs = copy.deepcopy(validated_data)
            validated_data_lhs['side'] = 'LHS'
            validated_data_lhs['working_volume'] = float(validated_data['working_volume'])/2 if 'working_volume' in validated_data else 0
            validated_data_list.append(validated_data_lhs)
            validated_data_rhs['side'] = 'RHS'
            validated_data_rhs['working_volume'] = float(validated_data['working_volume'])/2 if 'working_volume' in validated_data else 0
            validated_data_list.append(validated_data_rhs)
        else:
            validated_data_list.append(validated_data)
        for validated_data_new in validated_data_list:
            details = PlanningPeaconStatsSrtip.objects.create(**validated_data_new)
            current_user = details.created_by if details.created_by else None

            for requested_attachment_data in attachments:
                try:
                    PlanningPeaconStatsSrtipAttachments.objects.create(
                        master=details,
                        attachment=process_attachments(requested_attachment_data),
                        file_data="",
                        mime_type="",
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")

            details.save()
        return details
    
    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])

        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('planning_peacon_stats_srtip_attachments_master', [])

        existing_attachments = instance.planning_peacon_stats_srtip_attachments_master.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = PlanningPeaconStatsSrtipAttachments.objects.create(
                        master=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="",
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data

        return representation



class ActualPeaconResultSerializer(serializers.ModelSerializer):
    """
    Planning Peacon Strip VIew For Color Representations Of Resolved Areas
    """
    class Meta:
        model = ActualPeaconStatsStrip
        fields = '__all__'



class DelayBreakUpsPeaconStripSerializer(serializers.ModelSerializer):
    """
    Delay BreakUps Strip VIew For Color Representations Of Affected Areas
    """
    peacon_strip = serializers.SerializerMethodField()
    affected_length = serializers.SerializerMethodField()
    resolved_length = serializers.SerializerMethodField()
    resolved_strip = serializers.SerializerMethodField()

    class Meta:
        model = DelayBreakUps
        fields = '__all__'

    def get_peacon_strip(self, obj):
        project_id = self.context.get("project_id", None)
        side = self.context.get("side", None)

        peacon_strip_list = PlanningPeaconStatsSrtip.cmobjects.filter(project_id=project_id,\
                                                                      delay_breakup_id=obj.id, side=side).order_by('id')
        serializer = PlanningPeaconStatsSrtipSerializer(peacon_strip_list, many=True)

        return serializer.data
    

    def get_resolved_strip(self, obj):
        project_id = self.context.get("project_id", None)
        side = self.context.get("side", None)

        peacon_strip_list = ActualPeaconStatsStrip.cmobjects.filter(project_id=project_id,\
                                                                      delay_breakup_id=obj.id, side=side).order_by('id')
        serializer = ActualPeaconResultSerializer(peacon_strip_list, many=True)

        return serializer.data
    
    def get_resolved_length(self, obj):
        from administrations.utils import generate_large_list
        from administrations.generator import generate_large_list_with_start_index
        
        project_id = self.context.get("project_id", None)
        chainage = self.context.get("chainage", None)
        side = self.context.get("side", None)

        # length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, \
        #                                              form__form_internal_name='length_of_the_project__in_kms_planning').first()
        # total_length = float(length_in_kms_query.value) * 1000 if length_in_kms_query else 0

        length_in_kms_query = ProjectMaster.cmobjects.filter(id=project_id,).first()
        total_length = float(length_in_kms_query.project_length) * 1000 if length_in_kms_query else 0


        peacon_strip_list = ActualPeaconStatsStrip.cmobjects.filter(project_id=project_id,\
                                                                      delay_breakup_id=obj.id, side=side) 
        
        chainage_list = []


        for item in peacon_strip_list:
            start_point = item.resolved_start_meter
            end_point = item.resolved_end_meter

            for itr in generate_large_list_with_start_index(int(start_point), int(end_point) + 1, int(1)):
                chainage_list.append(itr)

        result_dict = {}

        result = []

        if chainage_list:
            for ref in generate_large_list(int(total_length) + 1, int(chainage)):
                if ref in chainage_list:
                    result_dict[ref] = True
                # else:
                #     result_dict[ref] = False

                    result.append(result_dict)
            return result[0] if len(result) != 0 else []
        else:
            return []
    

    def get_affected_length(self, obj):
        from administrations.utils import generate_large_list
        from project_and_planning.chainage_utility import float_range
        
        project_id = self.context.get("project_id", None)
        chainage = self.context.get("chainage", None)
        side = self.context.get("side", None)

        # length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, \
        #                                              form__form_internal_name='length_of_the_project__in_kms_planning').first()
        # total_length = float(length_in_kms_query.value) * 1000 if length_in_kms_query else 0
        length_in_kms_query = ProjectMaster.cmobjects.filter(id=project_id,).first()
        total_length = float(length_in_kms_query.project_length) * 1000 if length_in_kms_query else 0

        # start_length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, \
        #                                              form__form_internal_name='project_start__in_kms_planning').first()
        
        # start_length = float(start_length_in_kms_query.value) * 1000 if start_length_in_kms_query else 0
        start_length_in_kms_query = ProjectMaster.cmobjects.filter(id=project_id,).first()
        start_length = float(start_length_in_kms_query.start_length_in_kms) * 1000 if start_length_in_kms_query else 0

        peacon_strip_list = PlanningPeaconStatsSrtip.cmobjects.filter(project_id=project_id,\
                                                                      delay_breakup_id=obj.id, side=side) 
        
        chainage_list = []


        for item in peacon_strip_list:
            start_point = item.affected_start_meter
            end_point = item.affected_end_meter

            for itr in float_range(start_point, end_point, int(1)):
                chainage_list.append(itr)

        result_dict = {}

        result = []

        if chainage_list:
            for ref in float_range(float(start_length) ,float(total_length) + 1, int(chainage)):
                if ref in chainage_list:
                    result_dict[round(float(ref) , 0)] = True
                # else:
                #     result_dict[ref] = False

                    result.append(result_dict)
            return result[0] if len(result) != 0 else []
        else:
            return []
    

class WbsAttributePeaconStripSerializer(serializers.ModelSerializer):
    """
    BreakUps Strip VIew For Color Representations Of Affected Areas

    """

    affected_length = serializers.SerializerMethodField()
    resolved_length = serializers.SerializerMethodField()
    peacon_strip = serializers.SerializerMethodField()
    resolved_strip = serializers.SerializerMethodField()
    files = serializers.SerializerMethodField()
    resolved_files = serializers.SerializerMethodField()

    class Meta:
        model = WbsAttribute  # DelayBreakUps
        fields = '__all__'

    def get_affected_length(self, instance):
        '''
        w i p
        '''
        from administrations.utils import generate_large_list
        from administrations.generator import generate_large_list_with_start_index
        from project_and_planning.chainage_utility import float_range

        print('affected_length:::::::::')
        try:
            project_id = self.context.get("project_id", None)
            chainage = self.context.get("chainage", None)
            side = self.context.get("side", None)

            # length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, form__form_internal_name='length_of_the_project__in_kms_planning').first()
            # # print('length_in_kms_query', length_in_kms_query)
            # total_length = float(length_in_kms_query.value) * 1000 if length_in_kms_query else 0
            length_in_kms_query = ProjectMaster.cmobjects.filter(id=project_id,).first()
            total_length = float(length_in_kms_query.project_length) * 1000 if length_in_kms_query else 0

            # print('total_length', total_length)
            # start_length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, form__form_internal_name='project_start__in_kms_planning').first()
            # print('start_length_in_kms_query', start_length_in_kms_query)
            # start_length = float(start_length_in_kms_query.value) * 1000 if start_length_in_kms_query else 0
            # print('start_length', start_length)
            start_length_in_kms_query = ProjectMaster.cmobjects.filter(id=project_id,).first()
            start_length = float(start_length_in_kms_query.start_length_in_kms) * 1000 if start_length_in_kms_query else 0

            peacon_strip_list = PlanningPeaconStatsSrtip.cmobjects.filter(project_id=project_id, wbs_attribute_id=instance.pk, side=side)

            chainage_list = []

            for item in peacon_strip_list:
                start_point = item.affected_start_meter
                end_point = item.affected_end_meter
                # print('start_point', start_point)
                # print(Back.GREEN, 'end_point', end_point, Style)

                # for itr in float_range(start_point, end_point, int(1)):
                #     chainage_list.append(itr)
                for itr in generate_large_list_with_start_index(int(start_point), int(end_point) + 1, int(1)):
                    chainage_list.append(itr)

            # result_dict = {}

            result = []

            if chainage_list:
                # for ref in float_range(float(start_length), float(total_length) + 1, int(chainage)):
                for ref in generate_large_list_with_start_index(int(start_length), int(total_length), int(chainage)):
                    # if ref in chainage_list:
                    #     result_dict[round(float(ref), 0)] = True
                    # else:
                    #     result_dict[ref] = False
                    if ref in chainage_list:
                        result.append(ref)

                    # result.append(result_dict)
                # return result[0] if len(result) != 0 else []
                return result
            else:
                return []
        except Exception as e:
            print("ERROR::::", e)

        return None
    def get_resolved_length(self, instance):
        '''
        W I P
        '''

        from administrations.utils import generate_large_list
        from administrations.generator import generate_large_list_with_start_index

        project_id = self.context.get("project_id", None)
        chainage = self.context.get("chainage", None)
        side = self.context.get("side", None)

        try:
            # length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, form__form_internal_name='length_of_the_project__in_kms_planning').first()
            # print('length_in_kms_query', length_in_kms_query)

            # total_length = float(length_in_kms_query.value) * 1000 if length_in_kms_query else 0
            length_in_kms_query = ProjectMaster.cmobjects.filter(id=project_id,).first()
            total_length = float(length_in_kms_query.project_length) * 1000 if length_in_kms_query else 0

            peacon_strip_list = ActualPeaconStatsStrip.cmobjects.filter(project_id=project_id, wbs_attribute_id=instance.pk, side=side)

            sum_total = 0
            result = {}
            for idx, item in enumerate(peacon_strip_list):
                start_point = item.resolved_start_meter
                end_point = item.resolved_end_meter
                print('start_point', start_point)
                print('end_point', end_point)
                result.update({
                    idx: {'start_point':start_point, 'end_point': end_point, 'total': int(end_point - start_point)}
                })
                sum_total += int(end_point - start_point)
            result.update({'sum_total': f'{sum_total:.2f}'})
            done_par = sum_total / total_length
            result.update({'done_par': f'{100*done_par:.2f}'})
            return result
        except Exception as e:
            print("ERR:::: ", e)

        return None


    def get_peacon_strip(self, obj):
        project_id = self.context.get("project_id", None)
        side = self.context.get("side", None)

        peacon_strip_list = PlanningPeaconStatsSrtip.cmobjects.filter(project_id=project_id, wbs_attribute_id=obj.pk, side=side).order_by('pk')
        if peacon_strip_list:
            serializer = PlanningPeaconStatsSrtipSerializer(peacon_strip_list, many=True)
            return serializer.data
        return []

    def get_files(self, instance):
        files = []
        if PlanningAttachments.cmobjects.filter(model_name='PlanningPeaconStatsSrtip',).exists():
            _files = PlanningAttachments.cmobjects.filter(model_name='PlanningPeaconStatsSrtip',).values()
            for f in _files:
                pk = f['planned_strip_id']
                obj = PlanningPeaconStatsSrtip.cmobjects.filter(pk=pk).first()
                if obj:
                    if obj.wbs_attribute_id == instance.pk:
                        files.append(f)
        return files

    def get_resolved_files(self, instance):
        files = []
        if PlanningAttachments.cmobjects.filter(model_name='ActualPeaconStatsStrip', ).exists():
            _files = PlanningAttachments.cmobjects.filter(model_name='ActualPeaconStatsStrip', ).values()
            for f in _files:
                pk = f['resolved_strip_id']
                obj = ActualPeaconStatsStrip.cmobjects.filter(pk=pk).first()
                if obj:
                    if obj.wbs_attribute_id == instance.pk:
                        files.append(f)
        return files

    def get_resolved_strip(self, instance):
        '''
            get data from ActualPeaconStatsStrip  as per project_id, wbs, side
        '''
        project_id = self.context.get("project_id", None)
        side = self.context.get("side", None)

        precon_strip_list = ActualPeaconStatsStrip.cmobjects.filter(project_id=project_id, wbs_attribute_id=instance.pk, side=side).order_by('id')
        if precon_strip_list:
            serializer = ActualPeaconResultSerializer(precon_strip_list, many=True)
            return serializer.data
        return []



# TODO : to be removed
class DelayReasonMasterPeaconStripSerializer(serializers.ModelSerializer):
    """
    Delay Reason Master Strip VIew For Color Representations Of Affected Areas
    """
    delay_breakups = serializers.SerializerMethodField()

    class Meta:
        model = DelayReasons
        fields = '__all__'

    def get_delay_breakups(self, obj):
        project_id = self.context.get("project_id", None)
        side = self.context.get("side", None)

        chainage = self.context.get("chainage", None)
        
        delay_breakup_list = DelayBreakUps.cmobjects.filter(delay_id=obj.id).order_by('id')

        serializer = DelayBreakUpsPeaconStripSerializer(delay_breakup_list, many=True, context = {'project_id' : project_id,\
                                                                                                  'side' : side, 'chainage' : chainage})

        return serializer.data


class TenderWBSPeaconStripSerializer(serializers.ModelSerializer):
    """
    TenderWBS Strip VIew For Color Representations Of Affected Areas
    """
    wbs_attribute = serializers.SerializerMethodField()
    breakups = serializers.SerializerMethodField()

    class Meta:
        model = TenderWBS
        fields = '__all__'

    def get_wbs_attribute(self, instance):
        _list = WbsAttribute.cmobjects.filter(pk=instance.id).values()
        if _list:
            return _list
        return [{'risk_type': None, 'color_code': '#0d6efd'}] # default values

    def get_breakups(self, obj):
        project_id = self.context.get("project_id", None)
        side = self.context.get("side", None)
        chainage = self.context.get("chainage", None)

        _breakup_list = WbsAttribute.cmobjects.filter(wbs=obj).order_by('pk')

        serializer = WbsAttributePeaconStripSerializer(_breakup_list, many=True, context={'project_id': project_id, 'side': side, 'chainage': chainage})

        return serializer.data



class MobilizationTrackerSerializer(serializers.ModelSerializer):
    # project_details = serializers.SerializerMethodField()
    # mobilization_master_details = serializers.SerializerMethodField()
    # mobilization_activity_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()

    def get_created_by_details(self, instance):
        _details = None
        if instance.created_by and instance.created_by_id:
            _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email').first()
        return _details

    class Meta:
        model = MobilizationTracker
        fields = '__all__'

    # def get_project_details(self, instance):
    #     if instance.project:
    #         return get_project_data2(instance.project.pk)
    #     return None

    # def get_mobilization_master_details(self, instance):
    #     mobilization_master = instance.mobilization_master
    #     if mobilization_master:
    #         return MobilizationMaster.cmobjects.filter(id=mobilization_master.pk).values(
    #             'id', 'sub_function', 'cross_functional_collaborative_activity'
    #         ).first()
    #     return None

    # def get_mobilization_activity_details(self, instance):
    #     mobilization_activity = instance.mobilization_activity
    #     if mobilization_activity:
    #         return MobilizationActivity.cmobjects.filter(id=mobilization_activity.pk).values(
              
    #         ).first()
    #     return None



class MobilizationActivityLogSerializer(serializers.ModelSerializer):
    """Mobilization Activity log model """
    created_by_details = serializers.SerializerMethodField()

    class Meta:
        model = MobilizationActivityLog
        fields = '__all__'
    def get_created_by_details(self, instance):
        _details = None
        if instance.created_by and instance.created_by_id:
            _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email').first()
        return _details



class MobilizationActivitySerializer(serializers.ModelSerializer):
    # organization_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    mobilization_master_details = serializers.SerializerMethodField()
    person_responsible_details = serializers.SerializerMethodField()
    tracker_list = serializers.SerializerMethodField()
    activity_log_list = serializers.SerializerMethodField()
    class Meta:
        model = MobilizationActivity
        fields = '__all__'

   
    def get_activity_log_list(self, instance):
        applicable_trackers = MobilizationActivityLog.cmobjects.filter(
            mobilization_activity=instance
        )
        return MobilizationActivityLogSerializer(applicable_trackers, many=True).data

   
    def get_tracker_list(self, instance):
        applicable_trackers = MobilizationTracker.cmobjects.filter(
            mobilization_activity=instance,
            mobilization_activity__applicable_for_project='applicable'
        )
        return MobilizationTrackerSerializer(applicable_trackers, many=True).data
    def get_project_details(self, instance):
        data = {}
        if instance.project:
            data = get_project_data2(instance.project.pk)
        return data

    def get_mobilization_master_details(self, instance):
        details=None
        mobilization_master = instance.mobilization_master
        if mobilization_master:
            details=MobilizationMaster.cmobjects.filter(id=mobilization_master.pk)\
                .values('id','sub_function','cross_functional_collaborative_activity').first()
        return details

    

    def get_person_responsible_details(self, instance):
        person_responsible = instance.person_responsible.all()
        return [{"id": user.id, "first_name": user.first_name,"last_name":user.last_name} for user in person_responsible] if person_responsible else None

  
class MobilizationMasterSerializer(serializers.ModelSerializer):
    activity = serializers.SerializerMethodField()

    class Meta:
        model = MobilizationMaster
        fields = '__all__'
        extra_fields = ['activity'] 

    def get_activity(self, obj):
        project_id = self.context.get('project_id', None)
        activity_query = MobilizationActivity.cmobjects.filter(mobilization_master=obj)
        if project_id:
            activity_query = activity_query.filter(project__id=project_id)

        first_activity = activity_query.first()
        return MobilizationActivitySerializer(first_activity).data if first_activity else None
    

class ProjectJVIncorporationSerializer(serializers.ModelSerializer):
    """ Serializer for ProjectJVIncorporation model """

    project_details = serializers.SerializerMethodField()

    def get_project_details(self, instance):
        return get_details_from_instance(instance.project, type="dict")

    class Meta:
        model = ProjectJVIncorporation
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        filedata = validated_data.pop('file_data', None)
        mime_type = validated_data.pop('mime_type', '')
        file_name = validated_data.pop('file_name', '')
        try:
            if not filedata:
                raise serializers.ValidationError({
                    "file_data": "This field is required to process the attachment."
                })
            attachment_content = process_attachments({
                'mime_type': mime_type,
                'file_data': filedata
            })
            # attachment_content.name = file_name
            instance = ProjectJVIncorporation.objects.create(
                attachment=attachment_content,
                file_name=file_name,
                **validated_data
            )
            return instance
        except serializers.ValidationError:
            raise
        except Exception as e:
            print(f"Unexpected exception: {e}")
            raise serializers.ValidationError(f"Failed to create record: {str(e)}")

    @transaction.atomic
    def update(self, instance, validated_data):
        file_data = validated_data.pop('file_data', None)
        mime_type = validated_data.pop('mime_type', '')
        file_name = validated_data.pop('file_name', '')
        try:
            if file_data:
                attachment_content = process_attachments({'mime_type': mime_type, 'file_data': file_data})
                # attachment_content.name = file_name
                instance.attachment = attachment_content

            for attr, value in validated_data.items():
                setattr(instance, attr, value)
                
            instance.save()
            return instance

        except Exception as e:
            raise serializers.ValidationError(f"Failed to update ProjectJVIncorporation: {str(e)}")