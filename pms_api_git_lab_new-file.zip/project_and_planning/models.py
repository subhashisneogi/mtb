from django.db import models

from administrations.models import BaseAbstractStructure, Organization,PmsUser
from custom_management.models import FormMaster
from tender.models import TenderMaster, TenderWBS, TenderWBSKeyScopes, WbsAttribute , TenderMasterNew

# Create your models here.
class ProjectMaster(BaseAbstractStructure):
    """
    Project Master Model
    """
    PROJECT_CLASSIFICATION_CHOICES = (
        ('Infra', 'Infra'),
        ('Non-Infra', 'Non-Infra'),
    )
    CURRENT_STAGE_CHOICES = (
        ('Under Execution', 'Under Execution'),
        ('Executed', 'Executed'),
    )
    organization = models.ForeignKey(Organization, related_name='organization_project_master',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey("tender.TenderMasterNew", related_name='project_tender',on_delete=models.CASCADE, null=True, blank=True)
    project_head = models.ForeignKey("administrations.PmsUser", related_name='project_heads',on_delete=models.CASCADE, null=True, blank=True)
    planning_head = models.ForeignKey("administrations.PmsUser", related_name='project_planning_heads',on_delete=models.CASCADE, null=True, blank=True)
    
    is_project_head_selected = models.BooleanField(default=False)
    is_planning_head_selected = models.BooleanField(default=False)

    #################### For Risk Approval Matrix in Planning ###########################

    is_planning_risk_approved_by_planning_head = models.BooleanField(default=False)
    is_planning_risk_approved_by_project_head = models.BooleanField(default=False)
    is_risk_matrix_rejected = models.BooleanField(default=False)
    hrms_project_id = models.IntegerField(default=0)
    hrms_project_site_id = models.IntegerField(default=0)
    hrms_tender_id = models.IntegerField(default=0)
    users = models.ManyToManyField("administrations.PmsUser", null=True, blank=True)
    sap_plant_id = models.CharField(max_length=300, blank=True, null=True)
    sap_auth_key = models.CharField(max_length=300, blank=True, null=True)
    extra=models.JSONField(blank=True,null=True)
    #### newly added fields############
    project_code = models.CharField(max_length=255, blank=True, null=True)   
    project_name = models.CharField(max_length=255, blank=True, null=True) 
    site_address = models.TextField(blank=True, null=True)                
    project_start_date = models.DateField(blank=True, null=True)          
    expected_end_date = models.DateField(blank=True, null=True)           
    current_stage = models.CharField(max_length=255, choices=CURRENT_STAGE_CHOICES, blank=True, null=True) 
    project_value = models.DecimalField(max_digits=20, decimal_places=2, blank=True, null=True)
    project_classification = models.CharField(max_length=255, choices=PROJECT_CLASSIFICATION_CHOICES, blank=True, null=True) 
    # project_company_name = models.CharField(max_length=255, blank=True, null=True)
    company = models.ForeignKey("administrations.Company", related_name='project_company', on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='project_and_planning/project_master', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)

    site_latitude = models.CharField(max_length=255, blank=True, null=True)
    site_longitude = models.CharField(max_length=255, blank=True, null=True)
    site_type = models.CharField(max_length=255, blank=True, null=True)
    office_latitude = models.CharField(max_length=255, blank=True, null=True)
    office_longitude = models.CharField(max_length=255, blank=True, null=True)
    gst_number = models.CharField(max_length=255, blank=True, null=True)
    guest_house_latitude = models.CharField(max_length=255, blank=True, null=True)
    guest_house_longitude = models.CharField(max_length=255, blank=True, null=True)
    site_latitude_longitude_details = models.CharField(max_length=255, blank=True, null=True)
    camp_area_latitude = models.CharField(max_length=255, blank=True, null=True)
    camp_area_longitude = models.CharField(max_length=255, blank=True, null=True)
    project_length = models.CharField(max_length=255, blank=True, null=True)
    start_length_in_kms = models.CharField(max_length=255, blank=True, null=True)

    production_start_date = models.DateField(blank=True, null=True) 

    def __str__(self):
        return f"{self.pk} | {self.project_code}"


class ProjectData(BaseAbstractStructure):

    project = models.ForeignKey(ProjectMaster, related_name='projects',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='project_data_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=300, blank=True, null=True) 
    document= models.FileField(
        upload_to='project/document', null=True, blank=True, help_text='documents')
    by_order = models.IntegerField(default=0)



class PlanningExecutiveSummeryData(BaseAbstractStructure):
    project = models.ForeignKey(ProjectMaster, related_name='ex_planning_project',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderMaster, related_name='ex_planning_tender_id',on_delete=models.CASCADE, null=True, blank=True)
    wbs = models.ForeignKey(TenderWBS, related_name='ex_planning_wbs_id',on_delete=models.CASCADE, null=True, blank=True)
    # wbskey = models.ForeignKey(TenderWBSKeyScopes,related_name='ex_planning_wbskey_id',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='ex_planning_data_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True) 






class PlanningRiskdetails(BaseAbstractStructure):
    """
    Risk Details Model
    """
    project = models.ForeignKey(ProjectMaster, related_name='risk_details_planning_project',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderMaster, related_name='risk_details_planning_tender_id',on_delete=models.CASCADE, null=True, blank=True)
     

class PlanningRiskdetailsData(BaseAbstractStructure):
    """
    Risk Details Data
    """
    risk_details = models.ForeignKey(PlanningRiskdetails, related_name='risk_details_planning',on_delete=models.CASCADE, blank=True, null=True)
    form = models.ForeignKey(FormMaster, related_name='risk_details_planning_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.TextField(blank=True, null=True, max_length=500)
    table_id = models.CharField(max_length=200, blank=True, null=True)



class PlanningComplianceDerivative(BaseAbstractStructure):
    """
    Planning COmpliance Derivative
    """
    project = models.ForeignKey(ProjectMaster, related_name='compliance_planning_project',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderMaster, related_name='compliance_planning_tender_id',on_delete=models.CASCADE, null=True, blank=True)



class PlanningCompliancesData(BaseAbstractStructure):
    """
    Planning Compliances Data
    """
    compliances = models.ForeignKey(PlanningComplianceDerivative, related_name='planning_compliances',on_delete=models.CASCADE, blank=True, null=True)
    form = models.ForeignKey(FormMaster, related_name='planning_compliance_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)
    table_id = models.CharField(max_length=200, blank=True, null=True)


class PlanningCommiteeApprovalMatrix(BaseAbstractStructure):
    """
    Planning Commitee Approval Matrix API
    """
    OPTION_TYPE = (
        ('Agree', 'Agree'),
        ('Need Further Clarification', 'Need Further Clarification'),
        ('Hold', 'Hold'),
        ('Pending', 'Pending'),
    )
    project = models.ForeignKey(ProjectMaster, related_name='project_commitee',on_delete=models.CASCADE, null=True, blank=True)
    users = models.ForeignKey('administrations.PmsUser', related_name='project_approval_users',on_delete=models.CASCADE, null=True, blank=True)

    is_risk_approved = models.BooleanField(default=False)
    is_risk_rejected = models.BooleanField(default=False)

    options = models.CharField(max_length=150,choices=OPTION_TYPE, blank=True, null=True)

    risk_remarks = models.TextField(blank=True, null=True)





class PlanningRiskDiary(BaseAbstractStructure):
    """
    Planning Risk Diary (For Specific Project)
    """
    SIDE_TYPE = (
        ('LHS', 'LHS'),
        ('RHS', 'RHS'),
        ('BHS', 'BHS'),
    )

    project = models.ForeignKey(ProjectMaster, related_name='project_risk_diary',on_delete=models.CASCADE, null=True, blank=True)
    delay_reason = models.ForeignKey('administrations.DelayReasons', related_name='project_risk_delay_reasons',on_delete=models.CASCADE, null=True, blank=True)
    details_of_risks = models.TextField(blank=True, null=True)
    mitigation_plan = models.CharField(max_length=255, blank=True, null=True)
    responsible_manager = models.CharField(max_length=200, blank=True, null=True)
    side = models.CharField(max_length=15,choices=SIDE_TYPE, blank=True, null=True)
    wtd_risk = models.FloatField(null=True, blank=True, default=0.0)
    type_r = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(blank=True, null=True)


    ######################## Length Affected (Ch.) ################

    length_affected_from = models.FloatField(null=True, blank=True, default=0.0)
    length_affected_to = models.FloatField(null=True, blank=True, default=0.0)
    length_rm = models.FloatField(null=True, blank=True, default=0.0)

    ######################## Impact in Scope(rs) ###################

    project_length_affected_in_percentage = models.FloatField(null=True, blank=True, default=0.0)
    scope_affected = models.FloatField(null=True, blank=True, default=0.0)
    scope_affected_in_percentage = models.FloatField(null=True, blank=True, default=0.0)

    ######################## Time Impact till the Mitigations (rt) ###################

    mitigation_expected_by = models.DateField(blank=True, null=True)
    mitigation_from = models.DateField(blank=True, null=True)
    mitigation_to = models.DateField(blank=True, null=True)
    likely_days_affected = models.IntegerField(default=0, blank=True, null=True)
    contract_durations_in_percentage = models.FloatField(null=True, blank=True, default=0.0)

    ######################## Effect in Budget(rc) ###################

    value_of_direct_impact_wrt_revenue_or_sales = models.FloatField(null=True, blank=True, default=0.0)
    estimated_indirect_expenses = models.FloatField(null=True, blank=True, default=0.0)
    contigency = models.FloatField(null=True, blank=True, default=0.0)
    gross_impact = models.FloatField(null=True, blank=True, default=0.0)
    contract_price_in_percentage = models.FloatField(null=True, blank=True, default=0.0)



################################################ Planning Affected Areas Model Database for Strip View #####################


class ChainageBreakupValue(BaseAbstractStructure):
    """
    Chainage Breakup Value Based on Project
    """
    project = models.ForeignKey(ProjectMaster, related_name='project_chainage_breakup',on_delete=models.CASCADE, null=True, blank=True)
    value = models.IntegerField(default=0)

    def __str__(self):
        return str(self.project.id) + " - " + str(self.value) 


class PlanningActivity(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='planning_activity_organization', on_delete=models.CASCADE)
    type = models.CharField(max_length=200, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)
    max_layer = models.IntegerField(default=0, blank=True, null=True)
    color_code = models.CharField(max_length=50, blank=True, null=True, default='#0d6efd')

    class Meta:
        db_table = "planning_activity"


class PlanningSection(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='planning_section_organization', on_delete=models.CASCADE)
    type = models.CharField(max_length=200, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = "planning_section"

class PlanningPeaconStatsSrtip(BaseAbstractStructure):
    """"
    Planning Peacon Stats Strips Based On SIde (LHS/RHS/BHS)
    """
    SIDE_TYPE = (
        ('LHS', 'LHS'),
        ('RHS', 'RHS'),
        ('BHS', 'BHS'),
    )
    project = models.ForeignKey(ProjectMaster, related_name='project_planning_peacon',on_delete=models.CASCADE, null=True, blank=True)
    delay_breakup = models.ForeignKey('administrations.DelayBreakUps', related_name='project_risk_delay_breakups',on_delete=models.CASCADE, null=True, blank=True)  # TODO: unlink after stable
    ########
    wbs_attribute = models.ForeignKey(WbsAttribute, related_name='planningpeaconstatsrtip_wbs',on_delete=models.CASCADE, null=True, blank=True)
    affected_start_meter = models.FloatField(blank=True, null=True)
    affected_end_meter = models.FloatField(blank=True, null=True)
    side = models.CharField(max_length=15,choices=SIDE_TYPE, blank=True, null=True)
    category = models.CharField(max_length=200, null=True, blank=True)

    # Date planned
    date_planned = models.DateField(blank=True, null=True)
    criteria_planned = models.TextField(blank=True, null=True)
    boq_type = models.BooleanField(default=False)
    boq_code = models.ForeignKey('boq.WBSList', related_name='planningpeaconstatsrtip_boq_code',on_delete=models.CASCADE, null=True, blank=True)
    boq_code_text = models.CharField(max_length=200, blank=True, null=True)
    activity = models.ForeignKey(PlanningActivity, related_name='planningpeaconstatsrtip_activity',on_delete=models.CASCADE, null=True, blank=True)
    activity_text = models.CharField(max_length=200, blank=True, null=True)
    section = models.ForeignKey(PlanningSection, related_name='planningpeaconstatsrtip_section',on_delete=models.CASCADE, null=True, blank=True)
    uom = models.ForeignKey('material_master.UnitOfMesurement', related_name='planningpeaconstatsrtip_uom',on_delete=models.CASCADE, null=True, blank=True)
    working_volume = models.CharField(max_length=200, blank=True, null=True)
    layer = models.CharField(max_length=200, blank=True, null=True)
    boq_chainage = models.ForeignKey('boq.BOQChainage', related_name='planningpeaconstatsrtip_boq_chainage',on_delete=models.CASCADE, null=True, blank=True)
    work_start_meter = models.FloatField(blank=True, null=True)
    work_end_meter = models.FloatField(blank=True, null=True)


class PlanningPeaconStatsSrtipAttachments(BaseAbstractStructure):
    master = models.ForeignKey(PlanningPeaconStatsSrtip, related_name='planning_peacon_stats_srtip_attachments_master', on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='project/document', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "planning_peacon_stats_srtip_attachments"

class ActualPeaconStatsStrip(BaseAbstractStructure):
    """
    Actual Peacon Stats Strip
    """
    SIDE_TYPE = (
        ('LHS', 'LHS'),
        ('RHS', 'RHS'),
        ('BHS', 'BHS'),
    )
    project = models.ForeignKey(ProjectMaster, related_name='project_actual_peacon',on_delete=models.CASCADE, null=True, blank=True)
    delay_breakup = models.ForeignKey('administrations.DelayBreakUps', related_name='project_risk_delay_breakups_actual',on_delete=models.CASCADE, null=True, blank=True)  # TODO: unlink after stable
    #####
    wbs_attribute = models.ForeignKey(WbsAttribute, related_name='actualpeaconstatsstrip_wbs', on_delete=models.CASCADE, null=True, blank=True)
    resolved_start_meter = models.FloatField(blank=True, null=True)
    resolved_end_meter = models.FloatField(blank=True, null=True)
    side = models.CharField(max_length=15,choices=SIDE_TYPE, blank=True, null=True)
    planned_strip_id = models.IntegerField(blank=True, null=True)

    # Date planned
    date_resolved = models.DateField(blank=True, null=True)
    resolve_notes = models.TextField(blank=True, null=True)



class PlanningAttachments(BaseAbstractStructure):
    planned_strip_id = models.IntegerField(null=True, blank=True)
    resolved_strip_id = models.IntegerField(null=True, blank=True)
    model_name = models.CharField(max_length=100, null=True, blank=True)
    order = models.IntegerField(default=0)
    attachment = models.FileField(upload_to='project/document', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "planning_attachments"

    def __str__(self):
        return str(self.id) + " - " + str(self.model_name)
    



class MobilizationMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='project_and_planning_mobilization_master_organization', on_delete=models.CASCADE)
    sub_function = models.CharField(max_length=300, blank=True, null=True)
    cross_functional_collaborative_activity = models.CharField(max_length=300, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)

    class Meta:
        db_table = "project_and_planning_mobilization_master"  


class MobilizationActivity(BaseAbstractStructure):
    """
    MobilizationActivity Model
    """

    STATUS_CHOICES = [
        ('open', 'Open'),
        ('close', 'Close'),
    ]

    PRIORITY_CHOICES = [
        ('critical', 'Critical'),
        ('high', 'High'),
        ('medium', 'Medium'),
        ('low', 'Low'),
    ]

    APPLICABILITY_CHOICES = [
        ('applicable', 'Applicable'),
        ('not_applicable', 'Not Applicable'),
    ]

    organization = models.ForeignKey(Organization, related_name='organization_mobilization_activity', on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='project_mobilization_activity', blank=True, null=True, on_delete=models.CASCADE)
    mobilization_master = models.ForeignKey(MobilizationMaster, related_name='mobilization_master_mobilization_activity', blank=True, null=True, on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster",related_name='site_mobilization_activity',on_delete=models.CASCADE, null=True, blank=True)

    status = models.CharField(max_length=50, choices=STATUS_CHOICES,  blank=True, null=True)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES,  blank=True, null=True)
    
    applicable_for_project = models.CharField(max_length=20, choices=APPLICABILITY_CHOICES,blank=True,null=True)
    remarks = models.TextField(blank=True, null=True)
    duration_days = models.IntegerField(blank=True, null=True, default=0)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    person_responsible = models.ManyToManyField(PmsUser, related_name='person_responsible_mobilization_activity', blank=True, null=True)
    action_to_be_taken = models.TextField(blank=True, null=True)
    target_date = models.DateField(blank=True, null=True)

    class Meta:
        db_table = "project_and_planning_mobilization_activity"        


class MobilizationTracker(BaseAbstractStructure):
    """
    MobilizationTracker Model
    Tracks the progress of mobilization activities.
    """
  
    organization = models.ForeignKey(
        Organization,
        related_name='organization_mobilization_tracker',
        on_delete=models.CASCADE
    )
    
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='project_mobilization_tracker',
        on_delete=models.CASCADE,
        blank=True,
        null=True
    )
    
    mobilization_master = models.ForeignKey(
        MobilizationMaster,
        related_name='mobilization_master_mobilization_tracker',
        on_delete=models.CASCADE,
        blank=True,
        null=True
    )
    
    mobilization_activity = models.ForeignKey(
        MobilizationActivity,
        related_name='mobilization_activity_mobilization_tracker',
        on_delete=models.CASCADE
    )

    # status_date = models.DateField(default=timezone.now)  # "Status as on Date"
    status_date=models.DateField(blank=True, null=True)
    time_elapsed = models.FloatField(blank=True, null=True)
    percentage_completion = models.FloatField( blank=True, null=True)
    progress_indicator = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )
    remarks = models.TextField(blank=True, null=True)

    class Meta:
        db_table = "project_and_planning_mobilization_tracker"
    
        # ordering = ["status_date"]

class MobilizationActivityLog(BaseAbstractStructure):
    ACTION_CHOICES = [
        ('create', 'Create'),
        ('update', 'Update'),
    ]

    mobilization_activity = models.ForeignKey(
        MobilizationActivity,
        related_name="mobilization_activity_logs",
        on_delete=models.CASCADE,null=True, blank=True
    )
    action = models.CharField(max_length=10, choices=ACTION_CHOICES)
    # performed_by = models.ForeignKey(PmsUser,related_name="performed_by_mobilization_activity_log", on_delete=models.CASCADE, null=True,blank=True)
    change_details = models.JSONField(null=True, blank=True)  
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "mobilization_activity_log"
        # ordering = ["-timestamp"]


class ProjectJVIncorporation(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='project_jv_incorporation', on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='project_jv_incorporation', on_delete=models.CASCADE,
        blank=True,
        null=True
    )
    file_name=models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(
        upload_to='project/jv/incorporation/document/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "project_jv_incorporation"

