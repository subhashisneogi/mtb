from django.apps import AppConfig


class ProjectAndPlanningConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'project_and_planning'
    def ready(self):
        import project_and_planning.signals

