import pprint
import threading

import colorama
import numpy as np
import pandas as pd
from django.db.models import Q, Value, Func, Subquery, OuterRef, Aggregate, JSONField
from django.db.models.functions import Coalesce, Concat
from django.shortcuts import render
from procurement.helper import GroupConcat
from rest_framework.pagination import PageNumberPagination
from rest_framework.views import APIView
from knox.auth import TokenAuthentication
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from django.core.paginator import Paginator
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException
from django.db.models import Sum, F, Value as V, FloatField
from django.db.models.functions import Coalesce, Cast

from administrations.utils import timer_wrapper, hrms_request, schedule_generic_mail , trigger_notifications
from boq.models import WBSList
from boq.serializers import WBSListSerializer
from material_master.models import VendorMaterialMaster
from tender.models import *
from tender.serializers import *
from procurement.helper import custom_filters, calculate_quantity_on_uom, sync_user_project_hrms ,handle_belsio_cost_centre1
from tender.helper import get_all_child
from user_permissions.models import UserWiseModulePermissions


from .models import *
from .p import save_attachment
from .serializers import *
# Create your views here.


def sync_hrms_project(data=None):
    try:
        if bool(int(str(os.getenv('HRMS_SYNC','0')))):
            end_point1 = None
            request_type1 = None
            hrms_project_site_id = None
            _data_dict = {item['internal_name']: item['value'] for item in data['project_data']}
            post_data1 = {
                'name': _data_dict['project_name'],
                'address': _data_dict['site_address'],
            }
            if data['hrms_project_site_id'] and data['hrms_project_site_id'] > 0:
                request_type1 = 'put'
                end_point1 = f"{os.getenv('HRMS_PROJECT_SITE_EDIT','')}{data['hrms_project_site_id']}/"
            else:
                request_type1 = 'post'
                end_point1 = f"{os.getenv('HRMS_PROJECT_SITE_ADD','')}"
            resp1 = hrms_request(request_type1, end_point1, post_data1)
            print(resp1)
            if resp1 and 'id' in resp1:
                ProjectMaster.objects.filter(pk=data['id']).update(hrms_project_site_id=resp1['id'])
                hrms_project_site_id = resp1['id']
            
            end_point2 = None
            request_type2 = None
            hrms_tender_id = None
            post_data2 = {
                'site_location': hrms_project_site_id,
            }
            if data['hrms_tender_id'] and data['hrms_tender_id'] > 0:
                request_type2 = 'put'
                end_point2 = f"{os.getenv('HRMS_TENDER_EDIT','')}{data['hrms_tender_id']}/"
            else:
                request_type2 = 'post'
                end_point2 = f"{os.getenv('HRMS_TENDER_ADD','')}"
            resp2 = hrms_request(request_type2, end_point2, post_data2)
            print(resp2)
            if resp2 and 'id' in resp2:
                ProjectMaster.objects.filter(pk=data['id']).update(hrms_tender_id=resp2['id'])
                hrms_tender_id = resp2['id']
            
            end_point = None
            request_type = None
            post_data = {
                'project_g_id': _data_dict['project_id'],
                'name': _data_dict['project_name'],
                'site_location': hrms_project_site_id,
                'tender': hrms_tender_id,
                'start_date': _data_dict['project_start_date']+' 00:00:00.000000',
                'end_date': _data_dict['expected_end_date']+' 00:00:00.000000',
            }
            if data['hrms_project_id'] and data['hrms_project_id'] > 0:
                request_type = 'put'
                end_point = f"{os.getenv('HRMS_PROJECT_EDIT','')}{data['hrms_project_id']}/"
            else:
                request_type = 'post'
                end_point = f"{os.getenv('HRMS_PROJECT_ADD','')}"
            resp = hrms_request(request_type, end_point, post_data)
            print(resp)
            if resp and 'id' in resp:
                ProjectMaster.objects.filter(pk=data['id']).update(hrms_project_id=resp['id'])
                return resp['id']
            else:
                return None
    except Exception as e:
        print('ERROR', e)


class ProjectListAPI(APIView):
    """
    Project List From Tender API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender converted to project
        """
        id = self.request.query_params.get('id', None)
        organization_id = self.request.query_params.get('organization_id', None)

        if id:
            tender_list = TenderMaster.cmobjects.filter(id = id).first()
            serializer = TenderMasterSerializer(tender_list, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True})
            return Response(serializer.data)

        dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='agreement_signed', \
                                                               option='Yes').values_list('id', flat=True))
        
        tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='agreement_signed', \
                                                      value__in=dropdown_ids).values_list('tender_id', flat=True))
        
        tender_list = TenderMaster.cmobjects.filter(id__in = tender_ids, \
                                                    organization_id=organization_id).order_by('id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(tender_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        serializer = TenderMasterSerializer(page, many=True, context = {"organization_id": organization_id,\
                                                                                        "list_type" : True})
        # serializer = CompanySerializer(company_list, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


class ProjectMasterAPI(APIView):
    """ Project Master API View """

    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all plant machinery master records
        """
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        form_menu_type = self.request.query_params.get('form_menu_type', None)
        form_group_id = self.request.query_params.get('form_group_id', None)
        list_type = self.request.query_params.get('list', None)
        order_by = self.request.query_params.get('order_by', 'id')

        search = {}
        has_permission = UserWiseModulePermissions.objects.filter(
            user=request.user,
            module_item__unique_id__in=['project-manager'],
            level_permission=True,
            is_deleted=False
        ).exists()
        if not has_permission:
            search = { 'users__in': [request.user] }
        search = custom_filters(self.request, search,['list', 'form_menu_type', 'form_group_id'])

        if id:
            project_master = ProjectMaster.cmobjects.filter(id=id).first()
            if form_menu_type and form_group_id:
                serializer = ProjectDataSerializer(project_master, context={"organization_id": organization_id, \
                                                                                    "form_menu_type": form_menu_type, \
                                                                                        "form_group_id": form_group_id,\
                                                                                            "list_type" : list_type,\
                                                                                                "user_id" : request.user.id})
            elif form_menu_type:
                serializer = ProjectDataSerializer(project_master, context={"organization_id": organization_id, \
                                                                                    "form_menu_type": form_menu_type,\
                                                                                        "list_type" : list_type,\
                                                                                            "user_id" : request.user.id})
            elif form_group_id:
                serializer = ProjectDataSerializer(project_master, context={"organization_id": organization_id, \
                                                                                    "form_group_id": form_group_id,\
                                                                                        "list_type" : list_type,\
                                                                                            "user_id" : request.user.id})
            else:
                serializer = ProjectDataSerializer(project_master, context={"organization_id": organization_id,\
                                                                                    "list_type" : list_type,\
                                                                                                "user_id" : request.user.id})
            return Response(serializer.data)

        project_master = ProjectMaster.cmobjects.select_related('tender', 'project_head', 'planning_head').prefetch_related('projects').filter(*search).order_by(*str(order_by).split(","))

        # project_master = ProjectMaster.cmobjects.filter(organization_id=organization_id).order_by('id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(project_master, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = ProjectDataSerializer(page, many=True, context={"organization_id": organization_id,\
                                                                                    "list_type" : list_type,\
                                                                                                "user_id" : request.user.id})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new plant machinery master record
        """
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            form_type = self.request.query_params.get('form_type', None)
            organization_id = Organization.objects.get(id=organization_id)
            tender_id = self.request.query_params.get('tender_id', None)

            with transaction.atomic():
                project_master_create = ProjectMaster.objects.create(organization=organization_id, \
                                                                        created_by=request.user, tender_id=tender_id)
                project_master_create.save()

                for key, value in request.data.items():
                    form_details = FormMaster.objects.filter(id=key).first()

                    if form_details.form_input_type == 'file':
                        created = ProjectData.objects.create(project=project_master_create, \
                                                                    form_id=key, \
                                                                    document=value, \
                                                                        created_by=request.user)
                    else:
                        created = ProjectData.objects.create(project=project_master_create, \
                                                                    form_id=key, value=value, created_by=request.user)
                    
                    created.save()

            serializer = ProjectDataSerializer(project_master_create, context={"organization_id": organization_id,\
                                                                                                "user_id" : request.user.id})

            form_type_list = list(FormMenuMaster.cmobjects.filter(\
                is_display=True).order_by('sort_order').values_list('form_type_name', flat=True).distinct())
            
            next_form_type = ''

            for num, value in enumerate(form_type_list, start=0):
                if form_type == value:
                    next_form_type = form_type_list[num + 1]
            
            hrms_project_resp = sync_hrms_project(serializer.data)
            handle_belsio_cost_centre1(instance=project_master_create,created=True)
            return Response({'results': {'Data': serializer.data },
                                'next': next_form_type,
                                'msg': 'Added Successfully',
                                'status': status.HTTP_200_OK,
                                "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e)})

    def put(self, request, *args, **kwargs):
        """
        Update an existing plant machinery master record
        """
        try:
            method = self.request.query_params.get('method', None)
            organization_id = self.request.query_params.get('organization_id', None)
            project_id = self.request.query_params.get('id', None)
            form_type = self.request.query_params.get('form_type', None)
            tender_id = self.request.query_params.get('tender_id', None)

            with transaction.atomic():
                if method and method.lower() == 'delete':
                    project_master_details = ProjectMaster.cmobjects.filter(organization_id=organization_id, \
                                                                          id=project_id).first()
                    project_master_details.is_deleted = True
                    project_master_details.save()

                    serializer = ProjectDataSerializer(project_master_details, context={"organization_id": organization_id,\
                                                                                                "user_id" : request.user.id})

                    return Response({'results': {'Data': serializer.data },
                                'msg': 'Data Deleted Successfully',
                                'status': status.HTTP_200_OK,
                                "request_status": 0})

                else:
                    if project_id != 'null':
                        project_master_details = ProjectMaster.cmobjects.filter(organization_id=organization_id, \
                                                                              id=project_id).first()
                    else:
                        project_master_details = ProjectMaster.objects.create(organization_id=organization_id, \
                                                                            created_by=request.user, tender_id=tender_id)
                        project_master_details.save()

                    for key, value in request.data.items():
                        formatted_key = str(key).split("_")
                        form_id = formatted_key[0]
                        sort_count = formatted_key[1]
                        form_details = FormMaster.objects.select_related('form_group').filter(id=int(form_id)).first()

                        if form_details.form_group.is_multiple:
                            if form_details.form_input_type == 'file':
                                created = ProjectData.objects.create(project=project_master_details, \
                                                                          form_id=form_id, document=value, created_by=request.user, by_order=sort_count)
                            else:
                                created = ProjectData.objects.create(project=project_master_details, \
                                                                          form_id=form_id, value=value, created_by=request.user, by_order=sort_count)
                        else:
                            if form_details.form_input_type == 'file':
                                created = ProjectData.objects.update_or_create(project=project_master_details, \
                                                                               form_id=form_id, \
                                                                                defaults={'document': value, \
                                                                                          'created_by': request.user, \
                                                                                            'by_order' : sort_count})
                            else:
                                created = ProjectData.objects.update_or_create(project=project_master_details, \
                                                                               form_id=form_id, defaults={'value': value, 'created_by': request.user,\
                                                                                                            'by_order' : sort_count})

                serializer = ProjectDataSerializer(project_master_details, context={"organization_id": organization_id,\
                                                                                                "user_id" : request.user.id})

                form_type_list = list(FormMenuMaster.cmobjects.filter(is_display=True).order_by('sort_order').values_list('form_type_name', flat=True).distinct())

                next_form_type = ''

                try:
                    for num, value in enumerate(form_type_list, start=0):
                        if form_type == value:
                            next_form_type = form_type_list[num + 1]
                except Exception as ex:
                    next_form_type = "last"
                print(project_master_details)
                hrms_project_resp = sync_hrms_project(serializer.data)
                handle_belsio_cost_centre1(instance=project_master_details,created=False)

                return Response({'results': {'Data': serializer.data },
                                'next': next_form_type,
                                'msg': 'Updated Successfully',
                                'status': status.HTTP_200_OK,
                                "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e)})


class ProjectMasterSearchAPI(APIView):
    """ Project Master API View """

    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all plant machinery master records
        """
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        form_menu_type = self.request.query_params.get('form_menu_type', None)
        form_group_id = self.request.query_params.get('form_group_id', None)
        list_type = self.request.query_params.get('list', None)

        project_start_date__gte = self.request.query_params.get('project_start_date__gte', None)

        order_by = self.request.query_params.get('order_by', 'id')

        if id:
            project_master = ProjectMaster.cmobjects.filter(id=id).first()
            if form_menu_type and form_group_id:
                serializer = ProjectDataSerializer2(project_master, context={"organization_id": organization_id, \
                                                                            "form_menu_type": form_menu_type, \
                                                                            "form_group_id": form_group_id, \
                                                                            "list_type": list_type, \
                                                                            "user_id": request.user.id})
            elif form_menu_type:
                serializer = ProjectDataSerializer2(project_master, context={"organization_id": organization_id, \
                                                                            "form_menu_type": form_menu_type, \
                                                                            "list_type": list_type, \
                                                                            "user_id": request.user.id})
            elif form_group_id:
                serializer = ProjectDataSerializer2(project_master, context={"organization_id": organization_id, \
                                                                            "form_group_id": form_group_id, \
                                                                            "list_type": list_type, \
                                                                            "user_id": request.user.id})
            else:
                serializer = ProjectDataSerializer2(project_master, context={"organization_id": organization_id, \
                                                                            "list_type": list_type, \
                                                                            "user_id": request.user.id})
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search,['hideLoader', 'organization_id', 'list', 'form_menu_type', 'form_group_id', 'project_start_date__gte'])
        project_master = (ProjectMaster.
                          cmobjects.
                          select_related('tender', 'project_head', 'planning_head').
                          prefetch_related('projects').filter(organization_id=organization_id, *search).
                          order_by('id'))

        if project_start_date__gte:
            project_master = project_master.filter(
                projects__form__form_type='project_details',
                projects__form__form_internal_name='project_start_date',
            )
            project_master = project_master.annotate(
                converted_date=Func(F('projects__value'), function='DATE')
            ).filter(converted_date__gte=project_start_date__gte)

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(project_master, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = ProjectDataSerializer2(page, many=True, context={"organization_id": organization_id, "list_type": list_type, "user_id": request.user.id})
        results = serializer.data

        _reverse = True if str(order_by).startswith('-') else False
        results.sort(key=lambda x: x[str(order_by).replace('-', '')], reverse=_reverse)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': results,
        })


class ProjectMasterDashboardTopAPI(APIView):
    """
    project overview top
    """
    
    

    def get(self, request, *args, **kwargs):
        """

		"""
        # order_by = self.request.query_params.get('order_by', '-id')
        # search = {}
        # search = custom_filters(self.request, search, ['hideLoader', ])

        # project_master = (ProjectMaster.
        #                   cmobjects.
        #                   select_related('tender', 'project_head', 'planning_head').
        #                   prefetch_related('projects').filter(*search).
        #                   order_by(*str(order_by).split(",")))

        # serializer = ProjectDataSerializer2(project_master, many=True)
        # results = serializer.data

        # total_projects = project_master

        # stand_alone_projects = list(filter(lambda x: not x['is_jv'], results))
        # jv_projects = list(filter(lambda x: x['is_jv'], results))

        # projects_won = TenderMaster.cmobjects.filter(is_l1=True).values()

        # current_stages=FormDropdownChoices.cmobjects.filter(form__form_type='project_details',
        #     form__form_internal_name='current_stage',).values('id','option')
        # current_stages={x['option']:x['id'] for x in current_stages}
        
        # on_going_projects_project_master = project_master.filter(
        #     projects__form__form_type='project_details',
        #     projects__form__form_internal_name='current_stage',
        #     projects__value = current_stages['Under Execution']
        # )
        # on_going_projects = ProjectDataSerializer2(on_going_projects_project_master, many=True).data



        # completed_projects_project_master = project_master.filter(
        #     projects__form__form_type='project_details',
        #     projects__form__form_internal_name='current_stage',
        #     projects__value = current_stages['Executed']
        # )
        # completed_projects = ProjectDataSerializer2(completed_projects_project_master, many=True).data


        # return Response({
        #     'results': {
        #         # 'total_projects': total_projects.values(),
        #         'total_projects_count': len(total_projects.values()),
        #         'stand_alone_projects': len(stand_alone_projects),
        #         'jv_projects': len(jv_projects),
        #         'projects_own': len(projects_won),
        #         'on_going_projects': len(on_going_projects),
        #         'completed_projects': len(completed_projects)
        #     },
        # })
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request,{}, ['hideLoader', ])

        _list = ProjectMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        total_projects_count = _list.count()

        stand_alone_projects_count = _list.filter(tender__tender_type='standalone').count()
        jv_projects_count = _list.filter(tender__tender_type='jv').count()

        projects_own_count = _list.count()

        on_going_projects_count = _list.filter(current_stage='Under Execution').count()

        completed_projects_count = _list.filter(current_stage='Executed').count()

        return Response({
            'results': {
                'total_projects_count': total_projects_count,
                'stand_alone_projects': stand_alone_projects_count,
                'jv_projects': jv_projects_count,
                'projects_own': projects_own_count,
                'on_going_projects': on_going_projects_count,
                'completed_projects': completed_projects_count
            }
        })

class JSONArrayAgg(Aggregate):
    function = "JSON_ARRAYAGG"
    output_field = JSONField()


class ProjectMasterDashboardBudgetVSActualAPI(APIView):
    '''
    Budget Vs Actual
    '''

    
    
    

    def get(self, request, *args, **kwargs):
        """

        """

        order_by = self.request.query_params.get('order_by', '-id')
        search = {}
        search = custom_filters(self.request, search,['hideLoader',])

        _val_wbs_list = ('id', 'organization_id', 'category', 'by_order', 'after_this_id', 'boq_code', 'boq_no', 'wbs', 'short_name', 'opening_done_quantity', 'opening_undone_quantity', 'tender_quantity', 'rate', 'cost', 'manual_rate', 'manual_cost', 'start_date', 'end_date', 'duration', 'parent', 'boq__project__id', 'wbs_material_wbs_list__material__id')
        wbs_list = (WBSList.
                 cmobjects.
                 select_related('boq', 'boq__project', 'wbs_material_wbs_list__material').
                 # prefetch_related('').
                 filter(*search).
                 order_by(*str(order_by).split(",")).
                 values(*_val_wbs_list))

        wbs_list = pd.DataFrame(wbs_list).drop_duplicates(subset=["wbs"], keep='first').to_dict('records')

        all_projects = [i['boq__project__id'] for i in wbs_list if i['boq__project__id']]
        all_projects = list(set(all_projects))
        print('all_projects', all_projects)
        _val = ('id', 'project_id', 'working_volume', 'boq_code_id', 'boq_code__wbs', 'uom_id',)
        planning_peacon_stats_srtip = (PlanningPeaconStatsSrtip.
                 cmobjects.
                 filter(project__in=all_projects, ).
                 values(*_val))

        planning_peacon_stats_srtip = pd.DataFrame(planning_peacon_stats_srtip).drop_duplicates(subset=["id"], keep='first').to_dict('records')

        # using pd
        wbs_list_df = pd.DataFrame(wbs_list)
        wbs_list_df = wbs_list_df.fillna(np.nan).replace([np.nan], [None])
        if not wbs_list:
            print('wbs_list  ',  wbs_list)
            wbs_list_df = pd.DataFrame(columns=_val_wbs_list)

        planning_peacon_stats_srtip_df = pd.DataFrame(planning_peacon_stats_srtip)
        if not planning_peacon_stats_srtip:
            planning_peacon_stats_srtip_df = pd.DataFrame(columns=_val)

        planning_peacon_stats_srtip_df = planning_peacon_stats_srtip_df.fillna(np.nan).replace([np.nan], [None])
        merged_df = pd.merge(wbs_list_df, planning_peacon_stats_srtip_df, left_on=['wbs', 'boq__project__id'], right_on=['boq_code__wbs', 'project_id'], how='left')
        result_df = merged_df.groupby(['wbs', 'boq__project__id']).agg({'working_volume': 'sum'}).reset_index()
        result_df.rename(columns={'working_volume': 'actual_cost'}, inplace=True)
        final_df = pd.merge(wbs_list_df, result_df, on=['wbs', 'boq__project__id'], how='left')
        final_df['actual_cost'].fillna(0, inplace=True)
        final_df['actual_cost'] = pd.to_numeric(final_df['actual_cost'], errors='coerce')

        _material = lambda i: VendorMaterialMaster.cmobjects.get(pk=int(i or 0)) if i else None
        _uom = lambda i: UnitOfMesurement.cmobjects.get(pk=int(i or 0)) if i else None
        final_df['actual_cost'] = final_df.apply(lambda row: calculate_quantity_on_uom(_material(row['wbs_material_wbs_list__material__id']),_material(row['wbs_material_wbs_list__material__unit_of_mesurement_id']),_uom(row['uom_id']), row['actual_cost']) if 'uom_id' in row else row['actual_cost'], axis=1)
        final_df[['parent', 'wbs_material_wbs_list__material__id']] = final_df[['parent', 'wbs_material_wbs_list__material__id']].fillna(0).astype(int).replace(0, None)


        wbs_list = final_df.to_dict(orient='records')

        # paginator = PageNumberPagination()
        # page_size = int(request.query_params.get('page_size', 200))
        # page_number = request.query_params.get('page', 1)
        # paginator.page = page_number
        # paginator.page_size = page_size
        # result_page = paginator.paginate_queryset(wbs_list, request)

        # return Response({
        #     'count': paginator.page.paginator.count,
        #     'next': paginator.get_next_link(),
        #     'previous': paginator.get_previous_link(),
        #     'results': result_page,
        # })

        return Response({
            'results': wbs_list,
        })



class ProjectHeadSelection(APIView):
    """
    Project Head Selection API
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            project_id = request.data.get('project_id', None)
            user_id = request.data.get('user_id', None)

            project_details = ProjectMaster.cmobjects.filter(id=project_id).first()

            if not project_details:
                return Response({'error': "Invalid Project Selected!"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            with transaction.atomic():
                project_details.project_head_id = user_id
                project_details.is_project_head_selected = True
                project_details.save()

            serializer = ProjectDataSerializer(project_details, context={"organization_id": project_details.organization_id,\
                                                                                                    "user_id" : request.user.id})
            
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as ex:
            return Response({'error': str(ex)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        


class ProjectPlanningHeadSelection(APIView):
    """
    Project Planning Head Selection API
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            project_id = request.data.get('project_id', None)
            user_id = request.data.get('user_id', None)

            project_details = ProjectMaster.cmobjects.filter(id=project_id).first()

            if not project_details:
                return Response({'error': "Invalid Project Selected!"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            with transaction.atomic():
                project_details.planning_head_id = user_id
                project_details.is_planning_head_selected = True
                project_details.save()

            serializer = ProjectDataSerializer(project_details, context={"organization_id": project_details.organization_id,\
                                                                                                    "user_id" : request.user.id})
            
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as ex:
            return Response({'error': str(ex)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        

class PlanningExecutiveSummeryDataAPIView(APIView):
    
    

    
    def get(self, request, format=None):
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)
        project_id = request.query_params.get('project_id', None)
        
        queryset = PlanningExecutiveSummeryData.cmobjects.all()
        if id:
            queryset = queryset.filter(id=id).first()
            serializer = PlanningExecutiveSummeryDataSerializer(queryset)
            return Response(serializer.data)
        
        if project_id:
            queryset = queryset.filter(project_id=project_id)
            serializer = PlanningExecutiveSummeryDataSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response({'error': "Project Not Found"}, status=status.HTTP_404_NOT_FOUND)
        

        if organization_id:
            queryset = queryset.filter(project__organization_id=organization_id)
            serializer = PlanningExecutiveSummeryDataSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response({'error': "please enter a valid organization_id"}, status=status.HTTP_404_NOT_FOUND)
            
        
    def put(self, request, *args, **kwargs):
        try:
            # Extract the relevant data from the request
            project_id = request.data.get('project_id', None)
            tender_id = request.data.get('tender_id', None)
            wbs_id = request.data.get('wbs_id', None)
            wbskey_id = request.data.get('wbskey_id', None)
            form_id = request.data.get('form_id', None)
            value = request.data.get('value', None)

            # Get or create the related objects
            
            tender = TenderMaster.objects.get(id=tender_id)
            wbs = TenderWBS.objects.get(id=wbs_id)
            wbskey = TenderWBSKeyScopes.objects.get(id=wbskey_id)

            # Check if the PlanningExecutiveSummeryData instance already exists
            instance, created = PlanningExecutiveSummeryData.objects.get_or_create(tender=tender, wbs=wbs, \
                                                                           wbskey=wbskey, form_id=form_id, project_id=project_id)

            # Update the value field
            instance.value = value
            instance.save()

            # Serialize the updated instance
            serializer = PlanningExecutiveSummeryDataSerializer(instance)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except (TenderMaster.DoesNotExist, TenderWBS.DoesNotExist, TenderWBSKeyScopes.DoesNotExist) as e:
            return Response({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        

class PlanningRiskDetilsAPIView(APIView):
    
    

    
    def get(self, request, format=None):
        project_id = request.query_params.get('project_id', None)
        id = request.query_params.get('id', None)

        if id:
            queryset = PlanningRiskdetails.cmobjects.filter(id=id).first()
            serializer = PlanningRiskdetailsSerializer(queryset)
            return Response(serializer.data)


        if project_id:
            queryset = PlanningRiskdetails.cmobjects.filter(project_id=project_id).order_by('id')
            serializer = PlanningRiskdetailsSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response({'error': "Project Not Found"}, status=status.HTTP_404_NOT_FOUND)
            
        
    def put(self, request, *args, **kwargs):
        try:
            # Extract the relevant data from the request
            project_id = request.data.get('project_id', None)
            tender_id = request.data.get('tender_id', None)
            form_id = request.data.get('form_id', None)
            value = request.data.get('value', None)
            table_id = request.data.get('table_id', None)

            risk_details_id = request.data.get('risk_details_id', None)


            if risk_details_id:
                risk_details_id = int(risk_details_id)
                risk_details = PlanningRiskdetails.objects.filter(id=risk_details_id).first()
            else:
                risk_details = PlanningRiskdetails.objects.create(tender_id=tender_id, \
                                                                  project_id=project_id)
                risk_details.save()
                risk_details_id = risk_details.id            

            instance, created = PlanningRiskdetailsData.objects.get_or_create(risk_details_id=risk_details_id,\
                                                                                  form_id=form_id)
            # Update the value field
            instance.value = value
            instance.table_id = table_id
            instance.save()
            # Serialize the updated instance
            serializer = PlanningRiskdetailsSerializer(risk_details)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)
        




class PlanningMembersRiskApprovalMatrix(APIView):
    """
    Planning Members Risk Approval Matrix APi both GET and PUT
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all PlanningCommiteeApprovalMatrix
        """
        project_id = self.request.query_params.get(
            'project_id', None)
        
        members_list = PlanningCommiteeApprovalMatrix.cmobjects.filter(
            project_id=project_id).order_by('id')

        serializer = PlanningCommiteeApprovalMatrixSerializer(members_list, many=True)


        return Response({
            'results': serializer.data,
        })
    
    def put(self, request, *args, **kwargs):
        from time import gmtime, strftime, localtime
        try:
            project_id = self.request.query_params.get('project_id', None)
            # action_status = self.request.query_params.get('action_status', None)

            end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)
            time_now = strftime("%d %b %Y %I:%M %p", localtime())

            project_details = ProjectMaster.cmobjects.filter(id=project_id).first()

            # project_data_details = ProjectData.objects.filter(project=project_details, \
            #                                                         form__form_internal_name='project_id').first()

            with transaction.atomic():
                user_id = request.user.id
                remarks = request.data.get('remarks', None)
                options = request.data.get('options', None)

                if options == 'Agree':
                    PlanningCommiteeApprovalMatrix.objects.update_or_create(project_id=project_id, users_id=user_id,\
                                                                        defaults={'risk_remarks' : remarks, \
                                                                                    'options' : options, 'is_risk_approved' : True})
                else:
                    PlanningCommiteeApprovalMatrix.objects.update_or_create(project_id=project_id, users_id=user_id,\
                                                                        defaults={'risk_remarks' : remarks, \
                                                                                    'options' : options, 'is_risk_approved' : False})
                
                if project_details.planning_head.id == user_id and options == 'Agree':
                    project_details.is_planning_risk_approved_by_planning_head = True
                    project_details.save()

                    if project_details.is_planning_risk_approved_by_project_head == False:
                        noti_create = NotificationMaster.objects.create(organization_id=project_details.organization_id,\
                                                                notification="Project With Project ID " + str(project_details.project_code) + " Risk Approved By " + \
                                                        str(end_user_name) + " at " + str(time_now) + " And send to Project Manager For Final Risk Matrix Approval", is_universal=True)
                
                        noti_create.save()

                        user_emails = list(UserWiseModulePermissions.objects.filter(\
                            level_permission=True).values_list('user__username', flat=True).distinct())
                        user_ids = list(UserWiseModulePermissions.objects.filter(\
                            level_permission=True).values_list('user_id', flat=True).distinct())
                        subject = "Project With Project ID " + str(project_details.project_code) + \
                            " Risk Approved By " + str(end_user_name)

                        notification_text = "Project With Project ID " + str(project_details.project_code) + " Risk Approved By " + str(end_user_name) + " at " + str(time_now) + " And send to Project Manager For Final Risk Matrix Approval" + "\n" + "Remarks : " + str(remarks)
                        trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                        # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

                if project_details.project_head.id == user_id and options == 'Agree':
                    project_details.is_planning_risk_approved_by_project_head = True
                    project_details.save()

                    noti_create = NotificationMaster.objects.create(organization_id=project_details.organization_id,\
                                                                notification="Project With Project ID " + str(project_details.project_code) + " Risk Approved By " + \
                                                        str(end_user_name) + " at " + str(time_now), is_universal=True)
                
                    noti_create.save()

                    user_emails = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user__username', flat=True).distinct())
                    user_ids = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user_id', flat=True).distinct())  
                    subject = "Project With Project ID " + str(project_details.project_code) + \
                        " Risk Approved By " + str(end_user_name)

                    notification_text = "Project With Project ID " + str(project_details.project_code) + " Risk Approved By " + str(end_user_name) + " at " + str(time_now) + "\n" + "Remarks : " + str(remarks)
                    trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                    # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

            members_list = PlanningCommiteeApprovalMatrix.cmobjects.filter(
                project_id=project_id).order_by('id')

            serializer = PlanningCommiteeApprovalMatrixSerializer(members_list, many=True)

            return Response({'results':{
                                'Data':serializer.data,
                                },
                                'msg': 'Status Updated',
                                'status':status.HTTP_200_OK,    
                                "request_status": 0})


        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        




class PlanningRiskDiaryAPIView(APIView):
    """
    CRUD API for PlanningRiskDiary model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all Planning Risk Diary
        """

        project_id = self.request.query_params.get(
            'project_id', None)
        
        risk_diary = PlanningRiskDiary.cmobjects.filter(
            project_id=project_id).order_by('-id')

        serializer = PlanningRiskDiarySerializer(risk_diary, many=True)

        return Response({
            'results': serializer.data
        })

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method
        """
        project_id = request.data.get('project_id', None)
        delay_reason_id = request.data.get('delay_reason_id', None)
        details_of_risks = request.data.get('details_of_risks', None)
        mitigation_plan = request.data.get('mitigation_plan', None)
        responsible_manager = request.data.get('responsible_manager', None)
        side = request.data.get('side', None)
        wtd_risk = request.data.get('wtd_risk', None)
        type_r = request.data.get('type_r', None)
        remarks = request.data.get('remarks', None)
        length_affected_from = request.data.get('length_affected_from', None)
        length_affected_to = request.data.get('length_affected_to', None)
        length_rm = request.data.get('length_rm', None)
        project_length_affected_in_percentage = request.data.get('project_length_affected_in_percentage', None)
        scope_affected = request.data.get('scope_affected', None)
        scope_affected_in_percentage = request.data.get('scope_affected_in_percentage', None)
        mitigation_expected_by = request.data.get('mitigation_expected_by', None)
        mitigation_from = request.data.get('mitigation_from', None)
        mitigation_to = request.data.get('mitigation_to', None)
        likely_days_affected = request.data.get('likely_days_affected', None)
        contract_durations_in_percentage = request.data.get('contract_durations_in_percentage', None)
        value_of_direct_impact_wrt_revenue_or_sales = request.data.get('value_of_direct_impact_wrt_revenue_or_sales', None)
        estimated_indirect_expenses = request.data.get('estimated_indirect_expenses', None)
        contigency = request.data.get('contigency', None)
        gross_impact = request.data.get('gross_impact', None)
        contract_price_in_percentage = request.data.get('contract_price_in_percentage', None)

        if mitigation_expected_by == "": # Null Handling Check for date field as it cause format error issue
            mitigation_expected_by = None
        else:
            mitigation_expected_by = mitigation_expected_by

        if mitigation_from == "": # Null Handling Check for date field as it cause format error issue
            mitigation_from = None
        else:
            mitigation_from = mitigation_from

        if mitigation_to == "": # Null Handling Check for date field as it cause format error issue
            mitigation_to = None
        else:
            mitigation_to = mitigation_to


        PlanningRiskDiary.objects.update_or_create(project_id=project_id, delay_reason_id=delay_reason_id,\
                                                   defaults={'details_of_risks': details_of_risks, 'mitigation_plan' : mitigation_plan,\
                                                             'responsible_manager' : responsible_manager, 'side' : side, 'wtd_risk' : wtd_risk,\
                                                                'type_r' : type_r, 'remarks' : remarks, 'length_affected_from' : length_affected_from, \
                                                                    'length_affected_to' : length_affected_to, 'length_rm' : length_rm, 'project_length_affected_in_percentage' : project_length_affected_in_percentage,\
                                                                        'scope_affected' : scope_affected, 'scope_affected_in_percentage' : scope_affected_in_percentage, 'mitigation_expected_by' : mitigation_expected_by, \
                                                                            'mitigation_from' : mitigation_from, 'mitigation_to' : mitigation_to, 'likely_days_affected': likely_days_affected, 'contract_durations_in_percentage' : contract_durations_in_percentage,\
                                                                                'value_of_direct_impact_wrt_revenue_or_sales': value_of_direct_impact_wrt_revenue_or_sales, 'estimated_indirect_expenses' : estimated_indirect_expenses, \
                                                                                    'contigency' : contigency, 'gross_impact' : gross_impact, 'contract_price_in_percentage' : contract_price_in_percentage})
        
        risk_diary_details = PlanningRiskDiary.cmobjects.filter(project_id=project_id, delay_reason_id=delay_reason_id).first()

        serializer = PlanningRiskDiarySerializer(risk_diary_details)

        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated Risk Diary",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
    

#################################### Peacon Strip View Starts From Here For Affected Areas Representations #########


class ChainBreakHeaderForPeaconStrip(APIView):
    """
    Chain Break Header For Peacon Strip
    """
    
    

    def get(self, request, format=None):
        """
        Get API for Chainage Breakup
        """
        chainage = self.request.query_params.get(
            'chainage', None)
        
        project_id = self.request.query_params.get(
            'project_id', None)
        
        
        # start_length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, \
        #                                              form__form_internal_name='project_start__in_kms_planning').first()
        
        # start_length = float(start_length_in_kms_query.value) * 1000 if start_length_in_kms_query else 0
        start_length_in_kms_query = ProjectMaster.cmobjects.filter(id=project_id,).first()
        start_length = float(start_length_in_kms_query.start_length_in_kms) * 1000 if start_length_in_kms_query and start_length_in_kms_query.start_length_in_kms else 0

        
        # end_length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, \
        #                                              form__form_internal_name='length_of_the_project__in_kms_planning').first()
        
        # end_length = float(end_length_in_kms_query.value) * 1000 if end_length_in_kms_query else 0
        end_length_in_kms_query = ProjectMaster.cmobjects.filter(id=project_id,).first()
        end_length = float(end_length_in_kms_query.project_length) * 1000 if end_length_in_kms_query and end_length_in_kms_query.project_length else 0

        result_list = []

        from project_and_planning.chainage_utility import float_range

        for item in float_range(start_length, end_length, int(chainage)):
            result_list.append(item)

        return Response({
            'result' : result_list
        })


class ChainageBreakupValueAPI(APIView):
    """
    Chainage Breakup Value API VIew
    """
    
    

    def get(self, request, format=None):
        """
        Get API for Chainage Breakup value
        """
        project_id = self.request.query_params.get(
            'project_id', None)
        
        chainage_details = ChainageBreakupValue.cmobjects.filter(project_id=project_id).first()

        length_in_kms_query = ProjectData.cmobjects.filter(project_id=project_id, \
                                                     form__form_internal_name='length_of_the_project__in_kms_planning').first()
        


        return Response({
            'chainage_value': chainage_details.value if chainage_details else 50,
            'length_in_kms' : float(length_in_kms_query.value) * 1000 if length_in_kms_query else 0
        })
    
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method
        """
        project_id = request.data.get('project_id', None)
        value = request.data.get('value', None)

        ChainageBreakupValue.objects.update_or_create(project_id=project_id, defaults={'value' : value})

        chainage_details = ChainageBreakupValue.cmobjects.filter(project_id=project_id).first()

        return Response({'chainage_value': chainage_details.value,
                            'msg': "Chainage Value Updated Successfully!",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})


class PeaconStripViewForAffectedAreas(APIView):
    """
    Get API for Peacon Strip View For Affected Areas Representations
    """
    
    

    @timer_wrapper(route_name='Precon StripView For Affected Areas:  GET')
    def get(self, request, format=None):
        """
        Get API for Peacon Strip View For Affected Areas Representations
        """

        project_id = self.request.query_params.get('project_id', None)
        
        side = self.request.query_params.get('side', None)
        
        chainage = self.request.query_params.get('chainage', None)
        
        organization_id = self.request.query_params.get('organization_id', None)


        # TenderWBS
        project_master = ProjectMaster.cmobjects.filter(id=project_id, organization_id=organization_id).first()
        tender = project_master.tender if project_master else None

        search = custom_filters(self.request, {}, ['project_id','side','chainage','organization_id',])
        
        tender_wbs_list = TenderWBS.cmobjects.filter(Q(tender=tender) | Q(is_default=True), *search).order_by('id') # is_master True
        return_list = []
        parent_list = list(set(list(tender_wbs_list.values_list('id', flat=True))))
        return_list = get_all_child(parent_list,return_list)
        tender_wbs_list = TenderWBS.cmobjects.filter(id__in=return_list).order_by('after_this','id','by_order')

        tender_wbs_serializer = TenderWBSPeaconStripSerializer(tender_wbs_list, many=True, context={'project_id': project_id, 'side': side, 'chainage': chainage})

        return Response({
            'results2': tender_wbs_serializer.data
        })


class PeaconAffectedAreasCreation(APIView):
    """
    Peacon Affected Areas Creation For Dynamic Strip View
    """
    
    

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method
        """
        project_id = request.data.get('project_id', None)
        delay_breakup_id = request.data.get('delay_breakup_id', None)
        affected_start_meter = request.data.get('affected_start_meter', None)
        affected_end_meter = request.data.get('affected_end_meter', None)
        side = request.data.get('side', None)

        # PlanningPeaconStatsSrtip.objects.update_or_create(project_id=project_id, delay_breakup_id=delay_breakup_id,\
        #                                                   defaults={'affected_start_meter' : affected_start_meter, 'affected_end_meter' : affected_end_meter,\
        #                                                             'side' : side})
        
        

        
        from administrations.generator import generate_large_list_with_start_index
        from django.db.models import Q
        
        chainage_list = []


        start_point = affected_start_meter
        end_point = affected_end_meter

        for itr in generate_large_list_with_start_index(int(start_point), int(end_point) + 1, 1):
            chainage_list.append(itr)

        if PlanningPeaconStatsSrtip.cmobjects.filter(Q(project_id=project_id), Q(delay_breakup_id=delay_breakup_id), \
                                                     Q(side=side), Q(affected_start_meter__in=chainage_list) | Q(affected_end_meter__in=chainage_list)).exists():
            
            PlanningPeaconStatsSrtip.cmobjects.filter(Q(project_id=project_id), Q(delay_breakup_id=delay_breakup_id), \
                                                      Q(side=side), \
                                                        Q(affected_start_meter__in=chainage_list) | \
                                                            Q(affected_end_meter__in=chainage_list)).update(affected_start_meter=affected_start_meter, \
                                                                                                           affected_end_meter=affected_end_meter)
            created = PlanningPeaconStatsSrtip.cmobjects.filter(Q(project_id=project_id), Q(delay_breakup_id=delay_breakup_id), \
                                                      Q(side=side), \
                                                        Q(affected_start_meter__in=chainage_list) | \
                                                            Q(affected_end_meter__in=chainage_list)).first()
            
        else:
            created = PlanningPeaconStatsSrtip.objects.create(project_id=project_id, delay_breakup_id=delay_breakup_id, side=side,\
                                                              affected_start_meter=affected_start_meter, \
                                                                affected_end_meter=affected_end_meter)
            created.save()

        #strip_details = PlanningPeaconStatsSrtip.cmobjects.filter(project_id=project_id, delay_breakup_id=delay_breakup_id).last()
        
        serializer = PlanningPeaconStatsSrtipSerializer(created)

        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated Strip Details",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})


class PreconAffectedAreasCreation(APIView):
    """
        Precon Affected Areas Creation For Dynamic Strip View (new)
    """
    
    

    @transaction.atomic()
    def post(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method
        """
        project_id = request.data.get('project_id', None)
        wbs_attribute_id = request.data.get('wbs_attribute_id', None)
        affected_start_meter = request.data.get('affected_start_meter', None)
        affected_end_meter = request.data.get('affected_end_meter', None)
        side = request.data.get('side', None)
        boq_code_id = request.data.get('boq_code_id', None)
        boq_type = request.data.get('boq_type', False)
        boq_code_text = request.data.get('boq_code_text', None)
        activity_id = request.data.get('activity_id', None)
        section_id = request.data.get('section_id', None)
        uom_id = request.data.get('uom_id', None)
        working_volume = request.data.get('working_volume', None)
        layer = request.data.get('layer', None)
        boq_chainage_id = request.data.get('boq_chainage_id', None)

        planning_attachments = request.data.get('planning_attachments', [])

        from administrations.generator import generate_large_list_with_start_index
        from django.db.models import Q

        chainage_list = []

        start_point = affected_start_meter
        end_point = affected_end_meter
        try:
            for itr in generate_large_list_with_start_index(int(start_point), int(end_point) + 1, 1):
                chainage_list.append(itr)

            '''
            if PlanningPeaconStatsSrtip.cmobjects.filter(Q(project_id=project_id), Q(wbs_attribute_id=wbs_attribute_id), Q(side=side), Q(affected_start_meter__in=chainage_list) | Q(affected_end_meter__in=chainage_list)).exists():
                print("POST: update PlanningPeaconStatsSrtip")
                if not WbsAttribute.cmobjects.filter(wbs_id=wbs_attribute_id).exists():
                    # wbs_attribute_create
                    _obj, _created = WbsAttribute.cmobjects.update_or_create(
                        risk_type='NORMAL', color_code='#0d6efd',
                        defaults={'wbs_id': wbs_attribute_id},
                    )

                planningpeaconstatssrtip = PlanningPeaconStatsSrtip.cmobjects.filter(Q(project_id=project_id), Q(wbs_attribute_id=wbs_attribute_id), Q(side=side), Q(affected_start_meter__in=chainage_list) | Q(affected_end_meter__in=chainage_list))
                planningpeaconstatssrtip.update(
                    affected_start_meter=affected_start_meter,
                    affected_end_meter=affected_end_meter,
                    boq_code=boq_code,
                    created_by=request.user
                )


                created = planningpeaconstatssrtip.first()

                #### save the attachments
                _details = created
                if planning_attachments:
                    save_attachment(_details, planning_attachments)
            else:
                print("POST: new PlanningPeaconStatsSrtip")
                if not WbsAttribute.cmobjects.filter(wbs_id=wbs_attribute_id).exists():
                    # wbs_attribute_create
                    _obj, _created = WbsAttribute.cmobjects.update_or_create(
                        risk_type='NORMAL', color_code='#0d6efd',
                        defaults={'wbs_id': wbs_attribute_id},
                    )
                created = PlanningPeaconStatsSrtip.objects.create(project_id=project_id,
                                                                  wbs_attribute_id=wbs_attribute_id,
                                                                  side=side,
                                                                  affected_start_meter=affected_start_meter,
                                                                  affected_end_meter=affected_end_meter,
                                                                  boq_code=boq_code,
                                                                  created_by=request.user
                                                                  )
                created.save()

                #### save the attachments
                _details = created
                if planning_attachments:
                    save_attachment(_details, planning_attachments)
            '''

            if not WbsAttribute.cmobjects.filter(wbs_id=boq_code_id).exists():
                # wbs_attribute_create
                wbs_attribute = WbsAttribute.cmobjects.create(
                    risk_type='NORMAL',
                    color_code='#0d6efd',
                    wbs_id=boq_code_id,
                )
                wbs_attribute_id = wbs_attribute.id
            created = PlanningPeaconStatsSrtip.objects.create(project_id=project_id,
                                                              wbs_attribute_id=wbs_attribute_id,
                                                              side=side,
                                                              affected_start_meter=affected_start_meter,
                                                              affected_end_meter=affected_end_meter,
                                                              created_by=request.user,
                                                              boq_code_id = boq_code_id,
                                                              boq_type = boq_type,
                                                              boq_code_text = boq_code_text,
                                                              activity_id = activity_id,
                                                              section_id = section_id,
                                                              uom_id = uom_id,
                                                              working_volume = working_volume,
                                                              layer = layer,
                                                              boq_chainage_id = boq_chainage_id,
                                                            )
            created.save()

            #### save the attachments
            _details = created
            if planning_attachments:
                save_attachment(_details, planning_attachments)

            serializer = PlanningPeaconStatsSrtipSerializer(created)
        except Exception as e:
            print("ERROR ", print(e))
            raise APIException({'request_status': 1, 'msg': e})

        return Response({'results': {
                'Data': serializer.data,
            },
            'msg': "Successfully updated Strip Details",
            'status': status.HTTP_202_ACCEPTED,
            "request_status": 1
        })

    @transaction.atomic()
    def put(self, request, *args, **kwargs):

        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)

        if method.lower() == 'edit':
            """
            Update a PlanningPeaconStatsSrtip
            """
            if PlanningPeaconStatsSrtip.cmobjects.filter(pk=id, ).exists():
                _details = PlanningPeaconStatsSrtip.cmobjects.filter(pk=id).first()
                planning_attachments = request.data.get('planning_attachments', [])
                if not WbsAttribute.cmobjects.filter(wbs=_details.wbs_attribute).exists():
                    # wbs_attribute_create
                    _obj, _created = WbsAttribute.cmobjects.update_or_create(
                        risk_type='NORMAL', color_code='#0d6efd',
                        defaults={'wbs': _details.wbs_attribute},
                    )

                request.data['updated_by_id'] = request.user.id
                serializer = PlanningPeaconStatsSrtipSerializer(_details, data=request.data)

                if serializer.is_valid():
                    try:
                        serializer.save()
                        #### save the attachment
                        if planning_attachments:
                            save_attachment(_details, planning_attachments)
                    except Exception as e:
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                    return Response({'results': {
                        'Data': serializer.data,
                    },
                        'msg': "Successfully updated",
                        'status': status.HTTP_202_ACCEPTED,
                        "request_status": 1})
                raise APIException({'request_status': 0, 'msg': serializer.errors})
            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
        elif method.lower() == 'delete':
            """
            Delete a PlanningPeaconStatsSrtip
            """
            if PlanningPeaconStatsSrtip.cmobjects.filter(pk=id,).exists():
                _details = PlanningPeaconStatsSrtip.cmobjects.get(pk=id,)
                _details.is_deleted = True
                _details.updated_by = request.user
                _details.save()

                return Response({'results': {
                    'Data': PlanningPeaconStatsSrtip.objects.filter(pk=id).values(),
                },
                    'msg': 'Successfully deleted Accounts Head',
                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
        else:
            raise APIException({'request_status': 0, 'msg': "method not selected."})



class PeaconAffectedAreasPlanAndTargetCreation(APIView):
    """
    Peacon Affected Areas Creation For Dynamic Strip View
    """
    
    

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method
        """
        id = request.data.get('id', None)
        date_planned = request.data.get('date_planned', None)
        criteria_planned = request.data.get('criteria_planned', None)
        attachment = request.data.get('attachment', None)

        if attachment:
            PlanningPeaconStatsSrtip.objects.update_or_create(id=id, defaults={'date_planned': date_planned, 'criteria_planned': criteria_planned, 'attachment': attachment})
        else:
            PlanningPeaconStatsSrtip.objects.update_or_create(id=id, defaults={'date_planned': date_planned, \
                                                                               'criteria_planned' : criteria_planned})

        strip_details = PlanningPeaconStatsSrtip.cmobjects.filter(id=id).first()

        serializer = PlanningPeaconStatsSrtipSerializer(strip_details)

        return Response({'results': {'Data': serializer.data,},
                            'msg': "Sucessfully updated Strip Details",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                                                          


class PeaconSolvedAreasActual(APIView):
    """
    Peacon Affected Areas Creation For Dynamic Strip View
    """
    
    

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method
        """
        project_id = request.data.get('project_id', None)
        delay_breakup_id = request.data.get('delay_breakup_id', None)
        resolved_start_meter = request.data.get('resolved_start_meter', None)
        resolved_end_meter = request.data.get('resolved_end_meter', None)
        side = request.data.get('side', None)
        planned_strip_id = request.data.get('planned_strip_id', None)
        date_resolved = request.data.get('date_resolved', None)
        resolve_notes = request.data.get('resolve_notes', None)

        # PlanningPeaconStatsSrtip.objects.update_or_create(project_id=project_id, delay_breakup_id=delay_breakup_id,\
        #                                                   defaults={'affected_start_meter' : affected_start_meter, 'affected_end_meter' : affected_end_meter,\
        #                                                             'side' : side})
        
        

        
        from administrations.generator import generate_large_list_with_start_index
        from django.db.models import Q
        
        chainage_list = []


        start_point = resolved_start_meter
        end_point = resolved_end_meter

        for itr in generate_large_list_with_start_index(int(start_point), int(end_point) + 1, 1):
            chainage_list.append(itr)

        if ActualPeaconStatsStrip.cmobjects.filter(Q(project_id=project_id), Q(delay_breakup_id=delay_breakup_id), \
                                                     Q(side=side), Q(resolved_start_meter__in=chainage_list) | Q(resolved_end_meter__in=chainage_list)).exists():
            
            ActualPeaconStatsStrip.cmobjects.filter(Q(project_id=project_id), Q(delay_breakup_id=delay_breakup_id), \
                                                      Q(side=side), \
                                                        Q(resolved_start_meter__in=chainage_list) | \
                                                            Q(resolved_end_meter__in=chainage_list)).update(resolved_start_meter=resolved_start_meter, \
                                                                                                           resolved_end_meter=resolved_end_meter, date_resolved=date_resolved, \
                                                                                                            resolve_notes=resolve_notes, planned_strip_id=planned_strip_id)
            


            created = ActualPeaconStatsStrip.cmobjects.filter(Q(project_id=project_id), Q(delay_breakup_id=delay_breakup_id), \
                                                      Q(side=side), \
                                                        Q(resolved_start_meter__in=chainage_list) | \
                                                            Q(resolved_end_meter__in=chainage_list)).first()
        else:
            created = ActualPeaconStatsStrip.objects.create(project_id=project_id, delay_breakup_id=delay_breakup_id, side=side,\
                                                              resolved_start_meter=resolved_start_meter, \
                                                                resolved_end_meter=resolved_end_meter, date_resolved=date_resolved, \
                                                                    resolve_notes=resolve_notes, planned_strip_id=planned_strip_id)
            created.save()

        #strip_details = ActualPeaconStatsStrip.cmobjects.filter(project_id=project_id, delay_breakup_id=delay_breakup_id).last()
        
        serializer = ActualPeaconResultSerializer(created)

        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated Resolved Strip Details",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})


class PreconSolvedAreasActual(APIView):
    """
        Precon Affected Areas Creation For Dynamic Strip View (new)
    """
    
    

    @transaction.atomic()
    def post(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method
        """
        project_id = request.data.get('project_id', None)
        wbs_attribute_id = request.data.get('wbs_attribute_id', None)
        resolved_start_meter = request.data.get('resolved_start_meter', None)
        resolved_end_meter = request.data.get('resolved_end_meter', None)

        side = request.data.get('side', None)
        date_resolved = request.data.get('date_resolved', None)
        resolve_notes = request.data.get('resolve_notes', None)
        planned_strip_id = request.data.get('planned_strip_id', None)

        planning_attachments = request.data.get('planning_attachments', [])



        from administrations.generator import generate_large_list_with_start_index
        from django.db.models import Q

        chainage_list = []

        start_point = resolved_start_meter
        end_point = resolved_end_meter
        try:
            for itr in generate_large_list_with_start_index(int(start_point), int(end_point) + 1, 1):
                chainage_list.append(itr)
            '''
            if ActualPeaconStatsStrip.cmobjects.filter(
                    Q(project_id=project_id),
                    Q(wbs_attribute_id=wbs_attribute_id),
                    Q(side=side),
                    Q(resolved_start_meter__in=chainage_list) | Q(resolved_end_meter__in=chainage_list)).exists():

                if not WbsAttribute.cmobjects.filter(wbs_id=wbs_attribute_id).exists():
                    # wbs_attribute_create
                    _obj, _created = WbsAttribute.cmobjects.update_or_create(
                        risk_type='NORMAL', color_code='#0d6efd',
                        defaults={'wbs_id': wbs_attribute_id},
                    )

                _ = ActualPeaconStatsStrip.cmobjects.filter(Q(project_id=project_id),
                                                             Q(wbs_attribute_id=wbs_attribute_id),
                                                             Q(side=side),
                                                             Q(resolved_start_meter__in=chainage_list) |
                                                             Q(resolved_end_meter__in=chainage_list))
                _.update(
                    resolved_start_meter=resolved_start_meter,
                    resolved_end_meter=resolved_end_meter,
                    date_resolved=date_resolved,
                    resolve_notes=resolve_notes,
                    planned_strip_id=planned_strip_id,
                    created_by=request.user
                )

                created = _.first()

                print("Precon Affected Areas : update:  POST")
                #### save the attachments
                _details = created
                if planning_attachments:
                    save_attachment(_details, planning_attachments)
            else:

                if not WbsAttribute.cmobjects.filter(wbs_id=wbs_attribute_id).exists():
                    # wbs_attribute_create
                    _obj, _created = WbsAttribute.cmobjects.update_or_create(
                        risk_type='NORMAL', color_code='#0d6efd',
                        defaults={'wbs_id': wbs_attribute_id},
                    )
                created = ActualPeaconStatsStrip.objects.create(
                    project_id=project_id,
                    wbs_attribute_id=wbs_attribute_id,
                    side=side,
                    resolved_start_meter=resolved_start_meter,
                    resolved_end_meter=resolved_end_meter,
                    date_resolved=date_resolved,
                    resolve_notes=resolve_notes,
                    planned_strip_id=planned_strip_id,
                    created_by=request.user
                )
                created.save()

                print("Precon Affected Areas : new:  POST")
                #### save the attachments
                _details = created
                if planning_attachments:
                    save_attachment(_details, planning_attachments)
            '''

            if not WbsAttribute.cmobjects.filter(wbs_id=wbs_attribute_id).exists():
                # wbs_attribute_create
                _obj, _created = WbsAttribute.cmobjects.update_or_create(
                    risk_type='NORMAL', color_code='#0d6efd',
                    defaults={'wbs_id': wbs_attribute_id},
                )
            created = ActualPeaconStatsStrip.objects.create(
                project_id=project_id,
                wbs_attribute_id=wbs_attribute_id,
                side=side,
                resolved_start_meter=resolved_start_meter,
                resolved_end_meter=resolved_end_meter,
                date_resolved=date_resolved,
                resolve_notes=resolve_notes,
                planned_strip_id=planned_strip_id,
                created_by=request.user
            )
            created.save()

            print("Precon Affected Areas : new:  POST")
            #### save the attachments
            _details = created
            if planning_attachments:
                save_attachment(_details, planning_attachments)

            serializer = ActualPeaconResultSerializer(created)
        except Exception as e:
            print("ERROR ", print(e))
            raise APIException({'request_status': 1, 'msg': e})

        return Response({'results': {
            'Data': serializer.data,
        },
            'msg': "Successfully updated Strip Details",
            'status': status.HTTP_202_ACCEPTED,
            "request_status": 1
        })

    @transaction.atomic()
    def put(self, request, *args, **kwargs):
        '''  '''
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)

        if method.lower() == 'edit':
            """
            Update a ActualPeaconStatsStrip
            """
            if ActualPeaconStatsStrip.cmobjects.filter(pk=id, ).exists():
                _details = ActualPeaconStatsStrip.cmobjects.filter(pk=id).first()
                planning_attachments = request.data.get('planning_attachments', [])
                if not WbsAttribute.cmobjects.filter(wbs=_details.wbs_attribute).exists():
                    # wbs_attribute_create
                    _obj, _created = WbsAttribute.cmobjects.update_or_create(
                        risk_type='NORMAL', color_code='#0d6efd',
                        defaults={'wbs': _details.wbs_attribute},
                    )

                request.data['updated_by_id'] = request.user.id
                serializer = ActualPeaconResultSerializer(_details, data=request.data)

                if serializer.is_valid():
                    try:
                        serializer.save()

                        #### save the attachments
                        if planning_attachments:
                            save_attachment(_details, planning_attachments)
                    except Exception as e:
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                    return Response({'results': {
                        'Data': serializer.data,
                    },
                        'msg': "Successfully updated",
                        'status': status.HTTP_202_ACCEPTED,
                        "request_status": 1})
                raise APIException({'request_status': 0, 'msg': serializer.errors})
            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
        elif method.lower() == 'delete':
            """
            Delete a ActualPeaconStatsStrip
            """
            if ActualPeaconStatsStrip.cmobjects.filter(pk=id, ).exists():
                _details = PlanningPeaconStatsSrtip.cmobjects.get(pk=id, )
                _details.is_deleted = True
                _details.updated_by = request.user
                _details.save()

                return Response({'results': {
                    'Data': PlanningPeaconStatsSrtip.objects.filter(pk=id).values(),
                },
                    'msg': 'Successfully deleted Accounts Head',
                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
        else:
            raise APIException({'request_status': 0, 'msg': "method not selected."})
        



class PlanningSectionAPIView(APIView):
    """
    CRUD API for planning section model
    """
    
    

    def get(self, request):
        """
        Get a list of all planning commission
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            queryset = PlanningSection.cmobjects.filter(id=id).first()
            serializer = PlanningSectionSerializer(queryset)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])
        queryset = PlanningSection.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlanningSectionSerializer(queryset, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlanningSectionSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request):
        """
        Create a new planning section
        """
        request.data['created_by_id'] = request.user.id
        serializer = PlanningSectionSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Planning Section
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        planning_section_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Planning Section
                """
                if PlanningSection.cmobjects.filter(pk=planning_section_id, organization_id=organization_id).exists():
                    details = PlanningSection.cmobjects.filter(pk=planning_section_id).first()
                    if details:
                        request.data['updated_by_id'] = request.user.id
                    serializer = PlanningSectionSerializer(details, data=request.data,partial=True)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Planning Section
                """
                if PlanningSection.cmobjects.filter(pk=planning_section_id, organization_id=organization_id).exists():
                    details = PlanningSection.cmobjects.filter(
                        pk=planning_section_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': PlanningSection.objects.filter(pk=planning_section_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted planning section',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
    


class PlanningActivityAPIView(APIView):
    """
    CRUD API for planning activity model
    """
    
    

    def get(self, request):
        """
        Get a list of all communication type
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            queryset = PlanningActivity.cmobjects.filter(id=id).first()
            serializer = PlanningActivitySerializer(queryset)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])
        queryset = PlanningActivity.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlanningActivitySerializer(queryset, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlanningActivitySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    

    def post(self, request):
        """
        Create a new planning activity
        """
        request.data['created_by_id'] = request.user.id
        serializer = PlanningActivitySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Planning Activity
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        planning_activity_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Planning Activity
                """
                if PlanningActivity.cmobjects.filter(pk=planning_activity_id, organization_id=organization_id).exists():
                    details = PlanningActivity.cmobjects.filter(pk=planning_activity_id).first()
                    if details:
                        request.data['updated_by_id'] = request.user.id
                    serializer = PlanningActivitySerializer(details, data=request.data,partial=True)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Planning Activity
                """
                if PlanningActivity.cmobjects.filter(pk=planning_activity_id, organization_id=organization_id).exists():
                    details = PlanningActivity.cmobjects.filter(
                        pk=planning_activity_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': PlanningActivity.objects.filter(pk=planning_activity_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted planning activity',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})



class PlanningPeaconStatsSrtipAPIView(APIView):
    """
    CRUD API for PlanningPeaconStatsSrtip model
    """
    
    

    def get(self, request):
        """
        Get a list of all PlanningPeaconStatsSrtip
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            queryset = PlanningPeaconStatsSrtip.cmobjects.filter(id=id).first()
            serializer = PlanningPeaconStatsSrtipSerializer(queryset)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])
        queryset = PlanningPeaconStatsSrtip.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlanningPeaconStatsSrtipSerializer(queryset, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlanningPeaconStatsSrtipSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request):
        """
        Create a new PlanningPeaconStatsSrtip
        """
        request.data['created_by_id'] = request.user.id
        serializer = PlanningPeaconStatsSrtipSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    
    def put(self, request):
        """
        Edit a PlanningPeaconStatsSrtip
        """
        method = self.request.query_params.get('method', None)
        # organization_id = self.request.query_params.get(
            # 'organization_id', None)
        planning_peacon_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlanningPeaconStatsSrtip
                """
                if PlanningPeaconStatsSrtip.cmobjects.filter(pk=planning_peacon_id).exists():
                    details = PlanningPeaconStatsSrtip.cmobjects.filter(pk=planning_peacon_id).first()
                    if details:
                        request.data['updated_by_id'] = request.user.id
                    serializer = PlanningPeaconStatsSrtipSerializer(details, data=request.data,partial=True)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlanningPeaconStatsSrtip
                """
                if PlanningPeaconStatsSrtip.cmobjects.filter(pk=planning_peacon_id).exists():
                    details = PlanningPeaconStatsSrtip.cmobjects.filter(
                        pk=planning_peacon_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': PlanningPeaconStatsSrtip.objects.filter(pk=planning_peacon_id).values(),
                    },
                        'msg': 'Successfully deleted planning section',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
        

class ProjectUserSelection(APIView):
    
    

    def put(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                id = self.request.query_params.get('id', None)
                users = request.data.get('users', None)

                project_details = ProjectMaster.cmobjects.filter(id=id).first()
                if project_details:
                    project_details.users.set(users)
                    project_details.save()
                    sync_user_project_hrms(project_details)
                
                    return Response({
                        'msg': 'Successfully Updated.',
                        'status': status.HTTP_200_OK,
                        "request_status": 1
                    })
                else:
                    raise APIException({'request_status': 0, 'msg': 'Not Found'})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class ProjectMasterV2API(APIView):
    
    

    def get(self, request):
        try:
            order_by = self.request.query_params.get('order_by', 'id')
            search = { 'users__in': [request.user] }
            search = custom_filters(self.request, search,[])

            projects = ProjectMaster.cmobjects.values(
                'id', 'project_code', 'project_name','project_classification','project_start_date','expected_end_date','production_start_date',
            ).filter(*search).order_by(*str(order_by).split(","))
            return Response(projects)
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})



class MobilizationMasterAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        project_id = request.query_params.get('project_id', None)
        mobilization_master_mobilization_activity__project__id = request.query_params.get('mobilization_master_mobilization_activity__project__id', None)
        _exclude = ['mobilization_master_mobilization_activity__project__id']

        search = {}

        # search = custom_filters(request, search,[])
        search = custom_filters(request, search,_exclude)
        if mobilization_master_mobilization_activity__project__id:
            serializer_context = {'project_id': mobilization_master_mobilization_activity__project__id}
            print(serializer_context)
        else:
            serializer_context = {}
        # if project_id:
        #     serializer_context = {'project_id': project_id}
        #     _list = MobilizationMaster.cmobjects.all().order_by(*str(order_by).split(","))
        #     serializer = MobilizationMasterSerializer(_list, many=True,context=serializer_context)
        #     return Response({'results': serializer.data}) 
       
        _list = MobilizationMaster.cmobjects.filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = MobilizationMasterSerializer(_list, many=True,context=serializer_context)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MobilizationMasterSerializer(page, many=True,context=serializer_context)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = MobilizationMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if MobilizationMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = MobilizationMaster.cmobjects.filter(pk=id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = MobilizationMasterSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if MobilizationMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = MobilizationMaster.objects.filter(pk=id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    
                    return Response({'results': {'Data': MobilizationMaster.objects.filter(pk=id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                


class MobilizationActivityAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        search = {}
        search = custom_filters(request, search, [])

        _list = MobilizationActivity.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = MobilizationActivitySerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MobilizationActivitySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = MobilizationActivitySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)

        with transaction.atomic():
            if method == 'edit':
                details = MobilizationActivity.cmobjects.filter(pk=id, organization_id=organization_id).first()
                if details:
                    request.data['updated_by'] = request.user.id
                    serializer = MobilizationActivitySerializer(details, data=request.data, partial=True, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                            return Response({'results': serializer.data, 
                                            'msg': "Successfully updated", 
                                            'status': status.HTTP_202_ACCEPTED,
                                            'request_status': 1})
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

            elif method == 'delete':
                activity_instance = MobilizationActivity.cmobjects.filter(pk=id, organization_id=organization_id).first()
                if activity_instance:
                    activity_instance.is_deleted = True
                    activity_instance.updated_by_id = request.user.id
                    activity_instance.save()
                    return Response({'results': {'Data': MobilizationActivity.objects.filter(pk=id, organization_id=organization_id).values()}, 
                                     'msg': 'Successfully deleted', "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})                
                

class MobilizationTrackerAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-status_date')
        search = {}
        search = custom_filters(request, search, [])

        _list = MobilizationTracker.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = MobilizationTrackerSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MobilizationTrackerSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        mobilization_activity = request.data.get('mobilization_activity')
        status_date = request.data.get('status_date')

        existing_tracker = MobilizationTracker.cmobjects.filter(
            mobilization_activity=mobilization_activity,
            status_date=status_date
        ).first()

        if existing_tracker:
            return Response({
                'results': {'data': MobilizationTrackerSerializer(existing_tracker).data},
                'msg': 'Tracker for the same activity and status date already exists.',
                'status': status.HTTP_200_OK,
                "request_status": 0
            })
        serializer = MobilizationTrackerSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response({
                'results': {'data': serializer.data},
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1
            })
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)

        with transaction.atomic():
            if method == 'edit':
                details = MobilizationTracker.cmobjects.filter(pk=id, organization_id=organization_id).first()
                if details:
                    request.data['updated_by'] = request.user.id
                    serializer = MobilizationTrackerSerializer(details, data=request.data, partial=True, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                            return Response({
                                'results': serializer.data,
                                'msg': "Successfully updated",
                                'status': status.HTTP_202_ACCEPTED,
                                'request_status': 1
                            })
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

            elif method == 'delete':
                details = MobilizationTracker.cmobjects.filter(pk=id, organization_id=organization_id).first()
                if details:
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({
                        'results': {'Data': MobilizationTracker.objects.filter(pk=id, organization_id=organization_id).values()},
                        'msg': 'Successfully deleted',
                        "request_status": 1
                    })
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})                
                


class MobilizationActivityLogAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-timestamp')  
        search = {}
        search = custom_filters(request, search, [])

        _list = MobilizationActivityLog.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = MobilizationActivityLogSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MobilizationActivityLogSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })                
    



# class ProjectStageValueGraphAPI(APIView):
#     """
#     API to generate total project value grouped by current_stage
#     """
#     
#     

#     def get(self, request, *args, **kwargs):
        
#         current_stages = FormDropdownChoices.cmobjects.filter(
#             form__form_type='project_details',
#             form__form_internal_name='current_stage'
#         ).values('id', 'option')

#         current_stages = {x['id']: x['option'] for x in current_stages}
#         print(current_stages)
#         # for item in current_stages:

#         #     project_data = (
#         #         ProjectData.cmobjects.filter(
#         #             form__form_type='project_details',
#         #             form__form_internal_name='current_stage',
#         #             value = item['id']
#         #             # value__in=current_stages.keys()
#         #         )).values('id','project_id','value')
#         # print(project_data)   
#         # project_data_new = (
#         #     ProjectData.cmobjects.filter(
#         #         form__form_type='project_details',
#         #         form__form_internal_name='project_value',
#         #         # value__isnull=False 
               
#         #     )).values('value') 
#         # print('check',project_data_new)
#         project_data = ProjectData.cmobjects.filter(
#                 form__form_internal_name='current_stage',
#                 value__in=['1318']
#             ).annotate(
#                     project_value=Coalesce(Sum(
#                         Subquery(
#                         ProjectData.cmobjects.filter(
#                             project_id=OuterRef('project'),
#                             form__form_internal_name='project_value'
#                         ).values('value')
#                     ),output_field=FloatField()),
#                     Value(0, output_field=FloatField())
#             )
#             ).values('project_value')
#         print(project_data)  
#         #     .annotate(
#         #         stage_name=Subquery(
#         #             FormDropdownChoices.cmobjects.filter(
#         #                 id=OuterRef('value') 
#         #             ).values('option')[:1]  
#         #         )
#         #     )
#         #     .values('stage_name') 
#         #     .annotate(
#         #         total_project_value=Sum(
#         #             F('project__projects__value'), 
#         #             output_field=FloatField()
#         #         )
#         #     )
          
#         # )

#         return Response({
#             "results": list(project_data)
#         })    
    

class ProjectStageValueGraphAPI(APIView):
    """
    API to generate total project value grouped by current_stage
    """
    
    

    def get(self, request, *args, **kwargs):
        # response_data = FormDropdownChoices.cmobjects.filter(
        #     form__form_type='project_details',
        #     form__form_internal_name='current_stage'
        # ).values('option').annotate(
        #     total_project_value = Coalesce(Sum(Subquery(
        #         ProjectData.cmobjects.filter(
        #             form__form_type='project_details',
        #             form__form_internal_name='project_value',
        #             project_id__in=ProjectData.cmobjects.filter(
        #                 value=OuterRef(OuterRef("pk")),
        #                 form__form_type='project_details',
        #                 form__form_internal_name='current_stage',
        #                 project__is_deleted=False,
        #             ).values_list('project',flat=True)
        #         ).values('form').annotate(
        #             project_value=Sum('value')
        #         ).values('project_value')
        #     )), Value(0), output_field=FloatField()),
        # ).values('option','total_project_value')
        # return Response({
        #     "results": response_data
        # })
        _list = ProjectMaster.cmobjects.values('current_stage').annotate(
            total_project_value=Coalesce(Sum('project_value'), Value(0), output_field=FloatField())
        )
        result_dict = {row['current_stage']: row['total_project_value'] for row in _list}
        response_data = []
        for key, label in ProjectMaster.CURRENT_STAGE_CHOICES:
            response_data.append({
                'option': key,
                'total_project_value': float(result_dict.get(key, 0))
            })

        return Response(response_data)
class ProjectMasterNewAPIView(APIView):
    """
    New API ProjectMaster entries
    """
    def get(self, request):
        """
        Get ProjectMaster details
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = ProjectMaster.cmobjects.select_related(
                'organization', 'tender', 'project_head', 'planning_head'
            ).filter(id=id).first()
            serializer = ProjectMasterNewSerializer(details, context={'request': request})
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])

        _list = ProjectMaster.cmobjects.select_related(
            'organization', 'tender', 'project_head', 'planning_head'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = ProjectMasterNewSerializer(_list, many=True, context={'request': request})
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = ProjectMasterNewSerializer(page, many=True, context={'request': request})
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request):
        """
        Create a ProjectMaster entry
        """
        request.data['created_by'] = request.user.id
        serializer = ProjectMasterNewSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            # try:
            serializer.save()
            # except Exception as e:
            #     error_message = str(e.args[0]) if e.args else str(e)
            #     raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created.',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete ProjectMaster entry
        """
        method = request.query_params.get('method', '').lower()
        id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            details = ProjectMaster.cmobjects.filter(pk=id,organization_id=organization_id).first()

            if not details:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            if method == 'edit':
                """
                Update ProjectMaster entry
                """
                request.data['updated_by'] = request.user.id
                serializer = ProjectMasterNewSerializer(details, data=request.data, partial=True, context={'request': request})

                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})

                    return Response(
                        {'results': serializer.data,
                         'msg': 'Successfully updated.',
                         'status': status.HTTP_202_ACCEPTED,
                         "request_status": 1})
                raise APIException({'request_status': 0, 'msg': serializer.errors})

            elif method == 'delete':
                """
                Delete a ProjectMaster entry
                """
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()

                return Response({
                    'results': {'Data': ProjectMaster.objects.filter(pk=id,organization_id=organization_id).values()},
                    'msg': 'Successfully deleted.',
                    "request_status": 1
                })

            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})



class ProjectJVIncorporationAPIView(APIView):
    """
        CRUD API for ProjectJVIncorporation model
    """
    
    

    def get(self, request):
        """
        Get a list of all communication
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            queryset = ProjectJVIncorporation.cmobjects.filter(id=id).first()
            serializer = ProjectJVIncorporationSerializer(queryset)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])
       
        queryset = ProjectJVIncorporation.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = ProjectJVIncorporationSerializer(queryset, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = ProjectJVIncorporationSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create one or more records
        """
        data = request.data if isinstance(request.data, list) else [request.data]
        created_objects = []
        errors = []

        for item in data:
            item['created_by'] = request.user.id
            serializer = ProjectJVIncorporationSerializer(data=item, context={'request': request})
            print("View File DATA", item.get('file_data'))
            if serializer.is_valid():
                try:
                    instance = serializer.save()
                    created_objects.append(ProjectJVIncorporationSerializer(instance).data)
                except Exception as e:
                    errors.append({'data': item, 'error': str(e)})
            else:
                errors.append({'data': item, 'error': serializer.errors})

        if errors:
            return Response({
                'request_status': 0,
                'msg': 'Some records failed to create',
                'errors': errors,
                'created': created_objects
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'results': {'Data': created_objects},
            'msg': 'Successfully created',
            'status': status.HTTP_201_CREATED,
            'request_status': 1
        }, status=status.HTTP_201_CREATED)

    def put(self, request):
        """
        Edit a ProjectJVIncorporation
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a ProjectJVIncorporation
                """
                if ProjectJVIncorporation.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = ProjectJVIncorporation.cmobjects.filter(pk=id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = ProjectJVIncorporationSerializer(details, data=request.data,partial=True,)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                """
                Delete a ProjectJVIncorporation
                """
                if ProjectJVIncorporation.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = ProjectJVIncorporation.cmobjects.filter(
                        pk=id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': ProjectJVIncorporation.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted communication',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})