import numpy as np


def float_range(start, end, step):
    current_value = start
    while current_value <= end:
        yield round(current_value, 3)
        current_value += step