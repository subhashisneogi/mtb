import pandas as pd
from .models import MobilizationMaster
from administrations.models import Organization

def import_mobilization_data(excel_file_path='mobilization_master.xlsx', default_organization_id=1):
    try:
        df = pd.read_excel(excel_file_path)
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        return

    df.columns = df.columns.str.strip()

    print("Columns in Excel file:", df.columns)

    required_columns = ['sub_function', 'cross_functional_collaborative_activity']
    for col in required_columns:
        if col not in df.columns:
            print(f"Column '{col}' is missing in the Excel file.")
            return

    try:
        organization = Organization.objects.get(id=default_organization_id)
    except Organization.DoesNotExist:
        print(f"Organization with ID {default_organization_id} does not exist.")
        return

    for index, row in df.iterrows():
        sub_function = row.get('sub_function', '').strip()  
        cross_functional_collaborative_activity = row.get('cross_functional_collaborative_activity', '').strip()

        if not sub_function or not cross_functional_collaborative_activity:
            print(f"Skipping row {index} due to missing data in required fields.")
            continue  

        mobilization_master = MobilizationMaster(
            organization=organization,
            sub_function=sub_function,
            cross_functional_collaborative_activity=cross_functional_collaborative_activity,
        )

        mobilization_master.save()

    print("Data has been inserted successfully.")