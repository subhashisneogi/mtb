from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from django.utils.safestring import mark_safe

from .models import *

# Register your models here.


@admin.register(PlanningExecutiveSummeryData)
class PlanningExecutiveSummeryDataAdmin(ModelAdmin):
    list_display = ['id', 'value']


class PlanningRiskdetailsDataAdmin(StackedInline):
	"""
	PlanningRiskdetailsData Admin
	"""
	model = PlanningRiskdetailsData
	fk_name = 'risk_details'
        

class PlanningRiskAdmin(ModelAdmin):
    inlines = (PlanningRiskdetailsDataAdmin,) 


class ProjectMasterAdmin(ModelAdmin):
    list_display = ['id', 'project_name', 'project_code', 'tender', 
    'project_head', 'project_classification', 'project_value', 'created_at']
    search_fields = ['project_name', 'project_code']

admin.site.register(ProjectMaster, ProjectMasterAdmin)
admin.site.register(ProjectData,ModelAdmin)
admin.site.register(PlanningRiskdetails, PlanningRiskAdmin)
admin.site.register(ChainageBreakupValue,ModelAdmin)
admin.site.register(ActualPeaconStatsStrip,ModelAdmin)
admin.site.register(PlanningAttachments,ModelAdmin)


@admin.register(PlanningActivity)
class PlanningActivityAdmin(ModelAdmin):
    def _color_code(self, obj):
        return mark_safe(f'<div style="display: flex;"><div style="height: 15px;width: 15px;background-color: {str(obj.color_code)};"></div>&nbsp;<i style="font-size: x-small;">{str(obj.color_code)}</i></div>')
    list_display = ['id', 'type', 'value', 'max_layer', '_color_code']


@admin.register(PlanningSection)
class PlanningSectionAdmin(ModelAdmin):
    list_display = ['id', 'type', 'value']


@admin.register(PlanningPeaconStatsSrtip)
class PlanningPeaconStatsSrtipAdmin(ModelAdmin):
    list_display = ['id', 'activity', 'affected_start_meter', 'affected_end_meter', 'side']



@admin.register(MobilizationMaster)
class MobilizationMasterAdmin(ModelAdmin):
    list_display = ['id', 'sub_function', 'cross_functional_collaborative_activity',  'is_deleted']


@admin.register(MobilizationActivity)
class MobilizationActivityAdmin(ModelAdmin):
    list_display = ['id','organization', 'project', 'mobilization_master',  'is_deleted']    

@admin.register(MobilizationTracker)
class MobilizationTrackerAdmin(ModelAdmin):
    list_display = ['id','organization', 'project', 'mobilization_master', 'mobilization_activity', 'is_deleted']  

@admin.register(MobilizationActivityLog)
class MobilizationActivityLogAdmin(ModelAdmin):
    list_display = ['id','mobilization_activity','created_by' ]                  


class ProjectJVIncorporationAdmin(ModelAdmin):
    list_display = ['id', 'name', 'attachment', 'created_at']
admin.site.register(ProjectJVIncorporation,ModelAdmin)