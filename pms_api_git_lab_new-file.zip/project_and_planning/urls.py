from django.urls import path
from project_and_planning import views
from django.views.decorators.cache import cache_page

urlpatterns = [
    path('project_list/', views.ProjectListAPI.as_view()),
    path('project-master/', views.ProjectMasterAPI.as_view()),
    path('project-master-new/', views.ProjectMasterNewAPIView.as_view()),
    path('project-master-dashboard/', views.ProjectMasterSearchAPI.as_view()),
    path('project-master-dashboard-top/', views.ProjectMasterDashboardTopAPI.as_view()),

    path('project-dashboard-budget-vs-actual/', views.ProjectMasterDashboardBudgetVSActualAPI.as_view()),


    path('planning-executive-summary/', views.PlanningExecutiveSummeryDataAPIView.as_view()),

    path('planning-risk/', views.PlanningRiskDetilsAPIView.as_view()),

    path('project-head-selection/', views.ProjectHeadSelection.as_view()),
    path('project-planning-head-selection/', views.ProjectPlanningHeadSelection.as_view()),


    path('project-planning-risk-approval-matrix/', views.PlanningMembersRiskApprovalMatrix.as_view()),

    path('project-planning-risk-diary/', views.PlanningRiskDiaryAPIView.as_view()),


    ############################ Strip VIew APIs Start ###############

    path('chainage-list/', views.ChainBreakHeaderForPeaconStrip.as_view()),

    path('chainage-breakup/', views.ChainageBreakupValueAPI.as_view()),

    # path('peacon-strip-for-affected-areas/', views.PeaconStripViewForAffectedAreas.as_view()), # new
    path('peacon-strip-for-affected-areas/',  cache_page(60 * 1)(views.PeaconStripViewForAffectedAreas.as_view())), # new

    # path('peacon-strip-for-affected-areas-create/', views.PeaconAffectedAreasCreation.as_view()),  # old

    path('precon-strip-for-affected-areas-create/', views.PreconAffectedAreasCreation.as_view()),  # new

    # path('peacon-strip-target-date-set/', views.PeaconAffectedAreasPlanAndTargetCreation.as_view()),  # old

    # path('peacon-strip-actual-date-set/', views.PeaconSolvedAreasActual.as_view()),  # old

    path('precon-strip-actual-date-set/', views.PreconSolvedAreasActual.as_view()),  # new
    path('planning-section/', views.PlanningSectionAPIView.as_view()),  # new
    path('planning-activity/', views.PlanningActivityAPIView.as_view()),  # new
    path('planning-peacon-stats-srtip/', views.PlanningPeaconStatsSrtipAPIView.as_view()), # new
    path('project-user-selection/', views.ProjectUserSelection.as_view()),
    path('project-master-v2/', views.ProjectMasterV2API.as_view()),

    path('project-planning-mobilization-master/', views.MobilizationMasterAPIView.as_view()),
    path('project-planning-mobilization-activity/', views.MobilizationActivityAPIView.as_view()),
    path('project-planning-mobilization-tracker/', views.MobilizationTrackerAPIView.as_view()),
    path('project-planning-mobilization-activity-log/', views.MobilizationActivityLogAPIView.as_view()),
    path('project-stage-value-graph/', views.ProjectStageValueGraphAPI.as_view()),

    path('project-jv-incorporation/', views.ProjectJVIncorporationAPIView.as_view()),


]