from django.db.models.signals import pre_save, post_save, m2m_changed
from django.dispatch import receiver
import datetime  # Import datetime module
from django.db import models, transaction
from django.db.models import Sum, Value, FloatField
from django.db.models.functions import Coalesce
from deepdiff import DeepDiff

from django.utils.timezone import now
from .models import *
import json
from administrations.models import PmsUser


@receiver(pre_save, sender=MobilizationActivity)
def log_mobilization_activity_changes(sender, instance, **kwargs):
    if instance.pk:
        original_instance = MobilizationActivity.objects.filter(pk=instance.pk).first()
        if not original_instance:
            return

       
        changed_fields = {}
        for field in instance._meta.fields:
            field_name = field.name
            original_value = getattr(original_instance, field_name, None)
            new_value = getattr(instance, field_name, None)
            
            if isinstance(original_value, datetime.date):
                original_value = original_value.isoformat()
            if isinstance(new_value, datetime.date):
                new_value = new_value.isoformat()

            if original_value != new_value:
                changed_fields[field_name] = {"old": original_value, "new": new_value}
        if not hasattr(instance, '_original_person_responsible'):
            instance._original_person_responsible = [
                {"id": user.id, "first_name": user.first_name, "last_name": user.last_name}
                for user in original_instance.person_responsible.all()
            ]

        instance._changed_fields = changed_fields



@receiver(m2m_changed, sender=MobilizationActivity.person_responsible.through)
def log_person_responsible_changes(sender, instance, action, pk_set, **kwargs):
    if action in ["post_add", "post_remove"]:
        new_person_responsible = [
            {"id": user.id, "first_name": user.first_name, "last_name": user.last_name}
            for user in instance.person_responsible.all()
        ]
        old_person_responsible = getattr(instance, "_original_person_responsible", [])

        if new_person_responsible != old_person_responsible:
            instance._changed_fields = getattr(instance, "_changed_fields", {})
            instance._changed_fields['person_responsible'] = {
                "old": old_person_responsible,
                "new": new_person_responsible
            }

        instance._original_person_responsible = new_person_responsible

        if hasattr(instance, '_log_entry') and instance._log_entry:
            instance._log_entry.change_details.update(instance._changed_fields)
            instance._log_entry.save()
        else:
            instance._log_entry = MobilizationActivityLog.objects.create(
                mobilization_activity=instance,
                action="update",
                created_by=instance.updated_by,
                change_details=instance._changed_fields,
                timestamp=now()
            )


@receiver(post_save, sender=MobilizationActivity)
def log_mobilization_activity_creation(sender, instance, created, **kwargs):
    try:
        with transaction.atomic():
            if created:
                instance._log_entry = MobilizationActivityLog.objects.create(
                    mobilization_activity=instance,
                    action="create",
                    created_by=instance.created_by,
                    change_details={"message": "Created New Mobilization Activity"},
                    timestamp=now()
                )
            elif hasattr(instance, '_changed_fields') and instance._changed_fields:
                instance._log_entry = MobilizationActivityLog.objects.create(
                    mobilization_activity=instance,
                    action="update",
                    created_by=instance.updated_by,
                    change_details=instance._changed_fields,
                    timestamp=now()
                )
    except Exception as e:
        print(f"Error during post_save: {e}")


@receiver(post_save, sender=MobilizationTracker)
def mobilization_completion(sender, instance, created, **kwargs):
    try:
        with transaction.atomic():
            # records = MobilizationTracker.cmobjects.values(
            #     'mobilization_activity'
            # ).annotate(
            #     total_percentage_completion = Coalesce(Sum('percentage_completion'), Value(0), output_field=FloatField()),
            # ).filter(
            #     mobilization_activity_id=instance.mobilization_activity_id,
            #     project_id=instance.project_id,
            # )
            # if records:
            #     if records[0]['total_percentage_completion'] == 100:
            #         MobilizationActivity.cmobjects.filter(pk=instance.mobilization_activity_id).update(status='close')
            if instance.percentage_completion >= 100:
                MobilizationActivity.cmobjects.filter(pk=instance.mobilization_activity_id).update(status='close')
    except Exception as e:
        print(f"Error during post_save: {e}")
