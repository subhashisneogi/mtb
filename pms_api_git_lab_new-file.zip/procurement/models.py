from datetime import timezone
from django.db import models
from django.db.models.aggregates import Sum
from django.utils.http import urlencode
# from rest_framework import serializers
from rest_framework.exceptions import ValidationError
from administrations.models import *
from adminpanel.models import *
from boq.models import WBSMaterial, WBSPlantMachinery, WbsIndirectCostPlaning, BOQChainageExecutiveSummeryData, WbsTempPlaning,WBSList,BOQ
from email_config.models import *
from material_master.models import *
from plant_machinery.models import *
from project_and_planning.models import *
from vendor.models import *
from labour_master.models import *
from misc.models import *
from tender.models import TenderMasterNew
import base64
import json


class FinancialYear(BaseAbstractStructure):
    """
    Represents a financial year.
    """
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    name = models.CharField(max_length=100, default='2023-24')
    description = models.CharField(max_length=100, default='')

    def __str__(self):
        return f"{self.start_date.year}-{self.end_date.year}"

    class Meta:
        db_table = "procurement_financial_year"
        verbose_name_plural = "Financial Years"


class SiteLocationMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_site_location_master_organizations',
                                     on_delete=models.CASCADE)
    zone = models.ForeignKey(Zone, related_name='procurement_site_location_zone', on_delete=models.CASCADE,
                             null=True, blank=True)
    location_name = models.CharField(max_length=200)

    def __str__(self):
        return self.location_name

    class Meta:
        db_table = "procurement_site_locations_master"


class SiteLocationChild(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_site_location_child_organizations',
                                     on_delete=models.CASCADE)
    location_master = models.ForeignKey(SiteLocationMaster, related_name='procurement_site_location_child_master',
                                        on_delete=models.CASCADE, null=True, blank=True)
    latitude = models.CharField(max_length=100)
    longitude = models.CharField(max_length=100)
    radius = models.FloatField(default=500, null=True, blank=True)

    def __str__(self):
        return f"{self.latitude} latitude - {self.longitude} longitude - {self.radius} Radius"

    class Meta:
        db_table = "procurement_site_locations_child"


class SiteMaster(BaseAbstractStructure):
    """
    Site Master Model
    """
    # More fields: site manage
    # TODO:1. foreign key to lat and long master table. 2. Add zone reference (Nullable), Add state lnk
    organization = models.ForeignKey(Organization, related_name='procurement_site_organizations',
                                     on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_site_project',
                                on_delete=models.CASCADE)
    slug = models.CharField(max_length=150, default=None, unique=True)
    site_name = models.CharField(max_length=100)
    location = models.CharField(max_length=200, default="")
    address = models.TextField(max_length=500, null=True, blank=True)
    # location = models.ForeignKey(SiteLocationMaster, related_name='procurement_site_location',on_delete=models.CASCADE, null=True, blank=True)
    state = models.ForeignKey(State, related_name='procurement_site_state', on_delete=models.CASCADE)
    users = models.ManyToManyField(PmsUser, related_name='procurement_site_users', null=True, blank=True)
    po_tracker_to_users = models.ManyToManyField(PmsUser, related_name='po_tracker_cc_users_po_tracker_to_users_ids', null=True, blank=True)
    po_tracker_cc_users = models.ManyToManyField(PmsUser, related_name='procurement_site_po_tracker_cc_users', null=True, blank=True)

    def __str__(self):
        return self.site_name

    class Meta:
        db_table = "procurement_site"


class StoreSection(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_store_section_organizations')
    section_name = models.CharField(max_length=200)
    short_name = models.CharField(max_length=100)

    class Meta:
        db_table = "procurement_store_section"


class StoreMaster(BaseAbstractStructure):
    """
    Store Master Model
    """
    # TODO: store manager, How many store managers should be there for one store?
    organization = models.ForeignKey(Organization, related_name='procurement_store_organizations',
                                     on_delete=models.CASCADE)
    store_name = models.CharField(max_length=100)
    address = models.TextField(max_length=500, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_store_site', on_delete=models.CASCADE,
                             null=True, blank=True)
    users = models.ManyToManyField(PmsUser, null=True, blank=True, related_name='procurement_store_user')
    rack = models.ManyToManyField(StoreSection, null=True, blank=True, related_name='procurement_store_rack')

    # rack = models.ForeignKey(StoreSection, related_name='procurement_store_rack', on_delete=models.CASCADE, null=True, blank=True)
    sap_plant_id = models.CharField(max_length=300, blank=True, null=True)
    sap_auth_key_material = models.CharField(max_length=300, blank=True, null=True)
    sap_auth_key_po = models.CharField(max_length=300, blank=True, null=True)
    sap_auth_key_grn = models.CharField(max_length=300, blank=True, null=True)
    sap_auth_key_pr = models.CharField(max_length=300, blank=True, null=True)
    sap_auth_key_stock = models.CharField(max_length=300, blank=True, null=True)
    sap_start_codes = models.CharField(max_length=300, blank=True, null=True)
    purhase_org = models.ForeignKey('procurement.SAPMasters', related_name='procurement_store_purchase_org',null=True, blank=True, on_delete=models.CASCADE)
    # company_code = models.ForeignKey('procurement.SAPMasters', related_name='procurement_store_company_code',null=True, blank=True, on_delete=models.CASCADE)
    # company_code = models.ForeignKey('administrations.Company', related_name='procurement_store_company_code',null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.store_name

    class Meta:
        db_table = "procurement_store"


class SAPMasters(BaseAbstractStructure):
    TYPE_CHOICES = (
        ('Purchase Organization', 'Purchase Organization'),
        ('Purchase Group', 'Purchase Group'),
        ('Company Code', 'Company Code'),
        ('InCo Terms', 'InCo Terms'),
        ('Payment Terms', 'Payment Terms'),
        ('Tax Code', 'Tax Code'),
        ('Terms & Condition Header Tax', 'Terms & Condition Header Tax'),
    )
    organization = models.ForeignKey(
        Organization, related_name='procurement_sap_masters_organizations',
        on_delete=models.CASCADE
    )
    type = models.CharField(
        max_length=200, choices=TYPE_CHOICES, blank=True, null=True
    )
    code = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(max_length=500, null=True, blank=True)
    # is_default = models.BooleanField(default=False)
    extra=models.JSONField(blank=True,null=True)
    # sap_auth_key = models.CharField(max_length=300, blank=True, null=True)
    def __str__(self):
        return f"{self.type} -> {self.code}"

    class Meta:
        db_table = "procurement_sap_master"


class MaterialRequestMaster(BaseAbstractStructure):
    """
    Material Request
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_material_request_organizations',
                                     on_delete=models.CASCADE)
    requested_by = models.ForeignKey(PmsUser, related_name='procurement_material_requested_by',
                                     on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True)
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE)
    department = models.ForeignKey(Department, related_name='procurement_material_request_department',
                                   on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_material_request_project', on_delete=models.CASCADE, null=True)
    previous_version = models.ForeignKey('self', related_name='procurement_material_request_previous_version',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    version = models.IntegerField(default=1)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    location = models.CharField(max_length=200, null=True, blank=True)
    line_in_bottom = models.CharField(max_length=200, null=True, blank=True)
    already_purchased = models.BooleanField(default=False)
    is_fulfilled = models.BooleanField(default=False)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_material_request_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.site} Site Requested {self.store} Store"

    class Meta:
        db_table = "procurement_material_request"


class MaterialRequestMasterItems(BaseAbstractStructure):
    """
    Material Request Items
    """
    PRIORITIES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )

    # request date = created at
    organization = models.ForeignKey(Organization, related_name='procurement_material_item_request_organizations',
                                     on_delete=models.CASCADE)
    material_request = models.ForeignKey(MaterialRequestMaster, related_name='procurement_material_item_request',
                                         on_delete=models.CASCADE, null=True, blank=True)
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_requested_material',
                                           on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_material_request_items_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_material_request_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_material_request_items_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_material_request_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_material_request_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_material_request_items_uom_id', on_delete=models.CASCADE, null=True, blank=True)
    size_part_grade = models.CharField(max_length=100, null=True, blank=True)
    quantity_unit = models.FloatField(default=0.0)
    sanctioned_quantity = models.FloatField(default=0)
    rejected_quantity = models.FloatField(default=0)
    closed_quantity = models.FloatField(default=0)
    weight_unit = models.CharField(max_length=100, null=True, blank=True)
    requested_for_type = models.CharField(max_length=200, blank=True, null=True)
    requested_for = models.CharField(max_length=200, blank=True, null=True)
    department = models.CharField(max_length=100, null=True, blank=True)
    charge_type = models.CharField(max_length=100, null=True, blank=True)
    is_returnable = models.BooleanField(default=False)
    priority = models.CharField(max_length=100, choices=PRIORITIES, blank=True, null=True, default="low")
    due_date = models.DateField(null=True, blank=True)
    is_fulfilled = models.DecimalField(max_digits=5, decimal_places=2, default=0)  # Store Percentage
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    rate = models.FloatField(default=0)  # not in use
    amount = models.FloatField(default=0)  # not in use
    ## new
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    budgeted_qty = models.CharField(max_length=200, blank=True, null=True, default="")
    total_received_uptodate = models.CharField(max_length=200, blank=True, null=True, default="")
    stock_on_site = models.CharField(max_length=200, blank=True, null=True, default="")
    application = models.CharField(max_length=200, blank=True, null=True, default="")
    delivery_schedule_date = models.CharField(max_length=200, blank=True, null=True, default="")
    delivery_schedule_day = models.CharField(max_length=200, blank=True, null=True, default="")
    delivery_schedule = models.CharField(max_length=200, blank=True, null=True, default="")  # category
    sanctioned_remarks = models.TextField(null=True, blank=True)
    # purchase_remarks = models.TextField(null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_items_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_items_cancelled_by",  on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_items_close_by",  on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_items_approved_by",  on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_request_items_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    cost_center = models.ForeignKey(CostCenter, related_name='procurement_material_request_items_cost_center', on_delete=models.CASCADE, null=True, blank=True)
    gl_account = models.ForeignKey(GLAccount, related_name='procurement_material_request_items_gl_account', on_delete=models.CASCADE, null=True, blank=True)

    def clean(self):
        # Perform custom validation logic before saving the model
        if self.quantity_unit < self.sanctioned_quantity:
            raise ValidationError("Sanctioned quantity is higher than quantity!")
        return super().clean()

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity_unit:
            self.quantity_unit = 0
        if not self.sanctioned_quantity:
            self.sanctioned_quantity = 0
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.id} {self.requested_material.material_code} for {self.material_request} {self.quantity_unit} | {self.weight_unit}"

    class Meta:
        db_table = "procurement_material_request_items"


class MaterialRequestMasterItemsNotes(BaseAbstractStructure):
    """
    Material Request Items
    """
    organization = models.ForeignKey(Organization, related_name='procurement_material_item_note_request_organizations',
                                     on_delete=models.CASCADE)
    material_request_item = models.ForeignKey(MaterialRequestMasterItems,
                                              related_name='procurement_material_item_note_request',
                                              on_delete=models.CASCADE, null=True, blank=True)
    note_title = models.CharField(max_length=100, blank=True, null=True)
    note_details = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = "procurement_material_request_item_notes"


class MaterialRequestMasterAttachments(BaseAbstractStructure):
    """
    Material Request Items
    """
    organization = models.ForeignKey(Organization, related_name='procurement_material_request_attachment_organizations',
                                     on_delete=models.CASCADE)
    material_request = models.ForeignKey(MaterialRequestMaster,
                                         related_name='procurement_material_request_attachment',
                                         on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/material_request', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_material_request_attachments"


class MaterialRequestMasterItemsRemarks(BaseAbstractStructure):
    REMARKS_TYPE = (
        ('purchase', 'purchase'),
        ('general', 'general'),
    )
    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name='procurement_material_request_item_remarks_material_request_item', on_delete=models.CASCADE, null=True, blank=True)
    remarks_type = models.CharField(max_length=100, choices=REMARKS_TYPE, blank=True, null=True, default='general')
    remarks = models.TextField(null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    class Meta:
        db_table = "procurement_material_request_item_remarks"


class Inventory(BaseAbstractStructure):
    """
    Inventory Model
    """
    TYPE = (
        ('party', 'party'),
        ('self', 'self'),
    )
    OPENING_TYPE = (
        ('manual', 'Manual'),
        ('transfer', 'Transfer'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_inventory_organizations', on_delete=models.CASCADE)
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_inventory_material', on_delete=models.CASCADE, blank=True, null=True)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='procurement_inventory_plant_machinery_machine', on_delete=models.CASCADE, blank=True, null=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_store_inventory', on_delete=models.CASCADE, blank=True, null=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_site_inventory', on_delete=models.CASCADE, blank=True, null=True)
    quantity = models.FloatField(default=0)
    opening_quantity = models.FloatField(default=0)
    min_stock_quantity = models.FloatField(default=0)
    max_stock_quantity = models.FloatField(default=0)
    weight = models.FloatField(default=0)
    opening_weight = models.FloatField(default=0)
    min_stock_weight = models.FloatField(default=0)
    max_stock_weight = models.FloatField(default=0)
    cost_per_unit = models.FloatField(default=0)  # average price
    # uom
    uom_opening_qty = models.ForeignKey(UnitOfMesurement, related_name='uom_master_inventory_oq',
                                        on_delete=models.CASCADE, blank=True, null=True)
    uom_opening_weight = models.ForeignKey(UnitOfMesurement, related_name='uom_master_inventory_ow',
                                           on_delete=models.CASCADE, blank=True, null=True)
    uom_opening_cost_per_unit = models.ForeignKey(UnitOfMesurement, related_name='uom_master_inventory_cpu',
                                                  on_delete=models.CASCADE, blank=True, null=True)

    remarks = models.CharField(max_length=255, blank=True, null=True)
    stock_type = models.CharField(max_length=100, choices=TYPE, blank=True, null=True, default="self")
    opening_type = models.CharField(max_length=100, choices=OPENING_TYPE, blank=True, null=True, default="manual")
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_site_financial_year', on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.id} {self.store.store_name} : {self.material.material_name if self.material else self.plant_machinery_machine.equipment_description} - {self.quantity} ({self.financialyear})"

    class Meta:
        unique_together = ('organization', 'material', 'plant_machinery_machine', 'store', 'site', 'financialyear')
        db_table = "procurement_inventory"


class InventoryLogs(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_inventory_log_organizations',
                                     on_delete=models.CASCADE)
    inventory = models.ForeignKey(Inventory, related_name='procurement_inventory_log_inventory',
                                  on_delete=models.CASCADE)
    transaction_quantity = models.FloatField()
    before_quantity = models.FloatField(default=0)  # Before value of material in the Inventory
    after_quantity = models.FloatField(default=0)  # After value of material in the Inventory
    cost_per_unit = models.FloatField(default=0)
    reference_type = models.CharField(null=True, blank=True, max_length=100)  # Indent, Issue, RFQ, etc
    reference_id = models.IntegerField(null=True, blank=True)  # id of the reference
    details = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "procurement_inventory_logs"


class PhysicalStockGroup(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_physical_stock_group_organization', on_delete=models.CASCADE)
    name = models.CharField(max_length=200, blank=True, null=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)

    class Meta:
        db_table = "procurement_physical_stock_group"


class PhysicalStock(BaseAbstractStructure):
    STATUS = (
        ('draft', 'draft'),
        ('post', 'post'),
        ('unpost', 'unpost'),
        ('cancel', 'cancel')
    )

    organization = models.ForeignKey(Organization, related_name='physical_stock_organizations',
                                     on_delete=models.CASCADE)
    inventory = models.ForeignKey(Inventory, related_name='physical_stock_inventory', on_delete=models.CASCADE,
                                  null=True)

    material = models.ForeignKey(VendorMaterialMaster, related_name='physical_stock_material', on_delete=models.CASCADE)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_physical_stock_uom', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='physical_stock_store', on_delete=models.CASCADE, null=True,
                              blank=True)
    site = models.ForeignKey(SiteMaster, related_name='physical_stock_site', on_delete=models.CASCADE, null=True,
                             blank=True)
    parent_group = models.ForeignKey(PhysicalStockGroup, related_name='physical_stock_parent_group', on_delete=models.CASCADE, null=True, blank=True)

    physical_qty = models.FloatField(default=0.0)
    actual_qty = models.FloatField(default=0.0)

    diff_qty = models.FloatField(default=0.0)  # physical_qty - actual_qty
    physical_rate = models.FloatField(default=0.0)
    actual_rate = models.FloatField(default=0.0)
    diff_rate = models.FloatField(default=0.0)  # physical_rate - actual_rate
    physical_amt = models.FloatField(default=0.0)  # physical_qty * physical_rate
    actual_amt = models.FloatField(default=0.0)  # actual_qty * actual_rate
    diff_amt = models.FloatField(default=0.0)  # physical_amt - actual_amt

    remarks = models.TextField(max_length=300, null=True, blank=True)

    status = models.CharField(max_length=100, choices=STATUS, blank=True, null=True, default="unpost")
    financialyear = models.ForeignKey(FinancialYear, related_name='physical_stock_financial_year',
                                      on_delete=models.CASCADE)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.physical_qty:
            self.physical_qty = 0.0
        if not self.actual_qty:
            self.actual_qty = 0.0
        if not self.physical_rate:
            self.physical_rate = 0.0
        if not self.actual_rate:
            self.actual_rate = 0.0
        self.diff_qty = float(self.physical_qty) - float(self.actual_qty)
        self.diff_rate = float(self.physical_rate) - float(self.actual_rate)
        self.diff_amt = float(self.physical_amt) - float(self.actual_amt)
        self.physical_amt = float(self.physical_qty) * float(self.physical_rate)
        self.actual_amt = float(self.actual_qty) * float(self.actual_rate)
        super().save(*args, **kwargs)

    class Meta:
        # unique_together = ('organization', 'material', 'store', 'site', 'financialyear')
        db_table = "procurement_physical_stock"


class Indent(BaseAbstractStructure):
    """
    Indent Request
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_indent_organizations', on_delete=models.CASCADE)
    selected_quotation = models.ForeignKey('Quotation', related_name='procurement_indent_selected_quotation', on_delete=models.CASCADE, null=True, blank=True)

    requested_by = models.ForeignKey(PmsUser, related_name='procurement_indent_requested_by', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_indent_site')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_indent_store')
    department = models.ForeignKey(Department, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_indent_department')
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_indent_project')
    previous_version = models.ForeignKey('self', related_name='procurement_indent_previous_version',on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    version = models.IntegerField(default=1)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    location = models.CharField(max_length=200, null=True, blank=True)
    manual_slip_number = models.CharField(max_length=200, null=True, blank=True)
    line_in_bottom = models.CharField(max_length=200, null=True, blank=True)
    already_purchased = models.BooleanField(default=False)
    is_fulfilled = models.BooleanField(default=False)
    total_amount = models.FloatField(default=0)  # not in use
    remarks = models.TextField(max_length=500, null=True, blank=True)  # For materials that was not added in project planning stage
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    current_stage = models.IntegerField(default=0)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_indent_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)
    
    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_indent_material_request", on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='procurement_indent', blank=True, null=True, on_delete=models.CASCADE)

    class Meta:
        db_table = "procurement_indent"


class IndentStages(BaseAbstractStructure):
    """
    Stages
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_indent_stages_organizations',
                                     on_delete=models.CASCADE)
    indent = models.ForeignKey(Indent, related_name='procurement_indent_stages',
                               on_delete=models.CASCADE, null=True, blank=True)
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_stages_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_stages_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_stages_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_stages_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_stages_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    def __str__(self):
        return f"{self.indent} -> {self.stage} {self.status}"

    class Meta:
        db_table = "procurement_indent_stages"
        ordering = ['stage']


class IndentItems(BaseAbstractStructure):
    """
    Indent Items
    """
    PRIORITIES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    TRACKER_STATUS = (
        ('MR Approval Pending', 'MR Approval Pending'),
        ('Waitting For Quotation', 'Waitting For Quotation'),
        ('Quotation awaiting', 'Quotation awaiting'),
        ('CST under approval', 'CST under approval'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_indent_item_organizations',
                                     on_delete=models.CASCADE)
    indent = models.ForeignKey(Indent, related_name='procurement_indent_item_indent',
                               on_delete=models.CASCADE, null=True, blank=True)
    requested_material = models.ForeignKey(VendorMaterialMaster,
                                           related_name='procurement_indent_item_requested_material',
                                           on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                           related_name='procurement_indent_item_requested_machine',
                                           on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_indent_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_indent_items_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_indent_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_indent_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)

    size_part_grade = models.CharField(max_length=100, null=True, blank=True)
    quantity = models.FloatField(default=0)
    sanctioned_quantity = models.FloatField(default=0)
    rejected_quantity = models.FloatField(default=0)
    closed_quantity = models.FloatField(default=0)
    po_closed_quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_indent_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    weight = models.FloatField(default=0)
    requested_for_type = models.CharField(max_length=100, blank=True, null=True)
    requested_for = models.CharField(max_length=100, blank=True, null=True)
    department = models.CharField(max_length=100, null=True, blank=True)
    charge_type = models.CharField(max_length=100, null=True, blank=True)
    is_returnable = models.BooleanField(default=False)
    priority = models.CharField(max_length=100, choices=PRIORITIES, blank=True, null=True, default="low")
    due_date = models.DateField(null=True, blank=True)
    tracker_status = models.CharField(max_length=100, choices=TRACKER_STATUS, blank=True, null=True)
    tracker_remarks = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    rate = models.FloatField(default=0)  # not in use
    amount = models.FloatField(default=0)  # not in use

    ## new
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    budgeted_qty = models.CharField(max_length=200, blank=True, null=True, default="")
    total_received_uptodate = models.CharField(max_length=200, blank=True, null=True, default="")
    stock_on_site = models.CharField(max_length=200, blank=True, null=True, default="")
    application = models.CharField(max_length=200, blank=True, null=True, default="")
    delivery_schedule_date = models.CharField(max_length=200, blank=True, null=True, default="")
    delivery_schedule_day = models.CharField(max_length=200, blank=True, null=True, default="")
    delivery_schedule = models.CharField(max_length=200, blank=True, null=True, default="") # category

    sanctioned_remarks = models.TextField(null=True, blank=True)

    # other model links #
    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_material_indent_item_request", on_delete=models.CASCADE, null=True, blank=True)
    cost_center = models.ForeignKey(CostCenter, related_name='procurement_indent_items_cost_center', on_delete=models.CASCADE, null=True, blank=True)
    gl_account = models.ForeignKey(GLAccount, related_name='procurement_indent_items_gl_account', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_items_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_items_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_items_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_items_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_indent_items_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    def clean(self):
        # Perform custom validation logic before saving the model
        if self.sanctioned_quantity > self.quantity:
            raise ValidationError("Sanctioned quantity is higher than quantity!")
        return super().clean()

    class Meta:
        db_table = "procurement_indent_items"

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.quantity:
            self.quantity = 0
        if not self.sanctioned_quantity:
            self.sanctioned_quantity = 0
        self.amount = float(self.rate) * float(self.quantity)
        super().save(*args, **kwargs)



class IndentItemsNotes(BaseAbstractStructure):
    """
    Indent Items Notes
    """
    organization = models.ForeignKey(Organization, related_name='procurement_indent_items_notes_organization',
                                     on_delete=models.CASCADE)
    indent_items = models.ForeignKey(IndentItems,
                                     related_name='procurement_indent_item_notes',
                                     on_delete=models.CASCADE, null=True, blank=True)
    note_title = models.CharField(max_length=100, blank=True, null=True)
    note_details = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = "procurement_indent_item_notes"


class IndentAttachments(BaseAbstractStructure):
    """
    Indent Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_indent_attachments_organization', on_delete=models.CASCADE)
    master = models.ForeignKey(Indent, related_name='procurement_indent_attachments', on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/indent', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_indent_attachments"


class RFQVendors(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_rfq_vendors_organizations',
                                     on_delete=models.CASCADE)
    selected_quotation = models.ForeignKey('Quotation', related_name='procurement_rfq_vendors_selected_quotation', on_delete=models.CASCADE, null=True, blank=True)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    # vendor_ids = models.TextField(null=True, blank=True) # Remove
    vendor = models.ManyToManyField(VendorMasterV2, related_name='procurement_rfq_vendors_vendor', null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_rfq_site')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_rfq_store')
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_rfq_project')
    request_code = models.CharField(max_length=100, null=True, blank=True)
    manual_slip_number = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    validity_date = models.DateField(null=True, blank=True)
    enquiry_subject = models.CharField(max_length=255, null=True, blank=True)
    jurisdiction = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    terms_and_condition = models.TextField(null=True, blank=True)
    is_repeat_order = models.BooleanField(default=False)

    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_rfq_material_request", on_delete=models.CASCADE, null=True, blank=True)
    material_requests = models.ManyToManyField(MaterialRequestMaster, related_name="procurement_rfq_material_requests",null=True, blank=True)

    indent = models.ForeignKey(Indent, related_name="procurement_rfq_indent", on_delete=models.CASCADE, null=True, blank=True)
    indents= models.ManyToManyField(Indent, related_name="procurement_rfq_indents", null=True, blank=True)

    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_rfq_financial_year', on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_vendors_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_vendors_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_vendors_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_vendors_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_vendors_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    cst_title = models.CharField(max_length=255, null=True, blank=True)
    scope_of_supply = models.TextField(null=True, blank=True)
    is_archived = models.BooleanField(default=False)


class RFQVendorsMailList(BaseAbstractStructure):
    """
    RFQVendors Mails
    """
    organization = models.ForeignKey(Organization, related_name='procurement_rfq_vendors_mail_organizations',
                                     on_delete=models.CASCADE)
    rfq_vendors = models.ForeignKey(RFQVendors, related_name='procurement_rfq_vendors_mails', on_delete=models.CASCADE,
                                    null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_rfq_vendors_mail_vendor',
                               on_delete=models.CASCADE, null=True, blank=True)
    email_send = models.ForeignKey(EmailSend, related_name="procurement_rfq_vendors_mail_email_send",
                                   on_delete=models.CASCADE, null=True, blank=True)
    allow_revision = models.BooleanField(default=True)
    regret = models.BooleanField(default=False)

    class Meta:
        db_table = "procurement_rfq_vendors_mails"


class RFQVendorsItems(BaseAbstractStructure):
    """
    RFQVendors Items
    """
    PRIORITIES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_rfq_vendors_item_organizations',
                                     on_delete=models.CASCADE)
    rfq_vendors = models.ForeignKey(RFQVendors, related_name='procurement_rfq_vendors_items', on_delete=models.CASCADE,
                                    null=True, blank=True)
    requested_material = models.ForeignKey(VendorMaterialMaster,
                                           related_name='procurement_rfq_vendors_item_requested_material',
                                           on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_rfq_vendors_items_gl_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_rfq_vendors_items_gl_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_rfq_vendors_items_gl_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_rfq_vendors_items_gl_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_rfq_vendors_items_gl_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_rfq_vendors_items_gl_uom', on_delete=models.CASCADE, null=True, blank=True)

    size_part_grade = models.CharField(max_length=100, null=True, blank=True)
    weight = models.FloatField(default=0)
    requested_for_type = models.CharField(max_length=100, blank=True, null=True)
    requested_for = models.CharField(max_length=100, blank=True, null=True)
    department = models.CharField(max_length=100, null=True, blank=True)
    charge_type = models.CharField(max_length=100, null=True, blank=True)
    is_returnable = models.BooleanField(default=False)
    priority = models.CharField(max_length=100, choices=PRIORITIES, blank=True, null=True, default="low")
    due_date = models.DateField(null=True, blank=True)
    rate = models.FloatField(default=0)  # not in use
    amount = models.FloatField(default=0)  # not in use

    ## new
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    budgeted_qty = models.CharField(max_length=200, blank=True, null=True, default="")
    total_received_uptodate = models.CharField(max_length=200, blank=True, null=True, default="")
    stock_on_site = models.CharField(max_length=200, blank=True, null=True, default="")
    application = models.CharField(max_length=200, blank=True, null=True, default="")
    delivery_schedule = models.CharField(max_length=200, blank=True, null=True, default="")
    sanctioned_quantity = models.FloatField(default=0)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    
    delivery_schedule_date = models.CharField(max_length=200, blank=True, null=True, default="")
    delivery_schedule_day = models.CharField(max_length=200, blank=True, null=True, default="")
    remarks = models.TextField(null=True, blank=True)
    last_purchased_rate = models.FloatField(default=0)
    last_purchased_reference = models.TextField(max_length=500, null=True, blank=True)

    # other model links #
    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_rfq_vendors_item_request_item", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_rfq_vendors_item_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    cost_center = models.ForeignKey(CostCenter, related_name='procurement_rfq_vendors_items_gl_cost_center', on_delete=models.CASCADE, null=True, blank=True)
    gl_account = models.ForeignKey(GLAccount, related_name='procurement_rfq_vendors_items_gl_account', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.id} {self.requested_material.material_code} -> {self.quantity}"

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.quantity:
            self.quantity = 0
        self.amount = float(self.rate) * float(self.quantity)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_rfq_vendors_items"


class EnquiryAtOnce(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_enquiry_at_once_organizations',
                                     on_delete=models.CASCADE)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_enquiry_at_once_site')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_enquiry_at_once_store')
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_enquiry_at_once_project')
    delivery_state = models.ForeignKey(State, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_enquiry_at_once_delivery_state')
    request_code = models.CharField(max_length=100, null=True, blank=True)
    date = models.DateField(null=True, blank=True)

    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_enquiry_at_once_material_request", on_delete=models.CASCADE, null=True, blank=True)
    material_requests = models.ManyToManyField(MaterialRequestMaster, related_name="procurement_enquiry_at_once_material_requests",null=True, blank=True)

    indent = models.ForeignKey(Indent, related_name="procurement_enquiry_at_once_indent", on_delete=models.CASCADE, null=True, blank=True)
    ##new field add for store multiple indent
    indents= models.ManyToManyField(Indent, related_name="procurement_enquiry_at_once_indents", null=True, blank=True)

    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_enquiry_at_once_financial_year', on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_enquiry_at_once_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_enquiry_at_once_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_enquiry_at_once_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_enquiry_at_once_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_enquiry_at_once_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)


class EnquiryAtOnceVendors(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_enquiry_at_once_vendors_organizations', on_delete=models.CASCADE)
    enquiry_at_once = models.ForeignKey(EnquiryAtOnce, related_name='procurement_enquiry_at_once_vendors', on_delete=models.CASCADE, null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_enquiry_at_once_vendors_vendor', on_delete=models.CASCADE, null=True, blank=True)

class EnquiryAtOnceItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_enquiry_at_once_item_organizations',
                                     on_delete=models.CASCADE)
    enquiry_at_once = models.ForeignKey(EnquiryAtOnce, related_name='procurement_enquiry_at_once_item_enquiry_at_once', on_delete=models.CASCADE, null=True, blank=True)

    requested_material = models.ForeignKey(VendorMaterialMaster,
                                           related_name='procurement_enquiry_at_once_item_requested_material',
                                           on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_enquiry_at_once_items_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_enquiry_at_once_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_enquiry_at_once_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_enquiry_at_once_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_enquiry_at_once_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    size_part_number = models.CharField(max_length=200, null=True, blank=True)
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_enquiry_at_once_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    weight = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_enquiry_at_once_item_excise_tax_head',
                                        on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_enquiry_at_once_item_tax_head',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)

    # other model links #

    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_enquiry_at_once_item_material_request_item", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_enquiry_at_once_item_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    cost_center = models.ForeignKey(CostCenter, related_name='procurement_enquiry_at_once_items_gl_cost_center', on_delete=models.CASCADE, null=True, blank=True)
    gl_account = models.ForeignKey(GLAccount, related_name='procurement_enquiry_at_once_items_gl_account', on_delete=models.CASCADE, null=True, blank=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_enquiry_at_once_items"

class Quotation(BaseAbstractStructure):
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    ADVANCE_PAYMENT = (
        ('Applicable', 'Applicable'),
        ('Not Applicable', 'Not Applicable'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_rfq_quotation_organizations',
                                     on_delete=models.CASCADE)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_rfq_quotation_vendor', on_delete=models.CASCADE,
                               null=True, blank=True)
    vendor_state = models.ForeignKey(State, related_name='procurement_rfq_quotation_vendor_state',
                                     on_delete=models.CASCADE, null=True, blank=True)
    gst_number = models.CharField(max_length=200, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_rfq_quotation_site')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_rfq_quotation_store')
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_rfq_quotation_project')
    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="vat")
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    address = models.TextField(max_length=500, null=True, blank=True)
    previous_version = models.ForeignKey('self', related_name='procurement_quotation_previous_version',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    version = models.IntegerField(default=1)
    vendor_quotation_number = models.CharField(max_length=200, null=True, blank=True)
    delivery_days = models.IntegerField(default=0)
    delivery_state = models.ForeignKey(State, related_name='procurement_rfq_quotation_delivery_state',
                                       on_delete=models.CASCADE, null=True, blank=True)
    payment_mode = models.CharField(max_length=200, null=True, blank=True)
    payment_days = models.IntegerField(default=0)
    purchase_type = models.CharField(max_length=200, null=True, blank=True)
    revised_quotation = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    payment_terms = models.TextField(max_length=500, null=True, blank=True)
    rate_validity = models.TextField(max_length=500, null=True, blank=True)
    warranty = models.TextField(max_length=500, null=True, blank=True)
    inco_term = models.TextField(max_length=500, null=True, blank=True)

    date = models.DateField(null=True, blank=True)
    advance_percentage = models.FloatField(default=0)
    advance_amount = models.FloatField(default=0)
    against_c_form = models.BooleanField(default=False)

    total_before_gst_amount = models.FloatField(default=0)
    total_after_gst_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)

    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    is_repeat_order = models.BooleanField(default=False)

    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_rfq_quotation_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    ## other model links
    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_rfq_quotation_material_request", on_delete=models.CASCADE, null=True, blank=True)
    material_requests = models.ManyToManyField(MaterialRequestMaster, related_name="procurement_rfq_quotation_material_requests",null=True, blank=True)

    indent = models.ForeignKey(Indent, related_name='procurement_rfq_quotation_indent', on_delete=models.CASCADE, null=True, blank=True)
    indents= models.ManyToManyField(Indent, related_name="procurement_rfq_quotation_indents", null=True, blank=True)

    rfq_vendor = models.ForeignKey(RFQVendors, related_name='procurement_rfq_quotation', on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once = models.ForeignKey(EnquiryAtOnce, related_name='procurement_quotation_enquiry_at_once', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_quotation_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_quotation_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_quotation_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_quotation_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_rfq_quotation_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)

    packing_forwarding_by_cst = models.FloatField(default=0)
    transportaion_charges_by_cst = models.FloatField(default=0)
    other_charges_by_cst = models.FloatField(default=0)
    advance_payment_by_cst = models.CharField(max_length=100, choices=ADVANCE_PAYMENT, blank=True, null=True)
    inco_term_one_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_rfq_quotation_inco_term_one_for_sap", on_delete=models.CASCADE)
    location_of_material_source = models.CharField(max_length=255, null=True, blank=True)
    rfq_vendor_rank = models.IntegerField(default=1)
    rfq_vendor_count = models.IntegerField(default=1)
    valid_from = models.DateField(blank=True, null=True,)
    valid_to = models.DateField(blank=True, null=True,)
    class Meta:
        db_table = "procurement_rfq_quotation"
        ordering = ('total_amount', )


class QuotationTermsAndConditions(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_rfq_quotation_terms_and_condition_organizations',
                                     on_delete=models.CASCADE)
    quotation = models.ForeignKey(Quotation, related_name='procurement_rfq_quotation_terms_and_conditions',
                                  on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(TermsAndConditionsChild, related_name='procurement_rfq_quotation_terms_and_conditions_master', on_delete=models.CASCADE, null=True, blank=True)
    key = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    order_id = models.IntegerField(default=0)

    class Meta:
        db_table = "procurement_rfq_quotation_terms_and_conditions"


class QuotationItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_rfq_quotation_item_organizations',
                                     on_delete=models.CASCADE)
    quotation = models.ForeignKey(Quotation, related_name='procurement_rfq_quotation_item', on_delete=models.CASCADE,
                                  null=True, blank=True)
    requested_material = models.ForeignKey(VendorMaterialMaster,
                                           related_name='procurement_rfq_quotation_item_requested_material',
                                           on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_rfq_quotation_items_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_rfq_quotation_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_rfq_quotation_items_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_rfq_quotation_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_rfq_quotation_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    size_part_number = models.CharField(max_length=200, null=True, blank=True)
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_rfq_quotation_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    weight = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_rfq_quotation_item_excise_tax_head',
                                        on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_rfq_quotation_item_tax_head',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)
    last_purchased_rate = models.FloatField(default=0)
    last_purchased_reference = models.TextField(max_length=500, null=True, blank=True)

    selected_by_cst = models.FloatField(default=0)
    quantity_by_cst = models.FloatField(default=0)
    is_selected_by_cst = models.BooleanField(default=False)

    # other model links #

    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_rfq_quotation_item_material_request_item", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_rfq_quotation_item_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor_item = models.ForeignKey(RFQVendorsItems, related_name="procurement_rfq_quotation_item_rfq_vendor_item", on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once_item = models.ForeignKey(EnquiryAtOnceItems, related_name="procurement_rfq_quotation_item_enquiry_at_once_item", on_delete=models.CASCADE, null=True, blank=True)
    cost_center = models.ForeignKey(CostCenter, related_name='procurement_rfq_quotation_items_cost_center', on_delete=models.CASCADE, null=True, blank=True)
    gl_account = models.ForeignKey(GLAccount, related_name='procurement_rfq_quotation_items_gl_account', on_delete=models.CASCADE, null=True, blank=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_rfq_quotation_items"


class QuotationAttachments(BaseAbstractStructure):
    """
    Quotation Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_quotation_attachment_organizations',
                                     on_delete=models.CASCADE)
    quotation = models.ForeignKey(Quotation,
                                  related_name='procurement_quotation_attachment',
                                  on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/quotation', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment_by_cst = models.BooleanField(default=False)

    class Meta:
        db_table = "procurement_quotation_attachments"


class QuotationTaxDetails(BaseAbstractStructure):
    """
    Quotation Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_quotation_tax_organizations',
                                     on_delete=models.CASCADE)
    quotation = models.ForeignKey(Quotation, related_name='procurement_quotation_tax', on_delete=models.CASCADE,
                                  null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_quotation_tax_head', on_delete=models.CASCADE,
                                 null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = Quotation.cmobjects.filter(pk=self.quotation.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.procurement_quotation_tax.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_quotation_tax.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value) * float(self.tax_percentage) / 100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount) * float(self.sgst_percentage) / 100
        self.cgst_amount = float(self.tax_amount) * float(self.cgst_percentage) / 100
        self.igst_amount = float(self.tax_amount) * float(self.igst_percentage) / 100
        self.utgst_amount = float(self.tax_amount) * float(self.utgst_percentage) / 100
        self.cess_amount = float(self.tax_amount) * float(self.cess_percentage) / 100
        self.total_tax_amount = float(self.tax_amount) + float(self.sgst_amount) + float(self.cgst_amount) + float(
            self.igst_amount) + float(self.utgst_amount) + float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_quotation_tax"


class QuotationExpenseDetails(BaseAbstractStructure):
    """
    Quotation Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_quotation_expense_organizations',
                                     on_delete=models.CASCADE)
    quotation = models.ForeignKey(Quotation, related_name='procurement_quotation_expense', on_delete=models.CASCADE,
                                  null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_quotation_expense_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_quotation_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = Quotation.cmobjects.filter(pk=self.quotation.id).first()
        if self.expense_on_parent:
            value = getattr(parent_record, self.expense_on_parent)
        elif self.expense_on_self:
            temp = parent_record.procurement_quotation_expense.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_quotation_expense.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_quotation_expense"

class CST(BaseAbstractStructure):
    """
    Comparison statement (CST)
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    ADVANCE_PAYMENT = (
        ('Applicable', 'Applicable'),
        ('Not Applicable', 'Not Applicable'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_cst_organizations', on_delete=models.CASCADE)

    site = models.ForeignKey(SiteMaster,related_name='procurement_cst_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster,related_name='procurement_cst_store', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_cst_project', on_delete=models.CASCADE, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_cst_financial_year', on_delete=models.CASCADE, blank=True, null=True)
    previous_version = models.ForeignKey('self', related_name='procurement_cst_previous_version',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    version = models.IntegerField(default=1)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
 
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    title = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    cancelled_remarks = models.TextField(null=True, blank=True)
    checked_remarks = models.TextField(null=True, blank=True)
    approved_remarks = models.TextField(null=True, blank=True)
    rejected_remarks = models.TextField(null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    is_repeat_order = models.BooleanField(default=False)
    
    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_cst_material_request", on_delete=models.CASCADE, null=True, blank=True)
    material_requests = models.ManyToManyField(MaterialRequestMaster, related_name="procurement_cst_material_requests",null=True, blank=True)

    indent = models.ForeignKey(Indent, related_name='procurement_cst_indent', on_delete=models.CASCADE, null=True, blank=True)
    indents= models.ManyToManyField(Indent, related_name="procurement_cst_indents", null=True, blank=True)

    rfq_vendor = models.ForeignKey(RFQVendors, related_name='procurement_cst_rfq_vendor', on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once = models.ForeignKey(EnquiryAtOnce, related_name='procurement_cst_enquiry_at_once', on_delete=models.CASCADE, null=True, blank=True)

    advance_payment_by_cst = models.CharField(max_length=100, choices=ADVANCE_PAYMENT, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)
    current_stage = models.IntegerField(default=0)
    is_budgeted = models.BooleanField(default=False)
    
    ##independent Po(direct po)
    is_direct_po= models.BooleanField(default=False)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_cst_vendor', on_delete=models.CASCADE, null=True, blank=True)
    vendor_state = models.ForeignKey(State, related_name='procurement_cst_vendor_state', on_delete=models.CASCADE, null=True, blank=True)
    vendor_currency = models.ForeignKey(VendorCurrencyMaster, related_name='procurement_cst_vendor_currency', on_delete=models.CASCADE, null=True, blank=True)

    quotation_by = models.ForeignKey(PmsUser, related_name='procurement_cst_quotation_by', on_delete=models.CASCADE, null=True, blank=True)
    quotation_by_text = models.CharField(max_length=100, blank=True, null=True, default='')
    quotation_text = models.CharField(max_length=100, blank=True, null=True, default='')
    quotation_date = models.DateField(blank=True, null=True)

    po_code = models.CharField(max_length=200, null=True, blank=True)
    po_for = models.CharField(max_length=200, null=True, blank=True)
    subject = models.TextField(max_length=500, null=True, blank=True)
    purchase_type = models.CharField(max_length=200, null=True, blank=True)
    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, default="vat", blank=True, null=True)
    exchange_rate = models.FloatField(default=1)

    valid_date_from = models.DateField(null=True, blank=True)
    valid_date_to = models.DateField(null=True, blank=True)
    delivery_address1 = models.TextField(max_length=500, null=True, blank=True)
    delivery_address2 = models.TextField(max_length=500, null=True, blank=True)
    delivery_address3 = models.TextField(max_length=500, null=True, blank=True)
    delivery_days = models.IntegerField(null=True, blank=True)
    pay_term = models.CharField(max_length=200, null=True, blank=True)
    for_alerts_delivery_days = models.IntegerField(null=True, blank=True)
    payment_days = models.IntegerField(null=True, blank=True)
    for_alerts_payment_days = models.IntegerField(null=True, blank=True)
    gst_as_billing_state = models.BooleanField(default=False)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, default="material", blank=True, null=True)

    #sap fields
    refrence_for_sap = models.CharField(max_length=200, null=True, blank=True)
    sales_person_for_sap = models.CharField(max_length=200, null=True, blank=True)
    telephone_for_sap = models.CharField(max_length=200, null=True, blank=True)
    inco_term_two_for_sap = models.CharField(max_length=200, null=True, blank=True)
    our_reference_for_sap = models.CharField(max_length=200, null=True, blank=True)
    sales_tax_country_for_sap = models.ForeignKey(Country, blank=True, null=True, related_name="procurement_cst_sales_tax_country_for_sap", on_delete=models.CASCADE)
    pay_term_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_cst_pay_term_for_sap", on_delete=models.CASCADE)
    purchase_org_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_cst_purchase_org_for_sap", on_delete=models.CASCADE)
    purchase_group_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_cst_purchase_group_for_sap", on_delete=models.CASCADE)
    inco_term_one_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_cst_inco_term_one_for_sap", on_delete=models.CASCADE)
    company_code_for_sap = models.ForeignKey('administrations.Company', blank=True, null=True, related_name="procurement_cst_company_code_for_sap", on_delete=models.CASCADE)
    is_asset_for_sap = models.BooleanField(default=False)
    is_expense_for_sap = models.BooleanField(default=False)
    line_before_items = models.TextField(max_length=500, null=True, blank=True)
    line_in_bottom = models.TextField(max_length=500, null=True, blank=True)
    party_bank = models.CharField(max_length=200, null=True, blank=True)
    is_submitted = models.BooleanField(default=False)

    total_before_gst_amount = models.FloatField(default=0)
    total_after_gst_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    total_amount_without_gst = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    with_gst = models.BooleanField(default=True)
    is_project_for_sap = models.BooleanField(default=False)
    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)

    #tax
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)

    #expense
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    on_hold = models.BooleanField(default=False)
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='procurement_cst_ref_stage_type', blank=True, null=True, on_delete=models.CASCADE)


    def __str__(self):
        return f"{self.site} Site Requested {self.store} Store"

    class Meta:
        db_table = "procurement_cst"


class CSTStages(BaseAbstractStructure):
    """
    Stages
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('hold', 'Hold'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_cst_stages_organizations', on_delete=models.CASCADE)
    cst = models.ForeignKey(CST, related_name='procurement_cst_stages', on_delete=models.CASCADE, null=True, blank=True)
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_stages_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_stages_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_stages_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_stages_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_cst_stages_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    is_web = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.cst} -> {self.stage} {self.status}"

    class Meta:
        db_table = "procurement_cst_stages"

class CSTItems(BaseAbstractStructure):
    ExpiryDateInd = (
        ('D', 'D'),
        ('M', 'M'),
        ('W', 'W'),
        ('Y', 'Y'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_cst_item_organizations',
                                     on_delete=models.CASCADE)
    cst = models.ForeignKey(CST, related_name='procurement_cst_item_cst', on_delete=models.CASCADE, null=True, blank=True)

    requested_material = models.ForeignKey(VendorMaterialMaster,
                                           related_name='procurement_cst_item_requested_material',
                                           on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_cst_items_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_cst_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_cst_items_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_cst_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_cst_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    size_part_number = models.CharField(max_length=200, null=True, blank=True)
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_cst_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    weight = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_cst_item_excise_tax_head',
                                        on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_cst_item_tax_head',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)
    last_purchased_rate = models.FloatField(default=0)
    last_purchased_reference = models.TextField(max_length=500, null=True, blank=True)
    business_area = models.CharField(max_length=200, blank=True, null=True, default="")

    # other model links #

    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_cst_item_material_request_item", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_cst_item_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor_item = models.ForeignKey(RFQVendorsItems, related_name="procurement_cst_item_rfq_vendor_item", on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once_item = models.ForeignKey(EnquiryAtOnceItems, related_name="procurement_cst_item_enquiry_at_once_item", on_delete=models.CASCADE, null=True, blank=True)
    cost_center = models.ForeignKey(CostCenter, related_name='procurement_cst_items_cost_center', on_delete=models.CASCADE, null=True, blank=True)
    gl_account = models.ForeignKey(GLAccount, related_name='procurement_cst_items_gl_account', on_delete=models.CASCADE, null=True, blank=True)

    #Independent PO(direct-po) fields#
    asset_no_for_sap = models.CharField(max_length=200, blank=True, null=True, default="")
    wbs_temp_planning_for_sap = models.ForeignKey(WbsTempPlaning, blank=True, null=True, related_name="procurement_cst_items_wbs_temp_planning_for_sap", on_delete=models.CASCADE)
    tax_code_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_cst_items_tax_code_for_sap", on_delete=models.CASCADE)
    goods_receipt_date_for_sap = models.DateField(null=True, blank=True)
    expiry_date_ind_for_sap = models.CharField(max_length=100, choices=ExpiryDateInd, blank=True, null=True, default="D")
    storage_location_for_sap = models.ForeignKey(StoreSection, blank=True, null=True, related_name="procurement_cst_items_storage_location_for_sap", on_delete=models.CASCADE)
    delivery_date = models.DateField(null=True, blank=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_cst_items"

class CSTAttachments(BaseAbstractStructure):
    """
    CST Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_cst_attachments_organizations',
                                     on_delete=models.CASCADE)
    cst = models.ForeignKey(CST, related_name='procurement_cst_attachments_cst',
                                       on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/cst', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_cst_attachments"

class CSTTermsAndConditions(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_cst_terms_and_conditions_organizations',
                                     on_delete=models.CASCADE)
    cst = models.ForeignKey(CST, related_name='procurement_cst_terms_and_conditions_cst',
                                       on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(TermsAndConditionsChild, related_name='procurement_cst_terms_and_conditions_master', on_delete=models.CASCADE, null=True, blank=True)
    key = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(null=True, blank=True, default='')
    order_id = models.IntegerField(default=0, blank=True, null=True)
    is_checked = models.BooleanField(blank=True, null=True, default=True)

    class Meta:
        db_table = "procurement_cst_terms_and_conditions"


class CSTTaxDetails(BaseAbstractStructure):
    """
    CST Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_cst_tax_organizations',
                                     on_delete=models.CASCADE)
    cst = models.ForeignKey(CST,related_name='procurement_cst_tax_cst',on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_cst_tax_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = CST.cmobjects.filter(pk=self.cst.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.procurement_cst_tax_cst.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_cst_tax_cst.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.tax_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.tax_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.tax_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.tax_amount)*float(self.cess_percentage)/100
        self.total_tax_amount = float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_cst_tax"


class CSTExpenseDetails(BaseAbstractStructure):
    """
    CST Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_cst_expense_organizations',
                                     on_delete=models.CASCADE)
    cst = models.ForeignKey(CST,related_name='procurement_cst_expense_cst',
                                       on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_cst_expense_expense_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_cst_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = CST.cmobjects.filter(pk=self.cst.id).first()
        if self.expense_on_parent:
            value = getattr(parent_record, self.expense_on_parent)
        elif self.expense_on_self:
            temp = parent_record.procurement_cst_expense_cst.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_cst_expense_cst.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_cst_expense"


class ProcurementStatusOfOrder(BaseAbstractStructure):
    name = models.CharField(max_length=200, null=True, blank=True)
    delivered = models.BooleanField(default=False)

    class Meta:
        db_table = 'procurement_status_of_order'


class PurchaseOrder(BaseAbstractStructure):
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_order_organizations',
                                     on_delete=models.CASCADE)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_purchase_order_site')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_purchase_order_store')
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_purchase_order_project')
    billing_site = models.ForeignKey(SiteMaster, related_name='procurement_purchase_order_billing_site',
                                     on_delete=models.CASCADE, null=True, blank=True)
    billing_state = models.ForeignKey(State, related_name='procurement_purchase_order_billing_state',
                                      on_delete=models.CASCADE, null=True, blank=True)
    delivery_site = models.ForeignKey(SiteMaster, related_name='procurement_purchase_order_delivery_site',
                                      on_delete=models.CASCADE, null=True, blank=True)
    delivery_state = models.ForeignKey(State, related_name='procurement_purchase_order_delivery_state',
                                       on_delete=models.CASCADE, null=True, blank=True)
    job_site = models.ForeignKey(SiteMaster, related_name='procurement_purchase_order_job_site',
                                 on_delete=models.CASCADE, null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_purchase_order_vendor',
                               on_delete=models.CASCADE, null=True, blank=True)
    vendor_state = models.ForeignKey(State, related_name='procurement_purchase_order_vendor_state',
                                     on_delete=models.CASCADE, null=True, blank=True)
    quotation_by = models.ForeignKey(PmsUser, related_name='procurement_purchase_order_quotation_by',
                                     on_delete=models.CASCADE, null=True, blank=True)
    quotation_by_text = models.CharField(blank=True, null=True, default='', max_length=100)
    quotation_text = models.CharField(blank=True, null=True, default='', max_length=100)
    quotation_date = models.DateField(blank=True, null=True)
    vendor_currency = models.ForeignKey(VendorCurrencyMaster, related_name='procurement_purchase_order_vendor_currency',
                                        on_delete=models.CASCADE, null=True, blank=True)
    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="vat")
    previous_version = models.ForeignKey('self', related_name='procurement_po_previous_version',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    po_code = models.CharField(max_length=200, null=True, blank=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    version = models.IntegerField(default=1)
    current_stage = models.IntegerField(default=0)
    is_draft = models.BooleanField(default=True)

    date = models.DateField(null=True, blank=True)
    po_for = models.CharField(max_length=200, null=True, blank=True)
    valid_date_from = models.DateField(null=True, blank=True)
    valid_date_to = models.DateField(null=True, blank=True)
    subject = models.TextField(max_length=500, null=True, blank=True)
    party_bank = models.CharField(max_length=200, null=True, blank=True)
    line_before_items = models.TextField(max_length=500, null=True, blank=True)
    exchange_rate = models.FloatField(default=1)
    purchase_type = models.CharField(max_length=200, null=True, blank=True)

    delivery_address1 = models.TextField(max_length=500, null=True, blank=True)
    delivery_address2 = models.TextField(max_length=500, null=True, blank=True)
    delivery_address3 = models.TextField(max_length=500, null=True, blank=True)
    gst_as_billing_state = models.BooleanField(default=False)
    line_in_bottom = models.TextField(max_length=500, null=True, blank=True)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    delivery_days = models.IntegerField(null=True, blank=True)
    for_alerts_delivery_days = models.IntegerField(null=True, blank=True)
    payment_days = models.IntegerField(null=True, blank=True)
    for_alerts_payment_days = models.IntegerField(null=True, blank=True)
    total_before_gst_amount = models.FloatField(default=0)
    total_after_gst_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    total_amount_without_gst = models.FloatField(default=0)
    with_gst = models.BooleanField(default=True)
    
    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_item_expense_expense_amount = models.FloatField(default=0)
    total_item_expense_sgst_amount = models.FloatField(default=0)
    total_item_expense_cgst_amount = models.FloatField(default=0)
    total_item_expense_igst_amount = models.FloatField(default=0)
    total_item_expense_utgst_amount = models.FloatField(default=0)
    total_item_expense_cess_amount = models.FloatField(default=0)
    total_item_expense_total_expense_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)

    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_purchase_order_financial_year', on_delete=models.CASCADE, blank=True, null=True)

    ## other model link
    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_purchase_order_material_request", on_delete=models.CASCADE, null=True, blank=True)
    material_requests = models.ManyToManyField(MaterialRequestMaster, related_name="procurement_purchase_order_material_requests",null=True, blank=True)

    indent = models.ForeignKey(Indent, related_name='procurement_purchase_order_indent', on_delete=models.CASCADE, null=True, blank=True)
    indents= models.ManyToManyField(Indent, related_name="procurement_purchase_order_indents", null=True, blank=True)

    rfq_vendor = models.ForeignKey(RFQVendors, related_name='procurement_purchase_order_rfq_vendor', on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once = models.ForeignKey(EnquiryAtOnce, related_name='procurement_purchase_order_enquiry_at_once', on_delete=models.CASCADE, null=True, blank=True)
    quotation = models.ForeignKey(Quotation, related_name='procurement_purchase_order_quotation', on_delete=models.CASCADE, null=True, blank=True)
    cst = models.ForeignKey(CST, related_name='procurement_purchase_order_cst', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)
    
    sap_code = models.CharField(max_length=200, null=True, blank=True)
    final_releaser_from_sap = models.CharField(max_length=200, null=True, blank=True)
    final_release_date_from_sap = models.DateField(null=True, blank=True)
    final_release_time_from_sap = models.TimeField(null=True, blank=True)
    release_strategy_from_sap = models.CharField(max_length=200, null=True, blank=True)
    document_date_from_sap = models.CharField(max_length=200, null=True, blank=True)
    purchasing_group_from_sap = models.CharField(max_length=200, null=True, blank=True)
    attachment_from_sap = models.FileField(upload_to='sap/purchase_order', null=True, blank=True)
    sap_resp = models.JSONField(null=True, blank=True)

    is_asset_for_sap = models.BooleanField(default=False)
    is_expense_for_sap = models.BooleanField(default=False)
    is_project_for_sap = models.BooleanField(default=False)
    refrence_for_sap = models.CharField(max_length=200, null=True, blank=True)
    sales_person_for_sap = models.CharField(max_length=200, null=True, blank=True)
    telephone_for_sap = models.CharField(max_length=200, null=True, blank=True)
    inco_term_two_for_sap = models.CharField(max_length=200, null=True, blank=True)
    our_reference_for_sap = models.CharField(max_length=200, null=True, blank=True)
    sales_tax_country_for_sap = models.ForeignKey(Country, blank=True, null=True, related_name="procurement_purchase_order_sales_tax_country_for_sap", on_delete=models.CASCADE)
    pay_term_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_purchase_order_pay_term_for_sap", on_delete=models.CASCADE)
    purchase_org_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_purchase_order_purchase_org_for_sap", on_delete=models.CASCADE)
    purchase_group_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_purchase_order_purchase_group_for_sap", on_delete=models.CASCADE)
    inco_term_one_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_purchase_order_inco_term_one_for_sap", on_delete=models.CASCADE)
    # company_code_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_purchase_order_company_code_for_sap", on_delete=models.CASCADE)
    company_code_for_sap = models.ForeignKey('administrations.Company', blank=True, null=True, related_name="procurement_purchase_order_company_code_for_sap", on_delete=models.CASCADE)
    extra=models.JSONField(blank=True,null=True)
    retention = models.CharField(max_length=200, null=True, blank=True)
    dp_category = models.CharField(max_length=200, null=True, blank=True)
    dp_amount = models.FloatField(default=0)
    dp_percent = models.FloatField(default=0)
    dp_due_date = models.DateField(null=True, blank=True)
    is_unlinked_po = models.BooleanField(default=False)
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='procurement_purchase_order_ref_stage_type', blank=True, null=True, on_delete=models.CASCADE)
    class Meta:
        db_table = "procurement_purchase_order"

    # def save(self, *args, **kwargs):
    #     self.full_clean()
    #     try:
    #         payment_schedules = self.procurement_purchase_order_payment_schedule.filter(is_deleted=False).aggregate(total_percent=Sum('percent'))
    #         if 'total_percent' in payment_schedules:
    #             if payment_schedules['total_percent'] == 100:
    #                 self.is_draft = False
    #             else:
    #                 self.is_draft = True
    #         else:
    #             self.is_draft = True
    #     except Exception as e:
    #         print(e)
    #     super().save(*args, **kwargs)


class PurchaseOrderStages(BaseAbstractStructure):
    """
    Stages
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_order_stages_organizations',
                                     on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_purchase_order_stages',
                               on_delete=models.CASCADE, null=True, blank=True)
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_stages_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_stages_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_stages_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_stages_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_order_stages_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    def __str__(self):
        return f"{self.purchase_order} -> {self.stage} {self.status}"

    class Meta:
        db_table = "procurement_purchase_order_stages"


class PurchaseOrderItems(BaseAbstractStructure):
    ExpiryDateInd = (
        ('D', 'D'),
        ('M', 'M'),
        ('W', 'W'),
        ('Y', 'Y'),
    )
    TRACKER_CODE = (
        ('TRA', 'TRA'),
        ('UA', 'UA'),
        ('GR', 'GR'),
        ('PGR', 'PGR'),
        ('HOLD', 'HOLD'),
    )
    EXCESS_ACTION = (
        ('Required a PO','Required a PO'),
        ('Within tolerance','Within tolerance'),
    )
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_purchase_order_item',
                                       on_delete=models.CASCADE, null=True, blank=True)
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_order_item_organizations',
                                     on_delete=models.CASCADE)
    item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_purchase_order_item_material',
                             on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_purchase_order_items_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_purchase_order_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_purchase_order_items_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_purchase_order_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_purchase_order_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    size_part_no_grade = models.CharField(max_length=200, null=True, blank=True)
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    weight = models.FloatField(default=0)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_purchase_order_items_gl_uom', on_delete=models.CASCADE, null=True, blank=True)
    tolerance_percentage = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_order_items_excise_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_order_items_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)

    
    # other model links #

    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_purchase_order_item_material_request_item", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_purchase_order_item_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor_item = models.ForeignKey(RFQVendorsItems, related_name="procurement_purchase_order_item_rfq_vendor_item", on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once_item = models.ForeignKey(EnquiryAtOnceItems, related_name="procurement_purchase_order_item_enquiry_at_once_item", on_delete=models.CASCADE, null=True, blank=True)

    quotation_item = models.ForeignKey(QuotationItems, related_name="procurement_purchase_order_item_quotation_item", on_delete=models.CASCADE, null=True, blank=True)
    cst_item= models.ForeignKey(CSTItems, related_name='procurement_purchase_order_item_cst_item', on_delete=models.CASCADE, null=True, blank=True)
    cost_center = models.ForeignKey(CostCenter, related_name='procurement_purchase_order_items_gl_cost_center', on_delete=models.CASCADE, null=True, blank=True)
    gl_account = models.ForeignKey(GLAccount, related_name='procurement_purchase_order_items_gl_account', on_delete=models.CASCADE, null=True, blank=True)
    business_area = models.CharField(max_length=200, blank=True, null=True, default="")

    asset_no_for_sap = models.CharField(max_length=200, blank=True, null=True, default="")
    wbs_temp_planning_for_sap = models.ForeignKey(WbsTempPlaning, blank=True, null=True, related_name="procurement_purchase_order_items_wbs_temp_planning_for_sap", on_delete=models.CASCADE)
    tax_code_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_purchase_order_items_tax_code_for_sap", on_delete=models.CASCADE)
    goods_receipt_date_for_sap = models.DateField(null=True, blank=True)
    expiry_date_ind_for_sap = models.CharField(max_length=100, choices=ExpiryDateInd, blank=True, null=True, default="D")
    delivery_date = models.DateField(null=True, blank=True)
    storage_location_for_sap = models.ForeignKey(StoreSection, blank=True, null=True, related_name="procurement_purchase_order_items_storage_location_for_sap", on_delete=models.CASCADE)

    status_of_order = models.ForeignKey(ProcurementStatusOfOrder, related_name='procurement_purchase_order_items_status_of_order', on_delete=models.CASCADE, null=True, blank=True)
    edd = models.DateField(null=True, blank=True)
    is_delivered = models.BooleanField(blank=True, null=True, default=False)
    delivered_date = models.DateField(null=True, blank=True)
    tracker_code = models.CharField(max_length=100, choices=TRACKER_CODE, blank=True, null=True)
    tracker_remarks = models.TextField(null=True, blank=True)
    manual_received_quantity = models.FloatField(default=0)
    manual_return_quantity = models.FloatField(default=0)
    manual_quantity_remarks = models.TextField(null=True, blank=True)
    excess_action = models.CharField(max_length=100, choices=EXCESS_ACTION, blank=True, null=True,)
    sap_item_no = models.IntegerField(default=0)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_order_items"


class PurchaseOrderAttachments(BaseAbstractStructure):
    """
    Quotation Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_order_attachment_organizations',
                                     on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_purchase_order_attachment',
                                       on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/purchase_order', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_purchase_order_attachments"


class PurchaseOrderItemsNotes(BaseAbstractStructure):
    """
    Purchase Order Items
    """
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_order_note_organizations',
                                     on_delete=models.CASCADE)
    purchase_order_item = models.ForeignKey(PurchaseOrderItems, related_name='procurement_purchase_order_item_note',
                                            on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(TermsAndConditionsChild, related_name='procurement_purchase_order_item_notes_master', on_delete=models.CASCADE, null=True, blank=True)
    note_title = models.CharField(max_length=100, blank=True, null=True)
    note_details = models.CharField(max_length=255, blank=True, null=True)
    order_id = models.IntegerField(default=0, blank=True, null=True)
    is_checked = models.BooleanField(blank=True, null=True, default=True)

    class Meta:
        db_table = "procurement_purchase_order_item_notes"


class PurchaseOrderItemsExpenseDetails(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_order_item_expense_organizations', on_delete=models.CASCADE)
    purchase_order_item = models.ForeignKey(PurchaseOrderItems, related_name='procurement_purchase_order_item_expense', on_delete=models.CASCADE, null=True, blank=True)
    expense_on = models.FloatField(default=0)
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_purchase_order_item_expense_expense_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_order_item_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        if self.expense_percentage != 0:
            self.expense_amount = float(self.expense_on)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_order_item_expense"


class PurchaseOrderPaymentSchedule(BaseAbstractStructure):
    """
    Purchase Order Payment Schedule
    """
    PERCENT_TYPE = (
        ('bg', 'BG'),
        ('lc', 'LC (LETTER OF CREDIT)'),
        ('before_dispatch', 'BEFORE DISPATCH'),
        ('advance', 'ADVANCE'),
        ('after_delivery', 'AFTER DELIVERY'),
        ('after_days', 'AFTER DAYS'),
        ('other', 'OTHER'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_purchase_order_payment_schedule_organizations',
                                     on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_purchase_order_payment_schedule',
                                       on_delete=models.CASCADE, null=True, blank=True)
    percent = models.FloatField(default=0)
    percent_type = models.CharField(max_length=100, choices=PERCENT_TYPE, null=True, blank=True)
    payment_credit_days = models.IntegerField(default=0)
    notify_days = models.IntegerField(default=0)
    description = models.TextField(max_length=500, null=True, blank=True)
    amount = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.percent:
            self.percent = 0
        parent_record = PurchaseOrder.cmobjects.filter(pk=self.purchase_order.id).first()
        self.amount = float(parent_record.total_amount)*float(self.percent)/100
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_order_payment_schedule"


class PurchaseOrderPaymentScheduleAttachments(BaseAbstractStructure):
    """
    PurchaseOrderPaymentScheduleAttachments model
    """
    organization = models.ForeignKey(Organization, related_name='procurement_po_payment_schedule_attachments_organization', on_delete=models.CASCADE)
    master = models.ForeignKey(PurchaseOrderPaymentSchedule, related_name='procurement_po_payment_schedule_attachments',on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/purchase_order/payment_schedule', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_po_payment_schedule_attachments"


class PurchaseOrderTermsAndConditions(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_terms_and_conditions_organizations',
                                     on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_terms_and_conditions',
                                       on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(TermsAndConditionsChild, related_name='procurement_terms_and_conditions_master', on_delete=models.CASCADE, null=True, blank=True)
    key = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(null=True, blank=True, default='')
    order_id = models.IntegerField(default=0, blank=True, null=True)
    is_checked = models.BooleanField(blank=True, null=True, default=True)

    class Meta:
        db_table = "procurement_terms_and_conditions"


class PurchaseOrderTaxDetails(BaseAbstractStructure):
    """
    Purchase order Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_po_tax_organizations',
                                     on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder,
                                       related_name='procurement_po_tax',
                                       on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_order_tax_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = PurchaseOrder.cmobjects.filter(pk=self.purchase_order.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.procurement_po_tax.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_po_tax.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.tax_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.tax_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.tax_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.tax_amount)*float(self.cess_percentage)/100
        self.total_tax_amount = float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_order_tax"


class PurchaseOrderExpenseDetails(BaseAbstractStructure):
    """
    Purchase order Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_po_expense_organizations',
                                     on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder,
                                       related_name='procurement_po_expense',
                                       on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_purchase_order_expense_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_order_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = PurchaseOrder.cmobjects.filter(pk=self.purchase_order.id).first()
        if self.expense_on_parent:
            value = getattr(parent_record, self.expense_on_parent)
        elif self.expense_on_self:
            temp = parent_record.procurement_po_expense.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_po_expense.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_order_expense"


class PurchaseOrderDeliveryLocation(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_po_delivery_loc_organizations',
                                     on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_po_delivery_loc',
                                       on_delete=models.CASCADE, null=True, blank=True)
    delivery_location = models.CharField(max_length=200, null=True, blank=True)
    contact_person = models.CharField(max_length=200, null=True, blank=True)
    goods_percentage = models.FloatField(default=0, null=True, blank=True)

    class Meta:
        db_table = "procurement_purchase_order_delivery_location"


class PlantProduction(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_plant_production_organizations', on_delete=models.CASCADE)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    vehicle_number = models.CharField(max_length=200, null=True, blank=True)
    manual_slip_number = models.CharField(max_length=200, null=True, blank=True)
    receive_date = models.DateField(null=True, blank=True)
    receive_reading = models.CharField(max_length=200, null=True, blank=True)
    production_type = models.CharField(max_length=200, null=True, blank=True)
    dc_no = models.CharField(max_length=200, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_plant_production_project', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_plant_production_store', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_plant_production_site', on_delete=models.CASCADE, null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_plant_production_vendor', on_delete=models.CASCADE, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_plant_production_financial_year', on_delete=models.CASCADE, blank=True, null=True)

    class Meta:
        db_table = "procurement_plant_production"


class PlantProductionItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_plant_production_item_organizations', on_delete=models.CASCADE)
    plant_production = models.ForeignKey(PlantProduction, related_name="procurement_plant_production_items", null=True, blank=True, on_delete=models.CASCADE)
    item = models.ForeignKey(VendorMaterialMaster, related_name="procurement_plant_production_item_material", null=True, blank=True, on_delete=models.CASCADE)
    quantity = models.FloatField(default=0)
    unit = models.ForeignKey(UnitOfMesurement, related_name="procurement_plant_production_items_unit", null=True, blank=True, on_delete=models.CASCADE)

    class Meta:
        db_table = "procurement_plant_production_items"


class WayBillForm(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_way_bill_form_organizations',
                                     on_delete=models.CASCADE)
    way_bill_form_no = models.CharField(max_length=200, null=True, blank=True)
    is_issued_by_party = models.BooleanField(default=False)
    vendor = models.ForeignKey(VendorMasterV2, on_delete=models.CASCADE, related_name='procurement_way_bill_form_vendor',
                               null=True, blank=True)
    issued_date = models.DateField(null=True, blank=True)
    is_used_date = models.BooleanField(default=False)
    used_date = models.DateField(null=True, blank=True)
    entry_in_state = models.ForeignKey(State,  on_delete=models.CASCADE,
                                       related_name='procurement_way_bill_form_entry_in_state',
                                       null=True, blank=True)
    issue_details = models.TextField(null=True, blank=True)
    used_details = models.TextField(null=True, blank=True)

    def __str__(self):
        return str(self.way_bill_form_no)

    class Meta:
        db_table = "procurement_way_bill_form"


class WayBillFormItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_way_bill_form_items_organizations',
                                     on_delete=models.CASCADE)
    way_bill_form = models.ForeignKey(WayBillForm, related_name='procurement_way_bill_form_items', on_delete=models.CASCADE,
                                      null=True, blank=True)
    bill_no = models.CharField(max_length=200, null=True, blank=True)
    bill_date = models.DateField(null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, on_delete=models.CASCADE, related_name='procurement_way_bill_form_item', null=True, blank=True)
    quantity = models.FloatField(default=0)
    bill_amount = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_way_bill_form_items"


class WayBillFormAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_way_bill_form_attachment_organizations',
                                     on_delete=models.CASCADE)
    way_bill_form = models.ForeignKey(WayBillForm, related_name='procurement_way_bill_form_attachments',
                                      on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/way_bill_form', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_way_bill_form_attachments"


class GRN(BaseAbstractStructure):
    LOADED_VIA = (
        ('self', 'Self'),
        ('party', 'Party'),
    )
    RECEIVED_FROM = (
        ('supplier_transfer', 'Supplier/Transfer'),
        ('customer', 'Customer'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_grn_organizations',
                                     on_delete=models.CASCADE)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_grn_site')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_grn_store')
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_grn_project')

    grn_no = models.CharField(max_length=200, null=True, blank=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    manual_slip_no = models.CharField(max_length=200, null=True, blank=True)
    unload_date = models.DateField(null=True, blank=True)
    unload_time = models.TimeField(null=True, blank=True)
    loaded_via = models.CharField(max_length=50, choices=LOADED_VIA, null=True, blank=True, default="self")
    job_site = models.ForeignKey(SiteMaster, related_name='procurement_grn_job_site', on_delete=models.CASCADE,
                                 null=True, blank=True)
    party_bill_amt = models.FloatField(default=0)
    lab_report_no = models.CharField(max_length=200, null=True, blank=True)
    e_way_bill_no = models.CharField(max_length=200, null=True, blank=True)
    party_bill_no = models.CharField(max_length=200, null=True, blank=True)
    party_bill_date = models.DateField(null=True, blank=True)
    bill_date = models.DateField(null=True, blank=True)
    cash_payment = models.BooleanField(default=False)
    cash_payment_account = models.ForeignKey(AccountsHead, related_name='procurement_grn_cash_payment_account',
                                             on_delete=models.CASCADE, null=True, blank=True)
    challan_no = models.CharField(max_length=200, null=True, blank=True)
    challan_date = models.DateField(null=True, blank=True)
    gate_pass_no = models.CharField(max_length=200, null=True, blank=True)
    rst_no = models.CharField(max_length=200, null=True, blank=True)
    # transporter = models.CharField(max_length=200, null=True, blank=True)
    transporter = models.ForeignKey(VendorMasterV2, related_name='procurement_grn_transporter',
                                             on_delete=models.CASCADE, null=True, blank=True)
    other = models.CharField(max_length=200, null=True, blank=True)
    lr_no = models.CharField(max_length=200, null=True, blank=True)
    lr_date = models.DateField(null=True, blank=True)
    carrying_vehicle_no = models.CharField(max_length=200, null=True, blank=True)
    reading = models.CharField(max_length=200, null=True, blank=True)
    driver_name = models.CharField(max_length=200, null=True, blank=True)
    receive_location = models.CharField(max_length=200, null=True, blank=True)
    received_from = models.CharField(max_length=50, choices=RECEIVED_FROM, null=True, blank=True,
                                     default="supplier_transfer")
    received_by = models.ForeignKey(PmsUser, related_name='procurement_grn_received_by',
                                    on_delete=models.CASCADE, null=True, blank=True)
    arrival_date = models.DateField(null=True, blank=True)
    arrival_time = models.TimeField(null=True, blank=True)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    line_in_bottom = models.TextField(max_length=500, null=True, blank=True)
    create_material_issue = models.BooleanField(default=False)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_grn_vendor',
                               on_delete=models.CASCADE, null=True, blank=True)
    vendor_currency = models.ForeignKey(VendorCurrencyMaster, related_name='procurement_grn_vendor_currency',
                                        on_delete=models.CASCADE, null=True, blank=True)
    exchange_rate = models.FloatField(default=1)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    total_po_pending_quantity = models.FloatField(default=0)
    total_challan_quantity = models.FloatField(default=0)
    total_received_quantity = models.FloatField(default=0)
    total_return_quantity = models.FloatField(default=0)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_grn_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)
    plant_production = models.ForeignKey(PlantProduction, related_name="procurement_grn_transfer",
                              on_delete=models.CASCADE, null=True, blank=True)
    way_bill_form = models.ForeignKey(WayBillForm, related_name="procurement_grn_way_bill_form",
                              on_delete=models.CASCADE, null=True, blank=True)

    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="gst")
    is_igst = models.BooleanField(default=False)

    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    
    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_grn_material_request", on_delete=models.CASCADE, null=True, blank=True)
    material_requests = models.ManyToManyField(MaterialRequestMaster, related_name="procurement_grn_material_requests",null=True, blank=True)

    indent = models.ForeignKey(Indent, related_name='procurement_grn_indent', on_delete=models.CASCADE, null=True, blank=True)
    indents= models.ManyToManyField(Indent, related_name="procurement_grn_indents", null=True, blank=True)

    rfq_vendor = models.ForeignKey(RFQVendors, related_name='procurement_grn_rfq_vendor', on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once = models.ForeignKey(EnquiryAtOnce, related_name='procurement_grn_enquiry_at_once', on_delete=models.CASCADE, null=True, blank=True)
    quotation = models.ForeignKey(Quotation, related_name='procurement_grn_quotation', on_delete=models.CASCADE, null=True, blank=True)
    cst = models.ForeignKey(CST, related_name='procurement_grn_cst', on_delete=models.CASCADE, null=True, blank=True)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_grn_purchase_orders', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_grn_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_grn_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_grn_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_grn_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_grn_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)

    movement_type = models.CharField(max_length=200, null=True, blank=True)
    batch = models.CharField(max_length=200, null=True, blank=True)
    sap_code = models.CharField(max_length=200, null=True, blank=True) 
    reference = models.CharField(max_length=200, null=True, blank=True)
    entered_on = models.CharField(max_length=200, null=True, blank=True)
    plant = models.CharField(max_length=200, null=True, blank=True)
    storage_location = models.CharField(max_length=200, null=True, blank=True)
    header_text = models.CharField(max_length=200, null=True, blank=True)
    company_code = models.CharField(max_length=200, null=True, blank=True)
    material_year = models.CharField(max_length=200, null=True, blank=True)
    event_type = models.CharField(max_length=200, null=True, blank=True)
    valuation_type = models.CharField(max_length=200, null=True, blank=True)
    user_name = models.CharField(max_length=200, null=True, blank=True)
    name1 = models.CharField(max_length=200, null=True, blank=True)
    name2 = models.CharField(max_length=200, null=True, blank=True)
    pur_org = models.CharField(max_length=200, null=True, blank=True)
    movement_type_text = models.CharField(max_length=200, null=True, blank=True)
    doc_header_text = models.CharField(max_length=200, null=True, blank=True)
    time = models.CharField(max_length=200, null=True, blank=True)
    reason_movement = models.CharField(max_length=200, null=True, blank=True)
    movement_indicator = models.CharField(max_length=200, null=True, blank=True)
    currency = models.CharField(max_length=200, null=True, blank=True)
    cost_center = models.CharField(max_length=200, null=True, blank=True)
    gl = models.CharField(max_length=200, null=True, blank=True)
    text = models.CharField(max_length=200, null=True, blank=True)

    sales_order = models.CharField(max_length=200, null=True, blank=True)
    salesorder = models.CharField(max_length=200, null=True, blank=True)
    customer = models.CharField(max_length=200, null=True, blank=True)
    receipt_indicator = models.CharField(max_length=200, null=True, blank=True)
    gate_entry_no = models.CharField(max_length=200, null=True, blank=True)
    vehicle_no = models.CharField(max_length=200, null=True, blank=True)
    name3 = models.CharField(max_length=200, null=True, blank=True)
    name4 = models.CharField(max_length=200, null=True, blank=True)
    confirmation_no = models.CharField(max_length=200, null=True, blank=True)
    confirmation_text1 = models.CharField(max_length=200, null=True, blank=True)
    confirmation_text2 = models.CharField(max_length=200, null=True, blank=True)
    confirmation_text3 = models.CharField(max_length=200, null=True, blank=True)
    confirmation_text4 = models.CharField(max_length=200, null=True, blank=True)
    gate_entry_date = models.CharField(max_length=200, null=True, blank=True)
    class Meta:
        db_table = "procurement_grn"


class GRNItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_grn_item_organizations',
                                     on_delete=models.CASCADE)
    grn = models.ForeignKey(GRN, related_name='procurement_grn_item',
                            on_delete=models.CASCADE, null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_grn_item_material',
                             on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_grn_items_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_grn_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_grn_items_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_grn_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_grn_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    size_part_no_grade = models.CharField(max_length=200, null=True, blank=True)
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    fill_item_by_party = models.BooleanField(default=False)
    barcode = models.CharField(max_length=200, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_grn_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    tolerance_percentage = models.FloatField(default=0)
    ordered_item = models.CharField(max_length=200, null=True, blank=True)
    change_reason = models.TextField(max_length=500, null=True, blank=True)
    is_royalty = models.BooleanField(default=False)
    is_warranty = models.BooleanField(default=False)
    is_istp = models.BooleanField(default=False)
    po_pending_quantity = models.FloatField(default=0)
    challan_quantity = models.FloatField(default=0)
    received_quantity = models.FloatField(default=0)
    received_weight = models.FloatField(default=0)
    return_quantity = models.FloatField(default=0)
    royalty_quantity = models.FloatField(default=0)
    royalty_bk = models.CharField(max_length=200, null=True, blank=True)
    royalty_no = models.CharField(max_length=200, null=True, blank=True)
    royalty_rate = models.FloatField(default=0)
    royalty_date = models.CharField(max_length=200, null=True, blank=True)
    royalty_holder = models.CharField(max_length=200, null=True, blank=True)
    warranty_from_date = models.DateField(null=True, blank=True)
    warranty_from_time = models.TimeField(null=True, blank=True)
    warranty_to_date = models.DateField(null=True, blank=True)
    warranty_to_time = models.TimeField(null=True, blank=True)
    istp_date = models.DateField(null=True, blank=True)
    istp_to = models.CharField(max_length=200, null=True, blank=True)
    istp_royalty_no = models.CharField(max_length=200, null=True, blank=True)

    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_grn_items_excise_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_grn_items_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)

    # other model links #

    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_grn_item_material_request_item", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_grn_item_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor_item = models.ForeignKey(RFQVendorsItems, related_name="procurement_grn_item_rfq_vendor_item", on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once_item = models.ForeignKey(EnquiryAtOnceItems, related_name="procurement_grn_item_enquiry_at_once_item", on_delete=models.CASCADE, null=True, blank=True)
    quotation_item = models.ForeignKey(QuotationItems, related_name="procurement_grn_item_quotation_item", on_delete=models.CASCADE, null=True, blank=True)
    cst_item= models.ForeignKey(CSTItems, related_name='procurement_grn_item_cst_item', on_delete=models.CASCADE, null=True, blank=True)
    purchase_order_item = models.ForeignKey(PurchaseOrderItems, related_name="procurement_grn_item_purchase_order_item", on_delete=models.CASCADE, null=True, blank=True)
    is_auto_approved = models.BooleanField(default=False)
    cost_center = models.ForeignKey(CostCenter, related_name='procurement_grn_items_cost_center', on_delete=models.CASCADE, null=True, blank=True)
    gl_account = models.ForeignKey(GLAccount, related_name='procurement_grn_items_gl_account', on_delete=models.CASCADE, null=True, blank=True)
    
    unit_of_entry = models.CharField(max_length=255, null=True, blank=True)
    material_description = models.CharField(max_length=255, null=True, blank=True)
    qty_unit_entry = models.CharField(max_length=255, null=True, blank=True)
    po_item = models.CharField(max_length=255, null=True, blank=True)
    material_doc_item = models.CharField(max_length=255, null=True, blank=True)
    asset = models.CharField(max_length=255, null=True, blank=True)
    order = models.CharField(max_length=255, null=True, blank=True)
    order_price_unit = models.CharField(max_length=255, null=True, blank=True)
    order_unit = models.CharField(max_length=255, null=True, blank=True)
    qty_order_unit = models.CharField(max_length=255, null=True, blank=True)
    ext_amount = models.CharField(max_length=255, null=True, blank=True)
    sales_value = models.CharField(max_length=255, null=True, blank=True)
    sales_order_schedule = models.CharField(max_length=255, null=True, blank=True)
    sales_order_item = models.CharField(max_length=255, null=True, blank=True)
    del_note_quantity = models.CharField(max_length=255, null=True, blank=True)
    salesorderitem = models.CharField(max_length=255, null=True, blank=True)
    wbs_element = models.CharField(max_length=255, null=True, blank=True)
    network = models.CharField(max_length=255, null=True, blank=True)
    reservation = models.CharField(max_length=255, null=True, blank=True)
    item_no_reservation = models.CharField(max_length=255, null=True, blank=True)
    debit_credit_ind = models.CharField(max_length=255, null=True, blank=True)
    sales_value_vat = models.CharField(max_length=255, null=True, blank=True)
    original_line_item = models.CharField(max_length=255, null=True, blank=True)

    delivery_note_unit=models.CharField(max_length=255, null=True, blank=True)
    qty_op_unit = models.CharField(max_length=255, null=True, blank=True)

    routing_no_operations = models.CharField(max_length=255, null=True, blank=True)
    smart_number = models.CharField(max_length=255, null=True, blank=True)
    activity = models.CharField(max_length=255, null=True, blank=True)
    wbselement = models.CharField(max_length=255, null=True, blank=True)
    stock_segment = models.CharField(max_length=255, null=True, blank=True)
    issue_slip = models.CharField(max_length=255, null=True, blank=True)
    item_auto_created = models.CharField(max_length=255, null=True, blank=True)
    multiple_account_assignment = models.CharField(max_length=255, null=True, blank=True)
    consumption = models.CharField(max_length=255, null=True, blank=True)
    sub_number = models.CharField(max_length=255, null=True, blank=True)
    counter = models.CharField(max_length=255, null=True, blank=True)
    rr_text = models.CharField(max_length=255, null=True, blank=True)
    royality_received_qty= models.FloatField(default=0)
    royality_remarks = models.TextField(null=True,blank=True)

    class Meta:
        db_table = "procurement_grn_items"

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.received_quantity:
            self.received_quantity = 0
        if not self.return_quantity:
            self.return_quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)


class GRNItemsBatch(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_grn_items_batch_organization', on_delete=models.CASCADE)
    grn_item = models.ForeignKey(GRNItems, related_name='procurement_grn_items_batch', on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    quantity = models.FloatField(default=0)
    expiry_date = models.DateField(null=True, blank=True)

    class Meta:
        db_table = "procurement_grn_items_batch"


class GRNTaxDetails(BaseAbstractStructure):
    """
    GRN Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_grn_tax_organization', on_delete=models.CASCADE)
    grn = models.ForeignKey(GRN, related_name='procurement_grn_tax', on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_grn_tax_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = GRN.cmobjects.filter(pk=self.grn.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.procurement_grn_tax.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_grn_tax.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.tax_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.tax_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.tax_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.tax_amount)*float(self.cess_percentage)/100
        self.total_tax_amount = float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_grn_tax"


class GRNExpenseDetails(BaseAbstractStructure):
    """
    GRN Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_grn_expense_tax_organization', on_delete=models.CASCADE)
    grn = models.ForeignKey(GRN, related_name='procurement_grn_expense', on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_grn_expense_tax_expense_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_grn_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = GRN.cmobjects.filter(pk=self.grn.id).first()
        if self.expense_on_parent:
            value = getattr(parent_record, self.expense_on_parent)
        elif self.expense_on_self:
            temp = parent_record.procurement_grn_expense.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_grn_expense.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_grn_expense"


class GRNAttachments(BaseAbstractStructure):
    """
    GRN Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_grn_attachment_organizations',
                                     on_delete=models.CASCADE)
    grn = models.ForeignKey(GRN, related_name='procurement_grn_attachment',
                            on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/grn', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_grn_attachments"


class BillReceive(BaseAbstractStructure):
    """
    Bill Receive
    """
    BILL_TYPE = (
        ('purchase', 'Purchase'),
        ('journal', 'Journal'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    RECEIVED_STATUS = (
        ('not_forward', 'Not Forward'),
        ('forward', 'Forward'),
    )
    VOUCHER_STATUS = (
        ('unpost', 'Un-post'),
        ('post', 'Post'),
        ('rejected', 'Rejected'),
        ('corrected', 'Corrected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_bill_receive_organizations',
                                     on_delete=models.CASCADE)
    request_code = models.CharField(max_length=100, null=True, blank=True)
    sr_no = models.CharField(max_length=100, null=True, blank=True)
    received_date = models.DateField(null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_bill_receive_vendor', on_delete=models.CASCADE,
                               null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_bill_receive_store', on_delete=models.CASCADE,
                              null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_bill_receive_site', on_delete=models.CASCADE,
                             null=True, blank=True)
    amount = models.FloatField(default=0)
    manual_slip_number = models.CharField(max_length=200, null=True, blank=True)
    bill_date = models.DateField(null=True, blank=True)
    bill_type = models.CharField(max_length=100, choices=BILL_TYPE, blank=True, null=True, default="purchase")
    forward_to_user = models.ForeignKey(PmsUser, related_name='procurement_bill_receive_received_by',
                                        on_delete=models.CASCADE, blank=True, null=True)
    nature_of_work = models.TextField(null=True, blank=True)
    file_no = models.CharField(max_length=200, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    received_status = models.CharField(max_length=100, choices=RECEIVED_STATUS, blank=True, null=True,
                                       default="not_forward")
    voucher_no = models.CharField(max_length=100, null=True, blank=True)
    voucher_status = models.CharField(max_length=100, choices=VOUCHER_STATUS, blank=True, null=True, default="unpost")
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_bill_receive_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_bill_receive_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_bill_receive_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_bill_receive_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_bill_receive_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_bill_receive_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    def save(self, *args, **kwargs):
        self.full_clean()
        print(self.forward_to_user)
        if not self.forward_to_user:
            self.received_status = "not_forward"
        else:
            self.received_status = "forward"
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_bill_receive"


class BillReceiveAttachments(BaseAbstractStructure):
    """
    Bill Receive Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_bill_receive_attachment_organizations',
                                     on_delete=models.CASCADE)
    bill_receive = models.ForeignKey(BillReceive, related_name='procurement_bill_receive_attachment',
                                     on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/bill_receive', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_bill_receive_attachments"


class GatePass(BaseAbstractStructure):
    """
    Gate Pass
    """
    GATE_PASS_TYPES = (
        ('in', 'In'),
        ('out', 'Out'),
    )
    TYPE_CHOICES = (
        ('consumable', 'Consumable'),
        ('returnable', 'Returnable'),
        ('non_returnable', 'Non-Returnable'),
        ('transfer', 'Transfer'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_gate_pass_organizations',
                                     on_delete=models.CASCADE)
    request_code = models.CharField(max_length=100, null=True, blank=True)
    gate_pass_no = models.CharField(max_length=200, null=True, blank=True)
    gate_pass_type = models.CharField(max_length=100, choices=GATE_PASS_TYPES)
    rst_no = models.CharField(max_length=100, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    challan_no = models.CharField(max_length=200, null=True, blank=True)
    grn = models.ForeignKey(GRN, related_name='procurement_gate_pass_grn', on_delete=models.CASCADE, blank=True,
                            null=True)
    chainage_from = models.FloatField(default=0)
    chainage_to = models.FloatField(default=0)
    chainage_unit = models.ForeignKey(UnitOfMesurement, related_name='procurement_gate_pass_chainage_unit',
                                      on_delete=models.CASCADE, blank=True, null=True)
    diff = models.FloatField(default=0)
    type = models.CharField(max_length=100, choices=TYPE_CHOICES, blank=True, null=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_gate_pass_vendor', on_delete=models.CASCADE,
                               null=True, blank=True)
    transporter = models.CharField(max_length=200, null=True, blank=True)
    other = models.CharField(max_length=200, null=True, blank=True)
    tare_weight = models.FloatField(default=0)
    unit = models.ForeignKey(UnitOfMesurement, related_name='procurement_gate_pass_unit', on_delete=models.CASCADE,
                             blank=True, null=True)
    driver = models.CharField(max_length=200, null=True, blank=True)
    vehicle_no = models.CharField(max_length=200, null=True, blank=True)
    gross_weight = models.FloatField(default=0)
    net_weight = models.FloatField(default=0)
    prepared_by = models.ForeignKey(PmsUser, related_name='procurement_gate_pass_prepared_by', on_delete=models.CASCADE,
                                    blank=True, null=True)
    remark = models.TextField(null=True, blank=True)
    transportation_rate_status = models.BooleanField(default=False)
    supervisor = models.ForeignKey(PmsUser, related_name='procurement_gate_pass_supervisor', on_delete=models.CASCADE,
                                   blank=True, null=True)
    side = models.CharField(max_length=200, null=True, blank=True)
    first_km = models.FloatField(default=0)
    first_rate = models.FloatField(default=0)
    other_km = models.FloatField(default=0)
    rate_per_km = models.FloatField(default=0)
    amount = models.FloatField(default=0)
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, related_name='procurement_gate_pass_store',
                              null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_gate_pass_site', on_delete=models.CASCADE, null=True,
                             blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_gate_pass_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_gate_pass_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_gate_pass_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_gate_pass_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_gate_pass_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_gate_pass_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_gate_pass"

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.chainage_to:
            self.chainage_to = 0
        if not self.chainage_from:
            self.chainage_from = 0
        if not self.first_km:
            self.first_km = 0
        if not self.first_rate:
            self.first_rate = 0
        if not self.other_km:
            self.other_km = 0
        if not self.rate_per_km:
            self.rate_per_km = 0
        self.diff = float(self.chainage_to) - float(self.chainage_from)
        self.other_km = float(self.diff) - float(self.first_km)
        self.amount = float(self.first_rate) + float(float(self.other_km) * float(self.rate_per_km))
        super().save(*args, **kwargs)


class GatePassItems(BaseAbstractStructure):
    """
    Gate Pass Items
    """
    ITEM_STATUSES = (
        ('under_warranty', 'UNDER WARRANTY'),
        ('repairing', 'REPAIRING'),
        ('sample', 'SAMPLE'),
        ('general', 'GENERAL'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_gate_pass_item_organizations',
                                     on_delete=models.CASCADE)
    gate_pass = models.ForeignKey(GatePass, related_name='procurement_gate_pass_item', on_delete=models.CASCADE,
                                  null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_gate_pass_item_item',
                             on_delete=models.CASCADE,
                             null=True, blank=True)

    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='procurement_gate_pass_item_plant_machinery_machine',
                                on_delete=models.CASCADE,null=True, blank=True)
    weight_uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_gate_pass_item_uom',
                                   on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_gate_pass_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    weight = models.FloatField(default=0)
    value = models.FloatField(default=0)
    item_status = models.CharField(max_length=100, choices=ITEM_STATUSES, default='general')
    remark = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "procurement_gate_pass_items"


class GatePassAttachments(BaseAbstractStructure):
    """
    Gate Pass Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_gate_pass_attachment_organizations',
                                     on_delete=models.CASCADE)
    gate_pass = models.ForeignKey(GatePass, related_name='procurement_gate_pass_attachment',
                                  on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/gate_pass', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_gate_pass_attachments"


class SubletOrder(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_sublet_order_organizations',
                                     on_delete=models.CASCADE)
    so_no = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    company = models.CharField(max_length=200, null=True, blank=True)
    number = models.CharField(max_length=200, null=True, blank=True)
    work_description = models.TextField(null=True, blank=True)
    representative = models.ForeignKey(VendorMasterV2, related_name="procurement_sublet_order_vendor",
                                       on_delete=models.CASCADE, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_sublet_order_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)
    

    project = models.ForeignKey(ProjectMaster, related_name='project_sublet_order', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='site_sublet_order', on_delete=models.CASCADE,
                         null=True, blank=True)

    class Meta:
        db_table = "procurement_sublet_order"


class LabReportEntry(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_lab_report_organizations',
                                     on_delete=models.CASCADE)
    gate_pass_no = models.ForeignKey(GatePass, related_name='procurement_lab_report_entry_gate_pass_no',
                                     on_delete=models.CASCADE, null=True, blank=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    lr_no = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    sample_quantity = models.FloatField(default=0)
    # item_group = models.ForeignKey(MaterialType, related_name='procurement_lab_report_entry_item_group',
    #                          null=True, blank=True, on_delete=models.CASCADE)
    materials_groups = models.ManyToManyField(MaterialType, related_name='procurement_lab_report_entry_materials_group',
                                              null=True, blank=True)

    # item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_lab_report_entry_item_list',
    #                          null=True, blank=True, on_delete=models.CASCADE)

    materials = models.ManyToManyField(VendorMaterialMaster, related_name='procurement_lab_report_entry_materials',
                                       null=True, blank=True)

    remark = models.TextField(null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_lab_report_entry_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    class Meta:
        db_table = "procurement_lab_report_entry"


class LabReportEntryItem(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_lab_report_entry_item_organizations',
                                     on_delete=models.CASCADE)
    lab_report_entry = models.ForeignKey(LabReportEntry, related_name='procurement_lab_report_entry_item_link',
                                         on_delete=models.CASCADE, null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_lab_report_entry_item_item',
                             null=True, blank=True, on_delete=models.CASCADE)
    remark = models.TextField(null=True, blank=True)
    accept = models.BooleanField(default=False)

    project = models.ForeignKey(ProjectMaster, related_name='project_lab_report_entry', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='site_lab_report_entry', on_delete=models.CASCADE,
                            null=True, blank=True)

    class Meta:
        db_table = "procurement_lab_report_entry_item"


class ItemStockJV(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_item_stock_jv_organizations',
                                     on_delete=models.CASCADE)
    jv_no = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_item_stock_jv_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    project = models.ForeignKey(ProjectMaster, related_name='project_item_stock_jv', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='site_item_stock_jv', on_delete=models.CASCADE,
                            null=True, blank=True)
    

    class Meta:
        db_table = "procurement_item_stock_jv"


class ItemStockJVFReceiveIssueItem(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    TYPE = (
        ('party', 'party'),
        ('self', 'self'),
    )
    STOCK_TYPE = (
        ('issue', 'Issue'),
        ('receive', 'Receive'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_item_stock_jv_issue_item_organizations',
                                     on_delete=models.CASCADE)
    item_stock_jv = models.ForeignKey(ItemStockJV, related_name='procurement_item_stock_jv_item',
                                      on_delete=models.CASCADE, null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_item_stock_jv_issue_material_item',
                             null=True, blank=True, on_delete=models.CASCADE)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_item_stock_jv_receive_issue_item_uom', on_delete=models.CASCADE, null=True, blank=True)
    rate = models.FloatField(default=0)
    amount = models.FloatField(default=0)
    location = models.CharField(max_length=200, null=True, blank=True)
    type = models.CharField(max_length=100, choices=TYPE, blank=True, null=True, default="self")
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="receive")
    site = models.ForeignKey(SiteMaster, related_name='procurement_item_stock_jv_site', on_delete=models.CASCADE,
                             null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_item_stock_jv_store', on_delete=models.CASCADE,
                              null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_receive_issue_item_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_receive_issue_item_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_receive_issue_item_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_receive_issue_item_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_item_stock_jv_receive_issue_item_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_item_stock_jv_receive_issue_item"


class LogBook(BaseAbstractStructure):
    OWNER_CHOICES = (
        ('self', 'Self'),
        ('hired', 'Hired'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_log_book_organizations',
                                     on_delete=models.CASCADE)
    date = models.DateField(null=True, blank=True)
    owner = models.CharField(max_length=100, choices=OWNER_CHOICES)
    fuel_opening = models.FloatField(default=0)
    fuel_closing = models.FloatField(default=0)
    driver_operator = models.CharField(max_length=200, null=True, blank=True)
    location = models.CharField(max_length=200, null=True, blank=True)
    consumption = models.FloatField(default=0)
    issue = models.CharField(max_length=200, null=True, blank=True)
    work_done_type = models.TextField(null=True, blank=True)
    from_date = models.DateField(null=True, blank=True)
    from_time = models.TimeField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    to_time = models.TimeField(null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_log_book_store', on_delete=models.CASCADE,
                              null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_log_book_site', on_delete=models.CASCADE,
                             null=True, blank=True)
    shift = models.CharField(max_length=200, null=True, blank=True)
    machine_no = models.CharField(max_length=200, null=True, blank=True)
    machine_issue = models.CharField(max_length=200, null=True, blank=True)
    machine_consumption = models.FloatField(default=0)
    helper_cleaner = models.CharField(max_length=200, null=True, blank=True)
    average = models.FloatField(default=0)
    remark = models.TextField(null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_log_book_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)
    plantmachinery = models.ForeignKey(PlantMachineryMaster, related_name='procurement_log_book_plantmachinery',
                                       on_delete=models.CASCADE, blank=True, null=True)

    class Meta:
        db_table = "procurement_log_book"


class LogBookAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_log_book_attachment_organizations',
                                     on_delete=models.CASCADE)
    log_book = models.ForeignKey(LogBook, related_name='procurement_log_book_attachments', on_delete=models.CASCADE,
                                 null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/log_book', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_log_book_attachments"


class GroupTaskMaster(BaseAbstractStructure):
    TASK_TYPE_CHOICES = (
        ('tender_group_subgroup', 'Tender Group/Sub-Group'),
        ('tender_task', 'Tender Task'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_group_task_master_organizations',
                                     on_delete=models.CASCADE)
    task_type = models.CharField(max_length=100, choices=TASK_TYPE_CHOICES, default='tender_group_subgroup',
                                 null=True, blank=True)
    boq_no = models.CharField(max_length=200, null=True, blank=True)
    group_subgroup_and_task_name = models.TextField(null=True, blank=True)
    primary = models.ForeignKey('self', related_name='procurement_group_task_master_primary',
                                on_delete=models.CASCADE, null=True, blank=True)
    after_this = models.ForeignKey('self', related_name='procurement_group_task_master_after_this',
                                   on_delete=models.CASCADE, null=True, blank=True)
    sor_master = models.CharField(max_length=200, null=True, blank=True)
    sor_group = models.CharField(max_length=200, null=True, blank=True)
    non_billable = models.BooleanField(default=False)
    weightage = models.FloatField(default=0)
    copy_downline = models.BooleanField(default=False)
    description = models.TextField(null=True, blank=True)
    predecessor = models.ForeignKey('self', related_name='procurement_group_task_master_predecessor',
                                    on_delete=models.CASCADE, null=True, blank=True)
    priority = models.IntegerField(default=0)
    short_name = models.CharField(max_length=50)
    build_up_area_qty = models.FloatField(default=0)

    project = models.ForeignKey(ProjectMaster, related_name='project_group_task', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='site_group_task', on_delete=models.CASCADE,
                            null=True, blank=True)

    class Meta:
        db_table = "procurement_group_task_master"


class GroupTaskMasterAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_group_task_master_attachment_organizations',
                                     on_delete=models.CASCADE)
    group_task_master = models.ForeignKey(GroupTaskMaster, related_name='procurement_group_task_master_attachments',
                                          on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/group_task_master', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_group_task_master_attachments"


class WorkIndent(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_indent_organizations',
                                     on_delete=models.CASCADE)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    wo_no = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    work_desc = models.TextField(null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_work_indent_project', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_work_indent_site', on_delete=models.CASCADE,
                             null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_work_indent_store', on_delete=models.CASCADE,
                              null=True, blank=True)
    work_type = models.CharField(max_length=100, null=True, blank=True)
    employee_name = models.ForeignKey(PmsUser, on_delete=models.CASCADE,
                                      related_name='procurement_work_indent_employee_name', null=True, blank=True)
    jurisdiction = models.CharField(max_length=200, null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    total_quantity = models.FloatField(default=0)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_work_indent_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_work_indent"


class WorkIndentWorkDetail(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_detail_organizations',
                                     on_delete=models.CASCADE)
    work_indent = models.ForeignKey(WorkIndent,
                                    related_name='procurement_work_indent_details',
                                    on_delete=models.CASCADE, null=True, blank=True)
    work = models.ForeignKey(GroupTaskMaster, on_delete=models.CASCADE, related_name='procurement_work_detail_task',
                             null=True, blank=True)
    work_detail = models.TextField(null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_work_details_uom',
                            on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    sanctioned_quantity = models.FloatField(default=0)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_work_detail_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_work_detail_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_work_detail_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_work_detail_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_indent_work_detail_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_work_indent_work_detail"


class WorkIndentAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_indent_attachments_organizations',
                                     on_delete=models.CASCADE)
    work_indent = models.ForeignKey(WorkIndent, related_name='procurement_work_indent_attachments',
                                    on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/work_indent', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_work_indent_attachments"


class WorkOrder(BaseAbstractStructure):
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_order_organizations',
                                     on_delete=models.CASCADE)
    work_indent = models.ForeignKey(WorkIndent, related_name='procurement_work_order_work_indent', on_delete=models.CASCADE, null=True, blank=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    current_stage = models.IntegerField(default=0)
    type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="vat")
    wo_no = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_work_order_project', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, related_name='procurement_work_order_site')
    site_address = models.TextField(null=True, blank=True)
    site_state = models.ForeignKey(State, on_delete=models.CASCADE, related_name='procurement_work_order_site_state',
                                   null=True, blank=True)
    work_description = models.TextField(null=True, blank=True)
    location = models.CharField(max_length=200, null=True, blank=True)
    sd_percentage = models.FloatField(default=0)
    party = models.ForeignKey(VendorMasterV2, on_delete=models.CASCADE, related_name='procurement_work_order_party',
                              null=True, blank=True)
    party_state_gst_no = models.CharField(max_length=200, null=True, blank=True)
    job_site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, related_name='procurement_work_order_job_site',
                                 null=True, blank=True)
    buyer_order_no = models.CharField(max_length=200, null=True, blank=True)
    manual_wo_no = models.CharField(max_length=200, null=True, blank=True)
    retention_percentage = models.FloatField(default=0)
    kind_attn = models.TextField(null=True, blank=True)
    billing_site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE,
                                     related_name='procurement_work_order_billing_site', null=True, blank=True)
    billing_state = models.ForeignKey(State, on_delete=models.CASCADE,
                                      related_name='procurement_work_order_billing_state', null=True, blank=True)
    purchase_type = models.CharField(max_length=200, null=True, blank=True)
    work_type = models.CharField(max_length=200, null=True, blank=True)
    place_of_supply = models.BooleanField(default=False)
    cheque_no = models.CharField(max_length=200, null=True, blank=True)
    cheque_date = models.DateField(null=True, blank=True)
    cheque_amount = models.FloatField(default=0)
    bank_name = models.CharField(max_length=200, null=True, blank=True)
    cash_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    employee_name = models.ForeignKey(PmsUser, on_delete=models.CASCADE,
                                      related_name='procurement_work_order_employee_name', null=True, blank=True)
    jurisdiction = models.TextField(null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    extra_notes = models.TextField(null=True, blank=True)
    total_labor_quantity = models.FloatField(default=0)
    total_labor_amount = models.FloatField(default=0)
    total_labor_discount = models.FloatField(default=0)
    total_labor_taxable_amount = models.FloatField(default=0)
    total_labor_cgst_amount = models.FloatField(default=0)
    total_labor_sgst_amount = models.FloatField(default=0)
    total_labor_igst_amount = models.FloatField(default=0)
    total_labor_net_amount = models.FloatField(default=0)
    total_material_quantity = models.FloatField(default=0)
    total_material_amount = models.FloatField(default=0)
    total_material_discount = models.FloatField(default=0)
    total_material_taxable_amount = models.FloatField(default=0)
    total_material_cgst_amount = models.FloatField(default=0)
    total_material_sgst_amount = models.FloatField(default=0)
    total_material_igst_amount = models.FloatField(default=0)
    total_material_net_amount = models.FloatField(default=0)
    total_work_detail_quantity = models.FloatField(default=0)
    total_work_detail_amount = models.FloatField(default=0)
    total_work_detail_discount = models.FloatField(default=0)
    total_work_detail_taxable_amount = models.FloatField(default=0)
    total_work_detail_cgst_amount = models.FloatField(default=0)
    total_work_detail_sgst_amount = models.FloatField(default=0)
    total_work_detail_igst_amount = models.FloatField(default=0)
    total_work_detail_net_amount = models.FloatField(default=0)
    work_detail_discount = models.FloatField(default=0)
    work_detail_total_tax = models.FloatField(default=0)
    work_detail_round_off = models.FloatField(default=0)
    work_detail_grand_total = models.FloatField(default=0)
    net_total_quantity = models.FloatField(default=0)
    net_total_amount = models.FloatField(default=0)
    net_total_discount = models.FloatField(default=0)
    net_total_taxable_amount = models.FloatField(default=0)
    net_total_cgst_amount = models.FloatField(default=0)
    net_total_sgst_amount = models.FloatField(default=0)
    net_total_igst_amount = models.FloatField(default=0)
    net_total_net_amount = models.FloatField(default=0)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_work_order_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='procurement_work_order_ref_stage_type', blank=True, null=True, on_delete=models.CASCADE)

    class Meta:
        db_table = "procurement_work_order"

    def save(self, *args, **kwargs):
        self.full_clean()
        self.work_detail_grand_total = float(self.total_work_detail_net_amount) - float(
            self.work_detail_discount) + float(self.work_detail_total_tax) + float(self.work_detail_round_off)
        self.net_total_quantity = float(self.total_labor_quantity) + float(self.total_material_quantity) + float(
            self.total_work_detail_quantity)
        self.net_total_amount = float(self.total_labor_amount) + float(self.total_material_amount) + float(
            self.total_work_detail_amount)
        self.net_total_discount = float(self.total_labor_discount) + float(self.total_material_discount) + float(
            self.total_work_detail_discount)
        self.net_total_taxable_amount = float(self.total_labor_taxable_amount) + float(
            self.total_material_taxable_amount) + float(self.total_work_detail_taxable_amount)
        self.net_total_cgst_amount = float(self.total_labor_cgst_amount) + float(
            self.total_material_cgst_amount) + float(self.total_work_detail_cgst_amount)
        self.net_total_sgst_amount = float(self.total_labor_sgst_amount) + float(
            self.total_material_sgst_amount) + float(self.total_work_detail_sgst_amount)
        self.net_total_igst_amount = float(self.total_labor_igst_amount) + float(
            self.total_material_igst_amount) + float(self.total_work_detail_igst_amount)
        self.net_total_net_amount = float(self.total_labor_net_amount) + float(self.total_material_net_amount) + float(
            self.work_detail_grand_total)

        super().save(*args, **kwargs)


class WorkOrderStages(BaseAbstractStructure):
    """
    Stages
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_work_order_stages_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_stages',
                               on_delete=models.CASCADE, null=True, blank=True)
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_stages_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_stages_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_stages_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_stages_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_work_order_stages_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    def __str__(self):
        return f"{self.work_order} -> {self.stage} {self.status}"

    class Meta:
        db_table = "procurement_work_order_stages"


class WorkOrderLabor(BaseAbstractStructure):
    ADV_LESS = (
        ('add', 'Add'),
        ('less', 'Less'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_order_labor_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_labors',
                                   on_delete=models.CASCADE, null=True, blank=True)
    category = models.ForeignKey(LabourMaster, on_delete=models.CASCADE,
                                 related_name='procurement_work_order_labor_category', null=True, blank=True)
    adv_less = models.CharField(max_length=10, choices=ADV_LESS, default='add')
    quantity = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    amount = models.FloatField(default=0)
    discount_pecentage = models.FloatField(default=0)
    discount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    tax = models.ForeignKey(TaxHead, related_name='procurement_work_order_labor_tax', on_delete=models.CASCADE,
                            null=True, blank=True)
    cgst_pecentage = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    sgst_pecentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    igst_pecentage = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    net_amount = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_work_order_labor"

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.quantity:
            self.quantity = 0
        if not self.discount_pecentage:
            self.discount_pecentage = 0
        if not self.discount:
            self.discount = 0
        if not self.taxable_amount:
            self.taxable_amount = 0
        if not self.cgst_pecentage:
            self.cgst_pecentage = 0
        if not self.cgst_amount:
            self.cgst_amount = 0
        if not self.sgst_pecentage:
            self.sgst_pecentage = 0
        if not self.sgst_amount:
            self.sgst_amount = 0
        if not self.igst_pecentage:
            self.igst_pecentage = 0
        if not self.igst_amount:
            self.igst_amount = 0
        if not self.net_amount:
            self.net_amount = 0
        self.amount = float(self.rate) * float(self.quantity)
        if self.discount == 0:
            self.discount = float(float(self.amount) * float(self.discount_pecentage)) / 100
        self.taxable_amount = float(self.amount) - float(self.discount)
        self.cgst_amount = float(float(self.taxable_amount) * float(self.cgst_pecentage)) / 100
        self.sgst_amount = float(float(self.taxable_amount) * float(self.sgst_pecentage)) / 100
        self.igst_amount = float(float(self.taxable_amount) * float(self.igst_pecentage)) / 100
        self.net_amount = float(self.taxable_amount) + float(self.cgst_amount) + float(self.sgst_amount) + float(
            self.igst_amount)
        super().save(*args, **kwargs)


class WorkOrderDetail(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_order_detail_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_details',
                                   on_delete=models.CASCADE, null=True, blank=True)
    work_indent_work_detail = models.ForeignKey(WorkIndentWorkDetail, related_name='procurement_work_order_detail_work_indent_work_detail', on_delete=models.CASCADE, null=True, blank=True)
    task = models.ForeignKey(GroupTaskMaster, related_name='procurement_work_order_detail_task',
                             on_delete=models.CASCADE, null=True, blank=True)
    work_detail = models.TextField(null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_work_order_details_uom',
                            on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    amount = models.FloatField(default=0)
    discount_pecentage = models.FloatField(default=0)
    discount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    tax = models.ForeignKey(TaxHead, related_name='procurement_work_order_details_tax', on_delete=models.CASCADE,
                            null=True, blank=True)
    cgst_pecentage = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    sgst_pecentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    igst_pecentage = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    net_amount = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_work_order_detail"

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.quantity:
            self.quantity = 0
        if not self.discount_pecentage:
            self.discount_pecentage = 0
        if not self.discount:
            self.discount = 0
        if not self.taxable_amount:
            self.taxable_amount = 0
        if not self.cgst_pecentage:
            self.cgst_pecentage = 0
        if not self.cgst_amount:
            self.cgst_amount = 0
        if not self.sgst_pecentage:
            self.sgst_pecentage = 0
        if not self.sgst_amount:
            self.sgst_amount = 0
        if not self.igst_pecentage:
            self.igst_pecentage = 0
        if not self.igst_amount:
            self.igst_amount = 0
        if not self.net_amount:
            self.net_amount = 0
        self.amount = float(self.rate) * float(self.quantity)
        if self.discount == 0:
            self.discount = float(float(self.amount) * float(self.discount_pecentage)) / 100
        self.taxable_amount = float(self.amount) - float(self.discount)
        self.cgst_amount = float(float(self.taxable_amount) * float(self.cgst_pecentage)) / 100
        self.sgst_amount = float(float(self.taxable_amount) * float(self.sgst_pecentage)) / 100
        self.igst_amount = float(float(self.taxable_amount) * float(self.igst_pecentage)) / 100
        self.net_amount = float(self.taxable_amount) + float(self.cgst_amount) + float(self.sgst_amount) + float(
            self.igst_amount)
        super().save(*args, **kwargs)


class WorkOrderTax(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_work_order_tax_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_taxes', on_delete=models.CASCADE,
                                   null=True, blank=True)
    tax = models.ForeignKey(TaxHead, related_name='procurement_work_order_tax_tax', on_delete=models.CASCADE, null=True,
                            blank=True)
    tax_on = models.CharField(max_length=200, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_work_order_tax"


class WorkOrderRequirement(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_order_requirement_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_requirements',
                                   on_delete=models.CASCADE, null=True, blank=True)
    requirement = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "procurement_work_order_requirement"


class WorkOrderTermsAndConditions(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_order_tc_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_tcs',
                                   on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(TermsAndConditionsChild, related_name='procurement_work_order_terms_conditions_master', on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    order_id = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "procurement_work_order_terms_conditions"


class WorkOrderMaterial(BaseAbstractStructure):
    ADV_LESS = (
        ('add', 'Add'),
        ('less', 'Less'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_order_material_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_materials',
                                   on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_work_order_material',
                                 on_delete=models.CASCADE, null=True, blank=True)
    adv_less = models.CharField(max_length=10, choices=ADV_LESS, default='add')
    days = models.FloatField(default=0)
    remarks = models.CharField(max_length=200, null=True, blank=True)
    charge_type = models.CharField(max_length=200, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='work_order_uom', on_delete=models.CASCADE, null=True, blank=True)
    rate = models.FloatField(default=0)
    amount = models.FloatField(default=0)
    discount_pecentage = models.FloatField(default=0)
    discount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    tax = models.ForeignKey(TaxHead, related_name='procurement_work_order_material_tax', on_delete=models.CASCADE,
                            null=True, blank=True)
    cgst_pecentage = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    sgst_pecentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    igst_pecentage = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    net_amount = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_work_order_material"

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.quantity:
            self.quantity = 0
        if not self.discount_pecentage:
            self.discount_pecentage = 0
        if not self.discount:
            self.discount = 0
        if not self.taxable_amount:
            self.taxable_amount = 0
        if not self.cgst_pecentage:
            self.cgst_pecentage = 0
        if not self.cgst_amount:
            self.cgst_amount = 0
        if not self.sgst_pecentage:
            self.sgst_pecentage = 0
        if not self.sgst_amount:
            self.sgst_amount = 0
        if not self.igst_pecentage:
            self.igst_pecentage = 0
        if not self.igst_amount:
            self.igst_amount = 0
        if not self.net_amount:
            self.net_amount = 0
        self.amount = float(self.rate) * float(self.quantity)
        if self.discount == 0:
            self.discount = float(float(self.amount) * float(self.discount_pecentage)) / 100
        self.taxable_amount = float(self.amount) - float(self.discount)
        self.cgst_amount = float(float(self.taxable_amount) * float(self.cgst_pecentage)) / 100
        self.sgst_amount = float(float(self.taxable_amount) * float(self.sgst_pecentage)) / 100
        self.igst_amount = float(float(self.taxable_amount) * float(self.igst_pecentage)) / 100
        self.net_amount = float(self.taxable_amount) + float(self.cgst_amount) + float(self.sgst_amount) + float(
            self.igst_amount)
        super().save(*args, **kwargs)


class WorkOrderHireContract(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_order_hire_contract_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_hire_contracts',
                                   on_delete=models.CASCADE, null=True, blank=True)
    hire = models.CharField(max_length=255, null=True, blank=True)
    contract_code = models.CharField(max_length=255, null=True, blank=True)
    machine_category = models.CharField(max_length=255, null=True, blank=True)
    required_avg = models.FloatField(default=0)
    required_avg_type = models.CharField(max_length=255, null=True, blank=True)
    charges_base = models.CharField(max_length=255, null=True, blank=True)
    min_working_days = models.FloatField(default=0)
    allow_bd_days = models.FloatField(default=0)
    operator_charges = models.CharField(max_length=255, null=True, blank=True)
    operator_charges_amount = models.FloatField(default=0)
    helper_charges = models.CharField(max_length=255, null=True, blank=True)
    helper_charges_amount = models.FloatField(default=0)
    fuel_included = models.CharField(max_length=255, null=True, blank=True)
    fuel_included_amount = models.FloatField(default=0)
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    machine = models.ForeignKey(PlantMachineryMaster, related_name='procurement_work_order_hire_contract_machine',
                                on_delete=models.CASCADE, null=True, blank=True)
    rate = models.FloatField(default=0)
    per = models.CharField(max_length=255, null=True, blank=True)
    allow_idle_days = models.FloatField(default=0)
    maintenance_charges = models.CharField(max_length=255, null=True, blank=True)
    maintenance_charges_amount = models.FloatField(default=0)
    remark = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "procurement_work_order_hire_contract"


class WorkOrderAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_work_order_attachments_organizations',
                                     on_delete=models.CASCADE)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_work_order_attachments',
                                   on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/work_order', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_work_order_attachments"


class Purchase(BaseAbstractStructure):
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    FREIGHT_TYPE_CHOICES = [
        ('f_o_r', 'F.O.R'),
        ('to_pay', 'TO PAY'),
    ]

    SERVICE_TAX_TYPE_CHOICES = [
        ('on_service_charge', 'ON SERVICE CHARGE'),
        ('on_item_value', 'ON ITEM VALUE'),
    ]

    TAX_COLLECTED_AT_SOURCE_TYPE_CHOICES = [
        ('on_item_value', 'ON ITEM VALUE'),
        ('on_before_vat_cst', 'ON BEFORE VAT/CST'),
        ('on_after_vat_cst', 'ON AFTER VAT/CST'),
    ]

    INSURANCE_TYPE_CHOICES = [
        ('on_item_value_before_vat', 'ON ITEM VALUE BEFORE VAT'),
        ('on_balance_after_et', 'ON BALANCE AFTER ET'),
    ]
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_purchase_organizations',
                                     on_delete=models.CASCADE)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    request_code = models.CharField(max_length=200, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_purchase_site')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_purchase_store')
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_purchase_project')
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_purchase_vendor',
                               on_delete=models.CASCADE, null=True, blank=True)
    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="vat")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    cash_payment = models.BooleanField(default=False)
    way_bill_form = models.ForeignKey(WayBillForm, related_name='procurement_purchase_way_bill_form',
                                      on_delete=models.CASCADE, null=True, blank=True)
    party_bill_no = models.CharField(max_length=200, null=True, blank=True)
    party_bill_date = models.DateField(null=True, blank=True)
    job_site = models.ForeignKey(SiteMaster, related_name='procurement_purchase_job_site',
                                 on_delete=models.CASCADE, null=True, blank=True)
    against_c_form = models.BooleanField(default=False)
    cst_agst_e1_sale = models.BooleanField(default=False)
    jurisdiction = models.CharField(max_length=200, null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    t_and_c = models.TextField(null=True, blank=True)
    site_state = models.ForeignKey(State, related_name='procurement_purchase_site_state', on_delete=models.CASCADE, null=True, blank=True)
    vendor_state = models.ForeignKey(State, related_name='procurement_purchase_vendor_state', on_delete=models.CASCADE, null=True, blank=True)
    exchange_rate = models.FloatField(default=1)
    vendor_currency = models.ForeignKey(VendorCurrencyMaster, related_name='procurement_purchase_vendor_currency', on_delete=models.CASCADE, null=True, blank=True)
    
    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_weight = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)

    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_purchase_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)
    
    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_purchase_material_request", on_delete=models.CASCADE, null=True, blank=True)
    indent = models.ForeignKey(Indent, related_name='procurement_purchase_indent', on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor = models.ForeignKey(RFQVendors, related_name='procurement_purchase_rfq_vendor', on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once = models.ForeignKey(EnquiryAtOnce, related_name='procurement_purchase_enquiry_at_once', on_delete=models.CASCADE, null=True, blank=True)
    quotation = models.ForeignKey(Quotation, related_name='procurement_purchase_quotation', on_delete=models.CASCADE, null=True, blank=True)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_purchase_purchase_orders', on_delete=models.CASCADE, null=True, blank=True)
    grn = models.ForeignKey(GRN, related_name='procurement_purchase_grn', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "procurement_purchase"


class PurchaseItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_purchase_item_organizations',
                                     on_delete=models.CASCADE)
    purchase = models.ForeignKey(Purchase, related_name='procurement_purchase_items', on_delete=models.CASCADE,
                                 null=True,
                                 blank=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='purchase_item_material', on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_purchase_items_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_purchase_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_purchase_items_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_purchase_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_purchase_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    size_part_no_grade = models.CharField(max_length=200, null=True, blank=True)
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    fill_items_by_bill_entry = models.BooleanField(default=False)
    weight = models.FloatField(default=0)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_purchase_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    tolerance_percentage = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_items_excise_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_items_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)

    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_purchase_items_request", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_purchase_items_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor_item = models.ForeignKey(RFQVendorsItems, related_name="procurement_purchase_items_rfq_vendor_item", on_delete=models.CASCADE, null=True, blank=True)
    quotation_item = models.ForeignKey(QuotationItems, related_name="procurement_purchase_items_quotation_item", on_delete=models.CASCADE, null=True, blank=True)
    purchase_order_item = models.ForeignKey(PurchaseOrderItems, related_name="procurement_purchase_items_purchase_order_item", on_delete=models.CASCADE, null=True, blank=True)
    grn_item = models.ForeignKey(GRNItems, related_name="procurement_purchase_items_grn_item", on_delete=models.CASCADE, null=True, blank=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_items"


class PurchaseTaxDetails(BaseAbstractStructure):
    """
    Purchase Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_tax_organizations',
                                     on_delete=models.CASCADE)
    purchase = models.ForeignKey(Purchase,
                                       related_name='procurement_purchase_tax',
                                       on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_tax_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = Purchase.cmobjects.filter(pk=self.purchase.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.procurement_purchase_tax.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_purchase_tax.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.tax_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.tax_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.tax_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.tax_amount)*float(self.cess_percentage)/100
        self.total_tax_amount = float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_tax"


class PurchaseExpenseDetails(BaseAbstractStructure):
    """
    Purchase Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_expense_organizations',
                                     on_delete=models.CASCADE)
    purchase = models.ForeignKey(Purchase,
                                       related_name='procurement_purchase_expense',
                                       on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_purchase_expense_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = Purchase.cmobjects.filter(pk=self.purchase.id).first()
        if self.expense_on_parent:
            value = getattr(parent_record, self.expense_on_parent)
        elif self.expense_on_self:
            temp = parent_record.procurement_purchase_expense.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_purchase_expense.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_expense"


class PurchaseItemsNotes(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_purchase_item_notes_organizations',
                                     on_delete=models.CASCADE)
    purchase_item = models.ForeignKey(PurchaseItems, related_name='procurement_purchase_item_notes',
                                      on_delete=models.CASCADE, null=True, blank=True)
    note_title = models.CharField(max_length=100, blank=True, null=True)
    note_details = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = "procurement_purchase_item_notes"


class PurchaseAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_purchase_attachment_organizations',
                                     on_delete=models.CASCADE)
    purchase = models.ForeignKey(Purchase, related_name='procurement_purchase_attachments', on_delete=models.CASCADE,
                                 null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/purchase', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_purchase_attachments"


class MaterialIssue(BaseAbstractStructure):
    ISSUE_TYPE = (
        ('consumption_issue', 'Consumption/Issue'),
        ('transfer', 'Transfer'),
        ('production', 'Production'),
        ('issue_to_party', 'Issue to Party'),
    )
    ISSUE_TRANSFER_FROM = (
        ('party_stock', 'Party Stock'),
        ('self_stock', 'Self Stock'),
    )
    LOADED_VIA = (
        ('party', 'Party'),
        ('self', 'Self'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_material_issue_organizations',
                                     on_delete=models.CASCADE)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_material_issue_site')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, related_name="procurement_material_issue_store")
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, related_name='procurement_material_issue_project')
    requested_by = models.ForeignKey(PmsUser, related_name='procurement_material_issue_requested_by',
                                     on_delete=models.CASCADE, null=True, blank=True)
    received_by = models.ForeignKey(PmsUser, related_name='procurement_material_issue_received_by',
                                    on_delete=models.CASCADE, null=True, blank=True)
    party = models.ForeignKey(VendorMasterV2, related_name='procurement_material_issue_party',
                                   on_delete=models.CASCADE, blank=True, null=True)
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    request_code = models.CharField(max_length=100, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    sap_issue_number = models.CharField(max_length=100, null=True, blank=True)
    issue_type = models.CharField(max_length=100, choices=ISSUE_TYPE, blank=True, null=True)
    issue_transfer_from = models.CharField(max_length=100, choices=ISSUE_TRANSFER_FROM, blank=True, null=True)
    manual_slip_number = models.CharField(max_length=200, null=True, blank=True)
    rst_number = models.CharField(max_length=200, null=True, blank=True)
    issue_location = models.CharField(max_length=200, null=True, blank=True)
    lr_date = models.DateField(null=True, blank=True)
    lr_time = models.TimeField(null=True, blank=True)
    lr_number = models.CharField(max_length=200, null=True, blank=True)
    transporter = models.CharField(max_length=200, null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_material_issue_vendor',
                                   on_delete=models.CASCADE, blank=True, null=True)
    carrying_driver = models.CharField(max_length=200, null=True, blank=True)
    loaded_via = models.CharField(max_length=100, choices=LOADED_VIA, blank=True, null=True)
    carrying_vehicle_number = models.CharField(max_length=200, null=True, blank=True)
    gate_pass_number = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    self_carrying_vehicle = models.BooleanField(default=False)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_material_issue_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    plant_production = models.ForeignKey(PlantProduction, related_name="procurement_material_issue_plant_production",
                                         on_delete=models.CASCADE, null=True, blank=True)
    
    material_request = models.ForeignKey(MaterialRequestMaster, related_name="procurement_material_issue_material_request", on_delete=models.CASCADE, null=True, blank=True)
    indent = models.ForeignKey(Indent, related_name='procurement_material_issue_indent', on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor = models.ForeignKey(RFQVendors, related_name='procurement_material_issue_rfq_vendor', on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once = models.ForeignKey(EnquiryAtOnce, related_name='procurement_material_issue_enquiry_at_once', on_delete=models.CASCADE, null=True, blank=True)
    quotation = models.ForeignKey(Quotation, related_name='procurement_material_issue_quotation', on_delete=models.CASCADE, null=True, blank=True)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_material_issue_purchase_orders', on_delete=models.CASCADE, null=True, blank=True)
    grn = models.ForeignKey(GRN, related_name='procurement_material_issue_grn', on_delete=models.CASCADE, null=True, blank=True)
    purchase = models.ForeignKey(Purchase, related_name='procurement_material_issue_purchase', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    total_received_quantity = models.FloatField(default=0)
    total_return_quantity = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)

    bill_date=models.DateField(blank=True, null=True, )
    movement_type = models.CharField(max_length=200, null=True, blank=True)
    batch = models.CharField(max_length=200, null=True, blank=True)
    sap_code = models.CharField(max_length=200, null=True, blank=True) 
    reference = models.CharField(max_length=200, null=True, blank=True)
    entered_on = models.CharField(max_length=200, null=True, blank=True)
    plant = models.CharField(max_length=200, null=True, blank=True)
    storage_location = models.CharField(max_length=200, null=True, blank=True)
    header_text = models.CharField(max_length=200, null=True, blank=True)
    company_code = models.CharField(max_length=200, null=True, blank=True)
    material_year = models.CharField(max_length=200, null=True, blank=True)
    event_type = models.CharField(max_length=200, null=True, blank=True)
    valuation_type = models.CharField(max_length=200, null=True, blank=True)
    user_name = models.CharField(max_length=200, null=True, blank=True)
    name1 = models.CharField(max_length=200, null=True, blank=True)
    name2 = models.CharField(max_length=200, null=True, blank=True)
    pur_org = models.CharField(max_length=200, null=True, blank=True)
    movement_type_text = models.CharField(max_length=200, null=True, blank=True)
    doc_header_text = models.CharField(max_length=200, null=True, blank=True)
    time = models.CharField(max_length=200, null=True, blank=True)
    reason_movement = models.CharField(max_length=200, null=True, blank=True)
    movement_indicator = models.CharField(max_length=200, null=True, blank=True)
    currency=models.CharField(max_length=200, null=True, blank=True)

    cost_center = models.CharField(max_length=200, null=True, blank=True)
    gl = models.CharField(max_length=200, null=True, blank=True)
    text = models.CharField(max_length=200, null=True, blank=True)

    sales_order = models.CharField(max_length=200, null=True, blank=True)
    salesorder = models.CharField(max_length=200, null=True, blank=True)
    customer = models.CharField(max_length=200, null=True, blank=True)
    receipt_indicator = models.CharField(max_length=200, null=True, blank=True)
    gate_entry_no = models.CharField(max_length=200, null=True, blank=True)
    vehicle_no = models.CharField(max_length=200, null=True, blank=True)
    name3 = models.CharField(max_length=200, null=True, blank=True)
    name4 = models.CharField(max_length=200, null=True, blank=True)
    confirmation_no = models.CharField(max_length=200, null=True, blank=True)
    confirmation_text1 = models.CharField(max_length=200, null=True, blank=True)
    confirmation_text2 = models.CharField(max_length=200, null=True, blank=True)
    confirmation_text3 = models.CharField(max_length=200, null=True, blank=True)
    confirmation_text4 = models.CharField(max_length=200, null=True, blank=True)
    gate_entry_date = models.CharField(max_length=200, null=True, blank=True)
    class Meta:
        db_table = "procurement_material_issue"


class MaterialIssueAttachments(BaseAbstractStructure):
    """
    Material Issue Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_material_issue_attachment_organizations',
                                     on_delete=models.CASCADE)
    material_issue = models.ForeignKey(MaterialIssue,
                                       related_name='procurement_material_issue_attachment',
                                       on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/material_issue', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_material_issue_attachments"


class MaterialIssueItems(BaseAbstractStructure):
    REQUESTED_FOR = (
        ('all', 'All'),
        ('party', 'Party'),
        ('vehicle', 'Vehicle'),
        ('project', 'Project'),
        ('other', 'Other'),
        ('employee', 'Employee'),
        ('department', 'Department')
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    WBS_TYPE = (
        ('DC', 'DC'),
        ('IDC', 'IDC'),
        ('TM', 'TM'),
        ('TPNM', 'TPNM'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_material_issue_item_organizations',
                                     on_delete=models.CASCADE)
    material_issue = models.ForeignKey(MaterialIssue, related_name='procurement_material_issue_item',
                                       on_delete=models.CASCADE, null=True, blank=True)
    requested_material = models.ForeignKey(VendorMaterialMaster,
                                           related_name='procurement_material_issue_item_requested_material',
                                           on_delete=models.CASCADE, null=True, blank=True)
    requested_machine = models.ForeignKey(PlantMachineryMachine,
                                          related_name='procurement_material_issue_items_requested_machine',
                                          on_delete=models.CASCADE, null=True, blank=True)
    wbs_material = models.ForeignKey(WBSMaterial, related_name='procurement_material_issue_items_wbs_material', on_delete=models.CASCADE, null=True, blank=True)
    wbs_code = models.ForeignKey(BOQChainageExecutiveSummeryData, related_name='procurement_material_issue_items_wbs_code', on_delete=models.CASCADE, null=True, blank=True)
    wbs_indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='procurement_material_issue_items_wbs_indirect_cost', on_delete=models.CASCADE, null=True, blank=True)
    wbs_plantmachinery = models.ForeignKey(WBSPlantMachinery, related_name='procurement_material_issue_items_wbs_plantmachinery', on_delete=models.CASCADE, null=True, blank=True)
    wbs_temp = models.ForeignKey(WbsTempPlaning, related_name='procurement_material_issue_items_wbs_temp', on_delete=models.CASCADE, null=True, blank=True)
    wbs_type = models.CharField(max_length=100, choices=WBS_TYPE, blank=True, null=True)
    size_part_no_grade = models.CharField(max_length=200, null=True, blank=True)
    brand = models.CharField(max_length=200, blank=True, null=True, default="")
    specification = models.CharField(max_length=500, blank=True, null=True, default="")
    plant_production_items = models.ForeignKey(PlantProductionItems,
                                               related_name="procurement_material_issue_plant_production_items",
                                               on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_material_issue_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    requested_for_type = models.CharField(max_length=100, choices=REQUESTED_FOR, blank=True, null=True)
    requested_for = models.CharField(max_length=100, blank=True, null=True)
    rate = models.FloatField(default=0)
    amount = models.FloatField(default=0)
    charge_type = models.CharField(max_length=200, blank=True, null=True)
    shift = models.CharField(max_length=200, blank=True, null=True)
    is_returnable = models.BooleanField(default=False)
    is_chargeable = models.BooleanField(default=True)
    log_book = models.TextField(max_length=500, null=True, blank=True)
    loc_bal_qty = models.FloatField(default=0)
    weight = models.FloatField(default=0)

    # other model links #

    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_material_issue_item_request", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_material_issue_item_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor_item = models.ForeignKey(RFQVendorsItems, related_name="procurement_material_issue_item_rfq_vendor_item", on_delete=models.CASCADE, null=True, blank=True)
    quotation_item = models.ForeignKey(QuotationItems, related_name="procurement_material_issue_item_quotation_item", on_delete=models.CASCADE, null=True, blank=True)
    purchase_order_item = models.ForeignKey(PurchaseOrderItems, related_name="procurement_material_issue_item_purchase_order_item", on_delete=models.CASCADE, null=True, blank=True)
    grn_item = models.ForeignKey(GRNItems, related_name="procurement_material_issue_item_grn_item", on_delete=models.CASCADE, null=True, blank=True)
    purchase_item = models.ForeignKey(PurchaseItems, related_name="procurement_material_issue_item_purchase_item", on_delete=models.CASCADE, null=True, blank=True)

    chainage_from = models.FloatField(default=0)
    chainage_to = models.FloatField(default=0)
    received_date = models.DateField(null=True, blank=True)
    received_site = models.ForeignKey(SiteMaster, related_name='procurement_material_issue_items_received_site',
                                      on_delete=models.CASCADE, null=True, blank=True)
    purchase_voucher_no = models.CharField(max_length=200, blank=True, null=True)
    received_quantity = models.FloatField(default=0)
    return_quantity = models.FloatField(default=0)
    received_unit = models.ForeignKey(UnitOfMesurement, related_name='procurement_material_issue_items_received_unit',
                                      on_delete=models.CASCADE, null=True, blank=True)
    received_no = models.CharField(max_length=200, blank=True, null=True)
    waybill_form_no = models.CharField(max_length=200, blank=True, null=True)
    is_royalty_received = models.BooleanField(default=False)
    royalty_no = models.CharField(max_length=200, null=True, blank=True)
    royalty_quantity = models.FloatField(default=0)
    in_time = models.TimeField(null=True, blank=True)
    out_time = models.TimeField(null=True, blank=True)
    reach_time = models.TimeField(null=True, blank=True)
    unload_time = models.TimeField(null=True, blank=True)
    return_time = models.TimeField(null=True, blank=True)
    voucher_type = models.CharField(max_length=200, null=True, blank=True)

    chainage_from_acknowledge = models.FloatField(default=0)
    chainage_to_acknowledge = models.FloatField(default=0)
    received_date_acknowledge = models.DateField(null=True, blank=True)
    received_site_acknowledge = models.ForeignKey(SiteMaster,
                                                  related_name='procurement_material_issue_items_received_site_acknowledge',
                                                  on_delete=models.CASCADE, null=True, blank=True)
    purchase_voucher_no_acknowledge = models.CharField(max_length=200, blank=True, null=True)
    received_quantity_acknowledge = models.FloatField(default=0)
    received_unit_acknowledge = models.ForeignKey(UnitOfMesurement,
                                                  related_name='procurement_material_issue_items_received_unit_acknowledge',
                                                  on_delete=models.CASCADE, null=True, blank=True)
    received_no_acknowledge = models.CharField(max_length=200, blank=True, null=True)
    waybill_form_no_acknowledge = models.CharField(max_length=200, blank=True, null=True)
    is_royalty_received_acknowledge = models.BooleanField(default=False)
    royalty_no_acknowledge = models.CharField(max_length=200, null=True, blank=True)
    royalty_quantity_acknowledge = models.FloatField(default=0)
    in_time_acknowledge = models.TimeField(null=True, blank=True)
    out_time_acknowledge = models.TimeField(null=True, blank=True)
    reach_time_acknowledge = models.TimeField(null=True, blank=True)
    unload_time_acknowledge = models.TimeField(null=True, blank=True)
    return_time_acknowledge = models.TimeField(null=True, blank=True)
    voucher_type_acknowledge = models.CharField(max_length=200, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_items_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_items_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_items_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_items_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_items_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    
    is_auto_approved = models.BooleanField(default=False)
    unit_of_entry = models.CharField(max_length=255, null=True, blank=True)
    material_description = models.CharField(max_length=255, null=True, blank=True)
    qty_unit_entry = models.CharField(max_length=255, null=True, blank=True)
    po_item = models.CharField(max_length=255, null=True, blank=True)
    material_doc_item = models.CharField(max_length=255, null=True, blank=True)
    asset = models.CharField(max_length=255, null=True, blank=True)
    order = models.CharField(max_length=255, null=True, blank=True)
    order_price_unit = models.CharField(max_length=255, null=True, blank=True)
    order_unit = models.CharField(max_length=255, null=True, blank=True)
    qty_order_unit = models.CharField(max_length=255, null=True, blank=True)
    ext_amount = models.CharField(max_length=255, null=True, blank=True)
    sales_value = models.CharField(max_length=255, null=True, blank=True)
    sales_order_schedule = models.CharField(max_length=255, null=True, blank=True)
    sales_order_item = models.CharField(max_length=255, null=True, blank=True)
    del_note_quantity = models.CharField(max_length=255, null=True, blank=True)
    salesorderitem = models.CharField(max_length=255, null=True, blank=True)
    wbs_element = models.CharField(max_length=255, null=True, blank=True)
    network = models.CharField(max_length=255, null=True, blank=True)
    reservation = models.CharField(max_length=255, null=True, blank=True)
    item_no_reservation = models.CharField(max_length=255, null=True, blank=True)
    debit_credit_ind = models.CharField(max_length=255, null=True, blank=True)
    sales_value_vat = models.CharField(max_length=255, null=True, blank=True)
    original_line_item = models.CharField(max_length=255, null=True, blank=True)
    
    delivery_note_unit=models.CharField(max_length=255, null=True, blank=True)
    qty_op_unit = models.CharField(max_length=255, null=True, blank=True)

    routing_no_operations = models.CharField(max_length=255, null=True, blank=True)
    smart_number = models.CharField(max_length=255, null=True, blank=True)
    activity = models.CharField(max_length=255, null=True, blank=True)
    wbselement = models.CharField(max_length=255, null=True, blank=True)
    stock_segment = models.CharField(max_length=255, null=True, blank=True)
    issue_slip = models.CharField(max_length=255, null=True, blank=True)
    item_auto_created = models.CharField(max_length=255, null=True, blank=True)
    multiple_account_assignment = models.CharField(max_length=255, null=True, blank=True)
    consumption = models.CharField(max_length=255, null=True, blank=True)
    sub_number = models.CharField(max_length=255, null=True, blank=True)
    counter = models.CharField(max_length=255, null=True, blank=True)
    rr_text = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "procurement_material_issue_items"

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.chainage_to:
            self.chainage_to = 0
        if not self.chainage_from:
            self.chainage_from = 0
        self.diff = float(self.chainage_to) - float(self.chainage_from)
        if not self.chainage_to_acknowledge:
            self.chainage_to_acknowledge = 0
        if not self.chainage_from_acknowledge:
            self.chainage_from_acknowledge = 0
        self.diff = float(self.chainage_to_acknowledge) - float(self.chainage_from_acknowledge)
        if not self.rate:
            self.rate = 0
        if not self.quantity:
            self.quantity = 0
        self.amount = float(self.rate) * float(self.quantity)
        super().save(*args, **kwargs)


class MaterialIssueItemsNotes(BaseAbstractStructure):
    """
    Material Issue Items
    """
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_material_issue_item_note_organizations',
                                     on_delete=models.CASCADE, null=True, blank=True)
    material_issue_item = models.ForeignKey(MaterialIssueItems,
                                            related_name='procurement_material_issue_item_note',
                                            on_delete=models.CASCADE, null=True, blank=True)
    note_title = models.CharField(max_length=100, blank=True, null=True)
    note_details = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = "procurement_material_issue_item_notes"


class MaterialIssueReturn(BaseAbstractStructure):
    RETURN_TYPE = (
        ('defective', 'Defective'),
        ('excess', 'Excess'),
        ('other', 'Other'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_material_issue_return_organizations',
                                     on_delete=models.CASCADE)
    material_issue = models.ForeignKey(MaterialIssue, related_name='procurement_material_issue_return_material_issue',
                                       on_delete=models.CASCADE, null=True, blank=True)  #
    material_issue_return_no = models.CharField(max_length=200)
    date = models.DateField(null=True, blank=True)
    return_type = models.CharField(max_length=200, choices=RETURN_TYPE, null=True, blank=True)
    return_location = models.CharField(max_length=200, null=True, blank=True)
    gate_pass_no = models.CharField(max_length=200, null=True, blank=True)
    return_from = models.CharField(max_length=200, null=True, blank=True)
    manual_slip_no = models.CharField(max_length=200, null=True, blank=True)
    in_our_carrying_vehicle = models.BooleanField(default=False)
    in_our_carrying_vehicle_text = models.TextField(max_length=500, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    return_to = models.ForeignKey(StoreMaster, related_name='procurement_material_issue_return_to_store',
                                  on_delete=models.CASCADE,
                                  null=True, blank=True)
    return_from_site = models.ForeignKey(SiteMaster, related_name='procurement_material_issue_return_from_site',
                                         on_delete=models.CASCADE, null=True, blank=True)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    plant_production = models.ForeignKey(PlantProduction, related_name="procurement_material_issue_return_transfer",
                                         on_delete=models.CASCADE, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_material_issue_return_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_material_issue_return"


class MaterialIssueReturnItems(BaseAbstractStructure):
    RETURN_FROM_CHOICES = (
        ('party', 'Party'),
        ('vehicle', 'Vehicle'),
        ('other', 'Other'),
        ('employee', 'Employee'),
        ('department', 'Department'),
        ('project', 'Project'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_material_issue_return_item_organizations',
                                     on_delete=models.CASCADE)
    material_issue_return = models.ForeignKey(MaterialIssueReturn,
                                              related_name='procurement_material_issue_return_items',
                                              on_delete=models.CASCADE, null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_material_issue_return_item',
                             on_delete=models.CASCADE)
    material_issue_item = models.ForeignKey(MaterialIssueItems,
                                            related_name='procurement_material_issue_return_material_issue_item',
                                            on_delete=models.CASCADE, null=True, blank=True)  #
    material_request_item = models.ForeignKey(MaterialRequestMasterItems,
                                              related_name='procurement_material_issue_return_material_request_item',
                                              on_delete=models.CASCADE, null=True, blank=True)  #
    weight_uom = models.ForeignKey(UnitOfMesurement,
                                   related_name='procurement_material_issue_return_material_request_item_uom',
                                   on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    is_scrap = models.BooleanField(default=False)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_material_issue_return_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    stock_quantity = models.FloatField(default=0)
    weight = models.FloatField(default=0)
    return_from = models.CharField(max_length=100, choices=RETURN_FROM_CHOICES, blank=True, null=True)
    rate = models.FloatField(default=0)
    amount = models.FloatField(default=0)
    log_book = models.TextField(max_length=500, null=True, blank=True)
    remark = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_items_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_items_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_items_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_items_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_return_items_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_material_issue_return_items"


class MaterialIssueReturnAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_material_issue_return_attachment_organizations',
                                     on_delete=models.CASCADE)
    material_issue_return = models.ForeignKey(MaterialIssueReturn,
                                              related_name='procurement_material_issue_return_attachments',
                                              on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/material_issue_return', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_material_issue_return_attachments"


class FabricationWork(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_fabrication_work_organizations',
                                     on_delete=models.CASCADE)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, related_name='procurement_fabrication_work_site',
                             null=True, blank=True)
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, related_name='procurement_fabrication_work_store',
                              null=True, blank=True)
    work_order = models.ForeignKey(WorkOrder, related_name='procurement_fabrication_works_work_order',
                                   on_delete=models.CASCADE)
    voucher_no = models.CharField(max_length=200, null=True, blank=True)
    request_code = models.CharField(max_length=100, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    party_bill_no = models.CharField(max_length=200, null=True, blank=True)
    bill_date = models.DateField(null=True, blank=True)
    fabrication_by = models.CharField(max_length=10, choices=[('self', 'Self'), ('party', 'Party')], default='self')
    fabrication_type = models.CharField(max_length=10, choices=[('new', 'New'), ('old', 'Old')], default='new')
    contractor = models.ForeignKey(VendorMasterV2, related_name='procurement_fabrication_work_contractor',
                                   on_delete=models.CASCADE, blank=True, null=True)
    select_template = models.CharField(max_length=200, null=True, blank=True)
    batch = models.CharField(max_length=200, null=True, blank=True)
    number_of_jobs = models.IntegerField(default=0, null=True, blank=True)
    location = models.CharField(max_length=200, null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_fabrication_work_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    total_raw_material_quantity = models.FloatField(default=0)
    total_raw_material_weight = models.FloatField(default=0)
    total_labor_amount = models.FloatField(default=0)
    total_finish_goods_quantity = models.FloatField(default=0)
    total_finish_goods_weight = models.FloatField(default=0)
    total_finish_goods_amount = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_fabrication_work"


class FabricationWorkRawMaterial(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_fabrication_work_raw_material_organizations',
                                     on_delete=models.CASCADE)
    fabrication_work = models.ForeignKey(FabricationWork, related_name='procurement_fabrication_work_raw_materials',
                                         on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_fabrication_work_raw_material',
                                 on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_fabrication_work_raw_material_uom', on_delete=models.CASCADE, null=True, blank=True)
    weight_uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_fabrication_work_raw_uom',
                                   on_delete=models.CASCADE, null=True, blank=True)
    weight = models.FloatField(default=0)
    l = models.FloatField(default=0)
    w = models.FloatField(default=0)
    t = models.FloatField(default=0)
    d = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_fabrication_work_raw_material"


class FabricationWorkFinishGoods(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_fabrication_work_finish_goods_organizations',
                                     on_delete=models.CASCADE)
    fabrication_work = models.ForeignKey(FabricationWork, related_name='procurement_fabrication_work_finish_goods',
                                         on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_fabrication_work_finish_good_material',
                                 on_delete=models.CASCADE, null=True, blank=True)
    weight_uom = weight_uom = models.ForeignKey(UnitOfMesurement,
                                                related_name='procurement_fabrication_work_finish_good_uom',
                                                on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_fabrication_work_finish_goods_uom', on_delete=models.CASCADE, null=True, blank=True)
    weight = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    amount = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.quantity:
            self.quantity = 0
        self.amount = float(self.rate) * float(self.quantity)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_fabrication_work_finish_goods"


class FabricationWorkLabor(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_fabrication_work_labor_organizations',
                                     on_delete=models.CASCADE)
    fabrication_work = models.ForeignKey(FabricationWork, related_name='procurement_fabrication_work_labors',
                                         on_delete=models.CASCADE, null=True, blank=True)
    category = models.ForeignKey(LabourMaster, related_name='procurement_fabrication_work_labor_labor',
                                 on_delete=models.CASCADE, null=True, blank=True)
    no_of_duty = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    amount = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_fabrication_work_labor"


class FabricationWorkAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_fabrication_work_attachments_organizations',
                                     on_delete=models.CASCADE)
    fabrication_work = models.ForeignKey(FabricationWork, related_name='procurement_fabrication_work_attachments',
                                         on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/fabrication_work', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_fabrication_work_attachments"


class TransportationRate(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_transportation_rates_organizations')
    sub_contractor = models.ForeignKey(VendorMasterV2, on_delete=models.CASCADE,
                                       related_name='procurement_transportation_rates_sub_contractor',
                                       null=True, blank=True)
    # financialyear = models.ForeignKey(FinancialYear, related_name='procurement_transportation_rate_financial_year',
    #                                   on_delete=models.CASCADE, blank=True, null=True)

    class Meta:
        db_table = "procurement_transportation_rate"


class TransportationRateItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_transportation_rate_items_organizations')
    transportation_rate = models.ForeignKey(TransportationRate, on_delete=models.CASCADE,
                                            related_name='procurement_transportation_rate_items', null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, on_delete=models.CASCADE,
                             related_name='procurement_transportation_rate_material', null=True, blank=True)
    fixed_rate = models.FloatField(default=0)
    fixed_rate_km = models.FloatField(default=0)
    rate_per = models.FloatField(default=0)
    rate_km = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_transportation_rate_items"


class RackSetting(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_rack_setting_organizations')
    location = models.ForeignKey(StoreMaster, on_delete=models.CASCADE,
                                 related_name='procurement_rack_setting_location')
    rack = models.ForeignKey(StoreSection, on_delete=models.CASCADE,
                             related_name='procurement_rack_setting_rack')
    # item = models.ForeignKey(VendorMaterialMaster, on_delete=models.CASCADE,related_name='procurement_rack_setting_material')
    item = models.ManyToManyField(VendorMaterialMaster, null=True, blank=True)

    class Meta:
        db_table = "procurement_rack_setting"


class MaterialWastage(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_material_wastage_organizations')
    material_waste_no = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    location = models.CharField(max_length=200, null=True, blank=True)
    wastage_type = models.CharField(max_length=10, choices=[('self', 'Self'), ('party', 'party')])
    is_stock_effect_required = models.BooleanField(default=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, related_name='procurement_material_wastage_site',
                             null=True, blank=True)
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, related_name='procurement_material_wastage_store',
                              null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_material_wastage_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_material_wastage"


class MaterialWastageItems(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_material_wastage_item_organizations')
    item = models.ForeignKey(VendorMaterialMaster, on_delete=models.CASCADE,
                             related_name='procurement_material_wastage_item', null=True, blank=True)
    material_wastage = models.ForeignKey(MaterialWastage, on_delete=models.CASCADE,
                                         related_name='procurement_material_wastage_items', null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    quantity = models.FloatField(default=0, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_material_wastage_items_uom_id', on_delete=models.CASCADE, null=True, blank=True)
    rate = models.FloatField(default=0, null=True, blank=True)
    amount = models.FloatField(default=0, null=True, blank=True)
    type = models.CharField(max_length=10, choices=[('wastage', 'Wastage'), ('shortage', 'Shortage')],
                            default='wastage')
    remark = models.TextField(null=True, blank=True)
    weight = models.FloatField(default=0, null=True, blank=True)
    weight_uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_material_wastage_items_uom',
                                   on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_items_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_items_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_items_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_items_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_wastage_items_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_material_wastage_items"


class MaterialWastageAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_material_wastage_attachment_organizations')
    material_wastage = models.ForeignKey(MaterialWastage, on_delete=models.CASCADE,
                                         related_name='procurement_material_wastage_attachments', null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/material_wastage', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_material_wastage_attachments"


class DocumentEmployeeApproval(BaseAbstractStructure):
    DOCTYPE = (
        ('mr', 'MR'),
        ('indent', 'Indent'),
        ('quotation', 'Quotation'),
        ('po', 'PO'),
        ('grn', 'GRN'),
        ('work_order', 'Work Order'),
    )
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_document_employee_approval_organizations')
    doctype = models.CharField(max_length=100, choices=DOCTYPE, blank=True, null=True)
    user = models.ForeignKey(PmsUser, on_delete=models.CASCADE,
                             related_name='procurement_document_employee_approval_user', null=True, blank=True)
    site = models.ManyToManyField(SiteMaster, null=True, blank=True)
    min_value = models.FloatField(default=0)
    max_value = models.FloatField(default=0)

    class Meta:
        unique_together = ('organization', 'doctype', 'user',)
        db_table = "procurement_document_employee_approval"


class LabTestingParameters(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_leb_testing_parameters_organizations')
    check_items = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_leb_testing_parameters"


class LabTestingParametersItem(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_leb_testing_parameters_item_organizations')
    lab_testing_parameters = models.ForeignKey(LabTestingParameters, on_delete=models.CASCADE,
                                               related_name='procurement_leb_testing_parameters_items',
                                               null=True, blank=True)
    item_group = models.ForeignKey(MaterialType, on_delete=models.CASCADE,
                                   related_name='procurement_leb_testing_parameters_item_organizations',
                                   null=True, blank=True)
    description = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "procurement_leb_testing_parameters_items"


class FreightContract(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_freight_contracts_organizations')
    effective_date = models.DateField(null=True, blank=True)
    source_city = models.ForeignKey(City, related_name='procurement_freight_contracts_source_city',
                                    on_delete=models.CASCADE, null=True, blank=True)
    distance = models.FloatField(default=0)
    tolerance_level = models.FloatField()
    # account = models.CharField(max_length=200)
    account = models.ForeignKey(AccountsHead, on_delete=models.CASCADE,
                                related_name='procurement_freight_contracts_account', null=True, blank=True)
    destination_city = models.ForeignKey(City, related_name='procurement_freight_contracts_destination_city',
                                         on_delete=models.CASCADE, null=True, blank=True)
    rate_mt = models.FloatField(default=0)
    rate_bag = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_freight_contract"


class RateContract(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_rate_contract_organizations')
    entry_date = models.DateField(null=True, blank=True)
    effect_date = models.DateField(null=True, blank=True)
    # account = models.CharField(max_length=200)
    account = models.ForeignKey(AccountsHead, on_delete=models.CASCADE,
                                related_name='procurement_rate_contract_account', null=True, blank=True)
    item_group = models.ForeignKey(MaterialType, on_delete=models.CASCADE,
                                   related_name='procurement_rate_contract_item_groups', null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, on_delete=models.CASCADE,
                             related_name='procurement_rate_contract_items', null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE,
                             related_name='procurement_rate_contract_sites', null=True, blank=True)
    company_rate = models.FloatField(default=0, null=True, blank=True)
    edu_percentage = models.FloatField(default=0, null=True, blank=True)
    she_percentage = models.FloatField(default=0, null=True, blank=True)
    vat_percentage = models.FloatField(default=0, null=True, blank=True)
    invoice_rate = models.FloatField(default=0, null=True, blank=True)
    company_discount = models.FloatField(default=0, null=True, blank=True)
    edu_amount = models.FloatField(default=0, null=True, blank=True)
    she_amount = models.FloatField(default=0, null=True, blank=True)
    vat_amount = models.FloatField(default=0, null=True, blank=True)
    additional_discount = models.FloatField(default=0, null=True, blank=True)
    basic_rate = models.FloatField(default=0, null=True, blank=True)
    excise_percentage = models.FloatField(default=0, null=True, blank=True)
    cst_percentage = models.FloatField(default=0, null=True, blank=True)
    total_rate = models.FloatField(default=0, null=True, blank=True)
    net_rate = models.FloatField(default=0, null=True, blank=True)
    tax_type = models.ForeignKey(TaxHead, on_delete=models.CASCADE, related_name='procurement_rate_contract_tax_types',
                                 null=True, blank=True)
    excise_amount = models.CharField(max_length=200, null=True, blank=True)
    cst_amount = models.FloatField(default=0, null=True, blank=True)
    discount = models.FloatField(default=0, null=True, blank=True)

    class Meta:
        db_table = "procurement_rate_contract"


class OtherTextbox(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_other_textbox_organizations')
    value = models.TextField()

    class Meta:
        db_table = "procurement_other_textbox"


class ApprovalDoctype(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_approval_doctype_organizations')
    indent = models.ForeignKey(Indent, on_delete=models.CASCADE,
                               related_name='procurement_approval_doctype_indent')
    department_type = models.CharField(max_length=200)

    class Meta:
        db_table = "procurement_approval_doctype"


class MonthFinancialYearLock(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_material_financial_year_lock_organizations')
    month = models.PositiveIntegerField()
    year = models.PositiveIntegerField()
    financial_year = models.ForeignKey(FinancialYear, related_name='procurement_material_financial_year_lock_financial_year', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE,
                             related_name='procurement_material_financial_year_lock_sites', null=True, blank=True, )
    mr = models.BooleanField(default=False)  # done
    indent = models.BooleanField(default=False)
    enquiry = models.BooleanField(default=False)
    quotation = models.BooleanField(default=False)  # done
    po = models.BooleanField(default=False)  # done
    grn = models.BooleanField(default=False)  # done
    purchase = models.BooleanField(default=False)  # Done
    raw_material_sale = models.BooleanField(default=False)
    min_max_challan = models.BooleanField(default=False)
    purchase_return = models.BooleanField(default=False)
    transport_bill = models.BooleanField(default=False)
    item_opening = models.BooleanField(default=False)
    physical_stock = models.BooleanField(default=False)  # done
    issue = models.BooleanField(default=False)  # done
    material_wastage = models.BooleanField(default=False)
    material_issue_return = models.BooleanField(default=False)  # done
    fabrication_work = models.BooleanField(default=False)
    gate_pass = models.BooleanField(default=False)  # done
    item_jv = models.BooleanField(default=False)

    class Meta:
        db_table = "procurement_material_financial_year_lock"
        unique_together = ('site', 'month', 'year')


class RestrictItemGroup(BaseAbstractStructure):
    TYPE = (
        ('mr', 'Material Request'),
        ('indent', 'Indent'),
        ('enquiry', 'Enquiry'),
        ('quotation', 'Quotation'),
        ('po', 'Purchase Order'),
        ('grn', 'DIRECT GRN'),
        ('purchase', 'Purchase'),
        ('raw_material_sale', 'Raw Material Sale'),
        ('min_max_challan', 'Min/Max Challan'),
        ('purchase_return', 'Purchase Return'),
        ('transport_bill', 'Transport Bill'),
        ('item_opening', 'Item Opening'),
        ('physical_stock', 'Physical Stock'),
        ('issue', 'Material Issue'),
        ('material_wastage', 'Material Wastage'),
        ('material_issue_return', 'Material Issue Return'),
        ('fabrication_work', 'Fabrication Work'),
        ('gate_pass', 'Gate Pass'),
        ('item_jv', 'Item JV')
    )
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_restrict_item_group_organizations')
    page_name = models.CharField(max_length=100, choices=TYPE, blank=True, null=True, default="grn")
    item_group = models.ManyToManyField(MaterialType, related_name='procurement_restrict_item_group_item_group')
    site = models.ManyToManyField(SiteMaster, related_name='procurement_restrict_item_group_site')

    class Meta:
        db_table = "procurement_restrict_item_group"


class GeneralSetting(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_general_setting_organizations')
    is_active = models.BooleanField(default=True)
    setting_name = models.CharField(max_length=200)
    tag = models.CharField(max_length=200, unique=True)
    site = models.ManyToManyField(SiteMaster, related_name='procurement_general_setting_site')

    class Meta:
        db_table = "procurement_general_setting"


class MultiStageSetting(BaseAbstractStructure):
    TYPE = (
        ('mr', 'Material Request'),
        ('indent', 'Indent'),
        ('enquiry', 'Enquiry'),
        ('quotation', 'Quotation'),
        ('po', 'Purchase Order'),
        ('grn', 'DIRECT GRN'),
        ('purchase', 'Purchase'),
        ('raw_material_sale', 'Raw Material Sale'),
        ('min_max_challan', 'Min/Max Challan'),
        ('purchase_return', 'Purchase Return'),
        ('transport_bill', 'Transport Bill'),
        ('item_opening', 'Item Opening'),
        ('physical_stock', 'Physical Stock'),
        ('issue', 'Material Issue'),
        ('material_wastage', 'Material Wastage'),
        ('material_issue_return', 'Material Issue Return'),
        ('fabrication_work', 'Fabrication Work'),
        ('gate_pass', 'Gate Pass'),
        ('item_jv', 'Item JV'),
        ('work_order', 'Work Order'),
        ('cst', 'CST'),
        ('pm', 'Payment Master'),
        ('pnmar', 'Plant & Machinery Asset Requisition'),
        ('pnmcst', 'Plant & Machinery CST'),
        ('pnmhbi', 'Plant & Machinery Hire Bill Invoice'),
        ('pnmhsda', 'Plant & Machinery HSD Approval'),
        ('old', 'OLD'),
    )
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_multi_stage_setting_organizations')
    from_name = models.CharField(max_length=100, choices=TYPE, blank=True, null=True, default="po")
    site = models.ManyToManyField(SiteMaster, related_name='procurement_multi_stage_setting_sites')
    conditions = models.JSONField(null=True, blank=True)
    multi_stage_name = models.CharField(max_length=100, null=True, blank=True)
    is_archived = models.BooleanField(default=False)

    def __str__(self):
        return self.from_name

    class Meta:
        db_table = "procurement_multi_stage_setting"
        # unique_together = ('organization', 'from_name')


class MultiStageSettingStages(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,
                                     related_name='procurement_multi_stage_setting_stages_organizations')
    multi_stage_setting = models.ForeignKey(MultiStageSetting, on_delete=models.CASCADE, null=True, blank=True,
                                            related_name='procurement_multi_stage_setting_stages')
    stage_name = models.CharField(max_length=50)
    ref_stage_name = models.CharField(max_length=50)
    stage = models.IntegerField()
    remarks_required = models.BooleanField(default=True)
    department = models.ManyToManyField(Department, related_name='procurement_multi_stage_setting_stages_departments',
                                        null=True, blank=True, )
    employee = models.ManyToManyField(PmsUser, related_name='procurement_multi_stage_setting_stages_employees',
                                      null=True, blank=True, )

    def __str__(self):
        return self.stage_name

    class Meta:
        db_table = "procurement_multi_stage_setting_stages"


class SiteWiseStockLevelSetting(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_site_wise_stock_level_settings_organizations',
                                     on_delete=models.CASCADE)
    site = models.ForeignKey(SiteMaster, related_name='procurement_site_wise_stock_level_settings_site',
                             on_delete=models.CASCADE)
    item_type = models.ForeignKey(MaterialType, on_delete=models.CASCADE,
                                  related_name='procurement_site_wise_stock_level_item_type',
                                  null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster,
                                 related_name='procurement_site_wise_stock_level_settings_material',
                                 on_delete=models.CASCADE)
    inventory = models.ForeignKey(Inventory, related_name='procurement_site_wise_stock_level_settings_inventory',
                                  on_delete=models.CASCADE)
    min_quantity = models.FloatField(default=0)
    max_quantity = models.FloatField(default=0)
    financial_year = models.ForeignKey(FinancialYear, related_name='procurement_site_wise_stock_level_settings_financial_year', on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.site} - {self.item_type} - {self.material} - {self.financial_year}"

    class Meta:
        db_table = "procurement_site_wise_stock_level_setting"


class GeneralAdministrationExpenses(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_general_admin_expenses_organizations',
                                     on_delete=models.CASCADE)
    voucher_no = models.CharField(max_length=200, null=True, blank=True)
    request_code = models.CharField(max_length=100, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    p_b_date = models.DateField(null=True, blank=True)
    party_bill_no = models.CharField(max_length=200, null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_general_admin_expenses_vendor',
                               on_delete=models.CASCADE, null=True, blank=True)
    vendor_state_gstin = models.CharField(max_length=200, null=True, blank=True)
    vendor_state = models.ForeignKey(State, related_name='procurement_general_admin_expenses_vendor_state',
                                     on_delete=models.CASCADE, null=True, blank=True)
    sale_pur_trans_type = models.CharField(max_length=100, null=True, blank=True)
    site_state_gstin = models.CharField(max_length=200, null=True, blank=True)
    site_state = models.ForeignKey(State, related_name='procurement_general_admin_expenses_site_state',
                                   on_delete=models.CASCADE, null=True, blank=True)
    apply_forcefully_rcm = models.BooleanField(default=False)
    is_place_of_supply_different = models.BooleanField(default=False)
    narration = models.TextField(null=True, blank=True)
    total_amount = models.FloatField(default=0)
    total_sgst_amount = models.FloatField(default=0)
    total_utgst_amount = models.FloatField(default=0)
    total_cgst_amount = models.FloatField(default=0)
    total_igst_amount = models.FloatField(default=0)
    total_cess_amount = models.FloatField(default=0)
    total_amount_with_all_taxes = models.FloatField(default=0)
    net_amount = models.FloatField(default=0)

    class Meta:
        db_table = "procurement_finance_general_admin_expenses"


class GeneralAdministrationExpenseItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_general_admin_expense_items_organizations',
                                     on_delete=models.CASCADE)
    general_admin_expense = models.ForeignKey(GeneralAdministrationExpenses,
                                              related_name='procurement_general_admin_expense_items',
                                              on_delete=models.CASCADE, null=True, blank=True)
    account = models.ForeignKey(AccountsHead, related_name='procurement_general_admin_expense_items_account',
                                on_delete=models.CASCADE, null=True, blank=True)
    account_hsn_code = models.ForeignKey(HSNMaster, related_name='procurement_general_admin_expense_items_account_hsn_code',
                                on_delete=models.CASCADE, null=True, blank=True)
    # account_hsn_code = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    amount = models.FloatField(default=0)
    debit_credit = models.CharField(max_length=2, choices=[('de', 'DR'), ('cr', 'CR')])
    sgst_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.amount:
            self.amount = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.sgst_amount = float(self.amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_general_admin_expense_items"


class GeneralAdministrationExpensesAttachments(BaseAbstractStructure):
    """
    general_admin_expense attachments
    """
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_general_admin_expense_attachment_organizations',
                                     on_delete=models.CASCADE)
    general_admin_expense = models.ForeignKey(GeneralAdministrationExpenses,
                                              related_name='procurement_general_admin_expense_attachment',
                                              on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/general_admin_expense', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_general_admin_expense_attachments"


class RawMaterialSales(BaseAbstractStructure):
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    BILL_TYPE_CHOICES = [
        ('excise_invoice', 'Excise Invoice'),
        ('high_seas', 'High Seas'),
        ('retail_invoice', 'Retail Invoice'),
        ('service_tax', 'Service Tax'),
        ('tax_invoice', 'Tax Invoice'),
    ]

    ENTRY_TAX_TYPE_CHOICES = [
        ('on_item_value', 'On Item Value'),
        ('on_before_vat_cst', 'On Before VAT/CST'),
        ('on_after_vat_cst', 'On After VAT/CST'),
    ]
    ADDRESS_TYPE = (
        ('account', 'Account'),
        ('gst', 'GST'),
    )
    ADDRESS_OF = (
        ('site', 'Site'),
        ('gst', 'GST'),
        ('location', 'Location'),
        ('company', 'Company'),
    )
    DISPLAY_DETAILS = (
        ('site', 'Site'),
        ('gst', 'GST'),
        ('location', 'Location'),
    )
    GST_ON = (
        ('party', 'Party'),
        ('buyer', 'Buyer'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_raw_material_sales_organizations',
                                     on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_raw_material_sales_project', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_raw_material_sales_site',
                             on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_raw_material_sales_store',
                              on_delete=models.CASCADE, null=True, blank=True)
    request_code = models.CharField(max_length=100, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="vat")
    bill_type = models.CharField(max_length=20, choices=BILL_TYPE_CHOICES, default="excise_invoice", null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    issue_time = models.TimeField(null=True, blank=True)
    rm_sale_voucher_no = models.CharField(max_length=200, null=True, blank=True)
    invoice_no_prefix = models.CharField(max_length=200, null=True, blank=True)
    removal_date = models.DateField(null=True, blank=True)
    removal_time = models.TimeField(null=True, blank=True)
    is_stock_effect = models.BooleanField(default=False)
    mfgr_no = models.FloatField(default=0)
    sale_from_location = models.CharField(max_length=200, null=True, blank=True)
    party_name = models.ForeignKey(VendorMasterV2, on_delete=models.CASCADE,
                                   related_name='procurement_raw_material_sales_party', null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, on_delete=models.CASCADE, related_name='procurement_raw_material_sales_financialyear', null=True, blank=True)
    destination = models.CharField(max_length=200, null=True, blank=True)
    transporter = models.CharField(max_length=200, null=True, blank=True)
    manufacturer = models.CharField(max_length=200, null=True, blank=True)
    lr_no_date = models.DateField(null=True, blank=True)
    vehicle_no = models.CharField(max_length=200, null=True, blank=True)
    total_quantity = models.FloatField(default=0)
    total_item_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    total_excise_amount = models.FloatField(default=0)
    total_discount_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    remarks = models.TextField(null=True, blank=True)
    narration = models.TextField(null=True, blank=True)
    jurisdiction = models.CharField(max_length=200, null=True, blank=True)
    
    site_state = models.ForeignKey(State, on_delete=models.CASCADE, related_name='procurement_raw_material_sales_site_state', null=True, blank=True)
    manual_bill_no = models.CharField(max_length=200, null=True, blank=True)
    party_state = models.ForeignKey(State, on_delete=models.CASCADE, related_name='procurement_raw_material_sales_party_state', null=True, blank=True)
    address_type = models.CharField(max_length=100, choices=ADDRESS_TYPE, blank=True, null=True, default="account")
    lr_no = models.CharField(max_length=200, null=True, blank=True)
    royalty_no = models.CharField(max_length=200, null=True, blank=True)
    buyer_name = models.ForeignKey(VendorMasterV2, on_delete=models.CASCADE, related_name='procurement_raw_material_sales_buyer_name', null=True, blank=True)
    buyer_state = models.ForeignKey(State, on_delete=models.CASCADE, related_name='procurement_raw_material_sales_buyer_state', null=True, blank=True)
    job_site = models.ForeignKey(SiteMaster, related_name='procurement_raw_material_sales_job_site', on_delete=models.CASCADE, null=True, blank=True)
    show_address_of = models.CharField(max_length=100, choices=ADDRESS_OF, blank=True, null=True, default="site")
    display_details = models.CharField(max_length=100, choices=DISPLAY_DETAILS, blank=True, null=True, default="site")
    vehicle_no = models.CharField(max_length=200, null=True, blank=True)
    transport_gst = models.CharField(max_length=200, null=True, blank=True)
    gst_calculation_on = models.CharField(max_length=100, choices=GST_ON, blank=True, null=True, default="party")
    eway_bill_no = models.CharField(max_length=200, null=True, blank=True)
    eway_bill_date = models.DateField(null=True, blank=True)
    
    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)

    # excise = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_excise',
    #                            on_delete=models.CASCADE, null=True, blank=True)
    # excise_incl = models.BooleanField(default=False)
    # excise_percentage = models.FloatField(default=0)
    # excise_amount = models.FloatField(default=0)
    # edu_cess_percentage = models.FloatField(default=0)
    # edu_cess_amount = models.FloatField(default=0)
    # she_cess_percentage = models.FloatField(default=0)
    # she_cess_amount = models.FloatField(default=0)
    # vat_tax = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_vat_tax',
    #                             on_delete=models.CASCADE, null=True, blank=True)
    # vat_tax_incl = models.BooleanField(default=False)
    # vat_tax_percentage = models.FloatField(default=0)
    # vat_tax_amount = models.FloatField(default=0)
    # additional_tax = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_additional_tax',
    #                                    on_delete=models.CASCADE, null=True, blank=True)
    # additional_tax_incl = models.BooleanField(default=False)
    # additional_tax_percentage = models.FloatField(default=0)
    # additional_tax_amount = models.FloatField(default=0)
    # tcs_incl = models.BooleanField(default=False)
    # tcs = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_tcs',
    #                         on_delete=models.CASCADE, null=True, blank=True)
    # tcs_percentage = models.FloatField(default=0)
    # tcs_amount = models.FloatField(default=0)
    # entry_tax = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_entry_tax',
    #                               on_delete=models.CASCADE, null=True, blank=True)
    # entry_tax_type = models.CharField(max_length=20, choices=ENTRY_TAX_TYPE_CHOICES, default="on_item_value", null=True, blank=True)
    # is_entry_tax_paid = models.BooleanField(default=False)
    # entry_tax_incl = models.BooleanField(default=False)
    # entry_tax_percentage = models.FloatField(default=0)
    # entry_tax_amount = models.FloatField(default=0)
    # service_tax_incl = models.BooleanField(default=False)
    # service_tax_percentage = models.FloatField(default=0)
    # service_tax_amount = models.FloatField(default=0)
    # discount_incl = models.BooleanField(default=0)
    # discount_amount = models.FloatField(default=False)
    # discount_percentage = models.FloatField(default=False)
    # freight = models.FloatField(default=0)
    # round_off = models.FloatField(default=0)
    # others = models.FloatField(default=0)
    # total_value = models.FloatField(default=0)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_raw_material_sales_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_raw_material_sales_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_raw_material_sales_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_raw_material_sales_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_raw_material_sales_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_raw_material_sales"


class RawMaterialSalesItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_raw_material_sales_item_organizations',
                                     on_delete=models.CASCADE)
    raw_material_sales = models.ForeignKey(RawMaterialSales, related_name='procurement_raw_material_sales_items',
                                           on_delete=models.CASCADE, null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_raw_material_sales_item_material',
                             on_delete=models.CASCADE, null=True, blank=True)
    size_part_no_grade = models.CharField(max_length=200, null=True, blank=True)
    weight = models.FloatField(default=0)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_raw_material_sales_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    tolerance_percentage = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_items_excise_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_items_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)

    # quantity = models.FloatField(default=0)
    # weight = models.FloatField(default=0)
    # rate = models.FloatField(default=0)
    # amount = models.FloatField(default=0)
    # tax_percentage = models.FloatField(default=0)
    # tax_amount = models.FloatField(default=0)
    # excise_percentage = models.FloatField(default=0)
    # excise_amount = models.FloatField(default=0)
    # discount_percentage = models.FloatField(default=0)
    # discount_amount = models.FloatField(default=0)
    # total_amount = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_raw_material_sales_items"


class RawMaterialSalesTaxDetails(BaseAbstractStructure):
    """
    RawMaterialSales Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_raw_material_sales_tax_organizations',
                                     on_delete=models.CASCADE)
    raw_material_sales = models.ForeignKey(RawMaterialSales, related_name='procurement_raw_material_sales_tax', on_delete=models.CASCADE,
                                  null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_tax_head', on_delete=models.CASCADE,
                                 null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = RawMaterialSales.cmobjects.filter(pk=self.raw_material_sales.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.procurement_raw_material_sales_tax.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_raw_material_sales_tax.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value) * float(self.tax_percentage) / 100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount) * float(self.sgst_percentage) / 100
        self.cgst_amount = float(self.tax_amount) * float(self.cgst_percentage) / 100
        self.igst_amount = float(self.tax_amount) * float(self.igst_percentage) / 100
        self.utgst_amount = float(self.tax_amount) * float(self.utgst_percentage) / 100
        self.cess_amount = float(self.tax_amount) * float(self.cess_percentage) / 100
        self.total_tax_amount = float(self.tax_amount) + float(self.sgst_amount) + float(self.cgst_amount) + float(
            self.igst_amount) + float(self.utgst_amount) + float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_raw_material_sales_tax"


class RawMaterialSalesExpenseDetails(BaseAbstractStructure):
    """
    Raw Material Sales Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_raw_material_sales_expense_organizations',
                                     on_delete=models.CASCADE)
    raw_material_sales = models.ForeignKey(RawMaterialSales,
                                       related_name='procurement_raw_material_sales_expense',
                                       on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_raw_material_sales_expense_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_raw_material_sales_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = RawMaterialSales.cmobjects.filter(pk=self.raw_material_sales.id).first()
        if self.expense_on_parent:
            value = getattr(parent_record, self.expense_on_parent)
        elif self.expense_on_self:
            temp = parent_record.procurement_raw_material_sales_expense.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_raw_material_sales_expense.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_raw_material_sales_expense"


class RawMaterialSalesAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_raw_material_sales_attachment_organizations',
                                     on_delete=models.CASCADE)
    raw_material_sales = models.ForeignKey(RawMaterialSales, related_name='procurement_raw_material_sales_attachments',
                                           on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/raw_material_sales', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_raw_material_sales_attachments"


class TransporterBill(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_transporter_bill_organizations',
                                     on_delete=models.CASCADE)

    invoice_no = models.CharField(max_length=100, blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    bill_no = models.CharField(max_length=100, blank=True, null=True)
    bill_date = models.DateField(blank=True, null=True)
    site_state = models.ForeignKey(State, related_name='procurement_transporter_bill_site_state', blank=True, null=True, on_delete=models.CASCADE)
    rate_to_fill = models.CharField(choices=(('only_loc', 'only_loc'),
                                             ('from_to_chainage', 'from_to_chainage'),
                                             ('from_chainage', 'from_chainage'),
                                             ('to_chainage', 'to_chainage'),
                                             ),
                                    blank=True, null=True, default='only_loc',max_length=100)
    hsn_sac_code = models.CharField(max_length=100, blank=True, null=True)
    transporter = models.ForeignKey(VendorMasterV2, related_name='procurement_transporter_bill_transporter',  blank=True, null=True, on_delete=models.CASCADE)
    transporter_state = models.ForeignKey(State, related_name='procurement_transporter_bill_transporter_state', blank=True, null=True, on_delete=models.CASCADE)
    apply_forcefully_rcm = models.BooleanField(blank=True, null=True, default=False)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")

    # m2m
    site = models.ManyToManyField(SiteMaster, related_name='procurement_transporter_bill_site', null=True, blank=True)
    store = models.ManyToManyField(StoreMaster, related_name='procurement_transporter_bill_store', null=True,
                                   blank=True)
    remarks = models.TextField(max_length=500, blank=True, null=True)

    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_weight = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_item_short_age_qty = models.FloatField(default=0) # new
    total_item_excess_qty = models.FloatField(default=0) # new
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)

    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_transporter_bill_financial_year', on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_transporter_bill_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_transporter_bill_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_transporter_bill_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_transporter_bill_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_transporter_bill_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_transporter_bill"
        verbose_name_plural = "Transporter bills"
        ordering = ('-id',)


class TransporterBillItems(BaseAbstractStructure):


    organization = models.ForeignKey(Organization, related_name='procurement_transporter_bill_items_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(TransporterBill,
                               related_name='procurement_transporter_bill_items',
                               on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster,related_name='procurement_transporter_bill_items_materials',
                               on_delete=models.CASCADE, null=True, blank=True)
    party = models.ForeignKey(VendorMasterV2, related_name='procurement_transporter_bill_items_party',
                               on_delete=models.CASCADE, null=True, blank=True)
    issue = models.ForeignKey(MaterialIssue, related_name='procurement_transporter_bill_items_issue',
                              on_delete=models.CASCADE, null=True, blank=True)
    grn = models.ForeignKey(GRN, related_name='procurement_transporter_bill_items_grn', on_delete=models.CASCADE, null=True,
                            blank=True)
    transporter = models.ForeignKey(VendorMasterV2, related_name='procurement_transporter_bill_items_transporter',
                               on_delete=models.CASCADE, null=True, blank=True)
    transporter_name = models.CharField(blank=True, null=True, max_length=200)  # grn transporter_name
    transporter_state_name = models.CharField(blank=True, null=True, max_length=200)

    bill_date = models.DateField(blank=True, null=True)
    delivery_date = models.DateField(blank=True, null=True)
    voucher_no = models.CharField(blank=True, null=True, default='#', max_length=100)
    voucher_date = models.DateField(blank=True, null=True)
    challan_no = models.CharField(blank=True, null=True, default='#', max_length=100)
    challan_qty = models.FloatField(blank=True, null=True, default=.0)

    track_no = models.CharField(max_length=100, blank=True, null=True)
    short_age_qty = models.FloatField(blank=True, null=True, default=0.)
    excess_qty = models.FloatField(blank=True, null=True, default=0.)
    halting_charge = models.FloatField(blank=True, null=True, default=0.)
    chanage_qty = models.FloatField(blank=True, null=True, default=0.)
    received_qty = models.FloatField(blank=True, null=True, default=0.)
    freight_charge = models.FloatField(blank=True, null=True, default=0.)
    km_run = models.FloatField(blank=True, null=True, default=0.)
    tax_type = models.CharField(choices=(('gst', 'gst'), ('vat', 'vat')), blank=True, null=True, default='gst',
                                max_length=50)
    amount = models.FloatField(blank=True, null=True, default=0.)

    weight = models.FloatField(default=0)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_transporter_bill_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    tolerance_percentage = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_transporter_bill_items_excise_tax_head',
                                        on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_transporter_bill_items_tax_head', on_delete=models.CASCADE,
                                 null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    # notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)


    class Meta:
        db_table = "procurement_transporter_bill_items"
        verbose_name_plural = "Transporter bill items"
        ordering = ('id', )


class TransporterBillExpenseDetails(BaseAbstractStructure):
    """
    TransporterBillExpenseDetails
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_transporter_bill_expense_details_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(TransporterBill,
                                       related_name='procurement_transporter_bill_expense_details',
                                       on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_transporter_bill_expense_details_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_transporter_bill_expense_details_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = TransporterBill.cmobjects.filter(pk=self.master.id).first()
        if self.expense_on_parent:
            value = getattr(parent_record, self.expense_on_parent)
        elif self.expense_on_self:
            temp = parent_record.procurement_transporter_bill_expense_details.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_transporter_bill_expense_details.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_transporter_bill_expense_details"


class TransporterBillShortageCharges(BaseAbstractStructure):
    """
    TransporterBillShortageCharges model
    """
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_transporter_bill_shortage_charges_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(TransporterBill,
                               related_name='procurement_transporter_bill_shortage_charges',
                               on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster,related_name='procurement_transporter_bill_shortage_charges_materials',
                               on_delete=models.CASCADE, null=True, blank=True)
    shortage_charge = models.FloatField(blank=True, null=True, default=0.)
    quantity = models.FloatField(blank=True, null=True, default=0.)
    uom = models.ForeignKey(UnitOfMesurement, related_name='TransporterBillShortageCharges_uom', on_delete=models.CASCADE, null=True, blank=True)
    issued_amount = models.FloatField(blank=True, null=True, default=0.)
    repair_n_maintenance = models.FloatField(blank=True, null=True, default=0.)
    class Meta:
        db_table = "procurement_transporter_bill_shortage_charges"


class TransporterBillTaxDetails(BaseAbstractStructure):
    """
    TransporterBill Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_transporter_bill_tax_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(TransporterBill,
                                       related_name='procurement_transporter_bill_tax',
                                       on_delete=models.CASCADE, null=True, blank=True)

    round_off = models.FloatField(blank=True, null=True, default=0.)
    invoice_amount = models.FloatField(blank=True, null=True, default=0.)
    advance_amount = models.FloatField(blank=True, null=True, default=0.)
    final_balance = models.FloatField(blank=True, null=True, default=0.)

    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_transporter_bill_tax_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = TransporterBill.cmobjects.filter(pk=self.master.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.procurement_transporter_bill_tax.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_transporter_bill_tax.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.tax_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.tax_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.tax_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.tax_amount)*float(self.cess_percentage)/100
        self.total_tax_amount = float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_transporter_bill_tax"


class TransporterBillAttachments(BaseAbstractStructure):
    """
        TransporterBill Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_transporter_bill_attachments_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(TransporterBill, related_name='procurement_transporter_bill_attachments',
                                    on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/transporter_bill', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return f"{self.pk} - {self.master if self.master else ''}  {'deleted' if self.is_deleted else 'not deleted'}"

    class Meta:
        db_table = "procurement_transporter_bill_attachments"
        verbose_name_plural = "Transporter Bill Attachments"


class TaxInvoice(BaseAbstractStructure):
    """
    TaxInvoice model
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )

    GST_ON = (
        ('party', 'Party'),
        ('buyer', 'Buyer'),
        ('bill_to', 'Bill to'),
        ('shipped_to', 'Shipped To'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_tax_invoice_organizations',
                                     on_delete=models.CASCADE)

    bill_no = models.CharField(max_length=100, blank=True, null=True)
    inv_date = models.DateField(blank=True, null=True)
    bill_date = models.DateField(blank=True, null=True)
    address = models.TextField(max_length=500, blank=True, null=True)
    delivery_address = models.TextField(max_length=500, blank=True, null=True)

    customer = models.ForeignKey(VendorMasterV2, related_name='procurement_tax_invoice_customer', on_delete=models.CASCADE, blank=True, null=True)
    customer_account_gst = models.CharField(max_length=200, blank=True, null=True)
    is_rcm = models.BooleanField(default=False)
    manual_bill_no = models.CharField(max_length=200, blank=True, null=True)
    sale_type = models.CharField(max_length=100, choices=(('registered', 'registered'), ('un-registered', 'un-registered'),), blank=True, null=True)
    # tax_type = models.CharField(max_length=100, choices=(('gst', 'gst'), ('vat', 'vat')), blank=True, null=True)
    tax_type = models.ForeignKey(TaxHead, related_name='procurement_tax_invoice_tax_type', on_delete=models.CASCADE, blank=True, null=True)
    wo = models.ForeignKey(WorkOrder, related_name='procurement_tax_invoice_ow', on_delete=models.CASCADE, blank=True, null=True)
    is_tax_applicable = models.BooleanField(default=True)
    transporter = models.ForeignKey(VendorMasterV2, related_name='procurement_tax_invoice_transporter', on_delete=models.CASCADE, blank=True, null=True)
    transporter_gst = models.CharField(max_length=200, blank=True, null=True)
    carrying_vehicle_no = models.CharField(max_length=100, blank=True, null=True)
    seller_address = models.CharField(max_length=50, blank=True, null=True) # choice ?
    dispatched_address = models.CharField(max_length=50, blank=True, null=True) # choice ?

    account_contact_person = models.CharField(max_length=200, blank=True, null=True)
    istp_no = models.CharField(max_length=100, blank=True, null=True)
    royalty_no = models.CharField(max_length=100, blank=True, null=True)
    name_of_work = models.CharField(max_length=100, blank=True, null=True)
    e_way_bill_no = models.CharField(max_length=100, blank=True, null=True)

    lr_no = models.CharField(max_length=50, blank=True, null=True)
    lr_date = models.DateField(blank=True, null=True)
    distance = models.FloatField(default=0.)
    bill_to_address = models.CharField(max_length=200, blank=True, null=True)

    from_state = models.ForeignKey(State, related_name='procurement_tax_invoice_state', on_delete=models.CASCADE, blank=True, null=True)
    buyer = models.ForeignKey(VendorMasterV2, related_name='procurement_tax_invoice_buyer', on_delete=models.CASCADE, blank=True, null=True)
    # buyer_state = models.ForeignKey(State, related_name='procurement_tax_invoice_buyer_state', on_delete=models.CASCADE, blank=True, null=True)
    buyer_state = models.CharField(max_length=200, blank=True, null=True)

    gst_calculation_on = models.CharField(max_length=100, choices=GST_ON, blank=True, null=True, default="bill_to")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(max_length=500, null=True, blank=True)
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)

    discount_percentage = models.FloatField(blank=True, null=True, default=0.)
    discount_amount = models.FloatField(blank=True, null=True, default=0.)
    other_charges = models.FloatField(blank=True, null=True, default=0.)
    round_off = models.FloatField(blank=True, null=True, default=0.)
    total_bill_value = models.FloatField(blank=True, null=True, default=0.)


    # m2m
    site = models.ManyToManyField(SiteMaster, related_name='procurement_tax_invoice_site', null=True, blank=True)
    store = models.ManyToManyField(StoreMaster, related_name='procurement_tax_invoice_store', null=True, blank=True)

    grn = models.ForeignKey(GRN, related_name='procurement_tax_invoice_grn', on_delete=models.CASCADE, null=True,
                            blank=True)
    material_issue = models.ForeignKey(MaterialIssue, related_name='procurement_tax_invoice_material_issue', on_delete=models.CASCADE, null=True,
                            blank=True)

    ########
    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_tax_invoice_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_tax_invoice_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_tax_invoice_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_tax_invoice_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_tax_invoice_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_tax_invoice"
        verbose_name_plural = "Tax Invoices"


class TaxInvoiceItems(BaseAbstractStructure):
    master = models.ForeignKey(TaxInvoice, related_name='procurement_tax_invoice_items_master',
                                    on_delete=models.CASCADE, null=True, blank=True)
    # fk
    organization = models.ForeignKey(Organization, related_name='procurement_tax_invoice_items_organizations',
                                     on_delete=models.CASCADE)
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_tax_invoice_items_material',
                                 on_delete=models.CASCADE, null=True, blank=True)

    min_no = models.CharField(max_length=200, blank=True, null=True)  # material in word
    min_date = models.DateField(blank=True, null=True)  # material in word date
    rst_no = models.CharField(max_length=200, blank=True, null=True)
    # receive_location = models.CharField(max_length=200, blank=True, null=True)
    from_to_chainage_remarks = models.CharField(max_length=200, blank=True, null=True)

    received_qty = models.FloatField(blank=True, null=True, default=0.)
    received_qty_unit = models.ForeignKey(UnitOfMesurement,
                                            related_name="procurement_tax_invoice_items_received_qty_unit",
                                            on_delete=models.CASCADE, blank=True, null=True,)

    amount = models.FloatField(blank=True, null=True, default=0.)

    royalty_description = models.TextField(max_length=300, blank=True, null=True)

    freight_amount = models.FloatField(default=0.)


    other_charges = models.CharField(max_length=20, null=True, blank=True)

    rate_to_fill = models.FloatField(blank=True, null=True, default=0.)
    freight_rate_to_fill = models.FloatField(blank=True, null=True, default=0.)
    dispatched_qty = models.FloatField(blank=True, null=True, default=0.)
    dispatched_qty_unit = models.ForeignKey(UnitOfMesurement,
                                            related_name="procurement_tax_invoice_items_dispatched_qty_unit",
                                            on_delete=models.CASCADE, blank=True, null=True, )
    chainage_from = models.CharField(blank=True, null=True, max_length=200)
    chainage_to = models.CharField(blank=True, null=True, max_length=200)

    trip = models.FloatField(blank=True, null=True, default=0.)
    weight = models.FloatField(blank=True, null=True, default=0.)
    weight_unit = models.ForeignKey(UnitOfMesurement, related_name="procurement_tax_invoice_items_rate_weight_uom",
                                    on_delete=models.CASCADE, blank=True, null=True)
    distance_in_km = models.FloatField(blank=True, null=True, default=0.)

    from_location = models.ForeignKey(StoreMaster,related_name="procurement_tax_invoice_items_from_location",on_delete=models.CASCADE, blank=True, null=True, )
    to_location = models.ForeignKey(StoreMaster,related_name="procurement_tax_invoice_items_to_location",on_delete=models.CASCADE, blank=True, null=True, )
    receive_location = models.ForeignKey(StoreMaster,related_name="procurement_tax_invoice_items_receive_location",on_delete=models.CASCADE, blank=True, null=True, )


    ##############
    size_part_no_grade = models.CharField(max_length=200, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_tax_invoice_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    tolerance_percentage = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_tax_invoice_items_excise_tax_head',
                                        on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_tax_invoice_items_tax_head',
                                 on_delete=models.CASCADE, null=True, blank=True)


    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)

    # def save(self, *args, **kwargs):
    #     self.full_clean()
    #     if not self.quantity:
    #         self.quantity = 0
    #     if not self.rate:
    #         self.rate = 0
    #     if not self.disc_percentage:
    #         self.disc_percentage = 0
    #     if not self.excise_tax_percentage:
    #         self.excise_tax_percentage = 0
    #     if not self.tax_percentage:
    #         self.tax_percentage = 0
    #     if not self.sgst_percentage:
    #         self.sgst_percentage = 0
    #     if not self.cgst_percentage:
    #         self.cgst_percentage = 0
    #     if not self.igst_percentage:
    #         self.igst_percentage = 0
    #     if not self.utgst_percentage:
    #         self.utgst_percentage = 0
    #     if not self.cess_percentage:
    #         self.cess_percentage = 0
    #     self.item_amount = float(self.quantity)*float(self.rate)
    #     if self.disc_percentage != 0:
    #         self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
    #     else:
    #         if not self.disc_amount:
    #             self.disc_amount = 0
    #     self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
    #     if self.excise_tax_percentage != 0:
    #         self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
    #     else:
    #         if not self.excise_tax_amount:
    #             self.excise_tax_amount = 0
    #     if self.tax_percentage != 0:
    #         self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
    #     else:
    #         if not self.tax_amount:
    #             self.tax_amount = 0
    #     self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
    #     self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
    #     self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
    #     self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
    #     self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
    #     self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
    #     super().save(*args, **kwargs)


    class Meta:
        db_table = "procurement_tax_invoice_items"
        verbose_name_plural = "Tax Invoice Items"


class TaxInvoiceItemRate(BaseAbstractStructure):
    master = models.ForeignKey(TaxInvoice, related_name='procurement_tax_invoice_item_rate_master',
                               on_delete=models.CASCADE, null=True, blank=True)
    # fk
    organization = models.ForeignKey(Organization, related_name='procurement_tax_invoice_item_rate_organizations',
                                     on_delete=models.CASCADE)
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_tax_invoice_item_rate_material',
                                 on_delete=models.CASCADE, null=True, blank=True)

    rate_to_fill = models.FloatField(blank=True, null=True, default=0.)
    dispatched_qty = models.FloatField(blank=True, null=True, default=0.)
    dispatched_qty_unit = models.ForeignKey(UnitOfMesurement, related_name="procurement_tax_invoice_item_rate_uom", on_delete=models.CASCADE, blank=True, null=True)
    from_to_chainage =  models.CharField(blank=True, null=True, max_length=200)

    trip = models.FloatField(blank=True, null=True, default=0.)
    weight = models.FloatField(blank=True, null=True, default=0.)
    weight_unit = models.ForeignKey(UnitOfMesurement, related_name="procurement_tax_invoice_item_rate_weight_uom",
                                    on_delete=models.CASCADE, blank=True, null=True)
    distance_in_km = models.FloatField(blank=True, null=True, default=0.)

    class Meta:
        db_table = "procurement_tax_invoice_item_rate"
        verbose_name_plural = "Tax Invoice Item Rate"


class TaxInvoiceFreightRate(BaseAbstractStructure):
    master = models.ForeignKey(TaxInvoice, related_name='procurement_tax_invoice_freight_rate_master',
                               on_delete=models.CASCADE, null=True, blank=True)
    # fk
    organization = models.ForeignKey(Organization, related_name='procurement_tax_invoice_freight_rate_organizations',
                                     on_delete=models.CASCADE)
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_tax_invoice_freight_rate_material',
                                 on_delete=models.CASCADE, null=True, blank=True)

    rate_to_fill = models.FloatField(blank=True, null=True, default=0.)
    dispatched_qty = models.FloatField(blank=True, null=True, default=0.)
    dispatched_qty_unit = models.ForeignKey(UnitOfMesurement, related_name="procurement_tax_invoice_freight_rate_uom",
                                            on_delete=models.CASCADE, blank=True, null=True)
    from_to_chainage = models.CharField(blank=True, null=True, max_length=200)

    trip = models.FloatField(blank=True, null=True, default=0.)
    weight = models.FloatField(blank=True, null=True, default=0.)
    weight_unit = models.ForeignKey(UnitOfMesurement, related_name="procurement_tax_invoice_freight_rate_weight_uom",
                                            on_delete=models.CASCADE, blank=True, null=True)
    distance_in_km = models.FloatField(blank=True, null=True, default=0.)

    class Meta:
        db_table = "procurement_tax_invoice_freight_rate"
        verbose_name_plural = "Tax Invoice Freight Rate"


class TaxInvoiceExpenseDetails(BaseAbstractStructure):
    """
    Tax Invoice Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_tax_invoice_expense_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(TaxInvoice,
                                       related_name='procurement_tax_invoice_expense',
                                       on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_head = models.ForeignKey(ExpenseHead,
                                     related_name='procurement_tax_invoice_expense_expense_head',
                                     on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_tax_invoice_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage_expense = models.FloatField(default=0)
    cgst_percentage_expense = models.FloatField(default=0)
    igst_percentage_expense = models.FloatField(default=0)
    utgst_percentage_expense = models.FloatField(default=0)
    cess_percentage_expense = models.FloatField(default=0)
    sgst_amount_expense = models.FloatField(default=0)
    cgst_amount_expense = models.FloatField(default=0)
    igst_amount_expense = models.FloatField(default=0)
    utgst_amount_expense = models.FloatField(default=0)
    cess_amount_expense = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    # def save(self, *args, **kwargs):
    #     self.full_clean()
    #     if not self.expense_percentage:
    #         self.expense_percentage = 0
    #     if not self.sgst_percentage_expense:
    #         self.sgst_percentage_expense = 0
    #     if not self.cgst_percentage_expense:
    #         self.cgst_percentage_expense = 0
    #     if not self.igst_percentage_expense:
    #         self.igst_percentage_expense = 0
    #     if not self.utgst_percentage_expense:
    #         self.utgst_percentage_expense = 0
    #     if not self.cess_percentage_expense:
    #         self.cess_percentage = 0
    #     value = 0
    #     if self.expense_on_parent:
    #         value = getattr(self.master, self.expense_on_parent)
    #     elif self.expense_on_self:
    #         temp = self.master.procurement_tax_invoice_expense.filter(is_deleted=False, name=self.expense_on_self)
    #         if temp:
    #             value = temp[0].total_expense_amount
    #     else:
    #         value = self.master.total_amount
    #     if self.expense_percentage != 0:
    #         self.expense_amount = float(value)*float(self.expense_percentage)/100
    #     else:
    #         if not self.expense_amount:
    #             self.expense_amount = 0
    #     self.sgst_amount_expense = float(self.expense_amount)*float(self.sgst_percentage_expense)/100
    #     self.cgst_amount_expense = float(self.expense_amount)*float(self.cgst_percentage_expense)/100
    #     self.igst_amount_expense = float(self.expense_amount)*float(self.igst_percentage_expense)/100
    #     self.utgst_amount_expense = float(self.expense_amount)*float(self.utgst_percentage_expense)/100
    #     self.cess_amount_expense = float(self.expense_amount)*float(self.cess_percentage_expense)/100
    #     self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount_expense)+float(self.cgst_amount_expense)+float(self.igst_amount_expense)+float(self.utgst_amount_expense)+float(self.cess_amount_expense)
    #     super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_tax_invoice_expense"


class TaxInvoiceTaxDetails(BaseAbstractStructure):
    """
        TaxInvoice TaxDetails
    """
    TCS_TYPE = (
        ('on_item', 'ON ITEM'),
        ('after_gst', 'AFTER GST'),
        ('after_expense', 'AFTER EXPENSE'),
    )

    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),

        ('on_item', 'ON ITEM'),
        ('after_gst', 'AFTER GST'),
        ('after_expense', 'AFTER EXPENSE'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_tax_invoice_tax_details_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(TaxInvoice,
                                       related_name='procurement_tax_invoice_tax_details',
                                       on_delete=models.CASCADE, null=True, blank=True)
    # item = models.ForeignKey(TaxInvoiceItems, related_name='procurement_tax_invoice_tax_details_item',
    #                          on_delete=models.CASCADE, null=True, blank=True)

    charge_type = models.CharField(max_length=200, blank=True, null=True)
    sgst_rate = models.FloatField(blank=True, null=True, default=0.)
    cgst_rate = models.FloatField(blank=True, null=True, default=0.)
    igst_rate = models.FloatField(blank=True, null=True, default=0.)
    total_amt = models.FloatField(blank=True, null=True, default=0.)
    tcs = models.CharField(max_length=200, blank=True, null=True, choices=TCS_TYPE)
    description = models.TextField(max_length=300, null=True, blank=True)

    ##new
    discount_percentage = models.FloatField(blank=True, null=True, default=0.)
    discount_amount = models.FloatField(blank=True, null=True, default=0.)
    other_charges = models.FloatField(blank=True, null=True, default=0.)
    round_off = models.FloatField(blank=True, null=True, default=0.)
    total_bill_value = models.FloatField(blank=True, null=True, default=0.)

    ######### as par 'po tax details'
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead,
                                 related_name='procurement_tax_invoice_tax_details_tax_head',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0, null=True, blank=True)
    tax_amount = models.FloatField(default=0, null=True, blank=True)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)

    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    # def save(self, *args, **kwargs):
    #     self.full_clean()
    #     if not self.tax_percentage:
    #         self.tax_percentage = 0
    #     if not self.sgst_percentage:
    #         self.sgst_percentage = 0
    #     if not self.cgst_percentage:
    #         self.cgst_percentage = 0
    #     if not self.igst_percentage:
    #         self.igst_percentage = 0
    #     if not self.utgst_percentage:
    #         self.utgst_percentage = 0
    #     if not self.cess_percentage:
    #         self.cess_percentage = 0
    #     value = 0
    #     if self.tax_on_parent:
    #         value = getattr(self.master, self.tax_on_parent)
    #     elif self.tax_on_self:
    #         temp = self.master.procurement_tax_invoice_tax_details.filter(is_deleted=False, name=self.tax_on_self)
    #         if temp:
    #             value = temp[0].total_tax_amount
    #     else:
    #         value = self.master.total_amount
    #     if self.tax_percentage != 0:
    #         self.tax_amount = float(value) * float(self.tax_percentage) / 100
    #     else:
    #         if not self.tax_amount:
    #             self.tax_amount = 0
    #     self.sgst_amount = float(self.tax_amount) * float(self.sgst_percentage) / 100
    #     self.cgst_amount = float(self.tax_amount) * float(self.cgst_percentage) / 100
    #     self.igst_amount = float(self.tax_amount) * float(self.igst_percentage) / 100
    #     self.utgst_amount = float(self.tax_amount) * float(self.utgst_percentage) / 100
    #     self.cess_amount = float(self.tax_amount) * float(self.cess_percentage) / 100
    #     self.total_tax_amount = float(self.tax_amount) + float(self.sgst_amount) + float(self.cgst_amount) + float(
    #         self.igst_amount) + float(self.utgst_amount) + float(self.cess_amount)
    #     super().save(*args, **kwargs)

    #########

    def __str__(self):
        return f"{self.pk} {'deleted' if self.is_deleted else 'not deleted'}"
    class Meta:
        db_table = "procurement_tax_invoice_tax_details"


class TaxInvoiceAttachments(BaseAbstractStructure):
    """
        TaxInvoice Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_tax_invoice_attachment_organizations',
                                     on_delete=models.CASCADE)
    tax_invoice = models.ForeignKey(TaxInvoice, related_name='procurement_tax_invoice_attachment',
                                    on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/tax_invoice', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return f"{self.pk} - {self.tax_invoice if self.tax_invoice else ''}  {'deleted' if self.is_deleted else 'not deleted'}"

    class Meta:
        db_table = "procurement_tax_invoice_attachments"
        verbose_name_plural = "Tax Invoice Attachments"


class MaterialIssueDebitNote(BaseAbstractStructure):
    """
        MaterialIssueDebitNote
    """

    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_material_issue_debit_note_organization',
                                     on_delete=models.CASCADE)
    voucher_no = models.CharField(blank=True, null=True, default='', max_length=100)
    voucher_date = models.DateField(blank=True, null=True)
    party_bill_no = models.CharField(blank=True, null=True, default='', max_length=100)
    party_bill_date = models.DateField(blank=True, null=True)

    min_date = models.DateField(blank=True, null=True)
    min_no = models.CharField(blank=True, null=True, default='', max_length=100)

    challan_no = models.CharField(blank=True, null=True, default='', max_length=100)
    challan_date = models.DateField(blank=True, null=True)

    vendor = models.ForeignKey(VendorMasterV2, blank=True, null=True, related_name='procurement_material_issue_debit_note_vendor', on_delete=models.CASCADE)
    vendor_state_gst = models.CharField(max_length=200, blank=True, null=True)

    # M2M
    site = models.ManyToManyField(SiteMaster, related_name='procurement_material_issue_debit_note_site', null=True, blank=True)  # issue form location
    store = models.ManyToManyField(StoreMaster, related_name='procurement_material_issue_debit_note_store', null=True, blank=True)

    behalf_of_dr = models.CharField(max_length=100, choices=(('in_word', 'In Word'), ('out_word', 'Out Word')), blank=True, null=True)
    ref_no = models.CharField(max_length=200, blank=True, null=True)
    # ? devision

    site_state = models.ForeignKey(State, related_name='procurement_material_issue_debit_note_site_state', blank=True, null=True, on_delete=models.CASCADE)
    # ? dispatched_from

    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(max_length=300, null=True, blank=True)  # particulars remarks
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)

    # calculate on items
    total_item_amount = models.FloatField(blank=True, null=True, default=0.)
    total_item_rate = models.FloatField(blank=True, null=True, default=0.)
    total_item_qty = models.FloatField(blank=True, null=True, default=0.)
    # calculate on tax
    tax_total_tax_amount = models.FloatField(blank=True, null=True, default=0.)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_debit_note_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_debit_note_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_debit_note_closed_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_debit_note_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_issue_debit_note_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    def __str__(self):
        return f"{self.pk} "

    class Meta:
        db_table = "procurement_material_issue_debit_note"
        verbose_name_plural = "Material issue debit notes"


class MaterialIssueDebitNoteItems(BaseAbstractStructure):
    """
    MaterialIssueDebitNoteItems
    """
    ISSUE_TYPE = (
        ('consumption_issue', 'Consumption/Issue'),
        ('transfer', 'Transfer'),
        ('production', 'Production'),
        ('issue_to_party', 'Issue to Party'),
    )
    ISSUE_TRANSFER_FROM = (
        ('party_stock', 'Party Stock'),
        ('self_stock', 'Self Stock'),
    )
    LOADED_VIA = (
        ('party', 'Party'),
        ('self', 'Self'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_material_issue_debit_note_items_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(MaterialIssueDebitNote,
                               related_name='procurement_material_issue_debit_note_items',
                               on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_material_issue_debit_note_items_materials',
                                 on_delete=models.CASCADE, null=True, blank=True)

    materials_issue = models.ForeignKey(MaterialIssue, related_name='procurement_material_issue_debit_note_items_materials_issue', on_delete=models.CASCADE, null=True, blank=True)
    grn = models.ForeignKey(GRN, related_name='procurement_material_issue_debit_note_items_grn', on_delete=models.CASCADE, null=True, blank=True)

    # other model's links #
    material_request_item = models.ForeignKey(MaterialRequestMasterItems,
                                              related_name="procurement_material_issue_debit_note_items_material_request_item", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_material_issue_debit_note_items_indent_item",
                                    on_delete=models.CASCADE, null=True,blank=True)
    quotation_item = models.ForeignKey(QuotationItems,
                                       related_name="procurement_material_issue_debit_note_items_quotation_item",
                                       on_delete=models.CASCADE,
                                       null=True, blank=True)
    purchase_order_item = models.ForeignKey(PurchaseOrderItems,
                                            related_name="procurement_material_issue_debit_note_items_purchase_order_item",
                                            on_delete=models.CASCADE, null=True, blank=True)
    grn_item = models.ForeignKey(GRNItems, related_name="procurement_material_issue_debit_note_items_grn_item",
                                 on_delete=models.CASCADE, null=True,blank=True)
    #####

    amount = models.FloatField(blank=True, null=True, default=0.)
    rate = models.FloatField(blank=True, null=True, default=0.)
    qty = models.FloatField(blank=True, null=True, default=0.)

    issue_type = models.CharField(max_length=100, choices=ISSUE_TYPE, blank=True, null=True)
    amount_type = models.CharField(blank=True, null=True, default='', max_length=100)
    issue_transfer_from = models.CharField(max_length=100, choices=ISSUE_TRANSFER_FROM, blank=True, null=True)
    loaded_via = models.CharField(max_length=100, choices=LOADED_VIA, blank=True, null=True)

    class Meta:
        db_table = "procurement_material_issue_debit_note_items"
        verbose_name_plural = "Material issue debit note items"


class MaterialIssueDebitNoteTax(BaseAbstractStructure):
    """
        MaterialIssueDebitNoteTax
    """
    TCS_TYPE = (
        ('on_item', 'ON ITEM'),
        ('after_gst', 'AFTER GST'),
        ('after_expense', 'AFTER EXPENSE'),
    )

    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),

        ('on_item', 'ON ITEM'),
        ('after_gst', 'AFTER GST'),
        ('after_expense', 'AFTER EXPENSE'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_material_issue_debitnotetax_organization',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(MaterialIssueDebitNote,
                                       related_name='procurement_material_issue_debitnotetax',
                                       on_delete=models.CASCADE, null=True, blank=True)
    # item = models.ForeignKey(TaxInvoiceItems, related_name='procurement_material_issue_debitnotetax_item',
    #                          on_delete=models.CASCADE, null=True, blank=True)

    charge_type = models.CharField(max_length=200, blank=True, null=True)
    sgst_rate = models.FloatField(blank=True, null=True, default=0.)
    cgst_rate = models.FloatField(blank=True, null=True, default=0.)
    igst_rate = models.FloatField(blank=True, null=True, default=0.)
    total_amt = models.FloatField(blank=True, null=True, default=0.)
    tcs = models.CharField(max_length=200, blank=True, null=True, choices=TCS_TYPE)
    description = models.TextField(max_length=300, null=True, blank=True)


    #########
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead,
                                 related_name='procurement_material_issue_debitnotetax_tax_head',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0, null=True, blank=True)
    tax_amount = models.FloatField(default=0, null=True, blank=True)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)

    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    class Meta:
        db_table = "procurement_material_issue_debitnotetax"
        verbose_name_plural = "Material Issue Debit Note Taxes"



class PurchaseReturn(BaseAbstractStructure):
    """
        PurchaseReturn ( main )
    """
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_return_organizations',
                                     on_delete=models.CASCADE)
    # fk
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_purchase_return_financialyear',
                                      on_delete=models.CASCADE, blank=True, null=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_purchase_return_project', on_delete=models.CASCADE, blank=True, null=True)

    grn = models.ForeignKey(GRN, related_name='procurement_purchase_return_grn', on_delete=models.CASCADE, blank=True, null=True)

    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_purchase_return_vendor', on_delete=models.CASCADE, blank=True, null=True)
    vendor_state = models.ForeignKey(State, related_name='procurement_purchase_return_vendor_state', on_delete=models.CASCADE, null=True, blank=True)
    vendor_currency = models.ForeignKey(UnitOfMesurement, related_name='procurement_purchase_return_vendor_currency', on_delete=models.CASCADE, null=True, blank=True)

    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="vat")
    voucher_no = models.CharField(max_length=100, blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    time = models.TimeField(blank=True, null=True)
    remarks = models.TextField(max_length=300, blank=True, null=True)
    jurisdiction = models.TextField(max_length=300, blank=True, null=True)
    t_and_c = models.TextField(max_length=300, blank=True, null=True)
    party_bill_date = models.DateField(blank=True, null=True)
    party_bill_no = models.CharField(max_length=200, null=True, blank=True)
    site_state = models.ForeignKey(State, related_name='procurement_purchase_return_site_state',  blank=True, null=True, on_delete=models.CASCADE)
    exchange_rate = models.FloatField(default=1)

    ###### item total
    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)

    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)

    #####
    # M2M -> FK
    site = models.ForeignKey(SiteMaster, related_name='procurement_purchase_return_site',  blank=True, null=True, on_delete=models.CASCADE)
    store = models.ForeignKey(SiteMaster, related_name='procurement_purchase_return_store', blank=True, null=True, on_delete=models.CASCADE)


    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_return_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_return_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_return_closed_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_return_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_purchase_return_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )


    def __str__(self):
        return f"{self.pk} {'deleted' if self.is_deleted else 'not deleted'}"

    class Meta:
        db_table = "procurement_purchase_return"


class PurchaseReturnItems(BaseAbstractStructure):
    """
        PurchaseReturn items
    """
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_return_items_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(PurchaseReturn,
                               related_name='procurement_purchase_return_items',
                               on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster,related_name='procurement_purchase_return_items_materials',
                               on_delete=models.CASCADE, null=True, blank=True)

    # qty = models.FloatField(blank=True, null=True, default=0.)
    # unit_rate = models.FloatField(blank=True, null=True, default=0.)

    hsn_code = models.CharField(max_length=200, blank=True, null=True)
    loc_balance_qty = models.FloatField(blank=True, null=True, default=0.)
    party_bill_date = models.DateField(blank=True, null=True)
    stock_qty = models.FloatField(blank=True, null=True, default=0.)
    # amount = models.FloatField(blank=True, null=True, default=0.)
    # discount_rate_amt = models.FloatField(blank=True, null=True, default=0.)
    # taxable_amt = models.FloatField(blank=True, null=True, default=0.)

    weight = models.FloatField(blank=True, null=True, default=0.)
    weight_uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_purchase_return_items_uom_id',
                                   on_delete=models.CASCADE, null=True, blank=True)

    ############## as per po item:
    size_part_no_grade = models.CharField(max_length=200, null=True, blank=True)
    quantity = models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_purchase_return_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    tolerance_percentage = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_return_items_excise_tax_head',
                                        on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_return_items_tax_head',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    # notes = models.TextField(max_length=500, null=True, blank=True)
    amount_description = models.TextField(max_length=200, null=True, blank=True)


    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    #############
    class Meta:
        db_table = "procurement_purchase_return_items"


class PurchaseReturnItemsNotes(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='procurement_purchase_return_item_notes_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(PurchaseReturnItems, related_name='procurement_purchase_return_item_notes',
                                      on_delete=models.CASCADE, null=True, blank=True)
    note_title = models.CharField(max_length=100, blank=True, null=True)
    note_details = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = "procurement_purchase_return_item_notes"


class PurchaseReturnTaxDetails(BaseAbstractStructure):
    """
        PurchaseReturn TaxDetails
    """
    TCS_TYPE = (
        ('on_item', 'ON ITEM'),
        ('after_gst', 'AFTER GST'),
        ('after_expense', 'AFTER EXPENSE'),
    )

    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),

        ('on_item', 'ON ITEM'),
        ('after_gst', 'AFTER GST'),
        ('after_expense', 'AFTER EXPENSE'),
    )

    organization = models.ForeignKey(Organization, related_name='procurement_purchase_return_tax_details_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(PurchaseReturn,
                                       related_name='procurement_purchase_return_tax_details',
                                       on_delete=models.CASCADE, null=True, blank=True)
    item = models.ForeignKey(PurchaseReturnItems, related_name='procurement_purchase_return_tax_details_item',
                             on_delete=models.CASCADE, null=True, blank=True)

    charge_type = models.CharField(max_length=200, blank=True, null=True)
    sgst_rate = models.FloatField(blank=True, null=True, default=0.)
    cgst_rate = models.FloatField(blank=True, null=True, default=0.)
    igst_rate = models.FloatField(blank=True, null=True, default=0.)
    total_amt = models.FloatField(blank=True, null=True, default=0.)
    other_charges = models.CharField(max_length=20, null=True, blank=True)
    tcs = models.CharField(max_length=200, blank=True, null=True, choices=TCS_TYPE)
    description = models.TextField(max_length=300, null=True, blank=True)
    ######### as par 'po tax details'
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead,
                                 related_name='procurement_purchase_return_tax_details_tax_head',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0, null=True, blank=True)
    tax_amount = models.FloatField(default=0, null=True, blank=True)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)

    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = PurchaseReturn.cmobjects.filter(pk=self.master.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.procurement_purchase_return_tax_details.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.procurement_purchase_return_tax_details.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value) * float(self.tax_percentage) / 100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount) * float(self.sgst_percentage) / 100
        self.cgst_amount = float(self.tax_amount) * float(self.cgst_percentage) / 100
        self.igst_amount = float(self.tax_amount) * float(self.igst_percentage) / 100
        self.utgst_amount = float(self.tax_amount) * float(self.utgst_percentage) / 100
        self.cess_amount = float(self.tax_amount) * float(self.cess_percentage) / 100
        self.total_tax_amount = float(self.tax_amount) + float(self.sgst_amount) + float(self.cgst_amount) + float(
            self.igst_amount) + float(self.utgst_amount) + float(self.cess_amount)
        super().save(*args, **kwargs)

    #########

    def __str__(self):
        return f"{self.pk} {'deleted' if self.is_deleted else 'not deleted'}"
    class Meta:
        db_table = "procurement_purchase_return_tax_details"


class PurchaseReturnsExpenseDetails(BaseAbstractStructure):
    """
    PurchaseReturnsExpenseDetails
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_return_expense_organization',on_delete=models.CASCADE)
    master = models.ForeignKey(PurchaseReturn, related_name='procurement_purchase_return_expense', on_delete=models.CASCADE, null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) #field_name
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    expense_head = models.ForeignKey(ExpenseHead, related_name='procurement_purchase_return_expense_expense_head', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='procurement_purchase_return_expense_expense_tax_head', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        master = PurchaseReturn.cmobjects.filter(pk=self.master.pk).first()
        if self.expense_on_parent:
            value = getattr(master, self.expense_on_parent)
        elif self.expense_on_self:
            temp = master.procurement_purchase_return_expense_expense_head.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = master.total_amount
            temp = master.procurement_purchase_return_expense_expense_head.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = master.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_purchase_return_expense"


class PurchaseReturnAttachments(BaseAbstractStructure):
    """
        PurchaseReturn Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_purchase_return_attachments_organizations',
                                     on_delete=models.CASCADE)
    master = models.ForeignKey(PurchaseReturn, related_name='procurement_purchase_return_attachments',
                                    on_delete=models.CASCADE, null=True, blank=True)
    item = models.ForeignKey(PurchaseReturnItems, related_name='procurement_purchase_return_attachments_item',
                                    on_delete=models.CASCADE, null=True, blank=True)

    attachment = models.FileField(upload_to='procurement/tax_invoice', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return f"{self.pk} - {self.master if self.master else ''}  {'deleted' if self.is_deleted else 'not deleted'}"

    class Meta:
        db_table = "procurement_purchase_return_attachments"


class CFrom(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_c_from_organizations',
                                     on_delete=models.CASCADE)
    book_no = models.CharField(max_length=200)
    c_form_number = models.CharField(max_length=200)
    c_form_date = models.DateField()
    cst_tax_rate = models.FloatField()
    is_issued = models.BooleanField(default=False)
    issued_date = models.DateField(null=True, blank=True)
    issued_party = models.ForeignKey(VendorMasterV2, on_delete=models.CASCADE,
                                     related_name='procurement_c_from_issued_party', null=True, blank=True)
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, related_name='procurement_c_from_site', null=True,
                             blank=True)
    period_from = models.DateField()
    period_to = models.DateField()
    is_manual_details = models.BooleanField(default=False)
    c_form_amount = models.FloatField()
    issued_details = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.pk} {self.book_no} {self.c_form_number}"

    class Meta:
        db_table = "procurement_c_from"


class CFromAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_c_from_attachment_organizations',
                                     on_delete=models.CASCADE)
    c_from = models.ForeignKey(CFrom, related_name='procurement_c_from_attachments', on_delete=models.CASCADE,
                               null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/c_from', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_c_from_attachments"


class CommunicationType(BaseAbstractStructure):
    
    organization = models.ForeignKey(Organization, related_name='procurement_communication_type_organization', on_delete=models.CASCADE,null=True, blank=True)
    name = models.CharField(max_length=200,null=True, blank=True)
    parent = models.ForeignKey('self', related_name='procurement_communication_type_parent', on_delete=models.CASCADE, blank=True, null=True)
    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = "procurement_communication_type"


class CommunicationMaster(BaseAbstractStructure):
    """
    Communication Master Model
    """
 
    organization = models.ForeignKey(
        Organization,
        related_name='organizations_communication_master',
        on_delete=models.CASCADE
    )
    name = models.CharField(max_length=300, null=True, blank=True)

    class Meta:
        db_table = "procurement_communication_master"


class Communication(BaseAbstractStructure):
    CHOICES = (
        ('Incoming', 'Incoming'),
        ('Outgoing', 'Outgoing'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_communication_organization', on_delete=models.CASCADE,null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_communication_project', on_delete=models.CASCADE,null=True, blank=True)
    tender = models.ForeignKey(TenderMasterNew, related_name='procurement_communication_tender', on_delete=models.CASCADE, null=True, blank=True)
    communication_type=models.ForeignKey(CommunicationType, related_name='procurement_communication_communication_type', on_delete=models.CASCADE,null=True, blank=True)
    name = models.CharField(max_length=200,null=True, blank=True)
    from_name = models.CharField(max_length=200,null=True, blank=True)
    to_name =models.CharField(max_length=200,null=True, blank=True)
    from_master=models.ForeignKey(CommunicationMaster, related_name='procurement_communication_from_master', on_delete=models.CASCADE,null=True, blank=True)
    to_master=models.ForeignKey(CommunicationMaster, related_name='procurement_communication_to_master', on_delete=models.CASCADE,null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    name_of_document =models.CharField(max_length=200,null=True, blank=True)
    file_name=models.CharField(max_length=200,null=True, blank=True)
    attachment = models.FileField(
        upload_to='procurement/communication', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    option = models.CharField(max_length=200,choices=CHOICES, null=True, blank=True)
    is_archived = models.BooleanField(default=False)
    is_replied = models.BooleanField(default=False)
    replied_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return str(self.name_of_document)

    class Meta:
        db_table = "procurement_communication"
    
class VendorDatabase(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_vendor_database_organization', on_delete=models.CASCADE,null=True, blank=True)
    material_type = models.CharField(max_length=200,null=True, blank=True)
    material_name = models.CharField(max_length=200,null=True, blank=True)
    vendor_name = models.CharField(max_length=200,null=True, blank=True)
    contact_person = models.CharField(max_length=200,null=True, blank=True)
    contact_no = models.CharField(max_length=200,null=True, blank=True)
    email_id = models.CharField(max_length=200,null=True, blank=True)
    address = models.CharField(max_length=200,null=True, blank=True)
    location = models.CharField(max_length=200,null=True, blank=True)
    state = models.CharField(max_length=200,null=True, blank=True)
    gst_no = models.CharField(max_length=200,null=True, blank=True)
    pan_no = models.CharField(max_length=200,null=True, blank=True)
    worked_with_sinpl=models.CharField(max_length=50,null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_vendor_database_vendor', on_delete=models.CASCADE, null=True, blank=True)
    type_of_vendor = models.CharField(max_length=200,null=True, blank=True)
    supply_brand = models.CharField(max_length=200,null=True, blank=True)
    work_location = models.CharField(max_length=200,null=True, blank=True)
    vendor_code = models.CharField(max_length=200,null=True, blank=True)
    class Meta:
        db_table = "procurement_vendor_database"



class StockTransferred(BaseAbstractStructure):
    """
    Stock Transferred Model
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    TYPE = (
        ('in', 'IN'),
        ('out', 'OUT'),
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    TARGET_TYPE = (
        ('warehouse', 'Warehouse'),
        ('store', 'Store'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_stock_transferred_organizations',
                                     on_delete=models.CASCADE)
    
    site = models.ForeignKey(SiteMaster,related_name='procurement_stock_transferred_site',on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_stock_transferred_store',on_delete=models.CASCADE,null=True, blank=True)

    project = models.ForeignKey(ProjectMaster, related_name='procurement_stock_transferred_project',
                                on_delete=models.CASCADE,null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
    type = models.CharField(max_length=100, choices=TYPE, blank=True, null=True, default="in")
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")

    remarks = models.TextField(max_length=500, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_stock_transferred_financial_year',
                                      on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_closed_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    target_site = models.ForeignKey(SiteMaster,related_name='procurement_stock_transferred_target_site',on_delete=models.CASCADE, null=True, blank=True)
    target_store = models.ForeignKey(StoreMaster, related_name='procurement_stock_transferred_target_store',on_delete=models.CASCADE,null=True, blank=True)

    target_project = models.ForeignKey(ProjectMaster, related_name='procurement_stock_transferred_target_project',
                                on_delete=models.CASCADE,null=True, blank=True)
    target_type = models.CharField(max_length=100, choices=TARGET_TYPE, blank=True, null=True, default="warehouse")


    class Meta:
        db_table = "procurement_stock_transferred"

class StockTransferredItems(BaseAbstractStructure):
    """
    StockTransferredItems
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_stock_transferred_items_organizations',
                                     on_delete=models.CASCADE)
    
    stock_transferred = models.ForeignKey(StockTransferred,related_name='procurement_stock_transferred_items_stock_transferred',on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster,related_name='procurement_stock_transferred_items_materials',
                               on_delete=models.CASCADE, null=True, blank=True)

    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='procurement_stock_transferred_items_plant_machinery_machine',
                                on_delete=models.CASCADE,null=True, blank=True)
    
    quantity=models.FloatField(default=0)
    sanctioned_quantity=models.FloatField(default=0)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_stock_transferred_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_items_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_items_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_items_closed_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_items_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_stock_transferred_items_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    

    class Meta:
        db_table = "procurement_stock_transferred_items"



class MaterialDispatch(BaseAbstractStructure):
    """
    MaterialDispatch Model
    """
    STATUS = (
        ('dispatched', 'dispatched'),
        ('intransit', 'Intransit'),
        ('received', 'Received'),
       
    )
    STOCK_TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_material_dispatch_organizations',
                                     on_delete=models.CASCADE)
    
    # Source fields
    source_site = models.ForeignKey(
        SiteMaster,
        related_name='procurement_material_dispatch_source_site',
        on_delete=models.CASCADE, 
        null=True, 
        blank=True
    )
    source_store = models.ForeignKey(
        StoreMaster, 
        related_name='procurement_material_dispatch_source_store',
        on_delete=models.CASCADE,
        null=True, 
        blank=True
    )
    source_project = models.ForeignKey(
        ProjectMaster,
        related_name='procurement_material_dispatch_source_project',
        on_delete=models.CASCADE,
        null=True, 
        blank=True
    )

    # Destination fields
    destination_site = models.ForeignKey(
        SiteMaster,
        related_name='procurement_material_dispatch_destination_site',
        on_delete=models.CASCADE, 
        null=True, 
        blank=True
    )
    destination_store = models.ForeignKey(
        StoreMaster, 
        related_name='procurement_material_dispatch_destination_store',
        on_delete=models.CASCADE,
        null=True, 
        blank=True
    )
    destination_project = models.ForeignKey(
        ProjectMaster,
        related_name='procurement_material_dispatch_destination_project',
        on_delete=models.CASCADE,
        null=True, 
        blank=True
    )
    stock_type = models.CharField(max_length=100, choices=STOCK_TYPE, blank=True, null=True, default="material")
    date = models.DateField(null=True, blank=True)
    medium = models.CharField(max_length=100,  blank=True, null=True,)
    vendor_and_courier = models.CharField(max_length=200,  blank=True, null=True,)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    status = models.CharField(max_length=100, choices=STATUS, blank=True, null=True, default="dispatched")
    intransit_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_dispatch_intransit_by", on_delete=models.CASCADE)
    received_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_dispatch_received_by", on_delete=models.CASCADE)
   
    class Meta:
        db_table = "procurement_material_dispatch"

class MaterialDispatchItems(BaseAbstractStructure):
    """
    MaterialDispatchItems
    """
    STATUS = (
        ('dispatched', 'dispatched'),
        ('intransit', 'Intransit'),
        ('received', 'Received'),
       
    )
    organization = models.ForeignKey(Organization, related_name='procurement_material_dispatch_items_organizations',
                                     on_delete=models.CASCADE)
    
    material_dispatch = models.ForeignKey(MaterialDispatch,related_name='procurement_material_dispatch_items_material_dispatch',on_delete=models.CASCADE, null=True, blank=True)
    material = models.ForeignKey(VendorMaterialMaster,related_name='procurement_material_dispatch_materials',
                               on_delete=models.CASCADE, null=True, blank=True)

    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='procurement_material_dispatch_items_plant_machinery_machine',
                                on_delete=models.CASCADE,null=True, blank=True)
    
    quantity=models.FloatField(default=0)
    intransit_quantity=models.FloatField(default=0)
    received_quantity=models.FloatField(default=0)

    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_material_dispatch_items_uom', on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=100, choices=STATUS, blank=True, null=True,)
 
   

    class Meta:
        db_table = "procurement_material_dispatch_items"


class BalancePORemarks(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_balance_po_remarks_organizations', on_delete=models.CASCADE)
    material_request_item = models.ForeignKey(MaterialRequestMasterItems, related_name="procurement_balance_po_remarks_material_request_item", on_delete=models.CASCADE, null=True, blank=True)
    indent_item = models.ForeignKey(IndentItems, related_name="procurement_balance_po_remarks_indent_item", on_delete=models.CASCADE, null=True, blank=True)
    rfq_vendor_item = models.ForeignKey(RFQVendorsItems, related_name="procurement_balance_po_remarks_rfq_vendor_item", on_delete=models.CASCADE, null=True, blank=True)
    enquiry_at_once_item = models.ForeignKey(EnquiryAtOnceItems, related_name="procurement_balance_po_remarks_enquiry_at_once_item", on_delete=models.CASCADE, null=True, blank=True)
    cst_item= models.ForeignKey(CSTItems, related_name='procurement_balance_po_remarks_cst_item', on_delete=models.CASCADE, null=True, blank=True)
    purchase_order_item = models.ForeignKey(PurchaseOrderItems, related_name="procurement_balance_po_remarks_purchase_order_item", on_delete=models.CASCADE, null=True, blank=True)
    balance_po_remarks = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "procurement_balance_po_remarks"

class BOIProcurementTracker(BaseAbstractStructure):
    SUPPLIER_OEM_CHOICES = (
        ('Supplier', 'Supplier'),
        ('OEM', 'OEM'),
    )
    TDS_PREPARATION = (
        ('Yes', 'Yes'),
        ('No', 'No'),
    )
    
    parent = models.ForeignKey('self', related_name='procurement_boi_procurement_tracker_parent', on_delete=models.CASCADE, null=True, blank=True)
    organization = models.ForeignKey(Organization, related_name='boi_procurement_tracker_organizations', on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='boi_procurement_tracker_project', on_delete=models.CASCADE, null=True, blank=True)
    # boq = models.ForeignKey(BOQ, related_name='procurement_boi_procurement_tracker_boq',on_delete=models.CASCADE, null=True, blank=True)
    wbs = models.ManyToManyField(WBSList, related_name='boi_procurement_tracker_wbs',null=True, blank=True)  
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='boi_procurement_tracker_requested_material', on_delete=models.CASCADE, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='boi_procurement_tracker_uom', on_delete=models.CASCADE, null=True, blank=True)
    # supplier_oem = models.CharField(max_length=200, blank=True, null=True, choices=SUPPLIER_OEM_CHOICES)
    req_qty = models.FloatField(default=0)
    recd_qty = models.FloatField(default=0)
    balance_qty = models.FloatField(default=0)
    supplier_oem = models.CharField(max_length=100, blank=True, null=True)
    lead_time_mr_to_po_planned = models.FloatField(default=0)
    lead_time_mr_to_po_remarks = models.TextField(blank=True, null=True)
    lead_time_po_to_delivery_planned = models.FloatField(default=0)
    lead_time_po_to_delivery_remarks = models.TextField(blank=True, null=True)
    approved_mr_date_planned = models.DateField(null=True, blank=True)
    approved_mr_date_remarks = models.TextField(blank=True, null=True)
    tds_preparation = models.CharField(max_length=200, blank=True, null=True, choices=TDS_PREPARATION, default='No')
    tds_approval = models.DateField(null=True, blank=True)
    pcs_preparation = models.CharField(max_length=200, blank=True, null=True, choices=TDS_PREPARATION, default='No')
    pcs_approval_from_management = models.DateField(null=True, blank=True)
    issuance_of_powo_planned = models.DateField(null=True, blank=True)
    issuance_of_powo_remarks = models.TextField(blank=True, null=True)
    supplier_name = models.CharField(max_length=100, blank=True, null=True)
    delivery_period_day = models.FloatField(default=0)
    receipt_of_shop_drawing_planned = models.DateField(null=True, blank=True)
    receipt_of_shop_drawing_forecast_actual = models.DateField(null=True, blank=True)
    receipt_of_shop_drawing_remarks = models.TextField(blank=True, null=True)
    approval_of_shop_drawing_planned = models.DateField(null=True, blank=True)
    approval_of_shop_drawing_forecast_actual = models.DateField(null=True, blank=True)
    approval_of_shop_drawing_remarks = models.TextField(blank=True, null=True)
    manufacturingclearance_planned = models.DateField(null=True, blank=True)
    manufacturingclearance_forecast_actual = models.DateField(null=True, blank=True)
    manufacturingclearance_remarks = models.TextField(blank=True, null=True)
    inspection_date_planned = models.DateField(null=True, blank=True)
    inspection_date_forecast_actual = models.DateField(null=True, blank=True)
    inspection_date_remarks = models.TextField(blank=True, null=True)
    dispatch_clearance_planned = models.DateField(null=True, blank=True)
    dispatch_clearance_forecast_actual = models.DateField(null=True, blank=True)
    dispatch_clearance_remarks = models.TextField(blank=True, null=True)
    delivery_to_site_store_planned = models.DateField(null=True, blank=True)
    delivery_to_site_store_forecast_actual = models.DateField(null=True, blank=True)
    delivery_to_site_store_remarks = models.TextField(blank=True, null=True)
    installation_at_site_planned = models.DateField(null=True, blank=True)
    installation_at_site_forecast_actual = models.DateField(null=True, blank=True)
    installation_at_site_remarks = models.TextField(blank=True, null=True)
    testing_commissioning_trial_run_planned = models.DateField(null=True, blank=True)
    testing_commissioning_trial_run_forecast_actual = models.DateField(null=True, blank=True)
    testing_commissioning_trial_run_remarks = models.TextField(blank=True, null=True)
    hand_over_planned = models.DateField(null=True, blank=True)
    hand_over_forecast_actual = models.DateField(null=True, blank=True)
    hand_over_remarks = models.TextField(blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)

    class Meta:
        db_table = "procurement_boi_procurement_tracker"


class StoreDSRMaster(BaseAbstractStructure):
    """
    DAILY STOCK REPORT Master
    """
    organization = models.ForeignKey(Organization, related_name='procurement_store_dsr_master_organization', on_delete=models.CASCADE)
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_store_dsr_master_requested_material', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_store_dsr_master_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_store_dsr_master_store', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_store_dsr_master_project', on_delete=models.CASCADE, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_store_dsr_master_financialyear', on_delete=models.CASCADE, blank=True, null=True)
    # ordering = models.IntegerField(default=0)
    class Meta:
        db_table = "procurement_store_dsr_master"


class StoreDSRRecords(BaseAbstractStructure):
    """
    DAILY STOCK REPORT RECORDS
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_store_dsr_records_organization', on_delete=models.CASCADE)
    site = models.ForeignKey(SiteMaster, related_name='procurement_store_dsr_records_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_store_dsr_records_store', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_store_dsr_records_project', on_delete=models.CASCADE, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_store_dsr_records_financialyear', on_delete=models.CASCADE, blank=True, null=True)
    date=models.DateField(null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_store_dsr_records_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_store_dsr_records_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_store_dsr_records_closed_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_store_dsr_records_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_store_dsr_records_rejected_by", on_delete=models.CASCADE)

    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        # constraints = [
        #     models.UniqueConstraint(fields=['organization','site','store','project','date'], name='unique_procurement_store_dsr_records')
        # ]
        db_table = "procurement_store_dsr_records"


class StoreDSRRecordsItems(BaseAbstractStructure):
    """
    DAILY STOCK REPORT
    """
    organization = models.ForeignKey(Organization, related_name='procurement_store_dsr_organization', on_delete=models.CASCADE)
    store_dsr_records = models.ForeignKey(StoreDSRRecords, related_name='procurement_store_dsr_store_dsr_records', on_delete=models.CASCADE, null=True, blank=True)
    store_dsr_master = models.ForeignKey(StoreDSRMaster, related_name='procurement_store_dsr_store_dsr_master', on_delete=models.CASCADE, null=True, blank=True)
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_store_dsr_requested_material', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_store_dsr_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_store_dsr_store', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_store_dsr_project', on_delete=models.CASCADE, null=True, blank=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='procurement_store_dsr_financialyear', on_delete=models.CASCADE, blank=True, null=True)
    date=models.DateField(null=True, blank=True)
    opening_quantity = models.FloatField(default=0)
    issued_quantity = models.FloatField(default=0)
    received_quantity = models.FloatField(default=0)
    # balance_quantity = models.FloatField(default=0)
    location = models.TextField(max_length=500, null=True, blank=True)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    
    class Meta:
        db_table = "procurement_store_dsr"


class SAPPR(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_sap_pr_organization', on_delete=models.CASCADE)
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_sap_pr_requested_material', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_sap_pr_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_sap_pr_store', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_sap_pr_project', on_delete=models.CASCADE, null=True, blank=True)

    pr_no = models.CharField(max_length=200, null=True, blank=True)
    pr_item = models.CharField(max_length=200, null=True, blank=True)
    material = models.CharField(max_length=200, null=True, blank=True)
    short_text = models.CharField(max_length=200, null=True, blank=True)
    pr_quantity = models.CharField(max_length=200, null=True, blank=True)
    order_quantity = models.CharField(max_length=200, null=True, blank=True)
    doc_type = models.CharField(max_length=200, null=True, blank=True)
    purchase_group = models.CharField(max_length=200, null=True, blank=True)
    plant = models.CharField(max_length=200, null=True, blank=True)
    storage_location = models.CharField(max_length=200, null=True, blank=True)
    matrial_group = models.CharField(max_length=200, null=True, blank=True)
    uom = models.CharField(max_length=200, null=True, blank=True)
    requisition_date = models.CharField(max_length=200, null=True, blank=True)
    purchase_org = models.CharField(max_length=200, null=True, blank=True)
    account_assignment_category = models.CharField(max_length=200, null=True, blank=True)
    valuation_type = models.CharField(max_length=200, null=True, blank=True)
    wbs_element = models.CharField(max_length=200, null=True, blank=True)
    gl_account = models.CharField(max_length=200, null=True, blank=True)
    controlling_area = models.CharField(max_length=200, null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "procurement_sap_pr"



class ProcurementMaterialProjectGroup(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_material_project_grp_organization', on_delete=models.CASCADE, blank=True, null=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_material_project_grp_project', on_delete=models.CASCADE,null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_material_project_grp_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_material_project_grp_store', on_delete=models.CASCADE, null=True, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    # state
    is_send_for_checked = models.BooleanField(default=False)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_grp_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_grp_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_grp_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_grp_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_grp_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_material_project_grp"
        verbose_name_plural = "6. Procurement Material Projects Group"

class ProcurementMaterialProject(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_material_project_organization', on_delete=models.CASCADE, blank=True, null=True)
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_material_project_requested_material', blank=True, null=True, on_delete=models.CASCADE)

    group = models.ForeignKey(ProcurementMaterialProjectGroup, related_name='procurement_material_project_grp', blank=True, null=True, on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_material_project_project', on_delete=models.CASCADE)
    site = models.ForeignKey(SiteMaster, related_name='procurement_material_project_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_material_project_store', on_delete=models.CASCADE, null=True, blank=True)
    material_code = models.CharField(max_length=100, blank=True, null=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_material_project_uom', blank=True, null=True, on_delete=models.CASCADE)
    uom_text = models.CharField(max_length=100, blank=True, null=True)
    item_desc = models.CharField(max_length=100, blank=True, null=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    qty_left = models.FloatField(null=True, blank=True, default=0.)
    budget_left = models.FloatField(null=True, blank=True, default=0.)
    ordering = models.IntegerField(default=0)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_material_project_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True,)
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    def __str__(self):
        return str(self.id) + ' ' + str(self.material_code)

    class Meta:
        db_table = "procurement_material_project"
        verbose_name_plural = "7. Procurement Material Projects"


class ProcurementMaterialBudgetBreakdown(BaseAbstractStructure):
    master = models.ForeignKey(ProcurementMaterialProject, related_name='procurement_material_budget_breakdown', on_delete=models.CASCADE, null=True, blank=True)
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_material_budget_breakdown_requested_material', blank=True, null=True, on_delete=models.CASCADE)
    material_code=models.CharField(max_length=100, blank=True, null=True)
    requirement_qty = models.FloatField(blank=True, null=True, default=0.)
    wastage = models.FloatField(blank=True, null=True, default=0.)
    qty = models.FloatField(blank=True, null=True, default=0.)
    rate = models.FloatField(blank=True, null=True, default=0.)
    amount = models.FloatField(blank=True, null=True, default=0.)
    entry_date = models.DateField(null=True, blank=True)
    is_zero_budget = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.requirement_qty:
            self.requirement_qty = 0
        if not self.wastage:
            self.wastage = 0
        if not self.qty:
            self.qty = 0
        self.qty = float(self.requirement_qty) * (1+(float(self.wastage/100)))
        self.amount = float(self.rate) * float(self.qty)
        super().save(*args, **kwargs)

    def __str__(self):
        return str(self.id)+" ("+str(self.entry_date)+" | "+str(self.is_zero_budget)+") "+str(self.qty)+" * "+str(self.rate)+" = "+str(self.amount)


    class Meta:
        db_table = "procurement_material_budget_breakdown"
        ordering = ('entry_date', 'id')
        verbose_name_plural = "8. Procurement Material Budget Breakdown"


class ProcurementMaterialConsumptionBreakdown(BaseAbstractStructure):
    master = models.ForeignKey(ProcurementMaterialProject, related_name='procurement_mat_consumption_breakdown', on_delete=models.CASCADE, null=True, blank=True)
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_mat_consumption_breakdown_requested_material', blank=True, null=True, on_delete=models.CASCADE)
    material_code = models.CharField(max_length=100, blank=True, null=True)
    consumed_qty = models.FloatField(default=0.0)
    consumed_rate = models.FloatField(default=0.0)
    consumed_amt = models.FloatField(default=0.0)
    entry_date = models.DateField(null=True, blank=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.consumed_rate:
            self.consumed_rate = 0
        if not self.consumed_qty:
            self.consumed_qty = 0
        self.consumed_amt = float(self.consumed_rate) * float(self.consumed_qty)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "procurement_mat_consumption_breakdown"
        verbose_name_plural = "9. Procurement Material Consumption Breakdowns"
        
class PaymentMaster(BaseAbstractStructure):
    """
    PaymentMaster
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    PAYMENT_AGAINST_CHOICE = (
        ('PO', 'PO'),
        ('Invoice', 'Invoice'),
        ('PI', 'PI'),
    )
    PAYMENT_THROUGH_CHOICE = (
        ('CST', 'CST'),
        ('Non-CST', 'Non-CST'),
    )
    ADVANCE_PAYMENT_CHOICE = (
        ('Yes', 'Yes'),
        ('No', 'No'),
    )
    PAYMENT_STATUS_CHOICE = (
        ('pending', 'pending'),
        ('partial', 'partial'),
        ('processed', 'processed'),
        ('hold', 'hold'),
    )
    GST_CHOICE = (
        ('including_gst', 'including_gst'),
        ('hold_gst', 'hold_gst'),

    )
    organization = models.ForeignKey(Organization, related_name='procurement_payment_master_organizations', on_delete=models.CASCADE)
    site = models.ForeignKey(SiteMaster,related_name='procurement_payment_master_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster,related_name='procurement_payment_master_store', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_payment_master_project', on_delete=models.CASCADE, null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_payment_master_vendor', on_delete=models.CASCADE, null=True, blank=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(null=True, blank=True)
    cancelled_remarks = models.TextField(null=True, blank=True)
    checked_remarks = models.TextField(null=True, blank=True)
    approved_remarks = models.TextField(null=True, blank=True)
    rejected_remarks = models.TextField(null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    amount = models.FloatField(default=0.0)
    purpose = models.TextField(null=True, blank=True)
    payment_against = models.CharField(max_length=100, choices=PAYMENT_AGAINST_CHOICE, blank=True, null=True, default="PO")
    payment_no = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    payment_through = models.CharField(max_length=100, choices=PAYMENT_THROUGH_CHOICE, blank=True, null=True, default="Non-CST")
    cst_no = models.CharField(max_length=200, null=True, blank=True)
    cst = models.ForeignKey(CST, related_name='procurement_payment_master_cst', on_delete=models.CASCADE, null=True, blank=True)
    purchase_order = models.ForeignKey(PurchaseOrder, related_name='procurement_payment_master_purchase_order', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    current_stage = models.IntegerField(default=0)
    latest = models.BooleanField(default=True)
    previous_version = models.ForeignKey('self', related_name='procurement_payment_master_previous_version',
                                on_delete=models.CASCADE, null=True, blank=True)
    version = models.IntegerField(default=1)
    is_advance_payment = models.CharField(max_length=100, choices=ADVANCE_PAYMENT_CHOICE, blank=True, null=True,)
    payment_status_type = models.CharField(max_length=100, choices=PAYMENT_STATUS_CHOICE,default='pending',blank=True, null=True,)
    gst_type = models.CharField(max_length=100, choices=GST_CHOICE,default='including_gst',blank=True, null=True,)
    on_hold = models.BooleanField(default=False)
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='procurement_payment_master_ref_stage_type', blank=True, null=True, on_delete=models.CASCADE)

    class Meta:
        # unique_together = ('organization', 'payment_no', 'site', 'store', 'project', 'vendor')
        db_table = "procurement_payment_master"


class PaymentMasterAttachments(BaseAbstractStructure):
    """
    PaymentMaster Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_payment_master_attachments_organizations',
                                     on_delete=models.CASCADE)
    payment_master = models.ForeignKey(PaymentMaster,
                                  related_name='procurement_payment_master_attachments',
                                  on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/payment_master', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_payment_master_attachments"
class PaymentMasterUTR(BaseAbstractStructure):
    """
    PaymentMasterUTR
    """
    payment_master = models.ForeignKey(PaymentMaster, related_name='procurement_payment_master_utr', on_delete=models.CASCADE, null=True, blank=True)
    utr_no = models.CharField(max_length=200, null=True, blank=True)
    utr_date = models.DateField(null=True, blank=True)
    utr_remarks = models.TextField(null=True, blank=True)
    base_amount = models.FloatField(default=0.0)
    tds_amount = models.FloatField(default=0.0)
    amount = models.FloatField(default=0.0)

    class Meta:
        db_table = "procurement_payment_master_utr"
class PaymentMasterUTRAttachments(BaseAbstractStructure):
    """
    PaymentMasterUTR Attachments
    """
    organization = models.ForeignKey(Organization, related_name='procurement_payment_master_utr_attachments_organizations',
                                     on_delete=models.CASCADE)
    payment_master_utr = models.ForeignKey(PaymentMasterUTR,
                                  related_name='procurement_payment_master_utr_attachments',
                                  on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='procurement/payment_master_utr', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "procurement_payment_master_utr_attachments"
class PaymentMasterStages(BaseAbstractStructure):
    """
    PaymentMasterStages
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('hold', 'Hold'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_payment_master_stages_organizations', on_delete=models.CASCADE)
    payment_master = models.ForeignKey(PaymentMaster, related_name='procurement_payment_master_stages', on_delete=models.CASCADE, null=True, blank=True)
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_stages_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_stages_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_stages_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_stages_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_payment_master_stages_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    is_web = models.BooleanField(default=False)

    class Meta:
        db_table = "procurement_payment_master_stages"



class UnlinkPurchaseOrder(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='procurement_unlink_purchase_order_organizations',
                                     on_delete=models.CASCADE)
    sap_code = models.CharField(max_length=200, null=True, blank=True) 
    release_state = models.CharField(max_length=200, null=True, blank=True)
    release_strategy_from_sap = models.CharField(max_length=200, null=True, blank=True)
    attachment_from_sap = models.CharField(max_length=200, null=True, blank=True)
    acct_assignment_cat = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_unlink_purchase_order_vendor',
                               on_delete=models.CASCADE, null=True, blank=True)
    item = models.ForeignKey(VendorMaterialMaster, related_name='procurement_unlink_purchase_order_item_material',
                             on_delete=models.CASCADE, null=True, blank=True)
    short_text = models.CharField(max_length=255, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='procurement_unlink_purchase_order_uom', on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    stil_to_be_delivered_quantity = models.FloatField(default=0)
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, 
                              related_name='procurement_unlink_purchase_order_store')
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, 
        related_name='procurement_unlink_purchase_order_sites')
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, 
                                related_name='procurement_unlink_purchase_order_project')
    vendor_currency = models.ForeignKey(VendorCurrencyMaster, related_name='procurement_purchase_unlink_order_vendor_currency',
                                        on_delete=models.CASCADE, null=True, blank=True)
    rate = models.FloatField(default=0)
    tax_code_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_unlink_purchase_order_tax_code_for_sap", on_delete=models.CASCADE)
    po_created_by_name = models.CharField(max_length=255, null=True, blank=True)
    item_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    still_to_be_delivered_value = models.FloatField(default=0)
    delivery_date = models.DateField(blank=True, null=True)
    purchase_org_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_unlink_purchase_order_purchase_org_for_sap", on_delete=models.CASCADE)
    created_by_name = models.CharField(max_length=255, null=True, blank=True)
    req_tracking_number =  models.CharField(max_length=255, null=True, blank=True)
    purchase_group_for_sap = models.ForeignKey(SAPMasters, blank=True, null=True, related_name="procurement_unlink_purchase_order_purchase_group_for_sap", on_delete=models.CASCADE)
    stil_to_be_invoiced_quantity = models.FloatField(default=0)
    stil_to_be_invoiced_value = models.FloatField(default=0)
    release_strategy_from_sap = models.CharField(max_length=200, null=True, blank=True)
    item_from_sap = models.FloatField(default=0)
    purchasing_doc_type =  models.CharField(blank=True, null=True,  max_length=250)
    purch_doc_category = models.CharField(blank=True, null=True,  max_length=250)
    amendment_date = models.DateField(blank=True, null=True)
    preview = models.CharField(blank=True, null=True,  max_length=250)
    release_indicator = models.CharField(blank=True, null=True,  max_length=250)
    issuing_storage_loc = models.CharField(blank=True, null=True,  max_length=250)
    incomplete = models.CharField(blank=True, null=True,  max_length=250)
    external_sort_number = models.FloatField(default=0)
    ext_hierarchy_category = models.CharField(blank=True, null=True,  max_length=250)
    control_indicator = models.CharField(blank=True, null=True,  max_length=250)
    configurable_item_number = models.CharField(blank=True, null=True,  max_length=250)
    component_consumption_history = models.CharField(blank=True, null=True,  max_length=250)
    collective_number = models.CharField(blank=True, null=True,  max_length=250)
    characteristic_value_1 = models.CharField(blank=True, null=True,  max_length=250)
    characteristic_value_2 = models.CharField(blank=True, null=True,  max_length=250)
    characteristic_value_3 = models.CharField(blank=True, null=True,  max_length=250)
    characteristic_description_1 = models.TextField(blank=True, null=True)
    characteristic_description_2 = models.TextField(blank=True, null=True)
    characteristic_description_3 = models.TextField(blank=True, null=True)
    valid_date_to = models.DateField(null=True, blank=True)
    valid_date_from = models.DateField(null=True, blank=True)
    total_open_value =  models.FloatField(default=0)
    tax_jurisdiction = models.CharField(blank=True, null=True,  max_length=250)
    target_quantity = models.FloatField(default=0)
    targ_val_hdr =  models.FloatField(default=0)
    stock_keeping_unit = models.ForeignKey(UnitOfMesurement, related_name='procurement_unlink_purchase_order_stock_keeping_unit', on_delete=models.CASCADE, null=True, blank=True)
    stock_segment = models.CharField(blank=True, null=True,  max_length=250)
    smart_number = models.CharField(blank=True, null=True,  max_length=250)
    rfq_status = models.CharField(blank=True, null=True,  max_length=250)
    requirement_urgency = models.FloatField(default=0)  
    requirement_segment = models.CharField(blank=True, null=True,  max_length=250)
    reqmt_priority = models.CharField(blank=True, null=True,  max_length=250)
    released_value = models.FloatField(default=0)
    rd = models.CharField(blank=True, null=True,  max_length=250)
    quotation_deadline = models.DateField(blank=True, null=True)    
    quantity_in_sku = models.FloatField(default=0)
    qty_released_to_date = models.FloatField(default=0)
    purchasing_info_rec = models.CharField(blank=True, null=True,  max_length=250)
    psst_grouping_rule = models.CharField(blank=True, null=True,  max_length=250)
    psst_group = models.CharField(blank=True, null=True,  max_length=250)
    princ_agreement_item = models.FloatField(default=0)
    price_unit = models.FloatField(default=0)
    package_number = models.FloatField(default=0)
    outline_agreement = models.CharField(blank=True, null=True, max_length=250)
    order_price_unit = models.ForeignKey(UnitOfMesurement, related_name='procurement_unlink_purchase_order_order_price_unit', on_delete=models.CASCADE, null=True, blank=True)
    release_group = models.CharField(blank=True, null=True, max_length=250)
    open_value = models.FloatField(default=0)
    open_target_quantity = models.FloatField(default=0)
    notified_quantity = models.FloatField(default=0)
    no_of_positions = models.FloatField(default=0)
    item_category =  models.CharField(blank=True, null=True, max_length=250)
    nc_name = models.CharField(blank=True, null=True, max_length=250)
    nc = models.CharField(blank=True, null=True, max_length=250)
    deletion_indicator = models.CharField(blank=True, null=True, max_length=250)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_unlink_purchase_order_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_unlink_purchase_order_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_unlink_purchase_order_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_unlink_purchase_order_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_unlink_purchase_order_rejected_by", on_delete=models.CASCADE)
    
    class Meta:
        db_table = "procurement_unlink_purchase_order"


class ProcurementBudgetPlanning(BaseAbstractStructure):
    project = models.ForeignKey(ProjectMaster, on_delete=models.CASCADE, null=True, blank=True, 
                                related_name='procurement_budget_planning_project')
    store = models.ForeignKey(StoreMaster, on_delete=models.CASCADE, null=True, blank=True, 
                              related_name='procurement_budget_planning_store')
    site = models.ForeignKey(SiteMaster, on_delete=models.CASCADE, null=True, blank=True, 
        related_name='procurement_budget_planningr_site')
    requested_material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_budget_planning_request_material',
                             on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    wastage = models.FloatField(default=0)
    total_quantity = models.FloatField(default=0)
    tender_rate = models.FloatField(default=0)
    budget_rate = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.wastage:
            self.wastage = 0
        self.total_quantity = float(self.quantity)+(float(self.wastage)/100)
        super().save(*args, **kwargs)
 
    class Meta:
        db_table = "procurement_budget_planning"


class SAPStockMaster(BaseAbstractStructure):
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_sap_stock_material', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_sap_stock_site', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_sap_stock_store', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_sap_stock_project', on_delete=models.CASCADE, null=True, blank=True)
    date = models.DateField(blank=True, null=True)
    closing_stock = models.FloatField(default=0)
    closing_value = models.FloatField(default=0)
    opening_stock = models.FloatField(default=0)
    opening_value = models.FloatField(default=0)
    total_issue_value = models.FloatField(default=0)
    total_issued_qty = models.FloatField(default=0)
    total_receipt_qties = models.FloatField(default=0)
    total_receipt_value = models.FloatField(default=0)
    
    class Meta:
        db_table = "procurement_sap_stock"
        indexes = [
            models.Index(fields=['project','site','store','material','date']),
            models.Index(fields=['site','store','material','date']),
            models.Index(fields=['project','site','store']),
            models.Index(fields=['date']),
        ]


class ProcurementRealTimeMaterialReceive(BaseAbstractStructure):
    purchase_order_item = models.ForeignKey(PurchaseOrderItems, related_name='procurement_real_time_material_receive_purchase_order_item', on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.FloatField(default=0)
    remarks = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "procurement_real_time_material_receive"


class NABLLabDirectory(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_nabl_lab_directory_organizations',
                                     on_delete=models.CASCADE)
    name = models.CharField(max_length=200, null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    contact_person = models.CharField(max_length=200, null=True, blank=True)
    contact_no = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_nabl_lab_directory_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_nabl_lab_directory_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_nabl_lab_directory_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_nabl_lab_directory_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_nabl_lab_directory_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "procurement_nabl_lab_directory"

class ProcurementReturnableMaterial(BaseAbstractStructure):
    ISSUE_TYPE = (
        ('free_issue', 'Free Issue'),
        ('returanable', 'Returanable'),
        ('chargeable', 'Chargeable'),
    )
    ISSUE_TO = (
        ('employee', 'Employee'),
        ('subcontractor', 'Subcontractor'),
    )
    organization = models.ForeignKey(Organization, related_name='procurement_returnable_material_organization',
                                     on_delete=models.CASCADE)
    mode_of_issue = models.CharField(max_length=100, choices=ISSUE_TYPE, blank=True, null=True, default="free_issue")
    material = models.ForeignKey(VendorMaterialMaster, related_name='procurement_returnable_material_material', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey(StoreMaster, related_name='procurement_returnable_material_store', on_delete=models.CASCADE, null=True, blank=True)
    site = models.ForeignKey(SiteMaster, related_name='procurement_returnable_material_site', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='procurement_returnable_material_project', on_delete=models.CASCADE, null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='procurement_returnable_material_vendor', on_delete=models.CASCADE, null=True, blank=True)
    issue_to = models.CharField(max_length=100, choices=ISSUE_TO, blank=True, null=True, default="employee")
    user = models.ForeignKey(PmsUser, blank=True, null=True, related_name="procurement_returnable_material_user", on_delete=models.CASCADE)
    date = models.DateField(blank=True, null=True)
    received_by = models.TextField(null=True, blank=True)
    issued_quantity = models.FloatField(default=0.0)
    purpose_of_issue = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "procurement_returnable_material"

class ProcurementReturnableMaterialReturnQuantityDetails(BaseAbstractStructure):
    returnable_material = models.ForeignKey(ProcurementReturnableMaterial, related_name='returnable_material_master',
                                     on_delete=models.CASCADE)
    date =  models.DateField(blank=True, null=True)
    quantity = models.FloatField(default=0.0)
    material_condition = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "procurement_returnable_material_quantity_details"
