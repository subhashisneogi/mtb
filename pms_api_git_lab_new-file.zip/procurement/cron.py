
# 1
import datetime
import random
from procurement.models import CFrom

# 2
from concurrent.futures import ProcessPoolExecutor
from email_config.models import EmailSend
from email_config.utils import send_notification_mail_to


def my_scheduled_job_test():
    # cron 1
    try:
        CFrom.cmobjects.create(
            organization_id=1,
            book_no=f'book-no-{random.randint(0,99)}',
            c_form_number=f'cron-test-{random.randint(0,99)}',
            c_form_date=datetime.date.today(),
            cst_tax_rate=0.,
            period_from=datetime.date.today(),
            period_to=datetime.date.today(),
            c_form_amount=0.
        )
    except Exception as e:
        print(f"exception: {e}")
    # cron 1 end


def scheduled_job_unsent_mails():
    # cron 2 🍿
    unsent_mails = EmailSend.objects.filter(is_sent=False)
    with ProcessPoolExecutor(max_workers=3) as executor:
        futures = [
            executor.submit(
                send_notification_mail_to,
                to_mail_list=[email_instance.to_email],
                template_name=email_instance.template.template_name,
                processed_message=email_instance.processed_message,
                subject=email_instance.subject
            )
            for email_instance in unsent_mails
        ]

        for future, email_instance in zip(futures, unsent_mails):
            try:
                result = future.result()
                if result:
                    email_instance.is_sent = True
                    email_instance.save()
            except Exception as e:
                print(f"Error: {e}")

        print('Email sending task submitted')
    # cron 2 end 🍿

