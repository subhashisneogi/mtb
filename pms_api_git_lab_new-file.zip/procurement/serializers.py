import base64
import json
import uuid
from django.core.paginator import Page
from datetime import date, timedelta , datetime, time
from decimal import Decimal
from colorama import Back, Style
from django.core.files.base import ContentFile
from django.db import transaction
from django.db.models import F, Sum, Count , ExpressionWrapper, DurationField , DateTimeField , IntegerField , Func , Subquery, OuterRef, FloatField
from django.db.models.functions import Extract ,Coalesce , Cast 
from procurement.helper import GroupConcat
from rest_framework import serializers
from rest_framework.exceptions import APIException, ValidationError
from administrations.serializers import DepartmentSerializer, PmsUserSerializer
from material_master.models import VendorMaterialMaster
from material_master.serializers import MaterialTypeSerializer,VendorMaterialMasterSerializer
from plant_machinery.serializers import PlantMachineryMachineSerializer
from .helper import *
# from .helper import get_vendor_data
from .models import *
from user_permissions.models import UserWiseModulePermissions
import pprint
from django.template import Template, Context
from django.db.models.functions import Abs
from django.utils.dateparse import parse_date
# from vendor.serializers import *
# pp = pprint.PrettyPrinter(indent=2)

# class CommonFilterListSerializer(serializers.ListSerializer):
#     """
#     ListSerializer
#     cmobject: is_deleted=False
#     """
#     def to_representation(self, data):
#         print(data)
#         try:
#             print(data.paginator)
#             if not data.paginator:
#                 data = data.filter(is_deleted=False)
#         except Exception as e:
#             pass
#         return super(CommonFilterListSerializer, self).to_representation(data)
class CommonFilterListSerializer(serializers.ListSerializer):
    """
    ListSerializer
    cmobject: is_deleted=False
    """
    def to_representation(self, data):
        # if isinstance(data, Page):
        #     data.object_list = data.object_list.filter(is_deleted=False)
        if hasattr(data, 'object_list'):
            # print("check with object list")
            data.object_list = [item for item in data.object_list if not item.is_deleted]
        else:
            # print("check without pagination")
            data = data.filter(is_deleted=False)
        
        return super().to_representation(data)

class FinancialYearSerializer(serializers.ModelSerializer):
    """"
    Procurement SiteMaster Serializer
    """

    class Meta:
        model = FinancialYear
        fields = '__all__'

class SiteMasterSerializer(serializers.ModelSerializer):
    """"
    Procurement SiteMaster Serializer
    """
    project_details = serializers.SerializerMethodField()
    state_details = serializers.SerializerMethodField()


    def get_project_details(self, instance):
        _details = None
        if instance.project and instance.project_id:
            _project = ProjectMaster.cmobjects.filter(pk=instance.project_id).values()
            try:
                data = get_project_data(instance.project_id)
                _details = {"project": _project,  "data": data}
            except Exception as e:
                print('ERROR', e)
        return _details

    def get_state_details(self, instance):
        _details = None
        if instance.state and instance.state_id:
            _details = State.objects.filter(pk=instance.state_id).values()
        return _details

    class Meta:
        model = SiteMaster
        fields = '__all__'


class StoreSectionSerializer(serializers.ModelSerializer):
    """
    StoreSection Serializer
    """

    class Meta:
        model = StoreSection
        fields = '__all__'


class StoreMasterSerializer(serializers.ModelSerializer):
    """"
    Procurement StoreMaster Serializer
    """

    class Meta:
        model = StoreMaster
        fields = '__all__'
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'include_hidden_fields' in self.context and not self.context['include_hidden_fields']:
            fields_to_remove = []
            for field_name in self.fields.keys():
                if field_name.startswith('sap_'):
                    fields_to_remove.append(field_name)
            for field_name in fields_to_remove:
                self.fields.pop(field_name)

    # def update(self, instance, validated_data):
    #     users_ids = validated_data.pop('users', [])
    #     if users_ids:
    #         if not isinstance(users_ids, list):
    #             raise APIException("Users must be a list of integers")
    #         instance.users.clear()
    #         users = PmsUser.objects.filter(id__in=users_ids)
    #         instance.users.clear()
    #         if instance.site:
    #             instance.site.users.clear()
    #             if instance.site.project:
    #                 instance.site.project.users.clear()
    #         instance.users.set(users)
    #         if instance.site:
    #             instance.site.users.set(users)
    #             if instance.site.project:
    #                 instance.site.project.users.set(users)


class InventorySerializer(serializers.ModelSerializer):
    """"
    Procurement Inventory Serializer
    """
    item_code = serializers.SerializerMethodField()
    item_group = serializers.SerializerMethodField()
    item_group_id = serializers.SerializerMethodField()
    item_sub_group = serializers.SerializerMethodField()
    site_disp = serializers.SerializerMethodField()
    logs = serializers.SerializerMethodField()
    site_name = serializers.SerializerMethodField()
    site_location = serializers.SerializerMethodField()
    store_name = serializers.SerializerMethodField()
    item_name = serializers.SerializerMethodField()
    uom = serializers.SerializerMethodField()
    item_details = serializers.SerializerMethodField()
    plant_machinery_machine_code = serializers.SerializerMethodField()
    plant_machinery_machine_name = serializers.SerializerMethodField()
    plant_machinery_machine_group_id = serializers.SerializerMethodField()

    uom_opening_qty_details = serializers.SerializerMethodField()
    uom_opening_weight_details = serializers.SerializerMethodField()
    uom_opening_cost_per_unit_details = serializers.SerializerMethodField()
    total_project_quantity = serializers.SerializerMethodField()
    total_recieved_quantity = serializers.SerializerMethodField()
    total_balance_quantity = serializers.SerializerMethodField()

    def get_total_project_quantity(self, instance):
        total_quantity = 0
        if instance.site:
            if instance.site.project:
                if instance.material:
                    total_quantity = total_project_quantity(instance.material.id,instance.site.project.id)
        return total_quantity

    def get_total_recieved_quantity(self, instance):
        total_quantity = 0
        if instance.site:
            if instance.site.project:
                if instance.material:
                    total_quantity = total_recieved_quantity(instance.material.id,instance.site.project.id)
        return total_quantity

    def get_total_balance_quantity(self, instance):
        total_quantity = 0
        if instance.site:
            if instance.site.project:
                if instance.material:
                    total_quantity = total_balance_quantity(instance.material.id,instance.site.project.id)
        return total_quantity

    def get_item_code(self, instance):
        if instance.material:
            return instance.material.material_code
        else:
            return ""

    def get_item_group(self, instance):
        if instance.material and instance.material.material_type_id:
            if instance.material.material_type and instance.material.material_type.parent_id:
                if MaterialType.cmobjects.filter(pk=instance.material.material_type.parent_id).exists():
                    return instance.material.material_type.parent.name
        else:
            return ""
    def get_item_group_id(self, instance):
        if instance.material and instance.material.material_type_id:
            if instance.material.material_type and instance.material.material_type.parent_id:
                if MaterialType.cmobjects.filter(pk=instance.material.material_type.parent_id).exists():
                    return instance.material.material_type.parent.id
        else:
            return ""

    def get_item_sub_group(self, instance):
        if instance.material and instance.material.material_type_id:
            if MaterialType.cmobjects.filter(pk=instance.material.material_type_id).exists():
                return instance.material.material_type.name
        else:
            return ""

    def get_site_disp(self, instance):
        if instance.store and instance.store.site:
            return instance.store.site.id
        else:
            return instance.site.id if instance.site else None

    def get_logs(self, instance):
        # return InventoryLogs.cmobjects.filter(inventory=instance.id).order_by('-created_at').values()
        return []

    def get_site_name(self, instance):
        if instance.site:
            return instance.site.site_name
        else:
            return ""

    def get_site_location(self, instance):
        if instance.site:
            return instance.site.location
        else:
            return ""

    def get_store_name(self, instance):
        if instance.store:
            return instance.store.store_name
        else:
            return ""

    def get_item_name(self, instance):
        if instance.material:
            return instance.material.material_name
        else:
            return ""

    def get_uom(self, instance):
        if instance.material:
            return instance.material.unit_of_mesurement.symbol
        else:
            return ""

    def get_item_details(self, instance):
        item_detail = []
        if instance.material:
            item_detail.append(VendorMaterialMaster.cmobjects.filter(pk=int(instance.material.id)).values())
        return item_detail


    #1
    def get_uom_opening_qty_details(self, instance):
        if instance and instance.uom_opening_qty and instance.uom_opening_qty_id:
            return (UnitOfMesurement.cmobjects.filter(pk=instance.uom_opening_qty_id)
                    .values('id', 'formal_name', 'symbol', 'decimal_places', 'formula_for_qty_calculation'))
        else:
            return None
    #2
    def get_uom_opening_weight_details(self, instance):
        if instance and instance.uom_opening_weight and instance.uom_opening_weight_id:
            return (UnitOfMesurement.cmobjects.filter(pk=instance.uom_opening_weight_id)
                    .values('id', 'formal_name', 'symbol', 'decimal_places', 'formula_for_qty_calculation'))
        else:
            return None
    #3
    def get_uom_opening_cost_per_unit_details(self, instance):
        if instance and instance.uom_opening_cost_per_unit and instance.uom_opening_cost_per_unit_id:
            return (UnitOfMesurement.cmobjects.filter(pk=instance.uom_opening_cost_per_unit_id)
                    .values('id', 'formal_name', 'symbol', 'decimal_places', 'formula_for_qty_calculation'))
        else:
            return None

    def get_plant_machinery_machine_code(self, instance):
        if instance.plant_machinery_machine:
            return instance.plant_machinery_machine.equipment_number
        else:
            return ""

    def get_plant_machinery_machine_name(self, instance):
        if instance.plant_machinery_machine:
            return instance.plant_machinery_machine.equipment_description
        else:
            return ""

    def get_plant_machinery_machine_group_id(self, instance):
        if instance.plant_machinery_machine:
            return instance.plant_machinery_machine.plant_machinery_group_id
        else:
            return ""

    class Meta:
        model = Inventory
        fields = '__all__'


class InventoryLogsSerializer(serializers.ModelSerializer):
    """"
    Procurement Inventory Logs Serializer
    """
    item_code = serializers.SerializerMethodField()
    site_name = serializers.SerializerMethodField()
    store_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()

    def get_item_code(self, instance):
        if instance.inventory.material:
            return instance.inventory.material.material_code
        else:
            return ""

    def get_site_name(self, instance):
        if instance.inventory.site:
            return instance.inventory.site.site_name
        else:
            return ""

    def get_store_name(self, instance):
        if instance.inventory.store:
            return instance.inventory.store.store_name
        else:
            return ""

    def get_project_code(self, instance):
        # project_name = ''
        # if instance.inventory.site:
        #     projectdata = ProjectData.cmobjects.filter(project=instance.inventory.site.project.id, form__form_type='project_details', form__form_internal_name='project_name')
        #     for item in projectdata:
        #         if item:
        #             project_name = item.value
        return instance.inventory.site.project.project_name if instance.inventory.site and instance.inventory.site.project else ''

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation.pop('details')

        return representation

    class Meta:
        model = InventoryLogs
        fields = '__all__'


class PhysicalStockGroupSerializer(serializers.ModelSerializer):
    """
    PhysicalStockGroup Serializer
    """

    physical_stock_details = serializers.SerializerMethodField()

    def get_physical_stock_details(self, instance):
        if instance:
            obj = PhysicalStock.cmobjects.filter(parent_group=instance)
            _details = PhysicalStockSerializer(obj, many=True)
            return _details.data
        return []

    class Meta:
        model = PhysicalStockGroup
        fields = '__all__'

class PhysicalStockSerializer(serializers.ModelSerializer):
    """
    Physical Stock Serializer
    """

    inventory_details = serializers.SerializerMethodField()
    parent_group_details = serializers.SerializerMethodField()

    class Meta:
        model = PhysicalStock
        fields = '__all__'

    def get_inventory_details(self, instance):
        _inv = []
        if instance.inventory and instance.inventory_id:
            inventory = Inventory.cmobjects.filter(pk=instance.inventory_id).first()
            _in = InventorySerializer(inventory)
            return _in.data
        return []

    def get_parent_group_details(self, instance):
        if instance.parent_group and instance.parent_group_id:
            parent_group = PhysicalStockGroup.cmobjects.filter(pk=instance.parent_group_id).values()
            return parent_group
        return []



class MaterialRequestMasterItemsNotesSerializer(serializers.ModelSerializer):
    """"
    Procurement Material Request Item Notes Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = MaterialRequestMasterItemsNotes
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialRequestMasterItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement Material Request Item Serializer
    """
    notes = MaterialRequestMasterItemsNotesSerializer(many=True, required=False)
    id = serializers.IntegerField(required=False)

    ## custom method for views
    material_details = serializers.SerializerMethodField()
    p_m_details = serializers.SerializerMethodField()
    unit_of_mesurement_details = serializers.SerializerMethodField()
    inventory_store = serializers.SerializerMethodField()
    issue_qty = serializers.SerializerMethodField()
    indent_qty = serializers.SerializerMethodField()
    wbs_indirect_cost_name = serializers.SerializerMethodField()

    # approved by
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()

    class Meta:
        model = MaterialRequestMasterItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.material_request.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_name = projectdata.value if projectdata else ''
        # return project_name

        # projectdata = ProjectData.cmobjects.filter(project__id=instance.material_request.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.material_request.project.project_name if instance.material_request.project else ''
    
    def get_project_code(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.material_request.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_id').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_code = projectdata.value if projectdata else ''
        # return project_code

        # projectdata = ProjectData.cmobjects.filter(project__id=instance.material_request.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.material_request.project.project_code if instance.material_request.project else ''

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                # details = VendorMaterialMaster.cmobjects.filter(pk=instance.requested_material_id).first()
                # serializer = VendorMaterialMasterSerializer(details)
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details

    def get_p_m_details(self, instance):
        return_details = {}
        try:
            if instance.requested_machine:
                # details = PlantMachineryMachine.cmobjects.filter(pk=instance.requested_machine_id).first()
                # serializer = PlantMachineryMachineSerializer(details)
                serializer = PlantMachineryMachineSerializer(instance.requested_machine)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details
    
    def get_unit_of_mesurement_details(self, instance):
        # unit_of_mesurement_id = instance.requested_material.unit_of_mesurement_id \
        #       if instance.requested_material and instance.requested_material.unit_of_mesurement else None
        # mesurement_details = UnitOfMesurement.cmobjects.filter(id=unit_of_mesurement_id).values()
        # return mesurement_details
        unit_of_mesurement = instance.requested_material.unit_of_mesurement \
              if instance.requested_material and instance.requested_material.unit_of_mesurement else None
        mesurement_details = get_details_from_instance(unit_of_mesurement)
        return mesurement_details
        



    def get_inventory_store(self, instance):
        inventory = None
        requested_material = instance.requested_material if instance.requested_material else None
        material_request = instance.material_request if instance.material_request else None
        if requested_material and material_request:
            store = material_request.store
            if store:
                inventory = Inventory.cmobjects.filter(material=requested_material, store=store, organization=instance.organization).values()
        return inventory

    def get_issue_qty(self, instance):
        _issue_qty = None
        requested_material = instance.requested_material if instance.requested_material else None
        if requested_material:
            _issue_qty = (MaterialIssueItems.cmobjects.filter(requested_material=requested_material,
                                                              material_issue__site=instance.material_request.site)
                      .aggregate(total_quantity=Sum('quantity')))['total_quantity']
        return _issue_qty

    def get_indent_qty(self, instance):
        _indent_qty = 0
        _qty = (IndentItems.cmobjects.filter(material_request_item_id=instance.id,).aggregate(total_quantity=Sum('quantity')))
        if _qty:
            _indent_qty= _qty['total_quantity'] or 0
        return _indent_qty
    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            # _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,
            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            # _details = PmsUser.objects.filter(pk=instance.checked_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,
            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            # _details = PmsUser.objects.filter(pk=instance.cancelled_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,
            })
        return details
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            # _details = PmsUser.objects.filter(pk=instance.close_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,
            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            # _details = PmsUser.objects.filter(pk=instance.approved_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,
            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            # _details = PmsUser.objects.filter(pk=instance.rejected_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details


    def get_wbs_indirect_cost_name(self, instance):
        return instance.wbs_indirect_cost.indirect_cost if instance.wbs_indirect_cost else None




class MaterialRequestMasterAttachmentsSerializer(serializers.ModelSerializer):
    """"
    Procurement Material Attachments Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = MaterialRequestMasterAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialRequestSerializer(serializers.ModelSerializer):
    """"
    Procurement Material Request Serializer
    """
    requested_items = MaterialRequestMasterItemsSerializer(many=True, source="procurement_material_item_request")
    attachments = MaterialRequestMasterAttachmentsSerializer(many=True, required=False, source='procurement_material_request_attachment')

    # method fields
    organization_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()
    project_classification = serializers.SerializerMethodField()
    project_attachment = serializers.SerializerMethodField()
    project_company_name = serializers.SerializerMethodField()
    created_by_name = serializers.SerializerMethodField()
    approved_by_name = serializers.SerializerMethodField()
    total_req_item_qty = serializers.SerializerMethodField()
    department_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()

    # approved by
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    requested_by_details = serializers.SerializerMethodField()



    class Meta:
        model = MaterialRequestMaster
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        requested_items_data = validated_data.pop('procurement_material_item_request')
        attachments = validated_data.pop('procurement_material_request_attachment')
        material_request = MaterialRequestMaster.objects.create(**validated_data)
        # material_request.request_code = generate_all_code(material_request,['MR'])
        current_user = material_request.created_by if material_request.created_by else None

        for requested_attachment_data in attachments:
            try:
                MaterialRequestMasterAttachments.objects.create(
                    organization=material_request.organization,
                    material_request=material_request,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user,
                )
            except Exception as e:
                print(f"exception: {e}")

        for requested_item_data in requested_items_data:
            notes_data = requested_item_data.pop('notes', [])
            requested_item = MaterialRequestMasterItems.objects.create(material_request=material_request, created_by=current_user, **requested_item_data)
            # purchase_remarks = str(requested_item_data.get('purchase_remarks','')).strip()
            # if purchase_remarks:
            #     MaterialRequestMasterItemsRemarks.objects.update_or_create(
            #         material_request_item_id=requested_item.id,
            #         created_by=current_user,
            #         date=date.today(),
            #         remarks_type='purchase',
            #         defaults={'remarks': purchase_remarks}
            #     )

            for note_data in notes_data:
                MaterialRequestMasterItemsNotes.objects.create(material_request_item=requested_item, created_by=current_user, **note_data)
        material_request.save()
        return material_request

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_material_request_attachment', [])
        items_data = validated_data.get('procurement_material_item_request', [])

        existing_attachments = instance.procurement_material_request_attachment.filter(is_deleted=False)
        existing_items = instance.procurement_material_item_request.filter(is_deleted=False)
        print("existing Items >>>>>>>>>>>>>>>>>>>>>", existing_items)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = MaterialRequestMasterAttachments.objects.create(
                        organization=instance.organization,
                        material_request=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        for item_data in items_data:
            item_id = item_data.get('id')
            notes_data = item_data.pop("notes", [])
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                existing_item = MaterialRequestMasterItems.objects.create(material_request=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
            # purchase_remarks = str(item_data.get('purchase_remarks','')).strip()
            # if purchase_remarks:
            #     MaterialRequestMasterItemsRemarks.objects.update_or_create(
            #         material_request_item_id=existing_item.id,
            #         created_by=current_user,
            #         date=date.today(),
            #         remarks_type='purchase',
            #         defaults={'remarks': purchase_remarks}
            #     )

            existing_notes = existing_item.procurement_material_item_note_request.filter(is_deleted=False)

            for note_data in notes_data:
                note_id = note_data.get('id')
                existing_note = next((note for note in existing_notes if note.id == note_id), None)
                if not existing_note:
                    existing_note = MaterialRequestMasterItemsNotes.objects.create(material_request_item=existing_item, created_by=current_user, **note_data)
                else:
                    for note_field in existing_note._meta.fields:
                        note_field_name = note_field.name
                        if note_field_name in note_data:
                            setattr(existing_note, note_field_name, note_data[note_field_name])
                    setattr(existing_note, 'updated_by', current_user)
                    existing_note.save()

            for existing_note in existing_notes:
                if existing_note.id not in [note_data.get('id') for note_data in notes_data]:
                # if existing_note.id not in [note_data.get('id') for note_data in notes_data] and not existing_note.note_title == 'Purchase Remark':
                    setattr(existing_note, 'is_deleted', True)
                    setattr(existing_note, 'updated_by', current_user)
                    existing_note.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        user = self.context.get("user")
        check_approve_flag = UserWiseModulePermissions.cmobjects.filter(
            user_id=user,
            module_item__unique_id__in=['procurement-mr-approver'],
            level_permission=True,
        ).exists()
        representation = super().to_representation(instance)

        requested_items_data = representation.pop('requested_items', [])
        representation['requested_items'] = requested_items_data
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data

        for item_data in requested_items_data:
            item_data['approval_applicable'] = False
            if item_data['status'] == 'checked' and check_approve_flag:
                item_data['approval_applicable'] = True
                allowed_approvers = list(PmsUser.objects.filter(material_mr_approver__material_types_master__pk=item_data['requested_material']).values_list('pk',flat=True))
                if allowed_approvers:
                    if not user in allowed_approvers:
                        item_data['approval_applicable'] = False
            notes_data = MaterialRequestMasterItemsNotes.cmobjects.filter(material_request_item__id=item_data['id'])
            item_data['notes'] = MaterialRequestMasterItemsNotesSerializer(notes_data, many=True).data
        return representation

    ## custom method fields
    def get_organization_details(self, instance):
        # key_list = Organization.objects.filter(pk=instance.organization_id).values()
        # _key_list = list(key_list)
        # city_id = _key_list[0]["org_city_id"] if _key_list and _key_list[0] else 0
        # state_id = _key_list[0]["org_state_id"] if _key_list and _key_list[0] else 0
        # country_id = _key_list[0]["org_country_id"] if _key_list and _key_list[0] else 0

        # city_obj = City.objects.filter(pk=int(city_id)).first()
        # city_name = city_obj.name if city_obj else None

        # state_obj = State.objects.filter(pk=int(state_id)).first()
        # state_name = state_obj.name if state_obj else None

        # country_obj = Country.objects.filter(pk=int(country_id)).first()
        # country_name = country_obj.name if country_obj else None
        

        key_list = get_details_from_instance(instance.organization)
        city_name = None
        if instance.organization and instance.organization.org_city:
            city_obj = get_details_from_instance(instance.organization.org_city, type="dict")
            city_name = city_obj['name'] if city_obj else None
        state_name = None
        if instance.organization and instance.organization.org_state:
            state_obj = get_details_from_instance(instance.organization.org_state, type="dict")
            state_name = state_obj['name'] if state_obj else None
        country_name = None
        if instance.organization and instance.organization.org_country:
            country_obj = get_details_from_instance(instance.organization.org_country, type="dict")
            country_name = country_obj['name'] if country_obj else None

        address = f"{city_name} {state_name} {country_name}"
        key_list.append({'organization_address': address})
        return key_list

    def get_store_details(self, instance):
        # key_list = StoreMaster.objects.filter(pk=instance.store_id).values()
        # _key_list = list(key_list)
        # site_obj = SiteMaster.cmobjects.filter(pk=instance.store.site_id).first()
        # address = f'{site_obj.location if site_obj else None } '
        # _key_list.append({"store_address": address})
        # return _key_list
        
        key_list = get_details_from_instance(instance.store)
        site_obj = get_details_from_instance(instance.store.site, type="dict")
        address = f'{site_obj["location"] if site_obj else None } '
        key_list.append({"store_address": address})
        return key_list

    def get_project_name(self, instance):
        return instance.project.project_name if instance.project else ''
    def get_project_code(self, instance):
        return instance.project.project_code if instance.project else ''
    def get_project_classification(self, instance):
        return instance.project.project_classification if instance.project else ''
    def get_project_attachment(self, instance):
        return str(instance.project.attachment) if instance.project else ''
    def get_project_company_name(self, instance):
        return (str(instance.project.company.name) if instance.project.company else '') if instance.project else ''
    def get_created_by_name(self, instance):
        first_name = instance.created_by.first_name if instance.created_by else ''
        last_name = instance.created_by.last_name if instance.created_by else ''
        return first_name + ' ' + last_name

    def get_approved_by_name(self, instance):
        name = ''
        if instance.status == 'approved':
            name = instance.approved_by.user_full_name if instance.approved_by else ''
        return name

    def get_total_req_item_qty(self, instance):
        _qty = 0.0
        items = MaterialRequestMasterItems.cmobjects.filter(material_request=instance)
        for i in items:
            _qty = _qty + float(i.quantity_unit)
        return _qty

    def get_department_details(self, instance):
        details = []
        if instance.department:
            # _details = Department.cmobjects.filter(pk=instance.department_id).values('department')
            details = get_details_from_instance(instance.department)
        return details

    def get_site_details(self, instance):
        details = None
        if instance.site:
            # _details = SiteMaster.cmobjects.filter(pk=instance.site_id).values()
            details = get_details_from_instance(instance.site)
        return details

    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            # _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            # _details = PmsUser.objects.filter(pk=instance.checked_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            # _details = PmsUser.objects.filter(pk=instance.cancelled_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            # _details = PmsUser.objects.filter(pk=instance.close_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            # _details = PmsUser.objects.filter(pk=instance.approved_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            # _details = PmsUser.objects.filter(pk=instance.rejected_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    
    def get_requested_by_details(self, instance):
        details = None
        if instance.requested_by:
            # _details = PmsUser.objects.filter(pk=instance.requested_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.requested_by.first_name,
                "last_name": instance.requested_by.last_name,
                "email": instance.requested_by.email,

            })
        return details

    
    
    
class LocationChildSerializer(serializers.ModelSerializer):
    """"
    Procurement LocationMaster Serializer
    """
    class Meta:
        model = SiteLocationChild
        fields = '__all__'


class LocationMasterSerializer(serializers.ModelSerializer):
    """"
    Procurement LocationMaster Serializer
    """
    coordinates = LocationChildSerializer(many=True, read_only=True,
                                          source='procurement_site_location_child_master')

    class Meta:
        model = SiteLocationMaster
        fields = '__all__'

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        coordinates_data = representation.pop('coordinates', [])
        representation['coordinates'] = coordinates_data

        return representation


class IndentItemsNotesSerializer(serializers.ModelSerializer):
    """"
    Procurement IndentItemsNotes Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = IndentItemsNotes
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class IndentItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement IndentItems Serializer
    """

    enquiry_details = serializers.SerializerMethodField()
    notes = IndentItemsNotesSerializer(many=True, required=False)
    id = serializers.IntegerField(required=False)
    material_details = serializers.SerializerMethodField()
    p_m_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    item_group = serializers.SerializerMethodField()
    item_sub_group = serializers.SerializerMethodField()
    wbs_indirect_cost_name = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()
    total_po_qty = serializers.SerializerMethodField()

    

    # approved by
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()

   
    def get_enquiry_details(self, instance):
        return RFQVendorsItems.cmobjects.filter(
            indent_item_id=instance.id,
            rfq_vendors__is_deleted=False,
            rfq_vendors__is_archived=False
        ).annotate(
            cst_status = Subquery(
                CST.cmobjects.filter(
                    rfq_vendor_id=OuterRef('rfq_vendors_id'),
                    latest=True,
                ).values('rfq_vendor').annotate(
                    value=GroupConcat('status', distinct=True)
                ).values('value')
            ),
        ).exclude(cst_status='rejected').values('rfq_vendors','quantity','cst_status')


    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                # details = VendorMaterialMaster.cmobjects.filter(pk=instance.requested_material_id).first()
                # serializer = VendorMaterialMasterSerializer(details)
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details
    
    def get_p_m_details(self, instance):
        return_details = {}
        try:
            if instance.requested_machine:
                # details = PlantMachineryMachine.cmobjects.filter(pk=instance.requested_machine_id).first()
                # serializer = PlantMachineryMachineSerializer(details)
                serializer = PlantMachineryMachineSerializer(instance.requested_machine)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details
    def get_project_details(self, instance):
        details = []
        if instance.indent.project:
            # details = ProjectMaster.cmobjects.filter(pk=instance.indent.project_id).values()
            details = get_details_from_instance(instance.indent.project)
        return details

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.indent.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_name = projectdata.value if projectdata else ''
        # return project_name

        # projectdata = ProjectData.cmobjects.filter(project__id=instance.indent.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.indent.project.project_name if instance.indent.project else ''

    def get_project_code(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.indent.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_id').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_code = projectdata.value if projectdata else ''
        # return project_code
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.indent.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.indent.project.project_code if instance.indent.project else ''
    
    def get_site_details(self, instance):
        details = []
        if instance.indent.site:
            # details = SiteMaster.cmobjects.filter(pk=instance.indent.site_id).values()
            details = get_details_from_instance(instance.indent.site)
        return details

    def get_store_details(self, instance):
        details = []
        if instance.indent.store:
            # details = StoreMaster.cmobjects.filter(pk=instance.indent.store_id).values()
            details = get_details_from_instance(instance.indent.store)
        return details


    def get_item_group(self, instance):
        if instance.requested_material and instance.requested_material.material_type_id:
            if instance.requested_material.material_type and instance.requested_material.material_type.parent:
                # if MaterialType.cmobjects.filter(pk=instance.requested_material.material_type.parent_id).exists():
                #     return instance.requested_material.material_type.parent.name
                if not instance.requested_material.material_type.parent.is_deleted:
                    return instance.requested_material.material_type.parent.name
        else:
            return ""

    def get_item_sub_group(self, instance):
        if instance.requested_material and instance.requested_material.material_type_id:
            # if MaterialType.cmobjects.filter(pk=instance.requested_material.material_type_id).exists():
            #     return instance.requested_material.material_type.name
            if not instance.requested_material.material_type.is_deleted:
                return instance.requested_material.material_type.name
        else:
            return ""


    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            # _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            # _details = PmsUser.objects.filter(pk=instance.checked_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            # _details = PmsUser.objects.filter(pk=instance.cancelled_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            # _details = PmsUser.objects.filter(pk=instance.close_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            # _details = PmsUser.objects.filter(pk=instance.approved_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            # _details = PmsUser.objects.filter(pk=instance.rejected_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details

    def get_wbs_indirect_cost_name(self, instance):
        return instance.wbs_indirect_cost.indirect_cost if instance.wbs_indirect_cost else None
    
    def get_total_po_qty(self, instance):
        tmp = PurchaseOrderItems.cmobjects.filter(indent_item_id=instance.id,purchase_order__is_deleted=False).values('indent_item').annotate(total=Sum('quantity')).values('total')
        return tmp[0]['total'] if tmp else 0


    class Meta:
        model = IndentItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class IndentStagesSerializer(serializers.ModelSerializer):
    """
    Procurement IndentStages Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = IndentStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class IndentAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement IndentAttachments Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = IndentAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


#TODO
class IndentSerializer(serializers.ModelSerializer):
    """"
    Procurement Indent Serializer
    """
    indent_items = IndentItemsSerializer(many=True, source="procurement_indent_item_indent")
    stages = IndentStagesSerializer(many=True, required=False, source="procurement_indent_stages")
    attachments = IndentAttachmentsSerializer(many=True, required=False, source="procurement_indent_attachments")

    # SerializerMethodFields
    multi_stage_details = serializers.SerializerMethodField()
    linked_docs = serializers.SerializerMethodField()

    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()
    def get_linked_docs(self, instance):
        return parent_fields(instance,'procurement_indent_item_indent')

    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_name = projectdata.value if projectdata else ''
        # return project_name
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.project.project_name if instance.project else ''


    def get_project_code(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_id').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_code = projectdata.value if projectdata else ''
        # return project_code
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.project.project_code if instance.project else ''



    @transaction.atomic
    def create(self, validated_data):
        requested_items_data = validated_data.pop('procurement_indent_item_indent', [])
        stages_data = validated_data.pop('procurement_indent_stages', [])
        attachments = validated_data.pop('procurement_indent_attachments', [])

        instance = Indent.objects.create(**validated_data)
        # instance.request_code = generate_all_code(instance,['INDENT'])

        current_user = instance.created_by if instance.created_by else None
        for requested_item_data in requested_items_data:
            notes_data = requested_item_data.pop('notes', [])
            material_request_item = requested_item_data.get('material_request_item', None)
            if material_request_item:
                if material_request_item.status != 'approved':
                    raise APIException({'request_status': 0, 'msg': "material_request_item not approved"})
            indent_item = IndentItems.objects.create(indent=instance, created_by=current_user, **requested_item_data)

            for note_data in notes_data:
                IndentItemsNotes.objects.create(indent_items=indent_item, created_by=current_user, **note_data)
        
        for stage_data in stages_data:
            IndentStages.objects.create(indent=instance, created_by=current_user, **stage_data)

        # insert attachments ✅
        _item = None
        for requested_attachment_data in attachments:
            _item = IndentAttachments.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                attachment=process_attachments(requested_attachment_data),
                file_data="",
                mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
            )
        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        requested_items_data = validated_data.get('procurement_indent_item_indent', [])
        existing_items = instance.procurement_indent_item_indent.filter(is_deleted=False)
        stages_data = validated_data.get('procurement_indent_stages', [])
        existing_stages = instance.procurement_indent_stages.filter(is_deleted=False)
        attachments_data = validated_data.pop('procurement_indent_attachments', [])
        existing_attachments = instance.procurement_indent_attachments.filter(is_deleted=False)

        for requested_item_data in requested_items_data:
            item_id = requested_item_data.get('id')
            material_request_item = requested_item_data.get('material_request_item', None)
            if not material_request_item is None:
                if material_request_item.status != 'approved':
                    raise APIException({'request_status': 0, 'msg': "material_request_item not approved"})
            existing_item = next((item for item in existing_items if item.id == item_id), None)

            notes_data = requested_item_data.pop('notes', [])
            if not existing_item:
                existing_item = IndentItems.objects.create(indent=instance, created_by=current_user, **requested_item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in requested_item_data:
                        setattr(existing_item, field_name, requested_item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

            existing_notes = existing_item.procurement_indent_item_notes.filter(is_deleted=False)

            for note_data in notes_data:
                note_id = note_data.get('id')
                existing_note = next((note for note in existing_notes if note.id == note_id), None)
                if not existing_note:
                    existing_note = IndentItemsNotes.objects.create(indent_items=existing_item, created_by=current_user, **note_data)
                else:
                    for note_field in existing_note._meta.fields:
                        note_field_name = note_field.name
                        if note_field_name in note_data:
                            setattr(existing_note, note_field_name, note_data[note_field_name])
                    setattr(existing_note, 'updated_by', current_user)
                    existing_note.save()

            for existing_note in existing_notes:
                if existing_note.id not in [note_data.get('id') for note_data in notes_data]:
                    setattr(existing_note, "is_deleted", True)
                    setattr(existing_note, "updated_by", current_user)
                    existing_note.save()

        for existing_item in existing_items:
            if existing_item.id not in [item_data.get('id') for item_data in requested_items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
            existing_item.save()

        for item_data in stages_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_stages if item.id == item_id), None)
            if not existing_item:
                existing_item = IndentStages.objects.create(indent=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_stages:
            if existing_item.id not in [item_data.get('id') for item_data in stages_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = IndentAttachments.objects.create(
                        organization=instance.organization,
                        master=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        requested_items_data = representation.pop('indent_items', [])
        representation['indent_items'] = requested_items_data
        stages_data = representation.pop('stages', [])
        representation['stages'] = stages_data

        for item_data in requested_items_data:
            notes_data = IndentItemsNotes.cmobjects.filter(indent_items=item_data['id'])
            item_data['notes'] = IndentItemsNotesSerializer(notes_data, many=True).data
        return representation

    class Meta:
        model = Indent
        fields = '__all__'

    # method fields
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()

    def get_site_details(self, instance):
        details = []
        if instance.site:
            # _details = SiteMaster.cmobjects.filter(pk=instance.site_id).values()
            details = get_details_from_instance(instance.site)
        return details

    def get_store_details(self, instance):
        details = []
        if instance.store:
            # _details = StoreMaster.cmobjects.filter(pk=instance.store_id).values()
            details = get_details_from_instance(instance.store)
        return details


class RFQVendorsItemsSerializer(serializers.ModelSerializer):
    """
    Procurement RFQVendorsItems Serializer
    """
    id = serializers.IntegerField(required=False)
    material_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                # details = VendorMaterialMaster.cmobjects.filter(pk=instance.requested_material_id).first()
                # serializer = VendorMaterialMasterSerializer(details)
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details

    def get_uom_details(self, instance):
        # uom_detail = None
        # if instance.requested_material.id:
        #     if instance.requested_material.unit_of_mesurement.id:
        #         uom_detail = UnitOfMesurement.cmobjects.filter(pk=instance.requested_material.unit_of_mesurement.id).values()
        # return uom_detail
        uom_detail = None
        if instance.requested_material and instance.requested_material.unit_of_mesurement:
           uom_detail = get_details_from_instance(instance.requested_material.unit_of_mesurement)
        return uom_detail
    class Meta:
        model = RFQVendorsItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class RFQVendorsSerializer(serializers.ModelSerializer):
    """"
    Procurement RFQVendors Serializer
    """
    id = serializers.IntegerField(required=False)
    items = RFQVendorsItemsSerializer(many=True, source="procurement_rfq_vendors_items")

    # vendor_ids_list = serializers.SerializerMethodField()
    # vendor_url_list = serializers.SerializerMethodField()
    indent_details = serializers.SerializerMethodField()
    mail_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    quot_count = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()

    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    cst_details = serializers.SerializerMethodField()
    linked_docs = serializers.SerializerMethodField()
    indents_details = serializers.SerializerMethodField()
    material_requests_details = serializers.SerializerMethodField()
    selected_quotation_list = serializers.SerializerMethodField()
    def get_selected_quotation_list(self, instance):
        return instance.procurement_purchase_order_rfq_vendor.values_list('quotation_id', flat=True)

    def get_indents_details(self, instance):
       
        return get_details_from_instance(instance.indents,extras=[], type="list")

    def get_material_requests_details(self, instance):
        return get_details_from_instance(instance.material_requests,extras=[], type="list")
    def get_linked_docs(self, instance):
        return parent_fields(instance,'procurement_rfq_vendors_items')
    
    def get_quot_count(self, instance):
        # _quot_count = Quotation.cmobjects.filter(rfq_vendor_id=instance.id).exclude(status__in=['rejected','cancelled']).aggregate(total_count=Count('id'))
        _quot_count = instance.procurement_rfq_quotation.exclude(status__in=['rejected','cancelled']).aggregate(total_count=Count('id'))
        return _quot_count['total_count'] if _quot_count['total_count'] else 0.0

    def get_vendor_details(self, instance):
        details = []
        for vendor_details in instance.vendor.filter(is_deleted=False):
            details.append(get_vendor_data(vendor_details))
        return details

    def get_mail_details(self, instance):
        mail_details = None
        if instance.id:
            email_template = EmailTemplates.cmobjects.get(template_name='RFQ')
            htmly = Template(email_template.body if email_template else '')
            mail_details = instance.procurement_rfq_vendors_mails.filter(is_deleted=False).values(
                'id',
                'vendor_id',
                'email_send__is_sent',
                'email_send__subject',
                'email_send__context',
                'allow_revision',
                'regret',
                'rfq_vendors_id',
                'organization_id',
            )
            for mail_detail in mail_details:
                mail_detail['email_send__processed_message'] = htmly.render(Context(mail_detail['email_send__context']))
                # mail_detail['quotation_url'] = generate_rfq_link(mail_detail['vendor_id'],mail_detail['rfq_vendors_id'],mail_detail['organization_id'],'purchase','non-gst')
                # mail_detail['quotation_url_with_gst'] = generate_rfq_link(mail_detail['vendor_id'],mail_detail['rfq_vendors_id'],mail_detail['organization_id'],'purchase','gst')
                mail_detail['quotation_url'] = mail_detail['email_send__context']['vendor_link_without_gst']
                mail_detail['quotation_url_with_gst'] = mail_detail['email_send__context']['vendor_link_with_gst']
                mail_detail['email_send__context'] = ''
        return mail_details

    def get_indent_details(self, instance):
        indent_details = None
        if instance.indent:
            # indent_details = Indent.cmobjects.filter(pk=instance.indent_id).values()
            indent_details = get_details_from_instance(instance.indent)
        return indent_details
    def get_cst_details(self, instance):
        
        return CST.cmobjects.filter(rfq_vendor_id=instance.id).values('id','status','current_stage')
    # def get_vendor_ids_list(self, obj):
    #     return obj.vendor_ids_list

    # def get_vendor_url_list(self, obj):
    #     return obj.vendor_url_list
    # vendor = VendorMasterV2Serializer(read_only=True, many=True)
    vendor_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)

    def validate_vendor_ids(self, value):
        errors = []
        for id in value:
            try:
                VendorMasterV2.cmobjects.get(pk=id)
            except VendorMasterV2.DoesNotExist:
                errors.append(f"Vendor with ID {id} does not exist.")
        if errors:
            raise serializers.ValidationError(errors)
        return value

    def get_project_details(self, instance):
        _details = None
        if instance.project:
            # _project = ProjectMaster.cmobjects.filter(pk=instance.project_id).values()
            try:
                data = get_project_data(instance.project_id)
                _details = {"project_id": instance.project_id, "data": data}
            except Exception as e:
                print('ERROR', e)
        return _details

    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            # _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            # _details = PmsUser.objects.filter(pk=instance.checked_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details

    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            # _details = PmsUser.objects.filter(pk=instance.cancelled_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details

    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            # _details = PmsUser.objects.filter(pk=instance.close_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details

    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            # _details = PmsUser.objects.filter(pk=instance.approved_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details

    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            # _details = PmsUser.objects.filter(pk=instance.rejected_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details

    @transaction.atomic
    def create(self, validated_data):
        requested_items_data = validated_data.pop('procurement_rfq_vendors_items', [])
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])

        id = validated_data.get('id')
        existing_record = RFQVendors.cmobjects.filter(pk=id).first()
        vendor_ids = validated_data.pop('vendor_ids')
        current_user = validated_data.get('updated_by', None)

        if existing_record:
            for field in existing_record._meta.fields:
                field_name = field.name
                if field_name in validated_data:
                    setattr(existing_record, field_name, validated_data[field_name])
            setattr(existing_record, 'updated_by', current_user)
            
            existing_record.vendor.clear()
            for vendor_id in vendor_ids:
                vendor = VendorMasterV2.objects.filter(pk=vendor_id).first()
                # vendor = VendorMasterV2.objects.get(pk=vendor_id)

                existing_record.vendor.add(vendor)
            ## uncomment below as aminul da and arindam sir disucssion on 23-05-2025   
            existing_items = existing_record.procurement_rfq_vendors_items.filter(is_deleted=False)
            for requested_item_data in requested_items_data:
                item_id = requested_item_data.get('id')
                existing_item = next((item for item in existing_items if item.id == item_id), None)

                if not existing_item:
                    existing_item = RFQVendorsItems.objects.create(rfq_vendors=existing_record, created_by=current_user, **requested_item_data)
                else:
                    for field in existing_item._meta.fields:
                        field_name = field.name
                        if field_name in requested_item_data:
                            setattr(existing_item, field_name, requested_item_data[field_name])
                    setattr(existing_item, 'updated_by', current_user)
                    existing_item.save()

            for existing_item in existing_items:
                if existing_item.id not in [item_data.get('id') for item_data in requested_items_data]:
                    setattr(existing_item, 'is_deleted', True)
                    setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
            ###comment out as per aminul da and arindam sir disucssion on 23-05-2025   
            # for requested_item_data in requested_items_data:
            #     requested_item_data['updated_by']=current_user
            #     requested_item_data['rfq_vendors']=existing_record
            #     # item = RFQVendorsItems.cmobjects.update_or_create(rfq_vendors=existing_record,requested_material=requested_item_data['requested_material'], defaults=requested_item_data)
            #     last_item = RFQVendorsItems.cmobjects.filter(
            #         rfq_vendors=existing_record,
            #         requested_material=requested_item_data['requested_material'],
            #         indent_item=requested_item_data['indent_item'],
            #         material_request_item=requested_item_data['material_request_item'],
            #     ).last() 
                
            #     if last_item:
            #         for key, value in requested_item_data.items():
            #             setattr(last_item, key, value)
            #         last_item.save()
            #     else:
            #         RFQVendorsItems.objects.create(**requested_item_data)
            if indents:
                existing_record.indents.clear()
                existing_record.indents.set(indents)
            if material_requests:
                existing_record.material_requests.clear()
                existing_record.material_requests.set(material_requests)    
            existing_record.save()
            return existing_record
        else:
            record = RFQVendors.objects.create(**validated_data)
            # record.request_code = generate_all_code(record,['ENQUIRY'])
            setattr(record, 'created_by', current_user)

            for vendor_id in vendor_ids:
                # vendor = VendorMasterV2.cmobjects.get(pk=vendor_id)
                vendor = VendorMasterV2.cmobjects.filter(pk=vendor_id).first()
                record.vendor.add(vendor)
            for requested_item_data in requested_items_data:
                requested_item_data['created_by']=current_user
                item = RFQVendorsItems.objects.create(rfq_vendors=record, **requested_item_data)
            record.indents.set(indents) if indents else None
            record.material_requests.set(material_requests) if material_requests else None

            record.save()
            return record

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        requested_items_data = representation.pop('items', [])
        representation['items'] = requested_items_data

        return representation

    class Meta:
        model = RFQVendors
        fields = '__all__'


class MaterialIssueItemsNotesSerializer(serializers.ModelSerializer):
    """
    Procurement MaterialIssueItemsNotes Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = MaterialIssueItemsNotes
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialIssueItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement MaterialIssueItems Serializer
    """
    notes = MaterialIssueItemsNotesSerializer(many=True, required=False)
    id = serializers.IntegerField(required=False)
    material_details = serializers.SerializerMethodField()
    material_type_details = serializers.SerializerMethodField()
    material_sub_type_details = serializers.SerializerMethodField()
    unit_of_mesurement_details = serializers.SerializerMethodField()
    hsn_details = serializers.SerializerMethodField()

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                # details = VendorMaterialMaster.cmobjects.filter(pk=instance.requested_material_id).first()
                # serializer = VendorMaterialMasterSerializer(details)
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details

    def get_material_type_details(self, instance):
        item = instance.requested_material if instance.requested_material else None
        material_type = None
        if item and item.material_type:
            # material_type = MaterialType.cmobjects.filter(pk=item.material_type_id).values()
            material_type = get_details_from_instance(item.material_type)
        return material_type

    def get_material_sub_type_details(self, instance):
        sub_type_details = None
        item = instance.requested_material if instance.requested_material else None
        if item and item.material_sub_type:
            # sub_type_details = MaterialSubType.cmobjects.filter(pk=item.material_sub_type_id).values()
            sub_type_details = get_details_from_instance(item.material_sub_type)
        return sub_type_details

    def get_unit_of_mesurement_details(self, instance):
        unit_of_mesurement = instance.requested_material.unit_of_mesurement if instance.requested_material and instance.requested_material.unit_of_mesurement else None
        # mesurement_details = UnitOfMesurement.cmobjects.filter(id=unit_of_mesurement_id).values()
        mesurement_details = get_details_from_instance(unit_of_mesurement)
        return mesurement_details

    def get_hsn_details(self, instance):
        hsn = None
        item = instance.requested_material if instance.requested_material else None
        if item and item.hsn_code:
            # vendormaterialmaster = VendorMaterialMaster.cmobjects.filter(pk=item.id).first()
            # if vendormaterialmaster:
                # hsn = HSNMaster.cmobjects.filter(pk=vendormaterialmaster.hsn_code_id).values()
            hsn = get_details_from_instance(item.hsn_code)
        return hsn

    class Meta:
        model = MaterialIssueItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialIssueAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement MaterialIssueAttachments Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = MaterialIssueAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialIssueSerializer(serializers.ModelSerializer):
    """"
    Procurement MaterialIssue Serializer
    """
    issue_items = MaterialIssueItemsSerializer(many=True, source="procurement_material_issue_item")
    attachment = MaterialIssueAttachmentsSerializer(many=True, required=False,
                                                                   source="procurement_material_issue_attachment")

    party_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    project__project_company_name = serializers.SerializerMethodField()
    project__attachment = serializers.SerializerMethodField()
    item_total_amount = serializers.SerializerMethodField()
    item_total_received_quantity = serializers.SerializerMethodField()
    item_total_return_quantity = serializers.SerializerMethodField()
    
    def get_project__project_company_name(self, instance):
        return (str(instance.project.company.name) if instance.project.company else '') if instance.project else ''
    
    def get_project__attachment(self, instance):
        # return (instance.project.attachment.url if instance.project.attachment else '') if instance.project else ''
        return str(instance.project.attachment) if instance.project else ''
    def get_item_total_amount(self, instance):
        return MaterialIssueItems.cmobjects.filter(material_issue_id=instance.id).values('material_issue').annotate(total=Sum('amount')).values('total')
    def get_item_total_received_quantity(self, instance):
        return MaterialIssueItems.cmobjects.filter(material_issue_id=instance.id).values('material_issue').annotate(total=Sum('received_quantity')).values('total')
    def get_item_total_return_quantity(self, instance):
        return MaterialIssueItems.cmobjects.filter(material_issue_id=instance.id).values('material_issue').annotate(total=Sum('return_quantity')).values('total')
    

    linked_docs = serializers.SerializerMethodField()
    def get_linked_docs(self, instance):
        return parent_fields(instance,'procurement_material_issue_item')
    
    @transaction.atomic
    def create(self, validated_data):
        requested_items_data = validated_data.pop('procurement_material_issue_item', [])
        requested_attachment = validated_data.pop('procurement_material_issue_attachment', [])
        material_issue = MaterialIssue.objects.create(**validated_data)
        # material_issue.request_code = generate_all_code(material_issue,['ISSUE'])
        current_user = material_issue.created_by if material_issue.created_by else None
        for requested_attachment_data in requested_attachment:
            try:
                MaterialIssueAttachments.objects.create(
                    organization=material_issue.organization,
                    material_issue=material_issue,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        for requested_item_data in requested_items_data:
            requested_item_data['created_by']=current_user
            notes_data = requested_item_data.pop('notes', [])
            issue_item = MaterialIssueItems.objects.create(material_issue=material_issue, **requested_item_data)

            for note_data in notes_data:
                note_data['created_by']=current_user
                MaterialIssueItemsNotes.objects.create(material_issue_item=issue_item, **note_data)
        material_issue.save()
        return material_issue

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_material_issue_attachment', [])
        requested_items_data = validated_data.get('procurement_material_issue_item', [])

        existing_attachments = instance.procurement_material_issue_attachment.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = MaterialIssueAttachments.objects.create(
                        organization=instance.organization,
                        material_issue=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()


        existing_items = instance.procurement_material_issue_item.filter(is_deleted=False)
        for requested_item_data in requested_items_data:
            notes_data = requested_item_data.pop('notes', [])
            
            item_id = requested_item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                requested_item_data['created_by'] = current_user
                existing_item = MaterialIssueItems.objects.create(material_issue=instance, **requested_item_data)

            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in requested_item_data:
                        setattr(existing_item, field_name, requested_item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

            existing_notes = existing_item.procurement_material_issue_item_note.filter(is_deleted=False)
            for note_data in notes_data:
                note_id = note_data.get('id')
                existing_note = next((note for note in existing_notes if note.id == note_id), None)
                if not existing_note:
                    note_data['created_by'] = current_user
                    existing_note = MaterialIssueItemsNotes.objects.create(material_issue_item=existing_item,**note_data)
                else:
                    for note_field in existing_note._meta.fields:
                        note_field_name = note_field.name
                        if note_field_name in note_data:
                            setattr(existing_note, note_field_name, note_data[note_field_name])
                    setattr(existing_note, 'updated_by', current_user)
                    existing_note.save()
            for existing_note in existing_notes:
                if existing_note.id not in [note_data.get('id') for note_data in notes_data]:
                    setattr(existing_note, 'is_deleted', True)
                    setattr(existing_note, 'updated_by', current_user)
                    existing_note.save()
        multiple = self.context.get("multiple",None)
        if not multiple:
            for existing_item in existing_items:
                if existing_item.id not in [item_data.get('id') for item_data in requested_items_data]:
                    if instance.status == 'approved':
                        pass
                    setattr(existing_item, 'is_deleted', True)
                    setattr(existing_item, 'updated_by', current_user)
                    existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        requested_items_data = representation.pop('issue_items', [])
        representation['issue_items'] = requested_items_data
        attachment_data = representation.pop('attachment', [])
        representation['attachment'] = attachment_data

        for item_data in requested_items_data:
            notes_data = MaterialIssueItemsNotes.cmobjects.filter(material_issue_item__id=item_data['id'])
            item_data['notes'] = MaterialIssueItemsNotesSerializer(notes_data, many=True).data

        return representation


    def get_party_details(self, instance):
        _details = []
        try:
            if instance.party:
                data = get_vendor_data(instance.party)
                _details = {"party_id": instance.party.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details

    def get_vendor_details(self, instance):
        _details = []
        try:
            if instance.vendor:
                data = get_vendor_data(instance.vendor)
                _details = {"vendor_id": instance.vendor.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details

    class Meta:
        model = MaterialIssue
        fields = '__all__'


class QuotationTermsAndConditionsSerializer(serializers.ModelSerializer):
    """
    Procurement QuotationTermsAndConditions Serializer
    """
    id = serializers.IntegerField(required=False)
    
    class Meta:
        model = QuotationTermsAndConditions
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class QuotationAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement QuotationAttachments Serializer
    """
    class Meta:
        model = QuotationAttachments
        fields = '__all__'


class QuotationItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement Quotation Serializer
    """
    id = serializers.IntegerField(required=False)
    material_details = serializers.SerializerMethodField()
    purchase_order_items = serializers.SerializerMethodField()
    mr_details = serializers.SerializerMethodField()

    def get_mr_details(self, instance):
        _details = None
        if instance.material_request_item and instance.material_request_item.material_request:
            _details = get_details_from_instance(instance.material_request_item.material_request)
        return _details

    def get_purchase_order_items(self, instance):
        return PurchaseOrderItems.cmobjects.filter(quotation_item_id=instance.id,purchase_order__is_deleted=False).values('id','quantity')

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                # details = VendorMaterialMaster.cmobjects.filter(pk=instance.requested_material_id).first()
                # serializer = VendorMaterialMasterSerializer(details)
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details

    class Meta:
        model = QuotationItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class QuotationTaxDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement Quotation Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = QuotationTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class QuotationExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement Quotation Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = QuotationExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class QuotationSerializer(serializers.ModelSerializer):
    """"
    Procurement Quotation Serializer
    """
    
    linked_docs = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()
    project_classification = serializers.SerializerMethodField()
    cst_details = serializers.SerializerMethodField()
    indents_details = serializers.SerializerMethodField()
    material_requests_details = serializers.SerializerMethodField()
    inco_term_one_for_sap_details = serializers.SerializerMethodField()

    def get_indents_details(self, instance):
        # _details = []
        # if instance.indents:
        #     _obj = instance.indents.filter(is_deleted=False)
        #     _ids = [o.pk for o in _obj]
        #     if _ids:
        #         _details = Indent.cmobjects.filter(pk__in=(_ids)).values()
        # return _details
        return get_details_from_instance(instance.indents,extras=[], type="list")
    def get_material_requests_details(self, instance):
        # _details = []
        # if instance.material_requests:
        #     _obj = instance.material_requests.filter(is_deleted=False)
        #     _ids = [o.pk for o in _obj]
        #     if _ids:
        #         _details = MaterialRequestMaster.cmobjects.filter(pk__in=(_ids)).values()
        #         print(_details)
        # return _details 
        return get_details_from_instance(instance.material_requests,extras=[], type="list")

    def get_cst_details(self, instance):
        cst_details = None
        if instance.rfq_vendor:
            cst_details = CST.cmobjects.filter(rfq_vendor_id=instance.rfq_vendor.id,latest=True).order_by('-version').values()
        return cst_details

    def get_linked_docs(self, instance):
        return parent_fields(instance,'procurement_rfq_quotation_item')
    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, type="dict")
    def get_inco_term_one_for_sap_details(self, instance):
        return get_details_from_instance(instance.inco_term_one_for_sap, type="dict")
    

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_name = projectdata.value if projectdata else ''
        # return project_name
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.project.project_name if instance.project else ''

    
    def get_project_code(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_id').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_code = projectdata.value if projectdata else ''
        # return project_code
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.project.project_code if instance.project else ''

    def get_project_classification(self, instance):
        # projectdata = ProjectData.cmobjects.filter(
        #     project_id=instance.project_id,
        #     form__form_internal_name='project_classification'
        # ).first()
        # if projectdata and projectdata.value:
        #     dropdown = FormDropdownChoices.cmobjects.filter(id=projectdata.value).first()
        #     return dropdown.option if dropdown else ''
        return instance.project.project_classification if instance.project else ''
    quotation_items = QuotationItemsSerializer(many=True, source="procurement_rfq_quotation_item")
    quotation_tax = QuotationTaxDetailsSerializer(many=True, required=False, source="procurement_quotation_tax")
    quotation_expense = QuotationExpenseDetailsSerializer(many=True, required=False, source="procurement_quotation_expense")
    attachments = QuotationAttachmentsSerializer(many=True, required=False, source="procurement_quotation_attachment")
    quotation_tnc = QuotationTermsAndConditionsSerializer(many=True, required=False, source="procurement_rfq_quotation_terms_and_conditions")

    def calculate_totals(self, instance):
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.procurement_rfq_quotation_item.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount

        for item in instance.procurement_quotation_expense.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

        for item in instance.procurement_quotation_tax.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_rfq_quotation_item', [])
        tax_data = validated_data.pop('procurement_quotation_tax', [])
        expense_data = validated_data.pop('procurement_quotation_expense', [])
        requested_attachment = validated_data.pop('procurement_quotation_attachment', [])
        tnc_data = validated_data.pop('procurement_rfq_quotation_terms_and_conditions', [])
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])

        quotation = Quotation.objects.create(**validated_data)
        
        current_user = quotation.created_by if quotation.created_by else None
        quotation.indents.set(indents) if indents else None
        quotation.material_requests.set(material_requests) if material_requests else None

        for requested_attachment_data in requested_attachment:
            try:
                QuotationAttachments.objects.create(
                    organization=quotation.organization,
                    quotation=quotation,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        for quotation_item_data in items_data:
            QuotationItems.objects.create(quotation=quotation, created_by=current_user, **quotation_item_data)
        self.calculate_totals(quotation)
        for quotation_expense_data in expense_data:
            QuotationExpenseDetails.objects.create(quotation=quotation, created_by=current_user, **quotation_expense_data)
        self.calculate_totals(quotation)
        for quotation_tax_data in tax_data:
            QuotationTaxDetails.objects.create(quotation=quotation, created_by=current_user, **quotation_tax_data)
        for quotation_tnc_data in tnc_data:
            QuotationTermsAndConditions.objects.create(quotation=quotation, created_by=current_user, **quotation_tnc_data)

        self.calculate_totals(quotation)
        quotation.save()
        return quotation

    @transaction.atomic
    def update(self, instance, validated_data):
        
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])

        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        if indents:
            instance.indents.clear()
            instance.indents.set(indents)
        if material_requests:
            instance.material_requests.clear()
            instance.material_requests.set(material_requests)    
        current_user = instance.updated_by if instance.updated_by else None

        quotation_item_data = validated_data.get('procurement_rfq_quotation_item', [])
        quotation_tax_data = validated_data.get('procurement_quotation_tax', [])
        quotation_expense_data = validated_data.get('procurement_quotation_expense', [])
        quotation_tnc_data = validated_data.get('procurement_rfq_quotation_terms_and_conditions', [])
        attachments_data = validated_data.get('procurement_quotation_attachment', [])

        existing_attachments = instance.procurement_quotation_attachment.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = QuotationAttachments.objects.create(
                        organization=instance.organization,
                        quotation=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        existing_items = instance.procurement_rfq_quotation_item.filter(is_deleted=False)
        existing_taxes = instance.procurement_quotation_tax.filter(is_deleted=False)
        existing_expense = instance.procurement_quotation_expense.filter(is_deleted=False)
        existing_tncs = instance.procurement_rfq_quotation_terms_and_conditions.filter(is_deleted=False)

        for item_data in quotation_tnc_data:
            item_id = item_data.get('id')
            item_data['created_by'] = current_user
            existing_item = next((item for item in existing_tncs if item.id == item_id), None)

            if not existing_item:
                existing_item = QuotationTermsAndConditions.objects.create(quotation=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_tncs:
            if existing_item.id not in [item_data.get('id') for item_data in quotation_tnc_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for item_data in quotation_item_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if not existing_item:
                existing_item = QuotationItems.objects.create(quotation=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [item_data.get('id') for item_data in quotation_item_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        self.calculate_totals(instance)
        
        for item_data in quotation_expense_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_expense if item.id == item_id), None)

            if not existing_item:
                existing_item = QuotationExpenseDetails.objects.create(quotation=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_expense:
            if existing_item.id not in [item_data.get('id') for item_data in quotation_expense_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        self.calculate_totals(instance)
        
        for item_data in quotation_tax_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_taxes if item.id == item_id), None)

            if not existing_item:
                existing_item = QuotationTaxDetails.objects.create(quotation=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_taxes:
            if existing_item.id not in [item_data.get('id') for item_data in quotation_tax_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        self.calculate_totals(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        quotation_items_data = representation.pop('quotation_items', [])
        representation['quotation_items'] = quotation_items_data
        quotation_tax_data = representation.pop('quotation_tax', [])
        representation['quotation_tax'] = quotation_tax_data
        quotation_expense_data = representation.pop('quotation_expense', [])
        representation['quotation_expense'] = quotation_expense_data
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data
        quotation_tnc_data = representation.pop('quotation_tnc', [])
        representation['quotation_tnc'] = quotation_tnc_data

        return representation

    class Meta:
        model = Quotation
        fields = '__all__'


class PurchaseOrderAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement PurchaseOrderAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseOrderAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderItemsNotesSerializer(serializers.ModelSerializer):
    """"
    Procurement Purchase Order Notes Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseOrderItemsNotes
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderItemsExpenseDetailsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    expense_details = serializers.SerializerMethodField()

    def get_expense_details(self, instance):
        details = None
        if instance.expense_head:
            details = get_details_from_instance(instance.expense_head)
        return details
    
    class Meta:
        model = PurchaseOrderItemsExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderPaymentScheduleAttachmentsSerializer(serializers.ModelSerializer):
    """"
    PurchaseOrderPaymentScheduleAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseOrderPaymentScheduleAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderPaymentScheduleSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseOrderPaymentSchedule Serializer
    """
    id = serializers.IntegerField(required=False)
    attachments = PurchaseOrderPaymentScheduleAttachmentsSerializer(many=True, required=False, source='procurement_po_payment_schedule_attachments')

    class Meta:
        model = PurchaseOrderPaymentSchedule
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseOrder Serializer
    """
    id = serializers.IntegerField(required=False)
    notes = PurchaseOrderItemsNotesSerializer(many=True, required=False)
    # expenses = PurchaseOrderItemsExpenseDetailsSerializer(many=True, required=False)


    ## custom method for views
    material_details = serializers.SerializerMethodField()
    material_type_details = serializers.SerializerMethodField()
    material_sub_type_details = serializers.SerializerMethodField()
    unit_of_mesurement_details = serializers.SerializerMethodField()
    hsn_details = serializers.SerializerMethodField()
    quotation_item_details = serializers.SerializerMethodField()
    quotation_details = serializers.SerializerMethodField()
    indent_item_details = serializers.SerializerMethodField()
    indent_details = serializers.SerializerMethodField()
    mr_details = serializers.SerializerMethodField()
    wbs_indirect_cost_name = serializers.SerializerMethodField()
    recieved_against_po = serializers.SerializerMethodField()

    class Meta:
        model = PurchaseOrderItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_recieved_against_po(self, instance):
        return GRNItems.cmobjects.filter(grn__is_deleted=False,purchase_order_item_id=instance.id).aggregate(total_quantity=Sum(F('quantity')))['total_quantity']

    def get_material_details(self, instance):
        return_details = []
        try:
            if instance.item:
                # details = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).first()
                serializer = VendorMaterialMasterSerializer(instance.item)
                return_details = [serializer.data]
        except Exception as e:
            print('ERROR', e)

        return return_details

    def get_material_type_details(self, instance):
        item = instance.item if instance.item else None
        material_type = None
        if item and item.material_type:
            # material_type = MaterialType.cmobjects.filter(pk=item.material_type_id).values()
            material_type = get_details_from_instance(item.material_type)

        return material_type

    def get_material_sub_type_details(self, instance):
        sub_type_details = None
        item = instance.item if instance.item else None
        if item and item.material_sub_type:
            # sub_type_details = MaterialSubType.cmobjects.filter(pk=item.material_sub_type_id).values()
            sub_type_details = get_details_from_instance(item.material_sub_type)
        return sub_type_details

    def get_unit_of_mesurement_details(self, instance):
        unit_of_mesurement = instance.item.unit_of_mesurement if instance.item and instance.item.unit_of_mesurement else None
        # mesurement_details = UnitOfMesurement.cmobjects.filter(id=unit_of_mesurement_id).values()
        mesurement_details = get_details_from_instance(unit_of_mesurement)
        return mesurement_details

    def get_hsn_details(self, instance):
        hsn = []
        item = instance.item if instance.item else None
        if item and item.hsn_code:
            # vendormaterialmaster = VendorMaterialMaster.cmobjects.filter(pk=item.id).first()
            # if vendormaterialmaster:
                # hsn = HSNMaster.cmobjects.filter(pk=vendormaterialmaster.hsn_code_id).values()
            hsn = get_details_from_instance(item.hsn_code)
        return hsn

    def get_quotation_details(self, instance):
        _details = None
        if instance.quotation_item and instance.quotation_item.quotation:
            _details = get_details_from_instance(instance.quotation_item.quotation)
        return _details

    def get_quotation_item_details(self, instance):
        _details = None
        if instance.quotation_item:
            # _details = (QuotationItems.cmobjects.filter(pk=instance.quotation_item_id)
            # .values(
            #     'id',
            #     'requested_material',
            #     'quantity',
            #     'uom',
            #     'weight',
            #     'rate',
            #     'item_amount'
            # ))
            _details = get_details_from_instance(instance.quotation_item)
        return _details

    def get_indent_item_details(self, instance):
        _details = None
        if instance.indent_item:
            # _details = (IndentItems.cmobjects.filter(pk=instance.indent_item_id)
            #             .values('id',
            #                     'requested_material',
            #                     'quantity',
            #                     'uom',
            #                     'weight'))
            _details = get_details_from_instance(instance.indent_item)
        return _details

    def get_indent_details(self, instance):
        _details = None
        if instance.indent_item and instance.indent_item.indent:
            # _details = (Indent.cmobjects.filter(pk=instance.indent_item.indent.pk)
            #             .values('id',
            #                     'request_code',
            #                     'date',
            #                     'created_at',
            #                     'updated_at',
            #                     'requested_by',
            #                     'created_by',
            #                     'updated_by'
            #                     ))
            _details = get_details_from_instance(instance.indent_item.indent)
        return _details

    def get_mr_details(self, instance):
        _details = None
        if instance.indent_item and instance.indent_item.indent and instance.indent_item.indent.material_request:
            # _details = (MaterialRequestMaster.cmobjects.filter(pk=instance.indent_item.indent.material_request.pk)
            #             .values('id',
            #                     'request_code',
            #                     'date'
            #             ))
            _details = get_details_from_instance(instance.indent_item.indent.material_request)
        return _details

    def get_wbs_indirect_cost_name(self, instance):
        return instance.wbs_indirect_cost.indirect_cost if instance.wbs_indirect_cost else None


class PurchaseOrderTermsAndConditionsSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseOrderTermsAndConditions Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseOrderTermsAndConditions
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderTaxDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseOrderTaxDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseOrderTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseOrderExpenseDetails Serializer
    """
    id = serializers.IntegerField(required=False)
    expense_details = serializers.SerializerMethodField()

    def get_expense_details(self, instance):
        details = None
        if instance.expense_head:
            # details = ExpenseHead.cmobjects.filter(pk=instance.expense_head_id).values()
            details = get_details_from_instance(instance.expense_head)
        return details

    class Meta:
        model = PurchaseOrderExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderDeliveryLocationSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseOrderDeliveryLocation Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseOrderDeliveryLocation
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderStagesSerializer(serializers.ModelSerializer):
    """
    Procurement PurchaseOrderStages Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PurchaseOrderStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseOrderSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseOrder Serializer
    """
    items = PurchaseOrderItemsSerializer(many=True, source="procurement_purchase_order_item")
    payment_schedule = PurchaseOrderPaymentScheduleSerializer(many=True,
                                                              source="procurement_purchase_order_payment_schedule")
    terms_and_conditions = PurchaseOrderTermsAndConditionsSerializer(many=True,
                                                                     source="procurement_terms_and_conditions")
    attachments = PurchaseOrderAttachmentsSerializer(many=True, required=False,
                                                     source="procurement_purchase_order_attachment")
    po_tax = PurchaseOrderTaxDetailsSerializer(many=True, required=False, source="procurement_po_tax")
    po_expense = PurchaseOrderExpenseDetailsSerializer(many=True, required=False, source="procurement_po_expense")
    po_delivery_loc = PurchaseOrderDeliveryLocationSerializer(many=True, required=False,
                                                              source="procurement_po_delivery_loc")
    stages = PurchaseOrderStagesSerializer(many=True, required=False, source="procurement_purchase_order_stages")

    # custom method for view
    organization_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()
    project_attachment = serializers.SerializerMethodField()
    project_company_name = serializers.SerializerMethodField()
    purchase_order_delivery_location_details = serializers.SerializerMethodField()
    grn_quantity = serializers.SerializerMethodField()
    indent_details = serializers.SerializerMethodField()
    grn_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    billing_site_details = serializers.SerializerMethodField()
    delivery_site_details = serializers.SerializerMethodField()
    total_payment_schedule = serializers.SerializerMethodField()

    multi_stage_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    linked_docs = serializers.SerializerMethodField()
    # approved by
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    indents_details = serializers.SerializerMethodField()

    def get_linked_docs(self, instance):
        return parent_fields(instance,'procurement_purchase_order_item')
    def get_indents_details(self, instance):
        _details = []
        if instance.indents:
            _obj = instance.indents.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = Indent.cmobjects.filter(pk__in=(_ids)).values()
        return _details
    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, type="dict")

    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_name = projectdata.value if projectdata else ''
        # return project_name
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.project.project_name if instance.project else ''

    def get_project_code(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_id').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_code = projectdata.value if projectdata else ''
        # return project_code
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.project.project_code if instance.project else ''
    
    def get_project_attachment(self, instance):
            return str(instance.project.attachment) if instance.project else ''
    def get_project_company_name(self, instance):
        return (str(instance.project.company.name) if instance.project.company else '') if instance.project else ''

    def get_purchase_order_delivery_location_details(self, instance):
        # purchaseorderdeliverylocation = PurchaseOrderDeliveryLocation.cmobjects.filter(purchase_order=instanse).values()
        purchaseorderdeliverylocation = instance.procurement_po_delivery_loc.all().values()
        return purchaseorderdeliverylocation

    # def get_po_quantity(self, instanse):
    #     po_quantity = (
    #                 PurchaseOrderItems.cmobjects.filter(purchase_order=instanse)
    #                 .aggregate(total_quantity=Sum('quantity')))
    #     return po_quantity['total_quantity'] if po_quantity['total_quantity'] else 0.0

    def get_grn_quantity(self, instanse):
        grn_quantity = (
            GRNItems.cmobjects.filter(grn__is_deleted=False,purchase_order_item__purchase_order=instanse)
            .aggregate(total_quantity=Sum(F('quantity'))))
        return grn_quantity['total_quantity'] if grn_quantity['total_quantity'] else 0.0

    def get_indent_details(self, instance):
        record = None
        if instance.indent:
            # record = Indent.cmobjects.filter(pk=instance.indent.id).values()
            record = get_details_from_instance(instance.indent)
        return record

    def get_grn_details(self, instance):
        record = None
        if instance.id:
            # record = GRN.cmobjects.filter(purchase_order_id=instance.id).values()
            record = instance.procurement_grn_purchase_orders.all().values()
        return record

    def get_site_details(self, instance):
        record = None
        if instance.site:
            # record = SiteMaster.cmobjects.filter(pk=instance.site.id).values()
            record = get_details_from_instance(instance.site)
        return record

    def get_store_details(self, instance):
        record = None
        if instance.store:
            # record = StoreMaster.cmobjects.filter(pk=instance.store.id).values()
            record = get_details_from_instance(instance.store)
        return record

    def get_billing_site_details(self, instance):
        _details = []
        if instance.billing_site:
            # _obj = SiteMaster.cmobjects.filter(pk=instance.billing_site_id)
            billing_list = [instance.billing_site]
            try:
                serializer = SiteMasterSerializer(billing_list, many=True)
                _details = serializer.data
            except Exception as e:
                print('ERROR', e)
        return _details

    def get_total_payment_schedule(self, instance):
        qty = 0.
        percent = 0.
        if instance:
            # pops = PurchaseOrderPaymentSchedule.cmobjects.filter(purchase_order=instance, )
            pops = instance.procurement_purchase_order_payment_schedule.all()
            for i in pops:
                qty += i.amount
                percent += i.percent
        return {'qty': qty, 'percent': percent}
    def get_delivery_site_details(self, instance):
        _details = []
        if instance.delivery_site:
            # _obj = SiteMaster.cmobjects.filter(pk=instance.delivery_site_id)
            delivery_site_list = [instance.delivery_site]
            try:
                serializer = SiteMasterSerializer(delivery_site_list, many=True)
                _details = serializer.data
            except Exception as e:
                print('ERROR', e)
        return _details
    def get_organization_details(self, instance):
        # key_list = Organization.objects.filter(pk=instance.organization_id).values()
        # _key_list = list(key_list)
        # city_id = _key_list[0]["org_city_id"] if _key_list and _key_list[0] else 0
        # state_id = _key_list[0]["org_state_id"] if _key_list and _key_list[0] else 0
        # country_id = _key_list[0]["org_country_id"] if _key_list and _key_list[0] else 0

        # city_obj = City.objects.filter(pk=int(city_id)).first()
        # city_name = city_obj.name if city_obj else None

        # state_obj = State.objects.filter(pk=int(state_id)).first()
        # state_name = state_obj.name if state_obj else None

        # country_obj = Country.objects.filter(pk=int(country_id)).first()
        # country_name = country_obj.name if country_obj else None
        # address = f"{city_name} {state_name} {country_name}"
        # _key_list.append({'organization_address': address})
        # return _key_list
        
        key_list = get_details_from_instance(instance.organization)
        city_name = None
        if instance.organization and instance.organization.org_city:
            city_obj = get_details_from_instance(instance.organization.org_city, type="dict")
            city_name = city_obj['name'] if city_obj else None
        state_name = None
        if instance.organization and instance.organization.org_state:
            state_obj = get_details_from_instance(instance.organization.org_state, type="dict")
            state_name = state_obj['name'] if state_obj else None
        country_name = None
        if instance.organization and instance.organization.org_country:
            country_obj = get_details_from_instance(instance.organization.org_country, type="dict")
            country_name = country_obj['name'] if country_obj else None

        address = f"{city_name} {state_name} {country_name}"
        key_list.append({'organization_address': address})
        return key_list

    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            # _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details

    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            # _details = PmsUser.objects.filter(pk=instance.checked_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            # _details = PmsUser.objects.filter(pk=instance.cancelled_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details

    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            # _details = PmsUser.objects.filter(pk=instance.close_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details

    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            # _details = PmsUser.objects.filter(pk=instance.approved_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details

    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            # _details = PmsUser.objects.filter(pk=instance.rejected_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details



    ######
    def calculate_totals(self, instance):
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_item_expense_expense_amount = 0
        instance.total_item_expense_sgst_amount = 0
        instance.total_item_expense_cgst_amount = 0
        instance.total_item_expense_igst_amount = 0
        instance.total_item_expense_utgst_amount = 0
        instance.total_item_expense_cess_amount = 0
        instance.total_item_expense_total_expense_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.procurement_purchase_order_item.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount
                # for item_exp in item.procurement_purchase_order_item_expense.filter(is_deleted=False):
                #     if not item_exp.is_deleted:
                #         if item_exp.included:
                #             if item_exp.add:
                #                 instance.total_item_expense_expense_amount = instance.total_item_expense_expense_amount+item_exp.expense_amount
                #                 instance.total_item_expense_sgst_amount = instance.total_item_expense_sgst_amount+item_exp.sgst_amount
                #                 instance.total_item_expense_cgst_amount = instance.total_item_expense_cgst_amount+item_exp.cgst_amount
                #                 instance.total_item_expense_igst_amount = instance.total_item_expense_igst_amount+item_exp.igst_amount
                #                 instance.total_item_expense_utgst_amount = instance.total_item_expense_utgst_amount+item_exp.utgst_amount
                #                 instance.total_item_expense_cess_amount = instance.total_item_expense_cess_amount+item_exp.cess_amount
                #                 instance.total_item_expense_total_expense_amount = instance.total_item_expense_total_expense_amount+item_exp.total_expense_amount
                #             else:
                #                 instance.total_item_expense_expense_amount = instance.total_item_expense_expense_amount-item_exp.expense_amount
                #                 instance.total_item_expense_sgst_amount = instance.total_item_expense_sgst_amount-item_exp.sgst_amount
                #                 instance.total_item_expense_cgst_amount = instance.total_item_expense_cgst_amount-item_exp.cgst_amount
                #                 instance.total_item_expense_igst_amount = instance.total_item_expense_igst_amount-item_exp.igst_amount
                #                 instance.total_item_expense_utgst_amount = instance.total_item_expense_utgst_amount-item_exp.utgst_amount
                #                 instance.total_item_expense_cess_amount = instance.total_item_expense_cess_amount-item_exp.cess_amount
                #                 instance.total_item_expense_total_expense_amount = instance.total_item_expense_total_expense_amount-item_exp.total_expense_amount

        for item in instance.procurement_po_expense.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

        for item in instance.procurement_po_tax.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_item_expense_total_expense_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.save()


    @transaction.atomic
    def create(self, validated_data):
        po_item_count = 0
        for item in validated_data['procurement_purchase_order_item']:
            po_item_count += 10
            item['sap_item_no'] = po_item_count
        sap_code = validated_data.get('sap_code', None)
        sap_resp = validated_data.get('sap_resp', {})
        if not sap_code:
            sap_code,sap_resp = generate_sap_po(validated_data)
        # sap_code,sap_resp = generate_sap_po(validated_data)
        items_data = validated_data.pop('procurement_purchase_order_item')
        requested_attachment = validated_data.pop('procurement_purchase_order_attachment', [])
        payment_schedule = validated_data.pop('procurement_purchase_order_payment_schedule', [])
        terms_and_conditions = validated_data.pop('procurement_terms_and_conditions', [])
        tax_data = validated_data.pop('procurement_po_tax', [])
        expense_data = validated_data.pop('procurement_po_expense', [])
        loc_data = validated_data.pop('procurement_po_delivery_loc', [])
        stages_data = validated_data.pop('procurement_purchase_order_stages', [])
        vendor_state = validated_data.get('vendor_state', [])
        site = validated_data.get('site', [])
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])

        purchase_order = PurchaseOrder.objects.create(**validated_data)

        purchase_order.sap_code = sap_code
        purchase_order.sap_resp = sap_resp
        current_user = purchase_order.created_by if purchase_order.created_by else None
        purchase_order.indents.set(indents) if indents else None
        purchase_order.material_requests.set(material_requests) if material_requests else None

        for requested_attachment_data in requested_attachment:
            try:
                attachment = PurchaseOrderAttachments.objects.create(
                    organization=purchase_order.organization,
                    purchase_order=purchase_order,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")

        for stage_data in stages_data:
            PurchaseOrderStages.objects.create(purchase_order=purchase_order, created_by=current_user, **stage_data)

        for terms_and_conditions_data in terms_and_conditions:
            PurchaseOrderTermsAndConditions.objects.create(purchase_order=purchase_order,created_by=current_user,**terms_and_conditions_data)

        for po_delivery_loc_data in loc_data:
            PurchaseOrderDeliveryLocation.objects.create(purchase_order=purchase_order,created_by=current_user,**po_delivery_loc_data)

        for purchase_order_item_data in items_data:
            notes_data = purchase_order_item_data.pop('notes', [])
            # item_expenses_data = purchase_order_item_data.pop('expenses', [])
            item = PurchaseOrderItems.objects.create(purchase_order=purchase_order,created_by=current_user,**purchase_order_item_data)

            for note_data in notes_data:
                PurchaseOrderItemsNotes.objects.create(purchase_order_item=item,created_by=current_user,**note_data)
            # for item_expense_data in item_expenses_data:
            #     PurchaseOrderItemsExpenseDetails.objects.create(purchase_order_item=item,created_by=current_user,**item_expense_data)
        self.calculate_totals(purchase_order)

        for po_expense_data in expense_data:
            PurchaseOrderExpenseDetails.objects.create(purchase_order=purchase_order,created_by=current_user,**po_expense_data)
        self.calculate_totals(purchase_order)

        for po_tax_data in tax_data:
            PurchaseOrderTaxDetails.objects.create(purchase_order=purchase_order,created_by=current_user,**po_tax_data)
        self.calculate_totals(purchase_order)

        for payment_schedule_item in payment_schedule:
            payment_schedule_attachments = payment_schedule_item.pop('procurement_po_payment_schedule_attachments', [])
            _obj =PurchaseOrderPaymentSchedule.objects.create(purchase_order=purchase_order, created_by=current_user, **payment_schedule_item)
            # add po payment schedule attachments
            for requested_attachment_data in payment_schedule_attachments:
                _ = PurchaseOrderPaymentScheduleAttachments.objects.create(
                    organization=purchase_order.organization,
                    created_by=current_user,
                    master=_obj,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                )

        self.calculate_totals(purchase_order)
        purchase_order.save()
        # REQUESTED FEATURE
        if purchase_order.indent and purchase_order.quotation:
            Indent.cmobjects.filter(pk=purchase_order.indent.id).update(selected_quotation=purchase_order.quotation.id)
        if purchase_order.rfq_vendor and purchase_order.quotation:
            RFQVendors.cmobjects.filter(pk=purchase_order.rfq_vendor.id).update(selected_quotation=purchase_order.quotation.id)
        handle_belsio_purchase_order(instance=purchase_order,created=True)
        return purchase_order


    @transaction.atomic
    def update(self, instance, validated_data):
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])


        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        if indents:
            instance.indents.clear()
            instance.indents.set(indents)
        if material_requests:
            instance.material_requests.clear()
            instance.material_requests.set(material_requests)    
        purchase_order_item_data = validated_data.get('procurement_purchase_order_item', [])
        existing_items = instance.procurement_purchase_order_item.filter(is_deleted=False)
        payment_schedule = validated_data.pop('procurement_purchase_order_payment_schedule', [])
        existing_payment_schedule = instance.procurement_purchase_order_payment_schedule.filter(is_deleted=False)
        attachments_data = validated_data.get('procurement_purchase_order_attachment', [])
        existing_attachments = instance.procurement_purchase_order_attachment.filter(is_deleted=False)
        terms_and_conditions = validated_data.pop('procurement_terms_and_conditions', [])
        existing_terms_and_conditions = instance.procurement_terms_and_conditions.filter(is_deleted=False)
        tax_data = validated_data.pop('procurement_po_tax', [])
        existing_tax = instance.procurement_po_tax.filter(is_deleted=False)
        expense_data = validated_data.pop('procurement_po_expense', [])
        existing_expense = instance.procurement_po_expense.filter(is_deleted=False)
        loc_data = validated_data.pop('procurement_po_delivery_loc', [])
        existing_loc_items = instance.procurement_po_delivery_loc.filter(is_deleted=False)
        stages_data = validated_data.get('procurement_purchase_order_stages', [])
        existing_stages = instance.procurement_purchase_order_stages.filter(is_deleted=False)

        vendor_state = validated_data.get('vendor_state', [])
        site = validated_data.get('site', [])

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                existing_attachment = PurchaseOrderAttachments.objects.create(
                    organization=instance.organization,
                    purchase_order=instance,
                    attachment=temp_attach_data,
                    file_data="",
                    mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        for item_data in stages_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_stages if item.id == item_id), None)

            if not existing_item:
                existing_item = PurchaseOrderStages.objects.create(purchase_order=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_stages:
            if existing_item.id not in [item_data.get('id') for item_data in stages_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for po_delivery_loc_data in loc_data:
            loc_id = po_delivery_loc_data.get('id')
            po_delivery_loc_data['created_by'] = current_user
            existing_loc_item = next((item for item in existing_loc_items if item.id == loc_id), None)

            if not existing_loc_item:
                #create
                existing_loc_item = PurchaseOrderDeliveryLocation.objects.create(purchase_order=instance, **po_delivery_loc_data)
            else:
                for field in existing_loc_item._meta.fields:
                    field_name = field.name
                    if field_name in po_delivery_loc_data:
                        setattr(existing_loc_item, field_name, po_delivery_loc_data[field_name])
                setattr(existing_loc_item, 'updated_by', current_user)
                existing_loc_item.save()

        for existing_loc_item in existing_loc_items:
            if existing_loc_item.id not in [data.get('id') for data in loc_data]:
                setattr(existing_loc_item, 'is_deleted', True)
                setattr(existing_loc_item, 'updated_by', current_user)
                existing_loc_item.save()

        for terms_and_conditions_data_item in terms_and_conditions:
            terms_and_conditions_id = terms_and_conditions_data_item.get('id')
            existing_terms_and_conditions_item = next(
                (item for item in existing_terms_and_conditions if item.id == terms_and_conditions_id), None)

            if not existing_terms_and_conditions_item:
                [terms_and_conditions_data_item.pop(k, None) for k in ('organization', 'updated_by', 'id',)]
                existing_terms_and_conditions_item = PurchaseOrderTermsAndConditions.objects.create(
                    purchase_order=instance,
                    organization=instance.organization,
                    created_by=current_user,
                    **terms_and_conditions_data_item
                )
            else:
                for field in existing_terms_and_conditions_item._meta.fields:
                    field_name = field.name
                    if field_name in terms_and_conditions_data_item:
                        setattr(existing_terms_and_conditions_item, field_name, terms_and_conditions_data_item[field_name])
                setattr(existing_terms_and_conditions_item, 'updated_by', current_user)
                existing_terms_and_conditions_item.save()

        for existing_terms_and_conditions_item in existing_terms_and_conditions:
            if existing_terms_and_conditions_item.id not in [item.get('id') for item in terms_and_conditions]:
                setattr(existing_terms_and_conditions_item, 'is_deleted', True)
                setattr(existing_terms_and_conditions_item, 'updated_by', instance.updated_by)
                existing_terms_and_conditions_item.save()

        for item_data in purchase_order_item_data:
            item_id = item_data.get('id')
            item_data['created_by'] = current_user
            notes_data = item_data.pop('notes', [])
            # item_expenses_data = item_data.pop('expenses', [])
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                existing_item = PurchaseOrderItems.objects.create(purchase_order=instance, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
            
            existing_notes = existing_item.procurement_purchase_order_item_note.filter(is_deleted=False)
            for note_data in notes_data:
                note_id = note_data.get('id')
                existing_note = next((note for note in existing_notes if note.id == note_id), None)
                if not existing_note:
                    existing_note = PurchaseOrderItemsNotes.objects.create(
                        purchase_order_item=existing_item,
                        created_by=current_user,
                        **note_data
                    )
                else:
                    for note_field in existing_note._meta.fields:
                        note_field_name = note_field.name
                        if note_field_name in note_data:
                            setattr(existing_note, note_field_name, note_data[note_field_name])
                    setattr(existing_note, 'updated_by', current_user)
                    existing_note.save()

            for existing_note in existing_notes:
                if existing_note.id not in [note_data.get('id') for note_data in notes_data]:
                    setattr(existing_note, 'is_deleted', True)
                    setattr(existing_note, 'updated_by', current_user)
                    existing_note.save()

            # existing_item_expenses = existing_item.procurement_purchase_order_item_expense.filter(is_deleted=False)
            # for item_expense_data in item_expenses_data:
            #     expense_id = item_expense_data.get('id')
            #     existing_item_expense = next((expense for expense in existing_item_expenses if expense.id == expense_id), None)
            #     if not existing_item_expense:
            #         existing_item_expense = PurchaseOrderItemsExpenseDetails.objects.create(
            #             purchase_order_item=existing_item,
            #             created_by=current_user,
            #             **item_expense_data
            #         )
            #     else:
            #         for expense_field in existing_item_expense._meta.fields:
            #             expense_field_name = expense_field.name
            #             if expense_field_name in item_expense_data:
            #                 setattr(existing_item_expense, expense_field_name, item_expense_data[expense_field_name])
            #         setattr(existing_item_expense, 'updated_by', current_user)
            #         existing_item_expense.save()

            # for existing_item_expense in existing_item_expenses:
            #     if existing_item_expense.id not in [item_expense_data.get('id') for item_expense_data in item_expenses_data]:
            #         setattr(existing_item_expense, 'is_deleted', True)
            #         setattr(existing_item_expense, 'updated_by', current_user)
            #         existing_item_expense.save()
        
        for existing_item in existing_items:
            if existing_item.id not in [item_data.get('id') for item_data in purchase_order_item_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        self.calculate_totals(instance)

        for expense_data_item in expense_data:
            expense_id = expense_data_item.get('id')
            existing_expense_item = next(
                (item for item in existing_expense if item.id == expense_id), None)

            if not existing_expense_item:
                existing_expense_item = PurchaseOrderExpenseDetails.objects.create(
                    purchase_order=instance,
                    created_by=current_user,
                    **expense_data_item
                )
            else:
                for field in existing_expense_item._meta.fields:
                    field_name = field.name
                    if field_name in expense_data_item:
                        setattr(existing_expense_item, field_name, expense_data_item[field_name])
                setattr(existing_expense_item, 'updated_by', current_user)
                existing_expense_item.save()

        for existing_expense_item in existing_expense:
            if existing_expense_item.id not in [item.get('id') for item in expense_data]:
                setattr(existing_expense_item, 'is_deleted', True)
                setattr(existing_expense_item, 'updated_by', current_user)
                existing_expense_item.save()
        self.calculate_totals(instance)

        for tax_data_item in tax_data:
            tax_id = tax_data_item.get('id')
            existing_tax_item = next(
                (item for item in existing_tax if item.id == tax_id), None)
            if not existing_tax_item:
                existing_tax_item = PurchaseOrderTaxDetails.objects.create(
                    purchase_order=instance,
                    created_by=current_user,
                    **tax_data_item
                )
            else:
                for field in existing_tax_item._meta.fields:
                    field_name = field.name
                    if field_name in tax_data_item:
                        setattr(existing_tax_item, field_name, tax_data_item[field_name])
                setattr(existing_tax_item, 'updated_by', current_user)
                existing_tax_item.save()

        for existing_tax_item in existing_tax:
            if existing_tax_item.id not in [item.get('id') for item in tax_data]:
                setattr(existing_tax_item, 'is_deleted', True)
                setattr(existing_tax_item, 'updated_by', current_user)
                existing_tax_item.save()
        self.calculate_totals(instance)
        
        for payment_schedule_item in payment_schedule:
            payment_schedule_id = payment_schedule_item.get('id')
            payment_schedule_attachments = payment_schedule_item.pop('procurement_po_payment_schedule_attachments', [])
            existing_payment_schedule_item = next(
                (item for item in existing_payment_schedule if item.id == payment_schedule_id), None)
            if not existing_payment_schedule_item:
                [payment_schedule_item.pop(k, None) for k in ('organization', 'updated_by', 'id',)]
                existing_payment_schedule_item = PurchaseOrderPaymentSchedule.objects.create(
                    organization=instance.organization,
                    purchase_order=instance,
                    created_by=current_user,
                    **payment_schedule_item
                )
            else:
                for field in existing_payment_schedule_item._meta.fields:
                    field_name = field.name
                    if field_name in payment_schedule_item:
                        setattr(existing_payment_schedule_item, field_name, payment_schedule_item[field_name])
                setattr(existing_payment_schedule_item, 'updated_by', current_user)
                existing_payment_schedule_item.save()

            # add payment_schedule_attachments
            for requested_attachment_data in payment_schedule_attachments:
                _ = PurchaseOrderPaymentScheduleAttachments.objects.create(
                    organization=instance.organization,
                    created_by=current_user,
                    master=existing_payment_schedule_item,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                )
            #####

        for existing_payment_schedule_item in existing_payment_schedule:
            if existing_payment_schedule_item.id not in [item.get('id') for item in payment_schedule]:
                setattr(existing_payment_schedule_item, 'is_deleted', True)
                setattr(existing_payment_schedule_item, 'updated_by', current_user)
                existing_payment_schedule_item.save()

        self.calculate_totals(instance)
        # handle_belsio_purchase_order(instance=instance,created=False)
        instance.save()
        return instance


    def to_representation(self, instance):
        representation = super().to_representation(instance)
        purchase_order_items_data = representation.pop('items', [])
        representation['items'] = purchase_order_items_data
        payment_schedule = representation.pop('payment_schedule', [])
        representation['payment_schedule'] = payment_schedule
        terms_and_conditions = representation.pop('terms_and_conditions', [])
        representation['terms_and_conditions'] = terms_and_conditions
        po_tax_data = representation.pop('po_tax', [])
        representation['po_tax'] = po_tax_data
        po_expense_data = representation.pop('po_expense', [])
        representation['po_expense'] = po_expense_data
        po_delivery_loc_data = representation.pop('po_delivery_loc', [])
        representation['po_delivery_loc'] = po_delivery_loc_data
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data
        stages_data = representation.pop('stages', [])
        representation['stages'] = stages_data


        # vendor = representation.pop("vendor")
        billing_site = representation.get("billing_site")
        if billing_site:
            try:
                site_instance = SiteMaster.objects.get(pk=billing_site)
                representation['billing_site'] = site_instance.site_name
            except SiteMaster.DoesNotExist:
                representation['billing_site'] = None

        delivery_site = representation.get("delivery_site")
        if delivery_site:
            try:
                site_instance = SiteMaster.objects.get(pk=delivery_site)
                representation['delivery_site'] = site_instance.site_name
            except SiteMaster.DoesNotExist:
                representation['delivery_site'] = None

        for item_data in purchase_order_items_data:
            notes_data = PurchaseOrderItemsNotes.cmobjects.filter(purchase_order_item=item_data['id'])
            item_data['notes'] = PurchaseOrderItemsNotesSerializer(notes_data, many=True).data

            # expenses_data = PurchaseOrderItemsExpenseDetails.cmobjects.filter(purchase_order_item=item_data['id'])
            # item_data['expenses'] = PurchaseOrderItemsExpenseDetailsSerializer(expenses_data, many=True).data

        return representation


    class Meta:
        model = PurchaseOrder
        fields = '__all__'


class GRNAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement GRNAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = GRNAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class GRNItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement GRNItems Serializer
    """
    id = serializers.IntegerField(required=False)


    ## custom method
    material_details = serializers.SerializerMethodField()
    material_type_details = serializers.SerializerMethodField()
    material_sub_type_details = serializers.SerializerMethodField()
    unit_of_mesurement_details = serializers.SerializerMethodField()
    hsn_details = serializers.SerializerMethodField()
    recieved_against_po = serializers.SerializerMethodField()



    class Meta:
        model = GRNItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.item:
                # details = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).first()
                # serializer = VendorMaterialMasterSerializer(details)
                serializer = VendorMaterialMasterSerializer(instance.item)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details

    def get_material_type_details(self, instance):
        item = instance.item if instance.item else None
        material_type = None
        if item and item.material_type:
            # material_type = MaterialType.cmobjects.filter(pk=item.material_type_id).values()
            material_type = get_details_from_instance(item.material_type)

        return material_type

    def get_material_sub_type_details(self, instance):
        sub_type_details = None
        item = instance.item if instance.item else None
        if item and item.material_sub_type:
            # sub_type_details = MaterialSubType.cmobjects.filter(pk=item.material_sub_type_id).values()
            sub_type_details = get_details_from_instance(item.material_sub_type)
        return sub_type_details

    def get_unit_of_mesurement_details(self, instance):
        unit_of_mesurement = instance.item.unit_of_mesurement if instance.item and instance.item.unit_of_mesurement else None
        # mesurement_details = UnitOfMesurement.cmobjects.filter(id=unit_of_mesurement_id).values()
        mesurement_details = get_details_from_instance(unit_of_mesurement)
        return mesurement_details

    def get_hsn_details(self, instance):
        hsn = None
        item = instance.item if instance.item else None
        # if item:
        #     vendormaterialmaster = VendorMaterialMaster.cmobjects.filter(pk=item.id).first()
        #     if vendormaterialmaster:
        #         hsn = HSNMaster.cmobjects.filter(pk=vendormaterialmaster.hsn_code_id).values()
        # return hsn
        if item and item.hsn_code:
            # vendormaterialmaster = VendorMaterialMaster.cmobjects.filter(pk=item.id).first()
            # if vendormaterialmaster:
            # hsn = HSNMaster.cmobjects.filter(pk=item.hsn_code).values()
            hsn = get_details_from_instance(item.hsn_code)
        return hsn

    def get_recieved_against_po(self, instance):
        total_quantity = 0
        purchase_order_item = instance.purchase_order_item.id if instance.purchase_order_item else None
        if purchase_order_item:
            total_quantity = GRNItems.cmobjects.filter(grn__is_deleted=False,purchase_order_item_id=purchase_order_item).exclude(pk=instance.id).aggregate(total_quantity=Sum(F('quantity')))['total_quantity']
        return total_quantity

class GRNItemsBatchSerializer(serializers.ModelSerializer):
    created_by_details = serializers.SerializerMethodField()

    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    class Meta:
        model = GRNItemsBatch
        fields = "__all__"
class GRNTaxDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement GRNTaxDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = GRNTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class GRNExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement GRNExpenseDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = GRNExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer



class GRNSerializer(serializers.ModelSerializer):
    """"
    Procurement GRN Serializer
    """
    grn_items = GRNItemsSerializer(many=True, source="procurement_grn_item")
    grn_tax = GRNTaxDetailsSerializer(many=True, required=False, source="procurement_grn_tax")
    grn_expense = GRNExpenseDetailsSerializer(many=True, required=False, source="procurement_grn_expense")
    attachments = GRNAttachmentsSerializer(many=True, required=False, source="procurement_grn_attachment")
    indent_no = serializers.SerializerMethodField()
    purchase_bill_done_qty = serializers.SerializerMethodField()
    qty_pending_for_pur = serializers.SerializerMethodField()
    purchase_order_details = serializers.SerializerMethodField()
    transporter_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    purchase_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()

    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    indents_details = serializers.SerializerMethodField()
    linked_docs = serializers.SerializerMethodField()
    company_data = serializers.SerializerMethodField()
    item_total_amount = serializers.SerializerMethodField()
    item_total_received_quantity = serializers.SerializerMethodField()
    item_total_return_quantity = serializers.SerializerMethodField()
    material_requests__request_code = serializers.SerializerMethodField()
    project__project_company_name = serializers.SerializerMethodField()
    project__attachment = serializers.SerializerMethodField()
    
    def get_project__project_company_name(self, instance):
        return (str(instance.project.company.name) if instance.project.company else '') if instance.project else ''
    
    def get_project__attachment(self, instance):
        # return (instance.project.attachment.url if instance.project.attachment else '') if instance.project else ''
        return str(instance.project.attachment) if instance.project else ''
    def get_material_requests__request_code(self, obj):
        
        # result =  MaterialRequestMasterItems.cmobjects.filter(
        #         procurement_grn_item_material_request_item__grn=obj,
        #         material_request__is_deleted=False
        #     ).order_by().values('procurement_grn_item_material_request_item__grn').annotate(
        #         value=GroupConcat('material_request__request_code', distinct=True)
        #     ).values('value')
        result = MaterialRequestMasterItems.cmobjects.filter(
            procurement_grn_item_material_request_item__grn=obj,
            material_request__is_deleted=False
        ).aggregate(
            value=GroupConcat('material_request__request_code', distinct=True)
        )
        
        return result['value'] if result['value'] else ''
    def get_linked_docs(self, instance):
        return parent_fields(instance,'procurement_grn_item')
    def get_item_total_amount(self, instance):
        return GRNItems.cmobjects.filter(grn_id=instance.id).values('grn').annotate(total=Sum('item_amount')).values('total')
    def get_item_total_received_quantity(self, instance):
        return GRNItems.cmobjects.filter(grn_id=instance.id).values('grn').annotate(total=Sum('received_quantity')).values('total')
    def get_item_total_return_quantity(self, instance):
        return GRNItems.cmobjects.filter(grn_id=instance.id).values('grn').annotate(total=Sum('return_quantity')).values('total')
    
    def get_company_data(self, instance):
        company_data = None
        if instance.project:
            company_data = get_company_data(instance.project.pk)
        return company_data

    def get_store_details(self, instance):
        details = []
        if instance.store:
            # details = StoreMaster.cmobjects.filter(pk=instance.store_id).values()
            details = get_details_from_instance(instance.store)
        return details

    def get_site_details(self, instance):
        details = []
        if instance.store and instance.store.site_id:
            # details = SiteMaster.cmobjects.filter(pk=instance.store.site_id).values()
            details = get_details_from_instance(instance.store.site)
        elif instance.site:
            # details = SiteMaster.cmobjects.filter(pk=instance.site_id).values()
            details = get_details_from_instance(instance.site)
        return details

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_name = projectdata.value if projectdata else ''
        # return project_name
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.project.project_name if instance.project else ''

    def get_project_code(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_id').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_code = projectdata.value if projectdata else ''
        # return project_code
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.project.project_code if instance.project else ''

    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            # _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,
            })
        return details
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            # _details = PmsUser.objects.filter(pk=instance.checked_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            # _details = PmsUser.objects.filter(pk=instance.cancelled_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            # _details = PmsUser.objects.filter(pk=instance.close_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,
            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            # _details = PmsUser.objects.filter(pk=instance.approved_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,
            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            # _details = PmsUser.objects.filter(pk=instance.rejected_by_id).values('first_name', 'last_name', 'email')
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,
            })
        return details

    def calculate_totals(self, instance):
        instance.total_po_pending_quantity = 0
        instance.total_challan_quantity = 0
        instance.total_received_quantity = 0
        instance.total_return_quantity = 0
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.procurement_grn_item.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_po_pending_quantity = instance.total_po_pending_quantity+item.po_pending_quantity
                instance.total_challan_quantity = instance.total_challan_quantity+item.challan_quantity
                instance.total_received_quantity = instance.total_received_quantity+item.received_quantity
                instance.total_return_quantity = instance.total_return_quantity+item.return_quantity
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount

        for item in instance.procurement_grn_expense.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

        for item in instance.procurement_grn_tax.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_grn_item')
        tax_data = validated_data.pop('procurement_grn_tax', [])
        expense_data = validated_data.pop('procurement_grn_expense', [])
        requested_attachment = validated_data.pop('procurement_grn_attachment', [])
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])


        grn = GRN.objects.create(**validated_data)
        # grn.request_code = generate_all_code(grn,['GRN'])

        current_user = grn.created_by if grn.created_by else None
        grn.indents.set(indents) if indents else None
        grn.material_requests.set(material_requests) if material_requests else None

        for requested_attachment_data in requested_attachment:
            try:
                GRNAttachments.objects.create(
                    organization=grn.organization,
                    grn=grn,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        for grn_item_data in items_data:
            GRNItems.objects.create(grn=grn,created_by=current_user,**grn_item_data)
        self.calculate_totals(grn)

        for grn_expense_data in expense_data:
            GRNExpenseDetails.objects.create(grn=grn,created_by=current_user,**grn_expense_data)
        self.calculate_totals(grn)

        for grn_tax_data in tax_data:
            GRNTaxDetails.objects.create(grn=grn,created_by=current_user,**grn_tax_data)
        self.calculate_totals(grn)
        grn.save()
        return grn

    @transaction.atomic
    def update(self, instance, validated_data):
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])


        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        if indents:
            instance.indents.clear()
            instance.indents.set(indents)
        if material_requests:
            instance.material_requests.clear()
            instance.material_requests.set(material_requests)    
        attachments_data = validated_data.get('procurement_grn_attachment', [])
        existing_attachments = instance.procurement_grn_attachment.filter(is_deleted=False)
        items_data = validated_data.get('procurement_grn_item', [])
        existing_items = instance.procurement_grn_item.filter(is_deleted=False)
        tax_data = validated_data.pop('procurement_grn_tax', [])
        existing_tax = instance.procurement_grn_tax.filter(is_deleted=False)
        expense_data = validated_data.pop('procurement_grn_expense', [])
        existing_expense = instance.procurement_grn_expense.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)

            if not existing_attachment:
                try:
                    existing_attachment = GRNAttachments.objects.create(
                        organization=instance.organization,
                        grn=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        for grn_item_data in items_data:
            item_id = grn_item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if not existing_item:
                existing_item = GRNItems.objects.create(grn=instance, created_by=current_user, **grn_item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in grn_item_data:
                        setattr(existing_item, field_name, grn_item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        self.calculate_totals(instance)

        for expense_data_item in expense_data:
            expense_id = expense_data_item.get('id')
            existing_expense_item = next(
                (item for item in existing_expense if item.id == expense_id), None)

            if not existing_expense_item:
                existing_expense_item = GRNExpenseDetails.objects.create(
                    grn=instance,
                    created_by=current_user,
                    **expense_data_item
                )
            else:
                for field in existing_expense_item._meta.fields:
                    field_name = field.name
                    if field_name in expense_data_item:
                        setattr(existing_expense_item, field_name, expense_data_item[field_name])
                setattr(existing_expense_item, 'updated_by', current_user)
                existing_expense_item.save()

        for existing_expense_item in existing_expense:
            if existing_expense_item.id not in [item.get('id') for item in expense_data]:
                setattr(existing_expense_item, 'is_deleted', True)
                setattr(existing_expense_item, 'updated_by', current_user)
                existing_expense_item.save()
        self.calculate_totals(instance)

        for tax_data_item in tax_data:
            tax_id = tax_data_item.get('id')
            existing_tax_item = next(
                (item for item in existing_tax if item.id == tax_id), None)
            if not existing_tax_item:
                existing_tax_item = GRNTaxDetails.objects.create(
                    grn=instance,
                    created_by=current_user,
                    **tax_data_item
                )
            else:
                for field in existing_tax_item._meta.fields:
                    field_name = field.name
                    if field_name in tax_data_item:
                        setattr(existing_tax_item, field_name, tax_data_item[field_name])
                setattr(existing_tax_item, 'updated_by', current_user)
                existing_tax_item.save()

        for existing_tax_item in existing_tax:
            if existing_tax_item.id not in [item.get('id') for item in tax_data]:
                setattr(existing_tax_item, 'is_deleted', True)
                setattr(existing_tax_item, 'updated_by', current_user)
                existing_tax_item.save()
        self.calculate_totals(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        grn_items_data = representation.pop('grn_items', [])
        representation['grn_items'] = grn_items_data
        grn_tax_data = representation.pop('grn_tax', [])
        representation['grn_tax'] = grn_tax_data
        grn_expense_data = representation.pop('grn_expense', [])
        representation['grn_expense'] = grn_expense_data
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data


        return representation

    class Meta:
        model = GRN
        fields = '__all__'

    def get_indent_no(self, instance):
        indent_no = ''
        if instance.purchase_order and instance.purchase_order.indent:
            indent_no = instance.purchase_order.indent.request_code
        return indent_no

    def get_purchase_bill_done_qty(self, instance):
        quantity = 0.0
        details = PurchaseItems.cmobjects.filter(grn_item__grn=instance).annotate(total_quantity=Sum('quantity')).values()
        if details:
            quantity = details[0]['total_quantity']
        return quantity

    def get_qty_pending_for_pur(self, instance):
        quantity = 0.0
        if instance.total_received_quantity:
            quantity = float(instance.total_received_quantity)-float(self.get_purchase_bill_done_qty(instance))
        return quantity

    def get_purchase_order_details(self, instance):
        purchaseorder = None
        if instance.purchase_order:
            # purchaseorder = PurchaseOrder.cmobjects.filter(pk=instance.purchase_order_id).values()
            purchaseorder = get_details_from_instance(instance.purchase_order)
        return purchaseorder

    def get_transporter_details(self, instance):
        _details = None
        try:
            if instance.transporter:
                data = get_vendor_data(instance.transporter)
                _details = {"transporter_id": instance.transporter.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details

    def get_vendor_details(self, instance):
        _details = None
        try:
            if instance.vendor:
                data = get_vendor_data(instance.vendor)
                _details = {"vendor_id": instance.vendor.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details
    def get_indents_details(self, instance):
        _details = []
        if instance.indents:
            _obj = instance.indents.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = Indent.cmobjects.filter(pk__in=(_ids)).values()
        return _details
    def get_purchase_details(self, instance):
        # _details = Purchase.cmobjects.filter(grn=instance).values()
        _details = instance.procurement_purchase_grn.all().values()
        return _details

class BillReceiveAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement GRNAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = BillReceiveAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class BillReceiveSerializer(serializers.ModelSerializer):
    """"
    Procurement BillReceive Serializer
    """
    attachments = BillReceiveAttachmentsSerializer(many=True, required=False,
                                           source="procurement_bill_receive_attachment")
    
    vendor_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    forward_to_user_details = serializers.SerializerMethodField()

    @transaction.atomic
    def create(self, validated_data):
        requested_attachment = validated_data.pop('procurement_bill_receive_attachment')
        bill_receive = BillReceive.objects.create(**validated_data)
        # bill_receive.request_code = generate_all_code(bill_receive,['BR'])

        current_user = bill_receive.created_by if bill_receive.created_by else None

        for requested_attachment_data in requested_attachment:
            try:
                BillReceiveAttachments.objects.create(
                    organization=bill_receive.organization,
                    bill_receive=bill_receive,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        bill_receive.save()
        return bill_receive

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_bill_receive_attachment', [])
        existing_attachments = instance.procurement_bill_receive_attachment.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)

            if not existing_attachment:
                try:
                    existing_attachment = BillReceiveAttachments.objects.create(
                        organization=instance.organization,
                        bill_receive=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data

        return representation


    def get_site_details(self, instance):
        site_name = None
        if instance.site_id:
            site_name=SiteMaster.cmobjects.filter(pk=instance.site_id).values()
        return site_name
    
    def get_forward_to_user_details(self, instance):
        forward_to_user_name = None
        if instance.forward_to_user_id:
            forward_to_user_name=PmsUser.objects.filter(pk=instance.forward_to_user_id).values()
        return forward_to_user_name

    def get_vendor_details(self, instance):
        vendor_name = None
        try:
            if instance.vendor_id:
                vendor_name=get_vendor_data(instance.vendor)
        except Exception as e:
            print('ERROR', e)
        return vendor_name

    class Meta:
        model = BillReceive
        fields = '__all__'


class GatePassAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement GatePassAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = GatePassAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class GatePassItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement GatePassItems Serializer
    """
    id = serializers.IntegerField(required=False)
    material_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()

    class Meta:
        model = GatePassItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_material_details(self, instance):
        return_details = []
        try:
            if instance.item and instance.item_id:
                details = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = [serializer.data]
        except Exception as e:
            print('ERROR', e)

        return return_details

    def get_plant_machinery_machine_details(self, instance):
        plant_machinery_machine = instance.plant_machinery_machine if instance.plant_machinery_machine else None
        plant_machinery_machine_details = None
        if plant_machinery_machine:
            plant_machinery_machine_details = PlantMachineryMachine.cmobjects.filter(pk=plant_machinery_machine.id).values()
        return plant_machinery_machine_details


class GatePassSerializer(serializers.ModelSerializer):
    """"
    Procurement GatePass Serializer
    """
    closed_status = serializers.SerializerMethodField()
    lab_report = serializers.SerializerMethodField()
    items = GatePassItemsSerializer(many=True, source="procurement_gate_pass_item")
    attachments = GatePassAttachmentsSerializer(many=True, required=False,
                                                source="procurement_gate_pass_attachment")

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_gate_pass_item')
        requested_attachment = validated_data.pop('procurement_gate_pass_attachment')
        gate_pass = GatePass.objects.create(**validated_data)
        # gate_pass.request_code = generate_all_code(gate_pass,['GP'])

        current_user = gate_pass.created_by if gate_pass.created_by else None

        for requested_attachment_data in requested_attachment:
            try:
                GatePassAttachments.objects.create(
                    organization=gate_pass.organization,
                    gate_pass=gate_pass,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        for gate_pass_item_data in items_data:

            GatePassItems.objects.create(gate_pass=gate_pass, created_by=current_user, **gate_pass_item_data)
        gate_pass.save()
        return gate_pass

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_gate_pass_attachment', [])
        existing_attachments = instance.procurement_gate_pass_attachment.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)

            if not existing_attachment:
                try:
                    existing_attachment = GatePassAttachments.objects.create(
                        organization=instance.organization,
                        gate_pass=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        items_data = validated_data.get('procurement_gate_pass_item', [])
        existing_items = instance.procurement_gate_pass_item.filter(is_deleted=False)

        for gate_pass_item_data in items_data:
            item_id = gate_pass_item_data.get('id')
            gate_pass_item_data['created_by'] = current_user
            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if not existing_item:
                existing_item = GatePassItems.objects.create(gate_pass=instance, **gate_pass_item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in gate_pass_item_data:
                        setattr(existing_item, field_name, gate_pass_item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        items = representation.pop('items', [])
        representation['items'] = items
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data

        return representation


    def get_closed_status(self, instance):
        resp = "unclosed"
        if instance.status in ['approved','rejected']:
            resp = "closed"
        return resp

    def get_lab_report(self, instance):
        resp = "pending"
        data = LabReportEntry.cmobjects.filter(gate_pass_no=instance).values()
        if len(data) > 0:
            resp = "already"
        return resp
    class Meta:
        model = GatePass
        fields = '__all__'


class MaterialIssueReturnItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement MaterialIssueReturnItems Serializer
    """
    id = serializers.IntegerField(required=False)

    ## custom method for views
    material_details = serializers.SerializerMethodField()
    unit_of_mesurement_details = serializers.SerializerMethodField()
    inventory_store = serializers.SerializerMethodField()


    class Meta:
        model = MaterialIssueReturnItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_material_details(self, instance):
        return_details = []
        try:
            if instance.item and instance.item_id:
                details = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = [serializer.data]
        except Exception as e:
            print('ERROR', e)

        return return_details

    def get_unit_of_mesurement_details(self, instance):
        unit_of_mesurement_id = instance.item.unit_of_mesurement_id if instance.item and instance.item.unit_of_mesurement else None
        mesurement_details = UnitOfMesurement.cmobjects.filter(id=unit_of_mesurement_id).values()
        return mesurement_details

    def get_inventory_store(self, instance):
        inventory = None
        requested_material = instance.item if instance.item else None
        material_issue_item = instance.material_issue_item if instance.material_issue_item else None
        if requested_material and material_issue_item:
            store = material_issue_item.material_issue.store
            if store:
                inventory = Inventory.cmobjects.filter(material=requested_material, store=store,
                                                       organization=instance.organization).values()
        return inventory



class MaterialIssueReturnAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement MaterialIssueReturnAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = MaterialIssueReturnAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialIssueReturnSerializer(serializers.ModelSerializer):
    """"
    Procurement MaterialIssueReturn Serializer
    """
    return_items = MaterialIssueReturnItemsSerializer(many=True, source="procurement_material_issue_return_items")
    attachments = MaterialIssueReturnAttachmentsSerializer(many=True, required=False,
                                                          source="procurement_material_issue_return_attachments")

    return_from_site_details = serializers.SerializerMethodField()
    @transaction.atomic
    def create(self, validated_data):
        requested_items_data = validated_data.pop('procurement_material_issue_return_items')
        requested_attachment = validated_data.pop('procurement_material_issue_return_attachments')
        site = validated_data.get('return_from_site')
        store = validated_data.get('return_to')

        material_issue_return = MaterialIssueReturn.objects.create(**validated_data)
        current_user = material_issue_return.created_by if material_issue_return.created_by else None

        for requested_attachment_data in requested_attachment:
            try:
                MaterialIssueReturnAttachments.objects.create(
                    organization=material_issue_return.organization,
                    material_issue_return=material_issue_return,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        for requested_item_data in requested_items_data:
            requested_item_data['created_by'] = current_user
            # update_fulfilled_percentage(material_request_item, quantity, 'revert')
            MaterialIssueReturnItems.objects.create(material_issue_return=material_issue_return,
                                                                 **requested_item_data)

        return material_issue_return

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_material_issue_return_attachments', [])
        requested_items_data = validated_data.get('procurement_material_issue_return_items', [])

        existing_attachments = instance.procurement_material_issue_return_attachments.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = MaterialIssueReturnAttachments.objects.create(
                        organization=instance.organization,
                        material_issue_return=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        existing_items = instance.procurement_material_issue_return_items.exclude(is_deleted=True)
        for requested_item_data in requested_items_data:

            item_id = requested_item_data.get('id')
            rate = requested_item_data.get('rate', None)
            quantity = float(requested_item_data.get('quantity'))
            item = requested_item_data.get('item')
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                requested_item_data['created_by'] = current_user
                existing_item = MaterialIssueReturnItems.objects.create(material_issue_return=instance,
                                                                        **requested_item_data)
                # update_fulfilled_percentage(existing_item.material_request_item, quantity, 'revert')

            else:
                # update_fulfilled_percentage(existing_item.material_request_item, existing_item.quantity, 'add')
                # update_fulfilled_percentage(existing_item.material_request_item, quantity, 'revert')
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in requested_item_data:
                        setattr(existing_item, field_name, requested_item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [item_data.get('id') for item_data in requested_items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        return_items = representation.pop('return_items', [])
        representation['return_items'] = return_items
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data

        return representation

    ### method fields
    def get_return_from_site_details(self, instance):
        _details = []
        if instance.return_from_site and instance.return_from_site_id:
            _details = SiteMaster.cmobjects.filter(pk=instance.return_from_site_id).values()
        return _details
    class Meta:
        model = MaterialIssueReturn
        fields = '__all__'


class SubletOrderSerializer(serializers.ModelSerializer):
    """"
    Procurement SubletOrder Serializer
    """

    representative_details =serializers.SerializerMethodField()

    def get_representative_details(self, instance):
        _details = []
        try:
            if instance.representative:
                data = get_vendor_data(instance.representative)
                _details = {"representative_id": instance.representative.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details

    class Meta:
        model = SubletOrder
        fields = '__all__'


class LabReportEntryItemSerializer(serializers.ModelSerializer):
    """"
    Procurement LabReportEntryItem Serializer
    """
    id = serializers.IntegerField(required=False)

    materials_details = serializers.SerializerMethodField()

    def get_materials_details(self, instance):
        material_detail = None
        if instance.item:
            material_detail = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).values()
        return material_detail


    class Meta:
        model = LabReportEntryItem
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class LabReportEntrySerializer(serializers.ModelSerializer):
    """"
    Procurement LabReportEntry Serializer
    """
    items = LabReportEntryItemSerializer(many=True, required=False,
                                               source='procurement_lab_report_entry_item_link')
    materials_details = serializers.SerializerMethodField()
    materials_groups_details = serializers.SerializerMethodField()
    gate_pass_details = serializers.SerializerMethodField()

    def get_materials_details(self, instance):
        _details = []
        if instance.materials:
            _obj = instance.materials.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = VendorMaterialMaster.cmobjects.filter(pk__in=(_ids)).values()
        return _details

    def get_materials_groups_details(self, instance):
        _details = []
        if instance.materials_groups:
            _obj = instance.materials_groups.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = MaterialType.cmobjects.filter(pk__in=(_ids)).values()
        return _details

    def get_gate_pass_details(self, instance):
        gate_pass_detail = []
        if instance.gate_pass_no_id:
            gate_pass_detail.append(GatePass.cmobjects.filter(pk=int(instance.gate_pass_no_id)).values())
        return gate_pass_detail

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_lab_report_entry_item_link', [])
        materials_groups = validated_data.pop('materials_groups', [])
        materials = validated_data.pop('materials', [])

        instance = LabReportEntry.objects.create(**validated_data)

        # Direct assignment to the forward side of a many-to-many set is prohibited.
        instance.materials_groups.set(materials_groups) if materials_groups else None
        instance.materials.set(materials) if materials else None

        # instance.request_code = generate_all_code(instance,['LRE'])

        current_user = instance.created_by if instance.created_by else None

        for item_data in items_data:
            LabReportEntryItem.objects.create(lab_report_entry=instance,
                                                    created_by=current_user, **item_data)

        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        materials_groups = validated_data.pop('materials_groups', [])
        materials = validated_data.pop('materials', [])
        items_data = validated_data.pop('procurement_lab_report_entry_item_link', [])

        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        instance.materials_groups.clear()
        instance.materials_groups.set(materials_groups)

        instance.materials.clear()
        instance.materials.set(materials)


        existing_items = instance.procurement_lab_report_entry_item_link.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                LabReportEntryItem.objects.create(created_by=current_user,
                                                        lab_report_entry=instance, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        items_data = representation.pop('items', [])
        representation['items'] = items_data
        return representation

    class Meta:
        model = LabReportEntry
        fields = '__all__'


class ItemStockJVFReceiveIssueItemSerializer(serializers.ModelSerializer):
    """"
    Procurement ItemStockJVFReceiveItem Serializer
    """
    id = serializers.IntegerField(required=False)

    item_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()

    class Meta:
        model = ItemStockJVFReceiveIssueItem
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


    def get_uom_details(self, instance):
        if instance.item and instance.item.unit_of_mesurement and instance.item.unit_of_mesurement_id:
            return (UnitOfMesurement.cmobjects.filter(pk=instance.item.unit_of_mesurement_id)
                    .values('id', 'formal_name', 'symbol', 'decimal_places', 'formula_for_qty_calculation'))
        else:
            return None

    def get_item_details(self, instance):
        item_detail = []
        if instance.item:
            item_detail.append(VendorMaterialMaster.cmobjects.filter(pk=int(instance.item.id)).values())
        return item_detail

    def get_store_details(self, instance):
        _details = []
        _temp = []
        if instance.store:
            _details = StoreMaster.cmobjects.filter(pk=instance.store_id).values()
        return _details

    def get_site_details(self, instance):
        ''' get site from store '''
        _temp = []
        if instance.store and instance.store.site_id:
            _temp = SiteMaster.cmobjects.filter(pk=instance.store.site_id).values()
        return _temp



class ItemStockJVSerializer(serializers.ModelSerializer):
    """"
    Procurement ItemStockJVFReceiveItem Serializer
    """
    issue_items = ItemStockJVFReceiveIssueItemSerializer(many=True, required=False)
    receive_items = ItemStockJVFReceiveIssueItemSerializer(many=True, required=False)

    @transaction.atomic
    def create(self, validated_data):
        issue_items_data = validated_data.pop('issue_items', [])
        receive_items_data = validated_data.pop('receive_items', [])
        item_stock_jv = ItemStockJV.objects.create(**validated_data)

        current_user = item_stock_jv.created_by if item_stock_jv.created_by else None
        
        ######## validation for issue item and received items
        issue_items_received_items_validation(issue_items_data, receive_items_data)
        ########
        for issue_item_data in issue_items_data:
            issue_item = ItemStockJVFReceiveIssueItem.objects.create(
                item_stock_jv=item_stock_jv,
                created_by=current_user,
                **issue_item_data)

        for receive_item_data in receive_items_data:
            receive_item = ItemStockJVFReceiveIssueItem.objects.create(
                item_stock_jv=item_stock_jv,
                created_by=current_user,
                **receive_item_data)

        return item_stock_jv

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        issue_items_data = validated_data.get('issue_items', [])
        receive_items_data = validated_data.get('receive_items', [])
        ######## validation for issue item and received items
        issue_items_received_items_validation(issue_items_data, receive_items_data)
        ########
        existing_issue_items = instance.procurement_item_stock_jv_item.filter(stock_type='issue', is_deleted=False)
        existing_receive_items = instance.procurement_item_stock_jv_item.filter(stock_type='receive', is_deleted=False)
        # Issue Item Update
        for issue_item_data in issue_items_data:
            issue_item_id = issue_item_data.get('id')
            new_quantity = issue_item_data.get('quantity')
            existing_issue_item = next((item for item in existing_issue_items if item.id == issue_item_id), None)

            if not existing_issue_item:
                existing_issue_item = ItemStockJVFReceiveIssueItem.objects.create(
                    item_stock_jv=instance,
                    created_by=current_user,
                    **issue_item_data)
            else:
                for key, value in issue_item_data.items():
                    setattr(existing_issue_item, key, value)
                setattr(existing_issue_item, 'updated_by', current_user)
                existing_issue_item.save()

        for existing_issue_item in existing_issue_items:
            if existing_issue_item.id not in [data.get('id') for data in issue_items_data]:
                setattr(existing_issue_item, 'is_deleted', True)
                setattr(existing_issue_item, 'updated_by', current_user)
                existing_issue_item.save()

        # Received item Update
        for receive_item_data in receive_items_data:
            receive_item_id = receive_item_data.get('id')
            new_quantity = receive_item_data.get('quantity')
            existing_receive_item = next((item for item in existing_receive_items if item.id == receive_item_id), None)

            if not existing_receive_item:
                existing_receive_item = ItemStockJVFReceiveIssueItem.objects.create(
                    item_stock_jv=instance,
                    created_by=current_user,
                    **receive_item_data)
            else:
                for key, value in receive_item_data.items():
                    setattr(existing_receive_item, key, value)
                setattr(existing_receive_item, 'updated_by', current_user)
                existing_receive_item.save()

        for existing_receive_item in existing_receive_items:
            if existing_receive_item.id not in [data.get('id') for data in receive_items_data]:
                setattr(existing_receive_item, 'is_deleted', True)
                setattr(existing_receive_item, 'updated_by', current_user)
                existing_receive_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        issue_items = instance.procurement_item_stock_jv_item.filter(stock_type='issue')
        receive_items = instance.procurement_item_stock_jv_item.filter(stock_type='receive')

        representation['issue_items'] = ItemStockJVFReceiveIssueItemSerializer(issue_items, many=True).data
        representation['receive_items'] = ItemStockJVFReceiveIssueItemSerializer(receive_items, many=True).data

        return representation

    class Meta:
        model = ItemStockJV
        fields = '__all__'


class LogBookAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement LogBookAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = LogBookAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class LogBookSerializer(serializers.ModelSerializer):
    """
    Procurement LogBookAttachments Serializer
    """
    attachments = LogBookAttachmentsSerializer(many=True, required=False, source='procurement_log_book_attachments')

    plant_machinery_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    class Meta:
        model = LogBook
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        attachments = validated_data.pop('procurement_log_book_attachments')
        log_book = LogBook.objects.create(**validated_data)

        current_user = log_book.created_by if log_book.created_by else None

        for requested_attachment_data in attachments:
            try:
                LogBookAttachments.objects.create(
                    organization=log_book.organization,
                    log_book=log_book,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        return log_book

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_log_book_attachments', [])

        existing_attachments = instance.procurement_log_book_attachments.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = LogBookAttachments.objects.create(
                        organization=instance.organization,
                        log_book=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        attachments_data = representation.pop('attachments', [])
        representation['attachments'] = attachments_data

        return representation

    def get_plant_machinery_details(self, instance):
        _details = []
        try:
            if instance.plantmachinery:
                data = get_plant_machinery_data(instance.plantmachinery.pk)
                _details = {'id': instance.plantmachinery.pk, 'data': data}
        except Exception as e:
            print('ERROR', e)
        return _details
    def get_store_details(self, instance):
        _details = []
        if instance.store:
            _details = StoreMaster.cmobjects.filter(pk=instance.store.id).values()
        return _details
    def get_site_details(self, instance):
        _details = []
        if instance.store.site_id:
            _details = SiteMaster.cmobjects.filter(pk=instance.store.site_id).values()
        return _details

class GroupTaskMasterAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement GroupTaskMasterAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = GroupTaskMasterAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class GroupTaskMasterSerializer(serializers.ModelSerializer):
    """
    Procurement GroupTaskMasterAttachments Serializer
    """
    attachments = GroupTaskMasterAttachmentsSerializer(many=True, required=False,
                                                       source='procurement_group_task_master_attachments')

    @transaction.atomic
    def create(self, validated_data):
        attachments = validated_data.pop('procurement_group_task_master_attachments')
        group_task_master = GroupTaskMaster.objects.create(**validated_data)

        current_user = group_task_master.created_by if group_task_master.created_by else None

        for requested_attachment_data in attachments:
            try:
                GroupTaskMasterAttachments.objects.create(
                    organization=group_task_master.organization,
                    group_task_master=group_task_master,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        return group_task_master

    class Meta:
        model = GroupTaskMaster
        fields = '__all__'

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_group_task_master_attachments', [])

        existing_attachments = instance.procurement_group_task_master_attachments.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = GroupTaskMasterAttachments.objects.create(
                        organization=instance.organization,
                        group_task_master=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        attachments_data = representation.pop('attachments', [])
        representation['attachments'] = attachments_data

        return representation
    

class WorkIndentAttachmentsSerializer(serializers.ModelSerializer):
    """
    WorkIndentAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkIndentAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkIndentWorkDetailSerializer(serializers.ModelSerializer):
    """
    WorkIndentWorkDetail Serializer
    """
    work = serializers.PrimaryKeyRelatedField(queryset=GroupTaskMaster.objects.filter(is_deleted=False))
    id = serializers.IntegerField(required=False)
    work_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()

    def get_work_details(self, instance):
        details = []
        if instance.work:
            details = GroupTaskMaster.cmobjects.filter(pk=instance.work_id).values()
        return details

    def get_uom_details(self, instance):
        details = []
        if instance.uom:
            details = UnitOfMesurement.cmobjects.filter(pk=instance.uom_id).values()
        return details

    class Meta:
        model = WorkIndentWorkDetail
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkIndentSerializer(serializers.ModelSerializer):
    """
    WorkIndent Serializer
    """
    attachments = WorkIndentAttachmentsSerializer(many=True, required=False,
                                                  source='procurement_work_indent_attachments')
    work_details = WorkIndentWorkDetailSerializer(many=True, required=False, source='procurement_work_indent_details')
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    
    def calculate_totals(self, instance):
        instance.total_quantity = 0
        for item in instance.procurement_work_indent_details.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_quantity = instance.total_quantity+item.quantity
        instance.save()
    
    @transaction.atomic
    def create(self, validated_data):
        attachments = validated_data.pop('procurement_work_indent_attachments', [])
        details = validated_data.pop('procurement_work_indent_details', [])

        work_indent = WorkIndent.objects.create(**validated_data)
        # work_indent.request_code = generate_all_code(work_indent,['WI'])

        current_user = work_indent.created_by if work_indent.created_by else None

        for requested_attachment_data in attachments:
            try:
                WorkIndentAttachments.objects.create(
                    organization=work_indent.organization,
                    work_indent=work_indent,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")

        for detail_data in details:
            WorkIndentWorkDetail.objects.create(work_indent=work_indent,created_by=current_user, **detail_data)
        
        self.calculate_totals(work_indent)
        work_indent.save()
        return work_indent

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_work_indent_attachments', [])
        details_data = validated_data.get('procurement_work_indent_details', [])

        existing_attachments = instance.procurement_work_indent_attachments.filter(is_deleted=False)
        existing_details = instance.procurement_work_indent_details.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = WorkIndentAttachments.objects.create(
                        organization=instance.organization,
                        work_indent=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        for detail_data in details_data:
            detail_id = detail_data.get('id')
            detail_data['created_by'] = current_user
            print("detail_id >>>>>>>>>>>>>>", detail_id)
            existing_detail = next((detail for detail in existing_details if detail.id == detail_id), None)
            if not existing_detail:
                WorkIndentWorkDetail.objects.create(work_indent=instance, **detail_data)
            else:
                for field in existing_detail._meta.fields:
                    field_name = field.name
                    if field_name in detail_data:
                        setattr(existing_detail, field_name, detail_data[field_name])
                setattr(existing_detail, 'updated_by', current_user)
                existing_detail.save()

        for existing_work in existing_details:
            if existing_work.id not in [data.get('id') for data in details_data]:
                setattr(existing_work, 'is_deleted', True)
                setattr(existing_work, 'updated_by', current_user)
                existing_work.save()
        
        self.calculate_totals(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        attachments_data = representation.pop('attachments', [])
        details_data = representation.pop('work_details', [])

        representation['attachments'] = attachments_data
        representation['work_details'] = details_data

        return representation

    def get_site_details(self, instance):
        details = []
        if instance.site:
            details = SiteMaster.cmobjects.filter(pk=instance.site_id).values()
        return details

    def get_store_details(self, instance):
        details = []
        if instance.store:
            details = StoreMaster.cmobjects.filter(pk=instance.store_id).values()
        return details

    class Meta:
        model = WorkIndent
        fields = '__all__'


class WorkOrderAttachmentsSerializer(serializers.ModelSerializer):
    """
    WorkOrderAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkOrderAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderLaborSerializer(serializers.ModelSerializer):
    """
    WorkOrderLabor Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkOrderLabor
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderHireContractSerializer(serializers.ModelSerializer):
    """
    WorkOrderHireContract Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkOrderHireContract
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderTaxSerializer(serializers.ModelSerializer):
    """
    WorkOrderTax Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkOrderTax
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderDetailSerializer(serializers.ModelSerializer):
    """
    WorkOrderDetail Serializer
    """
    task = serializers.PrimaryKeyRelatedField(queryset=GroupTaskMaster.objects.filter(is_deleted=False), allow_null=True)
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkOrderDetail
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderRequirementSerializer(serializers.ModelSerializer):
    """
    WorkOrderRequirement Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkOrderRequirement
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderTermsAndConditionsSerializer(serializers.ModelSerializer):
    """
    WorkOrderTermsAndConditions Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkOrderTermsAndConditions
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderMaterialSerializer(serializers.ModelSerializer):
    """
    WorkOrderMaterial Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WorkOrderMaterial
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderStagesSerializer(serializers.ModelSerializer):
    """
    Procurement WorkOrderStages Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = WorkOrderStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WorkOrderSerializer(serializers.ModelSerializer):
    """
    WorkOrder Serializer
    """
    attachments = WorkOrderAttachmentsSerializer(many=True, required=False, source='procurement_work_order_attachments')
    labors = WorkOrderLaborSerializer(many=True, required=False, source='procurement_work_order_labors')
    details = WorkOrderDetailSerializer(many=True, required=False, source='procurement_work_order_details')
    requirements = WorkOrderRequirementSerializer(many=True, required=False, source='procurement_work_order_requirements')
    terms_conditions = WorkOrderTermsAndConditionsSerializer(many=True, required=False, source='procurement_work_order_tcs')
    materials = WorkOrderMaterialSerializer(many=True, required=False, source='procurement_work_order_materials')
    hire_contracts = WorkOrderHireContractSerializer(many=True, required=False, source='procurement_work_order_hire_contracts')
    taxes = WorkOrderTaxSerializer(many=True, required=False, source='procurement_work_order_taxes')
    stages = WorkOrderStagesSerializer(many=True, required=False, source="procurement_work_order_stages")
    party_details = serializers.SerializerMethodField()
    multi_stage_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()

    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)


    def get_party_details(self, instance):
        vendor_name = None
        try:
            if instance.party_id:
                vendor_name=get_vendor_data(instance.party)
        except Exception as e:
            print('ERROR', e)
        return vendor_name

    def get_site_details(self, instance):
        details = []
        if instance.site:
            details = SiteMaster.cmobjects.filter(pk=instance.site_id).values()
        return details

    def calculate_totals(self, instance):
        instance.total_labor_quantity = 0
        instance.total_labor_amount = 0
        instance.total_labor_discount = 0
        instance.total_labor_taxable_amount = 0
        instance.total_labor_cgst_amount = 0
        instance.total_labor_sgst_amount = 0
        instance.total_labor_igst_amount = 0
        instance.total_labor_net_amount = 0
        instance.total_material_quantity = 0
        instance.total_material_amount = 0
        instance.total_material_discount = 0
        instance.total_material_taxable_amount = 0
        instance.total_material_cgst_amount = 0
        instance.total_material_sgst_amount = 0
        instance.total_material_igst_amount = 0
        instance.total_material_net_amount = 0
        instance.total_work_detail_quantity = 0
        instance.total_work_detail_amount = 0
        instance.total_work_detail_discount = 0
        instance.total_work_detail_taxable_amount = 0
        instance.total_work_detail_cgst_amount = 0
        instance.total_work_detail_sgst_amount = 0
        instance.total_work_detail_igst_amount = 0
        instance.total_work_detail_net_amount = 0
        for item in instance.procurement_work_order_labors.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_labor_quantity = instance.total_labor_quantity+item.quantity
                instance.total_labor_amount = instance.total_labor_amount+item.amount
                instance.total_labor_discount = instance.total_labor_discount+item.discount
                instance.total_labor_taxable_amount = instance.total_labor_taxable_amount+item.taxable_amount
                instance.total_labor_cgst_amount = instance.total_labor_cgst_amount+item.cgst_amount
                instance.total_labor_sgst_amount = instance.total_labor_sgst_amount+item.sgst_amount
                instance.total_labor_igst_amount = instance.total_labor_igst_amount+item.igst_amount
                instance.total_labor_net_amount = instance.total_labor_net_amount+item.net_amount
        
        for item in instance.procurement_work_order_materials.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_material_quantity = instance.total_material_quantity+item.quantity
                instance.total_material_amount = instance.total_material_amount+item.amount
                instance.total_material_discount = instance.total_material_discount+item.discount
                instance.total_material_taxable_amount = instance.total_material_taxable_amount+item.taxable_amount
                instance.total_material_cgst_amount = instance.total_material_cgst_amount+item.cgst_amount
                instance.total_material_sgst_amount = instance.total_material_sgst_amount+item.sgst_amount
                instance.total_material_igst_amount = instance.total_material_igst_amount+item.igst_amount
                instance.total_material_net_amount = instance.total_material_net_amount+item.net_amount
        
        for item in instance.procurement_work_order_details.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_work_detail_quantity = instance.total_work_detail_quantity+item.quantity
                instance.total_work_detail_amount = instance.total_work_detail_amount+item.amount
                instance.total_work_detail_discount = instance.total_work_detail_discount+item.discount
                instance.total_work_detail_taxable_amount = instance.total_work_detail_taxable_amount+item.taxable_amount
                instance.total_work_detail_cgst_amount = instance.total_work_detail_cgst_amount+item.cgst_amount
                instance.total_work_detail_sgst_amount = instance.total_work_detail_sgst_amount+item.sgst_amount
                instance.total_work_detail_igst_amount = instance.total_work_detail_igst_amount+item.igst_amount
                instance.total_work_detail_net_amount = instance.total_work_detail_net_amount+item.net_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        attachments = validated_data.pop('procurement_work_order_attachments', [])
        labors = validated_data.pop('procurement_work_order_labors', [])
        details = validated_data.pop('procurement_work_order_details', [])
        requirements = validated_data.pop('procurement_work_order_requirements', [])
        tcs = validated_data.pop('procurement_work_order_tcs', [])
        materials = validated_data.pop('procurement_work_order_materials', [])
        hire_contracts = validated_data.pop('procurement_work_order_hire_contracts', [])
        taxes = validated_data.pop('procurement_work_order_taxes', [])
        stages_data = validated_data.pop('procurement_work_order_stages', [])

        work_order = WorkOrder.objects.create(**validated_data)
        # work_order.request_code = generate_all_code(work_order,['WO'])

        
        current_user = work_order.created_by if work_order.created_by else None

        for requested_attachment_data in attachments:
            try:
                WorkOrderAttachments.objects.create(
                    organization=work_order.organization,
                    work_order=work_order,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user,
                )
            except Exception as e:
                print(f"exception: {e}")
        
        for stage_data in stages_data:
            WorkOrderStages.objects.create(work_order=work_order, created_by=current_user, **stage_data)

        for labor_data in labors:
            WorkOrderLabor.objects.create(work_order=work_order, created_by=current_user, **labor_data)

        for detail_data in details:
            WorkOrderDetail.objects.create(work_order=work_order, created_by=current_user, **detail_data)

        for requirement_data in requirements:
            WorkOrderRequirement.objects.create(work_order=work_order, created_by=current_user, **requirement_data)

        for tc_data in tcs:
            WorkOrderTermsAndConditions.objects.create(work_order=work_order, created_by=current_user, **tc_data)

        for material_data in materials:
            WorkOrderMaterial.objects.create(work_order=work_order, created_by=current_user, **material_data)

        for hire_contracts_data in hire_contracts:
            WorkOrderHireContract.objects.create(work_order=work_order, created_by=current_user, **hire_contracts_data)

        for taxes_data in taxes:
            WorkOrderTax.objects.create(work_order=work_order, created_by=current_user, **taxes_data)

        self.calculate_totals(work_order)
        work_order.save()
        return work_order

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_work_order_attachments', [])
        existing_attachments = instance.procurement_work_order_attachments.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = WorkOrderAttachments.objects.create(
                        organization=instance.organization,
                        work_order=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        edit_child_model(instance,validated_data,'WorkOrderStages','procurement_work_order_stages','work_order')
        edit_child_model(instance,validated_data,'WorkOrderLabor','procurement_work_order_labors','work_order')
        edit_child_model(instance,validated_data,'WorkOrderDetail','procurement_work_order_details','work_order')
        edit_child_model(instance,validated_data,'WorkOrderRequirement','procurement_work_order_requirements','work_order')
        edit_child_model(instance,validated_data,'WorkOrderTermsAndConditions','procurement_work_order_tcs','work_order')
        edit_child_model(instance,validated_data,'WorkOrderMaterial','procurement_work_order_materials','work_order')
        edit_child_model(instance,validated_data,'WorkOrderHireContract','procurement_work_order_hire_contracts','work_order')
        edit_child_model(instance,validated_data,'WorkOrderTax','procurement_work_order_taxes','work_order')

        self.calculate_totals(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        attachments_data = representation.pop('attachments', [])
        representation['attachments'] = attachments_data
        labors_data = representation.pop('labors', [])
        representation['labors'] = labors_data
        details_data = representation.pop('details', [])
        representation['details'] = details_data
        requirements_data = representation.pop('requirements', [])
        representation['requirements'] = requirements_data
        tcs_data = representation.pop('terms_conditions', [])
        representation['terms_conditions'] = tcs_data
        materials_data = representation.pop('materials', [])
        representation['materials'] = materials_data
        hire_contracts_data = representation.pop('hire_contracts', [])
        representation['hire_contracts'] = hire_contracts_data
        taxes_data = representation.pop('taxes', [])
        representation['taxes'] = taxes_data
        stages_data = representation.pop('stages', [])
        representation['stages'] = stages_data

        return representation

    class Meta:
        model = WorkOrder
        fields = '__all__'


class FabricationWorkAttachmentsSerializer(serializers.ModelSerializer):
    """
    FabricationWorkAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = FabricationWorkAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class FabricationWorkLaborSerializer(serializers.ModelSerializer):
    """
    FabricationWorkLabor Serializer
    """
    id = serializers.IntegerField(required=False)

    # category detail
    category_details = serializers.SerializerMethodField()

    class Meta:
        model = FabricationWorkLabor
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_category_details(self, instance):
        _details = []
        if instance.category and instance.category_id:
            _details = LabourMaster.cmobjects.filter(pk=instance.category_id).values()
        return _details


class FabricationWorkFinishGoodsSerializer(serializers.ModelSerializer):
    """
    FabricationWorkFinishGoods Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = FabricationWorkFinishGoods
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class FabricationWorkRawMaterialSerializer(serializers.ModelSerializer):
    """
    FabricationWorkRawMaterial Serializer
    """
    id = serializers.IntegerField(required=False)

    materials_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()

    class Meta:
        model = FabricationWorkRawMaterial
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_uom_details(self, instance):
        if instance.material and instance.material.unit_of_mesurement and instance.material.unit_of_mesurement_id:
            return (UnitOfMesurement.cmobjects.filter(pk=instance.material.unit_of_mesurement_id)
                    .values('id', 'formal_name', 'symbol', 'decimal_places', 'formula_for_qty_calculation'))
        else:
            return None

    def get_materials_details(self, instance):
        material_detail = []
        if instance.material:
            material_detail.append(VendorMaterialMaster.cmobjects.filter(pk=int(instance.material.id)).values())
        return material_detail



class FabricationWorkSerializer(serializers.ModelSerializer):
    """
    FabricationWork Serializer
    """
    attachments = FabricationWorkAttachmentsSerializer(many=True, required=False,
                                                      source='procurement_fabrication_work_attachments')
    labors = FabricationWorkLaborSerializer(many=True, required=False,
                                            source='procurement_fabrication_work_labors')
    finish_goods = FabricationWorkFinishGoodsSerializer(many=True, required=False,
                                                        source='procurement_fabrication_work_finish_goods')
    raw_materials = FabricationWorkRawMaterialSerializer(many=True, required=False,
                                                         source='procurement_fabrication_work_raw_materials')

    ## details : site, store, contractor, work_order
    store_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    contractor_details = serializers.SerializerMethodField()
    work_order_details = serializers.SerializerMethodField()
    def calculate_totals_fabrication_work(self, instance):
        instance.total_raw_material_quantity = 0
        instance.total_raw_material_weight = 0
        instance.total_labor_amount = 0
        instance.total_finish_goods_quantity = 0
        instance.total_finish_goods_weight = 0
        instance.total_finish_goods_amount = 0
        for item in instance.procurement_fabrication_work_raw_materials.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_raw_material_quantity = instance.total_raw_material_quantity+item.quantity
                instance.total_raw_material_weight = instance.total_raw_material_weight+item.weight
        for item in instance.procurement_fabrication_work_labors.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_labor_amount = instance.total_labor_amount+item.amount
        for item in instance.procurement_fabrication_work_finish_goods.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_finish_goods_quantity = instance.total_finish_goods_quantity+item.quantity
                instance.total_finish_goods_weight = instance.total_finish_goods_weight+item.weight
                instance.total_finish_goods_amount = instance.total_finish_goods_amount+item.amount

    @transaction.atomic
    def create(self, validated_data):
        attachments = validated_data.pop('procurement_fabrication_work_attachments', [])
        labors = validated_data.pop('procurement_fabrication_work_labors', [])
        finish_goods = validated_data.pop('procurement_fabrication_work_finish_goods', [])
        raw_materials = validated_data.pop('procurement_fabrication_work_raw_materials', [])

        fabrication_work = FabricationWork.objects.create(**validated_data)
        # fabrication_work.request_code = generate_all_code(fabrication_work,['FW'])

        current_user = fabrication_work.created_by if fabrication_work.created_by else None

        for requested_attachment_data in attachments:
            try:
                FabricationWorkAttachments.objects.create(
                    organization=fabrication_work.organization,
                    fabrication_work=fabrication_work,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user,
                )
            except Exception as e:
                print(f"exception: {e}")

        for labor_data in labors:
            FabricationWorkLabor.objects.create(fabrication_work=fabrication_work, created_by=current_user, **labor_data)

        for finish_goods_data in finish_goods:
            FabricationWorkFinishGoods.objects.create(fabrication_work=fabrication_work, created_by=current_user, **finish_goods_data)

        for raw_material_data in raw_materials:
            FabricationWorkRawMaterial.objects.create(fabrication_work=fabrication_work, created_by=current_user, **raw_material_data)

        self.calculate_totals_fabrication_work(fabrication_work)
        fabrication_work.save()
        return fabrication_work

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.get('procurement_fabrication_work_attachments', [])
        labors_data = validated_data.get('procurement_fabrication_work_labors', [])
        finish_goods_datas = validated_data.get('procurement_fabrication_work_finish_goods', [])
        raw_materials_data = validated_data.get('procurement_fabrication_work_raw_materials', [])

        existing_attachments = instance.procurement_fabrication_work_attachments.filter(is_deleted=False)
        existing_labors = instance.procurement_fabrication_work_labors.filter(is_deleted=False)
        existing_finish_goods = instance.procurement_fabrication_work_finish_goods.filter(is_deleted=False)
        existing_raw_materials = instance.procurement_fabrication_work_raw_materials.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id', None)
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = FabricationWorkAttachments.objects.create(
                        organization=instance.organization,
                        fabrication_work=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        for labor_data in labors_data:
            labor_id = labor_data.get('id', None)
            labor_data['created_by']=current_user
            existing_labor = next((labor for labor in existing_labors if labor.id == labor_id), None)
            if not existing_labor:
                FabricationWorkLabor.objects.create(fabrication_work=instance, **labor_data)
            else:
                for field in existing_labor._meta.fields:
                    field_name = field.name
                    if field_name in labor_data:
                        setattr(existing_labor, field_name, labor_data[field_name])
                setattr(existing_labor, 'updated_by', current_user)
                existing_labor.save()

        for finish_goods_data in finish_goods_datas:
            finish_goods_id = finish_goods_data.get('id', None)
            finish_goods_data['created_by']=current_user
            existing_finish_good = next(
                (finish_good for finish_good in existing_finish_goods if finish_good.id == finish_goods_id), None)
            if not existing_finish_good:
                FabricationWorkFinishGoods.objects.create(fabrication_work=instance, **finish_goods_data)
            else:
                for field in existing_finish_good._meta.fields:
                    field_name = field.name
                    if field_name in finish_goods_data:
                        setattr(existing_finish_good, field_name, finish_goods_data[field_name])
                setattr(existing_finish_good, 'updated_by', current_user)
                existing_finish_good.save()

        for raw_material_data in raw_materials_data:
            raw_material_id = raw_material_data.get('id', None)
            raw_material_data['created_by']=current_user
            existing_raw_material = next(
                (raw_material for raw_material in existing_raw_materials if raw_material.id == raw_material_id), None)
            if not existing_raw_material:
                FabricationWorkRawMaterial.objects.create(fabrication_work=instance, **raw_material_data)
            else:
                for field in existing_raw_material._meta.fields:
                    field_name = field.name
                    if field_name in raw_material_data:
                        setattr(existing_raw_material, field_name, raw_material_data[field_name])
                setattr(existing_raw_material, 'updated_by', current_user)
                existing_raw_material.save()

        for existing_labor in existing_labors:
            if existing_labor.id not in [data.get('id') for data in labors_data]:
                setattr(existing_labor, 'is_deleted', True)
                setattr(existing_labor, 'updated_by', instance.updated_by)
                existing_labor.save()

        for existing_finish_good in existing_finish_goods:
            print("finish_goods_data >>>>> ", finish_goods_data)
            if existing_finish_good.id not in [data.get('id') for data in finish_goods_datas]:
                setattr(existing_finish_good, 'is_deleted', True)
                setattr(existing_finish_good, 'updated_by', instance.updated_by)
                existing_finish_good.save()

        for existing_raw_material in existing_raw_materials:
            print("raw_materials_data >>>>> ", raw_materials_data)
            if existing_raw_material.id not in [data.get('id') for data in raw_materials_data]:
                setattr(existing_raw_material, 'is_deleted', True)
                setattr(existing_raw_material, 'updated_by', instance.updated_by)
                existing_raw_material.save()

        self.calculate_totals_fabrication_work(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        attachments_data = representation.pop('attachments', [])
        labors_data = representation.pop('labors', [])
        finish_goods_data = representation.pop('finish_goods', [])
        raw_materials_data = representation.pop('raw_materials', [])

        representation['attachments'] = attachments_data
        representation['labors'] = labors_data
        representation['finish_goods'] = finish_goods_data
        representation['raw_materials'] = raw_materials_data

        return representation

    def get_store_details(self, instance):
        _details = []
        if instance.store:
            _details = StoreMaster.cmobjects.filter(pk=instance.store_id).values()
        return _details

    def get_site_details(self, instance):
        _temp = []
        if instance.site and instance.site_id:
            _temp = SiteMaster.cmobjects.filter(pk=instance.site_id).values()
        return _temp

    def get_contractor_details(self, instance):
        _details = []
        try:
            if instance.contractor and instance.contractor_id:
                data = get_vendor_data(instance.contractor)
                _details = {"contractor_id": instance.contractor.pk, "data": data}
        except Exception as e:
            print('ERROR ', e)
        return _details

    def get_work_order_details(self, instance):
        _details = []
        if instance.work_order:
            _details = (WorkOrder.cmobjects.filter(pk=instance.work_order_id)
                        .values('id', 'request_code', 'wo_no'))
        return _details

    class Meta:
        model = FabricationWork
        fields = '__all__'
        read_only_fields = ['amount']


class TransportationRateItemsSerializer(serializers.ModelSerializer):
    """
    TransportationRateItems Serializer
    """
    id = serializers.IntegerField(required=False)
    item_detail = serializers.SerializerMethodField()
    uom_detail = serializers.SerializerMethodField()
    item_group_detail = serializers.SerializerMethodField()
    item_sub_group_detail = serializers.SerializerMethodField()


    def get_item_detail(self, instance):
        item_detail = []
        if instance.item:
            item_detail.append(VendorMaterialMaster.cmobjects.filter(pk=int(instance.item.id)).values())
        return item_detail

    def get_uom_detail(self, instance):
        uom_detail = []
        if instance.item and instance.item.unit_of_mesurement_id:
            uom_detail = UnitOfMesurement.cmobjects.filter(pk=instance.item.unit_of_mesurement_id).values()
            if uom_detail:
                return uom_detail
        return uom_detail

    def get_item_group_detail(self, instance):
        _item_group_detail = None
        if instance.item and instance.item.material_type and instance.item.material_type_id:
            _item_group_detail=MaterialType.cmobjects.filter(pk=instance.item.material_type_id).values()
        return _item_group_detail

    def get_item_sub_group_detail(self, instance):
        _item_sub_group_detail = None
        if instance.item and instance.item.material_sub_type:
            _item_sub_group_detail=MaterialSubType.cmobjects.filter(pk=instance.item.material_sub_type_id).values()
        return _item_sub_group_detail

    class Meta:
        model = TransportationRateItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TransportationRateSerializer(serializers.ModelSerializer):
    """
    TransportationRate Serializer
    """
    subcontractor_detail = serializers.SerializerMethodField()
    id = serializers.IntegerField(required=False)
    items = TransportationRateItemsSerializer(many=True, required=False,
                                              source='procurement_transportation_rate_items')

    def get_subcontractor_detail(self, instance):
        subcontractor_detail = {}
        try:
            if instance.sub_contractor:
                if instance.sub_contractor.id:
                    data = get_vendor_data(instance.sub_contractor)
                    vendor_name = data.get('vendor_name', None)
                    subcontractor_detail = {"sub_contractor_id": instance.sub_contractor.id,
                                            "sub_contractor_name": vendor_name}
        except Exception as e:
            print('ERROR', e)
        return subcontractor_detail

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_transportation_rate_items', [])
        transportation_rate = TransportationRate.objects.create(**validated_data)

        current_user = transportation_rate.created_by if transportation_rate.created_by else None

        for item_data in items_data:
            TransportationRateItems.objects.create(transportation_rate=transportation_rate, created_by=current_user, **item_data)

        return transportation_rate

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.get('procurement_transportation_rate_items', [])
        existing_items = instance.procurement_transportation_rate_items.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            item_data['created_by'] = current_user
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                TransportationRateItems.objects.create(transportation_rate=instance, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        items_data = representation.pop('items', [])
        representation['items'] = items_data
        return representation

    class Meta:
        model = TransportationRate
        fields = '__all__'


class RackSettingSerializer(serializers.ModelSerializer):
    """
    RackSetting Serializer
    """

    ## custom method
    item_detail = serializers.SerializerMethodField()
    rack_detail = serializers.SerializerMethodField()
    location_detail = serializers.SerializerMethodField()

    class Meta:
        model = RackSetting
        fields = '__all__'

    def get_item_detail(self, instance):
        item_detail = []
        if instance.item:
            for i in instance.item.filter(is_deleted=False):
                if i.id:
                    item_detail.append(VendorMaterialMaster.cmobjects.filter(pk=int(i.id)).values())
        return item_detail

    def get_rack_detail(self, instance):
        rack_detail = []
        if instance.rack and instance.rack_id:
            rack_detail = StoreSection.cmobjects.filter(pk=instance.rack_id).values()
        return rack_detail

    def get_location_detail(self, instance):
        location_detail = []
        if instance.location and instance.location_id:
            location_detail = StoreMaster.cmobjects.filter(pk=instance.location_id).values()
        return location_detail

class MaterialWastageAttachmentsSerializer(serializers.ModelSerializer):
    """
    MaterialWastageAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = MaterialWastageAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialWastageItemsSerializer(serializers.ModelSerializer):
    """
    MaterialWastageItems Serializer
    """
    id = serializers.IntegerField(required=False)
    item = serializers.PrimaryKeyRelatedField(queryset=VendorMaterialMaster.objects.filter(is_deleted=False))

    material_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()


    def get_uom_details(self, instance):
        if instance.item and instance.item.unit_of_mesurement and instance.item.unit_of_mesurement_id:
            return (UnitOfMesurement.cmobjects.filter(pk=instance.item.unit_of_mesurement_id)
                    .values('id', 'formal_name', 'symbol', 'decimal_places', 'formula_for_qty_calculation'))
        else:
            return None

    def get_material_details(self, instance):
        return_details = []
        try:
            if instance.item and instance.item_id:
                details = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = [[serializer.data]]
        except Exception as e:
            print('ERROR', e)

        return return_details

    class Meta:
        model = MaterialWastageItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialWastageSerializer(serializers.ModelSerializer):
    """
    MaterialWastage Serializer
    """
    items = MaterialWastageItemsSerializer(many=True, required=False,
                                           source='procurement_material_wastage_items')
    attachments = MaterialWastageAttachmentsSerializer(many=True, required=False,
                                                       source='procurement_material_wastage_attachments')

    store_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_material_wastage_items', [])
        attachments = validated_data.pop('procurement_material_wastage_attachments', [])
        material_wastage = MaterialWastage.objects.create(**validated_data)
        current_user = material_wastage.created_by if material_wastage.created_by else None
        for requested_attachment_data in attachments:
            try:
                MaterialWastageAttachments.objects.create(
                    organization=material_wastage.organization,
                    material_wastage=material_wastage,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )
            except Exception as e:
                print(f"exception: {e}")

        for item_data in items_data:
            wastage_item = MaterialWastageItems.objects.create(material_wastage=material_wastage, created_by=current_user, **item_data)
            # update_material_wastage_inventory(material_wastage, wastage_item, 'add')
        return material_wastage

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.get('procurement_material_wastage_items', [])
        attachments_data = validated_data.get('procurement_material_wastage_attachments', [])

        existing_items = instance.procurement_material_wastage_items.exclude(is_deleted=True)
        existing_attachments = instance.procurement_material_wastage_attachments.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = MaterialWastageAttachments.objects.create(
                        organization=instance.organization,
                        material_wastage=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        for item_data in items_data:
            item_id = item_data.get('id')
            new_quantity = item_data.get('quantity')
            item_data['created_by'] = current_user
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                new_item = MaterialWastageItems.objects.create(material_wastage=instance, **item_data)
                # update_material_wastage_inventory(instance, new_item, 'add')
            else:
                update = False
                if existing_item.quantity != new_quantity:
                    update = True
                    # update_material_wastage_inventory(instance, existing_item, 'revert')
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
                # if update:
                    # update_material_wastage_inventory(instance, existing_item, 'add')

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                # update_material_wastage_inventory(instance, existing_item, 'revert')
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance._old_instance_items = existing_items
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        items_data = representation.pop('items', [])
        attachments_data = representation.pop('attachments', [])

        representation['items'] = items_data
        representation['attachments'] = attachments_data

        return representation


    def get_store_details(self, instance):
        _details = []
        if instance.store:
            _details = StoreMaster.cmobjects.filter(pk=instance.store_id).values()
        return _details

    def get_site_details(self, instance):
        ''' get site from store '''
        _temp = []
        if instance.store and instance.store.site_id:
            _temp = SiteMaster.cmobjects.filter(pk=instance.store.site_id).values()
        return _temp

    class Meta:
        model = MaterialWastage
        fields = '__all__'


class LabTestingParametersItemSerializer(serializers.ModelSerializer):
    """
    LabTestingParametersItem Serializer
    """
    id = serializers.IntegerField(required=False)
    item_group_name = serializers.SerializerMethodField()

    def get_item_group_name(self, instance):
        item_group_name = None
        if instance.item_group_id:
            item_group_name=MaterialType.cmobjects.filter(pk=instance.item_group_id).values()
        return item_group_name

    class Meta:
        model = LabTestingParametersItem
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class LabTestingParametersSerializer(serializers.ModelSerializer):
    """
    LabTestingParameters Serializer
    """
    items = LabTestingParametersItemSerializer(many=True, required=False,
                                               source='procurement_leb_testing_parameters_items')

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_leb_testing_parameters_items', [])
        lab_testing_parameters = LabTestingParameters.objects.create(**validated_data)

        current_user = lab_testing_parameters.created_by if lab_testing_parameters.created_by else None

        for item_data in items_data:
            LabTestingParametersItem.objects.create(lab_testing_parameters=lab_testing_parameters,
                                                    created_by=current_user, **item_data)

        return lab_testing_parameters

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.get('procurement_leb_testing_parameters_items', [])
        existing_items = instance.procurement_leb_testing_parameters_items.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            item_data['created_by']=current_user
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                LabTestingParametersItem.objects.create(created_by=current_user,
                                                        lab_testing_parameters=instance, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', instance.updated_by)
                existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        items_data = representation.pop('items', [])
        representation['items'] = items_data
        return representation

    class Meta:
        model = LabTestingParameters
        fields = '__all__'


class FreightContractSerializer(serializers.ModelSerializer):
    """
    FreightContract Serializer
    """

    class Meta:
        model = FreightContract
        fields = '__all__'


class RateContractSerializer(serializers.ModelSerializer):
    """
    RateContract Serializer
    """

    class Meta:
        model = RateContract
        fields = '__all__'


class OtherTextboxSerializer(serializers.ModelSerializer):
    """
    OtherTextbox Serializer
    """

    class Meta:
        model = OtherTextbox
        fields = '__all__'


class ApprovalDoctypeSerializer(serializers.ModelSerializer):
    """
    ApprovalDoctype Serializer
    """

    class Meta:
        model = ApprovalDoctype
        fields = '__all__'


class DocumentEmployeeApprovalSerializer(serializers.ModelSerializer):
    """
    DocumentEmployeeApproval Serializer
    """
    site = SiteMasterSerializer(read_only=True, many=True)
    site_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)

    def validate_site_ids(self, value):
        errors = []
        for site_id in value:
            try:
                SiteMaster.objects.get(pk=site_id)
            except SiteMaster.DoesNotExist:
                errors.append(f"Site with ID {site_id} does not exist.")
        if errors:
            raise serializers.ValidationError(errors)
        return value

    @transaction.atomic
    def create(self, validated_data):
        site_ids = validated_data.pop('site_ids')
        general_setting = DocumentEmployeeApproval.objects.create(**validated_data)

        for site_id in site_ids:
            site = SiteMaster.objects.get(pk=site_id)
            general_setting.site.add(site)

        return general_setting

    @transaction.atomic
    def update(self, instance, validated_data):
        site_ids = validated_data.pop('site_ids', [])

        for key, value in validated_data.items():
            setattr(instance, key, value)

        instance.site.clear()
        for site_id in site_ids:
            site = SiteMaster.objects.get(pk=site_id)
            instance.site.add(site)

        instance.save()
        return instance

    class Meta:
        model = DocumentEmployeeApproval
        fields = '__all__'


class MonthFinancialYearLockSerializer(serializers.ModelSerializer):
    """
    MaterialFinancialYearLock Serializer
    """

    class Meta:
        model = MonthFinancialYearLock
        fields = '__all__'


class RestrictItemGroupSerializer(serializers.ModelSerializer):
    """Serializer for RestrictItemGroup objects."""

    item_group_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)
    site_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)
    item_group = MaterialTypeSerializer(read_only=True, many=True)
    site = SiteMasterSerializer(read_only=True, many=True)

    class Meta:
        model = RestrictItemGroup
        fields = [
            'id',
            'item_group_ids',
            'site_ids',
            'page_name',
            'item_group',
            'site',
            'organization'
        ]

    @transaction.atomic
    def create(self, validated_data):
        item_group_ids = validated_data.pop('item_group_ids')
        site_ids = validated_data.pop('site_ids')
        page_name = validated_data.get('page_name')

        # Check for existing instances with the same combination
        # existing_instance = RestrictItemGroup.cmobjects.filter(
        #     page_name=page_name,
        #     item_group__in=item_group_ids,
        #     site__in=site_ids
        # ).fist()
        # print("existing_instance >>>> ", existing_instance)
        # if existing_instance:
        #     raise APIException("This combination of page_name, item_group_ids, and site_ids already exists.")
        restrict_item_group = RestrictItemGroup.objects.create(**validated_data)

        for item_group_id in item_group_ids:
            item_group = MaterialType.objects.get(pk=item_group_id)
            restrict_item_group.item_group.add(item_group)

        for site_id in site_ids:
            site = SiteMaster.objects.get(pk=site_id)
            restrict_item_group.site.add(site)

        return restrict_item_group

    @transaction.atomic
    def update(self, instance, validated_data):
        item_group_ids = validated_data.pop('item_group_ids', [])
        site_ids = validated_data.pop('site_ids', [])

        for key, value in validated_data.items():
            setattr(instance, key, value)

        instance.item_group.clear()
        for item_group_id in item_group_ids:
            item_group = MaterialType.objects.get(pk=item_group_id)
            instance.item_group.add(item_group)

        instance.site.clear()
        for site_id in site_ids:
            site = SiteMaster.objects.get(pk=site_id)
            instance.site.add(site)

        instance.save()
        return instance


class GeneralSettingSerializer(serializers.ModelSerializer):
    """Serializer for GeneralSetting objects."""

    site = SiteMasterSerializer(read_only=True, many=True)
    site_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)

    class Meta:
        model = GeneralSetting
        fields = [
            'id',
            'organization',
            'is_active',
            'setting_name',
            'tag',
            'site',
            'site_ids'
        ]

    def validate_site_ids(self, value):
        errors = []
        for site_id in value:
            try:
                SiteMaster.objects.get(pk=site_id)
            except SiteMaster.DoesNotExist:
                errors.append(f"Site with ID {site_id} does not exist.")
        if errors:
            raise serializers.ValidationError(errors)
        return value

    @transaction.atomic
    def create(self, validated_data):
        site_ids = validated_data.pop('site_ids')
        general_setting = GeneralSetting.objects.create(**validated_data)

        for site_id in site_ids:
            site = SiteMaster.objects.get(pk=site_id)
            general_setting.site.add(site)

        return general_setting

    @transaction.atomic
    def update(self, instance, validated_data):
        site_ids = validated_data.pop('site_ids', [])

        for key, value in validated_data.items():
            setattr(instance, key, value)

        instance.site.clear()
        for site_id in site_ids:
            site = SiteMaster.objects.get(pk=site_id)
            instance.site.add(site)

        instance.save()
        return instance


class MultiStageSettingStagesSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    department = DepartmentSerializer(read_only=True, many=True)
    department_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)

    employee = PmsUserSerializer(read_only=True, many=True)
    employee_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)

    def validate_department_ids(self, value):
        errors = []
        for department_id in value:
            try:
                Department.objects.get(pk=department_id)
            except Department.DoesNotExist:
                # raise serializers.ValidationError(f"Department with ID {department_id} does not exist.")
                errors.append(f"Department with ID {department_id} does not exist.")
        if errors:
            raise serializers.ValidationError(errors)
        return value

    def validate_employee_ids(self, value):
        errors = []
        for employee_id in value:
            try:
                PmsUser.objects.get(pk=employee_id)
            except PmsUser.DoesNotExist:
                # raise serializers.ValidationError(f"Employee with ID {employee_id} does not exist.")
                errors.append(f"Employee with ID {employee_id} does not exist.")
        if errors:
            raise serializers.ValidationError(errors)
        return value

    class Meta:
        model = MultiStageSettingStages
        fields = [
            'id',
            'organization',
            'stage',
            'stage_name',
            'ref_stage_name',
            'remarks_required',
            'department',
            'department_ids',
            'employee',
            'employee_ids'
        ]
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MultiStageSettingSerializer(serializers.ModelSerializer):
    """
    MultiStageSetting Serializer
    """
    stages = MultiStageSettingStagesSerializer(many=True, required=False, source='procurement_multi_stage_setting_stages')
    site = SiteMasterSerializer(read_only=True, many=True)
    site_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)

    def validate_site_ids(self, value):
        errors = []
        for site_id in value:
            try:
                SiteMaster.objects.get(pk=site_id)
            except SiteMaster.DoesNotExist:
                errors.append(f"Site with ID {site_id} does not exist.")
        if errors:
            raise serializers.ValidationError(errors)
        return value

    @transaction.atomic
    def create(self, validated_data):
        overlap = procurement_duplicate_multi_stages(validated_data)
        if overlap:
            raise APIException(f'Overlapping records: {str(','.join([f'{x['id']}: {x['multi_stage_name']}' for x in overlap]))}')
        stages_data = validated_data.pop('procurement_multi_stage_setting_stages', [])
        site_ids = validated_data.pop('site_ids')
        # errors = []
        # for site_id in site_ids:
        #     check_existing_records = MultiStageSetting.cmobjects.filter(site=site_id,organization=validated_data['organization'],from_name=validated_data['from_name']).exists()
        #     if check_existing_records:
        #         errors.append(f"Site with ID {site_id} already exist.")
        # if errors:
        #     raise serializers.ValidationError(errors)
        multi_stage_setting = MultiStageSetting.objects.create(**validated_data)

        current_user = multi_stage_setting.created_by if multi_stage_setting.created_by else None

        for site_id in site_ids:
            print("site_id >>>> ", site_id)
            site = SiteMaster.objects.get(pk=site_id)
            multi_stage_setting.site.add(site)
        print("stages_data >>>> ", stages_data)
        for stage_data in stages_data:
            department_ids = stage_data.pop('department_ids')
            employee_ids = stage_data.pop('employee_ids')
            stages = MultiStageSettingStages.objects.create(multi_stage_setting=multi_stage_setting, created_by=current_user, **stage_data)

            for department_id in department_ids:
                department = Department.objects.get(pk=department_id)
                stages.department.add(department)

            for employee_id in employee_ids:
                employee = PmsUser.objects.get(pk=employee_id)
                stages.employee.add(employee)

        return multi_stage_setting

    @transaction.atomic
    def update(self, instance, validated_data):
        flag = procurement_multi_stages_update_check(validated_data,instance)
        if flag:
            raise APIException(f'Linked with active records')
        overlap = procurement_duplicate_multi_stages(validated_data,instance.id)
        if overlap:
            raise APIException(f'Overlapping records: {str(','.join([f'{x['id']}: {x['multi_stage_name']}' for x in overlap]))}')
        site_ids = validated_data.pop('site_ids', [])
        # errors = []
        # for site_id in site_ids:
        #     check_existing_records = MultiStageSetting.cmobjects.exclude(pk=instance.id).filter(site=site_id,organization=validated_data['organization'],from_name=validated_data['from_name']).exists()
        #     if check_existing_records:
        #         errors.append(f"Site with ID {site_id} already exist.")
        # if errors:
        #     raise serializers.ValidationError(errors)
        
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        instance.site.clear()
        for site_id in site_ids:
            site = SiteMaster.objects.get(pk=site_id)
            instance.site.add(site)

        stages_data = validated_data.get('procurement_multi_stage_setting_stages', [])
        existing_stages = instance.procurement_multi_stage_setting_stages.filter(is_deleted=False)

        for stage_data in stages_data:
            stage_id = stage_data.get('id')
            stage_data['created_by'] = current_user
            existing_stage = next((stage for stage in existing_stages if stage.id == stage_id), None)
            department_ids = stage_data.pop('department_ids')
            employee_ids = stage_data.pop('employee_ids')
            if not existing_stage:
                existing_stage = MultiStageSettingStages.objects.create(multi_stage_setting=instance, **stage_data)
                for department_id in department_ids:
                    department = Department.objects.get(pk=department_id)
                    existing_stage.department.add(department)

                for employee_id in employee_ids:
                    employee = PmsUser.objects.get(pk=employee_id)
                    existing_stage.employee.add(employee)
            else:
                existing_stage.department.clear()
                for department_id in department_ids:
                    department = Department.objects.get(pk=department_id)
                    existing_stage.department.add(department)

                existing_stage.employee.clear()
                for employee_id in employee_ids:
                    employee = PmsUser.objects.get(pk=employee_id)
                    existing_stage.employee.add(employee)

                for field in existing_stage._meta.fields:
                    field_name = field.name
                    if field_name in stage_data:
                        setattr(existing_stage, field_name, stage_data[field_name])
                setattr(existing_stage, 'updated_by', current_user)
                existing_stage.save()

        for existing_stage in existing_stages:
            if existing_stage.id not in [data.get('id') for data in stages_data]:
                setattr(existing_stage, 'is_deleted', True)
                setattr(existing_stage, 'updated_by', instance.updated_by)
                existing_stage.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        stages_data = representation.pop('stages', [])
        representation['stages'] = stages_data
        return representation

    class Meta:
        model = MultiStageSetting
        fields = [
            'id',
            'organization',
            'from_name',
            'multi_stage_name',
            'conditions',
            'stages',
            'site',
            'site_ids',
            'is_archived',
        ]


class SiteWiseStockLevelSettingSerializer(serializers.ModelSerializer):
    """
    SiteWiseStockLevelSetting Serializer
    """

    class Meta:
        model = SiteWiseStockLevelSetting
        fields = '__all__'


class PurchaseItemsNotesSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PurchaseItemsNotes
        fields = '__all__'
        read_only_fields = ['id']
        # list_serializer_class = CommonFilterListSerializer


class PurchaseAttachmentsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PurchaseAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseItemsSerializer(serializers.ModelSerializer):
    notes = PurchaseItemsNotesSerializer(many=True, required=False)
    id = serializers.IntegerField(required=False)
    material_details = serializers.SerializerMethodField()

    # def get_material_details(self, instance):
    #     item_detail = []
    #     if instance.item_id:
    #         item_detail.append(VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).values())
    #         item_detail.append(MaterialType.cmobjects.filter(pk=instance.item.material_type_id).values())
    #     return item_detail

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.item:
                # details = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).first()
                # serializer = VendorMaterialMasterSerializer(details)
                serializer = VendorMaterialMasterSerializer(instance.item)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details

    class Meta:
        model = PurchaseItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseTaxDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseTaxDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement PurchaseExpenseDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseSerializer(serializers.ModelSerializer):
    items = PurchaseItemsSerializer(many=True, source='procurement_purchase_items')
    attachments = PurchaseAttachmentsSerializer(many=True, required=False, source='procurement_purchase_attachments')
    purchase_tax = PurchaseTaxDetailsSerializer(many=True, required=False, source="procurement_purchase_tax")
    purchase_expense = PurchaseExpenseDetailsSerializer(many=True, required=False, source="procurement_purchase_expense")
    grn_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()

    linked_docs = serializers.SerializerMethodField()
    def get_linked_docs(self, instance):
        return parent_fields(instance,'procurement_purchase_items')

    class Meta:
        model = Purchase
        fields = '__all__'

    def get_grn_details(self, instance):
        grn_name = None
        if instance.grn:
            # grn_name=GRN.cmobjects.filter(pk=instance.grn_id).values()
            grn_name=get_details_from_instance(instance.grn)
        return grn_name

    def get_vendor_details(self, instance):
        vendor_name = None
        try:
            if instance.vendor_id:
                vendor_name=get_vendor_data(instance.vendor)
        except Exception as e:
            print('ERROR', e)
        return vendor_name

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_name = projectdata.value if projectdata else ''
        # return project_name
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.project.project_name if instance.project else ''

    def get_project_code(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_id').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_code = projectdata.value if projectdata else ''
        # return project_code
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.project.project_code if instance.project else ''
    
    def calculate_totals(self, instance):
        instance.total_item_item_weight = 0
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.procurement_purchase_items.filter(is_deleted=False):
            instance.total_item_item_weight += item.weight
            instance.total_item_item_quantity += item.quantity
            instance.total_item_item_amount += item.item_amount
            instance.total_item_disc_amount += item.disc_amount
            instance.total_item_taxable_amount += item.taxable_amount
            instance.total_item_excise_tax_amount += item.excise_tax_amount
            instance.total_item_tax_amount += item.tax_amount
            instance.total_item_sgst_amount += item.sgst_amount
            instance.total_item_cgst_amount += item.cgst_amount
            instance.total_item_igst_amount += item.igst_amount
            instance.total_item_utgst_amount += item.utgst_amount
            instance.total_item_cess_amount += item.cess_amount
            instance.total_item_total_amount += item.total_amount
        
        for item in instance.procurement_purchase_expense.filter(is_deleted=False):
            if item.included:
                if item.add:
                    instance.total_expense_expense_amount += item.expense_amount
                    instance.total_expense_sgst_amount += item.sgst_amount
                    instance.total_expense_cgst_amount += item.cgst_amount
                    instance.total_expense_igst_amount += item.igst_amount
                    instance.total_expense_utgst_amount += item.utgst_amount
                    instance.total_expense_cess_amount += item.cess_amount
                    instance.total_expense_total_expense_amount += item.total_expense_amount
                else:
                    instance.total_expense_expense_amount -= item.expense_amount
                    instance.total_expense_sgst_amount -= item.sgst_amount
                    instance.total_expense_cgst_amount -= item.cgst_amount
                    instance.total_expense_igst_amount -= item.igst_amount
                    instance.total_expense_utgst_amount -= item.utgst_amount
                    instance.total_expense_cess_amount -= item.cess_amount
                    instance.total_expense_total_expense_amount -= item.total_expense_amount

        for item in instance.procurement_purchase_tax.filter(is_deleted=False):
            if item.included:
                if item.add:
                    instance.total_tax_tax_amount += item.tax_amount
                    instance.total_tax_sgst_amount += item.sgst_amount
                    instance.total_tax_cgst_amount += item.cgst_amount
                    instance.total_tax_igst_amount += item.igst_amount
                    instance.total_tax_utgst_amount += item.utgst_amount
                    instance.total_tax_cess_amount += item.cess_amount
                    instance.total_tax_total_tax_amount += item.total_tax_amount
                else:
                    instance.total_tax_tax_amount -= item.tax_amount
                    instance.total_tax_sgst_amount -= item.sgst_amount
                    instance.total_tax_cgst_amount -= item.cgst_amount
                    instance.total_tax_igst_amount -= item.igst_amount
                    instance.total_tax_utgst_amount -= item.utgst_amount
                    instance.total_tax_cess_amount -= item.cess_amount
                    instance.total_tax_total_tax_amount -= item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_purchase_items', [])
        attachments = validated_data.pop('procurement_purchase_attachments', [])
        tax_data = validated_data.pop('procurement_purchase_tax', [])
        expense_data = validated_data.pop('procurement_purchase_expense', [])

        purchase = Purchase.objects.create(**validated_data)
        # purchase.request_code = generate_all_code(purchase,['PB'])

        current_user = purchase.created_by if purchase.created_by else None

        for requested_attachment_data in attachments:
            try:
                PurchaseAttachments.objects.create(
                    organization=purchase.organization,
                    purchase=purchase,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )
            except Exception as e:
                print(f"exception: {e}")

        for item_data in items_data:
            notes_data = item_data.pop('notes', [])
            purchase_item = PurchaseItems.objects.create(purchase=purchase, created_by=current_user, **item_data)

            for note_data in notes_data:
                PurchaseItemsNotes.objects.create(purchase_item=purchase_item, created_by=current_user, **note_data)
        self.calculate_totals(purchase)

        for purchase_expense_data in expense_data:
            PurchaseExpenseDetails.objects.create(purchase=purchase, created_by=current_user, **purchase_expense_data)
        self.calculate_totals(purchase)

        for purchase_tax_data in tax_data:
            PurchaseTaxDetails.objects.create(purchase=purchase, created_by=current_user, **purchase_tax_data)
        self.calculate_totals(purchase)
        purchase.save()
        return purchase

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.pop('procurement_purchase_items', [])
        attachments_data = validated_data.pop('procurement_purchase_attachments', [])
        tax_data = validated_data.pop('procurement_purchase_tax', [])
        expense_data = validated_data.pop('procurement_purchase_expense', [])

        instance.organization = validated_data.get('organization', instance.organization)
        current_user = instance.updated_by if instance.updated_by else None

        existing_attachments = instance.procurement_purchase_attachments.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = PurchaseAttachments.objects.create(
                        organization=instance.organization,
                        purchase=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        existing_items = instance.procurement_purchase_items.filter(is_deleted=False)
        for item_data in items_data:
            item_id = item_data.get('id', None)
            notes_data = item_data.pop("notes", [])
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                existing_item = PurchaseItems.objects.create(purchase=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

            existing_notes = existing_item.procurement_purchase_item_notes.filter(is_deleted=False)

            for note_data in notes_data:
                note_id = note_data.get('id', None)
                existing_note = next((note for note in existing_notes if note.id == note_id), None)
                if not existing_note:
                    existing_note = PurchaseItemsNotes.objects.create(
                        purchase_item=existing_item,
                        created_by=current_user,
                        **note_data
                    )
                else:
                    for note_field in existing_note._meta.fields:
                        note_field_name = note_field.name
                        if note_field_name in note_data:
                            setattr(existing_note, note_field_name, note_data[note_field_name])
                    setattr(existing_note, 'updated_by', current_user)
                existing_note.save()

            for existing_note in existing_notes:
                if existing_note.id not in [note_data.get('id') for note_data in notes_data]:
                    setattr(existing_note, 'is_deleted', True)
                    setattr(existing_note, 'updated_by', instance.updated_by)
                    existing_note.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', instance.updated_by)
                existing_item.save()
        self.calculate_totals(instance)

        # Expense
        existing_expense = instance.procurement_purchase_expense.filter(is_deleted=False)
        for expense_data_item in expense_data:
            expense_id = expense_data_item.get('id', None)
            existing_expense_item = next(
                (item for item in existing_expense if item.id == expense_id), None)

            if not existing_expense_item:
                existing_expense_item = PurchaseExpenseDetails.objects.create(
                    purchase=instance,
                    created_by=current_user,
                    **expense_data_item
                )
            else:
                for field in existing_expense_item._meta.fields:
                    field_name = field.name
                    if field_name in expense_data_item:
                        setattr(existing_expense_item, field_name, expense_data_item[field_name])
                setattr(existing_expense_item, 'updated_by', instance.updated_by)
                existing_expense_item.save()

        for existing_expense_item in existing_expense:
            if existing_expense_item.id not in [item.get('id') for item in expense_data]:
                setattr(existing_expense_item, 'is_deleted', True)
                setattr(existing_expense_item, 'updated_by', instance.updated_by)
                existing_expense_item.save()

        self.calculate_totals(instance)

        # Tax
        existing_tax = instance.procurement_purchase_tax.filter(is_deleted=False)
        for tax_data_item in tax_data:
            tax_id = tax_data_item.get('id', None)
            existing_tax_item = next(
                (item for item in existing_tax if item.id == tax_id), None)

            if not existing_tax_item:
                existing_tax_item = PurchaseTaxDetails.objects.create(
                    purchase=instance,
                    created_by=current_user,
                    **tax_data_item
                )
            else:
                for field in existing_tax_item._meta.fields:
                    field_name = field.name
                    if field_name in tax_data_item:
                        setattr(existing_tax_item, field_name, tax_data_item[field_name])
                setattr(existing_tax_item, 'updated_by', instance.updated_by)
                existing_tax_item.save()

        for existing_tax_item in existing_tax:
            if existing_tax_item.id not in [item.get('id') for item in tax_data]:
                setattr(existing_tax_item, 'is_deleted', True)
                setattr(existing_tax_item, 'updated_by', instance.updated_by)
                existing_tax_item.save()
        self.calculate_totals(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        items_data = representation.pop('items', [])
        representation['items'] = items_data
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data
        purchase_tax_data = representation.pop('purchase_tax', [])
        representation['purchase_tax'] = purchase_tax_data
        purchase_expense_data = representation.pop('purchase_expense', [])
        representation['purchase_expense'] = purchase_expense_data

        for item_data in items_data:
            notes_data = PurchaseItemsNotes.cmobjects.filter(purchase_item__id=item_data['id'])
            item_data['notes'] = PurchaseItemsNotesSerializer(notes_data, many=True).data
        return representation


class PlantProductionItemsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PlantProductionItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    material_details = serializers.SerializerMethodField()

    def get_material_details(self, instance):
        return_details = []
        try:
            if instance.item and instance.item_id:
                details = VendorMaterialMaster.cmobjects.filter(pk=instance.item_id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = [serializer.data]
        except Exception as e:
            print('ERROR', e)

        return return_details


class PlantProductionSerializer(serializers.ModelSerializer):
    items = PlantProductionItemsSerializer(many=True, source='procurement_plant_production_items')

    class Meta:
        model = PlantProduction
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_plant_production_items', [])

        plant_production = PlantProduction.objects.create(**validated_data)
        # plant_production.request_code = generate_all_code(plant_production,['PP'])

        current_user = plant_production.created_by if plant_production.created_by else None

        for item_data in items_data:
            PlantProductionItems.objects.create(plant_production=plant_production, created_by=current_user, **item_data)

        return plant_production

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.pop('procurement_plant_production_items', [])

        # Update or create plant production items
        existing_items = instance.procurement_plant_production_items.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            item_data['created_by'] = current_user
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                existing_item = PlantProductionItems.objects.create(plant_production=instance, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        instance.save()
        return instance


class GeneralAdministrationExpensesAttachmentsSerializer(serializers.ModelSerializer):
    """
    GeneralAdministrationExpensesAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = GeneralAdministrationExpensesAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class GeneralAdministrationExpenseItemsSerializer(serializers.ModelSerializer):
    """
    GeneralAdministrationExpenseItems Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = GeneralAdministrationExpenseItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class GeneralAdministrationExpensesSerializer(serializers.ModelSerializer):
    items = GeneralAdministrationExpenseItemsSerializer(many=True, source="procurement_general_admin_expense_items")
    attachments = GeneralAdministrationExpensesAttachmentsSerializer(many=True, required=False,
                                                                    source="procurement_general_admin_expense_attachment")

    class Meta:
        model = GeneralAdministrationExpenses
        fields = '__all__'

    def calculate_totals(self, instance):
        instance.total_amount = 0
        instance.total_sgst_amount = 0
        instance.total_cgst_amount = 0
        instance.total_igst_amount = 0
        instance.total_utgst_amount = 0
        instance.total_cess_amount = 0
        instance.total_amount_with_all_taxes = 0
        instance.net_amount = 0
        for item in instance.procurement_general_admin_expense_items.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_amount = instance.total_amount+item.amount
                instance.total_sgst_amount = instance.total_sgst_amount+item.sgst_amount
                instance.total_cgst_amount = instance.total_cgst_amount+item.cgst_amount
                instance.total_igst_amount = instance.total_igst_amount+item.igst_amount
                instance.total_utgst_amount = instance.total_utgst_amount+item.utgst_amount
                instance.total_cess_amount = instance.total_cess_amount+item.cess_amount
                instance.total_amount_with_all_taxes = instance.total_amount_with_all_taxes+item.total_amount
                if item.debit_credit == 'de':
                    instance.net_amount = instance.net_amount-item.total_amount
                if item.debit_credit == 'cr':
                    instance.net_amount = instance.net_amount+item.total_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_general_admin_expense_items', [])
        attachments = validated_data.pop('procurement_general_admin_expense_attachment', [])

        general_admin_expense = GeneralAdministrationExpenses.objects.create(**validated_data)
        # general_admin_expense.request_code = generate_all_code(general_admin_expense,['GAE'])

        current_user = general_admin_expense.created_by if general_admin_expense.created_by else None

        for requested_attachment_data in attachments:
            try:
                GeneralAdministrationExpensesAttachments.objects.create(
                    organization=general_admin_expense.organization,
                    general_admin_expense=general_admin_expense,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )
            except Exception as e:
                print(f"exception: {e}")

        for item_data in items_data:
            GeneralAdministrationExpenseItems.objects.create(general_admin_expense=general_admin_expense, created_by=current_user, **item_data)
        self.calculate_totals(general_admin_expense)
        general_admin_expense.save()
        return general_admin_expense

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.pop('procurement_general_admin_expense_items', [])
        attachments_data = validated_data.pop('procurement_general_admin_expense_attachment', [])

        existing_items = instance.procurement_general_admin_expense_items.filter(is_deleted=False)
        existing_attachments = instance.procurement_general_admin_expense_attachment.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                existing_item = GeneralAdministrationExpenseItems.objects.create(created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = GeneralAdministrationExpensesAttachments.objects.create(
                        organization=instance.organization,
                        general_admin_expense=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        self.calculate_totals(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        items_data = representation.pop('items', [])
        representation['items'] = items_data
        attachments_data = representation.pop('attachments', [])
        representation['attachments'] = attachments_data

        return representation


class RawMaterialSalesAttachmentsSerializer(serializers.ModelSerializer):
    """
    RawMaterialSalesAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = RawMaterialSalesAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class RawMaterialSalesTaxDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement RawMaterialSalesTaxDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = RawMaterialSalesTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class RawMaterialSalesExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    Procurement RawMaterialSalesExpenseDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = RawMaterialSalesExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class RawMaterialSalesItemsSerializer(serializers.ModelSerializer):
    """
    RawMaterialSalesItems Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = RawMaterialSalesItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class RawMaterialSalesSerializer(serializers.ModelSerializer):
    """
    RawMaterialSales Serializer
    """
    items = RawMaterialSalesItemsSerializer(many=True, source='procurement_raw_material_sales_items')
    raw_material_sales_tax = RawMaterialSalesTaxDetailsSerializer(many=True, required=False, source="procurement_raw_material_sales_tax")
    raw_material_sales_expense = RawMaterialSalesExpenseDetailsSerializer(many=True, required=False, source="procurement_raw_material_sales_expense")
    attachments = RawMaterialSalesAttachmentsSerializer(many=True, required=False, source='procurement_raw_material_sales_attachments')

    store_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    class Meta:
        model = RawMaterialSales
        fields = '__all__'

    def calculate_totals(self, instance):
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.procurement_raw_material_sales_items.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount

        for item in instance.procurement_raw_material_sales_expense.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

        for item in instance.procurement_raw_material_sales_tax.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_raw_material_sales_items', [])
        tax_data = validated_data.pop('procurement_raw_material_sales_tax', [])
        expense_data = validated_data.pop('procurement_raw_material_sales_expense', [])
        attachments = validated_data.pop('procurement_raw_material_sales_attachments', [])

        raw_material_sales = RawMaterialSales.objects.create(**validated_data)
        # raw_material_sales.request_code = generate_all_code(raw_material_sales,['RMS'])

        
        current_user = raw_material_sales.created_by if raw_material_sales.created_by else None

        for requested_attachment_data in attachments:
            try:
                RawMaterialSalesAttachments.objects.create(
                    organization=raw_material_sales.organization,
                    raw_material_sales=raw_material_sales,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user,
                )
            except Exception as e:
                print(f"exception: {e}")
        
        for item_data in items_data:
            RawMaterialSalesItems.objects.create(raw_material_sales=raw_material_sales,created_by=current_user, **item_data)
        self.calculate_totals(raw_material_sales)
        for raw_material_sales_expense_data in expense_data:
            RawMaterialSalesExpenseDetails.objects.create(raw_material_sales=raw_material_sales,created_by=current_user,**raw_material_sales_expense_data)
        self.calculate_totals(raw_material_sales)
        for raw_material_sales_tax_data in tax_data:
            RawMaterialSalesTaxDetails.objects.create(raw_material_sales=raw_material_sales,created_by=current_user, **raw_material_sales_tax_data)
        self.calculate_totals(raw_material_sales)
        raw_material_sales.save()
        return raw_material_sales
    
    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.pop('procurement_raw_material_sales_attachments', [])

        existing_attachments = instance.procurement_raw_material_sales_attachments.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = RawMaterialSalesAttachments.objects.create(
                        organization=instance.organization,
                        raw_material_sales=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        edit_child_model(instance,validated_data,'RawMaterialSalesItems','procurement_raw_material_sales_items','raw_material_sales')
        self.calculate_totals(instance)
        edit_child_model(instance,validated_data,'RawMaterialSalesExpenseDetails','procurement_raw_material_sales_expense','raw_material_sales')
        self.calculate_totals(instance)
        edit_child_model(instance,validated_data,'RawMaterialSalesTaxDetails','procurement_raw_material_sales_tax','raw_material_sales')
        self.calculate_totals(instance)

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        items_data = representation.pop('items', [])
        representation['items'] = items_data
        raw_material_sales_tax_data = representation.pop('raw_material_sales_tax', [])
        representation['raw_material_sales_tax'] = raw_material_sales_tax_data
        raw_material_sales_expense_data = representation.pop('raw_material_sales_expense', [])
        representation['raw_material_sales_expense'] = raw_material_sales_expense_data
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data

        return representation


    def get_site_details(self, instance):
        site_name = None
        if instance.site_id:
            site_name=SiteMaster.cmobjects.filter(pk=instance.site_id).values()
        return site_name
    
    def get_store_details(self, instance):
        store_name = None
        if instance.store_id:
            store_name=StoreMaster.cmobjects.filter(pk=instance.store_id).values()
        return store_name

    def get_vendor_details(self, instance):
        vendor_name = None
        try:
            if instance.party_name_id:
                vendor_name=get_vendor_data(instance.party_name)
        except Exception as e:
            print('ERROR', e)
        return vendor_name


class WayBillFormItemsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WayBillFormItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WayBillFormAttachmentsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WayBillFormAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WayBillFormSerializer(serializers.ModelSerializer):
    items = WayBillFormItemsSerializer(many=True, source="procurement_way_bill_form_items")
    attachments = WayBillFormAttachmentsSerializer(many=True, required=False, source="procurement_way_bill_form_attachments")

    grn_details = serializers.SerializerMethodField()
    purchase_details = serializers.SerializerMethodField()
    entry_in_state_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    class Meta:
        model = WayBillForm
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('procurement_way_bill_form_items', [])
        attachments = validated_data.pop('procurement_way_bill_form_attachments', [])

        way_bill_form = WayBillForm.objects.create(**validated_data)

        current_user = way_bill_form.created_by if way_bill_form.created_by else None

        for requested_attachment_data in attachments:
            try:
                WayBillFormAttachments.objects.create(
                    organization=way_bill_form.organization,
                    way_bill_form=way_bill_form,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )
            except Exception as e:
                print(f"exception: {e}")

        for item_data in items_data:
            WayBillFormItems.objects.create(way_bill_form=way_bill_form, created_by=current_user, **item_data)

        return way_bill_form

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.pop('procurement_way_bill_form_items', [])
        attachments_data = validated_data.pop('procurement_way_bill_form_attachments', [])

        existing_items = instance.procurement_way_bill_form_items.filter(is_deleted=False)
        existing_attachments = instance.procurement_way_bill_form_attachments.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            item_data['created_by'] = current_user
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                WayBillFormItems.objects.create(way_bill_form=instance, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', instance.updated_by)
                existing_item.save()

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = WayBillFormAttachments.objects.create(
                        organization=instance.organization,
                        way_bill_form=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        items_data = representation.pop('items', [])
        representation['items'] = items_data
        attachments_data = representation.pop('attachments', [])
        representation['attachments'] = attachments_data

        return representation


    def get_grn_details(self, instance):
        return_details = {}
        try:
            if instance.id:
                details = GRN.cmobjects.filter(way_bill_form=instance.id).first()
                serializer = GRNSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)
        return return_details
    
    def get_purchase_details(self, instance):
        return_details = {}
        try:
            if instance.id:
                details = Purchase.cmobjects.filter(way_bill_form=instance.id).first()
                serializer = PurchaseSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)
        return return_details
    
    def get_entry_in_state_details(self, instance):
        record = None
        if instance.entry_in_state_id:
            record=State.objects.filter(pk=instance.entry_in_state_id).values()
        return record

    def get_vendor_details(self, instance):
        record = None
        try:
            if instance.vendor_id:
                record=get_vendor_data(instance.vendor)
        except Exception as e:
            print('ERROR', e)
        return record


class TransporterBillItemsSerializer(serializers.ModelSerializer):
    """
    TransporterBillItems Serializer
    """

    id = serializers.IntegerField(required=False)

    class Meta:
        model = TransporterBillItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
    # method fields
    material_details = serializers.SerializerMethodField()

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.material and instance.material_id:
                details = VendorMaterialMaster.cmobjects.filter(pk=instance.material_id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)
        return return_details


class TransporterBillExpenseDetailsSerializer(serializers.ModelSerializer):
    """
    TransporterBillExpenseDetails Serializer
    """

    id = serializers.IntegerField(required=False)

    class Meta:
        model = TransporterBillExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TransporterBillTaxDetailsSerializer(serializers.ModelSerializer):
    """
    TransporterBillTaxDetails Serializer
    """

    id = serializers.IntegerField(required=False)

    class Meta:
        model = TransporterBillTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class TransporterBillShortageChargesSerializer(serializers.ModelSerializer):
    """
    TransporterBillShortageCharges Serializer
    """

    id = serializers.IntegerField(required=False)

    class Meta:
        model = TransporterBillShortageCharges
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TransporterBillAttachmentsSerializer(serializers.ModelSerializer):
    """
    TransporterBillAttachments Serializer
    """

    id = serializers.IntegerField(required=False)

    class Meta:
        model = TransporterBillAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TransporterBillSerializer(serializers.ModelSerializer):
    """
    Serializer TransporterBill
    """
    items = TransporterBillItemsSerializer(many=True, required=False, source="procurement_transporter_bill_items")
    expense_details = TransporterBillExpenseDetailsSerializer(many=True, required=False, source="procurement_transporter_bill_expense_details")
    tax = TransporterBillTaxDetailsSerializer(many=True, required=False, source="procurement_transporter_bill_tax")
    shortage_charges = TransporterBillShortageChargesSerializer(many=True, required=False, source="procurement_transporter_bill_shortage_charges")
    attachments = TransporterBillAttachmentsSerializer(many=True, required=False, source="procurement_transporter_bill_attachments")


    def calculate_totals(self, instance):
        instance.total_item_item_weight = 0
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_item_short_age_qty = 0 # new
        instance.total_item_excess_qty = 0 # new
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.procurement_transporter_bill_items.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_item_weight = instance.total_item_item_weight+item.weight
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount
                instance.total_item_short_age_qty = instance.total_item_short_age_qty+item.short_age_qty
                instance.total_item_excess_qty = instance.total_item_excess_qty+item.excess_qty

        for item in instance.procurement_transporter_bill_expense_details.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

        for item in instance.procurement_transporter_bill_tax.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.save()



    @transaction.atomic
    def create(self, validated_data):
        # # M2M
        site = validated_data.pop('site', [])
        store = validated_data.pop('store', [])

        # M2O
        items = validated_data.pop('procurement_transporter_bill_items', [])
        expense_details = validated_data.pop('procurement_transporter_bill_expense_details', [])
        tax = validated_data.pop('procurement_transporter_bill_tax', [])
        shortage_charges = validated_data.pop('procurement_transporter_bill_shortage_charges', [])
        attachments = validated_data.pop('procurement_transporter_bill_attachments', [])

        instance = TransporterBill.objects.create(**validated_data)

        # Direct assignment to the forward side of a many-to-many set is prohibited.
        instance.site.set(site) if site else None
        instance.store.set(store) if store else None

        current_user = instance.created_by if instance.created_by else None

        # insert items ✅
        _item = None
        for item in items:
            [item.pop(k, None) for k in
             ('organization', 'created_by', 'master', 'id')]
            _item = TransporterBillItems.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)

        # insert expense_details ✅
        _item = None
        for item in expense_details:
            [item.pop(k, None) for k in
             ('organization', 'created_by', 'master', 'id')]
            _item = TransporterBillExpenseDetails.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)

        # insert tax ✅
        _item = None
        for item in tax:
            [item.pop(k, None) for k in
             ('organization', 'created_by', 'master', 'id')]
            _item = TransporterBillTaxDetails.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)

        # insert shortage_charges ✅
        _item = None
        for item in shortage_charges:
            [item.pop(k, None) for k in
             ('organization', 'created_by', 'master', 'id')]
            _item = TransporterBillShortageCharges.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)

        # insert attachments ✅
        _item = None
        for requested_attachment_data in attachments:
            _item = TransporterBillAttachments.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                attachment=process_attachments(requested_attachment_data),
                file_data="",
                mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
            )
        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        site = validated_data.pop('site', [])
        store = validated_data.pop('store', [])

        # M2O
        items = validated_data.pop('procurement_transporter_bill_items', [])  # 1
        expense_details = validated_data.pop('procurement_transporter_bill_expense_details', [])  # 2
        tax = validated_data.pop('procurement_transporter_bill_tax', []) # 3
        shortage_charges = validated_data.pop('procurement_transporter_bill_shortage_charges', []) # 4
        attachments = validated_data.pop('procurement_transporter_bill_attachments', []) # 5
        for key, value in validated_data.items():
            setattr(instance, key, value)

        
        current_user = instance.updated_by if instance.updated_by else None

        instance.site.clear()
        instance.site.set(site)

        instance.store.clear()
        instance.store.set(store)

        ''' 1.  update/insert Items ✅ '''
        old_item_ids = [item.pk for item in instance.procurement_transporter_bill_items.filter(is_deleted=False)]
        updated_item_ids = []
        for item in items:
            id = item.pop('id', None)
            # item_notes = item.pop('procurement_transporter_bill_items', [])
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TransporterBillItems.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                _obj, created = TransporterBillItems.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            # update_item_notes_generic2('TransporterBillItemsNotes', item_notes, updated_by=instance.updated_by, master=_obj)
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = TransporterBillItems.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                                updated_by=current_user)
        print('deleted TransporterBillItems', _)
        self.calculate_totals(instance)


        ''' 2.  update/insert expense_details ✅  '''
        old_ids = [item.pk for item in instance.procurement_transporter_bill_expense_details.filter(is_deleted=False)]
        updated_ids = []

        for item in expense_details:
            id = item.pop('id', None)
            print(f"ID {60 * '!'}", id)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TransporterBillExpenseDetails.objects.create(**item)
                id = _obj.pk
            else:
                _obj, created = TransporterBillExpenseDetails.objects.update_or_create(pk=id, defaults=item)
            updated_ids.append(id)
        # soft remove excluded items
        excluded_ids = list(set(old_ids) - set(updated_ids))
        _ = TransporterBillExpenseDetails.objects.filter(pk__in=excluded_ids).update(is_deleted=True, updated_by=current_user)
        print('deleted TransporterBillExpenseDetails ', _)
        self.calculate_totals(instance)


        ''' 3. update/insert shortage_charges ✅ '''
        old_ids = [item.pk for item in instance.procurement_transporter_bill_shortage_charges.filter(is_deleted=False)]
        updated_ids = []

        for item in shortage_charges:
            id = item.pop('id', None)
            print(f"ID {60 * '!'}", id)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TransporterBillShortageCharges.objects.create(**item)
                id = _obj.pk
            else:
                _obj, created = TransporterBillShortageCharges.objects.update_or_create(pk=id, defaults=item)
            updated_ids.append(id)
        # soft remove excluded items
        excluded_ids = list(set(old_ids) - set(updated_ids))
        _ = TransporterBillShortageCharges.objects.filter(pk__in=excluded_ids).update(is_deleted=True, updated_by=current_user)
        print('deleted TransporterBillShortageCharges ', _)
        self.calculate_totals(instance)


        '''  4. update/insert tax ✅ '''
        old_ids = [item.pk for item in instance.procurement_transporter_bill_tax.filter(is_deleted=False)]
        updated_ids = []

        for item in tax:
            id = item.pop('id', None)
            print(f"ID {60 * '!'}", id)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TransporterBillTaxDetails.objects.create(**item)
                id = _obj.pk
            else:
                _obj, created = TransporterBillTaxDetails.objects.update_or_create(pk=id, defaults=item)
            updated_ids.append(id)
        # soft remove excluded items
        excluded_ids = list(set(old_ids) - set(updated_ids))
        _ = TransporterBillTaxDetails.objects.filter(pk__in=excluded_ids).update(is_deleted=True,
                                                                                     updated_by=current_user)
        print('deleted TransporterBillTaxDetails ', _)
        self.calculate_totals(instance)


        ''' 5.  update/insert attachments ✅ '''
        old_ids = [item.pk for item in instance.procurement_transporter_bill_attachments.filter(is_deleted=False)]
        updated_ids = []
        for requested_attachment_data in attachments:
            id = requested_attachment_data.pop('id', None)
            if not id:
                print('attachment added')
                _obj = TransporterBillAttachments.objects.create(
                    organization=instance.organization,
                    master=instance,
                    created_by=current_user,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                )
                id = _obj.pk
            else:
                print(f'attachment updated {id}',  current_user)
                _obj, created = TransporterBillAttachments.objects.update_or_create(
                    pk=id,
                    defaults={
                        "master": instance,
                        "organization": instance.organization,
                        "attachment": process_attachments(requested_attachment_data),
                        "updated_by": current_user,
                        "attachment_name": requested_attachment_data.get('attachment_name', None),
                    }
                )
            updated_ids.append(id)

        # soft remove excluded items
        excluded_ids = list(set(old_ids) - set(updated_ids))
        _ = TransporterBillAttachments.objects.filter(pk__in=excluded_ids).update(is_deleted=True, updated_by=current_user)
        print('deleted TransporterBillAttachments ', _)



        instance.save()
        return instance

    class Meta:
        model = TransporterBill
        fields = '__all__'

    # method fields
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    transporter_details = serializers.SerializerMethodField()

    def get_site_details(self, instance):
        _details = []
        if instance.site:
            _obj = instance.site.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = SiteMaster.cmobjects.filter(pk__in=(_ids)).values()
        return _details

    def get_store_details(self, instance):
        _details = []
        if instance.site:
            _obj = instance.store.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = StoreMaster.cmobjects.filter(pk__in=(_ids)).values()
        return _details

    def get_transporter_details(self, instance):
        _details = None
        try:
            if instance.transporter:
                data = get_vendor_data(instance.transporter)
                _details = {"transporter_id": instance.transporter.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details

class CFromAttachmentsSerializer(serializers.ModelSerializer):
    """
    CFromAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = CFromAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class CFromSerializer(serializers.ModelSerializer):
    attachments = CFromAttachmentsSerializer(many=True, required=False, source="procurement_c_from_attachments")

    class Meta:
        model = CFrom
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        attachments = validated_data.pop('procurement_c_from_attachments', [])
        c_from = CFrom.objects.create(**validated_data)

        current_user = c_from.created_by if c_from.created_by else None

        for requested_attachment_data in attachments:
            try:
                CFromAttachments.objects.create(
                    organization=c_from.organization,
                    c_from=c_from,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user,
                )
            except Exception as e:
                print(f"exception: {e}")

        return c_from

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        attachments_data = validated_data.pop('procurement_c_from_attachments', [])
        existing_attachments = instance.procurement_c_from_attachments.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next(
                (attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = CFromAttachments.objects.create(
                        organization=instance.organization,
                        c_from=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user,
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        attachments_data = representation.pop('attachments', [])
        representation['attachments'] = attachments_data

        return representation


class TaxInvoiceItemsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = TaxInvoiceItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TaxInvoiceExpenseDetailsSerializer(serializers.ModelSerializer):
    """
    TaxInvoice Expense Details Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = TaxInvoiceExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TaxInvoiceTaxDetailsSerializer(serializers.ModelSerializer):
    """
    TaxInvoiceTaxDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = TaxInvoiceTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class TaxInvoiceItemRateSerializer(serializers.ModelSerializer):
    """
    TaxInvoiceItemRate Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = TaxInvoiceItemRate
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class TaxInvoiceFreightRateSerializer(serializers.ModelSerializer):
    """
    TaxInvoiceFreightRate Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = TaxInvoiceFreightRate
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TaxInvoiceAttachmentsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = TaxInvoiceAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TaxInvoiceSerializer(serializers.ModelSerializer):
    items = TaxInvoiceItemsSerializer(many=True, required=False, source="procurement_tax_invoice_items_master")
    invoice_expenses = TaxInvoiceExpenseDetailsSerializer(many=True, required=False, source="procurement_tax_invoice_expense")
    tax_details = TaxInvoiceExpenseDetailsSerializer(many=True, required=False,
                                                          source="procurement_tax_invoice_tax_details")
    item_rate = TaxInvoiceItemRateSerializer(many=True, required=False, source='procurement_tax_invoice_item_rate_master')
    freight_rate = TaxInvoiceItemRateSerializer(many=True, required=False, source='procurement_tax_invoice_freight_rate_master')

    attachments = TaxInvoiceAttachmentsSerializer(many=True, required=False, source="procurement_tax_invoice_attachment")

    def calculate_totals(self, instance: TaxInvoice):
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0

        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0

        for item in instance.procurement_tax_invoice_items_master.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount

        for item in instance.procurement_tax_invoice_tax_details.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount

        for item in instance.procurement_tax_invoice_expense.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount + item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount + item.sgst_amount_expense
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount + item.cgst_amount_expense
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount + item.igst_amount_expense
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount + item.utgst_amount_expense
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount + item.cess_amount_expense
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount + item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount - item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount - item.sgst_amount_expense
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount - item.cgst_amount_expense
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount - item.igst_amount_expense
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount - item.utgst_amount_expense
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount - item.cess_amount_expense
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount - item.total_expense_amount

        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        #fk
        items = validated_data.pop('procurement_tax_invoice_items_master', [])
        invoice_expenses = validated_data.pop('procurement_tax_invoice_expense', [])
        tax_details = validated_data.pop('procurement_tax_invoice_tax_details', [])
        item_rate = validated_data.pop('procurement_tax_invoice_item_rate_master', [])
        freight_rate = validated_data.pop('procurement_tax_invoice_freight_rate_master', [])
        attachments = validated_data.pop('procurement_tax_invoice_attachment', [])

        #m2m
        site = validated_data.pop('site', [])
        store = validated_data.pop('store', [])

        instance = TaxInvoice.objects.create(**validated_data)

        # Direct assignment to the forward side of a many-to-many set is prohibited.
        instance.site.set(site) if site else None

        instance.store.set(store) if store else None

        current_user = instance.created_by if instance.created_by else None

        # insert items ✅
        _taxinvoiceitems = None
        for item in items:
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'id',)]
            _taxinvoiceitems = TaxInvoiceItems.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)
        instance.save()

        # insert invoice_expense ✅
        _invoice_expense = None
        for item in invoice_expenses:
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'id',)]
            _invoice_expense = TaxInvoiceExpenseDetails.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)
        instance.save()

        # insert tax_details ✅
        _tax_details = None
        for item in tax_details:
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'id',)]
            _tax_details = TaxInvoiceTaxDetails.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)
        instance.save()

        # insert TaxInvoiceItemRate ✅
        _taxinvoiceitemrate = None
        for item in item_rate:
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'id',)]
            _taxinvoiceitemrate = TaxInvoiceItemRate.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        # self.calculate_totals(instance)
        # instance.save()

        # insert TaxInvoiceFreightRate ✅
        _taxinvoicefreightrate = None
        for item in freight_rate:
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'id',)]
            _taxinvoicefreightrate = TaxInvoiceFreightRate.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        # self.calculate_totals(instance)
        # instance.save()

        # insert attachments ✅
        for requested_attachment_data in attachments:
            try:
                TaxInvoiceAttachments.objects.create(
                    organization=instance.organization,
                    tax_invoice=instance,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )
            except Exception as e:
                print(f"exception: {e}")
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        items = validated_data.pop('procurement_tax_invoice_items_master', [])  # 1
        invoice_expenses = validated_data.pop('procurement_tax_invoice_expense', [])  # 2
        tax_details = validated_data.pop('procurement_tax_invoice_tax_details', [])  # 3
        item_rate = validated_data.pop('procurement_tax_invoice_item_rate_master', []) # 4
        freight_rate = validated_data.pop('procurement_tax_invoice_freight_rate_master', []) # 5
        attachments = validated_data.pop('procurement_tax_invoice_attachment', [])  # 6

        site = validated_data.pop('site', [])
        store = validated_data.pop('store', [])

        for key, value in validated_data.items():
            setattr(instance, key, value)

        instance.site.clear()
        instance.site.set(site)

        instance.store.clear()
        instance.store.set(store)

        
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None


        # 1. update/insert TaxInvoiceItems ✅
        old_item_ids = [item.pk for item in instance.procurement_tax_invoice_items_master.filter(is_deleted=False)]
        updated_item_ids = []
        for item in items:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TaxInvoiceItems.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                TaxInvoiceItems.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = TaxInvoiceItems.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                                updated_by=current_user)
        print('deleted TaxInvoiceItems', _)
        # self.calculate_totals(instance)

        # 2. update/insert TaxInvoiceExpenseDetails ✅
        old_item_ids = [item.pk for item in instance.procurement_tax_invoice_expense.filter(is_deleted=False)]
        updated_item_ids = []
        for item in invoice_expenses:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TaxInvoiceExpenseDetails.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                TaxInvoiceExpenseDetails.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = TaxInvoiceExpenseDetails.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                            updated_by=current_user)
        print('deleted TaxInvoiceExpenseDetails', _)
        # self.calculate_totals(instance)

        # 3. update/insert TaxInvoiceTaxDetails ✅
        old_item_ids = [item.pk for item in instance.procurement_tax_invoice_tax_details.filter(is_deleted=False)]
        updated_item_ids = []
        for item in tax_details:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TaxInvoiceTaxDetails.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                TaxInvoiceTaxDetails.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = TaxInvoiceTaxDetails.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                            updated_by=current_user)
        print('deleted TaxInvoiceTaxDetails', _)
        # self.calculate_totals(instance)

        # 4. update/insert TaxInvoiceItemRate ✅
        old_item_ids = [item.pk for item in instance.procurement_tax_invoice_tax_details.filter(is_deleted=False)]
        updated_item_ids = []
        for item in item_rate:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TaxInvoiceItemRate.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                TaxInvoiceItemRate.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = TaxInvoiceItemRate.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                                 updated_by=current_user)
        print('deleted TaxInvoiceItemRate', _)
        # self.calculate_totals(instance)

        # 5. update/insert TaxInvoiceFreightRate ✅
        old_item_ids = [item.pk for item in instance.procurement_tax_invoice_tax_details.filter(is_deleted=False)]
        updated_item_ids = []
        for item in freight_rate:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = TaxInvoiceFreightRate.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                TaxInvoiceFreightRate.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = TaxInvoiceFreightRate.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                               updated_by=current_user)
        print('deleted TaxInvoiceFreightRate', _)
        # self.calculate_totals(instance)


        # 7. update/insert TaxInvoiceAttachments ✅
        for requested_attachment_data in attachments:
            try:
                id = requested_attachment_data.pop('id', None)
                if not id:
                    TaxInvoiceAttachments.objects.create(
                        organization=instance.organization,
                        tax_invoice=instance,
                        attachment=process_attachments(requested_attachment_data),
                        file_data="",
                        mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                else:
                    TaxInvoiceAttachments.objects.update_or_create(
                        pk=id,
                        defaults={
                            "tax_invoice": instance,
                            "organization": instance.organization,
                            "attachment": process_attachments(requested_attachment_data),
                            "updated_by": current_user,
                            "attachment_name": requested_attachment_data.get('attachment_name', None),
                        }
                    )
            except Exception as e:
                print(f"exception: {e}")

        instance.save()
        return instance

    # methods fields
    site_details = serializers.SerializerMethodField()
    customer_details = serializers.SerializerMethodField()
    transporter_details = serializers.SerializerMethodField()
    buyer_details = serializers.SerializerMethodField()

    def get_site_details(self, instance):
        _details = []
        if instance.site:
            _objs = instance.site.filter(is_deleted=False)
            _ids = [o.pk for o in _objs]
            if _ids:
                _details = SiteMaster.cmobjects.filter(pk__in=(_ids)).values()
        return _details

    def get_customer_details(self, instance):
        _details = []
        try:
            if instance.customer:
                data = get_vendor_data(instance.customer)
                _details = {"customer_id": instance.customer.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details

    def get_transporter_details(self, instance):
        _details = []
        try:
            if instance.transporter:
                data = get_vendor_data(instance.transporter)
                _details = {"transporter_id": instance.transporter.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details

    def get_buyer_details(self, instance):
        _details = []
        try:
            if instance.buyer:
                data = get_vendor_data(instance.buyer)
                _details = {"buyer_id": instance.buyer.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details

    class Meta:
        model = TaxInvoice
        fields = '__all__'
        # list_serializer_class = CommonFilterListSerializer # should be commented in main serializer


class MaterialIssueDebitNoteItemsSerializer(serializers.ModelSerializer):
    """
    MaterialIssueDebitNoteItems Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = MaterialIssueDebitNoteItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialIssueDebitNoteTaxSerializer(serializers.ModelSerializer):
    """
    MaterialIssueDebitNoteTax Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = MaterialIssueDebitNoteTax
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialIssueDebitNoteSerializer(serializers.ModelSerializer):
    """
    MaterialIssueDebitNote Serializer
    """

    items = MaterialIssueDebitNoteItemsSerializer(many=True, required=False,
                                                  source="procurement_material_issue_debit_note_items")
    tax_details = MaterialIssueDebitNoteTaxSerializer(many=True, required=False,
                                                      source="procurement_material_issue_debitnotetax")
    def calculate_totals(self, instance: MaterialIssueDebitNote):
        instance.total_item_amount = 0
        instance.total_item_rate = 0
        instance.total_item_qty = 0
        for item in instance.procurement_material_issue_debit_note_items.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_amount += item.amount
                instance.total_item_rate += item.rate
                instance.total_item_qty += item.qty
        for item in instance.procurement_material_issue_debitnotetax.filter(is_deleted=False):
            if not item.is_deleted:
                instance.tax_total_tax_amount += item.total_tax_amount
        instance.save()


    @transaction.atomic
    def create(self, validated_data):
        site = validated_data.pop('site', [])
        store = validated_data.pop('store', [])

        items = validated_data.pop('procurement_material_issue_debit_note_items', [])
        tax_details = validated_data.pop('procurement_material_issue_debitnotetax', [])

        instance = MaterialIssueDebitNote.objects.create(**validated_data)

        # Direct assignment to the forward side of a many-to-many set is prohibited.
        instance.site.set(site) if site else None
        instance.store.set(store) if store else None

        current_user = instance.created_by if instance.created_by else None

        # insert items ✅
        _items = None
        for item in items:
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'id',)]
            _items = MaterialIssueDebitNoteItems.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)

        # insert tax ✅
        _items = None
        for item in tax_details:
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'id',)]
            _items = MaterialIssueDebitNoteTax.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)

        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        items = validated_data.pop('procurement_material_issue_debit_note_items', [])  # 1
        tax_details = validated_data.pop('procurement_material_issue_debitnotetax', []) # 2

        site = validated_data.pop('site', [])
        store = validated_data.pop('store', [])

        for key, value in validated_data.items():
            setattr(instance, key, value)

        instance.site.clear()
        instance.site.set(site)

        instance.store.clear()
        instance.store.set(store)

        
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        # 1. update/insert TaxInvoiceItems ✅
        old_item_ids = [item.pk for item in instance.procurement_material_issue_debit_note_items.filter(is_deleted=False)]
        updated_item_ids = []
        for item in items:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = MaterialIssueDebitNoteItems.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                MaterialIssueDebitNoteItems.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = MaterialIssueDebitNoteItems.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True, updated_by=current_user)
        print('deleted MaterialIssueDebitNoteItems', _)
        self.calculate_totals(instance)

        # 1. update/insert MaterialIssueDebitNoteTax ✅
        old_item_ids = [item.pk for item in instance.procurement_material_issue_debitnotetax.filter(is_deleted=False)]
        updated_item_ids = []
        for item in tax_details:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = MaterialIssueDebitNoteTax.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                MaterialIssueDebitNoteTax.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = MaterialIssueDebitNoteTax.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                                        updated_by=current_user)
        print('deleted MaterialIssueDebitNoteTax', _)
        self.calculate_totals(instance)



        instance.save()
        return instance

    class Meta:
        model = MaterialIssueDebitNote
        fields = '__all__'


class PurchaseReturnAttachmentsSerializer(serializers.ModelSerializer):
    """
    PurchaseReturn Attachments
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PurchaseReturnAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class PurchaseReturnTaxDetailsSerializer(serializers.ModelSerializer):
    """
    PurchaseReturn TaxDetails
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PurchaseReturnTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseReturnItemsNotesSerializer(serializers.ModelSerializer):
    """
    PurchaseReturnItemsNotes Serializer
    """

    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseReturnItemsNotes
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseReturnItemsSerializer(serializers.ModelSerializer):
    """
    PurchaseReturn items
    """
    notes = PurchaseReturnItemsNotesSerializer(many=True, required=False, source="procurement_purchase_return_item_notes")
    id = serializers.IntegerField(required=False)

    # method fields
    material_details = serializers.SerializerMethodField()
    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.material and instance.material_id:
                details = VendorMaterialMaster.cmobjects.filter(pk=instance.material_id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details



    class Meta:
        model = PurchaseReturnItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer



class PurchaseReturnsExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    PurchaseReturnsExpenseDetails Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PurchaseReturnsExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PurchaseReturnSerializer(serializers.ModelSerializer):
    """
        PurchaseReturn Serializer
        master Serializer
    """

    items = PurchaseReturnItemsSerializer(many=True, required=False, source="procurement_purchase_return_items")
    attachments = PurchaseReturnAttachmentsSerializer(many=True, required=False, source="procurement_purchase_return_attachments")
    tax_details = PurchaseReturnTaxDetailsSerializer(many=True, required=False, source="procurement_purchase_return_tax_details")
    po_return_expense = PurchaseReturnsExpenseDetailsSerializer(many=True, required=False, source="procurement_purchase_return_expense")

    def calculate_totals(self, instance: PurchaseReturn):
        instance.total_item_item_weight = 0
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0

        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0

        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.procurement_purchase_return_items.filter(is_deleted=False):
            instance.total_item_item_weight += item.weight
            instance.total_item_item_quantity += item.quantity
            instance.total_item_item_amount += item.item_amount
            instance.total_item_disc_amount += item.disc_amount
            instance.total_item_taxable_amount += item.taxable_amount
            instance.total_item_excise_tax_amount += item.excise_tax_amount
            instance.total_item_tax_amount += item.tax_amount
            instance.total_item_sgst_amount += item.sgst_amount
            instance.total_item_cgst_amount += item.cgst_amount
            instance.total_item_igst_amount += item.igst_amount
            instance.total_item_utgst_amount += item.utgst_amount
            instance.total_item_cess_amount += item.cess_amount
            instance.total_item_total_amount += item.total_amount

        for item in instance.procurement_purchase_return_expense.filter(is_deleted=False):
            if item.included:
                if item.add:
                    instance.total_expense_expense_amount += item.expense_amount
                    instance.total_expense_sgst_amount += item.sgst_amount
                    instance.total_expense_cgst_amount += item.cgst_amount
                    instance.total_expense_igst_amount += item.igst_amount
                    instance.total_expense_utgst_amount += item.utgst_amount
                    instance.total_expense_cess_amount += item.cess_amount
                    instance.total_expense_total_expense_amount += item.total_expense_amount
                else:
                    instance.total_expense_expense_amount -= item.expense_amount
                    instance.total_expense_sgst_amount -= item.sgst_amount
                    instance.total_expense_cgst_amount -= item.cgst_amount
                    instance.total_expense_igst_amount -= item.igst_amount
                    instance.total_expense_utgst_amount -= item.utgst_amount
                    instance.total_expense_cess_amount -= item.cess_amount
                    instance.total_expense_total_expense_amount -= item.total_expense_amount

        for item in instance.procurement_purchase_return_tax_details.filter(is_deleted=False):
            if item.included:
                if item.add:
                    instance.total_tax_tax_amount += item.tax_amount
                    instance.total_tax_sgst_amount += item.sgst_amount
                    instance.total_tax_cgst_amount += item.cgst_amount
                    instance.total_tax_igst_amount += item.igst_amount
                    instance.total_tax_utgst_amount += item.utgst_amount
                    instance.total_tax_cess_amount += item.cess_amount
                    instance.total_tax_total_tax_amount += item.total_tax_amount
                else:
                    instance.total_tax_tax_amount -= item.tax_amount
                    instance.total_tax_sgst_amount -= item.sgst_amount
                    instance.total_tax_cgst_amount -= item.cgst_amount
                    instance.total_tax_igst_amount -= item.igst_amount
                    instance.total_tax_utgst_amount -= item.utgst_amount
                    instance.total_tax_cess_amount -= item.cess_amount
                    instance.total_tax_total_tax_amount -= item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount + instance.total_tax_total_tax_amount + instance.total_expense_total_expense_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        # # M2M
        # site = validated_data.pop('site', [])
        # store = validated_data.pop('store', [])


        # M2O
        items = validated_data.pop('procurement_purchase_return_items', [])
        attachments = validated_data.pop('procurement_purchase_return_attachments', [])
        tax_details = validated_data.pop('procurement_purchase_return_tax_details', [])
        po_return_expense = validated_data.pop('procurement_purchase_return_expense', [])

        instance = PurchaseReturn.objects.create(**validated_data)

        current_user = instance.created_by if instance.created_by else None

        # Direct assignment to the forward side of a many-to-many set is prohibited.
        # instance.site.set(site) if site else None
        # instance.store.set(store) if store else None


        # insert items ✅
        _purchasereturnitems = None
        for item in items:
            item_notes = item.get('procurement_purchase_return_item_notes', [])
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'procurement_purchase_return_item_notes', 'id', )]

            _purchasereturnitems = PurchaseReturnItems.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
            for item_note in item_notes:
                _PurchaseReturnItemsNotes = PurchaseReturnItemsNotes.objects.create(
                    master=_purchasereturnitems,
                    created_by=current_user,
                    **item_note)
        self.calculate_totals(instance)

        # insert tax_details ✅
        for tax_detail in tax_details:
            [tax_detail.pop(k, None) for k in ('organization', 'created_by', 'master', 'id', )]
            _purchasereturntaxdetails = PurchaseReturnTaxDetails.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **tax_detail
            )
        self.calculate_totals(instance)

        # insert po_return_expense ✅
        for item in po_return_expense:
            [item.pop(k, None) for k in ('organization', 'created_by', 'master', 'id', )]
            _details = PurchaseReturnsExpenseDetails.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                **item
            )
        self.calculate_totals(instance)

        # insert attachments ✅
        _purchasereturnattachments = None
        for requested_attachment_data in attachments:
            _purchasereturnattachments = PurchaseReturnAttachments.objects.create(
                organization=instance.organization,
                created_by=current_user,
                master=instance,
                attachment=process_attachments(requested_attachment_data),
                file_data="",
                mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
            )

        # instance.voucher_no = generate_all_code(instance, ['PR'])
        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        # site = validated_data.pop('site', [])
        # store = validated_data.pop('store', [])


        # M2O
        items = validated_data.pop('procurement_purchase_return_items', [])
        attachments = validated_data.pop('procurement_purchase_return_attachments', [])
        tax_details = validated_data.pop('procurement_purchase_return_tax_details', [])
        po_return_expense = validated_data.pop('procurement_purchase_return_expense', [])


        for key, value in validated_data.items():
            setattr(instance, key, value)

        # instance.site.clear()
        # instance.site.set(site)
        #
        # instance.store.clear()
        # instance.store.set(store)

        # update/insert PurchaseReturnItems ✅

        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        old_item_ids = [item.pk for item in instance.procurement_purchase_return_items.filter(is_deleted=False)]
        updated_item_ids = []
        for item in items:
            id = item.pop('id', None)
            item_notes = item.pop('procurement_purchase_return_item_notes', [])
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = PurchaseReturnItems.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                _obj, created = PurchaseReturnItems.objects.update_or_create(pk=id,defaults=item)
                print(f"item update {id} {50 * '*'}")
            update_item_notes_generic2('PurchaseReturnItemsNotes', item_notes, updated_by=current_user, master=_obj)
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = PurchaseReturnItems.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True, updated_by=current_user)
        print('deleted PurchaseReturnItems', _)
        self.calculate_totals(instance)

        # update/insert PurchaseReturnTaxDetails ✅
        old_tax_details_ids = [item.pk for item in instance.procurement_purchase_return_tax_details.filter(is_deleted=False)]
        updated_tax_details_ids = []
        print('tax_details', tax_details)
        for item in tax_details:
            id = item.pop('id', None)
            print(f"ID {60*'!'}", id)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = PurchaseReturnTaxDetails.objects.create(**item)
                id = _obj.pk
            else:
                PurchaseReturnTaxDetails.objects.update_or_create(pk=id, defaults=item)
            updated_tax_details_ids.append(id)
        # soft remove excluded items
        excluded_tax_details_ids = list(set(old_tax_details_ids) - set(updated_tax_details_ids))
        _ = PurchaseReturnTaxDetails.objects.filter(pk__in=excluded_tax_details_ids).update(is_deleted=True, updated_by=current_user)
        print('deleted PurchaseReturnTaxDetails ',_)
        self.calculate_totals(instance)


        # update/insert PurchaseReturnsExpenseDetails ✅
        old_item_ids = [item.pk for item in instance.procurement_purchase_return_expense.filter(is_deleted=False)]
        updated_item_ids = []
        for item in po_return_expense:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': current_user},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = PurchaseReturnsExpenseDetails.objects.create(**item)
                id = _obj.pk
            else:
                _obj, created = PurchaseReturnsExpenseDetails.objects.update_or_create(pk=id, defaults=item)
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = PurchaseReturnsExpenseDetails.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True, updated_by=current_user)
        print('deleted PurchaseReturnsExpenseDetails', _)
        self.calculate_totals(instance)
        ##


        # update/insert attachments ✅
        for requested_attachment_data in attachments:
            id = requested_attachment_data.pop('id', None)
            if not id:
                print('attachment added')
                PurchaseReturnAttachments.objects.create(
                    organization=instance.organization,
                    master=instance,
                    created_by=current_user,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                )
            else:
                print(f'attachment updated {id}')
                PurchaseReturnAttachments.objects.update_or_create(
                    pk=id,
                    defaults={
                        "master": instance,
                        "organization": instance.organization,
                        "attachment": process_attachments(requested_attachment_data),
                        "updated_by": current_user,
                        "attachment_name": requested_attachment_data.get('attachment_name', None),
                    }
                )


        instance.save()
        return instance


    # method fields
    vendor_details = serializers.SerializerMethodField()
    grn_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()

    def get_vendor_details(self, instance):
        vendor_name = None
        try:
            if instance.vendor_id:
                vendor_name=get_vendor_data(instance.vendor)
        except Exception as e:
            print('ERROR', e)
        return vendor_name

    def get_grn_details(self, instance):
        grn_name = None
        if instance.grn and instance.grn_id:
            grn_name = GRN.cmobjects.filter(pk=instance.grn_id).values()
        return grn_name

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_name = projectdata.value if projectdata else ''
        return instance.project.project_name if instance.project else ''

    def get_project_code(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()
        # # project_details
        # formmaster = FormMaster.cmobjects.filter(form_type='project_details', form_internal_name='project_id').first()
        # projectdata = ProjectData.cmobjects.filter(project=project, form=formmaster).last()
        # project_code = projectdata.value if projectdata else ''
        return instance.project.project_code if instance.project else ''

    class Meta:
        model = PurchaseReturn
        fields = '__all__'


class CommunicationTypeSerializer(serializers.ModelSerializer):
    """"
    Procurement Communciation Type Serializer(model in procurement app)
    """

    class Meta:
        model = CommunicationType
        fields = '__all__'


class CommunicationSerializer(serializers.ModelSerializer):
    """Serializer for communication model"""
    communication_type_details = serializers.SerializerMethodField()
    from_master_details = serializers.SerializerMethodField()
    to_master_details = serializers.SerializerMethodField()

    def get_communication_type_details(self, instance):
        details = None
        if instance.communication_type and instance.communication_type_id:
            details = CommunicationType.cmobjects.filter(pk=instance.communication_type_id).values()
        return details
    def get_from_master_details(self, instance):
        details = None
        if instance.from_master :
            details = { 'id': instance.from_master.id,
                        'name': instance.from_master.name if instance.from_master else None

            } 
        return details
    def get_to_master_details(self, instance):
        details = None
        if instance.to_master :
            details = { 'id': instance.to_master.id,
                        'name': instance.to_master.name if instance.to_master else None

            } 
        return details
    
    class Meta:
        model = Communication
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        file_data = validated_data.pop('file_data', '')
        mime_type = validated_data.pop('mime_type', '')
        file_name = validated_data.pop('file_name', '')  # Get the file_name from validated_data
        try:
            attachment_content = process_attachments({'mime_type': mime_type,'file_data': file_data})
            attachment_content.name = f"{file_name}"
            communication = Communication.objects.create(
                attachment=attachment_content,
                **validated_data
            )
            return communication  # Return the created instance
        except Exception as e:
            print(f"Exception while create communication: {str(e)}")
            return None
    
    @transaction.atomic
    def update(self, instance, validated_data):
        file_data = validated_data.pop('file_data', '')
        mime_type = validated_data.pop('mime_type', '')
        file_name = validated_data.pop('file_name', '')  # Get the file_name from validated_data
        
        try:
            if file_data:
                attachment_content = process_attachments({'mime_type': mime_type,'file_data': file_data})
                attachment_content.name = f"{file_name}"
                instance.attachment = attachment_content

            for field, value in validated_data.items():
                setattr(instance, field, value)
            instance.save()

            return instance

        except Exception as e:
            print(f"Exception while updating communication: {str(e)}")
            return None

from vendor.serializers import VendorMasterV2Serializer

class VendorDatabaseSerializer(serializers.ModelSerializer):
    vendor_details = serializers.SerializerMethodField()
    def get_vendor_details(self, instance):

        vendor_name = None
        try:
            if instance.vendor_id:
                # vendor_name=get_vendor_data(instance.vendor)
                vendor_name= VendorMasterV2Serializer(instance.vendor).data

        except Exception as e:
            print('ERROR', e)
        return vendor_name
    class Meta:
        model = VendorDatabase
        fields = '__all__'

class StockTransferredItemsSerializer(serializers.ModelSerializer):
    """"
    Procurement Stock Transferred Item Serializer
    """
    id = serializers.IntegerField(required=False)

    material_details = serializers.SerializerMethodField()
    unit_of_mesurement_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()

    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()

    class Meta:
        model = StockTransferredItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.material and instance.material.id:
                details = VendorMaterialMaster.cmobjects.filter(pk=instance.material.id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details

    def get_plant_machinery_machine_details(self, instance):
        return_details = {}
        try:
            if instance.plant_machinery_machine and instance.plant_machinery_machine_id:
                details = PlantMachineryMachine.cmobjects.filter(pk=instance.plant_machinery_machine_id).first()
                serializer = PlantMachineryMachineSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details
    
    def get_unit_of_mesurement_details(self, instance):
        details=None
        if instance.uom and instance.uom.id:
            details = UnitOfMesurement.cmobjects.filter(id=instance.uom.id).values()
        return details

    

   


    # approved_by
    def get_created_by_details(self, instance):
        _details = None
        if instance.created_by and instance.created_by_id:
            _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
        return _details
    def get_checked_by_details(self, instance):
        _details = None
        if instance.checked_by and instance.checked_by_id:
            _details = PmsUser.objects.filter(pk=instance.checked_by_id).values('first_name', 'last_name', 'email')
        return _details
    def get_cancelled_by_details(self, instance):
        _details = None
        if instance.cancelled_by and instance.cancelled_by_id:
            _details = PmsUser.objects.filter(pk=instance.cancelled_by_id).values('first_name', 'last_name', 'email')
        return _details
    def get_close_by_details(self, instance):
        _details = None
        if instance.close_by and instance.close_by_id:
            _details = PmsUser.objects.filter(pk=instance.close_by_id).values('first_name', 'last_name', 'email')
        return _details
    def get_approved_by_details(self, instance):
        _details = None
        if instance.approved_by and instance.approved_by_id:
            _details = PmsUser.objects.filter(pk=instance.approved_by_id).values('first_name', 'last_name', 'email')
        return _details
    def get_rejected_by_details(self, instance):
        _details = None
        if instance.rejected_by and instance.rejected_by_id:
            _details = PmsUser.objects.filter(pk=instance.rejected_by_id).values('first_name', 'last_name', 'email')
        return _details






class StockTransferredSerializer(serializers.ModelSerializer):
    """
    Procurement Stock Transferred Serializer
    """
    stock_transferred_items = StockTransferredItemsSerializer(many=True,required=False, source="procurement_stock_transferred_items_stock_transferred")

    organization_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    target_store_details = serializers.SerializerMethodField()
    target_project_name = serializers.SerializerMethodField()
    created_by_name = serializers.SerializerMethodField()
    approved_by_name = serializers.SerializerMethodField()
    total_req_item_qty = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    target_site_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()

    class Meta:
        model = StockTransferred
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        stock_transferred_items_data = validated_data.pop('procurement_stock_transferred_items_stock_transferred')
        stock_transferred = StockTransferred.objects.create(**validated_data)
        current_user = stock_transferred.created_by if stock_transferred.created_by else None

        for requested_item_data in stock_transferred_items_data:
            StockTransferredItems.objects.create(stock_transferred=stock_transferred, created_by=current_user, **requested_item_data)

        stock_transferred.save()
        return stock_transferred

    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        print(current_user)
        items_data = validated_data.get('procurement_stock_transferred_items_stock_transferred', [])
        existing_items = instance.procurement_stock_transferred_items_stock_transferred.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                StockTransferredItems.objects.create(stock_transferred=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        stock_transferred_items_data = representation.pop('stock_transferred_items', [])
        representation['stock_transferred_items'] = stock_transferred_items_data
        # filtered_items = [item for item in stock_transferred_items_data if not item.get('is_deleted', False)]
        # representation['stock_transferred_items'] = filtered_items
        return representation

    ## custom method fields
    def get_organization_details(self, instance):
        key_list = Organization.objects.filter(pk=instance.organization_id).values()
        _key_list = list(key_list)
        city_id = _key_list[0]["org_city_id"] if _key_list and _key_list[0] else 0
        state_id = _key_list[0]["org_state_id"] if _key_list and _key_list[0] else 0
        country_id = _key_list[0]["org_country_id"] if _key_list and _key_list[0] else 0

        city_obj = City.objects.filter(pk=int(city_id)).first()
        city_name = city_obj.name if city_obj else None

        state_obj = State.objects.filter(pk=int(state_id)).first()
        state_name = state_obj.name if state_obj else None

        country_obj = Country.objects.filter(pk=int(country_id)).first()
        country_name = country_obj.name if country_obj else None
        address = f"{city_name} {state_name} {country_name}"
        _key_list.append({'organization_address': address})
        return _key_list

    def get_store_details(self, instance):
        key_list = StoreMaster.objects.filter(pk=instance.store_id).values()
        _key_list = list(key_list)
        site_obj=None
        if instance.store and instance.store.site_id:
            site_obj = SiteMaster.objects.filter(pk=instance.store.site_id).first()
        address = f'{site_obj.location if site_obj else None } '
        _key_list.append({"store_address": address})
        return _key_list
    def get_target_store_details(self, instance):
        key_list = StoreMaster.objects.filter(pk=instance.target_store_id).values()
        _key_list = list(key_list)
        site_obj=None
        if instance.target_store and instance.target_store.site_id:
            site_obj = SiteMaster.objects.filter(pk=instance.target_store.site_id).first()
        address = f'{site_obj.location if site_obj else None } '
        _key_list.append({"store_address": address})
        return _key_list

    def get_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.project_id).first()

        # formmaster = FormMaster.objects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.objects.filter(project=project, form=formmaster)

        # project_name = ''
        # for item in projectdata:
        #     if item:
        #         project_name = item.value
        return instance.project.project_name if instance.project else ''
    def get_target_project_name(self, instance):
        # project = ProjectMaster.objects.filter(pk=instance.target_project_id).first()

        # formmaster = FormMaster.objects.filter(form_type='project_details', form_internal_name='project_name').first()
        # projectdata = ProjectData.objects.filter(project=project, form=formmaster)

        # project_name = ''
        # for item in projectdata:
        #     if item:
        #         project_name = item.value
        return instance.target_project.project_name if instance.target_project else ''

    def get_created_by_name(self, instance):
        first_name = instance.created_by.first_name if instance.created_by else ''
        last_name = instance.created_by.last_name if instance.created_by else ''
        return first_name + ' ' + last_name

    def get_approved_by_name(self, instance):
        name = ''
        if instance.status == 'approved':
            name = instance.approved_by.user_full_name if instance.approved_by else ''
        return name

    def get_total_req_item_qty(self, instance):
        qty = 0.0
        items = StockTransferredItems.objects.filter(stock_transferred=instance)
        for i in items:
            qty += float(i.quantity)
        return qty

   

    def get_site_details(self, instance):
        details = None
        if instance.site and instance.site_id:
            details = SiteMaster.objects.filter(pk=instance.site_id).values()
        return details
    def get_target_site_details(self, instance):
        details = None
        if instance.target_site and instance.target_site_id:
            details = SiteMaster.objects.filter(pk=instance.target_site_id).values()
        return details
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by and instance.created_by_id:
            details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
        return details

    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by and instance.checked_by_id:
            details = PmsUser.objects.filter(pk=instance.checked_by_id).values('first_name', 'last_name', 'email')
        return details

    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by and instance.cancelled_by_id:
            details = PmsUser.objects.filter(pk=instance.cancelled_by_id).values('first_name', 'last_name', 'email')
        return details

    def get_close_by_details(self, instance):
        details = None
        if instance.close_by and instance.close_by_id:
            details = PmsUser.objects.filter(pk=instance.close_by_id).values('first_name', 'last_name', 'email')
        return details

    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by and instance.approved_by_id:
            details = PmsUser.objects.filter(pk=instance.approved_by_id).values('first_name', 'last_name', 'email')
        return details

    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by and instance.rejected_by_id:
            details = PmsUser.objects.filter(pk=instance.rejected_by_id).values('first_name', 'last_name', 'email')
        return details


class MaterialDispatchItemsSerializer(serializers.ModelSerializer):
    """
    Material Dispatch Items Serializer
    """
    id = serializers.IntegerField(required=False)
    
    material_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()

    class Meta:
        model = MaterialDispatchItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.material and instance.material.id:
                details = VendorMaterialMaster.objects.filter(pk=instance.material.id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)
        return return_details

    def get_plant_machinery_machine_details(self, instance):
        return_details = {}
        try:
            if instance.plant_machinery_machine and instance.plant_machinery_machine_id:
                details = PlantMachineryMachine.objects.filter(pk=instance.plant_machinery_machine_id).first()
                serializer = PlantMachineryMachineSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)
        return return_details
    
    def get_uom_details(self, instance):
        details = None
        if instance.uom and instance.uom.id:
            details = UnitOfMesurement.objects.filter(id=instance.uom.id).values()
        return details


class MaterialDispatchSerializer(serializers.ModelSerializer):
    """
    Material Dispatch Serializer
    """
    material_dispatch_items = MaterialDispatchItemsSerializer(many=True, required=False, source="procurement_material_dispatch_items_material_dispatch")

    organization_details = serializers.SerializerMethodField()
    source_site_details = serializers.SerializerMethodField()
    source_store_details = serializers.SerializerMethodField()
    source_project_details = serializers.SerializerMethodField()
    destination_site_details = serializers.SerializerMethodField()
    destination_store_details = serializers.SerializerMethodField()
    destination_project_details = serializers.SerializerMethodField()
    intransit_by_details = serializers.SerializerMethodField()
    received_by_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()
    class Meta:
        model = MaterialDispatch
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        
        material_dispatch_items_data = validated_data.pop('procurement_material_dispatch_items_material_dispatch', [])
        material_dispatch = MaterialDispatch.objects.create(**validated_data)
        current_user = material_dispatch.created_by if material_dispatch.created_by else None

        for item_data in material_dispatch_items_data:
            MaterialDispatchItems.objects.create(material_dispatch=material_dispatch, created_by=current_user, **item_data)

        material_dispatch.save()
        return material_dispatch

    @transaction.atomic
    def update(self, instance, validated_data):
        print("validd",validated_data)
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        print(current_user)
        items_data = validated_data.get('procurement_material_dispatch_items_material_dispatch', [])
        existing_items = instance.procurement_material_dispatch_items_material_dispatch.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                MaterialDispatchItems.objects.create(material_dispatch=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        material_dispatch_items_data = representation.pop('material_dispatch_items', [])
        representation['material_dispatch_items'] = material_dispatch_items_data
        return representation

    def get_organization_details(self, instance):
        key_list = Organization.objects.filter(pk=instance.organization_id).values()
        return key_list

    def get_source_site_details(self, instance):
        details = None
        if instance.source_site and instance.source_site_id:
            details = SiteMaster.objects.filter(pk=instance.source_site_id).values()
        return details

    def get_source_store_details(self, instance):
        details = None
        if instance.source_store and instance.source_store_id:
            details = StoreMaster.objects.filter(pk=instance.source_store_id).values()
        return details

    def get_source_project_details(self, instance):
        project = instance.source_project
        if project:
            return get_project_data(instance.source_project.id)
        return None


    def get_destination_site_details(self, instance):
        details = None
        if instance.destination_site and instance.destination_site_id:
            details = SiteMaster.objects.filter(pk=instance.destination_site_id).values()
        return details

    def get_destination_store_details(self, instance):
        details = None
        if instance.destination_store and instance.destination_store_id:
            details = StoreMaster.objects.filter(pk=instance.destination_store_id).values()
        return details

    def get_destination_project_details(self, instance):
       
        project = instance.destination_project
        if project:
            return get_project_data(instance.destination_project.id)
        return None
    def get_intransit_by_details(self, instance):
        details = None
        if instance.intransit_by and instance.intransit_by_id:
            details = PmsUser.objects.filter(pk=instance.intransit_by_id).values('first_name', 'last_name', 'email')
        return details

    def get_received_by_details(self, instance):
        details = None
        if instance.received_by and instance.received_by_id:
            details = PmsUser.objects.filter(pk=instance.received_by_id).values('first_name', 'last_name', 'email')
        return details        

    def get_created_by_details(self, instance):
        details = None
        if instance.created_by and instance.created_by_id:
            details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
        return details    
    


class EnquiryAtOnceVendorsSerializer(serializers.ModelSerializer):
    """
    Serializer for EnquiryAtOnceVendors model
    """
    id = serializers.IntegerField(required=False)
    
    class Meta:
        model = EnquiryAtOnceVendors
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class EnquiryAtOnceItemsSerializer(serializers.ModelSerializer):
    """
    Serializer for EnquiryAtOnceItems model
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = EnquiryAtOnceItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class EnquiryAtOnceSerializer(serializers.ModelSerializer):
    """
    Serializer for EnquiryAtOnce model
    """
    enquiry_at_once_vendors = EnquiryAtOnceVendorsSerializer(many=True, required=False, source="procurement_enquiry_at_once_vendors")
    enquiry_at_once_items = EnquiryAtOnceItemsSerializer(
        many=True, required=False, source="procurement_enquiry_at_once_item_enquiry_at_once"
    )
    indents_details = serializers.SerializerMethodField()

    class Meta:
        model = EnquiryAtOnce
        fields = '__all__'
    def get_indents_details(self, instance):
        _details = []
        if instance.indents:
            _obj = instance.indents.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = Indent.cmobjects.filter(pk__in=(_ids)).values()
        return _details
    @transaction.atomic
    def create(self, validated_data):
        enquiry_at_once_vendors_data = validated_data.pop('procurement_enquiry_at_once_vendors', [])
        enquiry_at_once_items_data = validated_data.pop('procurement_enquiry_at_once_item_enquiry_at_once', [])
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])



        enquiry_at_once = EnquiryAtOnce.objects.create(**validated_data)
        # enquiry_at_once.request_code = generate_all_code(enquiry_at_once,['ENQUIRY'])

        current_user = enquiry_at_once.created_by if enquiry_at_once.created_by else None
        enquiry_at_once.indents.set(indents) if indents else None
        enquiry_at_once.material_requests.set(material_requests) if material_requests else None


        for vendor_data in enquiry_at_once_vendors_data:
            EnquiryAtOnceVendors.objects.create(enquiry_at_once=enquiry_at_once, created_by=current_user, **vendor_data)
        for item_data in enquiry_at_once_items_data:
            EnquiryAtOnceItems.objects.create(
                enquiry_at_once=enquiry_at_once, created_by=current_user, **item_data
            )
        enquiry_at_once.save()
        return enquiry_at_once

    @transaction.atomic
    def update(self, instance, validated_data):
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])


        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        if indents:
            instance.indents.clear()
            instance.indents.set(indents)
        if material_requests:
            instance.material_requests.clear()
            instance.material_requests.set(material_requests)    
        vendors_data = validated_data.get('procurement_enquiry_at_once_vendors', [])
        items_data = validated_data.pop('procurement_enquiry_at_once_item_enquiry_at_once', [])

        existing_vendors = instance.procurement_enquiry_at_once_vendors.filter(is_deleted=False)

        for vendor_data in vendors_data:
            vendor_id = vendor_data.get('id')
            existing_vendor = next((vendor for vendor in existing_vendors if vendor.id == vendor_id), None)
            if not existing_vendor:
                EnquiryAtOnceVendors.objects.create(enquiry_at_once=instance, created_by=current_user, **vendor_data)
            else:
                for field in existing_vendor._meta.fields:
                    field_name = field.name
                    if field_name in vendor_data:
                        setattr(existing_vendor, field_name, vendor_data[field_name])
                setattr(existing_vendor, 'updated_by', current_user)
                existing_vendor.save()

        for existing_vendor in existing_vendors:
            if existing_vendor.id not in [data.get('id') for data in vendors_data]:
                setattr(existing_vendor, 'is_deleted', True)
                setattr(existing_vendor, 'updated_by', current_user)
                existing_vendor.save()
        
        existing_items = instance.procurement_enquiry_at_once_item_enquiry_at_once.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if not existing_item:
                EnquiryAtOnceItems.objects.create(enquiry_at_once=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        enquiry_at_once_vendors_data = representation.pop('enquiry_at_once_vendors', [])
        representation['enquiry_at_once_vendors'] = enquiry_at_once_vendors_data
        representation['enquiry_at_once_items'] = representation.pop('enquiry_at_once_items', [])


        return representation

    

class CommunicationMasterSerializer(serializers.ModelSerializer):
    """"
     CostCenter Serializer
    """
 
    class Meta:
        model = CommunicationMaster
        fields = '__all__'

class CSTAttachmentsSerializer(serializers.ModelSerializer):
    """
    CST Attachments Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = CSTAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class CSTTermsAndConditionsSerializer(serializers.ModelSerializer):
    """"
    CSTTermsAndConditions Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = CSTTermsAndConditions
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class CSTTaxDetailsSerializer(serializers.ModelSerializer):
    """"
    CSTTaxDetails Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = CSTTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class CSTExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    CSTExpenseDetails Serializer
    """
    id = serializers.IntegerField(required=False)
    expense_details = serializers.SerializerMethodField()

    def get_expense_details(self, instance):
        details = None
        if instance.expense_head:
            details = get_details_from_instance(instance.expense_head)
        return details
    class Meta:
        model = CSTExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class CSTStagesSerializer(serializers.ModelSerializer):
    """
    Procurement CSTStages Serializer
    """
    id = serializers.IntegerField(required=False)
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    
    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    
    class Meta:
        model = CSTStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class CSTItemsSerializer(serializers.ModelSerializer):
    """
    Procurement CSTItems Serializer
    """
    id = serializers.IntegerField(required=False)
    material_details = serializers.SerializerMethodField()
    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)   
        return return_details
     
    class Meta:
        model = CSTItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
   
class CSTSerializer(serializers.ModelSerializer):
    """
    Serializer for Comparison Statement (CST)
    """
    stages = CSTStagesSerializer(many=True, required=False, source="procurement_cst_stages")
    items = CSTItemsSerializer(many=True, required=False, source="procurement_cst_item_cst")

    terms_and_conditions = CSTTermsAndConditionsSerializer(many=True,required=False,source="procurement_cst_terms_and_conditions_cst")
    attachments = CSTAttachmentsSerializer(many=True,required=False,source="procurement_cst_attachments_cst")
    cst_tax = CSTTaxDetailsSerializer(many=True,required=False,source="procurement_cst_tax_cst")
    cst_expense = CSTExpenseDetailsSerializer(many=True,required=False,source="procurement_cst_expense_cst")
    organization_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    multi_stage_details = serializers.SerializerMethodField()
    indents_details = serializers.SerializerMethodField()
    material_requests_details = serializers.SerializerMethodField()
    rfq_vendor_details = serializers.SerializerMethodField()
    status_details = serializers.SerializerMethodField()
    ref_link = serializers.SerializerMethodField()
    selected_quotation_list = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    purchase_order_ids = serializers.SerializerMethodField()
    purchase_order_sap_codes = serializers.SerializerMethodField()
    inco_term_one_for_sap_details = serializers.SerializerMethodField()

    class Meta:
        model = CST
        fields = '__all__'

    def get_inco_term_one_for_sap_details(self, instance):
        return get_details_from_instance(instance.inco_term_one_for_sap, type="dict")

    def get_purchase_order_ids(self, instance):
        return  instance.procurement_purchase_order_cst.filter(is_deleted=False).values_list('id',flat=True)
    def get_purchase_order_sap_codes(self, instance):
        return  instance.procurement_purchase_order_cst.filter(is_deleted=False).values_list('sap_code',flat=True)
    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, type="dict")
    def get_selected_quotation_list(self, instance):
        return instance.procurement_purchase_order_cst.values_list('quotation_id', flat=True)

    def get_ref_link(self, instance):
        # details = str(os.getenv('FE_BUDGETED_CST','')) if instance.is_budgeted == True else str(os.getenv('FE_NONBUDGETED_CST',''))
        # return details + str(instance.rfq_vendor.id if instance.rfq_vendor else None) + '/' + str(instance.id) 
        return str(os.getenv('FE_CST_DETAILS', '#')).format(cst_id = str(instance.id))

    def get_rfq_vendor_details(self, instance):
        details = None
        if instance.rfq_vendor:
            details = get_details_from_instance(instance.rfq_vendor,type='dict')
        return details
    
    def get_indents_details(self, instance):
        _details = []
        if instance.indents:
            _obj = instance.indents.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = Indent.cmobjects.filter(pk__in=(_ids)).values()
        return _details
    def get_material_requests_details(self, instance):
        _details = []
        if instance.material_requests:
            _obj = instance.material_requests.filter(is_deleted=False)
            _ids = [o.pk for o in _obj]
            if _ids:
                _details = MaterialRequestMaster.cmobjects.filter(pk__in=(_ids)).values()
        return _details
    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)

    def get_status_details(self, instance):
        return multi_stage_status_details(instance, self.get_multi_stage_details(instance), 'checked')

    def get_organization_details(self, instance):
        key_list = get_details_from_instance(instance.organization)
        city_name = None
        if instance.organization and instance.organization.org_city:
            city_obj = get_details_from_instance(instance.organization.org_city, type="dict")
            city_name = city_obj['name'] if city_obj else None
        state_name = None
        if instance.organization and instance.organization.org_state:
            state_obj = get_details_from_instance(instance.organization.org_state, type="dict")
            state_name = state_obj['name'] if state_obj else None
        country_name = None
        if instance.organization and instance.organization.org_country:
            country_obj = get_details_from_instance(instance.organization.org_country, type="dict")
            country_name = country_obj['name'] if country_obj else None

        address = f"{city_name} {state_name} {country_name}"
        key_list.append({'organization_address': address})
        return key_list

    def get_store_details(self, instance):
        details = None
        if instance.store:
            details = get_details_from_instance(instance.store)
        return details

    def get_project_details(self, instance):
        project = instance.project
        if project:
            return get_project_data( instance.project.id)
        return None

    def get_site_details(self, instance):
        details = None
        if instance.site:
            details = get_details_from_instance(instance.site)
        return details

    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details

   
    def calculate_totals(self, instance):
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.procurement_cst_item_cst.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount

        for item in instance.procurement_cst_expense_cst.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

        for item in instance.procurement_cst_tax_cst.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])
        items_data = validated_data.pop('procurement_cst_item_cst', [])
        requested_attachment = validated_data.pop('procurement_cst_attachments_cst', [])
        terms_and_conditions = validated_data.pop('procurement_cst_terms_and_conditions_cst', [])
        tax_data = validated_data.pop('procurement_cst_tax_cst', [])
        expense_data = validated_data.pop('procurement_cst_expense_cst', [])
        cst = CST.objects.create(**validated_data)
        # cst.request_code = generate_all_code(cst,['CST'])
        # cst.save()
        cst.indents.set(indents) if indents else None
        cst.material_requests.set(material_requests) if material_requests else None

       
        current_user = cst.created_by if cst.created_by else None
        for requested_attachment_data in requested_attachment:
            try:
                attachment = CSTAttachments.objects.create(
                    organization=cst.organization,
                    cst=cst,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")

        for item_data in items_data:
            CSTItems.objects.create(cst=cst, **item_data,created_by=current_user)
        self.calculate_totals(cst)
        for terms_and_conditions_data in terms_and_conditions:
            CSTTermsAndConditions.objects.create(cst=cst,created_by=current_user,**terms_and_conditions_data)

        for cst_expense_data in expense_data:
            CSTExpenseDetails.objects.create(cst=cst,created_by=current_user,**cst_expense_data)
        self.calculate_totals(cst)

        for cst_tax_data in tax_data:
            CSTTaxDetails.objects.create(cst=cst,created_by=current_user,**cst_tax_data)
        self.calculate_totals(cst)
        cst.save()
        return cst
    @transaction.atomic
    def update(self, instance, validated_data):
        items_data = validated_data.pop('procurement_cst_item_cst', [])
        attachments_data = validated_data.get('procurement_cst_attachments_cst', [])
        terms_and_conditions = validated_data.pop('procurement_cst_terms_and_conditions_cst', [])
        tax_data = validated_data.pop('procurement_cst_tax_cst', [])
        expense_data = validated_data.pop('procurement_cst_expense_cst', [])
        indents = validated_data.pop('indents', [])
        material_requests = validated_data.pop('material_requests', [])
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        if indents:
            instance.indents.clear()
            instance.indents.set(indents)
        if material_requests:
            instance.material_requests.clear()
            instance.material_requests.set(material_requests)    
       

        existing_items = instance.procurement_cst_item_cst.filter(is_deleted=False)
        for item_data in items_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if not existing_item:
                CSTItems.objects.create(cst=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        self.calculate_totals(instance)
        ## for po direct##  
        existing_attachments = instance.procurement_cst_attachments_cst.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                existing_attachment = CSTAttachments.objects.create(
                    organization=instance.organization,
                    cst=instance,
                    attachment=temp_attach_data,
                    file_data="",
                    mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save() 

        existing_terms_and_conditions = instance.procurement_cst_terms_and_conditions_cst.filter(is_deleted=False)
        for terms_and_conditions_data_item in terms_and_conditions:
            terms_and_conditions_id = terms_and_conditions_data_item.get('id')
            existing_terms_and_conditions_item = next(
                (item for item in existing_terms_and_conditions if item.id == terms_and_conditions_id), None)

            if not existing_terms_and_conditions_item:
                [terms_and_conditions_data_item.pop(k, None) for k in ('organization', 'updated_by', 'id',)]
                existing_terms_and_conditions_item = CSTTermsAndConditions.objects.create(
                    cst=instance,
                    organization=instance.organization,
                    created_by=current_user,
                    **terms_and_conditions_data_item
                )
            else:
                for field in existing_terms_and_conditions_item._meta.fields:
                    field_name = field.name
                    if field_name in terms_and_conditions_data_item:
                        setattr(existing_terms_and_conditions_item, field_name, terms_and_conditions_data_item[field_name])
                setattr(existing_terms_and_conditions_item, 'updated_by', current_user)
                existing_terms_and_conditions_item.save()

        for existing_terms_and_conditions_item in existing_terms_and_conditions:
            if existing_terms_and_conditions_item.id not in [item.get('id') for item in terms_and_conditions]:
                setattr(existing_terms_and_conditions_item, 'is_deleted', True)
                setattr(existing_terms_and_conditions_item, 'updated_by', instance.updated_by)
                existing_terms_and_conditions_item.save() 
        
        existing_expense = instance.procurement_cst_expense_cst.filter(is_deleted=False)
        for expense_data_item in expense_data:
            expense_id = expense_data_item.get('id')
            existing_expense_item = next(
                (item for item in existing_expense if item.id == expense_id), None)

            if not existing_expense_item:
                existing_expense_item = CSTExpenseDetails.objects.create(
                    cst=instance,
                    created_by=current_user,
                    **expense_data_item
                )
            else:
                for field in existing_expense_item._meta.fields:
                    field_name = field.name
                    if field_name in expense_data_item:
                        setattr(existing_expense_item, field_name, expense_data_item[field_name])
                setattr(existing_expense_item, 'updated_by', current_user)
                existing_expense_item.save()

        for existing_expense_item in existing_expense:
            if existing_expense_item.id not in [item.get('id') for item in expense_data]:
                setattr(existing_expense_item, 'is_deleted', True)
                setattr(existing_expense_item, 'updated_by', current_user)
                existing_expense_item.save()
        self.calculate_totals(instance)   
        existing_tax = instance.procurement_cst_tax_cst.filter(is_deleted=False)
        for tax_data_item in tax_data:
            tax_id = tax_data_item.get('id')
            existing_tax_item = next(
                (item for item in existing_tax if item.id == tax_id), None)
            if not existing_tax_item:
                existing_tax_item = CSTTaxDetails.objects.create(
                    cst=instance,
                    created_by=current_user,
                    **tax_data_item
                )
            else:
                for field in existing_tax_item._meta.fields:
                    field_name = field.name
                    if field_name in tax_data_item:
                        setattr(existing_tax_item, field_name, tax_data_item[field_name])
                setattr(existing_tax_item, 'updated_by', current_user)
                existing_tax_item.save()

        for existing_tax_item in existing_tax:
            if existing_tax_item.id not in [item.get('id') for item in tax_data]:
                setattr(existing_tax_item, 'is_deleted', True)
                setattr(existing_tax_item, 'updated_by', current_user)
                existing_tax_item.save()
        self.calculate_totals(instance)                  
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        stages_data = representation.pop('stages', [])
        representation['stages'] = stages_data
        return representation

class SAPMastersSerializer(serializers.ModelSerializer):
    """
    Serializer for SAPMasters
    """
    class Meta:
        model = SAPMasters
        fields = '__all__'        

class BOIProcurementTrackerSerializer(serializers.ModelSerializer):
    """
    Serializer for BOIProcurementTracker
    """
    wbs_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()
    mr_po_details = serializers.SerializerMethodField()
    requested_material_details = serializers.SerializerMethodField()
    
    @transaction.atomic
    def create(self, validated_data):
        wbs = validated_data.pop('wbs', [])
        instance = BOIProcurementTracker.objects.create(**validated_data)
        instance.wbs.set(wbs) if wbs else None
        instance.save()    
        return instance
    @transaction.atomic
    def update(self, instance, validated_data):
        wbs = validated_data.pop('wbs', [])
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        if wbs:
            instance.wbs.clear()
            instance.wbs.set(wbs)
        instance.save()
        return instance

    class Meta:
        model = BOIProcurementTracker
        fields = '__all__'
    
    def get_requested_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material and instance.requested_material.id:
                details = VendorMaterialMaster.objects.filter(pk=instance.requested_material.id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)
        return return_details
   
    def get_mr_po_details(self, instance):
        data = (
            MaterialRequestMasterItems.cmobjects.filter(
                requested_material=instance.requested_material,material_request__project_id=instance.project_id
            ).values(
                'requested_material_id',
            ).annotate(
                rfq_vendors__date=Subquery(
                    RFQVendorsItems.cmobjects.filter(
                        material_request_item_id=OuterRef('pk'),
                        rfq_vendors__is_deleted=False,
                        rfq_vendors__is_archived=False
                    ).order_by().values('material_request_item_id').annotate(
                            value=GroupConcat('rfq_vendors__date', distinct=True)
                        ).values('value')
                ),
                purchase_order__date=Subquery(
                    PurchaseOrderItems.cmobjects.filter(
                        material_request_item_id=OuterRef('pk'),
                        purchase_order__is_deleted=False  
                    ).order_by().values('material_request_item_id').annotate(
                            value=GroupConcat('purchase_order__date', distinct=True)
                        ).values('value')
                ),
              
                purchase_order__vendor__vendor_name=Subquery(
                    PurchaseOrderItems.cmobjects.filter(
                        material_request_item_id=OuterRef('pk'),
                        purchase_order__is_deleted=False  
                    ).order_by().values('material_request_item_id').annotate(
                            value=GroupConcat('purchase_order__vendor__vendor_name', distinct=True)
                        ).values('value')
                ),
                quotation__count=Coalesce(
                    Subquery(
                        QuotationItems.cmobjects.filter(
                            material_request_item_id=OuterRef('pk'),
                            quotation__is_deleted=False
                        ).order_by().values('material_request_item_id')
                        .annotate(total_count=Count('id'))
                        .values('total_count')
                    ),Value(0)
                ),
                approved_by_date=GroupConcat('approved_by_date__date',distinct=True),
                lead_time_mr_to_po_day_count=Subquery(
                    PurchaseOrderItems.cmobjects.filter(
                        material_request_item_id=OuterRef('pk'),
                        purchase_order__is_deleted=False  


                    ).order_by().values('material_request_item_id').annotate(
                        value= ExpressionWrapper(
                    Coalesce(Sum(Func(
                        OuterRef('material_request__date'),
                        F('purchase_order__date'),
                        function='TIMESTAMPDIFF',
                        template="%(function)s(SECOND, %(expressions)s)",
                        output_field=IntegerField() 
                    )), Value(0), output_field=FloatField())/ 86400, 
                    output_field=IntegerField() 
                ),
                    ).values('value')
                ),
                lead_time_po_to_grn_day_count=Subquery(
                    GRNItems.cmobjects.filter(
                        material_request_item_id=OuterRef('pk'),
                        grn__is_deleted=False  
                    ).values('material_request_item_id').annotate(
                        value=ExpressionWrapper(
                            Coalesce(
                                Sum(Func(
                                    F('purchase_order_item__purchase_order__date'),  
                                    F('grn__date'),
                                    function='TIMESTAMPDIFF',
                                    template="%(function)s(SECOND, %(expressions)s)",
                                    output_field=IntegerField()
                                )), Value(0), output_field=FloatField()
                            ) / 86400,  
                            output_field=IntegerField()
                        )
                    ).values('value')
                ),
               
                ).order_by('requested_material_id')
        )
        result = {
            "rfq_vendors__date": [],
            "purchase_order__date": [],
            "purchase_order__vendor__vendor_name": [],
            "quotation__count": 0,
            "approved_by_date": [],
            "lead_time_mr_to_po_day_count": 0,
            "lead_time_po_to_grn_day_count": 0,
        }

        for item in data:
            if item["rfq_vendors__date"]:
                result["rfq_vendors__date"].extend(item["rfq_vendors__date"].split(","))
            if item["purchase_order__date"]:
                result["purchase_order__date"].extend(item["purchase_order__date"].split(","))
            if item["purchase_order__vendor__vendor_name"]:
                result["purchase_order__vendor__vendor_name"].extend(item["purchase_order__vendor__vendor_name"].split(","))
            if item["approved_by_date"]:
                result["approved_by_date"].extend(item["approved_by_date"].split(","))

            result["quotation__count"] += item["quotation__count"]
            
            result["lead_time_mr_to_po_day_count"] += item.get("lead_time_mr_to_po_day_count", 0) or 0
            result["lead_time_po_to_grn_day_count"] += item.get("lead_time_po_to_grn_day_count", 0) or 0

        result["rfq_vendors__date"] = list(set(result["rfq_vendors__date"]))
        result["purchase_order__date"] = list(set(result["purchase_order__date"]))
        result["purchase_order__vendor__vendor_name"] = list(set(result["purchase_order__vendor__vendor_name"]))
        result["approved_by_date"] = list(set(result["approved_by_date"]))

        return result
        # return data
    

    def get_wbs_details(self, instance):
   
        try:
            details = [
                {"id": wbs.id, "wbs": wbs.wbs} 
                for wbs in instance.wbs.filter(is_deleted=False)
            ]
            return details
        except Exception as e:
            print("ERROR:", e)
            return []
    # def get_wbs_details(self, instance):
    #     details = []
    #     for wbs_details in instance.wbs.filter(is_deleted=False):
    #         details.append(get_vendor_data(wbs_details))
    #     return details

    def get_project_details(self, instance):
        project = instance.project
        if project:
            return get_project_data(instance.project.id)
        return None
    def get_uom_details(self, instance):
       
        return get_details_from_instance(instance.uom,extras=[], type="dict") 
  
class StoreDSRMasterSerializer(serializers.ModelSerializer):
    """
    Serializer for Store DSR Master

    """
    requested_material_details = serializers.SerializerMethodField()

    class Meta:
        model = StoreDSRMaster
        fields = '__all__'
    def get_requested_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details    
class StoreDSRRecordsItemsSerializer(serializers.ModelSerializer):
    """
    Serializer for STore DSR Items
    """
    class Meta:
        model = StoreDSRRecordsItems
        fields = '__all__'     

class StoreDSRRecordsSerializer(serializers.ModelSerializer):
    """
    Serializer for Store DSR Records
    """
    class Meta:
        model = StoreDSRRecords
        fields = '__all__'   

class SAPPRSerializer(serializers.ModelSerializer):
    """
    Serializer for SAPPR
    """
    requested_material_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()

    class Meta:
        model = SAPPR
        fields = '__all__'           

    def get_project_details(self, instance):
        project = instance.project
        if project:
            return get_project_data(instance.project.id)
        return None
    def get_requested_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details    
    


class ProcurementMaterialBudgetBreakdownSerializer(serializers.ModelSerializer):
    """
    MaterialBudgetBreakdownSerializer Serializer
    """
    entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])

    id = serializers.IntegerField(required=False)
    class Meta:
        model = ProcurementMaterialBudgetBreakdown
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class ProcurementMaterialConsumptionBreakdownSerializer(serializers.ModelSerializer):
    """
    ProcurementMaterialConsumptionBreakdownSerializer Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = ProcurementMaterialConsumptionBreakdown
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer




class ProcurementMaterialProjectGroupSerializer(serializers.ModelSerializer):
    """
    ProcurementMaterialProjectGroup  Serializer
    """

    start_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])
    end_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'], required=False)
    class Meta:
        model = ProcurementMaterialProjectGroup
        fields = '__all__'


class ProcurementMaterialProjectSerializer(serializers.ModelSerializer):
    """
    ProcurementAccountProjectBudget Serializer
    """
    start_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])
    end_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'], required=False)
    requested_material_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()
    breakdown = ProcurementMaterialBudgetBreakdownSerializer(many=True, required=False, source="procurement_material_budget_breakdown")
    consumption_breakdown = ProcurementMaterialConsumptionBreakdownSerializer(many=True, required=False, source="procurement_mat_consumption_breakdown")

    def get_uom_details(self, instance):
        return get_details_from_instance(instance.uom,extras=[], type="dict") 
    def get_project_details(self, instance):
        project = instance.project
        if project:
            return get_project_data(instance.project.id)
        return None
    def get_requested_material_details(self, instance):
        return_details = {}
        try:
            if instance.requested_material:
                serializer = VendorMaterialMasterSerializer(instance.requested_material)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)

        return return_details

    def calculation(self, instance: ProcurementMaterialProject):
        # print('calculation...')
        instance.qty_left = 0.
        instance.budget_left = 0.

        # 1. qty_left, budget_left
        last_budget = instance.procurement_material_budget_breakdown.filter(is_deleted=False).last()
        # print('last_budget', last_budget)
        last_consumption = instance.procurement_mat_consumption_breakdown.filter(is_deleted=False).last()
        # print('last_consumption', last_consumption)
        if last_budget and last_consumption:
            instance.qty_left = (last_budget.qty - last_consumption.consumed_qty)
            instance.budget_left = (last_budget.amount - last_consumption.consumed_amt)

        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        breakdown_items = validated_data.pop('procurement_material_budget_breakdown', [])
        consumption_breakdown_items = validated_data.pop('procurement_mat_consumption_breakdown', [])

        # create grp if not exists
        print('validated_data project', validated_data['project'])
        project = validated_data['project']
        start_date = validated_data['start_date']
        request = self.context.get('request')
        validated_data['created_by'] = request.user
        if not ProcurementMaterialProjectGroup.cmobjects.filter(project=project).exists():
            grp = ProcurementMaterialProjectGroup.objects.create(project=project, start_date=start_date)
        else:
            grp = ProcurementMaterialProjectGroup.cmobjects.filter(project=project).first()
        print(validated_data)
        instance = ProcurementMaterialProject.objects.create(group=grp, **validated_data)

        # insert items ✅
        _items = None
        for item in breakdown_items:
            [item.pop(k, None) for k in
             ('created_by', 'master', 'id', 'material_code')]
            # print('master', instance)
            _items = ProcurementMaterialBudgetBreakdown.objects.create(
                created_by=instance.created_by,
                material_code=instance.material_code,
                requested_material_id=instance.requested_material.id,
                master=instance,
                **item
            )
        self.calculation(instance)

        # insert items ✅
        _items = None
        for item in consumption_breakdown_items:
            [item.pop(k, None) for k in
             ('created_by', 'master', 'id', 'material_code')]
            _items = ProcurementMaterialConsumptionBreakdown.objects.create(
                created_by=instance.created_by,
                material_code=instance.material_code,
                requested_material_id=instance.requested_material.id,
                master=instance,
                **item
            )
        self.calculation(instance)

        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        breakdown_items = validated_data.pop('procurement_material_budget_breakdown', [])
        consumption_breakdown_items = validated_data.pop('procurement_mat_consumption_breakdown', [])
        request = self.context.get('request')
        validated_data['updated_by'] = request.user
        for key, value in validated_data.items():
            setattr(instance, key, value)

        # update/insert MaterialBudgetBreakdown ✅
        old_item_ids = [item.pk for item in instance.procurement_material_budget_breakdown.filter(is_deleted=False)]
        updated_item_ids = []
        for item in breakdown_items:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'updated_by': instance.updated_by},
                                        {'material_code': instance.material_code},
                                        {'requested_material_id': instance.requested_material.id},
                                        {'is_deleted': False},
                                        {'master': instance},)]

            if not id:
                _obj = ProcurementMaterialBudgetBreakdown.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                _obj = ProcurementMaterialBudgetBreakdown.cmobjects.filter(pk=id).update(**item)
                print(f"item update {id} {50 * '*'}")


            updated_item_ids.append(id)
     
        self.calculation(instance)

        ''' 1.  update/insert Items ✅ '''
        old_item_ids = [item.pk for item in instance.procurement_mat_consumption_breakdown.filter(is_deleted=False)]
        updated_item_ids = []
        for item in consumption_breakdown_items:
            id = item.pop('id', None)
            [item.update(kv) for kv in (
                                        {'updated_by': instance.updated_by},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = ProcurementMaterialConsumptionBreakdown.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                _obj, created = ProcurementMaterialConsumptionBreakdown.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            # update_item_notes_generic2('MaterialConsumptionBreakdownNotes', item_notes, updated_by=instance.updated_by, master=_obj)
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = ProcurementMaterialConsumptionBreakdown.cmobjects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                                 updated_by=instance.updated_by)
        print('deleted MaterialConsumptionBreakdown', _)
        # # end update/insert MaterialConsumptionBreakdown
        self.calculation(instance)

        instance.save()
        return instance

    group_details = serializers.SerializerMethodField()
    def get_group_details(self, instance):
        _details = None
        if instance and instance.group:
            _details = ProcurementMaterialProjectGroup.cmobjects.filter(pk=instance.group.id).values()
        return _details

    def to_representation(self, instance):
        data = super().to_representation(instance)
        request = self.context.get("request")
        entry_date = request.query_params.get("entry_date") if request else None
        parsed_date = parse_date(entry_date) if entry_date else None
        if parsed_date:
            # qs = instance.procurement_material_budget_breakdown.filter(
            #     Q(entry_date__lte=parsed_date) | Q(is_zero_budget=True) 
            # ).annotate(
            #     date_diff=ExpressionWrapper(
            #         Abs(F("entry_date") - parsed_date),
            #         output_field=DurationField()
            #     )
            # ).order_by("date_diff").values()[:2]
            # data["breakdown"] =  qs
            closest_qs = (instance.procurement_material_budget_breakdown.filter(
                    entry_date__lte=parsed_date,).annotate(
                    date_diff=ExpressionWrapper(
                        Abs(F("entry_date") - parsed_date),
                        output_field=DurationField(),
                    )
                ).order_by("date_diff").values()[:1])
            zero_budget_qs = (instance.procurement_material_budget_breakdown.filter(is_zero_budget=True).values())
            data["breakdown"] = list(closest_qs) + list(zero_budget_qs)
        return data
    
    class Meta:
        model = ProcurementMaterialProject
        fields = '__all__'


class PaymentMasterStagesSerializer(serializers.ModelSerializer):
    """
    PaymentMasterStages Serializer
    """
    id = serializers.IntegerField(required=False)
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    
    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    
    class Meta:
        model = PaymentMasterStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PaymentMasterAttachmentsSerializer(serializers.ModelSerializer):
    """
    PaymentMaster Attachments Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PaymentMasterAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class PaymentMasterUTRAttachmentsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    
    class Meta:
        model = PaymentMasterUTRAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PaymentMasterUTRSerializer(serializers.ModelSerializer):
    """
    PaymentMasterUTR Serializer
    """
    id = serializers.IntegerField(required=False)
    attachments = PaymentMasterUTRAttachmentsSerializer(
        many=True, required=False, source="procurement_payment_master_utr_attachments"
    )
    class Meta:
        model = PaymentMasterUTR
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    @transaction.atomic
    def create(self, validated_data):
        attachments_data = validated_data.pop('procurement_payment_master_utr_attachments', [])
        utr_instance = PaymentMasterUTR.objects.create(**validated_data)
        current_user = utr_instance.created_by if utr_instance else None
        
        for attachment_data in attachments_data:
            PaymentMasterUTRAttachments.objects.create(
                organization=utr_instance.payment_master.organization,
                payment_master_utr=utr_instance,
                attachment=process_attachments(attachment_data),
                attachment_name=attachment_data.get('attachment_name'),
                file_data="",
                mime_type="",
                created_by=current_user
            )
        return utr_instance

    @transaction.atomic
    def update(self, instance, validated_data):
        attachments_data = validated_data.pop('procurement_payment_master_utr_attachments', [])
        current_user = instance.updated_by if hasattr(instance, 'updated_by') else None
        
        # Update UTR fields
        for field in instance._meta.fields:
            if field.name in validated_data:
                setattr(instance, field.name, validated_data[field.name])
        instance.save()

        existing_attachments = instance.procurement_payment_master_utr_attachments.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)

            existing_attachment = next(
                (att for att in existing_attachments if att.id == attachment_id), None
            )

            if not existing_attachment:
                PaymentMasterUTRAttachments.objects.create(
                    organization=instance.payment_master.organization,
                    payment_master_utr=instance,
                    attachment=temp_attach_data,
                    attachment_name=attachment_data.get('attachment_name'),
                    file_data="",
                    mime_type="",
                    created_by=current_user
                )
            else:
                if temp_attach_data:
                    existing_attachment.attachment = temp_attach_data
                existing_attachment.attachment_name = attachment_data.get('attachment_name')
                existing_attachment.updated_by = current_user
                existing_attachment.save()

        return instance
        
class PaymentMasterSerializer(serializers.ModelSerializer):
    """
    Serializer for PaymentMaster
    """
    stages = PaymentMasterStagesSerializer(many=True, required=False, source="procurement_payment_master_stages")
    utr = PaymentMasterUTRSerializer(many=True, required=False, source="procurement_payment_master_utr")
    attachments = PaymentMasterAttachmentsSerializer(many=True, required=False, source="procurement_payment_master_attachments")
    vendor_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    cst_details = serializers.SerializerMethodField()
    multi_stage_details = serializers.SerializerMethodField()
    status_details = serializers.SerializerMethodField()
            
    class Meta:
        model = PaymentMaster
        fields = '__all__'   

    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, type="dict")
    def get_site_details(self, instance):
        return get_details_from_instance(instance.site)
    def get_store_details(self, instance):
        return get_details_from_instance(instance.store) 
    def get_cst_details(self, instance):
        return get_details_from_instance(instance.cst)
    
    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)

    def get_status_details(self, instance):
        return multi_stage_status_details(instance, self.get_multi_stage_details(instance), 'pending')

    @transaction.atomic
    def create(self, validated_data):

        attachments_data = validated_data.pop('procurement_payment_master_attachments', [])
        payment_master = PaymentMaster.objects.create(**validated_data)
        current_user = payment_master.created_by if payment_master.created_by else None

        for attachment_data in attachments_data:
            try:
                attachment = PaymentMasterAttachments.objects.create(
                    organization=payment_master.organization,
                    payment_master=payment_master,
                    attachment=process_attachments(attachment_data),
                    file_data="",
                    mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")

        payment_master.save()
        return payment_master
    @transaction.atomic
    def update(self, instance, validated_data):
        attachments_data = validated_data.get('procurement_payment_master_attachments', [])
    
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
     
        existing_attachments = instance.procurement_payment_master_attachments.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                existing_attachment = PaymentMasterAttachments.objects.create(
                    organization=instance.organization,
                    payment_master=instance,
                    attachment=temp_attach_data,
                    file_data="",
                    mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save() 
              
        instance.save()
        return instance


class UnlinkPurchaseOrderSerializer(serializers.ModelSerializer):
    """
    Procurement UnlinkPurchaseOrder Serializer
    """
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()

    item_details = serializers.SerializerMethodField()
    uom_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    vendor_currency_details = serializers.SerializerMethodField()
    tax_code_for_sap_details = serializers.SerializerMethodField()
    purchase_org_for_sap_details = serializers.SerializerMethodField()
    purchase_group_for_sap_details = serializers.SerializerMethodField()
    stock_keeping_unit_details = serializers.SerializerMethodField()
    order_price_unit_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()

    class Meta:
        model = UnlinkPurchaseOrder
        fields = '__all__'

    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor)

    def get_item_details(self, instance):
        return get_details_from_instance(instance.item)

    def get_uom_details(self, instance):
        return get_details_from_instance(instance.uom)

    def get_store_details(self, instance):
        return get_details_from_instance(instance.store)

    def get_site_details(self, instance):
        return get_details_from_instance(instance.site)

    def get_project_details(self, instance):
        return get_details_from_instance(instance.project)

    def get_vendor_currency_details(self, instance):
        return get_details_from_instance(instance.vendor_currency)

    def get_tax_code_for_sap_details(self, instance):
        return get_details_from_instance(instance.tax_code_for_sap)

    def get_purchase_org_for_sap_details(self, instance):
        return get_details_from_instance(instance.purchase_org_for_sap)

    def get_purchase_group_for_sap_details(self, instance):
        return get_details_from_instance(instance.purchase_group_for_sap)

    def get_stock_keeping_unit_details(self, instance):
        return get_details_from_instance(instance.stock_keeping_unit)

    def get_order_price_unit_details(self, instance):
        return get_details_from_instance(instance.order_price_unit)


    def get_created_by_details(self, instance):
        if instance.created_by:
            return [{
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,
            }]
        return None

    def get_checked_by_details(self, instance):
        if instance.checked_by:
            return [{
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,
            }]
        return None

    def get_cancelled_by_details(self, instance):
        if instance.cancelled_by:
            return [{
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,
            }]
        return None

    def get_close_by_details(self, instance):
        if instance.close_by:
            return [{
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,
            }]
        return None

    def get_approved_by_details(self, instance):
        if instance.approved_by:
            return [{
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,
            }]
        return None
    def get_rejected_by_details(self, instance):
        if instance.rejected_by:
            return [{
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,
            }]
        return None
    
class ProcurementStatusOfOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProcurementStatusOfOrder
        fields = '__all__'


class ProcurementBudgetPlanningSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProcurementBudgetPlanning
        fields = '__all__'

class ProcurementRealTimeMaterialReceiveSerializer(serializers.ModelSerializer):
    created_by_full_name = serializers.SerializerMethodField()

    class Meta:
        model = ProcurementRealTimeMaterialReceive
        fields = '__all__' 

    def get_created_by_full_name(self, instance):
        return f"{instance.created_by.first_name or ''} {instance.created_by.last_name or ''}".strip() if instance.created_by else None
    
class NABLLabDirectorySerializer(serializers.ModelSerializer):
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    
    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by:
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by:
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by:
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by:
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    class Meta:
        model = NABLLabDirectory
        fields = "__all__"

class ProcurementReturnableMaterialSerializer(serializers.ModelSerializer):
    """
    Serializer for ProcurementReturnableMaterial model
    """
    vendor_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    material_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    user_details = serializers.SerializerMethodField()
    return_quantity = serializers.SerializerMethodField()

    def get_material_details(self, instance):
        return_details = {}
        try:
            if instance.material and instance.material.id:
                details = VendorMaterialMaster.objects.filter(pk=instance.material.id).first()
                serializer = VendorMaterialMasterSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)
        return return_details

    def get_user_details(self, instance):
        details = None
        if instance.user :
            details = []
            details.append({
                "id" : instance.user.pk,
                "first_name": instance.user.first_name,
                "last_name": instance.user.last_name,
                "email": instance.user.email,
                "employe_code" : instance.user.employe_code,
                "department_name" : instance.user.department.department,
            })
        return details

    def get_return_quantity(self, instance):
        total_returned = ProcurementReturnableMaterialReturnQuantityDetails.objects.filter(
            returnable_material=instance
        ).aggregate(total=Sum('quantity'))['total']
        return total_returned or 0

    class Meta:
        model = ProcurementReturnableMaterial
        fields = '__all__'   

    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, type="dict")
    def get_site_details(self, instance):
        return get_details_from_instance(instance.site)
    def get_store_details(self, instance):
        return get_details_from_instance(instance.store) 
    def get_project_details(self, instance):
        return get_details_from_instance(instance.project) 

    class Meta:
        model = ProcurementReturnableMaterial
        fields = '__all__'

class ProcurementReturnableMaterialReturnQuantityDetailsSerializer(serializers.ModelSerializer):
    """
    Serializer for ProcurementReturnableMaterialReturnQuantityDetails model
    """
    created_by_details = serializers.SerializerMethodField()
    class Meta:
        model = ProcurementReturnableMaterialReturnQuantityDetails
        fields = '__all__'
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details