from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline

from .models import *
# Register your models here.
from django import forms
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import path , reverse
from django.contrib import messages
from django.utils.html import format_html
from django.forms import inlineformset_factory
from unfold.widgets import UnfoldAdminColorInputWidget
from unfold.decorators import display
from django.utils.safestring import mark_safe

class InventoryLogsAdmin(StackedInline):
    model = InventoryLogs
    fk_name = 'inventory'
@admin.register(Inventory)
class InventoryAdmin(ModelAdmin):
    list_display = ('id','material', 'plant_machinery_machine', 'store', 'site', 'financialyear', 'quantity', 'is_deleted',)
    search_fields = ('material__material_code','material__material_name','plant_machinery_machine__equipment_description','store__store_name','site__site_name','financialyear__name',)
    inlines = (InventoryLogsAdmin,)


@admin.register(InventoryLogs)
class InventoryLogsAdmin(ModelAdmin):
    list_display = ('inventory', 'transaction_quantity', 'cost_per_unit', 'reference_type', 'reference_id', 'is_deleted',)
    search_fields = ('reference_type','inventory__material__material_code',)
        

class MaterialRequestMasterAttachmentsAdmin(StackedInline):
    model = MaterialRequestMasterAttachments
    fk_name = 'material_request'
class MaterialRequestMasterItemsAdmin(StackedInline):
    model = MaterialRequestMasterItems
    fk_name = 'material_request'
@admin.register(MaterialRequestMaster)
class MaterialRequestMasterAdmin(ModelAdmin):
    list_display = ['id','request_code','version','latest', 'financialyear', 'project', 'store', 'site', 'status', 'is_deleted']
    search_fields = ('request_code',)
    inlines = (MaterialRequestMasterAttachmentsAdmin,MaterialRequestMasterItemsAdmin,)
        

class BillReceiveAttachmentsAdmin(StackedInline):
    model = BillReceiveAttachments
    fk_name = 'bill_receive'
@admin.register(BillReceive)
class BillReceiveAdmin(ModelAdmin):
    list_display = ['vendor', 'store', 'site', 'amount', 'manual_slip_number', 'bill_date', 'bill_type']
    search_fields = ('manual_slip_number',)
    inlines = (BillReceiveAttachmentsAdmin,)
        

class GatePassAttachmentsAdmin(StackedInline):
    model = GatePassAttachments
    fk_name = 'gate_pass'
class GatePassItemsAdmin(StackedInline):
    model = GatePassItems
    fk_name = 'gate_pass'
@admin.register(GatePass)
class GatePassAdmin(ModelAdmin):
    list_display = ['request_code', 'gate_pass_no', 'gate_pass_type', 'type', 'date', 'time', 'status']
    search_fields = ('request_code', 'gate_pass_no',)
    inlines = (GatePassAttachmentsAdmin,GatePassItemsAdmin,)

class MultiStageSettingStagesAdmin(StackedInline):
    autocomplete_fields=['department','employee']
    model = MultiStageSettingStages
    fk_name = 'multi_stage_setting'
@admin.register(MultiStageSetting)
class MultiStageSettingAdmin(ModelAdmin):
    list_display = ['pk','multi_stage_name', 'from_name', 'display_project_classification', 'display_site', 'is_archived', 'is_deleted']
    search_fields = ('from_name',)
    inlines = (MultiStageSettingStagesAdmin,)
    autocomplete_fields=['site']
    @admin.display(description='Sites')
    def display_site(self, obj):
        return ", ".join([data.site_name for data in obj.site.all()])
    @admin.display(description='Classification')
    def display_project_classification(self, obj):
        return ", ".join(list(set([data.project.project_classification for data in obj.site.all()])))


@admin.register(DocumentEmployeeApproval)
class DocumentEmployeeApprovalAdmin(ModelAdmin):
    list_display = ['doctype', 'user', 'min_value', 'max_value', 'is_deleted']
    search_fields = ('doctype', 'user__username',)


@admin.register(GeneralSetting)
class GeneralSettingAdmin(ModelAdmin):
    list_display = ['setting_name', 'is_active', 'is_deleted']
    search_fields = ('setting_name',)


### Transportation rate
@admin.register(TransportationRateItems)
class TransportationRateItemsAdmin(ModelAdmin):
    list_display = ['organization', 'transportation_rate', 'item', 'fixed_rate', 'fixed_rate_km', 'rate_per', 'rate_km']
    # search_fields = ('',)
    readonly_fields = ('id',)

class TransportationRateItemsInline(StackedInline):
    model = TransportationRateItems
    extra = 1

class TransportationRateAdmin(ModelAdmin):
    list_display = ('organization', 'sub_contractor')
    inlines = [TransportationRateItemsInline]

admin.site.register(TransportationRate, TransportationRateAdmin)
#####

# PurchaseReturn
class PurchaseReturnAttachmentsInline(StackedInline):
    model = PurchaseReturnAttachments
    extra = 1
class PurchaseReturnTaxDetailsInline(StackedInline):
    model = PurchaseReturnTaxDetails
    extra = 1
class PurchaseReturnItemsInline(StackedInline):
    model = PurchaseReturnItems
    extra = 1
class PurchaseReturnExpenseInline(StackedInline):
    model = PurchaseReturnsExpenseDetails
    extra = 1
class PurchaseReturnAdmin(ModelAdmin):
    list_display = ('voucher_no', 'is_deleted', 'organization',)
    inlines = (PurchaseReturnItemsInline, PurchaseReturnTaxDetailsInline, PurchaseReturnAttachmentsInline, PurchaseReturnExpenseInline)
admin.site.register(PurchaseReturn, PurchaseReturnAdmin)
#####

# TaxInvoice
class TaxInvoiceAttachmentsInline(StackedInline):
    model = TaxInvoiceAttachments
    extra = 1
class TaxInvoiceTaxDetailsInline(StackedInline):
    model = TaxInvoiceTaxDetails
    extra = 1
class TaxInvoiceItemsInline(StackedInline):
    model = TaxInvoiceItems
    extra = 1
class TaxInvoiceAdmin(ModelAdmin):
    list_display = ('is_deleted', 'organization',)
    inlines = (TaxInvoiceItemsInline, TaxInvoiceTaxDetailsInline, TaxInvoiceAttachmentsInline,)
admin.site.register(TaxInvoice, TaxInvoiceAdmin)
#####

# TransporterBill
class TransporterBillAttachmentsInline(StackedInline):
    model = TransporterBillAttachments
    extra = 1
class TransporterBillTaxDetailsInline(StackedInline):
    model = TransporterBillTaxDetails
    extra = 1
class TransporterBillItemsInline(StackedInline):
    model = TransporterBillItems
    extra = 1
class TransporterBillAdmin(ModelAdmin):
    list_display = ('is_deleted', 'organization',)
    inlines = (TransporterBillItemsInline, TransporterBillTaxDetailsInline, TransporterBillAttachmentsInline)
admin.site.register(TransporterBill, TransporterBillAdmin)
#####


# MaterialIssueDebitNote
# class MaterialIssueDebitNoteAttachmentsInline(StackedInline):
#     model = MaterialIssueDebitNoteAttachments
#     extra = 1

class MaterialIssueDebitNoteTaxDetailsInline(StackedInline):
    model = MaterialIssueDebitNoteTax
    extra = 1
class MaterialIssueDebitNoteItemsInline(StackedInline):
    model = MaterialIssueDebitNoteItems
    extra = 1
class MaterialIssueDebitNoteAdmin(ModelAdmin):
    list_display = ('is_deleted', 'organization',)
    inlines = (MaterialIssueDebitNoteItemsInline, MaterialIssueDebitNoteTaxDetailsInline,)
admin.site.register(MaterialIssueDebitNote, MaterialIssueDebitNoteAdmin)
#####


class WorkOrderLaborAdmin(StackedInline):
    model = WorkOrderLabor
    fk_name = 'work_order'
class WorkOrderDetailAdmin(StackedInline):
    model = WorkOrderDetail
    fk_name = 'work_order'
class WorkOrderTaxAdmin(StackedInline):
    model = WorkOrderTax
    fk_name = 'work_order'
class WorkOrderRequirementAdmin(StackedInline):
    model = WorkOrderRequirement
    fk_name = 'work_order'
class WorkOrderTermsAndConditionsAdmin(StackedInline):
    model = WorkOrderTermsAndConditions
    fk_name = 'work_order'
class WorkOrderMaterialAdmin(StackedInline):
    model = WorkOrderMaterial
    fk_name = 'work_order'
class WorkOrderHireContractAdmin(StackedInline):
    model = WorkOrderHireContract
    fk_name = 'work_order'
class WorkOrderAttachmentsAdmin(StackedInline):
    model = WorkOrderAttachments
    fk_name = 'work_order'
class WorkOrderStagesAdmin(StackedInline):
    model = WorkOrderStages
    fk_name = 'work_order'
@admin.register(WorkOrder)
class WorkOrderAdmin(ModelAdmin):
    list_display = ['request_code', 'is_deleted']
    search_fields = ('request_code',)
    inlines = (WorkOrderLaborAdmin,WorkOrderDetailAdmin,WorkOrderTaxAdmin,WorkOrderRequirementAdmin,WorkOrderTermsAndConditionsAdmin,WorkOrderMaterialAdmin,WorkOrderHireContractAdmin,WorkOrderAttachmentsAdmin,WorkOrderStagesAdmin,)


class WorkIndentAttachmentsAdmin(StackedInline):
    model = WorkIndentAttachments
    fk_name = 'work_indent'
class WorkIndentWorkDetailAdmin(StackedInline):
    model = WorkIndentWorkDetail
    fk_name = 'work_indent'
@admin.register(WorkIndent)
class WorkIndentAdmin(ModelAdmin):
    list_display = ['request_code', 'is_deleted']
    search_fields = ('request_code',)
    inlines = (WorkIndentWorkDetailAdmin,WorkIndentAttachmentsAdmin,)


class RFQVendorsMailListAdmin(StackedInline):
    model = RFQVendorsMailList
    fk_name = 'rfq_vendors'
class RFQVendorsItemsAdmin(StackedInline):
    model = RFQVendorsItems
    fk_name = 'rfq_vendors'
@admin.register(RFQVendors)
class RFQVendorsAdmin(ModelAdmin):
    list_display = ['request_code', 'is_repeat_order', 'is_archived', 'is_deleted']
    search_fields = ('request_code',)
    list_filter = ['is_repeat_order', 'is_archived', 'is_deleted']
    inlines = (RFQVendorsMailListAdmin,RFQVendorsItemsAdmin,)


class FabricationWorkRawMaterialAdmin(StackedInline):
    model = FabricationWorkRawMaterial
    fk_name = 'fabrication_work'
class FabricationWorkFinishGoodsAdmin(StackedInline):
    model = FabricationWorkFinishGoods
    fk_name = 'fabrication_work'
class FabricationWorkLaborAdmin(StackedInline):
    model = FabricationWorkLabor
    fk_name = 'fabrication_work'
class FabricationWorkAttachmentsAdmin(StackedInline):
    model = FabricationWorkAttachments
    fk_name = 'fabrication_work'
@admin.register(FabricationWork)
class FabricationWorkAdmin(ModelAdmin):
    list_display = ['request_code', 'is_deleted']
    search_fields = ('request_code',)
    inlines = (FabricationWorkRawMaterialAdmin,FabricationWorkFinishGoodsAdmin,FabricationWorkLaborAdmin,FabricationWorkAttachmentsAdmin,)


class QuotationTermsAndConditionsAdmin(StackedInline):
    model = QuotationTermsAndConditions
    fk_name = 'quotation'
class QuotationTaxDetailsAdmin(StackedInline):
    model = QuotationTaxDetails
    fk_name = 'quotation'
class QuotationExpenseDetailsAdmin(StackedInline):
    model = QuotationExpenseDetails
    fk_name = 'quotation'
class QuotationAttachmentsAdmin(StackedInline):
    model = QuotationAttachments
    fk_name = 'quotation'
class QuotationItemsAdmin(StackedInline):
    model = QuotationItems
    fk_name = 'quotation'
@admin.register(Quotation)
class QuotationAdmin(ModelAdmin):
    list_display = ['request_code', 'version','latest', 'total_amount','rfq_vendor','rfq_vendor_rank','rfq_vendor_count', 'is_deleted']
    search_fields = ('request_code','rfq_vendor__request_code',)
    inlines = (QuotationItemsAdmin,QuotationExpenseDetailsAdmin,QuotationTaxDetailsAdmin,QuotationTermsAndConditionsAdmin,QuotationAttachmentsAdmin,)


class LabReportEntryItemAdmin(StackedInline):
    model = LabReportEntryItem
    fk_name = 'lab_report_entry'
@admin.register(LabReportEntry)
class LabReportEntryAdmin(ModelAdmin):
    list_display = ['request_code', 'is_deleted']
    search_fields = ('request_code',)
    inlines = (LabReportEntryItemAdmin,)


class GeneralAdministrationExpenseItemsAdmin(StackedInline):
    model = GeneralAdministrationExpenseItems
    fk_name = 'general_admin_expense'
@admin.register(GeneralAdministrationExpenses)
class GeneralAdministrationExpensesAdmin(ModelAdmin):
    list_display = ['request_code', 'is_deleted']
    search_fields = ('request_code',)
    inlines = (GeneralAdministrationExpenseItemsAdmin,)


class MaterialWastageItemsAdmin(StackedInline):
    model = MaterialWastageItems
    fk_name = 'material_wastage'
@admin.register(MaterialWastage)
class MaterialWastageAdmin(ModelAdmin):
    list_display = ['material_waste_no', 'store', 'is_deleted']
    search_fields = ('material_waste_no',)
    inlines = (MaterialWastageItemsAdmin,)


class ItemStockJVFReceiveIssueItemAdmin(StackedInline):
    model = ItemStockJVFReceiveIssueItem
    fk_name = 'item_stock_jv'
@admin.register(ItemStockJV)
class ItemStockJVAdmin(ModelAdmin):
    list_display = ['jv_no', 'is_deleted']
    search_fields = ('jv_no',)
    inlines = (ItemStockJVFReceiveIssueItemAdmin,)


class GRNItemsAdmin(StackedInline):
    model = GRNItems
    fk_name = 'grn'
class GRNTaxDetailsAdmin(StackedInline):
    model = GRNTaxDetails
    fk_name = 'grn'
class GRNExpenseDetailsAdmin(StackedInline):
    model = GRNExpenseDetails
    fk_name = 'grn'
class GRNAttachmentsAdmin(StackedInline):
    model = GRNAttachments
    fk_name = 'grn'
@admin.register(GRN)
class GRNAdmin(ModelAdmin):
    list_display = ['request_code', 'sap_code', 'date', 'bill_date', 'status', 'movement_type', 'is_deleted']
    search_fields = ('request_code','sap_code')
    inlines = (GRNItemsAdmin,GRNTaxDetailsAdmin,GRNExpenseDetailsAdmin,GRNAttachmentsAdmin,)
@admin.register(GRNItemsBatch)
class GRNItemsBatchAdmin(ModelAdmin):
    list_display = ['id', 'name', 'grn_item', 'quantity', 'expiry_date', 'is_deleted']
    search_fields = ('name',)
    list_filter = ('expiry_date', 'is_deleted',)
class MaterialIssueItemsAdmin(StackedInline):
    model = MaterialIssueItems
    fk_name = 'material_issue'
class MaterialIssueAttachmentsAdmin(StackedInline):
    model = MaterialIssueAttachments
    fk_name = 'material_issue'
@admin.register(MaterialIssue)
class MaterialIssueAdmin(ModelAdmin):
    list_display = ['request_code', 'sap_issue_number', 'is_deleted']
    search_fields = ('request_code', 'sap_issue_number')
    inlines = (MaterialIssueItemsAdmin,MaterialIssueAttachmentsAdmin,)


class MaterialIssueReturnItemsAdmin(StackedInline):
    model = MaterialIssueReturnItems
    fk_name = 'material_issue_return'
class MaterialIssueReturnAttachmentsAdmin(StackedInline):
    model = MaterialIssueReturnAttachments
    fk_name = 'material_issue_return'
@admin.register(MaterialIssueReturn)
class MaterialIssueReturnAdmin(ModelAdmin):
    list_display = ['material_issue_return_no', 'is_deleted']
    search_fields = ('material_issue_return_no',)
    inlines = (MaterialIssueReturnItemsAdmin,MaterialIssueReturnAttachmentsAdmin,)


@admin.register(PhysicalStock)
class PhysicalStockAdmin(ModelAdmin):
    list_display = ['material', 'site', 'store', 'physical_qty', 'actual_qty', 'diff_qty', 'is_deleted']
    search_fields = ('material_issue_return_no',)

@admin.register(PhysicalStockGroup)
class PhysicalStockGroupAdmin(ModelAdmin):
    list_display = ['name', 'is_deleted', 'created_by', 'updated_by']


class PurchaseOrderItemsAdmin(StackedInline):
    model = PurchaseOrderItems
    fk_name = 'purchase_order'
class PurchaseOrderTaxDetailsAdmin(StackedInline):
    model = PurchaseOrderTaxDetails
    fk_name = 'purchase_order'
class PurchaseOrderExpenseDetailsAdmin(StackedInline):
    model = PurchaseOrderExpenseDetails
    fk_name = 'purchase_order'
class PurchaseOrderPaymentScheduleAdmin(StackedInline):
    model = PurchaseOrderPaymentSchedule
    fk_name = 'purchase_order'
class PurchaseOrderTermsAndConditionsAdmin(StackedInline):
    model = PurchaseOrderTermsAndConditions
    fk_name = 'purchase_order'
class PurchaseOrderDeliveryLocationAdmin(StackedInline):
    model = PurchaseOrderDeliveryLocation
    fk_name = 'purchase_order'
class PurchaseOrderAttachmentsAdmin(StackedInline):
    model = PurchaseOrderAttachments
    fk_name = 'purchase_order'
class PurchaseOrderStagesAdmin(StackedInline):
    model = PurchaseOrderStages
    fk_name = 'purchase_order'
@admin.register(PurchaseOrder)
class PurchaseOrderAdmin(ModelAdmin):
    list_display = ['id','request_code', 'version','latest', 'sap_code', 'status', 'is_unlinked_po','is_deleted',]
    list_filter = ['is_unlinked_po', 'is_deleted']
    search_fields = ('request_code','sap_code')
    inlines = (PurchaseOrderItemsAdmin,PurchaseOrderTaxDetailsAdmin,PurchaseOrderExpenseDetailsAdmin,PurchaseOrderPaymentScheduleAdmin,PurchaseOrderTermsAndConditionsAdmin,PurchaseOrderDeliveryLocationAdmin,PurchaseOrderAttachmentsAdmin,PurchaseOrderStagesAdmin,)


class PurchaseItemsAdmin(StackedInline):
    model = PurchaseItems
    fk_name = 'purchase'
class PurchaseTaxDetailsAdmin(StackedInline):
    model = PurchaseTaxDetails
    fk_name = 'purchase'
class PurchaseExpenseDetailsAdmin(StackedInline):
    model = PurchaseExpenseDetails
    fk_name = 'purchase'
class PurchaseAttachmentsAdmin(StackedInline):
    model = PurchaseAttachments
    fk_name = 'purchase'
@admin.register(Purchase)
class PurchaseAdmin(ModelAdmin):
    list_display = ['request_code', 'is_deleted']
    search_fields = ('request_code',)
    inlines = (PurchaseItemsAdmin,PurchaseTaxDetailsAdmin,PurchaseExpenseDetailsAdmin,PurchaseAttachmentsAdmin,)


class RawMaterialSalesItemsAdmin(StackedInline):
    model = RawMaterialSalesItems
    fk_name = 'raw_material_sales'
class RawMaterialSalesTaxDetailsAdmin(StackedInline):
    model = RawMaterialSalesTaxDetails
    fk_name = 'raw_material_sales'
class RawMaterialSalesExpenseDetailsAdmin(StackedInline):
    model = RawMaterialSalesExpenseDetails
    fk_name = 'raw_material_sales'
class RawMaterialSalesAttachmentsAdmin(StackedInline):
    model = RawMaterialSalesAttachments
    fk_name = 'raw_material_sales'
@admin.register(RawMaterialSales)
class RawMaterialSalesAdmin(ModelAdmin):
    list_display = ['request_code', 'is_deleted']
    search_fields = ('request_code',)
    inlines = (RawMaterialSalesItemsAdmin,RawMaterialSalesTaxDetailsAdmin,RawMaterialSalesExpenseDetailsAdmin,RawMaterialSalesAttachmentsAdmin,)


class IndentItemsAdmin(StackedInline):
    model = IndentItems
    fk_name = 'indent'
class IndentStagesAdmin(StackedInline):
    model = IndentStages
    fk_name = 'indent'
@admin.register(Indent)
class IndentAdmin(ModelAdmin):
    list_display = ['id','request_code','version','latest','material_request_id','is_deleted']
    search_fields = ('request_code',)
    inlines = (IndentItemsAdmin,IndentStagesAdmin,)

@admin.register(SiteMaster)
class SiteMasterAdmin(ModelAdmin):
    list_display = ['id','project','site_name','is_deleted']
    search_fields = ['site_name',]

admin.site.register(IndentAttachments,ModelAdmin)

admin.site.register(FinancialYear,ModelAdmin)
admin.site.register(SiteLocationMaster,ModelAdmin)
admin.site.register(SiteLocationChild,ModelAdmin)
admin.site.register(MaterialRequestMasterAttachments,ModelAdmin)
admin.site.register(MaterialRequestMasterItems,ModelAdmin)
admin.site.register(MaterialRequestMasterItemsNotes,ModelAdmin)
admin.site.register(MaterialIssueItemsNotes,ModelAdmin)
admin.site.register(IndentItemsNotes,ModelAdmin)
admin.site.register(PurchaseOrderItemsNotes,ModelAdmin)
admin.site.register(PurchaseOrderItems,ModelAdmin)
admin.site.register(PurchaseItemsNotes,ModelAdmin)
admin.site.register(StoreSection,ModelAdmin)
admin.site.register(RackSetting,ModelAdmin)
admin.site.register(MonthFinancialYearLock,ModelAdmin)
admin.site.register(RestrictItemGroup,ModelAdmin)
admin.site.register(SiteWiseStockLevelSetting,ModelAdmin)
admin.site.register(GroupTaskMaster,ModelAdmin)
admin.site.register(PlantProduction,ModelAdmin)
admin.site.register(SubletOrder,ModelAdmin)
admin.site.register(LogBook,ModelAdmin)
admin.site.register(LogBookAttachments,ModelAdmin)
admin.site.register(WayBillForm,ModelAdmin)
admin.site.register(CFrom,ModelAdmin)
admin.site.register(Communication,ModelAdmin)
admin.site.register(CommunicationType,ModelAdmin)
admin.site.register(BalancePORemarks,ModelAdmin)


class StockTransferredItemsAdmin(StackedInline):
    model = StockTransferredItems
    fk_name = 'stock_transferred'
@admin.register(StockTransferred)
class StockTransferredAdmin(ModelAdmin):
    list_display = ['financialyear', 'project', 'store', 'site', 'stock_type', 'target_type', 'target_project', 'target_store', 'target_site', 'status', 'is_deleted']
    # search_fields = ('request_code',)
    inlines = (StockTransferredItemsAdmin,)


class LabTestingParametersItemAdmin(StackedInline):
    model = LabTestingParametersItem
    fk_name = 'lab_testing_parameters'
@admin.register(LabTestingParameters)
class LabTestingParametersAdmin(ModelAdmin):
    list_display = ['check_items', 'is_deleted']
    # search_fields = ('request_code',)
    inlines = (LabTestingParametersItemAdmin,)


@admin.register(VendorDatabase)
class VendorDatabaseAdmin(ModelAdmin):
    list_display = ['material_type', 'material_name', 'vendor_name', 'contact_person', 'worked_with_sinpl', 'is_deleted']
    search_fields = ('material_type', 'material_name', 'vendor_name', 'contact_person', 'worked_with_sinpl',)

class MaterialDispatchItemsAdmin(StackedInline):
    model = MaterialDispatchItems
    fk_name = 'material_dispatch'
@admin.register(MaterialDispatch)
class MaterialDispatchAdmin(ModelAdmin):
    list_display = ['source_project', 'source_store', 'source_site','destination_site', 'destination_store', 'destination_project', 'status', 'is_deleted']
    inlines = (MaterialDispatchItemsAdmin,)

class EnquiryAtOnceVendorsAdmin(StackedInline):
    model = EnquiryAtOnceVendors
    fk_name = 'enquiry_at_once'
@admin.register(EnquiryAtOnce)
class EnquiryAtOnceAdmin(ModelAdmin):
    list_display = ['project', 'store', 'site', 'status', 'is_deleted']
    inlines = (EnquiryAtOnceVendorsAdmin,)    


@admin.register(CommunicationMaster)
class CommunicationMasterAdmin(ModelAdmin):
    list_display = ['id','organization', 'name']  

class CSTStagesAdmin(StackedInline):
    model = CSTStages
    fk_name = 'cst'
class CSTItemsAdmin(StackedInline):
    model = CSTItems
    fk_name = 'cst'  

class IndicatorFilter(admin.SimpleListFilter):
    title = 'Indicator'
    parameter_name = 'indicator'
    def lookups(self, request, model_admin):
        return [('True', 'True'), ('False', 'False')]
    def queryset(self, request, queryset):
        ids_with_indicator = [
            instance.id for instance in queryset
            if MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.cst.ref_stage_type, employee__in=[instance.created_by_id]).exists()
        ]
        if self.value() == 'True':
            return queryset.filter(id__in=ids_with_indicator)
        if self.value() == 'False':
            return queryset.exclude(id__in=ids_with_indicator)
        return queryset
class CSTStagesAdmin2(ModelAdmin):
    list_display = ['id', 'cst', 'stage', 'status', 'is_web', 'created_by__username', 'cst__ref_stage_type__multi_stage_name', 'is_deleted','indicator']
    model = CSTStages
    list_filter = [IndicatorFilter, 'is_web', 'is_deleted',]
    def indicator(self, instance):
        return MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.cst.ref_stage_type, employee__in=[instance.created_by_id]).exists()
    indicator.boolean = True
admin.site.register(CSTStages, CSTStagesAdmin2)

@admin.register(CST)
class CSTAdmin(ModelAdmin):
    list_display = ['request_code', 'version', 'latest', 'status', 'current_stage','on_hold', 'project', 'site', 'store', 'is_budgeted', 'is_repeat_order','is_direct_po','is_deleted',]
    search_fields = ('request_code',)
    list_filter = ['status', 'current_stage', 'latest','on_hold', 'is_budgeted', 'is_repeat_order', 'is_deleted']
    inlines = (CSTStagesAdmin, CSTItemsAdmin)

@admin.register(SAPMasters)
class SAPMastersAdmin(ModelAdmin):
    list_display = ['id','organization','type','code','is_deleted']
    search_fields = ('type','description','code',)
    list_filter = ['type', 'is_deleted']

@admin.register(BOIProcurementTracker)
class BOIProcurementTrackerAdmin(ModelAdmin):
    list_display = ['id','organization','project','is_deleted']

@admin.register(StoreMaster)
class StoreMasterAdmin(ModelAdmin):
    autocomplete_fields = ['site','users',]
    list_display = ['id','store_name','site','sap_plant_id','sap_auth_key_material','sap_auth_key_po','sap_auth_key_grn','sap_auth_key_pr','sap_start_codes','is_deleted']

@admin.register(StoreDSRRecordsItems)
class StoreDSRRecordsItemsAdmin(ModelAdmin):
    search_fields = ('requested_material__sap_code','requested_material__material_name',)
    list_display = ['id','requested_material','site','date','opening_quantity','received_quantity','issued_quantity','is_deleted']
    list_filter = ['is_deleted','site',('date', admin.DateFieldListFilter),]

@admin.register(StoreDSRRecords)
class StoreDSRRecordsAdmin(ModelAdmin):
    list_display = ['id','site','store','project','date','status','is_deleted']
    list_filter = ['is_deleted','site','status',]

@admin.register(StoreDSRMaster)
class StoreDSRMasterAdmin(ModelAdmin):
    search_fields = ('requested_material__sap_code','requested_material__material_name',)
    list_display = ['id','requested_material','site','store','project','financialyear','is_deleted']
    list_filter = ['is_deleted','site',]

@admin.register(SAPPR)
class SAPPRAdmin(ModelAdmin):
    list_display = ['requested_material','site','store','project','pr_no','material','pr_quantity','order_quantity','requisition_date','wbs_element','is_active','is_deleted']
    search_fields = ('pr_no','material',)
    list_filter = ['is_active', 'is_deleted']


admin.site.register(ProcurementMaterialProjectGroup,ModelAdmin)
@admin.register(ProcurementMaterialProject)
class ProcurementMaterialProjectAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'requested_material','material_code','project']
    search_fields = ('material_code',)


@admin.register(ProcurementMaterialBudgetBreakdown)
class ProcurementMaterialBudgetBreakdownAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'is_zero_budget', 'material_code', 'amount', 'entry_date']
    search_fields = ('material_code',)

@admin.register(ProcurementMaterialConsumptionBreakdown)
class ProcurementMaterialConsumptionBreakdownAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'material_code', 'consumed_amt']
    search_fields = ('material_code',)

@admin.register(MaterialRequestMasterItemsRemarks)
class MaterialRequestMasterItemsRemarksAdmin(ModelAdmin):
    list_display = ['material_request_item', 'date', 'created_by', 'remarks', 'is_deleted']
    list_filter = ['is_deleted']
class PaymentMasterStagesAdmin(StackedInline):
    model = PaymentMasterStages
    fk_name = 'payment_master'  
class PaymentMasterUTRAdmin(StackedInline):
    model = PaymentMasterUTR
    fk_name = 'payment_master' 


@admin.register(PaymentMaster)
class PaymentMasterAdmin(ModelAdmin):
    list_display = [
        'id','request_code', 'vendor','cst','cst_no','payment_through',
        'purchase_order','amount','payment_no','payment_against','status',
        'current_stage', 'project', 'site', 'store', 'status', 'is_deleted', 'approved_by_date',
    ]
    search_fields = ('request_code',)
    list_filter = [
        'status',
        'current_stage',
        'is_deleted',
        ('approved_by_date', admin.DateFieldListFilter), 
    ]
    inlines = (PaymentMasterStagesAdmin, PaymentMasterUTRAdmin)

class PaymentMasterIndicatorFilter(admin.SimpleListFilter):
    title = 'Indicator'
    parameter_name = 'indicator'
    def lookups(self, request, model_admin):
        return [('True', 'True'), ('False', 'False')]
    def queryset(self, request, queryset):
        ids_with_indicator = [
            instance.id for instance in queryset
            if MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.payment_master.ref_stage_type, employee__in=[instance.created_by_id]).exists()
        ]
        if self.value() == 'True':
            return queryset.filter(id__in=ids_with_indicator)
        if self.value() == 'False':
            return queryset.exclude(id__in=ids_with_indicator)
        return queryset
class PaymentMasterStagesAdmin2(ModelAdmin):
    list_display = ['id','payment_master','stage','status','is_web','created_by__username','payment_master__ref_stage_type__multi_stage_name','is_deleted','indicator']
    list_filter = ['is_web', 'is_deleted', PaymentMasterIndicatorFilter]
    def indicator(self, instance):
        return MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.payment_master.ref_stage_type, employee__in=[instance.created_by_id]).exists()
    indicator.boolean = True
admin.site.register(PaymentMasterStages, PaymentMasterStagesAdmin2)

@admin.register(UnlinkPurchaseOrder)
class UnlinkPurchaseOrderAdmin(ModelAdmin):
    list_display = ['id', 'sap_code', 'item_sap_code', 'vendor', 'site', 'store', 'is_deleted']
    search_fields = ('sap_code', 'item__sap_code',)
    list_filter = ['is_deleted', 'site', 'store']
    ordering = ['id']
    
    def item_sap_code(self, obj):
        return obj.item.sap_code if obj.item else '-'    
    item_sap_code.short_description = 'Item SAP Code'

@admin.register(ProcurementStatusOfOrder)
class ProcurementStatusOfOrderAdmin(ModelAdmin):
    list_display = ['id','name','delivered','is_deleted']
    list_filter = ['is_deleted']
    search_fields = ('name',)
    list_editable = ['name','delivered','is_deleted',]

@admin.register(ProcurementBudgetPlanning)
class ProcurementBudgetPlanningAdmin(ModelAdmin):
    list_display = ['id','project','site','store','requested_material','is_deleted']
    list_filter = ['is_deleted']

@admin.register(SAPStockMaster)
class SAPStockMasterAdmin(ModelAdmin):
    search_fields = ('material__sap_code',)
    list_display = ['id','site','material','date','opening_stock','closing_stock','opening_value','closing_value','is_deleted']
    list_filter = ['is_deleted','site',('date', admin.DateFieldListFilter),]

@admin.register(PaymentMasterUTR)
class PaymentMasterUTRAdmin(ModelAdmin):
    search_fields = ('payment_master__request_code', 'utr_no')
    list_display = ['id', 'get_request_code', 'utr_no', 'utr_date', 'utr_remarks', 'base_amount', 'tds_amount', 'amount']
    list_filter = ['is_deleted', ('utr_date', admin.DateFieldListFilter),]

    def get_request_code(self, obj):
        return obj.payment_master.request_code if obj.payment_master else None
    get_request_code.short_description = 'Request Code'
    get_request_code.admin_order_field = 'payment_master__request_code'

@admin.register(NABLLabDirectory)
class NABLLabDirectoryAdmin(ModelAdmin):
    search_fields = ('name',)
    list_display = ['name', 'status','is_deleted',]
    list_filter = ['is_deleted','status',]

@admin.register(ProcurementRealTimeMaterialReceive)
class ProcurementRealTimeMaterialReceiveAdmin(admin.ModelAdmin):
    search_fields = ('purchase_order_item',)
    list_display = ['id', 'purchase_order_item', 'quantity',]
    list_filter = ['is_deleted',]

class ProcurementReturnableMaterialReturnQuantityDetailsAdmin(admin.ModelAdmin):
    list_display = ['id', 'returnable_material', 'quantity',]
    list_filter = ['is_deleted',]
admin.site.register(ProcurementReturnableMaterialReturnQuantityDetails, ProcurementReturnableMaterialReturnQuantityDetailsAdmin)
