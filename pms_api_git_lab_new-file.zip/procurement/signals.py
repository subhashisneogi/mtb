from django.db.models.signals import post_save, pre_delete, pre_save
from django.db import transaction
from django.dispatch import receiver
from django.db.models import Window
from django.db.models.functions import DenseRank

from administrations.utils import hrms_request
from .models import *
from .serializers import *
from .helper import *
@receiver(post_save, sender=GRN)
def signal_update_grn_items_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'approved' and not instance.is_deleted:
            for item in instance.procurement_grn_item.filter(is_deleted=False):
                final_received_quantity = calculate_quantity_on_uom(item.item.id,item.item.unit_of_mesurement.id,item.uom.id,item.received_quantity)
                final_return_quantity = calculate_quantity_on_uom(item.item.id,item.item.unit_of_mesurement.id,item.uom.id,item.return_quantity)
                update_inventory(
                    instance.organization.id,
                    item.item.id,
                    None,
                    instance.store.id,
                    instance.store.site.id,
                    float(final_received_quantity-final_return_quantity),
                    item.rate,
                    "GRN Approve",
                    instance.id,
                    validate_financialyear(instance)
                )


@receiver(post_save, sender=MaterialIssueItems)
def signal_update_issue_items_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if (not instance.is_deleted) and (not instance.material_issue.is_deleted) and (instance.status == "approved"):
            final_quantity = calculate_quantity_on_uom(instance.requested_material.id,instance.requested_material.unit_of_mesurement.id,instance.uom.id,instance.received_quantity_acknowledge)
            update_inventory(
                instance.material_issue.organization.id,
                instance.requested_material.id,
                None,
                instance.material_issue.store.id,
                instance.material_issue.store.site.id,
                (0 - float(final_quantity)),
                instance.rate,
                "Issue Item Approve",
                instance.id,
                validate_financialyear(instance.material_issue)
            )


@receiver(post_save, sender=MaterialIssueReturn)
def signal_update_issue_return_items_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'approved' and not instance.is_deleted:
            for item in instance.procurement_material_issue_return_items.filter(is_deleted=False, status="approved"):
                final_quantity = calculate_quantity_on_uom(item.item.id,item.item.unit_of_mesurement.id,item.uom.id,item.quantity)
                update_inventory(
                    instance.organization.id,
                    item.item.id,
                    None,
                    instance.return_to.id,
                    instance.return_to.site.id,
                    float(final_quantity),
                    item.rate,
                    "Issue Return Approve",
                    instance.id,
                    validate_financialyear(instance)
                )


@receiver(post_save, sender=MaterialWastage)
def signal_update_material_wastage_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'approved' and not instance.is_deleted and instance.is_stock_effect_required:
            for item in instance.procurement_material_wastage_items.filter(is_deleted=False, status="approved", type="wastage"):
                final_quantity = calculate_quantity_on_uom(item.item.id,item.item.unit_of_mesurement.id,item.uom.id,item.quantity)
                update_inventory(
                    instance.organization.id,
                    item.item.id,
                    None,
                    instance.store.id,
                    instance.store.site.id,
                    (0 - float(final_quantity)),
                    item.rate,
                    "Material Wastage Approve",
                    instance.id,
                    validate_financialyear(instance)
                )


@receiver(post_save, sender=ItemStockJV)
def signal_update_item_stock_jv_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'approved' and not instance.is_deleted:
            for item in instance.procurement_item_stock_jv_item.filter(is_deleted=False, status="approved"):
                final_quantity = calculate_quantity_on_uom(item.item.id,item.item.unit_of_mesurement.id,item.uom.id,item.quantity)
                quantity = 0
                type = ''
                if item.stock_type == "issue":
                    quantity = (0 - float(final_quantity))
                    type = 'Issue'
                if item.stock_type == "receive":
                    quantity = float(final_quantity)
                    type = 'Receive'
                update_inventory(
                    instance.organization.id,
                    item.item.id,
                    None,
                    item.store.id,
                    item.store.site.id,
                    quantity,
                    item.rate,
                    f"Item Stock JV {type} Approve",
                    instance.id,
                    validate_financialyear(instance)
                )


@receiver(post_save, sender=PhysicalStock)
def signal_update_physical_stock_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'post' and not instance.is_deleted:
            final_quantity = calculate_quantity_on_uom(instance.material.id,instance.material.unit_of_mesurement.id,instance.uom.id,instance.diff_qty)
            update_inventory(
                instance.organization.id,
                instance.material.id,
                None,
                instance.store.id,
                instance.store.site.id,
                float(final_quantity),
                instance.physical_rate,
                "Physical Stock Post",
                instance.id,
                validate_financialyear(instance)
            )


@receiver(post_save, sender=RawMaterialSales)
def signal_update_raw_material_sales_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'approved' and not instance.is_deleted and instance.is_stock_effect:
            for item in instance.procurement_raw_material_sales_items.filter(is_deleted=False):
                final_quantity = calculate_quantity_on_uom(item.item.id,item.item.unit_of_mesurement.id,item.uom.id,item.quantity)
                update_inventory(
                    instance.organization.id,
                    item.item.id,
                    None,
                    instance.store.id,
                    instance.store.site.id,
                    (0 - float(final_quantity)),
                    item.rate,
                    "Raw Material Sales Approve",
                    instance.id,
                    validate_financialyear(instance)
                )


@receiver(post_save, sender=Purchase)
def signal_update_purchase_items_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'approved' and not instance.is_deleted and not instance.grn:
            for item in instance.procurement_purchase_items.filter(is_deleted=False):
                final_quantity = calculate_quantity_on_uom(item.item.id,item.item.unit_of_mesurement.id,item.uom.id,item.quantity)
                update_inventory(
                    instance.organization.id,
                    item.item.id,
                    None,
                    instance.store.id,
                    instance.store.site.id,
                    float(final_quantity),
                    item.rate,
                    "Purchase Approve",
                    instance.id,
                    validate_financialyear(instance)
                )


@receiver(post_save, sender=StockTransferred)
def signal_update_stock_transferred_inventory(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'approved' and not instance.is_deleted:
            for item in instance.procurement_stock_transferred_items_stock_transferred.filter(is_deleted=False, status="approved"):
                final_quantity = item.quantity
                if instance.stock_type == 'material':
                    final_quantity = calculate_quantity_on_uom(item.material.id,item.material.unit_of_mesurement.id,item.uom.id,item.quantity)
                quantity = 0
                type = ''
                if instance.type == "out":
                    quantity = (0 - float(final_quantity))
                    type = 'OUT'
                if instance.type == "in":
                    quantity = float(final_quantity)
                    type = 'IN'
                update_inventory(
                    instance.organization.id,
                    item.material.id,
                    item.plant_machinery_machine.id,
                    instance.store.id,
                    instance.store.site.id,
                    quantity,
                    0,
                    f"Stock Transferred {type} Approve",
                    instance.id,
                    validate_financialyear(instance)
                )


# @receiver(post_save, sender=QuotationItems)
# def signal_quotation_gst_change(sender, instance, created, **kwargs):
#     with transaction.atomic():
#         if not instance.requested_material.gst_tax == instance.tax_head:

#             MaterialGstEntry.objects.update_or_create(
#             organization_id=instance.organization_id, material_id=instance.requested_material_id, 
#             defaults={"organization_id":instance.organization_id, "material_id":instance.requested_material_id, "tax_id":instance.tax_head_id})


@receiver(post_save, sender=PurchaseOrder)
def signal_update_vendor_status(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.status == 'approved' and not instance.is_deleted:
            VendorDatabase.objects.filter(vendor_id=instance.vendor_id).update(worked_with_sinpl='Yes')


# @receiver(post_save, sender=IndentItems)
# def signal_update_indent_status(sender, instance, **kwargs):
#     """
#     Post-save signal for IndentItems
  
#     """
#     with transaction.atomic():
#         if instance.status == 'checked':
#             instance.status = 'approved'
#             instance.approved_by = instance.checked_by if instance.checked_by else None
#             instance.approved_by_date = instance.checked_by_date if instance.checked_by_date else None
#             instance.sanctioned_quantity = instance.quantity
#             instance.save()


@receiver(post_save, sender=Quotation)
def signal_update_vendor_status(sender, instance, created, **kwargs):
    with transaction.atomic():
        if created and instance.rfq_vendor and instance.vendor:
            RFQVendorsMailList.objects.filter(rfq_vendors_id=instance.rfq_vendor.id,vendor_id=instance.vendor.id).update(allow_revision=False,regret=False)

@receiver(post_save, sender=Quotation)
def signal_update_vendor_rank(sender, instance, **kwargs):
    with transaction.atomic():
        quot_list = Quotation.cmobjects.filter(latest=True,rfq_vendor_id=instance.rfq_vendor.id).annotate(
            rank=Window(
                expression=DenseRank(),
                partition_by=[F('rfq_vendor_id')],
                order_by=F('total_amount').asc()
            ),
        ).values('id','rank')
        for quots in quot_list:
            Quotation.cmobjects.filter(pk=quots['id']).update(rfq_vendor_rank=quots['rank'],rfq_vendor_count=len(quot_list))

@receiver(post_save, sender=PaymentMasterUTR)
def signal_update_payment_status(sender, instance, **kwargs):
    with transaction.atomic():
        processed_amount = instance.payment_master.procurement_payment_master_utr.filter(is_deleted=False).aggregate(
            total=Coalesce(Sum('amount'), Value(0.0))
        )['total']
        amount = float(instance.payment_master.amount or 0.0)
        if processed_amount > 0:
            if amount > processed_amount:
                instance.payment_master.payment_status_type='partial'
            if amount <= processed_amount:
                instance.payment_master.payment_status_type='processed'
            instance.payment_master.save()

@receiver(post_save, sender=ProcurementStatusOfOrder)
def procurement_status_of_order_update_default(sender, instance, **kwargs):
    if instance.delivered:
        ProcurementStatusOfOrder.cmobjects.exclude(pk=instance.id).update(delivered=False)

@receiver(post_save, sender=PurchaseOrderItems)
def purchase_order_items_update_default(sender, instance, **kwargs):
    if instance.is_delivered:
        mark_po_delivered(instance.id)

@receiver(post_save, sender=GRNItems)
def grn_items_update_default(sender, instance, **kwargs):
    total_po_quantity = instance.purchase_order_item.quantity
    total_quantity = GRNItems.cmobjects.filter(purchase_order_item=instance.purchase_order_item).aggregate(Sum("quantity", default=0))['quantity__sum']
    if total_quantity >= total_po_quantity:
        mark_po_delivered(instance.purchase_order_item.id)

@receiver(post_save, sender=ProcurementRealTimeMaterialReceive)
def procurement_real_time_material_receive_update_default(sender, instance, **kwargs):
    total_po_quantity = instance.purchase_order_item.quantity
    total_quantity = ProcurementRealTimeMaterialReceive.cmobjects.filter(purchase_order_item=instance.purchase_order_item).aggregate(Sum("quantity", default=0))['quantity__sum']
    if total_quantity >= total_po_quantity:
        mark_po_delivered(instance.purchase_order_item.id)

@receiver(pre_save, sender=PaymentMaster)
def procurement_validate_unique_payment_no(sender, instance, **kwargs):
    qs = PaymentMaster.cmobjects.filter(
        payment_no=instance.payment_no,
        store=instance.store,
        project=instance.project,
        vendor=instance.vendor,
        site=instance.site
    ).exclude(status="rejected")
    if instance.id:
        qs = qs.exclude(id=instance.id)
    if qs.exists():
        raise APIException({
            'request_status': 0,
            'msg': f"Payment number '{instance.payment_no}' must be unique per project, vendor, and site."
        })

@receiver(pre_save, sender=PaymentMasterUTR)
def procurement_validate_unique_utr_no(sender, instance, **kwargs):
    qs = PaymentMasterUTR.cmobjects.filter(
        payment_master_id=instance.payment_master.id,
        utr_no=instance.utr_no,
    ).exclude(payment_master__status="rejected")
    if instance.id:
        qs = qs.exclude(id=instance.id)
    if qs.exists():
        raise APIException({
            'request_status': 0,
            'msg': f"Payment UTR number : '{instance.utr_no}' must be unique per request code."
        })

@receiver(post_save, sender=PaymentMaster)
def procurement_mark_pm_ref_stage_type(sender, instance, **kwargs):
    set_ref_stage_type_instance(instance,'pm')

@receiver(post_save, sender=CST)
def procurement_mark_cst_ref_stage_type(sender, instance, **kwargs):
    mark_cst_ref_stage_type(instance)

@receiver(post_save, sender=QuotationItems)
def procurement_mark_cst_ref_stage_type_quotation(sender, instance, **kwargs):
    if instance.is_selected_by_cst:
        cst_instance = CST.cmobjects.filter(rfq_vendor_id=instance.rfq_vendor_item.rfq_vendors.id,latest=True).first()
        if cst_instance:
            mark_cst_ref_stage_type(cst_instance)

@receiver(post_save, sender=MultiStageSetting)
def procurement_filter_conditions(sender, instance, **kwargs):
    MultiStageSetting.cmobjects.filter(pk=instance.id).update(conditions = [json.loads(s) for s in set(json.dumps(obj, sort_keys=True) for obj in instance.conditions)])