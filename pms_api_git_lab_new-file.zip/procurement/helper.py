from colorama import Back, Style
from django.db import transaction
from django.db.models import Sum, Q, Subquery, OuterRef, Case, When, F, Max, IntegerField, FloatField, ExpressionWrapper, Func, Value, CharField,DateField,Exists,BooleanField, Avg
from django.db.models.functions import Concat,ExtractDay,Replace
from django.db.models.expressions import Expression,Func
from rest_framework.exceptions import APIException
from django.template import Template, Context
from django.forms.models import model_to_dict
from datetime import datetime, time
from functools import reduce
import operator
import pandas as pd
import numpy as np
from django.db.models import Q
import pprint
import requests
import urllib3
from urllib.parse import quote
from rest_framework.test import APIRequestFactory
from django.http import QueryDict
from knox.models import AuthToken
from administrations.models import PmsUser
from requests.auth import HTTPBasicAuth
from administrations.utils import hrms_request,schedule_generic_mail,trigger_notifications
from misc.models import MimeTypes
from decimal import ROUND_HALF_UP
import mimetypes
from datetime import date, timedelta
from rest_framework.serializers import ModelSerializer
from django.apps import apps
import importlib
from .serializers import *
from .models import *
from user_permissions.models import *
from boq.models import *
from django.http import HttpResponse
from django.template.loader import render_to_string
import pdfkit
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import logging
import xlsxwriter
from urllib.parse import urlparse
from collections import Counter

import io, textwrap
from geopy.geocoders import Nominatim
from django.core.files.base import ContentFile
from django.core.files.base import ContentFile
from PIL import Image, ImageDraw, ImageFont, UnidentifiedImageError
from pathlib import Path

from django.db import connection
if connection.vendor == 'postgresql':
    from django.contrib.postgres.aggregates import StringAgg as StringAggCustom
else:
    from django_mysql.models import GroupConcat as StringAggCustom

def wrap_f_with_cast(expression, output_field):
    if isinstance(expression, Func):
        # For Function objects like Concat, use source_expressions
        if hasattr(expression, 'source_expressions'):
            new_sources = []
            for child in expression.source_expressions:
                new_sources.append(wrap_f_with_cast(child, output_field))
            expression.source_expressions = new_sources
        return expression
    elif isinstance(expression, Expression):
        # For other expressions, check for children
        if hasattr(expression, 'children'):
            new_children = []
            for child in expression.children:
                new_children.append(wrap_f_with_cast(child, output_field))
            expression.children = new_children
        return expression
    else:
        return Cast(expression, output_field=output_field)

class GroupConcat(StringAggCustom):
    def __init__(self, expression, **extra):
        # Set the default delimiter and output field
        delimiter = ', '
        output_field = extra.pop('output_field', CharField())
        if connection.vendor == 'postgresql' and 'ordering' in extra:
            extra.pop("ordering")
            if not isinstance(expression, Expression):
                extra['order_by'] = expression
                extra.pop("distinct")
        expression = Replace(
            Cast(wrap_f_with_cast(expression, CharField()), output_field=CharField()),
            Value(','),
            Value('&#44;')
        )
        super().__init__(
            expression, 
            delimiter=delimiter, 
            separator=delimiter, 
            output_field=output_field, 
            **extra
        )
def date_diff_handle(first_date,second_date):
    if connection.vendor == 'postgresql':
        return ExpressionWrapper(
            ExtractDay(
                Cast(first_date, output_field=DateField())-Cast(second_date, output_field=DateField()),
                output_field=IntegerField(),
            ),
            output_field=IntegerField(),
        )
    else:
        return ExpressionWrapper(
            Func(
                first_date,second_date,
                function="DATEDIFF",
                output_field=IntegerField(),
            ),
            output_field=IntegerField(),
        )

def get_model_details(type):
    MODELS = {
        'mr': {
            'permission': 'mr',
            'model_name': 'MaterialRequestMaster',
            'child_model_name': 'MaterialRequestMasterItems',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': 'material_request',
            'serializer': 'MaterialRequestSerializer',
        },
        'mr-items': {
            'permission': 'mr',
            'model_name': 'MaterialRequestMasterItems',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': 'MaterialRequestMaster',
            'child_parent_link_field': 'material_request',
            'serializer': 'MaterialRequestMasterItemsSerializer',
        },
        'indent': {
            'permission': 'indent',
            'model_name': 'Indent',
            'child_model_name': 'IndentItems',
            'stage_model_name': 'IndentStages',
            'parent_model_name': '',
            'child_parent_link_field': 'indent',
            'serializer': 'IndentSerializer',
        },
        'indent-items': {
            'permission': 'indent',
            'model_name': 'IndentItems',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': 'Indent',
            'child_parent_link_field': 'indent',
            'serializer': 'IndentItemsSerializer',
        },
        'quotation': {
            'permission': 'quotation',
            'model_name': 'Quotation',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'QuotationSerializer',
        },
        'rfq_vendor': {
            'permission': 'indent',
            'model_name': 'RFQVendors',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'RFQVendorsSerializer',
        },
        'po': {
            'permission': 'po',
            'model_name': 'PurchaseOrder',
            'child_model_name': '',
            'stage_model_name': 'PurchaseOrderStages',
            'parent_model_name': '',
            'child_parent_link_field': 'purchase_order',
            'serializer': 'PurchaseOrderSerializer',
        },
        'purchase-return': {
            'permission': 'purchase-return',
            'model_name': 'PurchaseReturn',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': 'master',
            'serializer': 'PurchaseReturnSerializer',
        },
        'physical-stock': {
            'permission': 'physical-stock',
            'model_name': 'PhysicalStock',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'PhysicalStockSerializer',
        },
        'gate-pass': {
            'permission': 'gate-pass',
            'model_name': 'GatePass',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'GatePassSerializer',
        },
        'bill-receive': {
            'permission': 'bill-receive',
            'model_name': 'BillReceive',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'BillReceiveSerializer',
        },
        'issue': {
            'permission': 'issue',
            'model_name': 'MaterialIssue',
            'child_model_name': 'MaterialIssueItems',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': 'material_issue',
            'serializer': 'MaterialIssueSerializer',
        },
        'issue-items': {
            'permission': 'issue',
            'model_name': 'MaterialIssueItems',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': 'MaterialIssue',
            'child_parent_link_field': 'material_issue',
            'serializer': 'MaterialIssueItemsSerializer',
        },
        'grn': {
            'permission': 'grn',
            'model_name': 'GRN',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'GRNSerializer',
        },
        'purchase': {
            'permission': 'purchase',
            'model_name': 'Purchase',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'PurchaseSerializer',
        },
        'tax-invoice': {
            'permission': 'tax-invoice',
            'model_name': 'TaxInvoice',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'TaxInvoiceSerializer',
        },
        'transporter-bill': {
            'permission': 'transporter-bill',
            'model_name': 'TransporterBill',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'TransporterBillSerializer',
        },
        'work-indent': {
            'permission': 'work-indent',
            'model_name': 'WorkIndent',
            'child_model_name': 'WorkIndentWorkDetail',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': 'work_indent',
            'serializer': 'WorkIndentSerializer',
        },
        'work-indent-items': {
            'permission': 'work-indent',
            'model_name': 'WorkIndentWorkDetail',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': 'WorkIndent',
            'child_parent_link_field': 'work_indent',
            'serializer': 'WorkIndentWorkDetailSerializer',
        },
        'work-order': {
            'permission': 'work-order',
            'model_name': 'WorkOrder',
            'child_model_name': '',
            'stage_model_name': 'WorkOrderStages',
            'parent_model_name': '',
            'child_parent_link_field': 'work_order',
            'serializer': 'WorkOrderSerializer',
        },
        'raw-material-sales': {
            'permission': 'raw-material-sales',
            'model_name': 'RawMaterialSales',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'RawMaterialSalesSerializer',
        },
        'issue-return': {
            'permission': 'material-issue-return',
            'model_name': 'MaterialIssueReturn',
            'child_model_name': 'MaterialIssueReturnItems',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': 'material_issue_return',
            'serializer': 'MaterialIssueReturnSerializer',
        },
        'issue-return-items': {
            'permission': 'material-issue-return',
            'model_name': 'MaterialIssueReturnItems',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': 'MaterialIssueReturn',
            'child_parent_link_field': 'material_issue_return',
            'serializer': 'MaterialIssueReturnItemsSerializer',
        },
        'material-wastage': {
            'permission': 'material-wastage',
            'model_name': 'MaterialWastage',
            'child_model_name': 'MaterialWastageItems',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': 'material_wastage',
            'serializer': 'MaterialWastageSerializer',
        },
        'material-wastage-items': {
            'permission': 'material-wastage',
            'model_name': 'MaterialWastageItems',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': 'MaterialWastage',
            'child_parent_link_field': 'material_wastage',
            'serializer': 'MaterialWastageItemsSerializer',
        },
        'item-stock-jv': {
            'permission': 'item-stock-jv',
            'model_name': 'ItemStockJV',
            'child_model_name': 'ItemStockJVFReceiveIssueItem',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': 'item_stock_jv',
            'serializer': 'ItemStockJVSerializer',
        },
        'item-stock-jv-items': {
            'permission': 'item-stock-jv',
            'model_name': 'ItemStockJVFReceiveIssueItem',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': 'ItemStockJV',
            'child_parent_link_field': 'item_stock_jv',
            'serializer': 'ItemStockJVFReceiveIssueItemSerializer',
        },
        'multi-stage-setting': {
            'permission': 'multi-stage-setting',
            'model_name': 'MultiStageSettingStages',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': 'MultiStageSetting',
            'child_parent_link_field': 'multi_stage_setting',
            'serializer': 'MultiStageSettingStagesSerializer',
        },
        'account-material': {
            'permission': 'account',
            'model_name': 'AccountMaterialProject',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'AccountMaterialProjectSerializer',
        },
        'account-material-grp': {
            'permission': 'account',
            'model_name': 'AccountMaterialProjectGroup',
            'child_model_name': 'AccountMaterialProject',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'AccountMaterialProjectGroupSerializer',
        },
        'account-project-budget': {
            'permission': 'account',
            'model_name': 'AccountProjectBudget',
            'child_model_name': 'BudgetBreakdown,AccountConsumptionBreakdown',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'AccountProjectBudgetSerializer',
        },
        'account-budget-breakdown': {
            'permission': 'account',
            'model_name': 'BudgetBreakdown',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'BudgetBreakdownSerializer',
        },
        'account-consumption-breakdown': {
            'permission': 'account',
            'model_name': 'AccountConsumptionBreakdown',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'AccountConsumptionBreakdownSerializer',
        },
        'stock-transferred': {
            'permission': 'stock-transferred',
            'model_name': 'StockTransferred',
            'child_model_name': 'StockTransferredItems',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': 'stock_transferred',
            'serializer': 'StockTransferredSerializer',
        },
        'fabrication-work': {
            'permission': 'fabrication-work',
            'model_name': 'FabricationWork',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'FabricationWorkSerializer',
        },
        'cst': {
            'permission': 'cst',
            'model_name': 'CST',
            'child_model_name': '',
            'stage_model_name': 'CSTStages',
            'parent_model_name': '',
            'child_parent_link_field': 'cst',
            'serializer': 'CSTSerializer',
        },
        'dsr': {
            'permission': 'dsr',
            'model_name': 'StoreDSRRecords',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'StoreDSRRecordsSerializer',
        },
        'pnmar': {
            'permission': 'pnmar',
            'model_name': 'PlantMachineryAssetRequisition',
            'child_model_name': '',
            'stage_model_name': 'PlantMachineryAssetRequisitionStages',
            'parent_model_name': '',
            'child_parent_link_field': 'asset_requisition',
            'serializer': 'PlantMachineryAssetRequisitionSerializer',
        },
        'pnmhsda': {
            'permission': 'pnmhsda',
            'model_name': 'PlantMachineryHSDApproval',
            'child_model_name': '',
            'stage_model_name': 'PlantMachineryHSDApprovalStages',
            'parent_model_name': '',
            'child_parent_link_field': 'hsd_approval',
            'serializer': 'PlantMachineryHSDApprovalSerializer',
        },
        'pnmcst': {
            'permission': 'pnmcst',
            'model_name': 'PlantMachineryCST',
            'child_model_name': '',
            'stage_model_name': 'PlantMachineryCSTStages',
            'parent_model_name': '',
            'child_parent_link_field': 'plant_machinery_cst',
            'serializer': 'PlantMachineryCSTStagesSerializer',
        },
        'vendor': {
            'permission': 'vendor',
            'model_name': 'VendorMasterV2',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'VendorMasterV2Serializer',
        },
        'pm': {
            'permission': 'pm',
            'model_name': 'PaymentMaster',
            'child_model_name': '',
            'stage_model_name': 'PaymentMasterStages',
            'parent_model_name': '',
            'child_parent_link_field': 'payment_master',
            'serializer': 'PaymentMasterStagesSerializer',
        },
        'pnmquotation': {
            'permission': 'pnmquotation',
            'model_name': 'PlantMachineryQuotation',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'PlantMachineryQuotationSerializer',
        },
        'pnmti': {
            'permission': 'pnmti',
            'model_name': 'PlantMachineryTaxInvoice',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'PlantMachineryTaxInvoiceSerializer',
        },
        'pnmhbi': {
            'permission': 'pnmhbi',
            'model_name': 'PlantMachineryHireBillInvoice',
            'child_model_name': '',
            'stage_model_name': 'PlantMachineryHireBillInvoiceStages',
            'parent_model_name': '',
            'child_parent_link_field': 'plant_machinery_hire_bill_invoice',
            'serializer': 'PlantMachineryHireBillInvoiceStagesSerializer',
        },
        'nabl-lab-directory': {
            'permission': 'nabl-lab-directory',
            'model_name': 'NABLLabDirectory',
            'child_model_name': '',
            'stage_model_name': '',
            'parent_model_name': '',
            'child_parent_link_field': '',
            'serializer': 'NABLLabDirectorySerializer',
        },
    }
    if type in MODELS:
        return MODELS[type]
    else:
        raise APIException({'request_status': 0, 'msg': "Invalid type"})

def process_filters(filter_name, filter_value):
    resp = Q()
    if filter_value == 'true':
        filter_value = True
    if filter_value == 'false':
        filter_value = False
    if filter_name.endswith('__isblank'):
        filter_name = filter_name.replace('__isblank','__exact')
        filter_value = ''
    if filter_name.endswith('__in') and not isinstance(filter_value,list):
        filter_value = filter_value.split(',')
    elif filter_name.startswith('compare__'):
        filter_value = F(filter_value)
        filter_name = filter_name.replace('compare__', '')
    if filter_name.startswith('exclude__'):
        resp = ~Q(**{filter_name.replace('exclude__', ''):filter_value})
    else:
        resp = Q(**{filter_name:filter_value})
    return resp

def process_filters_response(search):
    search_updated = []
    for filter_name, filter_value in search.items():
        search_list = Q()
        if '__or__' in filter_name:
            search_processed = []
            filter_name_list = filter_name.split('__or__')
            filter_value_list = filter_value.split('__or__')
            for index in range(len(filter_name_list)):
                search_processed.append(process_filters(filter_name_list[index],filter_value_list[index]))
            search_list = reduce(operator.or_,search_processed)
        else:
            search_list = process_filters(filter_name,filter_value)
        search_updated.append(search_list)
    return search_updated

def custom_filters(request, search: dict, extras: list, parent=None):
    valid_filters = ['id', 'all', 'page_size', 'page', 'order_by', 'hideLoader', 'order', 'my_debug']
    valid_filters = valid_filters+extras
    print(Back.CYAN,"*"*100)
    print("query_params -> ",request.query_params)
    print("search -> ",search)
    print('extras ->', extras)
    print("valid_filters -> ",valid_filters)
    for filter_name, filter_value in request.query_params.items():
        if filter_name not in valid_filters and filter_value:
            search[f'{filter_name}'] = filter_value
    if parent:
        search = {f'{parent}__{key}': value for key, value in search.items()}
    search_updated = process_filters_response(search)
    print("search -> ",search)
    print("search_updated -> ",search_updated)
    print("*"*100,Style.RESET_ALL)
    return search_updated


def issue_items_received_items_validation(issue_items: list(), received_items: list()) -> bool:
    ####### 1.0
    _field = ItemStockJVFReceiveIssueItem._meta.get_field("stock_type")
    choices = _field.choices
    cho1 = str(choices[0][0]) # issue
    cho2 = str(choices[1][0]) # receive
    _stock_type_issue_chk = [items['stock_type'] for items in issue_items]
    _stock_type_received_chk = [items['stock_type'] for items in received_items]
    res1 = list(filter(lambda x: cho1 not in x, _stock_type_issue_chk))
    res2 = list(filter(lambda x: cho2 not in x, _stock_type_received_chk))
    if len(res1) > 0 or len(res2) > 0:
        raise APIException({'request_status': 0, 'msg': "Wrong stock_type!"})

    ####### 2.0
    material_lst_issue = [items['item'] for items in issue_items]
    material_lst_received = [items['item'] for items in received_items]
    _intersect_materials = list(set(material_lst_issue) ^ set(material_lst_received))
    if len(_intersect_materials) > 0:
        raise APIException({'request_status': 0, 'msg': "Item missmatch between issue items and received items!"})

    ####### 3.0
    _x = {}
    for mat in material_lst_issue:
        _total_qty_per_item_issue = 0.0
        for i in issue_items:
            if mat == i['item']:
                _total_qty_per_item_issue += i['quantity']
        _x.update({mat.pk: _total_qty_per_item_issue})
    print(_x)

    _y = {}
    for mat in material_lst_received:
        _total_qty_per_item_received = 0.0
        for i in received_items:
            if mat == i['item']:
                _total_qty_per_item_received += i['quantity']
        _y.update({mat.pk: _total_qty_per_item_received})
    print(_y)

    modified_items = {k: _x[k] for k in _x if k in _y and _x[k] != _y[k]}
    print(modified_items)
    if len(modified_items) > 0:
        raise APIException({'request_status': 0, 'msg': "Issue item and received item quantity must be same!"})

    return True

def check_store_site(request):
    resp = {"site__in" : [],"store__in" : []}
    if any('site__isnull' in filter_name for filter_name in request.query_params.keys()):
        del resp["site__in"]
    else:
        user = request.user
        if user:
            site_details = SiteMaster.cmobjects.filter(users__in = [user])
            for values in site_details:
                resp["site__in"].append(values.id)
        if not resp["site__in"]:
            del resp["site__in"]
    if any('store__isnull' in filter_name for filter_name in request.query_params.keys()):
        del resp["store__in"]
    else:
        user = request.user
        if user:
            store_details = StoreMaster.cmobjects.filter(users__in = [user])
            for values in store_details:
                resp["store__in"].append(values.id)
        if not resp["store__in"]:
            del resp["store__in"]
    return resp


def check_user_doc_permissions(request,type,data):
    modules = {
        'mr': "MaterialRequestMaster",
        'indent': "Indent",
        'quotation': "Quotation",
        'po': "PurchaseOrder",
        'grn': "GRN",
        'work_order': "WorkOrder",
    }
    if 'id' in data:
        id = data['id']
        if type in modules:
            if type in ['mr', 'indent']:
                try:
                    id = data[get_model_details(type)['child_parent_link_field']]
                except Exception:
                    pass
            details = eval(f"{modules[type]}.cmobjects.filter(pk=id,).first()")
            user = request.user
            search = { "doctype": type }
            try:
                search['site'] = details.site
            except Exception:
                pass
            records = DocumentEmployeeApproval.cmobjects.filter(**search).values()
            if records:
                search['min_value__lte'] = details.total_amount
                search['max_value__gte'] = details.total_amount
                search['user'] = user
                has_permission = DocumentEmployeeApproval.cmobjects.filter(**search).exists()
                if not has_permission:
                    raise APIException({'request_status': 0, 'msg': "User does not have permission for this action", 'source': 'DocumentEmployeeApproval'})


def check_site_lock(request, type =""):
    type.replace("-", "_")
    modules = {
        'mr': "MaterialRequestMaster",
        'indent': "Indent",
        'quotation': "Quotation",
        'po': "PurchaseOrder",
        'grn': "GRN",
        'issue': 'MaterialIssue',
        'material_issue_return': 'MaterialIssueReturn',
        'gate_pass': 'GatePass'
    }
    current_date = datetime.now()
    current_month = current_date.month
    current_year = current_date.year
    id = request.query_params.get('id', None)
    if type in modules:
        if id:
            details = eval(f"{modules[type]}.cmobjects.filter(pk=id,).first()")
            if details:
                site = getattr(details, 'site', None)
                organization = getattr(details, 'organization', None)
                lock = MonthFinancialYearLock.cmobjects.filter(site=site, month=current_month, year=current_year,
                                                               organization=organization).first()
                if lock:
                    module_lock = getattr(lock, type, None)
                    if module_lock:
                        raise APIException({'request_status': 0, 'msg': f'Requested Site is currently locked'})
        else:
            request_datas = []
            if isinstance(request.data, list):
                request_datas = request.data
            else:
                request_datas = [request.data]
            for request_data in request_datas:
                organization = request_data.get('organization', None)
                if not organization:
                    organization_id = request.query_params.get('organization_id', None)
                    try:
                        organization = Organization.objects.get(pk=organization_id)
                    except Organization.DoesNotExist:
                        pass
                site = request_data.get('site', None)

                lock = MonthFinancialYearLock.cmobjects.filter(site=site, month=current_month, year=current_year,
                                                            organization=organization).first()
                if lock:
                    module_lock = getattr(lock, type, None)
                    if module_lock:
                        raise APIException({'request_status': 0, 'msg': f'Requested Site is currently locked'})


def check_editor_permissions(request,type=""):
    check_site_lock(request, type)
    check_item_group_restriction(request, type)
    check_site_stock_level(request, type)
    permission_type = type
    try:
        permission_type = get_model_details(type)['permission']
    except Exception as e:
        pass
    user = request.user
    data = []
    if not isinstance(request.data, list):
        data = [request.data]
    else:
        data = request.data
    for values in data:
        if user:
            if 'current_stage' in values:
                stage = values['current_stage']
                if stage and stage != 0:
                    type.replace("-", "_")
                    site = values['site'] if 'site' in values else request.query_params.get('site_id', None)
                    ref_stage_type = values['ref_stage_type'] if 'ref_stage_type' in values else None
                    organization = values['organization'] if 'organization' in values else request.query_params.get('organization_id', None)
                    id = values['id'] if 'id' in values else request.query_params.get('id', None)
                    if not ref_stage_type:
                        raise APIException({'request_status': 0, 'msg': "Approval flow link is missing.", 'source': 'MultiStageSetting'})
                    multi_stage_staging_filter = {
                        'site': site,
                        'organization': organization,
                        'pk': ref_stage_type,
                    }
                    multi_stage_staging = MultiStageSetting.cmobjects.filter(**multi_stage_staging_filter)
                    print(site,multi_stage_staging)
                    if multi_stage_staging:
                        multi_stage_staging_stages = multi_stage_staging.filter(
                            procurement_multi_stage_setting_stages__is_deleted=False,
                            procurement_multi_stage_setting_stages__stage=stage,
                            procurement_multi_stage_setting_stages__employee=user
                        ).exists()
                        print(stage,user,multi_stage_staging_stages)
                        if not multi_stage_staging_stages:
                            raise APIException({'request_status': 0, 'msg': "User does not have permission for this action", 'source': 'MultiStageSetting'})
                    else:
                        raise APIException({'request_status': 0, 'msg': "Invalid Stage.", 'source': 'MultiStageSetting Missing'})
            else:
                level_map = {
                    'pending': 0,
                    'checked': 1,
                    'rejected': 1,
                    'cancelled': 1,
                    'approved': 2,
                    'close': 2
                }
                permission_map = ['editor','checker','approver']
                level = 0
                permission_items = []
                if 'status' in values and values['status'] in level_map:
                    level = level_map[values['status']]
                if type != "":
                    counter = len(permission_map)-1
                    while counter >= level:
                        permission_items.append('procurement-'+permission_type+'-'+permission_map[counter])
                        if counter == 0 and request.method.upper() == 'GET':
                            permission_items.append('procurement-'+permission_type+'-viewer')
                        counter -= 1
                else:
                    permission_items.append('procurement-others')
                permission_items.append('procurement-site-manager') # TODO: Remove later
                print(level,permission_items)
                has_permission = UserWiseModulePermissions.cmobjects.filter(
                    user=user,
                    module_item__unique_id__in=permission_items,
                    level_permission=True,
                ).exists()
                if not has_permission:
                    raise APIException({'request_status': 0, 'msg': "User does not have permission for this action", 'source': 'UserWiseModulePermissions'})
                if level == 2:
                    check_user_doc_permissions(request,type,values)


def add_individual_inventory_logs(store, site, material_issue, quantity, requested_material, material_request_item):
    organization = site.organization
    store_inventory_item, created_site = Inventory.objects.get_or_create(
        material=requested_material,
        store=store,
        is_deleted=False,
        defaults={'organization': organization}
    )

    before_quantity = store_inventory_item.quantity

    InventoryLogs.objects.create(
        organization=organization,
        inventory=store_inventory_item,
        transaction_type='Subtraction',
        transaction_quantity=quantity,
        before_quantity=before_quantity,
        after_quantity=before_quantity - quantity,
        cost_per_unit=None,
        reference_type='Material Issue',
        reference_id=material_issue.id
    )
    store_inventory_item.quantity = before_quantity - quantity
    store_inventory_item.save()

    site_inventory_item, created_site = Inventory.objects.get_or_create(
        material=requested_material,
        site=site,
        is_deleted=False,
        defaults={'organization': organization}
    )

    before_quantity = site_inventory_item.quantity
    InventoryLogs.objects.create(
        organization=organization,
        inventory=site_inventory_item,
        transaction_type='Addition',
        transaction_quantity=quantity,
        before_quantity=before_quantity,
        after_quantity=before_quantity + quantity,
        cost_per_unit=None,
        reference_type='Material Issue',
        reference_id=material_issue.id
    )
    site_inventory_item.quantity = before_quantity + quantity
    site_inventory_item.save()

    if material_request_item is not None:
        total_requested_quantity = int(material_request_item.quantity_unit)
        fulfilled_percentage = (quantity / total_requested_quantity) * 100 if total_requested_quantity != 0 else 0
        material_request_item.is_fulfilled += Decimal(fulfilled_percentage)
        material_request_item.save()


@transaction.atomic
def update_inventory_logs(material_issue, material_issue_items_data):
    organization = material_issue.organization
    existing_items = material_issue.procurement_material_issue_item.all()
    for existing_item in existing_items:
        try:
            requested_item_data = next(
                item for item in material_issue_items_data if item['requested_material'] == existing_item.requested_material.id
            )
            new_quantity = int(requested_item_data['quantity'])
        except StopIteration:
            new_quantity = 0

        old_quantity = existing_item.quantity
        quantity_change = new_quantity - old_quantity
        if quantity_change != 0:
            existing_item.quantity = new_quantity
            existing_item.save()

        requested_material = existing_item.requested_material

        if new_quantity == 0 and old_quantity > 0:
            material_request_item = existing_item.material_request_item
            revert_individual_inventory_logs(abs(old_quantity), requested_material, material_issue, organization, material_request_item)
            continue

        store_inventory_item, created_store = Inventory.objects.get_or_create(
            material=requested_material,
            store=material_issue.store,
            is_deleted=False,
            defaults={'organization': organization}
        )
        if store_inventory_item and quantity_change != 0:
            transaction_type = 'Subtraction' if quantity_change < 0 else 'Addition'
            before_quantity = store_inventory_item.quantity
            after_quantity = before_quantity - quantity_change
            InventoryLogs.objects.create(
                organization=organization,
                inventory=store_inventory_item,
                transaction_type=transaction_type,
                transaction_quantity=abs(quantity_change),
                before_quantity=before_quantity,
                after_quantity=after_quantity,
                cost_per_unit=None,
                reference_type='Material Issue',
                reference_id=material_issue.id
            )
            store_inventory_item.quantity = after_quantity
            store_inventory_item.save()

        site_inventory_item, created_site = Inventory.objects.get_or_create(
            material=requested_material,
            site=material_issue.site,
            is_deleted=False,
            defaults={'organization': organization}
        )

        if site_inventory_item and quantity_change != 0:
            transaction_type = 'Subtraction' if quantity_change < 0 else 'Addition'
            before_quantity = site_inventory_item.quantity
            after_quantity = before_quantity + quantity_change
            InventoryLogs.objects.create(
                organization=organization,
                inventory=site_inventory_item,
                transaction_type=transaction_type,
                transaction_quantity=abs(quantity_change),
                before_quantity=old_quantity,
                after_quantity=after_quantity,
                cost_per_unit=None,
                reference_type='Material Issue',
                reference_id=material_issue.id
            )
            site_inventory_item.quantity = after_quantity
            site_inventory_item.save()

        material_request_item = existing_item.material_request_item
        total_requested_quantity = int(material_request_item.quantity_unit)

        old_percentage = (old_quantity / total_requested_quantity) * 100 if total_requested_quantity != 0 else 0
        new_percentage = (new_quantity / total_requested_quantity) * 100 if total_requested_quantity != 0 else 0

        material_request_item.is_fulfilled -= Decimal(old_percentage)
        material_request_item.is_fulfilled += Decimal(new_percentage)
        material_request_item.save()

    for requested_item_data in material_issue_items_data:
        material_request_item = None
        if requested_item_data['material_request_item'] is not None:
            try:
                material_request_item = MaterialRequestMasterItems.objects.get(pk=requested_item_data['material_request_item'])
            except MaterialRequestMasterItems.DoesNotExist:
                pass
        try:
            existing_item = MaterialIssueItems.objects.get(
                material_issue=material_issue,
                requested_material=requested_item_data['requested_material'],
            )
        except MaterialIssueItems.DoesNotExist:
            existing_item = None

        # New Item
        if not existing_item:
            new_quantity = int(requested_item_data['quantity'])
            requested_material = requested_item_data['requested_material']
            add_individual_inventory_logs(store=material_issue.store,
                                          site=material_issue.site,
                                          material_issue=material_issue,
                                          quantity=new_quantity,
                                          requested_material=requested_material,
                                          material_request_item=material_request_item
                                          )


@transaction.atomic
def revert_individual_inventory_logs(quantity, requested_material, material_issue, organization, material_request_item):
    store_inventory_item, created_store = Inventory.objects.get_or_create(
        material=requested_material,
        store=material_issue.store,
        is_deleted=False,
        defaults={'organization': organization}
    )

    before_quantity = store_inventory_item.quantity
    InventoryLogs.objects.create(
        organization=organization,
        inventory=store_inventory_item,
        transaction_type='Addition',
        transaction_quantity=quantity,
        before_quantity=before_quantity,
        after_quantity=before_quantity + quantity,
        cost_per_unit=None,
        reference_type='Material Issue (Revert)',
        reference_id=material_issue.id
    )
    store_inventory_item.quantity = before_quantity + quantity
    store_inventory_item.save()

    site_inventory_item, created_site = Inventory.objects.get_or_create(
        material=requested_material,
        site=material_issue.site,
        is_deleted=False,
        defaults={'organization': organization}
    )

    before_quantity = site_inventory_item.quantity
    InventoryLogs.objects.create(
        organization=organization,
        inventory=site_inventory_item,
        transaction_type='Subtraction',
        transaction_quantity=quantity,
        before_quantity=before_quantity,
        after_quantity=before_quantity - quantity,
        cost_per_unit=None,
        reference_type='Material Issue (Revert)',
        reference_id=material_issue.id
    )
    site_inventory_item.quantity = before_quantity - quantity
    site_inventory_item.save()

    if material_request_item is not None:
        total_requested_quantity = int(material_request_item.quantity_unit)
        fulfilled_percentage = (quantity / total_requested_quantity) * 100
        material_request_item.is_fulfilled -= Decimal(fulfilled_percentage)
        material_request_item.save()


def revert_inventory_logs(material_issue):
    organization = material_issue.organization

    for issued_item in material_issue.procurement_material_issue_item.all():
        quantity = issued_item.quantity
        requested_material = issued_item.requested_material
        material_request_item = issued_item.material_request_item
        revert_individual_inventory_logs(quantity, requested_material, material_issue, organization, material_request_item)


def check_approval(instance,target_status,target_stage,current_user):
    level_map = {
        'pending': 0,
        'checked': 1,
        'hold': 1,
        'rejected': 2,
        'cancelled': 2,
        'approved': 2,
    }
    current_status = getattr(instance,'status', None)
    current_stage = getattr(instance,'current_stage', None)
    if current_status:
        if current_status in ["approved", "rejected", "cancelled"]:
            raise APIException(f'Record already {current_status}')
        if target_status:
            if level_map[current_status] >= level_map[target_status]:
                raise APIException(f'Record already {current_status}')
        if current_status == 'approved' and instance.__class__.__name__ == 'MaterialRequestMasterItems':
            allowed_approvers = (list(instance.requested_material.material_type.mr_approver.values_list('username',flat=True)) if instance.requested_material.material_type else []) if instance.requested_material else []
            if allowed_approvers:
                if not current_user.username in allowed_approvers:
                    raise APIException("User does not have permission for this action")
    if (not current_stage is None) and (not target_stage is None):
        if not current_stage == target_stage-1:
            raise APIException("Invalid Action.")


def update_approved_status_by(instance: models.Model, current_user: PmsUser, status_value: str) -> bool:
    _field_name = status_value + '_by'
    _date_field_name = status_value + '_by' + '_date'
    if hasattr(instance, _field_name):
        setattr(instance, _field_name, current_user)
    if hasattr(instance, _date_field_name):
        setattr(instance, _date_field_name, datetime.now())
    return True


def generate_all_code(record,list):
    print('list',list)
    project = None
    if hasattr(record,'project'):
        project = record.project
    elif hasattr(record,'site'):
        if record.site and hasattr(record.site,'project'):
            project = record.site.project
    if project:
        # project_data = ProjectData.cmobjects.filter(project=project, form__form_internal_name='project_id').first()
        # if project_data:
        #     list.append(str(project_data.value))
        list.append(str(project.project_code))

    base = '-'.join(list)
    try:
        organization_id = record.organization.id
        # CodeRecord.cmobjects.lock()
        version = 1
        last_record = CodeRecord.cmobjects.filter(organization_id=organization_id,base=base).values('last_record')
        if last_record:
            version = int(last_record[0]['last_record'])+1
        list.append(str(version))
        CodeRecord.objects.update_or_create(organization_id=organization_id, base=base, defaults={'last_record' : version})
    finally:
        pass
        # CodeRecord.cmobjects.unlock()
    print('return list',list)
    return '-'.join(list)


def generate_all_mat_code(record,list):
    material_type = None
    if hasattr(record, 'material_type'):
        material_type = record.material_type

    if material_type:
        base = '-'.join(list)
        last_record = CodeRecord.cmobjects.filter(organization_id=record.organization.id,base=base, is_mat=True).values('last_record')

        if last_record:
            version = int(last_record[0]['last_record'])+1
        else:
            version = 1
        list.append(str(version).zfill(4))
        CodeRecord.objects.update_or_create(organization_id=record.organization.id, base=base, is_mat=True, defaults={'last_record' : version})
        return '-'.join(list)
    return ''


def generate_rfq_link(vendor_id,id,organization,module_type,link_type):
    links = {
        'purchase': {
            'gst': str(os.getenv('FE_QUOTATION_BASE_URL_WITH_GST','')),
            'non-gst': str(os.getenv('FE_QUOTATION_BASE_URL_WITHOUT_GST','')),
        },
        'pnm': {
            'gst': str(os.getenv('FE_PNM_QUOTATION_BASE_URL_WITH_GST','')),
            'non-gst': str(os.getenv('FE_PNM_QUOTATION_BASE_URL_WITHOUT_GST','')),
        },
    }
    token = None
    user_permission = UserWiseModulePermissions.cmobjects.filter(
        module_item__unique_id__in=['vendor-user'],
        level_permission=True,
    ).first()
    if user_permission:
        token = AuthToken.objects.create(user_permission.user)[1]
    _ids = {
        'vendor_id': vendor_id,
        'enquiry_id': id,
        'organization_id': organization,
        'token': token,
    }
    _ids_str = json.dumps(_ids)
    _ids_str_b = str(base64.b64encode(str(_ids_str).encode("ascii")).decode("ascii"))
    _ids_url = urlencode({"": _ids_str_b})
    return links[module_type][link_type] + _ids_url[1:] + '/'


def process_rfq_mail(vendor_id_list,data):
    try:
        email_template = EmailTemplates.cmobjects.get(template_name='RFQ')
        for vendor_id in vendor_id_list:
            vendor_details = get_vendor_data(vendor_id)
            if vendor_details:
                link_without_gst = generate_rfq_link(vendor_id,data['id'],data['organization'],'purchase','non-gst')
                link_with_gst = generate_rfq_link(vendor_id,data['id'],data['organization'],'purchase','gst')
                data['vendor_link_without_gst'] = link_without_gst
                data['vendor_link_with_gst'] = link_with_gst
                data['vendor_name'] = vendor_details['vendor_name']
                email_send_details = schedule_generic_mail(subject=data['enquiry_subject'], to_mail_list=[vendor_details['vendor_email_id']], context=json.loads(json.dumps(data, default=str)), template=email_template)
                email_send_id = None
                if email_send_details:
                    email_send_id = email_send_details.id
                RFQVendorsMailList.objects.update_or_create(
                    organization_id=data['organization'],
                    rfq_vendors_id=data['id'],
                    vendor_id=vendor_id,
                    defaults={'email_send_id' : email_send_id}
                )
        return 1
    except Exception as e:
        print(e)
        return 0


def process_pnm_rfq_mail(vendor_id_list,data):
    """
    Function to process and send RFQ emails to vendors and create RFQ mail records.
    """
    try:
        email_template = EmailTemplates.cmobjects.get(template_name='PNMRFQ')
        for vendor_id in vendor_id_list:
            vendor_details = get_vendor_data(vendor_id)
            if vendor_details:
                link_without_gst = generate_rfq_link(vendor_id,data['id'],data['organization'],'pnm','non-gst')
                link_with_gst = generate_rfq_link(vendor_id,data['id'],data['organization'],'pnm','gst')
                data['vendor_link_without_gst'] = link_without_gst
                data['vendor_link_with_gst'] = link_with_gst
                data['vendor_name'] = vendor_details['vendor_name']
                email_send_details = schedule_generic_mail(subject=data['enquiry_subject'], to_mail_list=[vendor_details['vendor_email_id']], context=json.loads(json.dumps(data, default=str)), template=email_template)
                email_send_id = None
                if email_send_details:
                    email_send_id = email_send_details.id
                PlantMachineryRFQVendorsMailList.cmobjects.create(
                    organization_id=data['organization'],
                    plant_machinery_rfq_vendor_id=data['id'],
                    vendor_id=vendor_id,
                    email_send_id=email_send_id,
                )
        return 1
    except Exception as e:
        print(e)
        return 0
    
def get_latest_boq(project):
    latest_boq_id = 0
    search = {}
    if project:
        search['project'] = project
        search['status'] = 'approved'
        boq_details = BOQ.cmobjects.filter(**search).order_by('-version').first()
        if boq_details:
            latest_boq_id = boq_details.id
        else:
            search['status'] = 'pending'
            boq_details = BOQ.cmobjects.filter(**search).order_by('-version').first()
            if boq_details:
                latest_boq_id = boq_details.id
    return latest_boq_id


def search_mr_boq(id,project,type=''):
    if project:
        resp = []
        material_list = []
        material_search = {}
        latest_boq_id = get_latest_boq(project)
        if id:
            material_search['material__in'] = str(id).split(',')
        material_search['wbs_list__boq'] = latest_boq_id
        wbs_material_details = pd.DataFrame(WBSMaterial.cmobjects.filter(**material_search).values(
            'budgeted_quantity','wbs_list__boq__name','wbs_list__wbs','id','material','chainage__name','wbs_list','quantity','rate'
        ))
        # print(wbs_material_details['wbs_list'])
        if 'material' in wbs_material_details:
            material_list = list(set(list(wbs_material_details['material'])))
        else:
            material_list = str(id).split(',') if id else []
        if 'wbs_list' in wbs_material_details and type == 'list':
            wbs_code_details = pd.DataFrame(BOQChainageExecutiveSummeryData.cmobjects.filter(wbs__in=wbs_material_details['wbs_list']).values(
                'id','wbs','form','type','value'
            ))
            # print(wbs_code_details)
            for index, row in wbs_material_details.iterrows():
                if 'wbs' in wbs_code_details:
                    for index1, row1 in wbs_code_details.loc[(wbs_code_details['wbs'].values == row['wbs_list']) & (wbs_code_details['type'].values == 'C')].iterrows():
                        row1['wbs_list__boq__name'] = row['wbs_list__boq__name']
                        row1['wbs_list__wbs'] = row['wbs_list__wbs']
                        row1['material'] = row['material']
                        row1['rate'] = row['rate']
                        row1['chainage__name'] = row['chainage__name']
                        row1['wbs_list'] = row['wbs_list']
                        row1['wbs_material_id'] = row['id']
                        row1['total_budgeted_quantity'] = row['budgeted_quantity']
                        result = 0
                        try:
                            temp = list(wbs_code_details.loc[(wbs_code_details['wbs'].values == row['wbs_list']) & (wbs_code_details['type'].values != 'C')]['value'].items())
                            if len(temp) > 0:
                                result = float(temp[0][1])*float(row['quantity'])
                        except Exception as e:
                            pass
                        row1['budgeted_quantity'] = result
                        resp.append(row1.to_dict())
                else:
                    row1 = {'id': '','wbs': '','form': '','type': '','value': ''}
                    row1['wbs_list__boq__name'] = row['wbs_list__boq__name']
                    row1['wbs_list__wbs'] = row['wbs_list__wbs']
                    row1['material'] = row['material']
                    row1['rate'] = row['rate']
                    row1['chainage__name'] = row['chainage__name']
                    row1['wbs_list'] = row['wbs_list']
                    row1['wbs_material_id'] = row['id']
                    row1['budgeted_quantity'] = row['budgeted_quantity']
                    row1['total_budgeted_quantity'] = row['budgeted_quantity']
                    resp.append(row1)
        else:
            resp = wbs_material_details.to_dict('records')
        # print(resp)
        return resp,latest_boq_id,material_list
    else:
        raise APIException({'request_status': 0, 'msg': "Not Found"})

def get_location_name(latitude, longitude):
    try:
        geolocator = Nominatim(user_agent="facility_site_app")
        location = geolocator.reverse(f"{latitude}, {longitude}", language="en")
        return location.address if location else ""
    except Exception as e:
        print(f"Error fetching location name: {e}")
        return ""

def overlay_text_on_image_file(content_file, text):
    content_file.seek(0)
    image = Image.open(io.BytesIO(content_file.read())).convert("RGBA")
    draw = ImageDraw.Draw(image)
    base_dir = Path(__file__).resolve().parent.parent  
    font_path = base_dir / "email_config" / "templates" / "font" / "Poppins" / "Poppins-Bold.ttf"
    try:
        font_size = max(10, image.width // 80)
        font = ImageFont.truetype(font_path, font_size)
    except OSError:
        font = ImageFont.load_default()
    lines = [wrapped if wrapped else [""] for line in text.split("\n") 
             for wrapped in [textwrap.wrap(line, width=40)]]
    lines = sum(lines, [])  # flatten

    line_heights = [draw.textbbox((0, 0), l, font=font)[3] - draw.textbbox((0, 0), l, font=font)[1] for l in lines]
    total_height = sum(line_heights) + (len(lines) - 1) * 5
    gradient_height = total_height + 15
    gradient = Image.new("RGBA", (image.width, gradient_height))
    grad_draw = ImageDraw.Draw(gradient)
    for i in range(image.width):
        shade = int((i / image.width) * 80)
        alpha = int(255 * (1 - i / image.width))
        grad_draw.line([(i, 0), (i, gradient_height)], fill=(shade, shade, shade, alpha))

    image.paste(gradient, (0, image.height - gradient_height), gradient)

    x, y = 10, image.height - gradient_height + 5
    for line in lines:
        draw.text((x, y), line, fill="white", font=font)
        y += font.size + 5

    output = io.BytesIO()
    image.save(output, format="PNG", optimize=True)
    output.seek(0)
    return ContentFile(output.read(), name=content_file.name)

def is_image(file_path):
    try:
        with Image.open(file_path) as img:
            return True
    except (UnidentifiedImageError, IOError):
        return False
def process_attachments(file_data):
    mime_type = file_data.get('mime_type', None)
    file_content = file_data.get('file_data', None)
    raw_file_name = file_data.get('raw_file_name', None)
    latitude = file_data.get('latitude', None)
    longitude = file_data.get('longitude', None)
    try:
        if file_content:
            attachment_content = base64.b64decode(file_content)
            file_name = raw_file_name if raw_file_name else f"{uuid.uuid4().hex}"
            # file_name = f"{uuid.uuid4().hex}"
            mime_type_obj = MimeTypes.objects.filter(mime_type=mime_type).first()
            if not mime_type_obj:
                file_extension = mimetypes.guess_extension(mime_type)
            else:
                file_extension=mime_type_obj.file_extension
            file_extension = file_extension if file_extension else '.bin'
            file_name_with_extension = f"{file_name}{file_extension}"
            content_file = ContentFile(attachment_content, name=file_name_with_extension)
            if latitude and longitude and is_image(content_file):
                location_name = get_location_name(latitude,longitude)
                raw_file_name_with_path = os.path.join("raw_file", file_name_with_extension)
                raw_content_file = ContentFile(attachment_content, name=raw_file_name_with_path)
                raw_storage_path = os.path.join("tender/site_survey/facility_site", raw_file_name_with_path)
                default_storage.save(raw_storage_path, raw_content_file)
                processed_file = overlay_text_on_image_file(content_file, location_name)
                return processed_file
            else:
                return content_file
        else:
            None
    except Exception as e:
        print(Back.MAGENTA, f"Exception while adding new attachments: {str(e)}", Style.RESET_ALL)

def rcv_process_attachments(file_data):
    mime_type = file_data.get('rcv_mime_type', None)
    file_content = file_data.get('rcv_file_data', None)
    try:
        if file_content:
            attachment_content = base64.b64decode(file_content)
            file_name = f"{uuid.uuid4().hex}"
            mime_type_obj = MimeTypes.objects.filter(mime_type=mime_type).first()
            if not mime_type_obj:
                file_extension = mimetypes.guess_extension(mime_type)
            else:
                file_extension=mime_type_obj.file_extension
            file_extension = file_extension if file_extension else '.bin'
            file_name_with_extension = f"{file_name}{file_extension}"
            return ContentFile(attachment_content, name=file_name_with_extension)
        else:
            None
    except Exception as e:
        print(Back.MAGENTA, f"Exception while adding new attachments: {str(e)}", Style.RESET_ALL)
    return None

def total_project_quantity(material_id,project_id):
    total_quantity = 0.0
    recieved_items,latest_boq_id,materials = search_mr_boq(material_id,project_id)
    for temp in recieved_items:
        total_quantity += float(temp['budgeted_quantity'])
    return total_quantity


def total_recieved_quantity(material_id,project_id):
    recieved_items = 0.0
    temp = {
        'GRNItems':[
            {
                'item': material_id,
                'grn__store__site__project': project_id,
                # 'grn__status__in': ['approved','close'],
                'is_deleted': False,
                'grn__is_deleted': False,
            },
            [
                'item_id',
                'item__unit_of_mesurement_id',
                'uom_id',
                'received_quantity',
                'return_quantity',
            ]
        ],
        # 'PurchaseItems':[
        #     {
        #         'item': material_id,
        #         'purchase__store__site__project': project_id,
        #         'purchase__status__in': ['approved','close'],
        #         'purchase__grn__isnull': True,
        #         'is_deleted': False,
        #         'purchase__is_deleted': False,
        #     },
        #     [
        #         'item',
        #         'uom',
        #         'quantity',
        #     ]
        # ],
        # 'MaterialIssueReturnItems':[
        #     {
        #         'item': material_id,
        #         'material_issue_return__return_to__site__project': project_id,
        #         'material_issue_return__status__in': ['approved','close'],
        #         'status__in': ['approved','close'],
        #         'is_deleted': False,
        #         'material_issue_return__is_deleted': False,
        #     },
        #     [
        #         'item',
        #         'uom',
        #         'quantity',
        #     ]
        # ],
        # 'ItemStockJVFReceiveIssueItem':[
        #     {
        #         'item': material_id,
        #         'store__site__project': project_id,
        #         'item_stock_jv__status__in': ['approved','close'],
        #         'status__in': ['approved','close'],
        #         'stock_type': 'receive',
        #         'is_deleted': False,
        #         'item_stock_jv__is_deleted': False,
        #     },
        #     [
        #         'item',
        #         'uom',
        #         'quantity',
        #     ]
        # ],
    }
    for key,value in temp.items():
        details = eval(f'{key}.cmobjects.filter(**value[0]).values(*value[1])')
        for detail in details:
            recieved_items += calculate_quantity_on_uom(detail[value[1][0]],detail[value[1][1]],detail[value[1][2]],float(float(detail[value[1][3]])-float(detail[value[1][4]])))
    return recieved_items


def total_balance_quantity(material_id,project_id):
    total_quantity = float(total_project_quantity(material_id,project_id))-float(total_recieved_quantity(material_id,project_id))
    return total_quantity


def validate_financialyear(instance):
    if not instance.date:
        instance.date = date.today()
        instance.save()
    fy = FinancialYear.cmobjects
    record = fy.filter(start_date__lte=instance.date,end_date__gte=instance.date)
    if not record:
        record = fy
    return record.first()


@transaction.atomic
def update_inventory(organization_id,material_id,plant_machinery_machine_id,store_id,site_id,quantity,rate,reference_type,reference_id,financialyear):
    """
    Update inventory :

    organization (obj),
    material,
    store (obj),
    site (obj),
    quantity (int),
    rate (float),
    reference_type (text),
    reference_id (int)
    """
    search = {
        "organization_id": organization_id,
        "material_id": material_id,
        "plant_machinery_machine_id": plant_machinery_machine_id,
        "store_id": store_id,
        "site_id": site_id,
        "financialyear": financialyear,
    }
    old_qty = 0
    new_qty = 0
    if Inventory.cmobjects.filter(**search).exists():
        inventory = Inventory.cmobjects.filter(**search).first()
        old_qty = float(inventory.quantity)
        new_qty = float(inventory.quantity) + float(quantity)
        # if new_qty < 0:
        #     raise APIException({'request_status': 0, 'msg': "Not enough quantity"})
        inventory.quantity = new_qty
        inventory.save()
    else:
        search["quantity"] = quantity
        search["opening_quantity"] = 0
        new_qty = quantity
        # if new_qty < 0:
        #     raise APIException({'request_status': 0, 'msg': "Not enough quantity"})
        inventory = Inventory.objects.create(**search)
    try:
        InventoryLogs.objects.create(
            organization_id = organization_id,
            inventory = inventory,
            before_quantity = old_qty,
            transaction_quantity = quantity,
            after_quantity = new_qty,
            cost_per_unit = rate,
            reference_type = reference_type,
            reference_id = reference_id,
        )
    except Exception as e:
        print(f"exception: {e}")


def update_inventory_physical_stock(instance: PhysicalStock, user: PmsUser)-> bool:
    """
    Update Inventory and Inventory Log from Physical Stock.
    """
    search = {
        "organization_id": instance.organization.id,
        "material_id": instance.material.id,
    }
    if instance.store:
        search["store_id"] = instance.store.id
    elif instance.site:
        search["site_id"] = instance.site.id
    before_quantity = 0
    if Inventory.cmobjects.filter(**search).exists():
        inventory = Inventory.cmobjects.filter(**search).first()
        before_quantity = inventory.quantity

        inventory.quantity = float(instance.actual_qty)
        inventory.cost_per_unit = float(instance.actual_rate)
        inventory.remarks = str(instance.remarks)
        inventory.financial_year = instance.financial_year
        print("----------------->>>>>")
        inventory.save()
    else:
        search["quantity"] = instance.actual_qty
        search["opening_quantity"] = instance.actual_rate
        search["updated_by"] = user
        inventory = Inventory.objects.create(**search)
    try:
        InventoryLogs.objects.create(
            organization=instance.organization,
            inventory=inventory,
            before_quantity=before_quantity,
            transaction_quantity=instance.physical_qty,
            after_quantity=instance.physical_qty,
            cost_per_unit=instance.actual_rate,
            reference_type=instance._meta.model.__name__,
            reference_id=instance.id,
            updated_by=user
        )
    except Exception as e:
        print(f"exception----> {e}")
    return True


def update_inventory_closing_stock_trn_helper(inventory: Inventory,
                                       user: PmsUser,
                                       updated_price: float,
                                       current_financial_year: FinancialYear,
                                       msg="") -> bool:
    """
    Update Inventory on closing stock TRN To Next Year.
    and Update InventoryLog
    """

    print("user", user)
    print("inventory id", inventory.id)
    ### create inventory with new current_financial_year
    try:
        if Inventory.cmobjects.filter(organization=inventory.organization, material=inventory.material, store=inventory.store, financialyear=current_financial_year).exists():
            # update inventory
            inventory.cost_per_unit = updated_price
            inventory.updated_by = user
            inventory.financialyear = current_financial_year  #
            inventory.remarks = msg
            inventory.save()
            print("-----inventory updated-------")
        else:
            # create new inventory
            Inventory.cmobjects.create(
                organization=inventory.organization,
                material=inventory.material,
                store=inventory.store,
                quantity=inventory.quantity,
                opening_quantity=inventory.quantity,
                min_stock_quantity=inventory.min_stock_quantity,
                cost_per_unit=updated_price,  # new average price
                remarks=msg,
                stock_type=inventory.stock_type,
                opening_type=inventory.opening_type,
                financialyear=current_financial_year  #
            )
            print("-----inventory created-------")
    except Exception as e:
        print("ERROR-->", str(e))
        raise APIException(e)

    # update inventory log
    try:
        InventoryLogs.objects.create(
            organization=inventory.organization,
            inventory=inventory,
            # before_quantity=,
            # after_quantity=,
            transaction_quantity=inventory.quantity,
            cost_per_unit=updated_price,
            reference_type=msg,
            reference_id=inventory.id,
            updated_by=user
        )
        print("---- inventory log created ----")
    except Exception as e:
        print(f"exception----> {e}")
    return True


def indent_qty_check(organization_id, site, material, indent_item_id: None, issue_item_id: None) -> bool:
    if indent_item_id:
        print('indent:')
        indent_items = IndentItems.cmobjects.filter(pk=indent_item_id, organization_id=organization_id).first()
        quantity = float(indent_items.quantity) if indent_items else 0.0
    if issue_item_id:
        print('issue')
        issue_items = MaterialIssueItems.cmobjects.filter(pk=issue_item_id, organization_id=organization_id).first()
        quantity = float(issue_items.quantity) if issue_items else 0.0


    # get all approved indent in the same site and same material(item)
    all_mat_indent = (IndentItems.cmobjects.filter(indent__site=site, requested_material=material, status='approved')
                           .aggregate(total_quantity=Sum('quantity')))
    sum_indent_quantity_approved = all_mat_indent['total_quantity'] if all_mat_indent['total_quantity'] else 0.0

    # get all approved mr in the same site and same material(item)
    all_mat_mr = (MaterialRequestMasterItems.cmobjects.filter(material_request__site=site, requested_material=material, status='approved')
                       .aggregate(total_quantity=Sum('quantity_unit')))
    sum_mr_quantity_approved = all_mat_mr['total_quantity'] if all_mat_mr['total_quantity'] else 0.0

    # get all approved issue in the same site and same material(item)
    all_mat_issue = (MaterialIssueItems.cmobjects.filter(material_issue__site=site, requested_material=material)
                     .aggregate(total_quantity=Sum('quantity')))
    sum_issue_quantity_approved = all_mat_issue['total_quantity'] if all_mat_issue['total_quantity'] else 0.0

    print("@ indent_qty_check")
    print("----->","quantity->",quantity,
          "sum_indent_quantity_approved->",sum_indent_quantity_approved,
          "sum_mr_quantity_approved->",sum_mr_quantity_approved,
          "sum_issue_quantity_approved->",sum_issue_quantity_approved)

    if (quantity > (sum_indent_quantity_approved + sum_mr_quantity_approved + sum_issue_quantity_approved  )):
        raise APIException({'request_status': 0, 'msg': "indent quantity is higher than request"})

    return True


def update_fulfilled_percentage(material_request_item, quantity, update_type):
    if material_request_item is not None:
        total_requested_quantity = int(material_request_item.quantity_unit)
        fulfilled_percentage = (quantity / total_requested_quantity) * 100 if total_requested_quantity != 0 else 0
        if update_type == "add":
            material_request_item.is_fulfilled += Decimal(fulfilled_percentage)
        elif update_type == "revert":
            material_request_item.is_fulfilled -= Decimal(fulfilled_percentage)
        material_request_item.save()


def calculate_amount_from_percentage(percentage, total_amount):
    result = Decimal(percentage / 100) * Decimal(total_amount)
    return result.quantize(Decimal('0.00'), rounding=ROUND_HALF_UP)


def calculate_discount_and_gst_for_item(item_data, vendor_state, site):
    use_igst = True
    if vendor_state.pk == site.state.pk:
        use_igst = False

    item = item_data.get('item')
    quantity = item_data.get('quantity', 0)
    unit_rate = item_data.get('unit_rate', 0)
    item_amount = quantity * unit_rate
    discount_percentage = item_data.get('discount_percentage', 0)
    discount_amount = item_data.get('discount_amount', 0)

    if discount_percentage > 0:
        discount = (discount_percentage / 100) * item_amount
    else:
        discount = discount_amount

    taxable_amount = item_amount - discount

    if use_igst:
        igst_percentage = item.hsn_code.igst_percentage
        igst_amount = calculate_amount_from_percentage(taxable_amount, igst_percentage)

        item_data['sgst_percentage'] = 0
        item_data['sgst_amount'] = 0
        item_data['cgst_percentage'] = 0
        item_data['cgst_amount'] = 0

        item_data['igst_percentage'] = igst_percentage
        item_data['igst_amount'] = igst_amount

        after_gst_amount = Decimal(taxable_amount) + igst_amount
    else:
        sgst_percentage = item.hsn_code.sgst_percentage
        sgst_amount = calculate_amount_from_percentage(taxable_amount, sgst_percentage)
        cgst_percentage = item.hsn_code.cgst_percentage
        cgst_amount = calculate_amount_from_percentage(taxable_amount, cgst_percentage)

        item_data['sgst_percentage'] = sgst_percentage
        item_data['sgst_amount'] = sgst_amount
        item_data['cgst_percentage'] = cgst_percentage
        item_data['cgst_amount'] = cgst_amount

        item_data['igst_percentage'] = 0
        item_data['igst_amount'] = 0

        total_gst = sgst_amount + cgst_amount
        after_gst_amount = Decimal(taxable_amount) + total_gst

    item_data['item_amount'] = item_amount
    item_data['taxable_amount'] = taxable_amount
    item_data['after_gst_amount'] = after_gst_amount
    return item_data


# def update_store_inventory_for_grn(grn_id):
#     try:
#         grn = GRN.objects.get(pk=grn_id)
#         grn_items = GRNItems.objects.filter(grn=grn)
#         for grn_item in grn_items:
#             update_inventory(grn_item.organization, grn_item.item, grn.store, 0,  float(grn_item.quantity), grn_item.amount,
#                              'GRN', grn_id)
#         print(f"Inventory updated successfully for GRN {grn_id}")
#     except GRN.DoesNotExist:
#         print(f"GRN with ID {grn_id} does not exist")

#     except Exception as e:
#         print(f"An error occurred: {str(e)}")


# def update_jv_inventory(jv_item, jv_type, update_type):
#     if not jv_item:
#         return
#     site = 0
#     store = 0
#     if jv_item.site:
#         site = jv_item.site
#     else:
#         # store = jv_item.store
#         return False
#     if update_type == "add":
#         quantity = (0 - float(jv_item.quantity)) if jv_type == "issue" else jv_item.quantity
#         update_inventory(jv_item.organization, jv_item.item, store, site,
#                          quantity, jv_item.rate,
#                          f'JV {jv_type}', jv_item.id)
#     elif update_type == "revert":
#         revert_quantity = (0 - float(jv_item.quantity)) if jv_type == "receive" else jv_item.quantity
#         update_inventory(jv_item.organization, jv_item.item, store, site,
#                          revert_quantity, jv_item.rate,
#                          f'JV {jv_type} revert', jv_item.id)


# def update_material_wastage_inventory(material_wastage, wastage_item, update_type):
#     if not material_wastage.is_stock_effect_required or wastage_item.type != "wastage":
#         return
#     site = 0
#     store = 0
#     if material_wastage.site:
#         site = material_wastage.site
#     else:
#         return False

#     if update_type == 'add':
#         update_inventory(material_wastage.organization, wastage_item.item, store, site,
#                          (0 - float(wastage_item.quantity)), wastage_item.rate, 'Material Wastage',
#                          material_wastage.id)
#     elif update_type == 'revert':
#         update_inventory(material_wastage.organization, wastage_item.item, store, site,
#                          float(wastage_item.quantity), wastage_item.rate, 'Material Wastage (revert)',
#                          material_wastage.id)


def get_plant_machinery_data(_id: int):
    _data = PlantMachineryData.cmobjects.filter(
        form__form_type='plant_and_machinery',
        plantmachinery_id=_id
    ).select_related('form').values('form__form_internal_name', 'value')
    if _data:
        _data_dict = {item['form__form_internal_name']: item['value'] for item in _data}
        return _data_dict
    else:
        return {}

def get_project_data(_id: int):
    # _data = ProjectData.cmobjects.filter(
    #     form__form_type='project_details',
    #     project_id=_id
    # ).select_related('form').annotate(resp_value=Case(
    #                     When(form__form_input_type='file', then=F('document')),
    #                     default=F('value'),
    #                     output_field=CharField()
    #                 )).values('form__form_internal_name', 'resp_value')
    # if _data:
    #     _data_dict = {item['form__form_internal_name']: item['resp_value'] for item in _data}
    #     return _data_dict
    # else:
    #     return {}
    return ProjectMaster.cmobjects.filter(pk=_id).values()

def get_project_data2(_id: int, form__form_internal_name=''):
    if form__form_internal_name:
        _data = ProjectData.cmobjects.filter(
            form__form_internal_name=form__form_internal_name,
            project_id=_id
        ).select_related('form').values('form__form_internal_name', 'value')
    else:
        _data = ProjectData.cmobjects.filter(
            project_id=_id
        ).select_related('form').values('form__form_internal_name', 'value')

    if _data:
        _data_dict = {item['form__form_internal_name']: item['value'] for item in _data}
        return _data_dict
    else:
        return {}

def get_tender_data_from_project(_id: int):
    _project = ProjectMaster.cmobjects.filter(pk=_id).first()
    try:
        if _project and _project.tender:
            _tender = TenderMaster.cmobjects.filter(pk=_project.tender.id).first()
            _data = TenderData.cmobjects.filter(
                (
                        Q(form__form_internal_name__icontains='company',) |
                        Q(form__form_internal_name__icontains='party',) |
                        Q(form__form_internal_name__icontains='address', ) |
                        Q(form__form_internal_name__icontains='jv',) |
                        Q(form__form_internal_name__icontains='contact', ) |
                        Q(form__form_internal_name__icontains='mode', )
                ),
                tender=_tender
            ).select_related('form').values('form__form_internal_name', 'value')
            _data_dict = {item['form__form_internal_name']: item['value'] for item in _data}
            # print('_data_dict', _data_dict)
            return _data_dict
        else:
            return {}
    except Exception as e:
        print('ERROR', e)
    return {}

def get_tender_data_from_project2(_id: int, form__form_internal_name=''):
    _project = ProjectMaster.cmobjects.filter(pk=_id).first()
    try:
        if _project and _project.tender:
            _tender = TenderMaster.cmobjects.filter(pk=_project.tender.id).first()
            if form__form_internal_name:
                _data = TenderData.cmobjects.filter(
                    form__form_internal_name=form__form_internal_name,
                    tender=_tender
                ).select_related('form').values('form__form_internal_name', 'value')
            else:
                _data = TenderData.cmobjects.filter(
                    tender=_tender
                ).select_related('form').values('form__form_internal_name', 'value')
            _data_dict = {item['form__form_internal_name']: item['value'] for item in _data}
            # print('_data_dict', _data_dict)
            return _data_dict
        else:
            return {}
    except Exception as e:
        print('ERROR', e)
    return {}


def get_company_data(project_id: int):
    company_data = None
    tender_data = get_tender_data_from_project(project_id)
    if 'participations_mode' in tender_data:
        fdc = FormDropdownChoices.cmobjects.filter(pk=tender_data['participations_mode']).first()
        fn = 'party_name_standalone'
        if (fdc.option == 'JV'):
            fn = 'select_own_company'
        if fn in tender_data:
            fdc2 = FormDependentChoices.cmobjects.filter(pk=tender_data[fn]).first()
            if fdc2.option_id:
                company_data = Company.cmobjects.filter(pk=fdc2.option_id).values()

    return company_data


def update_item_notes_generic(model_name, item_notes, updated_by, master):
    try:
        _ = eval(f"{model_name}.cmobjects.filter(master=master)")
        _.update(is_deleted=True)
        for item_note in item_notes:
            id = item_note.pop('id', None)
            if not id:
                eval(f"{model_name}.cmobjects.create(master=master,updated_by=updated_by,**item_note)")
            else:
                print(f"{model_name}.objects.filter(pk=id).update(master=master,updated_by=updated_by,is_deleted=False, **item_note)")
                eval(f"{model_name}.objects.filter(pk=id).update(master=master,updated_by=updated_by,is_deleted=False, **item_note)")
    except Exception as e:
        print("ERROR", e)
    return True


def update_item_notes_generic2(model_name, item_notes, updated_by, master):
    try:
        # Get the model class dynamically
        model_class = globals()[model_name]
        objects = model_class.cmobjects.filter(master=master)
        objects.update(is_deleted=True)
        for item_note in item_notes:
            item_id = item_note.pop('id', None)
            if not item_id:
                model_class.cmobjects.create(master=master, updated_by=updated_by, **item_note)
            else:
                obj = model_class.objects.get(pk=item_id)
                obj.master = master
                obj.updated_by = updated_by
                obj.is_deleted = False
                for key, value in item_note.items():
                    setattr(obj, key, value)
                obj.save()
    except Exception as e:
        print("ERROR:", e)
        return False
    return True


def check_item_group_restriction(request, type=''):
    type.replace("-", "_")
    modules = {
        'grn': "GRN",
    }
    requested_item_field = {
        'grn': 'item',
    }
    id = request.query_params.get('id', None)
    if type in modules:
        if id:
            details = eval(f"{modules[type]}.cmobjects.filter(pk=id,).first()")
            if details:
                site = getattr(details, 'site', None)
                organization = getattr(details, 'organization', None)
                items = []
                #use else if for othre types
                if type == "grn":
                    items = details.procurement_grn_item.all()
                for item in items:
                    if item:
                        material = getattr(item, requested_item_field[type], None)
                        material_type = getattr(material, 'material_type', None)
                        if material_type:
                            is_restricted = RestrictItemGroup.cmobjects.filter(organization=organization, site=site,
                                                                               item_group=material_type,
                                                                               page_name=type).first()
                            if is_restricted:
                                raise APIException({'request_status': 0, 'msg': f'Requested item is currently locked for the site'})

        else:
            request_datas = []
            if isinstance(request.data, list):
                request_datas = request.data
            else:
                request_datas = [request.data]
            for request_data in request_datas:
                organization = request_data.get('organization', None)
                if not organization:
                    organization_id = request.query_params.get('organization_id', None)
                    try:
                        organization = Organization.objects.get(pk=organization_id)
                    except Organization.DoesNotExist:
                        pass
                site = request_data.get('site', None)

                #check for items string in reqest and get items data
                items_key = next((key for key in request_data.keys() if 'items' in key), None)
                items = request_data[items_key] if items_key else []
                if type == "po":
                    items = request_data.get('items', [])
                for item in items:
                    item_id = item.get('item', None)
                    if item_id:
                        material_details = VendorMaterialMaster.cmobjects.filter(pk=item_id).first()
                        if material_details:
                            try:
                                material_type = material_details.material_type
                            except:
                                material_type = None
                            if material_type:
                                is_restricted = RestrictItemGroup.cmobjects.filter(organization=organization, site__id=site,
                                                                                item_group__id=material_type.id,
                                                                                page_name=type).first()
                                if is_restricted:
                                    raise APIException({'request_status': 0, 'msg': f'Requested item is currently locked for the site'})


def check_site_stock_level(request, type=''):
    modules = {
        'mr': 'MaterialRequestMaster',
        'indent': 'Indent',
        'po': 'PurchaseOrder',
        'grn': 'GRN',
        'issue': 'MaterialIssue'
    }
    requested_item_field = {
        'mr': 'requested_material',
        'indent': 'requested_material',
        'po': 'item',
        'grn': 'item',
        'issue': 'requested_material'
    }

    id = request.query_params.get('id', None)
    if type in modules:
        if id:
            details = eval(f"{modules[type]}.cmobjects.filter(pk=id).first()")
            if details:
                organization = getattr(details, 'organization', None)
                site = getattr(details, 'site', None)
                item_queryset_managers = {
                    'mr': 'procurement_material_item_request',
                    'indent': 'procurement_indent_item_indent',
                    'po': 'procurement_purchase_order_item',
                    'grn': 'procurement_grn_item',
                    'issue': 'procurement_material_issue_item'
                }
                items = getattr(details, item_queryset_managers.get(type, 'procurement_default_item_manager')).all()
                request_items_key = next((key for key in request.data.keys() if 'items' in key), None)
                request_items = request.data[request_items_key] if request_items_key else []
                if type == "po":
                    request_items = request.data.get('items', [])
                request_item_qty_data = {}
                for request_item in request_items:
                    request_item_id = request_item.get('id', None)
                    if request_item_id:
                        qty_key = [key for key in request_item.keys() if 'quantity' in key]
                        quantity = 0
                        if qty_key:
                            quantity = request_item[qty_key[0]]
                        request_item_qty_data[request_item_id] = quantity
                for item in items:
                    if item:
                        material = getattr(item, requested_item_field[type], None)
                        material_type = getattr(material, 'material_type', None)
                        quantity = request_item_qty_data.get(item.id, 0)
                        if material:
                            inventory = Inventory.cmobjects.filter(site=site, material=material,
                                                                   organization=organization).first()
                            if material_type and inventory:
                                financial_year = inventory.financialyear
                                site_wise_level = SiteWiseStockLevelSetting.cmobjects.filter(site=site, inventory=inventory,
                                                                                             material=material, item_type=material_type,
                                                                                             financial_year=financial_year,
                                                                                             organization=organization).first()
                                if site_wise_level:
                                    min_qty = site_wise_level.min_quantity
                                    max_qty = site_wise_level.max_quantity
                                    inventory_qty = inventory.quantity
                                    if inventory_qty > min_qty:
                                        raise APIException(f"Site ({site}) - material ({material}) Inventory has more than the minimum quantity")
                                    if quantity > max_qty:
                                        raise APIException(f"Requested Quantity for Site ({site}) - material ({material}) is more than the maximum quantity capacity")
        else:
            request_datas = []
            if isinstance(request.data, list):
                request_datas = request.data
            else:
                request_datas = [request.data]
            for request_data in request_datas:
                organization = request_data.get('organization', None)
                if not organization:
                    organization_id = request.query_params.get('organization_id', None)
                    try:
                        organization = Organization.objects.get(pk=organization_id)
                    except Organization.DoesNotExist:
                        pass
                site = request_data.get('site', None)
                #check for items string in reqest and get items data
                items_key = next((key for key in request_data.keys() if 'items' in key), None)
                items = request_data[items_key] if items_key else []
                if type == "po":
                    items = request_data.get('items', [])
                for item in items:

                    qty_key = [key for key in item.keys() if 'quantity' in key]
                    quantity = 0
                    if qty_key:
                        quantity = item[qty_key[0]]
                    material_id = item.get('requested_material', None)
                    if not material_id:
                        material_id = item.get('item', None)
                    material_details = VendorMaterialMaster.cmobjects.filter(pk=material_id).first()
                    if not material_details:
                        item.get('item', None)
                    if material_details:
                        material_type = getattr(material_details, 'material_type', None)
                        inventory = Inventory.cmobjects.filter(site=site, material=material_details,
                                                            organization=organization).first()
                        if material_type and inventory:
                            financial_year = inventory.financialyear
                            site_wise_level = SiteWiseStockLevelSetting.cmobjects.filter(site=site, inventory=inventory,
                                                                                        material=material_details, item_type=material_type,
                                                                                        financial_year=financial_year,
                                                                                        organization=organization).first()
                            print('-'*30)
                            print('site >>> ', site)
                            print('inventory >>> ', inventory.id)
                            print('material >>> ', material_id)
                            print('item_type >>> ', material_type.id)
                            print('financial_year >>> ', financial_year)
                            print('organization >>> ', organization)
                            print('site_wise_level >>> ', site_wise_level)

                            if site_wise_level:
                                min_qty = site_wise_level.min_quantity
                                max_qty = site_wise_level.max_quantity
                                inventory_qty = inventory.quantity
                                quantity = int(quantity)
                                print('min_qty >>> ', min_qty)
                                print('max_qty >>> ', max_qty)
                                print('inventory_qty >>> ', inventory_qty)
                                print('quantity >>> ', quantity)
                                if inventory_qty > min_qty:
                                    raise APIException(f"Site ({site}) - material ({material_details}) Inventory has more then minimum quantity")
                                if quantity > max_qty:
                                    raise APIException(f" Requested Quantity for Site ({site}) - material ({material_details}) is more than maximum quantity capacity")


def calculate_item_amounts_for_purchase(item_data):
    quantity = item_data.get('quantity', 0)
    unit_rate = item_data.get('rate', 0)
    discount_percentage = item_data.get('discount_percentage', 0)
    discount_amount = item_data.get('discount_amount', 0)
    excise_percentage = item_data.get('excise_percentage', 0)
    excise_amount = item_data.get('excise_amount', 0)
    vat_tax_percentage = item_data.get('vat_tax_percentage', 0)
    vat_tax_amount = item_data.get('vat_tax_amount', 0)
    additional_vat_tax_percentage = item_data.get('vat_tax_amount', 0)
    additional_vat_tax_amount = item_data.get('additional_vat_tax_amount', 0)
    item_amount = quantity * unit_rate

    #discount
    if discount_percentage > 0:
        discount = (discount_percentage / 100) * item_amount
    else:
        discount = discount_amount
    after_discount_amt = item_amount - discount

    #excise
    if excise_percentage > 0:
        excise = (excise_percentage / 100) * after_discount_amt
    else:
        excise = excise_amount
    after_excise_amt = after_discount_amt + excise

    #vat tax
    if vat_tax_percentage > 0:
        vat_tax = (vat_tax_percentage / 100) * after_excise_amt
    else:
        vat_tax = vat_tax_amount
    after_vat_tax_amt = after_excise_amt + vat_tax

    #additional vat tax
    if additional_vat_tax_percentage > 0:
        additional_vat_tax = (additional_vat_tax_percentage / 100) * after_vat_tax_amt
    else:
        additional_vat_tax = additional_vat_tax_amount
    after_additional_vat_tax_amt = after_vat_tax_amt + additional_vat_tax

    item_data['item_amount'] = item_amount
    item_data['total_amount'] = after_additional_vat_tax_amt
    return item_data


def calculate_item_amounts_for_raw_material_sales(item_data):
    print("*"*100)
    print(item_data)
    quantity = item_data.get('quantity', 0)
    unit_rate = item_data.get('rate', 0)
    discount_percentage = item_data.get('discount_percentage', 0)
    discount_amount = item_data.get('discount_amount', 0)
    excise_percentage = item_data.get('excise_percentage', 0)
    excise_amount = item_data.get('excise_amount', 0)
    tax_percentage = item_data.get('tax_percentage', 0)
    tax_amount = item_data.get('tax_amount', 0)
    item_amount = quantity * unit_rate

    #discount
    if discount_percentage > 0:
        discount = (discount_percentage / 100) * item_amount
    else:
        discount = discount_amount
    after_discount_amt = item_amount - discount

    #excise
    if excise_percentage > 0:
        excise = (excise_percentage / 100) * after_discount_amt
    else:
        excise = excise_amount
    after_excise_amt = after_discount_amt + excise

    #tax
    if tax_percentage > 0:
        vat_tax = (tax_percentage / 100) * after_excise_amt
    else:
        vat_tax = tax_amount
    after_vat_tax_amt = after_excise_amt + vat_tax

    item_data['amount'] = item_amount
    item_data['total_amount'] = after_vat_tax_amt

    return item_data
    pass


def edit_child_model(instance,validated_data,child_model,child_related_name,parent_field):
    list_datas = validated_data.get(child_related_name, [])
    existing_datas = eval(f'instance.{child_related_name}.all()')
    current_user = instance.updated_by if instance.updated_by else (instance.created_by if instance.created_by else None)
    for list_data in list_datas:
        ref_id = list_data.get('id')
        existing_data = next((ref for ref in existing_datas if ref.id == ref_id), None)
        if not existing_data:
            list_data[parent_field] = instance
            list_data['created_by'] = current_user
            eval(f'{child_model}.objects.create(**list_data)')
        else:
            for field in existing_data._meta.fields:
                field_name = field.name
                if field_name in list_data:
                    setattr(existing_data, field_name, list_data[field_name])
            existing_data.save()
    for existing_data in existing_datas:
        if existing_data.id not in [data.get('id') for data in list_datas]:
            setattr(existing_data, 'is_deleted', True)
            setattr(existing_data, 'updated_by', current_user)
            existing_data.save()


def parent_fields(instance,items_table):
    fields = [
        ['material_request_item','material_request','date'],
        ['indent_item','indent','date'],
        ['rfq_vendor_item','rfq_vendors','date'],
        ['quotation_item','quotation','date'],
        ['purchase_order_item','purchase_order','date'],
        ['grn_item','grn','date'],
        ['purchase_item','purchase','date'],
        ['plant_machinery_rfq_vendor_item','plant_machinery_rfq_vendor','date'],
        ['plant_machinery_quotation_item','plant_machinery_quotation','date'],
    ]
    resp = {}
    resp_list = {}
    items = eval(f'instance.{items_table}.all()')
    for item in items:
        if not item.is_deleted:
            for field in fields:
                if hasattr(item,field[0]):
                    if not field[1] in resp:
                        resp[field[1]] = []
                    link_value = getattr(item,field[0])
                    if link_value:
                        if hasattr(getattr(item,field[0]),field[1]):
                            parent_value = getattr(getattr(item,field[0]),field[1])
                            if parent_value:
                                if hasattr(getattr(getattr(item,field[0]),field[1]),'request_code'):
                                    request_code = getattr(getattr(getattr(item,field[0]),field[1]),'request_code')
                                    if request_code:
                                        date = ''
                                        if hasattr(getattr(getattr(item,field[0]),field[1]),field[2]):
                                            date_temp = getattr(getattr(getattr(item,field[0]),field[1]),field[2])
                                            if date_temp:
                                                date = ' ('+date_temp.strftime('%d/%m/%Y')+')'
                                        resp[field[1]].append(request_code+date)
    for key,value in resp.items():
        resp_list[key] = ', '.join(list(set(value)))
    return resp_list


def calculate_quantity_on_uom(material_id,material_uom_id,uom_id,quantity):
    final_quantity = float(quantity)
    if material_id and material_uom_id and uom_id:
            if material_uom_id != uom_id:
                details = SecondUnitOfMesurement.cmobjects.filter(material_id=material_id,second_uom=uom_id).first()
                if details:
                    final_quantity = float(float(details.primary_rate)/float(float(details.conversion_rate)))*float(quantity)
    return final_quantity

def sync_user_project_hrms(instance):
    current_date = datetime.now()
    future_date = current_date + timedelta(days=365 * 10)
    try:
        if bool(int(str(os.getenv('HRMS_SYNC','0')))):
            for user in instance.users.all():
                post_data = {
                    "project_list": [
                        {
                            "start_date": current_date.strftime('%Y-%m-%dT%H:%M:%S.0000Z'),
                            "expire_date": future_date.strftime('%Y-%m-%dT%H:%M:%S.0000Z'),
                            "project": instance.hrms_project_id if instance else -1
                        }
                    ],
                    "user": user.hrms_user_id if user.hrms_user_id else 0
                }
                print(post_data)
                user_project_map = hrms_request('post', os.getenv('HRMS_USER_PROJECT_MAP',''), post_data)
                print(user_project_map)
    except Exception as e:
        print('Error', e)


def update_query_for_user_search(_filter, _query, variable='created_by'):
    query = Q()
    query |= Q(**{f'{variable}__username__icontains': _filter})
    query |= Q(**{f'{variable}__first_name__icontains': _filter})
    query |= Q(**{f'{variable}__last_name__icontains': _filter})
    if len(_filter.split(' ')) > 1:
        query |= Q(**{f'{variable}__first_name__icontains': _filter.split(' ')[0].strip(), f'{variable}__last_name__icontains': _filter.split(' ')[1].strip()})

        # queryset = _query.annotate(search_name=Concat('created_by__first_name', Value(' '), 'created_by__last_name'))
        # then you can filter:
        # _query |= queryset.filter(search_name__icontains=_filter)

    _list = _query.filter(query)
    return _list

# def get_details_from_instance(instance,extras=[],type="list"):
#     res = [] if type == 'list' else None
#     try:
#         flag = True
#         result = {field.name:field.value_from_object(instance) for field in instance._meta.fields}
#         # result = model_to_dict(instance)
#         if 'is_deleted' in result and result['is_deleted']:
#             flag = False
#         if flag:
#             for extra in extras:
#                 result[extra+'_details'] = get_details_from_instance(getattr(instance,extra))
            
#             if type == 'list':
#                 res.append(result)
#             else:
#                 res = result
#     except Exception as e:
#         print(e)
#     return res 

def get_details_from_instance(instance,extras=[],type="list"):
    res = [] if type == 'list' else None
    try:
        if instance:
            if instance.__class__.__name__ == 'ManyRelatedManager':
                temp_instances = instance.all()
                for temp_instance in temp_instances:
                    res.append(get_details_from_instance(temp_instance,[],'dict'))
            else:
                flag = True
                # result = {field.name:field.value_from_object(instance) if field.value_from_object(instance)
                #            is not None else None for field in instance._meta.fields}
                # result = model_to_dict(instance)
                result = {}
                for field in instance._meta.fields:
                    try:
                        field_value = field.value_from_object(instance)
                        if (isinstance(field, models.FileField) or isinstance(field, models.ImageField)):
                            result[field.name] = field_value.url if field_value else None
                        elif isinstance(field, models.ForeignKey):
                            result[field.name] = field_value
                            result[field.name + "_id"] = field_value
                        else:
                            result[field.name] = field_value
                    except ValueError:
                        result[field.name] = None
                if 'is_deleted' in result and result['is_deleted']:
                    flag = False
                if flag:
                    for extra in extras:
                        result[extra+'_details'] = get_details_from_instance(getattr(instance,extra))
                    if type == 'list':
                        res.append(result)
                    else:
                        res = result
        else:
            res = None
    except Exception as e:
        print(e)
    return res


def get_vendor_data(vendor_id):
    details = vendor_id
    if isinstance(vendor_id, int):
        details = VendorMasterV2.cmobjects.filter(pk=vendor_id).first()
    return get_details_from_instance(details,extras=[],type="dict")


# def filter_by_date(queryset, date_field, date_str):
   
#     try:
#         parsed_date = datetime.strptime(date_str, '%Y-%m-%d').date()
#         start_of_day = datetime.combine(parsed_date, time.min)
#         end_of_day = datetime.combine(parsed_date, time.max)
#         return queryset.filter(**{f'{date_field}__range': (start_of_day, end_of_day)})
#     except ValueError:
#         raise ValueError('Invalid date format. Use YYYY-MM-DD.')

def convert_to_boolean(value):
    if isinstance(value, str):
        value = value.strip().lower()
        if value in ['true', 'yes', '1']:
            return True
        elif value in ['false', 'no', '0']:
            return False
    elif isinstance(value, (int, float)):
        return bool(value)
    return False


def text2tree(indented_text: str):
    tree = {}
    last_parent = {0: tree}
    for line in indented_text.splitlines():
        child_name = line.lstrip(' ')
        child_level = len(line) - len(child_name)
        last_parent[child_level][child_name] = {}
        last_parent[child_level + 4] = last_parent[child_level][child_name]
    return tree


def get_sap_plant_auth(type,pk__in=None,project_id__in=None):
    search ={'sap_plant_id__isnull':False,'sap_auth_key__isnull':False}
    if pk__in:
        search['pk__in'] = pk__in
    if project_id__in:
        search['site__project__in'] = project_id__in
    details = StoreMaster.cmobjects.annotate(
        sap_auth_key=F(f'sap_auth_key_{type}')
    ).filter(
        **search
    ).exclude(
        sap_plant_id=''
    ).exclude(
        sap_auth_key=''
    ).values('id','sap_plant_id','sap_auth_key','sap_start_codes','site_id','site__project_id')
    formatted_details = {detail['sap_plant_id']:detail for detail in details}
    print(formatted_details)
    return formatted_details


def sap_request(type='get',url='',data=None,data_type='json'):
    sap_resp = None
    error_msg = []
    if bool(int(str(os.getenv('SAP_SYNC','0')))):
        try:
            urllib3.disable_warnings()
            headers = {
                'Accept': 'application/json',
            }
            print('-'*100)
            print('url --> ',url)
            print('data --> ',data)
            print('headers --> ',headers)
            response = eval(f'requests.{type}(url=url, {data_type}=data, headers=headers, auth=HTTPBasicAuth(os.getenv("SAP_USERNAME", ""), os.getenv("SAP_PASSWORD", "")), verify=False)')
            print('RESPONSE: ',response)
            print('RESPONSE RAW: ',response.content)
            ExternalRequests.objects.create(
                type=type,
                url=url,
                data=data,
                status_code=response.status_code,
                elapsed=response.elapsed,
                response_details = str(response.content) if not str(response.status_code).startswith('2') else '',
            )
            try:
                sap_resp = json.loads(response.content)
                print('SAP RESPONSE: ',sap_resp)
                print('SAP RESPONSE MESSAGE: ',sap_resp['Message'] if 'Message' in sap_resp else '')
            except Exception as e:
                error_msg.append(str(e))
        except Exception as e:
            error_msg.append(str(e))
    else:
        sap_resp = {'Result':{'PONumber':'NA'}}
    return sap_resp,error_msg

def generate_sap_po(instance):
    sap_code = ""
    sap_resp = None
    try:
        current_date = datetime.now()
        filename = ''
        attachment_data = ''
        attachment_list = []
        base_values_list = [
            {'DocumentType': 'ZCAP','AssignmentCategory': 'A','ValuationType': 'ASSET-DOM',},
            {'DocumentType': 'ZPRJ','AssignmentCategory': 'Q','ValuationType': 'PRJ-DOM',},
        ]
        base_values = {}
        if instance['is_asset_for_sap']:
            base_values = base_values_list[0]
        else:
            base_values = base_values_list[1]
        for attachment in instance['procurement_purchase_order_attachment']:
            attachment_data = attachment.get('file_data', '')
            mime_type = attachment.get('mime_type', None)
            mime_type_obj = MimeTypes.objects.filter(mime_type=mime_type).first()
            if not mime_type_obj:
                file_extension = mimetypes.guess_extension(mime_type)
            else:
                file_extension=mime_type_obj.file_extension
            file_extension = file_extension if file_extension else '.bin'
            filename = f"{attachment.get('attachment_name', '')}{file_extension}"
            attachment_list.append({
                'AttachmentBase64': attachment_data,
                'FileName': filename,
            })
        data = {
            'Record': {
                'AuthorizationKey': os.getenv('SAP_PO_AUTH_KEY', ''),

                # 'FileName': filename,
                # 'AttachmentBase64': attachment_data,
                'Attachment': attachment_list,

                'Header': {
                    'HeaderTexts': [],
                    'CompanyCode': instance['company_code_for_sap'].sap_code if instance['company_code_for_sap'] else '',
                    'CreateDate': current_date.strftime('%d.%m.%Y'),
                    'CreatedBy': instance['created_by'].first_name if instance['created_by'] else '',
                    'Currency': instance['vendor_currency'].slug if instance['vendor_currency'] else '',
                    'DocumentDate': instance['date'].strftime('%d.%m.%Y') if instance['date'] else '',
                    'DocumentType': base_values['DocumentType'],
                    'ExchangeRate': instance['exchange_rate'],
                    'IncoTermOne': instance['inco_term_one_for_sap'].code if instance['inco_term_one_for_sap'] else '',
                    'IncoTermTwo': instance['inco_term_two_for_sap'],
                    'Language': 'EN',
                    'OurReference': instance['our_reference_for_sap'],
                    'PayTerm': instance['pay_term_for_sap'].code if instance['pay_term_for_sap'] else '',
                    'PurchaseGroup': instance['purchase_group_for_sap'].code if instance['purchase_group_for_sap'] else '',
                    'PurchaseOrg': instance['purchase_org_for_sap'].code if instance['purchase_org_for_sap'] else '',
                    'Refrence': instance['refrence_for_sap'],
                    'SalesPerson': instance['sales_person_for_sap'],
                    'SalesTaxCountry': instance['sales_tax_country_for_sap'].iso2 if instance['sales_tax_country_for_sap'] else '',
                    'Telephone': instance['telephone_for_sap'],
                    'ValidityPeriodEnd': instance['valid_date_to'].strftime('%d.%m.%Y') if instance['valid_date_to'] else '',
                    'ValidityPeriodStart': instance['valid_date_from'].strftime('%d.%m.%Y') if instance['valid_date_from'] else '',
                    'Vendor': instance['vendor'].vendor_code if instance['vendor'] else '',

                    'Retention': instance['retention'],
                    'DPCategory': instance['dp_category'],
                    'DPAmount': instance['dp_amount'],
                    'DPPercent': instance['dp_percent'],
                    'DPDueDate': instance['dp_due_date'].strftime('%d.%m.%Y') if instance['dp_due_date'] else '',

                    'QuotationNo': instance['quotation'].request_code if instance['quotation'] else instance['quotation_text'],
                    'QuotationDate': instance['quotation'].date.strftime('%d.%m.%Y') if instance['quotation'] else (instance['quotation_date'].strftime('%d.%m.%Y') if instance['quotation_date'] else ''),
                },
                'Account': [],
                'Item': [],
                'Schedule': []
            }
        }
        freight_amount = 0
        total_quantity = 0
        for item in instance['procurement_po_expense']:
            if 'freight' in (item['expense_head'].name).lower():
                freight_amount += float(item['total_expense_amount'])
        for item in instance['procurement_purchase_order_item']:
            total_quantity += float(item['quantity'])
        freight_value = float(freight_amount)/float(total_quantity)
        for item in instance['procurement_terms_and_conditions']:
            if item['master'] and item['is_checked']:
                data['Record']['Header']['HeaderTexts'].append({
                    'TextID': item['master'].work_category,
                    'Text': item['description'],
                })
        for item in instance['procurement_purchase_order_item']:
            condition_list = []
            item_text_list = []
            for note in item['notes']:
                if note['master'] and note['is_checked']:
                    item_text_list.append({
                        'TextId': note['master'].work_category,
                        'Text': note['note_details'],
                    })
            # for expense in item['expenses']:
            #     condition_list.append({
            #         'ConditionType': expense['expense_head'].short_name,
            #         'ConditionValue': expense['total_expense_amount'],
            #     })
            condition_list.append({
                'ConditionType': 'FRC1',
                'ConditionValue': freight_value,
            })
            requested_material_id = item['item'].id if item['item'] else None
            site_id = instance['site'].id if instance['site'] else None
            store_id = instance['store'].id if instance['store'] else None
            project_id = instance['project'].id if instance['project'] else None

            pr_instance = SAPPR.cmobjects.filter(requested_material_id=requested_material_id, site_id=site_id, store_id=store_id, project_id=project_id, is_active=True).first()
            account_temp = {
                'POItem': item['sap_item_no'],
                'AssetNo': item['asset_no_for_sap'],
                'WBSElement': item['wbs_temp_planning_for_sap'].wbs_code if item['wbs_temp_planning_for_sap'] else '',

                'BusinessArea': item['business_area'],
                'CostCenter': item['cost_center'].name if item['cost_center'] else '',
                'GLAccount': item['gl_account'].name if item['gl_account'] else '',
            }
            data['Record']['Account'].append(account_temp)
            data['Record']['Item'].append({
                'AssignmentCategory': base_values['AssignmentCategory'],
                'ExpiryDateInd': item['expiry_date_ind_for_sap'],
                'GoodsReceiptDate': item['goods_receipt_date_for_sap'].strftime('%d.%m.%Y') if item['goods_receipt_date_for_sap'] else '',
                'Material': item['item'].sap_code if item['item'] else '',
                'NetPrice': item['rate'],
                'Plant': instance['store'].sap_plant_id if instance['store'] else '',
                'POItem': item['sap_item_no'],
                'PRNo': pr_instance.pr_no if pr_instance else '',
                'PRItem': pr_instance.pr_item if pr_instance else '',
                'Quantity': item['quantity'],
                'RoundingInd': 'X',
                'StorageLocation': item['storage_location_for_sap'].section_name if item['storage_location_for_sap'] else '',
                'TaxCode': item['tax_head'].short_name if item['tax_head'] else '',
                'ValuationType': base_values['ValuationType'],

                # 'ConditionType': 'FRC1',
                # 'ConditionValue': freight_value,
                'FreightSupplier': instance['vendor'].vendor_code if instance['vendor'] else '',
                'Condition': [condition_list],

                'ItemText': item_text_list,
            })
            data['Record']['Schedule'].append({
                'DeliveryDate': item['delivery_date'].strftime('%d.%m.%Y') if item['delivery_date'] else '',
                'POItem': item['sap_item_no'],
                'Quantity': item['quantity']
            })
        print("data json :",data)
        sap_resp,error_msg = sap_request(type='post',url=os.getenv('SAP_PO', ''),data=data,data_type='json')
        if sap_resp:
            if 'Result' in sap_resp:
                sap_code = sap_resp['Result']['PONumber']
            else:
                err_resp = []
                if 'Message' in sap_resp:
                    for msg_temp in [sap_resp['Message']] if not isinstance(sap_resp['Message'], list) else sap_resp['Message']:
                        if msg_temp['Type'] == 'E':
                            err_resp.append(msg_temp['Message'])
                else:
                    err_resp = [sap_resp]
                raise APIException({'request_status': 0, 'msg': ', '.join(err_resp)})
        else:
            raise APIException({'request_status': 0, 'msg': error_msg})
    except Exception as e:
        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
    return sap_code,sap_resp

def generate_sap_vendor(instances):
    """
    Process multiple vendor instances in a single SAP request.
    """
    return False, 'BLOCKED'
    try:
        if not isinstance(instances, list):
            instances = [instances] 
        print(instances)
        data = {
            "Record": [
                {
                    "AUTHORIZATION_KEY": os.getenv("SAP_VENDOR_CREATE_AUTH_KEY", ""),
                    "SUPPLIER_ACCOUNT_GROUP": instance.get("supplier_account_group", ""),
                    "BP_GROUPING": instance.get("bp_grouping", ""),
                    "TITLE": instance.get("title", ""),
                    "NAME": instance.get("name", ""),
                    "NAME_2": instance.get("name_2", ""),
                    "SEARCH_TERM_1": instance.get("search_term_1", ""),## pass alphanumeric like PMS-Vendor_id
                    "STREET_2": instance.get("street_2", ""),
                    "STREET_3": instance.get("street_3", ""),
                    "STREET_4": instance.get("street_4", ""),
                    "STREET_5": instance.get("street_5", ""),
                    "POSTAL_CODE": instance.get("postal_code", ""),
                    "CITY": instance.get("city", ""),
                    "STATE": instance.get("state", ""),
                    "COUNTRY": instance.get("country", ""),
                    "LANGUAGE": instance.get("language", ""),
                    "DEFAULT_TELEPHONE": instance.get("default_telephone", ""),
                    "DEFAULT_MOBILE": instance.get("default_mobile", ""),
                    "DEFAULT_EMAIL": instance.get("default_email", ""),
                    "TAX_NUMBER_CATEGORY": instance.get("tax_number_category", ""),
                    "TAX_DECLARATION_TYPE": instance.get("tax_declaration_type", ""),
                    "TAN_NUMBER": instance.get("tan_number", ""),
                    "PAN": instance.get("pan", ""),
                    "GST_VEN_CLASS": instance.get("gst_ven_class", ""),
                    "MSME_CERT": instance.get("msme_cert", ""),
                    "LAST_EXT_REVIEW": instance.get("last_ext_review", ""),
                    "CHECK_DOUBLE_INVOICE": instance.get("check_double_invoice", ""),
                    "GRBASED_INVOICE_VERIFICATION": instance.get("grbased_invoice_verification", ""),
                    "SRVBASED_INVOICE_VERIFICATION": instance.get("srvbased_invoice_verification", ""),
                    "GROUP_FOR_CALCULATION_SCHEMA": instance.get("group_for_calculation_schema", ""),
                    "COMPANY_CODE": instance.get("company_code", ""),
                    "PURCHASING_ORGANIZATION": instance.get("purchasing_organization", ""),
                    "ORDER_CURRENCY": instance.get("order_currency", ""),
                    "PAYMENT_METHOD_1": instance.get("payment_method_1", ""),
                    "RECONCILIATION_ACCOUNT_IN_GEN_": instance.get("reconciliation_account_in_gen", ""),
                    "INFO_NUMBER": instance.get("info_number", ""),
                    "TAX_NUMBER":instance.get("tax_number", ""),
                    "UPLOADED_BY": instance.get("uploaded_by", ""),
                }
                for instance in instances  
            ]
        }

        sap_resp, error_msg = sap_request(type='post', url=os.getenv('SAP_VENDOR_CREATE', ''), data=data, data_type='json')
        print("SAP Response:", sap_resp)

        if sap_resp:
            if "Message" in sap_resp and "data uploaded successfully to sap" in sap_resp["Message"].lower():
                return True, sap_resp 
            else:
                return False, sap_resp["Message"]  

        return False, error_msg 
    except Exception as e:
        error_message = str(e.args[0]) if e.args else str(e)
        # raise APIException({'request_status': 0, 'msg': error_message})
        return False, error_message

def get_serializer_by_model(model):
    for app_config in apps.get_app_configs():
        try:
            serializers_module = importlib.import_module(f"{app_config.name}.serializers")
            for attr_name in dir(serializers_module):
                serializer = getattr(serializers_module, attr_name)
                if isinstance(serializer, type) and issubclass(serializer, ModelSerializer):
                    if hasattr(serializer, 'Meta') and hasattr(serializer.Meta, 'model'):
                        if serializer.Meta.model == model:
                            return serializer
        except ModuleNotFoundError:
            continue
    return None


def handle_trigger_notifications(type='',details=None,created=False):
    """
    Helper function to handle stage-based notifications dynamically.
    """
    user_list = []
    serializer_details = {}
    if details:
        serializer_class = get_serializer_by_model(details.__class__)
        if serializer_class:
            serializer_details = serializer_class(details).data
    if 'status_details' in serializer_details:
        if serializer_details['status_details']['target_status'] not in ['', 'Checked']:
            for multi_stage_detail in serializer_details['multi_stage_details']:
                if multi_stage_detail['procurement_multi_stage_setting_stages__stage'] == (int(serializer_details['current_stage']) + 1):
                    user_list.append(multi_stage_detail['procurement_multi_stage_setting_stages__employee'])
    if 'status' in serializer_details and not user_list:
        permission_type = "approver"
        if created:
            permission_type = "checker"
        user_list.extend(list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=[f'procurement-{type}-{permission_type}'],
            level_permission=True,
        ).values_list('user_id',flat=True)))
    if created and not user_list:
        print('record created without approval')
    if user_list:
        trigger_notifications(action=type.upper(), user_list=user_list, context=serializer_details)


def belsio_request(type='get',url='',data=None,data_type='json',login=False):
    try:
        urllib3.disable_warnings()
        resp = None
        headers = {
            'Content-type':'application/json', 
            'Accept': '*/*',
        }
        if not login:
            token = BelsioToken.objects.filter(username=str(os.getenv('BELSIO_USERNAME',''))).first()
            if token:
                headers['Authorization'] = 'Bearer '+token.token
        print('-'*100)
        print('url --> ',url)
        print('data --> ',data)
        print('headers --> ',headers)
        response = eval(f'requests.{type}(url=url, {data_type}=data, headers=headers, verify=False)')
        ExternalRequests.objects.create(type=type,url=url,data=data,status_code=response.status_code,elapsed=response.elapsed)
        if response.status_code == 401:
            login_resp = belsio_login_request()
            if login_resp['token']:
                belsio_request(type,url,data,data_type,login)
        try:
            resp = json.loads(response.content) 
        except Exception as e:
            resp = response.content
        return resp
    except Exception as e:
        print('ERROR', e)
    return None


def belsio_login_request(username=None):
    try:
        username = username if username else str(os.getenv('BELSIO_USERNAME',''))
        post_data = {
            "username": str(os.getenv('BELSIO_USERNAME','')),
            "password": str(os.getenv('BELSIO_PASSWORD','')),
            "companyId": str(os.getenv('BELSIO_COMPANY',''))
        }

        response = belsio_request('post',str(os.getenv('BELSIO_LOGIN','')),post_data,'json',True)
        try:
            token = response['token']
            print('token during belsio creation',token)
            BelsioToken.objects.filter(username=username).update(is_deleted=True)
            BelsioToken.objects.create(username=username,token=token)
        except Exception as e:
            print('ERROR', e)
        return response
    except Exception as e:
        print('ERROR', e)
    return None

def handle_belsio_purchase_order(instance=None,created=False):
    if bool(int(str(os.getenv('BELSIO_SYNC','0')))):
        try:
            if created:
                current_date = datetime.today()
                project_data = get_project_data(instance.project_id)
                doc_date = instance.date if instance.date else current_date
                delivery_date = doc_date + timedelta(instance.delivery_days if instance.delivery_days else 0)
                data = {
                    "vendorId": instance.vendor.vendor_code if instance.vendor else "", 
                    "vendorName": instance.vendor.vendor_name if instance.vendor else "",                        
                    "docDate": doc_date.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                    "deliveryDate": delivery_date.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                    "location": "Dubai,Sharjah",
                    "approvalUser": "construction", 
                    "currencyCode": "AED",
                    "exchangeRate": instance.exchange_rate,
                    "paymentTerms": instance.pay_term_for_sap.code if instance.pay_term_for_sap else "",
                    "quotationRef": instance.quotation.request_code if instance.quotation else "" , 
                    "costCenter1": project_data['project_id'] if 'project_id' in project_data else "",  
                    "items": []
                }

                po_item_count = 0
                for item in instance.procurement_purchase_order_item.all():
                    po_item_count += 1
                    data["items"].append({
                        # "srno": 0,
                        "requisitionNo": item.item.material_code if item.item else "",
                        "itemCode": item.item.material_code if item.item else "",
                        "itemDescription": item.item.material_descriptions if item.item else "",
                        "specification":item.specification if item.specification else "",
                        "qty": item.quantity if item.quantity else 0,
                        "uom": item.uom.formal_name if item.uom else "",
                        "unitPrice": item.rate if item.rate else 0,
                        "amount":item.item_amount if item.item_amount else 0,
                        "vatPerc": item.tax_head.name if item.tax_head else "",
                        "deliveryDate": delivery_date.strftime("%Y-%m-%d"),
                    })

                response = belsio_request('post',str(os.getenv('BELSIO_PO_DIRECT','')),data,'json',False)
                print('response',response)
        except Exception as e:
            print('ERROR', e)
    return None     
# def handle_belsio_purchase_order(instance=None, created=False):
#     if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
#         try:
#             current_date = datetime.today()
#             project_data = get_project_data(instance.project_id)
#             doc_date = instance.date if instance.date else current_date
#             delivery_date = doc_date + timedelta(instance.delivery_days if instance.delivery_days else 0) 

#             data = {
#                 "vendorId": instance.vendor.vendor_code if instance.vendor else "", 
#                 "vendorName": instance.vendor.vendor_name if instance.vendor else "",                        
#                 "docDate": doc_date.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
#                 "deliveryDate": delivery_date.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
#                 "location": "Dubai,Sharjah",
#                 "approvalUser": "construction", 
#                 "currencyCode": "AED",
#                 "exchangeRate": instance.exchange_rate,
#                 "paymentTerms": instance.pay_term_for_sap.code if instance.pay_term_for_sap else "",
#                 "quotationRef": instance.quotation.request_code if instance.quotation else "" , 
#                 "costCenter1": project_data['project_id'] if 'project_id' in project_data else "",  
#                 "items": []
#             }
#             po_item_count = 0
#             for item in instance.procurement_purchase_order_item.all():
#                 po_item_count += 1
#                 data["items"].append({
#                     # "srno": 0,
#                     "requisitionNo": item.item.material_code if item.item else "",
#                     "itemCode": item.item.material_code if item.item else "",
#                     "itemDescription": item.item.material_descriptions if item.item else "",
#                     "specification":item.specification if item.specification else "",
#                     "qty": item.quantity if item.quantity else 0,
#                     "uom": item.uom.formal_name if item.uom else "",
#                     "unitPrice": item.rate if item.rate else 0,
#                     "amount":item.item_amount if item.item_amount else 0,
#                     "vatPerc": item.tax_head.name if item.tax_head else "",
#                     "deliveryDate": delivery_date.strftime("%Y-%m-%d"),
#                 })

#             if created:
#                 response = belsio_request('post', os.getenv('BELSIO_PO_DIRECT', ''), data, 'json', False)
#                 print('response', response)
#                 if isinstance(response, dict) and response.get("purchaseOrderNo"):
#                     instance.extra = instance.extra or {}
#                     instance.extra['belsio_po_number'] = response['purchaseOrderNo']
#                     instance.save(update_fields=["extra"])
#             # else:
#             #     # UPDATE EXISTING PO
#             #     belsio_po_number = instance.extra.get('belsio_po_number') if instance.extra else None
#             #     if belsio_po_number:
#             #         # url = os.getenv('BELSIO_PO', '') + f"/{belsio_po_number}"
#             #         encoded_po_number = quote(belsio_po_number, safe='')
#             #         url = os.getenv('BELSIO_PO', '') + f"/{encoded_po_number}"
#             #         response = belsio_request('put', url, data, 'json', False)
#             #         print("Update Response:", response)
#             #     else:
#             #         print("Belsio PO number not found in instance.extra")

#         except Exception as e:
#             print('ERROR', e)


def handle_belsio_uom(instance=None, created=False):
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            url = os.getenv('BELSIO_UOM', '')
            uom_id = (instance.extra or {}).get("belsio_uom_id")
            data = {
                "description": instance.formal_name
            }
            if created:
                method = 'post'
            else:
                method = 'put'
                if not uom_id:
                    # print("Belsio UOM ID not found in instance.extra for update")
                    return None
                data["id"] = uom_id 
            response = belsio_request(method, url, data, 'json', False)
            # print(f"UOM {'create' if created else 'update'} response:", response)
            if created and isinstance(response, dict) and response.get("id"):
                instance.extra = {**(instance.extra or {}), "belsio_uom_id": response["id"]}
                instance.save(update_fields=["extra"])
        except Exception as e:
            print('ERROR in handle_belsio_uom:', e)



def sync_uoms_from_belsio():
    """
    Sync all UOMs from Belsio.
    """
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            url = os.getenv('BELSIO_UOM', '')
            page_number = 1
            page_size = os.getenv('BELSIO_PAGE_SIZE', 1000)

            while True:
                params = {
                    'PageNumber': page_number,
                    'PageSize': page_size,
                }
                response = belsio_request('get', url, params, 'params', False)
                if not isinstance(response, dict) or "items" not in response:
                    break

                items = response["items"]
                if not items:
                    break

                for uom_data in items:
                    belsio_id = uom_data.get("id")
                    description = uom_data.get("description", "").strip()
                    if not description:
                        continue
                    extra_data = {
                        **uom_data,  
                        "belsio_uom_id": belsio_id
                    }
                    uom, created = UnitOfMesurement.cmobjects.update_or_create(
                        formal_name=description,
                        organization_id=1,
                        defaults={
                            "extra": extra_data,
                            'symbol': description,
                            # 'organization_id':1
                        }
                    )
                    if not created:
                        existing_extra = uom.extra or {}
                        if not existing_extra.get("belsio_uom_id") or existing_extra != extra_data:
                            uom.extra = extra_data
                            uom.save(update_fields=["extra"])
                if not response.get("hasNextPage", False):
                    break
                page_number += 1
        except Exception as e:
            print("ERROR in sync_uoms_from_belsio:", e)
    return None

def handle_belsio_payment_term(instance=None, created=False):
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))) or instance.type != "Payment Terms":
        try:
            url = os.getenv('BELSIO_PAYMENT_TERMS', '')
            belsio_id = (instance.extra or {}).get("belsio_payment_term_id")
            data = {
                "terms": instance.code,
                "days": "1"
            }
            if created:
                method = 'post'
            else:
                method = 'put'
                if not belsio_id:
                    return None
                data["id"] = belsio_id  
            response = belsio_request(method, url, data, 'json', False)
            print(f"Payment Terms {'create' if created else 'update'} response:", response)
            if created and isinstance(response, dict) and response.get("id"):
                instance.extra = {**(instance.extra or {}), "belsio_payment_term_id": response["id"]}
                instance.save(update_fields=["extra"])

        except Exception as e:
            print("ERROR in handle_belsio_payment_term:", e)
    return None        

def sync_payment_terms_from_belsio():
    """
    Sync Payment Terms from Belsio into SAPMasters with type='Payment Terms'
    """

    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            url = os.getenv('BELSIO_PAYMENT_TERMS', '')
            page_number = 1
            page_size = os.getenv('BELSIO_PAGE_SIZE', 1000)
            while True:
                params = {
                    'PageNumber': page_number,
                    'PageSize': page_size,
                }
                response = belsio_request('get', url, params, 'params', False)

                if not isinstance(response, dict) or "items" not in response:
                    break

                items = response["items"]
                if not items:
                    break

                for item in items:
                    belsio_id = item.get("id")
                    terms = item.get("terms", "").strip()
                    days = item.get("days", "1")

                    if not terms:
                        continue

                    extra_data = {
                        **item,
                        "belsio_payment_term_id": belsio_id
                    }

                    obj, created = SAPMasters.cmobjects.update_or_create(
                        organization_id=1,
                        type="Payment Terms",
                        code=terms,
                        defaults={
                            "description": f"Days: {days}",
                            "extra": extra_data
                        }
                    )

                    if not created:
                        existing_extra = obj.extra or {}
                        if not existing_extra.get("belsio_payment_term_id") or existing_extra != extra_data:
                            obj.extra = extra_data
                            obj.save(update_fields=["extra"])

                if not response.get("hasNextPage", False):
                    break
                page_number += 1

        except Exception as e:
            print("ERROR in sync_payment_terms_from_belsio:", e)
    return None  
      
def handle_belsio_category(instance=None, created=False):
    """
    Sync a MaterialType instance to Belsio as a Category or SubCategory on create or update.
    """
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            is_sub_category = instance.parent is not None
            base_category_url = os.getenv('BELSIO_CATEGORY', '')
            base_sub_category_url = os.getenv('BELSIO_SUB_CATEGORY', '')

            belsio_id_key = "belsio_sub_category_id" if is_sub_category else "belsio_category_id"
            belsio_id = (instance.extra or {}).get(belsio_id_key)

            if is_sub_category:
                # Subcategory payload
                data = {
                    "subCatCode": str(instance.id),
                    "catCode": str(instance.parent.id),
                    "subCatName": instance.name,
                    "createdByModifiedBy": ""
                }
                if created:
                    method = 'post'
                    url = base_sub_category_url
                else:
                    if not belsio_id:
                        return None
                    method = 'put'
                    encoded_id = quote(str(belsio_id), safe='')
                    url = f"{base_sub_category_url}/{encoded_id}"

            else:
                # Category payload
                data = {
                    "catCode": str(instance.id),
                    "catName": instance.name,
                    "inventoryAccountCode": "",
                    "grnAccountCode": "",
                    "invoiceAccountCode": "",
                    "cgsAccountCode": "",
                    "adjustmentAccountCode": "",
                    "wastageAccountCode": "",
                    "workInProgressAccountCode": "",
                    "issueAccountCode": "",
                    "createdByModifiedBy": ""
                }
                if created:
                    method = 'post'
                    url = base_category_url
                else:
                    if not belsio_id:
                        return None
                    method = 'put'
                    encoded_id = quote(str(belsio_id), safe='')
                    url = f"{base_category_url}/{encoded_id}"

            response = belsio_request(method, url, data, 'json', False)
            print(f"MaterialType {'sub-category' if is_sub_category else 'category'} {'created' if created else 'updated'} response:", response)

            if created and isinstance(response, dict) and response.get("recordId"):
                instance.extra = {**(instance.extra or {}), belsio_id_key: response["recordId"]}
                instance.save(update_fields=["extra"])

        except Exception as e:
            print("ERROR in handle_belsio_category:", e)

    return None
def sync_category_from_belsio():
    """
    Sync Item Categories and Subcategories from Belsio into MaterialType.
    """
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            print('check')
            category_url = os.getenv('BELSIO_CATEGORY', '')
            sub_category_url = os.getenv('BELSIO_SUB_CATEGORY', '')
            page_size = int(os.getenv('BELSIO_PAGE_SIZE', 1000))
            category_map = {}

            # === Sync Categories ===
            page_number = 1
            while True:
                params = {'PageNumber': page_number, 'PageSize': page_size}
                response = belsio_request('get', category_url, params, 'params', False)
                print("Category response:", response)
                items = response.get("items", [])
                if not items:
                    break

                for item in items:
                    belsio_id = item.get("recordId")
                    cat_code = item.get("categoryCode", "")
                    cat_name = item.get("categoryName", "")
                    if not cat_name:
                        continue

                    extra_data = {
                        **item,
                        "belsio_category_id": belsio_id
                    }

                    obj, created = MaterialType.cmobjects.update_or_create(
                        organization_id=1,
                        name=cat_name,
                        parent=None,
                        defaults={
                            "code": cat_code,
                            "extra": extra_data
                        }
                    )
                    category_map[cat_name] = obj

                    if not created and (not obj.extra or obj.extra != extra_data):
                        obj.extra = extra_data
                        obj.save(update_fields=["extra"])

                if not response.get("hasNextPage", False):
                    break
                page_number += 1

            # Sync Subcategories 
            page_number = 1
            while True:
                params = {'PageNumber': page_number, 'PageSize': page_size}
                response = belsio_request('get', sub_category_url, params, 'params', False)
                print("Sub-category response:", response)

                items = response.get("items", [])
                if not items:
                    break

                for item in items:
                    belsio_id = item.get("recordId")
                    sub_cat_code = item.get("subCatCode", "")
                    sub_cat_name = item.get("subCatName", "")
                    cat_name = item.get("catName", "")

                    if not sub_cat_name or not cat_name:
                        continue

                    parent_obj = category_map.get(cat_name)
                    if not parent_obj:
                        continue

                    extra_data = {
                        **item,
                        "belsio_sub_category_id": belsio_id
                    }

                    obj, created = MaterialType.cmobjects.update_or_create(
                        organization_id=1,
                        name=sub_cat_name,
                        parent=parent_obj,
                        defaults={
                            "code": sub_cat_code,
                            "extra": extra_data
                        }
                    )

                    if not created and (not obj.extra or obj.extra != extra_data):
                        obj.extra = extra_data
                        obj.save(update_fields=["extra"])

                if not response.get("hasNextPage", False):
                    break
                page_number += 1

        except Exception as e:
            print("ERROR in sync_category_from_belsio:", e)
    return None

def handle_belsio_cost_centre1(instance=None, created=False):
    """
    Sync Project instance to Belsio as a Cost Centre on create or update.
    """
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            base_url = os.getenv('BELSIO_COST_CENTER', '')
            belsio_id = (instance.extra or {}).get("belsio_cost_center_id")
            project_data = get_project_data(instance.id)
            project_id = project_data.get("project_id")
            if not project_id:
                return None

            data = {
                "description": project_id
            }

            if created:
                method = 'post'
                url = base_url
            else:
                if not belsio_id:
                    return None  
                data["recordId"] = belsio_id  
                method = 'put'
                encoded_id = quote(str(belsio_id), safe='')
                print('encoded id',encoded_id)
                url = f"{base_url}/{encoded_id}"

            response = belsio_request(method, url, data, 'json', False)
            print(f"Cost Center {'created' if created else 'updated'} response:", response)

            if created and isinstance(response, dict) and response.get("recordId"):
                instance.extra = {**(instance.extra or {}), "belsio_cost_center_id": response["recordId"]}
                instance.save(update_fields=["extra"])

        except Exception as e:
            print("ERROR in handle_belsio_cost_centre:", e)

    return None

def handle_belsio_item_master(instance=None, created=False):
    """
    Sync a VendorMaterialMaster instance to Belsio Item Master on create or update.
    """
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            base_url = os.getenv('BELSIO_ITEM_MASTER', '')
            category_code = ""
            sub_category_code = ""

            if instance.material_type:
                if instance.material_type.parent:
                    category_code = str(instance.material_type.parent.id)
                else:
                    category_code=str(instance.material_type.id)
                sub_category_code = str(instance.material_type.id)

                extra = instance.extra or {}
                
            # inventory_account_code = extra.get("belsio_inventory_account_code") or "11384"
            # inventory_account_name = extra.get("belsio_inventory_account_name") or "Test"
            # grn_account_code = extra.get("belsio_grn_account_code") or "110311000"
            # grn_account_name = extra.get("belsio_grn_account_name") or "SUNDRY ACCOUNTS RECEIVABLE"
            # cgs_account_code = extra.get("belsio_cgs_account_code") or "110311000"
            # cgs_account_name = extra.get("belsio_cgs_account_name") or "SUNDRY ACCOUNTS RECEIVABLE"
            # adjustment_account_code = extra.get("belsio_adjustment_account_code") or ""
            # adjustment_account_name = extra.get("belsio_adjustment_account_name") or ""
            # wastage_account_code = extra.get("belsio_wastage_account_code") or ""
            # wastage_account_name = extra.get("belsio_wastage_account_name") or ""
            inventory_account_code = extra.get("belsio_inventory_account_code","") 
            inventory_account_name = extra.get("belsio_inventory_account_name","") 
            grn_account_code = extra.get("belsio_grn_account_code","") 
            grn_account_name = extra.get("belsio_grn_account_name","")
            cgs_account_code = extra.get("belsio_cgs_account_code","")
            cgs_account_name = extra.get("belsio_cgs_account_name","") 
            adjustment_account_code = extra.get("belsio_adjustment_account_code","") 
            adjustment_account_name = extra.get("belsio_adjustment_account_name","") 
            wastage_account_code = extra.get("belsio_wastage_account_code","") 
            wastage_account_name = extra.get("belsio_wastage_account_name","") 
            data = {
                "itemNo": instance.material_code,
                "description": instance.material_name or "",
                "averageCost": 0,
                "contractedPrice": 0,
                "reorderLevel": 0,
                "minQty": 5,
                "maxQty": 0,
                "brand": "",
                "supplierName": "",
                "remarks": instance.remarks or "",
                "vat": instance.gst_tax.name if instance.gst_tax else "",
                "stockTypeCode": "GE",
                "categoryCode": category_code,
                "subCategoryCode": sub_category_code,
                "inventoryUOM": instance.unit_of_mesurement.formal_name if instance.unit_of_mesurement else "",
                "packingUOM": instance.unit_of_mesurement.formal_name if instance.unit_of_mesurement else "",
                "packingType": "",
                "size": "",
                "shape": "",
                "weight": "",
                "finishedGood": False,
                "services": False,
                "fixedAsset": instance.is_asset_material or False,
                "sales": False,
                "directPurchase": False,
                "convToInvUOM": 5,
                "isActive": True,
                "length": 0,
                "width": 0,
                "height": 0,
                "volume": 0,
                "thickness": 0,
                "inventoryAccountCode": inventory_account_code,
                "inventoryAccountName": inventory_account_name,
                "grnAccountCode": grn_account_code,
                "grnAccountName": grn_account_name,
                "cgsAccountCode": cgs_account_code,
                "cgsAccountName": cgs_account_name,
                "adjustmentAccountCode": adjustment_account_code,
                "adjustmentAccountName": adjustment_account_name,
                "wastageAccountCode": wastage_account_code,
                "wastageAccountName": wastage_account_name,
                "issueAccountCode": "",
                "issueAccountName": "",
                "workInProgressAccountCode": "",
                "workInProgressAccountName": ""
            }

            if created:
                method = 'post'
                url = base_url
            else:
                method = 'put'
                url = base_url 

            response = belsio_request(method, url, data, 'json', False)
            print(f"Item Master {'create' if created else 'update'} response:", response)

            if created and isinstance(response, dict) and response.get("id"):
                instance.extra = {**(instance.extra or {}), "belsio_item_id": response["id"],"belsio_item_no":instance.material_code}
                instance.save(update_fields=["extra"])

        except Exception as e:
            print("ERROR in handle_belsio_item_master:", e)

    return None

def sync_item_master_from_belsio():
    """
    Sync (create/update) Item Master data from Belsio into VendorMaterialMaster.
    """
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            url = os.getenv('BELSIO_ITEM_MASTER', '')
            page_number = 1
            page_size = int(os.getenv('BELSIO_PAGE_SIZE', 1000))

            while True:
                params = {
                    'PageNumber': page_number,
                    'PageSize': page_size,
                }
                response = belsio_request('get', url, params, 'params', False)

                if not isinstance(response, dict) or "items" not in response:
                    break

                items = response["items"]
                if not items:
                    break

                for item in items:
                    item_no = item.get("itemNo")
                    if not item_no:
                        continue
                    
                    material_name = item.get("description", "").strip()
                    uom_name = item.get("inventoryUOM", "").strip() or item.get("uom", "").strip()
                    
                    belsio_id = item.get("id", None)
                    uom_obj = UnitOfMesurement.cmobjects.filter(formal_name__iexact=uom_name).first()
                    extra_data = {
                        **item,
                        "belsio_item_id": belsio_id,
                        "belsio_item_no": item_no,
                    }

                    defaults = {
                        "material_name": material_name,
                        "unit_of_mesurement_id": uom_obj.id if uom_obj else 1,
                        "extra": extra_data,
                        "organization_id": 1,
                        # "belsio_inventory_account_code": item.get("inventoryAccountCode", ""),
                        # "belsio_inventory_account_name": item.get("inventoryAccountName", ""),
                        # "belsio_grn_account_code": item.get("grnAccountCode", ""),
                        # "belsio_grn_account_name": item.get("grnAccountName", ""),
                        # "belsio_cgs_account_code": item.get("cgsAccountCode", ""),
                        # "belsio_cgs_account_name": item.get("cgsAccountName", ""),
                        # "belsio_adjustment_account_code": item.get("adjustmentAccountCode", ""),
                        # "belsio_adjustment_account_name": item.get("adjustmentAccountName", ""),
                        # "belsio_wastage_account_code": item.get("wastageAccountCode", ""),
                        # "belsio_wastage_account_name": item.get("wastageAccountName", ""),
                    }

                    with transaction.atomic():
                        obj, created = VendorMaterialMaster.cmobjects.update_or_create(
                            material_code=item_no,
                            defaults=defaults
                        )

                        if not created and (not obj.extra or obj.extra != extra_data):
                            obj.extra = extra_data
                            obj.save(update_fields=["extra"])

                if not response.get("hasNextPage", False):
                    break

                page_number += 1

        except Exception as e:
            print("ERROR in sync_item_master_from_belsio:", e)

    return None

def sync_tax_master_from_belsio():
    """
    Sync Tax Master data from Belsio into TaxHead.
    """
    if not bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        return

    try:
        url = os.getenv('BELSIO_TAX_MASTER', '')
        page_number = 1
        page_size = int(os.getenv('BELSIO_PAGE_SIZE', 1000))

        while True:
            params = {
                'PageNumber': page_number,
                'PageSize': page_size,
            }

            response = belsio_request('get', url, params, 'params', False)

            if not isinstance(response, dict) or "items" not in response:
                break

            items = response["items"]
            if not items:
                break

            for item in items:
                belsio_id = item.get("recordId")
                if belsio_id is None:
                    continue

                name = item.get("description", "").strip() or "NA"
                tax_type = item.get("category","")
                rate = item.get("rate", 0)
                remarks = item.get("remarks", "")
                short_name = item.get("regNo", "")

                extra_data = {
                    **item,
                    "belsio_tax_id": belsio_id,
                }

                defaults = {
                    "name": name,
                    "tax_type": tax_type if tax_type in dict(TaxHead.TAX_TYPE) else "",
                    "tax_rate": rate,
                    "remarks": remarks,
                    "short_name": short_name,
                    "extra": extra_data,
                    "organization_id": 1,
                }

                with transaction.atomic():
                    obj, created = TaxHead.cmobjects.update_or_create(
                        extra__belsio_tax_id=belsio_id,
                        defaults=defaults,
                    )

                    if not created and (not obj.extra or obj.extra != extra_data):
                        obj.extra = extra_data
                        obj.save(update_fields=["extra"])

            if not response.get("hasNextPage", False):
                break

            page_number += 1

    except Exception as e:
        print("ERROR in sync_tax_master_from_belsio:", e)

    return None

def handle_belsio_tax_master(instance=None, created=False):
    """
    Sync TaxHead instance to Belsio Tax Master on create or update.
    """
    if bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        try:
            base_url = os.getenv('BELSIO_TAX_MASTER', '')
            belsio_id = (instance.extra or {}).get("belsio_tax_id")
            current_date = datetime.today()
            # print(base_url)
            data = {
                "category": instance.tax_type or "",
                "frequency": 0,
                "description": instance.name,
                "regNo": instance.short_name or "",
                "fromDate": current_date.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                "toDate": current_date.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                "amountFrom": 0,
                "amountTo": 0,
                "rate": instance.tax_rate or 0,
                "calculateOn": 0,
                "exempted": False,
                "zero": False,
                "salesTaxRate": instance.tax_rate or 0,
                "vat": instance.tax_type == "vat_tax",
                "salesTax": instance.tax_type == "gst_tax",
                "excise": instance.tax_type == "excise_tax",
                "toSales": False,
                "toPurchase": False,
                "vatAcCode": "",
                "stAcCode": "",
                "eAcCode":  "",
                "remarks": instance.remarks or ""
            }

            if created:
                method = 'post'
                url = base_url
            else:
                if not belsio_id:
                    return None
                data["recordId"] = belsio_id
                method = 'put'
                print(data["recordId"])
                encoded_id = quote(str(belsio_id), safe='')
                url = f"{base_url}/{encoded_id}"
                print(url)
            response = belsio_request(method, url, data, 'json', False)
            print(f"Tax Master {'created' if created else 'updated'} response:", response)

            if created and isinstance(response, dict) and response.get("recordId"):
                instance.extra = {**(instance.extra or {}), "belsio_tax_id": response["recordId"]}
                instance.save(update_fields=["extra"])

        except Exception as e:
            print("ERROR in handle_belsio_tax_master:", e)

    return None

def fetch_all_account_master_items():
    """
    Fetch all account master items from Belsio.
    """
    if not bool(int(str(os.getenv('BELSIO_SYNC', '0')))):
        return []

    try:
        fetch_url = os.getenv('BELSIO_ACCOUNT_MASTER', '')  
        page_number = 1
        page_size = int(os.getenv('BELSIO_PAGE_SIZE', 5000))

        all_items = []

        while True:
            params = {
                'PageNumber': page_number,
                'PageSize': page_size,
            }

            response = belsio_request('get', fetch_url, params, 'params', False)

            if not isinstance(response, dict) or "items" not in response:
                print(f"No valid response at page {page_number}")
                break

            items = response["items"]
            if not items:
                break

            all_items.extend(items)

            if not response.get("hasNextPage", False):
                break

            page_number += 1

        return all_items

    except Exception as e:
        print("ERROR in fetch_all_account_master_items:", e)
        raise e  

    return []
def password_expiry_date_reset():
    return date.today() + timedelta(days=int(str(os.getenv('PASSWORD_RESET_DAYS', '0'))))

def financialyear_id_by_date(date):
    if not date:
        return None
    return FinancialYear.cmobjects.filter(
        start_date__lte=date,
        end_date__gte=date
    ).values_list('id', flat=True).first()


def generate_sap_vendor_master(instances):
    """
    Process multiple vendor instances in a single SAP request.
    """
    try:
        if not isinstance(instances, list):
            instances = [instances]
        context_data = []
        sap_records = []
        for instance in instances:
            last_ext_review = ''
            if getattr(instance, "last_ext_review", None):
                last_ext_review = str(getattr(instance, "last_ext_review", ""))
                last_ext_review = datetime.strptime(last_ext_review, '%Y-%m-%d').strftime('%Y%m%d')
            sap_record = {
                "AUTHORIZATION_KEY": os.getenv("SAP_VENDOR_CREATE_AUTH_KEY", ""),
                "SUPPLIER_ACCOUNT_GROUP": instance.account_group.name if getattr(instance, "account_group", None) else "",
                "BP_GROUPING": getattr(instance, "bp_grouping", ""),
                "TITLE": getattr(instance, "title", ""),
                "NAME": getattr(instance, "vendor_name", ""),
                "NAME_2": getattr(instance, "name_2", ""),
                # "SEARCH_TERM_1": getattr(instance, "search_term1", ""),#PMS-Vendor_id
                "SEARCH_TERM_1": f"PMS-{instance.id}" if getattr(instance, 'id', None) else "",
                "STREET_2": getattr(instance, "street2", ""),
                "STREET_3": getattr(instance, "street3", ""),
                "STREET_4": getattr(instance, "street4", ""),
                "STREET_5": getattr(instance, "street_5", ""),
                "POSTAL_CODE": getattr(instance, "postal_code", ""),
                "CITY": getattr(instance, "location", ""),
                "STATE": getattr(instance, "region", ""),
                "COUNTRY": getattr(instance, "country", ""),
                "LANGUAGE": getattr(instance, "language", ""),
                "DEFAULT_TELEPHONE": getattr(instance, "telephone1", ""),
                "DEFAULT_MOBILE": getattr(instance, "vendor_contact_no", ""),
                "DEFAULT_EMAIL": getattr(instance, "vendor_email_id", ""),
                "TAX_NUMBER_CATEGORY": getattr(instance, "tax_number_category", ""),
                "TAX_DECLARATION_TYPE": getattr(instance, "tax_declaration_type", ""),
                "TAN_NUMBER": getattr(instance, "tan_no", ""),
                "PAN": getattr(instance, "pan_no", ""),
                "GST_VEN_CLASS": getattr(instance, "gst_class", ""),
                "MSME_CERT": getattr(instance, "msme_no", ""),
                "LAST_EXT_REVIEW": last_ext_review,
                "CHECK_DOUBLE_INVOICE": getattr(instance, "check_double_invoice", ""),
                "GRBASED_INVOICE_VERIFICATION": getattr(instance, "grbased_invoice_verification", ""),
                "SRVBASED_INVOICE_VERIFICATION": getattr(instance, "srvbased_invoice_verification", ""),
                "GROUP_FOR_CALCULATION_SCHEMA": getattr(instance, "group_for_calculation_schema", ""),
                "COMPANY_CODE": instance.company_code.sap_code if getattr(instance, "company_code", None) else "",
                "PURCHASING_ORGANIZATION": getattr(instance, "pur_org", ""),
                "ORDER_CURRENCY": instance.vendor_currency.slug if getattr(instance, "vendor_currency", None) else "",
                "PAYMENT_METHOD_1": getattr(instance, "payment_methods", ""),
                "RECONCILIATION_ACCOUNT_IN_GEN_": getattr(instance, "reconciliation_account_in_gen", ""),
                "INFO_NUMBER": getattr(instance, "info_number", ""),
                "TAX_NUMBER": getattr(instance, "tax_number", ""),
                "UPLOADED_BY": getattr(instance, "uploaded_by", "") or ""
            }
            sap_records.append(sap_record)
            
            context_record = {
                **model_to_dict(instance),
            }
            context_data.append(context_record)
        
        data = {
            "Record": sap_records
        }

        sap_resp, error_msg = sap_request(type='post', url=os.getenv('SAP_VENDOR_CREATE', ''), data=data, data_type='json')
        print("SAP Response:", sap_resp)

        if sap_resp:
            if "Message" in sap_resp and "data uploaded successfully to sap" in sap_resp["Message"].lower():
                # mail with vendor details
                context = {
                    "data": context_data,
                    "current_time": datetime.now().strftime('%d-%m-%Y %H:%M:%S'),
                }
                # print(context)
                user_list = list(UserWiseModulePermissions.cmobjects.filter(
                    module_item__unique_id='procurement-vendor-to',
                    level_permission=True
                ).values_list('user_id', flat=True))

                cc_user_list = list(UserWiseModulePermissions.cmobjects.filter(
                    module_item__unique_id='procurement-vendor-cc',
                    level_permission=True
                ).values_list('user_id', flat=True))
                trigger_notifications(
                    action='VENDOR-APPROVED',
                    user_list=user_list,
                    cc_user_list=cc_user_list,
                    context=context
                )
                return True, sap_resp 
            else:
                return False, sap_resp["Message"]  

        return False, error_msg 
    except Exception as e:
        error_message = str(e.args[0]) if e.args else str(e)
        print(error_message)
        return False, error_message

# def trigger_payment_approval_notifications(request,ids):
#     from procurement.views import PaymentMasterMainAPIView
#     try:
#         if isinstance(ids, int):
#             ids = [ids]
#         if not request.GET._mutable:
#             request.GET._mutable = True
#         request.GET['all'] = 'true'
#         request.GET['pk__in'] = ','.join(str(i) for i in ids)
#         request.GET['site__isnull'] = 'false'
#         request.GET['store__isnull'] = 'false'
#         print('check')
#         print(request.GET['type'])
#         print(ids)
#         if 'type' in request.GET:
#             del request.GET['type']
#         resp = PaymentMasterMainAPIView().get(request)
#         print(resp)
#         result_data = resp.data.get('results', [])
#         print(result_data)
#         if not result_data:
#             return
#         user_list = list(UserWiseModulePermissions.cmobjects.filter(
#             module_item__unique_id='procurement-pm-to',
#             level_permission=True
#         ).values_list('user_id', flat=True))
#         print("user list",user_list)    
#         cc_user_list = list(UserWiseModulePermissions.cmobjects.filter(
#             module_item__unique_id='procurement-pm-cc',
#             level_permission=True
#         ).values_list('user_id', flat=True))

#         context = {
#             'data': result_data,
#         }
#         trigger_notifications(
#             action='PAYMENT-MASTER-APPROVED',
#             user_list=user_list,
#             cc_user_list=cc_user_list,
#             context=context
#         )
#     except Exception as e:
#         print(f"Error in trigger_payment_approval_notifications: {e}")

def safe_model_to_dict(obj):
    data = {}
    for field in obj._meta.get_fields():
        try:
            if field.one_to_many:
                continue
            if isinstance(field, (models.FileField, models.ImageField)):
                value = getattr(obj, field.name, None)
                data[field.name] = value.url if value and hasattr(value, 'url') else None
            elif isinstance(getattr(obj, field.name, None), (date, datetime)):
                value = getattr(obj, field.name, None)
                data[field.name] = value.isoformat() if value else None
            elif field.is_relation and (field.many_to_one or field.one_to_one):
                value = getattr(obj, field.name, None)
                data[field.name] = value.pk if value else None
            elif field.is_relation and field.many_to_many:
                try:
                    m2m_qs = getattr(obj, field.name).all()
                    data[field.name] = list(m2m_qs.values_list('pk', flat=True))
                except Exception:
                    data[field.name] = []
            else:
                value = getattr(obj, field.name, None)
                data[field.name] = value
        except Exception:
            data[field.name] = None
    return data

def get_list_of_model_dict(instance):
    return [safe_model_to_dict(obj) for obj in instance]

def parse_date(date_str, field_name):
    """validate YYYY-MM-DD format"""
    if not date_str:
        return None
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise APIException({
            'request_status': 0,
            'msg': f"Invalid {field_name} format '{date_str}', expected YYYY-MM-DD"
        })
    
def calculate_po_totals_during_sap_sync(instance):
    """
    totals for a PurchaseOrder instance.
    """

    instance.total_item_item_quantity = 0
    instance.total_item_item_amount = 0
    instance.total_item_disc_amount = 0
    instance.total_item_taxable_amount = 0

    instance.total_item_excise_tax_amount = 0
    instance.total_item_tax_amount = 0
    instance.total_item_sgst_amount = 0
    instance.total_item_cgst_amount = 0
    instance.total_item_igst_amount = 0
    instance.total_item_utgst_amount = 0
    instance.total_item_cess_amount = 0
    instance.total_item_total_amount = 0

    instance.total_item_expense_expense_amount = 0
    instance.total_item_expense_sgst_amount = 0
    instance.total_item_expense_cgst_amount = 0
    instance.total_item_expense_igst_amount = 0
    instance.total_item_expense_utgst_amount = 0
    instance.total_item_expense_cess_amount = 0
    instance.total_item_expense_total_expense_amount = 0

    instance.total_tax_tax_amount = 0
    instance.total_tax_sgst_amount = 0
    instance.total_tax_cgst_amount = 0
    instance.total_tax_igst_amount = 0
    instance.total_tax_utgst_amount = 0
    instance.total_tax_cess_amount = 0
    instance.total_tax_total_tax_amount = 0

    instance.total_expense_expense_amount = 0
    instance.total_expense_sgst_amount = 0
    instance.total_expense_cgst_amount = 0
    instance.total_expense_igst_amount = 0
    instance.total_expense_utgst_amount = 0
    instance.total_expense_cess_amount = 0
    instance.total_expense_total_expense_amount = 0

    for item in instance.procurement_purchase_order_item.filter(is_deleted=False):
        if not item.is_deleted:
            instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
            instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
            instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
            instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
            instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
            instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
            instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
            instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
            instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
            instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
            instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
            instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount
            for item_exp in item.procurement_purchase_order_item_expense.filter(is_deleted=False):
                if not item_exp.is_deleted:
                    if item_exp.included:
                        if item_exp.add:
                            instance.total_item_expense_expense_amount = instance.total_item_expense_expense_amount+item_exp.expense_amount
                            instance.total_item_expense_sgst_amount = instance.total_item_expense_sgst_amount+item_exp.sgst_amount
                            instance.total_item_expense_cgst_amount = instance.total_item_expense_cgst_amount+item_exp.cgst_amount
                            instance.total_item_expense_igst_amount = instance.total_item_expense_igst_amount+item_exp.igst_amount
                            instance.total_item_expense_utgst_amount = instance.total_item_expense_utgst_amount+item_exp.utgst_amount
                            instance.total_item_expense_cess_amount = instance.total_item_expense_cess_amount+item_exp.cess_amount
                            instance.total_item_expense_total_expense_amount = instance.total_item_expense_total_expense_amount+item_exp.total_expense_amount
                        else:
                            instance.total_item_expense_expense_amount = instance.total_item_expense_expense_amount-item_exp.expense_amount
                            instance.total_item_expense_sgst_amount = instance.total_item_expense_sgst_amount-item_exp.sgst_amount
                            instance.total_item_expense_cgst_amount = instance.total_item_expense_cgst_amount-item_exp.cgst_amount
                            instance.total_item_expense_igst_amount = instance.total_item_expense_igst_amount-item_exp.igst_amount
                            instance.total_item_expense_utgst_amount = instance.total_item_expense_utgst_amount-item_exp.utgst_amount
                            instance.total_item_expense_cess_amount = instance.total_item_expense_cess_amount-item_exp.cess_amount
                            instance.total_item_expense_total_expense_amount = instance.total_item_expense_total_expense_amount-item_exp.total_expense_amount

    for item in instance.procurement_po_expense.filter(is_deleted=False):
        if not item.is_deleted:
            if item.included:
                if item.add:
                    instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                    instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                    instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                    instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                    instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                    instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                    instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                else:
                    instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                    instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                    instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                    instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                    instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                    instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                    instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

    for item in instance.procurement_po_tax.filter(is_deleted=False):
        if not item.is_deleted:
            if item.included:
                if item.add:
                    instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                    instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                    instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                    instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                    instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                    instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                    instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                else:
                    instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                    instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                    instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                    instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                    instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                    instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                    instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
    instance.total_amount = instance.total_item_total_amount+instance.total_item_expense_total_expense_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
    instance.save()

# CST FINAL DIR APPROVAL 
def send_cst_approval_director_email(approved_cst_ids):
    """
        In CST (Both), on Director Approval, an auto email should be shared with "procurement@shyaminfra.com"
    """
    for id in approved_cst_ids:
        
        # CSTMainAPIView

        cst_details_query = CST.cmobjects.filter(id=id).values('id', 'request_code',
                'title', 'created_at', 'approved_by_date', 'date', 'rfq_vendor')
        if not cst_details_query:
            return
        cst_details = cst_details_query[0]

        created_at = cst_details['created_at'].strftime('%d-%m-%Y') if cst_details['created_at'] else ""
        approved_by_date = cst_details['approved_by_date'].strftime('%d-%m-%Y') if cst_details['approved_by_date'] else ""
        date = cst_details['date'].strftime('%d-%m-%Y') if cst_details['date'] else ""

        subject = f"Final Approval Notification CST - {cst_details['request_code']}"
        rfq_vendors = cst_details['rfq_vendor']
        if not rfq_vendors:
            return
        quotation_details = Quotation.cmobjects.filter(rfq_vendor=rfq_vendors)
        cumulativeTotalVendorAmount = 0
        for quotation in quotation_details:
            total_basic_amount = 0
            quotation_items = QuotationItems.cmobjects.filter(quotation=quotation, is_selected_by_cst=True)

            for item in quotation_items:
                rate = item.rate or 0
                qty = item.quantity_by_cst or 0
                disc_percent = item.disc_percentage or 0
                net_rate = rate * (1 - disc_percent / 100)
                total_basic_amount += net_rate * qty

            packing_forwarding = quotation.packing_forwarding_by_cst or 0
            transportation_charges = quotation.transportaion_charges_by_cst or 0 
            other_charges = quotation.other_charges_by_cst or 0
            total_before_gst = total_basic_amount + packing_forwarding + transportation_charges + other_charges
            total_gst_amount = 0
            gst_components = {"cgst": 0, "sgst": 0, "igst": 0, "cess": 0}

            for item in quotation_items:
                cgst_p = item.cgst_percentage or 0
                sgst_p = item.sgst_percentage or 0
                igst_p = item.igst_percentage or 0
                cess_p = item.cess_percentage or 0

                item_share = 0
                if total_basic_amount > 0:
                    item_total_net = (item.rate or 0) * (item.quantity_by_cst or 0) * (1 - (item.disc_percentage or 0)/100)
                    item_share = item_total_net / total_basic_amount

                item_gst_base = total_before_gst * item_share
                cgst_amt = (item_gst_base * cgst_p) / 100
                sgst_amt = (item_gst_base * sgst_p) / 100
                igst_amt = (item_gst_base * igst_p) / 100
                cess_amt = (item_gst_base * cess_p) / 100

                total_gst_amount += cgst_amt + sgst_amt + igst_amt + cess_amt
                gst_components["cgst"] += cgst_amt
                gst_components["sgst"] += sgst_amt
                gst_components["igst"] += igst_amt
                gst_components["cess"] += cess_amt

            extra_expense_gst = 0
            expense_details = QuotationExpenseDetails.cmobjects.filter(quotation=quotation)

            for exp in expense_details:
                exp_amount = exp.expense_amount or 0
                if exp.expense_condition == 'after_gst':
                    total_percentage = (exp.cgst_percentage or 0) + (exp.sgst_percentage or 0) + (exp.igst_percentage or 0)
                    extra_expense_gst += (exp_amount * total_percentage) / 100

            total_gst_amount += extra_expense_gst

            grand_total = total_before_gst + total_gst_amount
            cumulativeTotalVendorAmount += grand_total

        context = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "created_at" : created_at,
            "approved_by_date" : approved_by_date,
            "date" : date,
            "rfq_vendor" : cst_details['rfq_vendor'],
            "request_code" : cst_details['request_code'],
            "title" : cst_details['title'],
            "id" : cst_details['id'],
            "cumulativeTotalVendorAmount": round(cumulativeTotalVendorAmount, 2),
        }

        # to_users_email = ['procurement@shyaminfra.com']
        cc_users_email = []

        to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['cst_final_approval_mail_to'],
            level_permission=True,
        ).values_list('user_id',flat=True))

        to_users_list = list(PmsUser.objects.filter(email__in=to_users_list).values_list('id', flat=True))
        cc_users_list = list(PmsUser.objects.filter(email__in=cc_users_email).values_list('id', flat=True))
        trigger_notifications(action='', subject=subject, user_list=to_users_list, cc_user_list=cc_users_list, context=context) 

def mr_create_email_notifications(id, request_code, user_full_name):
    """
        MR CREATE Alerts Notifications Email
    """
    try:
        if isinstance(id, int):
            id = id
        to_user_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id='procurement-mr-checker',
            level_permission=True
        ).values_list('user_id', flat=True))   
        cc_user_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id='procurement-mr-checker-cc',
            level_permission=True
        ).values_list('user_id', flat=True))
        context = {
            'request_code': request_code,
            'date': datetime.now().strftime("%Y-%m-%d"),
            'ref_url' : f"{str(os.getenv('FE_MR_CREATE',''))}{id}",
            'user_full_name' : user_full_name,
        }
        trigger_notifications(
            action='MR-CREATE-NOTIFICATION',
            user_list=to_user_list,
            cc_user_list=cc_user_list,
            context=context
        )
    except Exception as e:
        print(f"Error in trigger_payment_approval_notifications: {e}")

def mr_checked_email_notifications(ids, user_full_name):
    """
    Send MR CHECKED email notifications to approvers and CC users.
    """
    try:
        if isinstance(ids, int):
            ids = [ids]
        mr_master_list = list(
            MaterialRequestMasterItems.cmobjects.filter(
                pk__in=ids,
                material_request__isnull=False
            ).values(
                'material_request__request_code',
                'material_request_id'
            ).distinct()
        )
        if not mr_master_list:
            return
        user_list = list(
            UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id='procurement-mr-approver',
                level_permission=True
            ).values_list('user_id', flat=True)
        )
        cc_user_list = list(
            UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id='procurement-mr-approver-cc',
                level_permission=True
            ).values_list('user_id', flat=True)
        )
        if not user_list:
            return
        for item in mr_master_list:
            material_request_id = item['material_request_id']
            context = {
                'request_code': item['material_request__request_code'],
                'date': datetime.now().strftime("%Y-%m-%d"),
                'user_full_name': user_full_name,
                'ref_url' : f"{str(os.getenv('FE_MR_CREATE',''))}{material_request_id}",
            }
            trigger_notifications(
                action='MR-CHECKED-NOTIFICATION',
                user_list=user_list,
                cc_user_list=cc_user_list,
                context=context
            )
    except Exception as e:
        print(f"Error in mr_checked_email_notifications: {e}")

## Indent
def indent_create_email_notifications(indent_no, indent_id, user_full_name):
    """
        INDENT CREATE Alerts Notifications Email
    """
    try:
        to_user_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id='procurement-mr-checker',
            level_permission=True
        ).values_list('user_id', flat=True))   
        cc_user_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id='procurement-mr-checker-cc',
            level_permission=True
        ).values_list('user_id', flat=True))
        context = {
            'request_code': indent_no,
            'date': datetime.now().strftime("%Y-%m-%d"),
            'ref_url' : f"{str(os.getenv('FF_INDENT_ITEM_LIST_URL',''))}{indent_id}",
            'user_full_name' : user_full_name,
        }
        trigger_notifications(
            action='INDENT-CREATE-NOTIFICATIONS',
            user_list=to_user_list,
            cc_user_list=cc_user_list,
            context=context
        )
    except Exception as e:
        print(f"Error in indent_create_email_notifications: {e}")


def indent_checked_email_notifications(ids, user_full_name):
    """
    Send INDENT CHECKED email notifications to approvers and CC users.
    """
    try:
        if isinstance(ids, int):
            ids = [ids]
        indent_master_list = list(
            IndentItems.cmobjects.filter(
                pk__in=ids,
                indent__isnull=False
            ).values(
                'indent__request_code',
                'indent_id'
            ).distinct()
        )
        if not indent_master_list:
            return
        user_list = list(
            UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id='procurement-mr-approver',
                level_permission=True
            ).values_list('user_id', flat=True)
        )
        cc_user_list = list(
            UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id='procurement-mr-approver-cc',
                level_permission=True
            ).values_list('user_id', flat=True)
        )
        if not user_list:
            return
        for item in indent_master_list:
            indent_id = item['indent_id']
            context = {
                'request_code': item['indent__request_code'],
                'date': datetime.now().strftime("%Y-%m-%d"),
                'user_full_name': user_full_name,
                'ref_url' : f"{str(os.getenv('FF_INDENT_ITEM_LIST_URL',''))}{indent_id}",
            }
            trigger_notifications(
                action='INDENT-CHECKED-NOTIFICATIONS',
                user_list=user_list,
                cc_user_list=cc_user_list,
                context=context
            )
    except Exception as e:
        print(f"Error in indent_checked_email_notifications: {e}")

# Quotation
def quotation_create_email_notifications(quotation_id, user_full_name):
    """
        Quotation CREATE Alerts Notifications Email
    """
    try:
        quotation_details = Quotation.cmobjects.select_related('rfq_vendor', 'vendor', 'project').filter(pk=quotation_id).values(
                'request_code', 'date','rfq_vendor__request_code','rfq_vendor__date', 'vendor__vendor_name').first()
        to_user_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id='procurement-quotation-received-to',
            level_permission=True
        ).values_list('user_id', flat=True))   
        cc_user_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id='procurement-quotation-received-cc',
            level_permission=True
        ).values_list('user_id', flat=True))
        context = {
            'data' : quotation_details,
            'date': datetime.now().strftime("%Y-%m-%d"),
            'ref_link' : str(os.getenv('FE_QUOTATION', '#')),
        }
        trigger_notifications(
            action='QUOTATION-CREATE-NOTIFICATIONS',
            user_list=to_user_list,
            cc_user_list=cc_user_list,
            context=context
        )
    except Exception as e:
        print(f"Error in quotation_create_email_notifications: {e}")

def parse_date_str(raw):
    """Try to parse YYYY-MM-DD or YYYY-MM-DD HH:MM:SS strings into datetime.date."""
    try:
        return datetime.fromisoformat(raw).date()
    except Exception:
        try:    
            return datetime.strptime(raw, "%Y-%m-%d").date()
        except Exception:
            return None

def generate_payment_list_excel(context):
    """
    Generates Excel file from context, saves to S3, and returns (excel_bytes, filename, s3_url).
    """
    try:
        COLUMN_HEADERS = [
            "SR NO", "Request Code", "Request Date", "Vendor Code", "Beneficiary Name", "Amount (Rs.)",
            "Site", "Purpose", "Payment Against", "Payment No", "Date", "Due Date",
            "Remarks", "GST Type", "PO No", "CST No", "Payment Status", "Status", "Approval Date",
        ]
        HEADER_TO_DATA_KEY = {
            "SR NO": None,
            "Request Code": "request_code",
            "Request Date": "created_at",
            "Vendor Code": "vendor__vendor_code",
            "Beneficiary Name": "vendor__vendor_name",
            "Amount (Rs.)": "amount",
            "Site": "site__site_name",
            "Purpose": "purpose",
            "Payment Against": "payment_against",
            "Payment No": "payment_no",
            "Date": "date",
            "Due Date": "due_date",
            "Remarks": "remarks",
            "GST Type": "gst_type", 
            "PO No": "purchase_order__sap_code",
            "CST No": "cst__request_code",
            "Payment Status": "payment_status_type",
            "Status": "current_status",
            "Approval Date" : "approved_by_date",
        }
        output = BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        worksheet = workbook.add_worksheet("Payment Approved List")

        header_format = workbook.add_format({
            'bold': True, 'border': 1, 'align': 'center',
            'valign': 'vcenter', 'bg_color': '#D9E1F2'
        })
        default_format = workbook.add_format({'border': 1, 'font_size': 10})
        date_format = workbook.add_format({
            'border': 1, 'align': 'center', 'valign': 'vcenter',
            'font_size': 10, 'num_format': 'dd-mm-yyyy'
        })
        indian_currency_format = workbook.add_format({
            'border': 1, 'align': 'right', 'valign': 'vcenter',
            'font_size': 10, 'num_format': '#,##,##0.00'
        })

        for col_idx, header in enumerate(COLUMN_HEADERS):
            worksheet.write(0, col_idx, header, header_format)

        data_list = context.get("data", [])
        if not data_list:
            raise ValueError("No data found in context['data'].")

        for row_idx, item in enumerate(data_list, start=1):
            for col_idx, header in enumerate(COLUMN_HEADERS):
                key = HEADER_TO_DATA_KEY.get(header)
                raw = item.get(key) if key else None

                if header == "SR NO":
                    worksheet.write(row_idx, col_idx, row_idx, default_format)
                    continue

                if header in ("Date", "Due Date", "Approval Date", "Request Date"):
                    if isinstance(raw, str):
                        date_obj = parse_date_str(raw)
                        if date_obj:
                            worksheet.write_datetime(row_idx, col_idx, date_obj, date_format)
                        else:
                            worksheet.write(row_idx, col_idx, raw, default_format)
                    else:
                        try:
                            if isinstance(raw, datetime):
                                d = raw.date()
                            elif isinstance(raw, (int, float)):
                                worksheet.write(row_idx, col_idx, raw, date_format)
                                continue
                            else:
                                d = None
                            if d:
                                worksheet.write_datetime(row_idx, col_idx, d, date_format)
                            else:
                                worksheet.write(row_idx, col_idx, str(raw), default_format)
                        except Exception:
                            worksheet.write(row_idx, col_idx, str(raw), default_format)
                    continue

                if header == "Amount (Rs.)":
                    try:
                        num_val = float(raw) if raw not in (None, '') else 0.0
                        worksheet.write_number(row_idx, col_idx, num_val, indian_currency_format)
                    except (TypeError, ValueError):
                        worksheet.write(row_idx, col_idx, 0.0, indian_currency_format)
                    continue

                if header == "GST Type":
                    raw_gst = item.get("gst_type")
                    if raw_gst == "including_gst":
                        display_val = "Including GST"
                    elif raw_gst == "hold_gst":
                        display_val = "Hold GST"
                    elif raw_gst == "excluding_gst":
                        display_val = "Excluding GST"
                    else:
                        display_val = str(raw_gst) if raw_gst else ""
                    worksheet.write(row_idx, col_idx, display_val, default_format)
                    continue

                if header == "Payment Status":
                    raw_payment_status_type = item.get("payment_status_type")
                    if raw_payment_status_type:
                        display_val = str(raw_payment_status_type).strip().capitalize()
                    else:
                        display_val = ""
                    worksheet.write(row_idx, col_idx, display_val, default_format)
                    continue

                worksheet.write(row_idx, col_idx, raw if raw is not None else "", default_format)
        workbook.close()
        excel_bytes = output.getvalue()
        # Save to S3
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        excel_filename = f"payment_approved_list_{timestamp}.xlsx"
        s3_path = f"payment_excels/{excel_filename}"
        content_file = ContentFile(excel_bytes)
        saved_path = default_storage.save(s3_path, content_file)
        excel_url = default_storage.url(saved_path)
        return excel_url
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error generating payment Excel: {str(e)}")
        raise

def generate_payment_list_pdf(context):
    """
    Generates PDF, saves to S3, and returns (pdf_bytes, filename, s3_url).
    """
    try:
        html = render_to_string('payment/payment_module_approve_list_pdf.html', context)
        if not isinstance(html, str):
            raise ValueError(f"render_to_string did not return a string! Got: {type(html)}")
        options = {
            'page-size': 'A4',
            'encoding': "UTF-8",
            'no-outline': None,
        }
        config = pdfkit.configuration(wkhtmltopdf=str(os.getenv('WKHTMLTOPDF_PATH','')))
        pdf_bytes = pdfkit.from_string(html, False, options=options, configuration=config)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        pdf_filename = f"payment_approved_list_{timestamp}.pdf"
        s3_path = f"payment_pdfs/{pdf_filename}"

        content_file = ContentFile(pdf_bytes)
        saved_path = default_storage.save(s3_path, content_file)
        pdf_url = default_storage.url(saved_path)
        return pdf_url
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error generating payment PDF: {str(e)}")
        raise 

def send_payment_mudule_dir_update_email(request, ids):
    """
        PMS-Auto Email Format Approval Request (Payment Module:Once the above list gets Final Dir-Approved (Verify| 
        HOD-Approved| Dir-Approved), an auto email containing the above final approved list, shall be shared 
        with (To: accounts@shyaminfra.com and CC: procurement@shyaminfra.com) 
    """
    from .views import PaymentMasterMainAPIView
    request._request.META['QUERY_STRING'] = ''
    request._request.GET = type(request._request.GET)()
    try:
        delattr(request, '_query_params')
    except AttributeError:
        pass
    # user = PmsUser.objects.filter(id=1).first()
    count = {}
    if not request.GET._mutable:
        request.GET._mutable = True
    request.GET['all'] = 'true'
    request.GET['status'] = 'approved'
    request.GET['pk__in'] = ids
    request.GET['order_by'] = '-id'
    # request.user = user
    request.user = PmsUser.objects.filter(id=1).first() if not request.user else request.user
    resp = PaymentMasterMainAPIView().get(request)
    _list = list(resp.data['results'])
    count['data_list'] = _list
    if _list and len(_list) > 0:
        to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['procurement-pm-approver-to'],
            level_permission=True,
        ).values_list('user_id',flat=True))
        cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['procurement-pm-approver-cc'],
            level_permission=True,
        ).values_list('user_id',flat=True))            
        if to_users_list and len(to_users_list) > 0:
            def serialize_dates(obj):
                if isinstance(obj, (datetime, date)):
                    return obj.strftime('%d-%m-%Y')  
                elif isinstance(obj, dict):
                    return {k: serialize_dates(v) for k, v in obj.items()}
                elif isinstance(obj, list):
                    return [serialize_dates(item) for item in obj]
                else:
                    return obj
            _list = list(resp.data['results'])
            context = {
                "create_date": datetime.now().strftime('%d-%m-%Y'),
                "data": serialize_dates(_list),
            }
            subject = f"Payment Approved Dated :{datetime.now().strftime('%d-%m-%Y')}"
            try:
                pdf_url = generate_payment_list_pdf(context)
                excel_url = generate_payment_list_excel(context)
            except Exception as e:
                print(f"Failed to generate PDF/Excel for email: {e}")
                return
            attachments = []
            if pdf_url:
                parsed_url = urlparse(pdf_url)
                pdf_path = parsed_url.path.lstrip('/')
                attachments.append(pdf_path)
            if excel_url:
                parsed_url = urlparse(excel_url)
                excel_path = parsed_url.path.lstrip('/')
                attachments.append(excel_path)
            trigger_notifications(
                action='PAYMENT-MASTER-DIR-AUTO-APPROVED',
                subject=subject,
                user_list=to_users_list,
                cc_user_list=cc_users_list,
                attachments=attachments, 
                context=context
            )

def send_payment_master_mudule_approve_update_email(request, ids):
    """
        PMS-Auto Email Format Approval Request (Payment Module:Once the above list gets Final Dir-Approved (Verify| 
        HOD-Approved)
    """
    from .views import PaymentMasterMainAPIView
    request._request.META['QUERY_STRING'] = ''
    request._request.GET = type(request._request.GET)()
    try:
        delattr(request, '_query_params')
    except AttributeError:
        pass
    # user = PmsUser.objects.filter(id=1).first()
    count = {}
    if not request.GET._mutable:
        request.GET._mutable = True
    request.GET['all'] = 'true'
    request.GET['status'] = 'pending'
    request.GET['pk__in'] = ids
    request.GET['order_by'] = '-id'
    # request.user = user
    request.user = PmsUser.objects.filter(id=1).first() if not request.user else request.user
    resp = PaymentMasterMainAPIView().get(request)
    _list = list(resp.data['results'])
    count['data_list'] = _list
    print("HIT EMAIL def ### data list", _list)
    if _list and len(_list) > 0:
        to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id='procurement-pm-to',
            level_permission=True
        ).values_list('user_id', flat=True))   
        cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id='procurement-pm-cc',
            level_permission=True
        ).values_list('user_id', flat=True))
        print("TO users List", to_users_list)
        if to_users_list and len(to_users_list) > 0:
            def serialize_dates(obj):
                if isinstance(obj, (datetime, date)):
                    return obj.strftime('%d-%m-%Y')  
                elif isinstance(obj, dict):
                    return {k: serialize_dates(v) for k, v in obj.items()}
                elif isinstance(obj, list):
                    return [serialize_dates(item) for item in obj]
                else:
                    return obj
            _list = list(resp.data['results'])
            context = {
                "create_date": datetime.now().strftime('%d-%m-%Y'),
                "data": serialize_dates(_list),
            }
            subject = f"Request for Payment Approval Dated :{datetime.now().strftime('%d-%m-%Y')}"
            # try:
            #     pdf_url = generate_payment_list_pdf(context)
            #     excel_url = generate_payment_list_excel(context)
            # except Exception as e:
            #     print(f"Failed to generate PDF/Excel for email: {e}")
                # return
            attachments = []
            # if pdf_url:
            #     parsed_url = urlparse(pdf_url)
            #     pdf_path = parsed_url.path.lstrip('/')
            #     attachments.append(pdf_path)
            # if excel_url:
            #     parsed_url = urlparse(excel_url)
            #     excel_path = parsed_url.path.lstrip('/')
            #     attachments.append(excel_path)
            trigger_notifications(
                action='PAYMENT-MASTER-APPROVED',
                subject=subject,
                user_list=to_users_list,
                cc_user_list=cc_users_list,
                attachments=attachments, 
                context=context
            )


def send_payment_mudule_utr_upadte_email(request, ids):
    """
    PMS-Auto Email Format (Payment Module: Once the same gets updated by Accounts, 
    an auto email should be shared with (To:procurement@shyaminfra.com)
    here Previous Date data is listed.
    """
    if isinstance(ids, int):
        ids = [ids]

    # stage_data = MultiStageSettingStages.cmobjects.filter(
    #     multi_stage_setting__from_name='pm',
    #     multi_stage_setting__is_deleted=False,
    #     multi_stage_setting__is_archived=False,
    # ).values(
    #     'stage',
    #     'stage_name'
    # ).order_by('stage')

    # stage_dict = {item['stage']: item['stage_name'] for item in stage_data}
    # max_stage = max(stage_dict.keys()) if stage_dict else 0

    # status_cases_list = [When(payment_master__current_stage=0, then=Value('Pending'))]
    # for stage in sorted(stage_dict.keys()):
    #     if stage != 0:
    #         status_cases_list.append(
    #             When(payment_master__current_stage=stage, then=Value(stage_dict[stage]))
    #         )
    _list = PaymentMasterUTR.cmobjects.select_related(
        'payment_master',
        'payment_master__vendor',
        'payment_master__site',
        'payment_master__purchase_order',
        'payment_master__cst',
    ).filter(
        pk__in=ids
    ).annotate(
        ref_ref_stage_type=F('payment_master__ref_stage_type'),
        current_status=Case(
            When(payment_master__status='rejected', then=Value('Rejected')),
            When(payment_master__status='cancelled', then=Value('Returned')),
            When(payment_master__status='pending',payment_master__current_stage=0, then=Value('Pending')),
            When(payment_master__status__in=['pending','approved'], then=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(stage=OuterRef('payment_master__current_stage')),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).values('stage_name')[:1],
            )),
            default=F('payment_master__status'),
            output_field=CharField()
        )
        
        # current_status=Case(
        #     When(payment_master__status='rejected', then=Value('Rejected')),
        #     When(payment_master__status='cancelled', then=Value('Returned')),
        #     When(payment_master__status='pending', then=Case(
        #         *status_cases_list,
        #         default=Value(''),
        #         output_field=CharField()
        #     )),
        #     When(payment_master__status='approved', then=Value(stage_dict.get(max_stage, 'Approved'))),
        #     default=F('payment_master__status'),
        #     output_field=CharField()
        # )
    ).values(
        'utr_no', 'utr_date', 'utr_remarks', 'base_amount', 'tds_amount', 'amount',
        'payment_master__request_code',
        'payment_master__vendor__vendor_code',
        'payment_master__vendor__vendor_name',
        'payment_master__site__site_name',
        'payment_master__purpose',
        'payment_master__remarks',
        'payment_master__status',
        'payment_master__amount',
        'payment_master__payment_against',
        'payment_master__payment_no',
        'payment_master__date',
        'payment_master__due_date',
        'payment_master__gst_type',
        'payment_master__purchase_order__sap_code',
        'payment_master__cst__request_code',
        'payment_master__payment_status_type',
        'current_status', 'payment_master__approved_by_date',
    )
    if _list:
        to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['procurement-payment-utr-update-to'],
            level_permission=True,
        ).values_list('user_id', flat=True))
        cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['procurement-payment-utr-update-cc'],
            level_permission=True,
        ).values_list('user_id', flat=True))    
        if to_users_list:
            context = {
                "data": list(_list),
                "current_date": datetime.now().strftime('%d-%m-%Y'),
            }
            subject = f"UTR Details Updated, Dated: {datetime.now().strftime('%d-%m-%Y')}"
            trigger_notifications(
                action='PAYMENT-MASTER-UTR-UPDATE-AUTO-EMAIL',
                subject=subject,
                user_list=to_users_list,
                cc_user_list=cc_users_list,
                context=context
            )

def mark_po_delivered(id):
    status_of_order = ProcurementStatusOfOrder.cmobjects.filter(delivered=True).first()
    PurchaseOrderItems.cmobjects.filter(pk=id).update(status_of_order=status_of_order,tracker_code='GR')


def filters_to_expression(filters,ret_type='str'):
    expressions = []
    for f in filters:
        expressions.append(f"{f['field']}{f['operands']}{f['options']}")
    return " and ".join(expressions) if ret_type=='str' else expressions


def check_overlapping_conditions(target_list,ref_list):
    resp = False
    subset_list = set(ref_list).issubset(target_list)
    if not subset_list:
        remainder_list = set(target_list)-set(ref_list)
        resp = True if not remainder_list else False
    else:
        resp = True
    return resp


def procurement_multi_stages_update_check(validated_data,instance):
    flag = False
    links = instance._meta.related_objects
    total_count = 0
    for relation in links:
        if not relation.related_model._meta.object_name.startswith(instance._meta.object_name):
            search = { relation.field.name: instance.id,'is_deleted': False}
            total_count += relation.related_model.objects.filter(**search).count()
    # print(total_count)
    if total_count > 0:
        old_site_list = [site_data.id for site_data in instance.site.all()]
        new_site_list = validated_data['site_ids']
        old_stage_list = [stage_data.stage for stage_data in instance.procurement_multi_stage_setting_stages.all()]
        new_stage_list = [stage_data['stage'] for stage_data in validated_data['procurement_multi_stage_setting_stages']]
        old_condition_list = filters_to_expression(instance.conditions if instance.conditions else [],'list')
        new_condition_list = filters_to_expression(validated_data['conditions'] if validated_data['conditions'] else [],'list')
        # print(old_site_list)
        # print(new_site_list)
        # print(old_stage_list)
        # print(new_stage_list)
        # print(old_condition_list)
        # print(new_condition_list)
        if (list(set(old_site_list) - set(new_site_list)) or (not Counter(old_stage_list) == Counter(new_stage_list)) or (not Counter(old_condition_list) == Counter(new_condition_list))):
            flag = True
    return flag


def procurement_duplicate_multi_stages(validated_data,instance_id=None):
    overlap = []
    if not validated_data['from_name'] == 'old':
        ref_site = validated_data['site_ids']
        ref_conditions = filters_to_expression(validated_data['conditions'] if validated_data['conditions'] else [],'list')
        # print('ref_site --> ',ref_site)
        # print('ref_conditions --> ',ref_conditions)
        rest_multi_list = MultiStageSetting.cmobjects.filter(
            site__in=ref_site,
            from_name=validated_data['from_name'],
            is_archived=False,
        ).distinct()
        if instance_id:
            rest_multi_list = rest_multi_list.exclude(pk=instance_id)
        for multi_stage_setting in rest_multi_list:
            conditions = filters_to_expression(multi_stage_setting.conditions if multi_stage_setting.conditions else [],'list')
            # print('conditions --> ',conditions)
            overlapping_conditions = check_overlapping_conditions(ref_conditions,conditions)
            # print('overlapping_conditions --> ',overlapping_conditions)
            if overlapping_conditions:
                overlap.append({
                    'id': multi_stage_setting.id,
                    'multi_stage_name': multi_stage_setting.multi_stage_name,
                })
    # print('overlap --> ',overlap)
    return overlap


def set_ref_stage_type_instance(instance,from_name):
    if not instance.ref_stage_type:
        result = []
        ref_id = None
        multi_stage_setting_list = MultiStageSetting.cmobjects.filter(
            Q(site=instance.site.id),
            Q(from_name=from_name),
            Q(is_archived=False),
        )
        for multi_stage_setting in multi_stage_setting_list:
            conditions = filters_to_expression(multi_stage_setting.conditions)
            print('CONDITION -> ',multi_stage_setting.id,conditions)
            # print(instance.is_budgeted,instance.quotation_selected,instance.saving_amount)
            if conditions:
                if eval(conditions):
                    result.append(multi_stage_setting.multi_stage_name)
                    ref_id = multi_stage_setting.id
            else:
                result.append(multi_stage_setting.multi_stage_name)
                ref_id = multi_stage_setting.id
        print('RESULT -> ',result)
        # print('FORM NAME -> ',instance.ref_from_name)
        if ref_id:
            instance.ref_stage_type_id = ref_id
            instance.save()

def mark_cst_ref_stage_type(instance):
    if not instance.ref_stage_type:
        annot = {}
        part_keys = {
            'packing_forwarding_by_cst': ["Packing & Forwarding"],
            'transportaion_charges_by_cst': ["Transportation Charges"],
            'other_charges_by_cst': ["Royalty Expenses", "Other Charges"],
        }
        for part_key,part_value in part_keys.items():
            annot['total_'+part_key] = Coalesce(Sum(Cast(
                F(part_key),
                output_field=FloatField()
            ),output_field=FloatField()),Value(0.0),output_field=FloatField())
        _list = CST.cmobjects.select_related('organization','site','store','project','financialyear','previous_version',
            'material_request','indent','rfq_vendor','enquiry_at_once','checked_by','cancelled_by','close_by','approved_by','rejected_by')\
            .annotate(
            total_budget_amount = Coalesce(
                Sum(
                    Subquery(
                        QuotationItems.cmobjects.filter(
                            rfq_vendor_item__rfq_vendors_id=OuterRef('rfq_vendor_id'),
                            quotation__is_deleted=False,
                            quotation__latest=True,
                            is_selected_by_cst=True,
                        ).annotate(
                            budget_rate=Coalesce(
                                Subquery(
                                    ProcurementMaterialBudgetBreakdown.cmobjects.filter(
                                        master__requested_material_id=OuterRef('requested_material_id'),
                                        master__project_id=OuterRef('quotation__project_id'),
                                        is_zero_budget=False,
                                        master__is_deleted=False,
                                        entry_date__lte=OuterRef(OuterRef('date')),
                                    )
                                    .order_by('-entry_date')
                                    .values('rate')[:1]
                                ),
                                Value(0.0),
                                output_field=FloatField()
                            ),
                            total_item_amount=Cast(
                                F('budget_rate') * F('quantity_by_cst'),
                                output_field=FloatField()
                            )
                        )
                        .values('rfq_vendor_item__rfq_vendors_id')
                        .annotate(total_item_amount=Coalesce(
                            Sum('total_item_amount'),
                            Value(0.0),
                            output_field=FloatField()
                        ))
                        .values('total_item_amount'),
                        output_field=FloatField()
                    )
                ),
                Value(0.0),
                output_field=FloatField()
            ),
            quotation_selected = Exists(Subquery(QuotationItems.cmobjects.filter(
                rfq_vendor_item__rfq_vendors_id=OuterRef('rfq_vendor_id'),
                quotation__is_deleted=False,
                quotation__latest=True,
                is_selected_by_cst=True,
                ).values('rfq_vendor_item__rfq_vendors_id')),
                output_field=BooleanField()
            ),
            total_item_amount = Coalesce(Sum(Subquery(QuotationItems.cmobjects.filter(
                rfq_vendor_item__rfq_vendors_id=OuterRef('rfq_vendor_id'),
                quotation__is_deleted=False,
                quotation__latest=True,
                is_selected_by_cst=True,
                ).values('rfq_vendor_item__rfq_vendors_id').annotate(
                total_item_amount=Coalesce(Sum(Cast(
                    F('rate') * F('quantity_by_cst') *(Value(1.0) - (F('disc_percentage') / Value(100.0))),
                    output_field=FloatField()
                ),output_field=FloatField()),Value(0.0),output_field=FloatField())
                ).values('total_item_amount'),
                output_field=FloatField())),Value(0.0),output_field=FloatField()
            ),
            total_expense_amount = Coalesce(Sum(Subquery(
                    Quotation.cmobjects.filter(
                        rfq_vendor_id=OuterRef('rfq_vendor_id'),
                        latest=True,
                        pk__in=Subquery(
                            QuotationItems.cmobjects.filter(
                                rfq_vendor_item__rfq_vendors_id=OuterRef(OuterRef("rfq_vendor_id")),
                                quotation__is_deleted=False,
                                quotation__latest=True,
                                is_selected_by_cst=True,
                            ).values_list('quotation_id', flat=True)
                        )
                    ).values('rfq_vendor_id')
                    .annotate(
                        **annot,
                        total_expense_sum=F('total_packing_forwarding_by_cst') +
                                        F('total_transportaion_charges_by_cst') +
                                        F('total_other_charges_by_cst')
                    ).values('total_expense_sum'),
                    output_field=FloatField()
                )),Value(0.0),output_field=FloatField()
            ),
            saving_amount = F('total_budget_amount') - (F('total_item_amount') + F('total_expense_amount')),
            ref_from_name = Case(
                When(Q(is_budgeted=False), then=Value('cst_nb')),
                When(Q(Q(is_budgeted=True),Q(quotation_selected=True),Q(saving_amount__gte=0)), then=Value('cst')),
                When(Q(Q(is_budgeted=True),Q(quotation_selected=True),Q(saving_amount__lt=0)), then=Value('cst_ob')),
                default=Value(None),
                output_field=CharField()
            )
        ).filter(pk=instance.id).values('pk','site_id','is_budgeted','quotation_selected','total_budget_amount','total_item_amount','total_expense_amount','saving_amount','ref_from_name')
        for entry in _list:
            print(entry)
            for entry_key,entry_val in entry.items():
                setattr(instance, entry_key, entry_val)
            set_ref_stage_type_instance(instance,'cst')

def mark_pnmcst_ref_stage_type(instance):
    if not instance.ref_stage_type:
        annot = {}
        part_keys = {
            'packing_forwarding_by_cst': ["Packing & Forwarding"],
            'transportaion_charges_by_cst': ["Transportation Charges"],
            'other_charges_by_cst': ["Royalty Expenses", "Other Charges"],
        }
        for part_key,part_value in part_keys.items():
            annot['total_'+part_key] = Coalesce(Sum(Cast(
                F(part_key),
                output_field=FloatField()
            ),output_field=FloatField()),Value(0.0),output_field=FloatField())
        _list = PlantMachineryCST.cmobjects.annotate(
            total_budget_amount = Coalesce(Sum(Subquery(
                PlantMachineryQuotationItems.cmobjects.filter(
                    plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                    plant_machinery_quotation__is_deleted=False,
                    plant_machinery_quotation__latest=True,
                    is_selected_by_cst=True,
                ).annotate(
                    total_budget_value=Coalesce(
                        Subquery(
                            PlantMachineryMachineBudget.cmobjects.filter(
                                project_id=OuterRef(OuterRef('project_id')),
                                plant_machinery_group=OuterRef('plant_machinery_group_id'),
                                budget_master__is_deleted=False,
                                budget_master__from_date__lte=OuterRef(OuterRef('date')),
                                # budget_master__to_date__gte=OuterRef(OuterRef('date')),
                            ).order_by('-budget_master__from_date').values('amount')[:1]
                        ),
                        Value(0.0),
                        output_field=FloatField()
                    ),
                ).values('plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id')
                .annotate(total_item_amount=Coalesce(
                    Sum('total_budget_value'),
                    Value(0.0),
                    output_field=FloatField()
                ))
                .values('total_item_amount'),
                output_field=FloatField())),Value(0.0),output_field=FloatField()
            ),
            total_consumed_amount = Coalesce(Sum(Subquery(
                PlantMachineryQuotationItems.cmobjects.filter(
                    plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                    plant_machinery_quotation__is_deleted=False,
                    plant_machinery_quotation__latest=True,
                    is_selected_by_cst=True,
                ).values('plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id').annotate(
                    total_consumed_value=Coalesce(Sum(
                        Subquery(
                            PlantMachineryLogBook.cmobjects.exclude(in_service='Breakdown').filter(
                                project_id=OuterRef(OuterRef('project_id')),
                                plant_machinery_machine__is_deleted=False,
                                plant_machinery_machine__plant_machinery_group__is_deleted=False,
                                plant_machinery_machine__plant_machinery_group_id=OuterRef('plant_machinery_group_id'),
                                log_book_date__lte=OuterRef(OuterRef('date')),
                            ).values('plant_machinery_machine__plant_machinery_group_id').annotate(
                                total_depreciation_cost_owned=Coalesce(Sum(
                                    Subquery(
                                        PlantMachineryMachineDepreciation.cmobjects.filter(
                                            date__lte=OuterRef('log_book_date'),
                                            to_date__gte=OuterRef('log_book_date'),
                                            plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                            plant_machinery_machine__owner_type='owned'
                                        ).values('plant_machinery_machine_id',).annotate(value=Avg('amount')).values('value')[:1]
                                    ),output_field=FloatField()),
                                    Value(0), output_field=FloatField()
                                ),
                                total_actual_cost_hired=Coalesce(Sum(
                                    Subquery(
                                        PlantMachineryMachineRent.cmobjects.filter(
                                            rent_date__lte=OuterRef('log_book_date'),
                                            rent_to_date__gte=OuterRef('log_book_date'),
                                            plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                            plant_machinery_machine__owner_type='hired'
                                        ).values('plant_machinery_machine_id',).annotate(value=Avg('rent_amount')).values('value')[:1]
                                    ),output_field=FloatField()),
                                    Value(0), output_field=FloatField()
                                ),
                                consumed_value=F('total_depreciation_cost_owned') + F('total_actual_cost_hired'),
                            ).values('consumed_value')
                        ),output_field=FloatField()),
                        Value(0), output_field=FloatField()
                    ),
                )
                .values('total_consumed_value'),
                output_field=FloatField())),Value(0.0),output_field=FloatField()
            ),
            quotation_selected = Exists(Subquery(PlantMachineryQuotationItems.cmobjects.filter(
                plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                plant_machinery_quotation__is_deleted=False,
                plant_machinery_quotation__latest=True,
                is_selected_by_cst=True,
                ).values('plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id')),
                output_field=BooleanField()
            ),
            total_item_amount = Coalesce(Sum(Subquery(PlantMachineryQuotationItems.cmobjects.filter(
                plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                plant_machinery_quotation__is_deleted=False,
                plant_machinery_quotation__latest=True,
                is_selected_by_cst=True,
                ).values('plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id').annotate(
                total_item_amount=Coalesce(Sum(Cast(
                    F('rate') * F('quantity_by_cst') * (Value(1.0) - (F('disc_percentage') / Value(100.0))),
                    output_field=FloatField()
                ),output_field=FloatField()),Value(0.0),output_field=FloatField())
                ).values('total_item_amount'),
                output_field=FloatField())),Value(0.0),output_field=FloatField()
            ),
            total_quantity = Coalesce(Sum(Subquery(PlantMachineryQuotationItems.cmobjects.filter(
                plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                plant_machinery_quotation__is_deleted=False,
                plant_machinery_quotation__latest=True,
                is_selected_by_cst=True,
                ).values('plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id').annotate(
                value=Coalesce(Sum(Cast(
                    F('quantity_by_cst'),
                    output_field=FloatField()
                ),output_field=FloatField()),Value(0.0),output_field=FloatField())
                ).values('value'),
                output_field=FloatField())),Value(0.0),output_field=FloatField()
            ),
            total_required_duration = Coalesce(Sum(Subquery(PlantMachineryQuotationItems.cmobjects.filter(
                plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                plant_machinery_quotation__is_deleted=False,
                plant_machinery_quotation__latest=True,
                is_selected_by_cst=True,
                ).values('plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id').annotate(
                value=Coalesce(Sum(Cast(
                    F('plant_machinery_quotation__required_duration'),
                    output_field=FloatField()
                ),output_field=FloatField()),Value(0.0),output_field=FloatField())
                ).values('value'),
                output_field=FloatField())),Value(0.0),output_field=FloatField()
            ),
            total_expense_amount = Coalesce(Sum(Subquery(
                    PlantMachineryQuotation.cmobjects.filter(
                        plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                        latest=True,
                        pk__in=Subquery(
                            PlantMachineryQuotationItems.cmobjects.filter(
                                plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef(OuterRef("plant_machinery_rfq_vendor_id")),
                                plant_machinery_quotation__is_deleted=False,
                                plant_machinery_quotation__latest=True,
                                is_selected_by_cst=True,
                            ).values_list('plant_machinery_quotation_id', flat=True)
                        )
                    ).values('plant_machinery_rfq_vendor_id')
                    .annotate(
                        **annot,
                        total_expense_sum=F('total_packing_forwarding_by_cst') +
                                        F('total_transportaion_charges_by_cst') +
                                        F('total_other_charges_by_cst')
                    ).values('total_expense_sum'),
                    output_field=FloatField()
                )),Value(0.0),output_field=FloatField()
            ),
            saving_amount = (F('total_budget_amount') - F('total_consumed_amount')) - ((F('total_item_amount') * F('total_required_duration')) + (F('total_expense_amount') * F('total_quantity'))),
            ref_from_name = Case(
                When(Q(is_budgeted=False), then=Value('pnmcst_nb')),
                When(Q(Q(is_budgeted=True),Q(quotation_selected=True),Q(saving_amount__gte=0)), then=Value('pnmcst')),
                When(Q(Q(is_budgeted=True),Q(quotation_selected=True),Q(saving_amount__lt=0)), then=Value('pnmcst_ob')),
                default=Value(None),
                output_field=CharField()
            )
        ).filter(pk=instance.id).values('pk','site_id','is_budgeted','quotation_selected','total_budget_amount','total_consumed_amount','total_item_amount','total_required_duration','total_expense_amount','total_quantity','saving_amount','ref_from_name')
        for entry in _list:
            print(entry)
            for entry_key,entry_val in entry.items():
                setattr(instance, entry_key, entry_val)
            set_ref_stage_type_instance(instance,'pnmcst')

def multi_stage_status_details(instance, multi_stage_details, begin_status='pending'):
    status_details = {'current_status': '','target_status': '','current_user': '','multi_stage_max_stage': (max(d['procurement_multi_stage_setting_stages__stage'] for d in multi_stage_details) if multi_stage_details else 0)}
    begin_status_disp = 'Pending'
    begin_status_user = instance.created_by
    if begin_status == 'checked':
        begin_status_disp = 'Checked'
        if instance.status == 'pending':
            status_details['current_status'] = 'Pending'
            status_details['target_status'] = 'Checked'
            if instance.created_by:
                status_details['current_user'] = instance.created_by.user_full_name
    if instance.status in [begin_status,'approved']:
        if instance.current_stage == 0:
            status_details['current_status'] = begin_status_disp
            if begin_status_user:
                status_details['current_user'] = begin_status_user.user_full_name
        else:
            for value in multi_stage_details.iterator():
                if int(value['procurement_multi_stage_setting_stages__stage']) == int(instance.current_stage):
                    status_details['current_status'] = value['procurement_multi_stage_setting_stages__stage_name']
                    status_details['current_user'] = value['procurement_multi_stage_setting_stages__employee__first_name'] + ' ' + value['procurement_multi_stage_setting_stages__employee__last_name']
        for value in multi_stage_details.iterator():
            if int(value['procurement_multi_stage_setting_stages__stage']) == (int(instance.current_stage)+1):
                status_details['target_status'] = value['procurement_multi_stage_setting_stages__stage_name']
    elif not instance.status == 'pending':
        status_details['current_status'] = 'Returned' if instance.status=='cancelled' else 'Rejected' if instance.status=='rejected' else instance.status
        if getattr(instance, instance.status+'_by'):
            status_details['current_user'] = getattr(instance, instance.status+'_by').user_full_name
    return status_details

def multi_stage_stage_details(instance):
    details = []
    ref_stage_type = instance.ref_stage_type.id if instance.ref_stage_type else None
    if instance.site and instance.organization:
        multi_stage_staging_filter = {
            'site': instance.site_id,
            'organization': instance.organization_id,
            'procurement_multi_stage_setting_stages__is_deleted': False,
            'pk': ref_stage_type,
        }
        # if ref_stage_type:
        #     multi_stage_staging_filter['pk'] = ref_stage_type
        # else:
        #     multi_stage_staging_filter['from_name'] = ref_multi_stage_type
        details = MultiStageSetting.cmobjects.filter(**multi_stage_staging_filter).order_by('procurement_multi_stage_setting_stages__stage').values(
            'procurement_multi_stage_setting_stages__stage',
            'procurement_multi_stage_setting_stages__stage_name',
            'procurement_multi_stage_setting_stages__employee',
            'procurement_multi_stage_setting_stages__employee__first_name',
            'procurement_multi_stage_setting_stages__employee__last_name',
            'procurement_multi_stage_setting_stages__remarks_required',
        )
    return details

    