### User permission info (modulepermissionsmaster, userwisemodulepermissions, submenumaster, userwisesubmodulepermissions)
| Serial Number | Permission Name                | Details          | 
|---------------|--------------------------------|------------------|
| 1             | procurement-mr-viewer          |                  |
| 2             | procurement-mr-approver        |                  |
| 3             | procurement-mr-editor          |                  |
| 4             | procurement-indent-approver    |                  |
| 5             | procurement-indent-editor      |                  |
| 6             | procurement-po-approver        |                  |
| 7             | procurement-po-editor          |                  |
| 8             | procurement-quotation-approver |                  |
| 9             | procurement-quotation-editor   |                  |
| 10            | procurement-grn-approver       |                  |
| 11            | procurement-grn-editor         |                  |
|               | procurement-site-manager       | will be removed  |


### mail/cron info using `call_command` [dev]

```bash

# (dev)cron log file -> /var/log/pms_cron_job.log 
*/5 * * * * /var/www/html/pms_venv/bin/python /var/www/html/pms_dev_backend/pms_api/manage.py send_email_notifications >> /var/log/pms_cron_job.log 2>&1

# (uat)cron log file -> /var/log/pms_cron_job.log
*/5 * * * * /var/www/html/pms_venv/bin/python /var/www/html/uat/pms-api/manage.py send_email_notifications >> /var/log/pms_cron_job.log 2>&1

30 0 * * * /var/www/html/pms_venv/bin/python /var/www/html/pms_dev_backend/pms_api/manage.py fetch_hsn_codes >> /var/log/pms_cron_job.log 2>&1 


```


### Cron tab info:
```bash
# https://blog.devgenius.io/cron-job-in-django-with-django-crontab-c02bff68a96d 
# 1
pip install django-crontab

# 2
#INSTALLED_APPS = [
#‘django_crontab’,
#…
#]

# 3
#For this example let’s assume our file is myapp/cron.py.
#def my_cron_job():
#     # your logic

# 4
#CRONJOBS = [
#(‘*/2 * * * *’, ‘myapp.cron.my_cron_job’)
#]

#5
python manage.py crontab add

python manage.py crontab show

python manage.py crontab remove

```