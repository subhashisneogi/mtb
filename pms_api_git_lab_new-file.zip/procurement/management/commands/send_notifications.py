from django.core.management.base import BaseCommand

from email_config.models import EmailSend,SMSSend,PushSend
from administrations.utils import send_generic_mail,send_generic_sms,send_generic_push
from concurrent.futures import ThreadPoolExecutor
from django.db.models import Q
from django.db import transaction

class Command(BaseCommand):
    help = 'Send unsent Notifications'
    type_map = {
        0: [EmailSend,send_generic_mail,'to_email'],
        1: [SMSSend,send_generic_sms,'to_number'],
        2: [PushSend,send_generic_push,None],
    }
    
    def add_arguments(self, parser):
        parser.add_argument(
            '-t', '--type', default=1,
            type=int, choices=self.type_map.keys(),
            help='Type of notification to trigger: 0=>email 1=>sms 2=>push',
        )

    def handle(self, *args, **options):
        if options['type'] in self.type_map:
            resp = []
            search = [
                Q(is_sent=False),
                Q(template__is_active_trigger=True),
                Q(tried_count__lt=3),
            ]
            if self.type_map[options['type']][2]:
                search.append(eval(f"~(Q({self.type_map[options['type']][2]}=None) | Q({self.type_map[options['type']][2]}=''))"))
            # unsent_instance = self.type_map[options['type']][0].objects.filter(*search)

            with transaction.atomic():
                unsent_instance = (
                    self.type_map[options['type']][0]
                    .objects.select_for_update(skip_locked=True)
                    .filter(*search)
                )
                with ThreadPoolExecutor(max_workers=1) as executor:
                    futures = [
                        executor.submit(
                            self.type_map[options['type']][1],
                            instance=instance,
                        )
                        for instance in unsent_instance
                    ]
                for future, instance in zip(futures, unsent_instance):
                    try:
                        result = future.result()
                        if result:
                            resp.append(instance.id)
                            instance.is_sent = True
                        instance.tried_count = instance.tried_count + 1
                        instance.save()
                    except Exception as e:
                        self.stdout.write(self.style.ERROR(f"Error: {e}"))
     
# class Command(BaseCommand):
#     help = 'Send unsent Notifications'
#     type_map = {
#         0: [EmailSend,send_generic_mail,'to_email'],
#         1: [SMSSend,send_generic_sms,'to_number'],
#         2: [PushSend,send_generic_push,None],
#     }
    
#     def add_arguments(self, parser):
#         parser.add_argument(
#             '-t', '--type', default=1,
#             type=int, choices=self.type_map.keys(),
#             help='Type of notification to trigger: 0=>email 1=>sms 2=>push',
#         )

#     def handle(self, *args, **options):
#         if options['type'] in self.type_map:
#             resp = []
#             search = [
#                 Q(is_sent=False),
#                 Q(template__is_active_trigger=True),
#                 Q(tried_count__lt=3),
#             ]
#             if self.type_map[options['type']][2]:
#                 search.append(eval(f"~(Q({self.type_map[options['type']][2]}=None) | Q({self.type_map[options['type']][2]}=''))"))
#             unsent_instance = self.type_map[options['type']][0].objects.filter(*search)

#             with ThreadPoolExecutor(max_workers=1) as executor:
#                 futures = [
#                     executor.submit(
#                         self.type_map[options['type']][1],
#                         instance=instance,
#                     )
#                     for instance in unsent_instance
#                 ]

#             for future, instance in zip(futures, unsent_instance):
#                 try:
#                     result = future.result()
#                     if result:
#                         resp.append(instance.id)
#                         instance.is_sent = True
#                     instance.tried_count = instance.tried_count + 1
#                     instance.save()
#                 except Exception as e:
#                     self.stdout.write(self.style.ERROR(f"Error: {e}"))

#             self.stdout.write(self.style.SUCCESS(f"{options['type']} sending task submitted --> {resp}"))
#         else:
#             self.stdout.write(self.style.ERROR(f"Invalid Type: {options['type']}"))

