from django.core.management.base import BaseCommand

import requests
from bs4 import BeautifulSoup
import unicodedata
from datetime import datetime
from material_master.models import HSNMaster


class Command(BaseCommand):
    help = 'Update HSN records'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS(f"{datetime.now().strftime('%d-%m-%Y %H:%M:%S')} :: Update HSN records start"))
        try:
            url = "https://cbic-gst.gov.in/gst-goods-services-rates.html"
            r = requests.post(url)
            parsed_html = BeautifulSoup(r.text,features="html.parser")
            table = parsed_html.body.find('table', attrs={'id':'goods_table'})
            table_body = table.find('tbody')
            for tr in table_body.find_all('tr'):
                if len(tr.find_all('td')) == 8:
                    temp = []
                    for td in tr.find_all('td'):
                        temp.append(unicodedata.normalize("NFKD",td.text.strip()))
                    if(temp[4] != '' and temp[5] != '' and temp[6] != ''):
                        obj, created = HSNMaster.objects.update_or_create(
                            schedule=temp[0],s_no=temp[1],hsn_code=temp[2],
                            defaults={'schedule': temp[0],
                                    's_no': temp[1],
                                    'hsn_code': temp[2],
                                    'cgst_percentage': temp[4].replace('%', ''),
                                    'sgst_percentage': temp[5].replace('%', ''),
                                    'igst_percentage': temp[6].replace('%', ''),
                                    'details': temp[3],},
                        )
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"{datetime.now().strftime('%d-%m-%Y %H:%M:%S')} :: HSN Error: {e}"))

        self.stdout.write(self.style.SUCCESS(f"{datetime.now().strftime('%d-%m-%Y %H:%M:%S')} :: Update HSN records done"))