from rest_framework import serializers
from .models import *









class  SiteParticularsListSerializer(serializers.ModelSerializer):
    """ Add Site particular list serizalizer"""
    class Meta:
        model = SiteParticularsList
        fields = '__all__'

class  OwnedMachineryListSerializer(serializers.ModelSerializer):
    """ Add Owned machinery list serizalizer"""
    class Meta:
        model = OwnedMachineryList
        fields = '__all__'



