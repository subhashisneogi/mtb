from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from .models import *
from adminpanel.models import SiteLocation
# Register your models here.

@admin.register(SiteParticularsList)
class SiteParticularsList(ModelAdmin):
    list_display = ['id', 'organization','code','machinery', 'particulars','site_assigned', 'policy_number','period_of_policy','premium_amount','invoice_number']
    search_fields = ('machinery', 'site_assigned','policy_number','period_of_policy','invoice_number')
@admin.register(OwnedMachineryList)
class OwnedMachineryList(ModelAdmin):
    list_display = ['id', 'organization','code','machinery', 'registration_number','site_assigned', 'policy_number','period_of_policy','premium_amount','invoice_number']
    search_fields = ('machinery', 'site_assigned','policy_number','period_of_policy','invoice_number')