from django.urls import path
from insurance import views


urlpatterns = [
    path('insurance-site/', views.SiteParticularsListAPIView.as_view()),
    path('insurance-owned/', views.OwnedMachineryListAPIView.as_view()),


]