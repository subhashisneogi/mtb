
# Create your models here.
from django.db import models

from administrations.models import Organization, BaseAbstractStructure
from adminpanel.models import SiteLocation
# Create your models here.




class SiteParticularsList(BaseAbstractStructure):
    """
       Site Perticulars List Model
    """

    organization = models.ForeignKey(Organization, related_name='site_particular_organization',on_delete=models.CASCADE, blank=True, null=True)
    code = models.CharField(max_length=200,blank=True, null=True)
    machinery = models.CharField(max_length=200,blank=True, null=True)
    particulars	 = models.CharField(max_length=200,blank=True, null=True)
    site_assigned = models.ForeignKey(SiteLocation, related_name='site_particular_site_location',on_delete=models.CASCADE, blank=True, null=True)
    policy_number=models.CharField(max_length=200,blank=True, null=True)
    period_of_policy=models.DateTimeField(blank=True, null=True)
    premium_amount=models.FloatField(blank=True, null=True)
    insurer_company = models.CharField(max_length=200,blank=True, null=True)
    policy_due_date=models.DateTimeField(blank=True, null=True)
    invoice_number=models.CharField(max_length=200,blank=True, null=True)
    sum_insured=models.FloatField(blank=True, null=True)


    def __str__(self):
        return self.code


class OwnedMachineryList(BaseAbstractStructure):
    """
       Owned Machinery List Model
    """

    organization = models.ForeignKey(Organization, related_name='owned_machinery_organization',on_delete=models.CASCADE, blank=True, null=True)
    code = models.CharField(max_length=200,blank=True, null=True)
    machinery = models.CharField(max_length=200,blank=True, null=True)
    registration_number	 = models.CharField(max_length=200,blank=True, null=True)
    site_assigned = models.ForeignKey(SiteLocation, related_name='owned_machinery_site_location',on_delete=models.CASCADE, blank=True, null=True)
    policy_number=models.CharField(max_length=200,blank=True, null=True)
    period_of_policy=models.DateTimeField(blank=True, null=True)
    premium_amount=models.FloatField(blank=True, null=True)
    insurer_company = models.CharField(max_length=200,blank=True, null=True)
    policy_due_date=models.DateTimeField(blank=True, null=True)
    invoice_number=models.CharField(max_length=200,blank=True, null=True)
    sum_insured=models.FloatField(blank=True, null=True)


    def __str__(self):
        return self.code



    
    