from django.shortcuts import render
from adminpanel.models import *
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException

from .models import *
from .serializers import *
from django.db.models import Q
# Create your views here.
class SiteParticularsListAPIView(APIView):
    
    

    queryset = SiteParticularsList.objects.filter(is_deleted=False)
    serializer_class = SiteParticularsListSerializer

    def get_queryset(self):
        organization = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        site_assigned_id = self.request.query_params.get('site_assigned_id', None)
        policy_due_date_from= self.request.query_params.get('policy_due_date_from', None)
        policy_due_date_to= self.request.query_params.get('policy_due_date_to', None)
        machinery_policy_number= self.request.query_params.get('machinery_policy_number', None)
        field_name = self.request.query_params.get('field_name', None)
        order_by = self.request.query_params.get('order_by', None)
        
        
        # filter = {}
        # if organization:
        #     filter['organization_id'] = organization
        # if id:
        #     filter['id'] = id
        if not field_name:
            sort_field = '-id'
        else:
            if field_name == 'code':
                if order_by == 'asc':
                    sort_field = 'code'
                else:
                    sort_field = '-code'
            if field_name=='machinery':
                if order_by == 'asc':
                    sort_field = "machinery"
                else:
                    sort_field = '-machinery'
            if field_name=='policy_number':
                if order_by == 'asc':
                    sort_field = "policy_number"
                else:
                    sort_field = '-policy_number'   
            if field_name=='premium_amount':
                if order_by == 'asc':
                    sort_field = "premium_amount"
                else:
                    sort_field = '-premium_amount'             

            if field_name=='sum_insured':
                if order_by == 'asc':
                    sort_field = "sum_insured"
                else:
                    sort_field = '-sum_insured'
        # print(**filter)
        print(policy_due_date_from,policy_due_date_to)
        if site_assigned_id:
            result = self.queryset.filter(site_assigned__id=site_assigned_id,organization_id=organization).order_by(sort_field)
            print(result)
        elif (policy_due_date_from and policy_due_date_to):
            result = self.queryset.filter(policy_due_date__range=[policy_due_date_from,policy_due_date_to],organization_id=organization).order_by(sort_field) 
            print(result)
        elif machinery_policy_number :
            result = self.queryset.filter((Q(machinery__icontains=machinery_policy_number)|\
         
                                            Q(policy_number__icontains=machinery_policy_number)),organization_id=organization).order_by(sort_field)
        
        else:
            result = self.queryset.filter(organization_id=organization).order_by(sort_field)
        return result


    def get(self, request, *args, **kwargs):
        """
        Get a list of all site particulars
        """
     

        organization_id = self.request.query_params.get('organization_id', None)
        # site_list = SiteParticularsList.cmobjects.filter(organization_id = organization_id).order_by('-id')
     
        queryset = self.get_queryset()
        print(queryset)

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = SiteParticularsListSerializer(queryset, many=True)
       
        
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)
            code = request.data.get('code', None)
            machinery = request.data.get('machinery', None)
            particulars	 = request.data.get('particulars', None)
            site_assigned_id= request.data.get('site_assigned', None)
            policy_number = request.data.get('policy_number', None)
            period_of_policy = request.data.get('period_of_policy', None)
            premium_amount = request.data.get('premium_amount', None)
            insurer_company = request.data.get('insurer_company', None)
            policy_due_date = request.data.get('policy_due_date', None)
            invoice_number = request.data.get('invoice_number', None)
            sum_insured = request.data.get('sum_insured', None)
         
          


            with transaction.atomic(): 

                if SiteParticularsList.cmobjects.filter(code=code.strip(),          # validate existing tender name
                            organization_id=organization_id, ).exists():
                    raise APIException({'request_status': 0, 'msg': "Site with same code is already exist "})
                
                created = SiteParticularsList.objects.create(organization_id=organization_id, code = code, machinery=machinery, particulars=particulars, \
                                                    site_assigned_id=site_assigned_id, policy_number=policy_number, period_of_policy=period_of_policy,\
                                                        premium_amount=premium_amount, insurer_company=insurer_company, policy_due_date=policy_due_date, \
                                                            invoice_number=invoice_number,sum_insured=sum_insured, created_by=request.user)
                created.save()

           

                serializer = SiteParticularsListSerializer(created)

                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Site Particular List Added SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        # code = request.data.get('code', None)


        with transaction.atomic():
            if method.lower() == 'edit':
                machinery = request.data.get('machinery', None)
                particulars	 = request.data.get('particulars', None)
                site_assigned_id= request.data.get('site_assigned', None)
                policy_number = request.data.get('policy_number', None)
                period_of_policy = request.data.get('period_of_policy', None)
                premium_amount = request.data.get('premium_amount', None)
                insurer_company = request.data.get('insurer_company', None)
                policy_due_date = request.data.get('policy_due_date', None)
                invoice_number = request.data.get('invoice_number', None)
                sum_insured = request.data.get('sum_insured', None)

                site_details = SiteParticularsList.cmobjects.filter(pk=id).first()


             
                
                if not site_details:
                    return Response({'results': [],
                                    'msg': "Selected Site Particular Does'nt exists!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                
                # if SiteParticularsList.cmobjects.filter(code=code.strip(),          # validate existing tender name
                #             organization_id=organization_id, ).exclude(\
                #                 code=site_details.code.strip()).exists():
                #     raise APIException("site with  same code already exist ")
         


                site = SiteParticularsList.cmobjects.filter(id=id).first()

                # serializer = SiteParticularsListSerializer(site)
                update=SiteParticularsList.cmobjects.filter(id=id, organization=organization_id)\
                    .update(machinery=machinery, particulars=particulars, \
                                                    site_assigned_id=site_assigned_id, policy_number=policy_number, period_of_policy=period_of_policy,\
                                                        premium_amount=premium_amount, insurer_company=insurer_company, policy_due_date=policy_due_date, \
                                                            invoice_number=invoice_number,sum_insured=sum_insured,updated_by=request.user)
                return Response({'results':{
                                        'Data':SiteParticularsList.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Site Particulars  Updated SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
            
            elif method.lower() == 'delete':
                """
                Delete a Site Particular
                """
                if SiteParticularsList.cmobjects.filter(id=id, organization_id=organization_id).exists():
                    site_details = SiteParticularsList.cmobjects.filter(id=id, organization=organization_id).first()
                    site_details.is_deleted = True
                    site_details.save()
                    
                    return Response({'results':{
                                        'form_details':SiteParticularsList.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Selected Site or Code Particulars Deleted Successfully',
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Selected Site or Code Does'nt exists!",
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
                

class OwnedMachineryListAPIView(APIView):
    
    

    queryset = OwnedMachineryList.objects.filter(is_deleted=False)
    serializer_class = OwnedMachineryListSerializer

    def get_queryset(self):
        organization = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        site_assigned_id = self.request.query_params.get('site_assigned_id', None)
        policy_due_date_from= self.request.query_params.get('policy_due_date_from', None)
        policy_due_date_to= self.request.query_params.get('policy_due_date_to', None)
        machinery_policy_number= self.request.query_params.get('machinery_policy_number', None)
        field_name = self.request.query_params.get('field_name', None)
        order_by = self.request.query_params.get('order_by', None)
        
        
      
        if not field_name:
            sort_field = '-id'
        else:
            if field_name == 'code':
                if order_by == 'asc':
                    sort_field = 'code'
                else:
                    sort_field = '-code'
            if field_name=='machinery':
                if order_by == 'asc':
                    sort_field = "machinery"
                else:
                    sort_field = '-machinery'
            if field_name=='policy_number':
                if order_by == 'asc':
                    sort_field = "policy_number"
                else:
                    sort_field = '-policy_number'   
            if field_name=='premium_amount':
                if order_by == 'asc':
                    sort_field = "premium_amount"
                else:
                    sort_field = '-premium_amount'             

            if field_name=='sum_insured':
                if order_by == 'asc':
                    sort_field = "sum_insured"
                else:
                    sort_field = '-sum_insured'
        # print(**filter)
        print(policy_due_date_from,policy_due_date_to)
        if site_assigned_id:
            result = self.queryset.filter(site_assigned__id=site_assigned_id,organization_id=organization).order_by(sort_field)
            print(result)
        elif (policy_due_date_from and policy_due_date_to):
            result = self.queryset.filter(policy_due_date__range=[policy_due_date_from,policy_due_date_to],organization_id=organization).order_by(sort_field) 
            print(result)
        elif machinery_policy_number :
            result = self.queryset.filter((Q(machinery__icontains=machinery_policy_number)|\
         
                                            Q(policy_number__icontains=machinery_policy_number)),organization_id=organization).order_by(sort_field)
        
        else:
            result = self.queryset.filter(organization_id=organization).order_by(sort_field)
        return result


    def get(self, request, *args, **kwargs):
        """
        Get a list of all owned machinery
        """
     

        organization_id = self.request.query_params.get('organization_id', None)
        # site_list = SiteParticularsList.cmobjects.filter(organization_id = organization_id).order_by('-id')
     
        queryset = self.get_queryset()
        print(queryset)

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = OwnedMachineryListSerializer(queryset, many=True)
       
        
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)
            code = request.data.get('code', None)
            machinery = request.data.get('machinery', None)
            registration_number	 = request.data.get('registration_number', None)
            site_assigned_id= request.data.get('site_assigned', None)
            policy_number = request.data.get('policy_number', None)
            period_of_policy = request.data.get('period_of_policy', None)
            premium_amount = request.data.get('premium_amount', None)
            insurer_company = request.data.get('insurer_company', None)
            policy_due_date = request.data.get('policy_due_date', None)
            invoice_number = request.data.get('invoice_number', None)
            sum_insured = request.data.get('sum_insured', None)
         
          


            with transaction.atomic(): 

                if OwnedMachineryList.cmobjects.filter(code=code.strip(),          # validate existing tender name
                            organization_id=organization_id, ).exists():
                    raise APIException({'request_status': 0, 'msg': "Owned machinery with same code is already exist "})
                
                created = OwnedMachineryList.objects.create(organization_id=organization_id, code = code, machinery=machinery, registration_number=registration_number, \
                                                    site_assigned_id=site_assigned_id, policy_number=policy_number, period_of_policy=period_of_policy,\
                                                        premium_amount=premium_amount, insurer_company=insurer_company, policy_due_date=policy_due_date, \
                                                            invoice_number=invoice_number,sum_insured=sum_insured, created_by=request.user)
                created.save()

           

                serializer = OwnedMachineryListSerializer(created)

                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Owned Machinery List Added SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        # code = request.data.get('code', None)


        with transaction.atomic():
            if method.lower() == 'edit':
                machinery = request.data.get('machinery', None)
                registration_number	 = request.data.get('registration_number', None)
                site_assigned_id= request.data.get('site_assigned', None)
                policy_number = request.data.get('policy_number', None)
                period_of_policy = request.data.get('period_of_policy', None)
                premium_amount = request.data.get('premium_amount', None)
                insurer_company = request.data.get('insurer_company', None)
                policy_due_date = request.data.get('policy_due_date', None)
                invoice_number = request.data.get('invoice_number', None)
                sum_insured = request.data.get('sum_insured', None)

                machinery_details = OwnedMachineryList.cmobjects.filter(pk=id).first()


             
                
                if not machinery_details:
                    return Response({'results': [],
                                    'msg': "Selected Owned Machinery Does'nt exists!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                
                # if SiteParticularsList.cmobjects.filter(code=code.strip(),          # validate existing tender name
                #             organization_id=organization_id, ).exclude(\
                #                 code=site_details.code.strip()).exists():
                #     raise APIException("site with  same code already exist ")
         


                site = OwnedMachineryList.cmobjects.filter(id=id).first()

                # serializer = SiteParticularsListSerializer(site)
                update=OwnedMachineryList.cmobjects.filter(id=id, organization=organization_id)\
                    .update(machinery=machinery, registration_number=registration_number, \
                                                    site_assigned_id=site_assigned_id, policy_number=policy_number, period_of_policy=period_of_policy,\
                                                        premium_amount=premium_amount, insurer_company=insurer_company, policy_due_date=policy_due_date, \
                                                            invoice_number=invoice_number,sum_insured=sum_insured,updated_by=request.user)
                return Response({'results':{
                                        'Data':OwnedMachineryList.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Owned Machinery  Updated SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
            
            elif method.lower() == 'delete':
                """
                Delete a Owned machinery
                """
                if OwnedMachineryList.cmobjects.filter(id=id, organization_id=organization_id).exists():
                    machinery_details = OwnedMachineryList.cmobjects.filter(id=id, organization=organization_id).first()
                    machinery_details.is_deleted = True
                    machinery_details.save()
                    
                    return Response({'results':{
                                        'form_details':OwnedMachineryList.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Selected Machinery or Code  Deleted Successfully',
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Selected Machinery Does'nt exists!",
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})