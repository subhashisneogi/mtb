from colorama import Back, Style
from django.db.models import FloatField, Value ,OuterRef, Subquery, Sum, Case, When, Value, IntegerField, Count
from django.db.models.functions import Cast , Coalesce
from procurement.helper import GroupConcat
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException
from datetime import date
import pandas as pd
import numpy as np
import json
import re
from tender.helper import str2bool
from tender.models import *
from tender.serializers import *
from .models import *
from .serializers import *
from .helper import *
from procurement.helper import generate_all_code, calculate_quantity_on_uom, custom_filters,get_latest_boq
from plant_machinery.helper import  handle_nan

# Create your views here.
class BOQAPIView(APIView):
    """
    CRUD API for BOQ model
    """
    def get(self, request, format=None):
        """
        Get a list of all BOQ
        """
        check_editor_permissions(request,0)
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        latest = self.request.query_params.get('latest', None)
        order_by = self.request.query_params.get('order', '-id')
        if id:
            boq_details = BOQ.cmobjects.prefetch_related(
                'boq_approval_details_boq',
            ).filter(id=id).first()
            serializer = BOQSerializer(boq_details)
            return Response(serializer.data)
        
        search = custom_filters(self.request, {}, ['latest'])

        boq_list = BOQ.cmobjects.prefetch_related(
            'boq_approval_details_boq',
        ).filter(*search).order_by(*str(order_by).split(","))

        if latest == 'true':
            boq_list = boq_list.first()
            serializer = BOQSerializer(boq_list, many=False)
            return Response({'results': serializer.data})

        if all == 'true':
            serializer = BOQSerializer(boq_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(boq_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BOQSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request, format=None):
        """
        Create a new BOQ
        """
        mismatch_records = None
        replicate_tender = self.request.query_params.get('replicate_tender', None)
        if replicate_tender in [None, '', 'null']: 
            replicate_tender = None
        replicate_boq = self.request.query_params.get('replicate_boq', None)
        replicate_planning_tender = self.request.query_params.get('replicate_planning_tender', None)
        source = self.request.query_params.get('source', '')
        request.data['version'] = int(BOQ.cmobjects.filter(project=request.data['project']).count())+1
        request.data['created_by'] = self.request.user.id
        request.data['parent_tender'] = replicate_tender
        request.data['parent_boq'] = replicate_boq
        request.data['parent_planning_tender'] = replicate_planning_tender
        request.data['source'] = source
        serializer = BOQSerializer(data=request.data)
        approve = 0
        if 'status' in request.data:
            if request.data['status'] != 'pending':
                approve = 1
        check_editor_permissions(request,approve)
        if serializer.is_valid():
            obj=serializer.save()
            # create_boq_chainge(obj.pk, obj.organization.id)
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'mismatch_records': mismatch_records,
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a BOQ
                """
                approve = 0
                if 'status' in request.data:
                    if request.data['status'] != 'pending':
                        approve = 1
                check_editor_permissions(request,approve)
                if BOQ.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                    boq_details = BOQ.cmobjects.filter(pk=id).first()
                    if boq_details.status == "pending" or boq_details.status == "approved":
                        request.data['updated_by_id'] = request.user.id
                        serializer = BOQSerializer(boq_details, data=request.data)

                        if serializer.is_valid():
                            serializer.save()

                            return Response({'results': {
                                            'Data': serializer.data,
                                            },
                                'msg': "Sucessfully updated",
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
                    else:
                        raise APIException({'request_status': 0, 'msg': "BOQ already "+boq_details.status})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a BOQ
                """
                if BOQ.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    boq_details = BOQ.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    approve = 0
                    if 'status' in request.data:
                        if boq_details.status != 'pending':
                            approve = 1
                    check_editor_permissions(request,approve)
                    boq_details.updated_by_id = request.user.id
                    boq_details.is_deleted = True
                    boq_details.save()

                    return Response({'results': {
                        'boq': BOQ.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted BOQ',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class BOQAPIViewBack(APIView):
    """
    CRUD API for BOQ model
    """
    def get(self, request, format=None):
        """
        Get a list of all BOQ
        """
        check_editor_permissions(request,0)
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        latest = self.request.query_params.get('latest', None)
        order_by = self.request.query_params.get('order', '-id')
        if id:
            boq_details = BOQ.cmobjects.prefetch_related(
                'boq_approval_details_boq',
            ).filter(id=id).first()
            serializer = BOQSerializer(boq_details)
            return Response(serializer.data)
        
        search = custom_filters(self.request, {}, ['latest'])

        boq_list = BOQ.cmobjects.prefetch_related(
            'boq_approval_details_boq',
        ).filter(*search).order_by(*str(order_by).split(","))

        if latest == 'true':
            boq_list = boq_list.first()
            serializer = BOQSerializer(boq_list, many=False)
            return Response({'results': serializer.data})

        if all == 'true':
            serializer = BOQSerializer(boq_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(boq_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BOQSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request, format=None):
        """
        Create a new BOQ
        """
        mismatch_records = None
        replicate_tender = self.request.query_params.get('replicate_tender', None)
        if replicate_tender in [None, '', 'null']: 
            replicate_tender = None
        replicate_boq = self.request.query_params.get('replicate_boq', None)
        replicate_planning_tender = self.request.query_params.get('replicate_planning_tender', None)
        source = self.request.query_params.get('source', '')
        request.data['version'] = int(BOQ.cmobjects.filter(project=request.data['project']).count())+1
        request.data['created_by'] = self.request.user.id
        request.data['parent_tender'] = replicate_tender
        request.data['parent_boq'] = replicate_boq
        request.data['parent_planning_tender'] = replicate_planning_tender
        request.data['source'] = source
        serializer = BOQSerializer(data=request.data)
        approve = 0
        if 'status' in request.data:
            if request.data['status'] != 'pending':
                approve = 1
        check_editor_permissions(request,approve)
        if serializer.is_valid():
            serializer.save()
            # if replicate_tender or replicate_boq or replicate_planning_tender:
            if replicate_boq or replicate_planning_tender:
                # Check if more than one field is specified
                specified_fields = [replicate_boq, replicate_tender, replicate_planning_tender]
                specified_count = sum(1 for field in specified_fields if field is not None)
                if specified_count == 0:
                    raise APIException({'request_status': 0, 'msg': "Either boq or tender or planning_tender must be specified."})
                elif specified_count > 1:
                    raise APIException({'request_status': 0, 'msg': "Only one of boq, tender, or planning_tender can be specified."})
                # if replicate_tender is not None and replicate_boq is not None:
                #     raise APIException({'request_status': 0, 'msg': "Both boq and tender cannot be specified simultaneously."})
                boq_id = serializer.data['id']
                replicate_wbs_list(boq_id,replicate_tender,replicate_boq,source, replicate_planning_tender)
                mismatch_records = validate_boq_replicate(replicate_planning_tender, boq_id)
                
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'mismatch_records': mismatch_records,
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a BOQ
                """
                approve = 0
                if 'status' in request.data:
                    if request.data['status'] != 'pending':
                        approve = 1
                check_editor_permissions(request,approve)
                if BOQ.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                    boq_details = BOQ.cmobjects.filter(pk=id).first()
                    if boq_details.status == "pending" or boq_details.status == "approved":
                        request.data['updated_by_id'] = request.user.id
                        serializer = BOQSerializer(boq_details, data=request.data)

                        if serializer.is_valid():
                            serializer.save()

                            return Response({'results': {
                                            'Data': serializer.data,
                                            },
                                'msg': "Sucessfully updated",
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
                    else:
                        raise APIException({'request_status': 0, 'msg': "BOQ already "+boq_details.status})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a BOQ
                """
                if BOQ.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    boq_details = BOQ.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    approve = 0
                    if 'status' in request.data:
                        if boq_details.status != 'pending':
                            approve = 1
                    check_editor_permissions(request,approve)
                    boq_details.updated_by_id = request.user.id
                    boq_details.is_deleted = True
                    boq_details.save()

                    return Response({'results': {
                        'boq': BOQ.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted BOQ',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class WBSListAPIView(APIView):
    """
    CRUD API for WBS List model
    """
    def get(self, request, format=None):
        """
        Get a list of all WBS List
        """
        boq_permit = check_editor_permissions(request,0,1)
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        cost_is_zero = self.request.query_params.get('cost_is_zero', None)
        order_by = self.request.query_params.get('order', '-id')
        search = {}
        if not boq_permit:
            search['boq'] = None
        if id:
            search['id'] = id
            wbs_list_details = WBSList.cmobjects.filter(**search).first()
            serializer = WBSListSerializer(wbs_list_details)
            return Response(serializer.data)
        
        search = custom_filters(self.request, search, ['cost_is_zero'])

        wbs_list_list = WBSList.cmobjects.prefetch_related(
            'wbs_labour_wbs_list',
            'wbs_material_wbs_list',
            'wbs_plant_machinery_wbs_list',
            'wbs_indirect_cost_wbs_list',
        ).filter(*search).select_related('uom').order_by(*str(order_by).split(","))

        if not 'parent__isnull' in self.request.query_params:
            return_list = []
            parent_list = list(set(list(wbs_list_list.values_list('id', flat=True))))
            all_list = WBSList.cmobjects.values()
            return_list = get_all_child(parent_list,return_list,all_list)
            wbs_list_list = WBSList.cmobjects.prefetch_related(
                'wbs_labour_wbs_list',
                'wbs_material_wbs_list',
                'wbs_plant_machinery_wbs_list',
                'wbs_indirect_cost_wbs_list',
            ).filter(id__in=return_list).select_related('uom').order_by('after_this','by_order','id')

        if cost_is_zero:
            _cost_is_zero = str2bool(cost_is_zero)
            if _cost_is_zero:
                wbs_list_list = wbs_list_list.annotate(cost_numeric=Cast('cost', FloatField())).filter(cost_numeric=0)
            else:
                wbs_list_list = wbs_list_list.annotate(cost_numeric=Cast('cost', FloatField())).filter(~Q(cost_numeric=0))

        if all == 'true':
            serializer = WBSListSerializer(wbs_list_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_list_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WBSListSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new WBS List
        """
        if request.data['boq']:
            check_boq_status(request,request.data['boq'],request.data['organization'])
        request.data['created_by_id'] = request.user.id
        serializer = WBSListSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a WBS List
                """

                if WBSList.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                    wbs_list_details = WBSList.cmobjects.filter(pk=id).first()
                    if wbs_list_details.boq_id:
                        check_boq_status(request,wbs_list_details.boq_id,organization_id)
                    request.data['updated_by_id'] = request.user.id
                    serializer = WBSListSerializer(wbs_list_details, data=request.data)

                    if serializer.is_valid():
                        serializer.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a WBSList
                """
                if WBSList.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    wbs_list_details = WBSList.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    if wbs_list_details.boq_id:
                        check_boq_status(request,wbs_list_details.boq_id,organization_id)
                    wbs_list_details.updated_by = request.user
                    wbs_list_details.is_deleted = True
                    wbs_list_details.save()

                    return Response({'results': {
                        'wbs_list': WBSList.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted WBSList',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
class WBSListNewAPIView(APIView):
    """
    CRUD API for WBS List model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all WBS List
        """
        all = self.request.query_params.get('all', None)
        ref_date = self.request.query_params.get('ref_date', datetime.today().strftime('%Y-%m-%d'))

        search = custom_filters(self.request, {}, ['ref_date'])
        ref_date = datetime.strptime(ref_date, '%Y-%m-%d')
        first_date = ref_date - timedelta(days=int(ref_date.strftime("%d")) - 1)
        data = WBSList.cmobjects.filter(*search).values_list('id', flat=True)
        return_list = []
        parent_list = list(set(list(data)))
        all_list = WBSList.cmobjects.values()
        return_list = get_all_child(parent_list,return_list,all_list)
        data = WBSList.cmobjects.filter(id__in=return_list).prefetch_related(
            'boq_invoice_schedule_wbs_tag_wbs','boq_monthly_planning_wbs','boq_monthly_progress_wbs'
        ).select_related('uom').annotate(
            invoice_schedule_items__name = Subquery(
                InvoiceScheduleWBSTag.cmobjects.filter(
                    wbs_id=OuterRef('pk'),
                    invoice_schedule_items__is_deleted=False,
                    ).values('wbs').annotate(
                        final_value=GroupConcat('invoice_schedule_items__name', distinct=True)
                    ).values('final_value')
            ),
            invoice_schedule_items__quantity = Coalesce(Sum(Subquery(
                InvoiceScheduleWBSTag.cmobjects.filter(
                    wbs_id=OuterRef('pk'),
                    invoice_schedule_items__is_deleted=False,
                    ).values('wbs').annotate(
                        final_value=Sum('invoice_schedule_items__quantity')
                    ).values('final_value')
            )), Value(0), output_field=FloatField()),
            planned__quantity = Coalesce(Sum(Subquery(
                BOQMonthlyPlanningData.cmobjects.filter(
                    wbs_id=OuterRef('pk'),
                    date=first_date,
                    ).values('wbs').annotate(
                        final_value=Sum('value')
                    ).values('final_value')
            )), Value(0), output_field=FloatField()),
            current_planned__quantity = Coalesce(Sum(Subquery(
                BOQMonthlyPlanningData.cmobjects.filter(
                    wbs_id=OuterRef('pk'),
                    date=first_date,
                    ).values('wbs').annotate(
                        final_value=Sum('current_value')
                    ).values('final_value')
            )), Value(0), output_field=FloatField()),
            planned__id = Subquery(
                BOQMonthlyPlanningData.cmobjects.filter(
                    wbs_id=OuterRef('pk'),
                    date=first_date,
                    ).values('wbs').annotate(
                        final_value=GroupConcat('id', distinct=True)
                    ).values('final_value')
            ),
            ref_date__quantity = Coalesce(Sum(Subquery(
                BOQMonthlyProgressData.cmobjects.filter(
                    wbs_id=OuterRef('pk'),
                    date=ref_date,
                    ).values('wbs').annotate(
                        final_value=Sum('value')
                    ).values('final_value')
            )), Value(0), output_field=FloatField()),
            till_ref_date__quantity = Coalesce(Sum(Subquery(
                BOQMonthlyProgressData.cmobjects.filter(
                    wbs_id=OuterRef('pk'),
                    date__lt=ref_date,
                    date__gte=first_date,
                    ).values('wbs').annotate(
                        final_value=Sum('value')
                    ).values('final_value')
            )), Value(0), output_field=FloatField()),
            till_last_month__quantity = Coalesce(Sum(Subquery(
                BOQMonthlyProgressData.cmobjects.filter(
                    wbs_id=OuterRef('pk'),
                    date__lt=first_date,
                    ).values('wbs').annotate(
                        final_value=Sum('value')
                    ).values('final_value')
            )), Value(0), output_field=FloatField()),
        ).values(
            'id','boq_code','boq_no','wbs','uom__symbol','budgeted_quantity','parent',
            'invoice_schedule_items__name','invoice_schedule_items__quantity','planned__quantity','ref_date__quantity','till_ref_date__quantity','till_last_month__quantity','current_planned__quantity','planned__id',
        ).order_by('after_this','by_order','id')

        if all == 'true':
            return Response({'results': data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': page.object_list,
            },
        })

class BOQChainageAPIView(APIView):
    """
    CRUD API for WBS List model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all WBS List
        """
        boq_permit = check_editor_permissions(request,0,1)
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order', '-id')
        search = {}
        if not boq_permit:
            search['boq'] = None
        if id:
            search['id'] = id
            wbs_list_details = BOQChainage.cmobjects.filter(**search).first()
            serializer = BOQChainageSerializer(wbs_list_details)
            return Response(serializer.data)
        
        search = custom_filters(self.request, search, [])

        wbs_list_list = BOQChainage.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = BOQChainageSerializer(wbs_list_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_list_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BOQChainageSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new WBS List
        """
        if request.data['boq']:
            check_boq_status(request,request.data['boq'],request.data['organization'])
        request.data['created_by_id'] = request.user.id
        serializer = BOQChainageSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        

        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a WBS List
                """

                if BOQChainage.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                    wbs_list_details = BOQChainage.cmobjects.filter(pk=id).first()
                    if wbs_list_details.boq_id:
                        check_boq_status(request,wbs_list_details.boq_id,organization_id)
                    request.data['updated_by_id'] = request.user.id
                    serializer = BOQChainageSerializer(wbs_list_details, data=request.data)

                    if serializer.is_valid():
                        serializer.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a BOQChainage
                """
                if BOQChainage.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    wbs_list_details = BOQChainage.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    if wbs_list_details.boq_id:
                        check_boq_status(request,wbs_list_details.boq_id,organization_id)
                    wbs_list_details.updated_by = request.user
                    wbs_list_details.is_deleted = True
                    wbs_list_details.save()

                    return Response({'results': {
                        'wbs_list': BOQChainage.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted BOQChainage',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class BOQChainageExecutiveSummeryDataAPIView(APIView):
    """
    CRUD API for WBS List model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all WBS List
        """
        search = custom_filters(self.request, {}, [])
        queryset = BOQChainageExecutiveSummeryData.cmobjects.filter(*search)
        return_list = []
        wbs_id = self.request.query_params.get('wbs_id', None)
        parent_list = [int(wbs_id)] if wbs_id else list(set(list(queryset.values_list('wbs_id', flat=True))))
        all_list = WBSList.cmobjects.values()
        return_list = get_all_child(parent_list,return_list,all_list)
        queryset = BOQChainageExecutiveSummeryData.cmobjects.select_related(
            'boq','wbs','form'
        ).filter(wbs_id__in=return_list).values(
            'id','wbs__wbs','wbs','wbs__parent_id','value','boq','form','type','form__name','form__start','form__end',\
            'form__chainage_value'
        )
        return Response(queryset)

    def post(self, request, format=None):
        """
        Create a new WBS List
        """
        if request.data['boq']:
            check_boq_status(request,request.data['boq'],request.data['organization'])
        request.data['created_by_id'] = request.user.id
        serializer = BOQChainageExecutiveSummeryDataSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        

        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a WBS List
                """

                if BOQChainageExecutiveSummeryData.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                    wbs_list_details = BOQChainageExecutiveSummeryData.cmobjects.filter(pk=id).first()
                    if wbs_list_details.boq_id:
                        check_boq_status(request,wbs_list_details.boq_id,organization_id)
                    request.data['updated_by_id'] = request.user.id
                    serializer = BOQChainageExecutiveSummeryDataSerializer(wbs_list_details, data=request.data)

                    if serializer.is_valid():
                        serializer.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a BOQChainageExecutiveSummeryData
                """
                if BOQChainageExecutiveSummeryData.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    wbs_list_details = BOQChainageExecutiveSummeryData.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    if wbs_list_details.boq_id:
                        check_boq_status(request,wbs_list_details.boq_id,organization_id)
                    wbs_list_details.updated_by = request.user
                    wbs_list_details.is_deleted = True
                    wbs_list_details.save()

                    return Response({'results': {
                        'wbs_list': BOQChainageExecutiveSummeryData.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted BOQChainageExecutiveSummeryData',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class BOQMonthlyPlanningDataAPIView(APIView):
    
    

    def get(self, request, format=None):
        search = custom_filters(self.request, {}, [])
        queryset = BOQMonthlyPlanningData.cmobjects.filter(*search)
        return_list = []
        wbs_id = self.request.query_params.get('wbs_id', None)
        parent_list = [int(wbs_id)] if wbs_id else list(set(list(queryset.values_list('wbs_id', flat=True))))
        all_list = WBSList.cmobjects.values()
        return_list = get_all_child(parent_list,return_list,all_list)

        queryset = (
            BOQMonthlyPlanningData.cmobjects
            .select_related('boq', 'wbs', 'form')
            .filter(wbs_id__in=return_list)
            .values(
                'id', 'wbs__wbs', 'wbs', 'wbs__parent_id', 'value', 'boq', 'form', 'side',
                'date', 'is_latest', 'form__name', 'form__start', 'form__end', 'form__chainage_value',
            )
        )
        return Response(queryset)

    def post(self, request, format=None):
        # if request.data['boq']:
        #     check_boq_status(request,request.data['boq'],request.data['organization'])
        request.data['created_by_id'] = request.user.id
        serializer = BOQMonthlyPlanningDataSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        

        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if BOQMonthlyPlanningData.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                    wbs_list_details = BOQMonthlyPlanningData.cmobjects.filter(pk=id).first()
                    # if wbs_list_details.boq_id:
                    #     check_boq_status(request,wbs_list_details.boq_id,organization_id)
                    request.data['updated_by_id'] = request.user.id
                    serializer = BOQMonthlyPlanningDataSerializer(wbs_list_details, data=request.data)

                    if serializer.is_valid():
                        serializer.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if BOQMonthlyPlanningData.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    wbs_list_details = BOQMonthlyPlanningData.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    # if wbs_list_details.boq_id:
                    #     check_boq_status(request,wbs_list_details.boq_id,organization_id)
                    wbs_list_details.updated_by = request.user
                    wbs_list_details.is_deleted = True
                    wbs_list_details.save()

                    return Response({'results': {
                        'wbs_list': BOQMonthlyPlanningData.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class WBSLabourAPIView(APIView):
    """
    CRUD API for WBS Labour model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all WBS Labour
        """
        boq_permit = check_editor_permissions(request,0,1)
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order', 'id')
        search = {}
        if not boq_permit:
            search['wbs_list__boq'] = None
        if id:
            search['id'] = id
            wbs_labour_details = WBSLabour.cmobjects.filter(**search).first()
            serializer = WBSLabourSerializer(wbs_labour_details)
            return Response(serializer.data)
        
        search = custom_filters(self.request, search, [])

        wbs_labour_list = WBSLabour.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = WBSLabourSerializer(wbs_labour_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_labour_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WBSLabourSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new WBS Labour
        """
        if isinstance(request.data, list):
            with transaction.atomic():
                return_data = []
                for bulk_data in request.data:
                    if bulk_data['wbs_list']:
                        check_wbs_boq_status(request,bulk_data['wbs_list'],bulk_data['organization'])
                    bulk_data['created_by'] = request.user.id
                    serializer = WBSLabourSerializer(data=bulk_data)
                    if serializer.is_valid():
                        serializer.save()
                        # update_wbs_cost(bulk_data['wbs_list'])
                        return_data.append(serializer.data)
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
                return Response({'results': {'Data': return_data,},
                                'msg': 'Successfully created',
                                'status': status.HTTP_201_CREATED,
                                "request_status": 1})
        else:
            raise APIException({'request_status': 0, 'msg': "Invalid body"})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        if method.lower() == 'edit':
            """
            Update a WBS Labour
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if WBSLabour.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                            wbs_labour_details = WBSLabour.cmobjects.filter(pk=id).first()
                            if wbs_labour_details.wbs_list_id:
                                check_wbs_boq_status(request,wbs_labour_details.wbs_list_id,organization_id)
                            bulk_data['updated_by'] = request.user.id
                            serializer = WBSLabourSerializer(wbs_labour_details, data=bulk_data)
                            if serializer.is_valid():
                                serializer.save()
                                # update_wbs_cost(bulk_data['wbs_list'])
                                return_data.append(serializer.data)
                            else:
                                raise APIException({'request_status': 0, 'msg': serializer.errors})
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'Data': return_data,},
                                    'msg': "Sucessfully updated",
                                    'status': status.HTTP_202_ACCEPTED,
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})
        elif method.lower() == 'delete':
            """
            Delete a WBS Labour
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if WBSLabour.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                            wbs_labour_details = WBSLabour.cmobjects.get(
                                pk=id, organization_id=organization_id)
                            if wbs_labour_details.wbs_list_id:
                                check_wbs_boq_status(request,wbs_labour_details.wbs_list_id,organization_id)
                            wbs_labour_details.updated_by = request.user
                            wbs_labour_details.is_deleted = True
                            wbs_labour_details.save()
                            # update_wbs_cost(wbs_labour_details.wbs_list_id)
                            return_data.append(WBSLabour.objects.filter(pk=id, organization_id=organization_id).values())
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'wbs_labour': return_data,},
                                    'msg': 'Successfully deleted WBS Labour',
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})


class WBSMaterialAPIView(APIView):
    """
    CRUD API for WBS Material model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all WBS Material
        """
        boq_permit = check_editor_permissions(request,0,1)
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order', 'id')
        search = {}
        if not boq_permit:
            search['wbs_list__boq'] = None
        if id:
            search['id'] = id
            wbs_material_details = WBSMaterial.cmobjects.filter(**search).first()
            serializer = WBSMaterialSerializer(wbs_material_details)
            return Response(serializer.data)
        
        search = custom_filters(self.request, search, [])

        wbs_material_list = WBSMaterial.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = WBSMaterialSerializer(wbs_material_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_material_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WBSMaterialSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new WBS Material
        """
        if isinstance(request.data, list):
            with transaction.atomic():
                return_data = []
                for bulk_data in request.data:
                    if bulk_data['wbs_list']:
                        check_wbs_boq_status(request,bulk_data['wbs_list'],bulk_data['organization'])
                    bulk_data['created_by'] = request.user.id
                    serializer = WBSMaterialSerializer(data=bulk_data)
                    if serializer.is_valid():
                        serializer.save()
                        # update_wbs_cost(bulk_data['wbs_list'])
                        return_data.append(serializer.data)
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
                return Response({'results': {'Data': return_data,},
                                'msg': 'Successfully created',
                                'status': status.HTTP_201_CREATED,
                                "request_status": 1})
        else:
            raise APIException({'request_status': 0, 'msg': "Invalid body"})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        if method.lower() == 'edit':
            """
            Update a WBS Material
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if WBSMaterial.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                            wbs_material_details = WBSMaterial.cmobjects.filter(pk=id).first()
                            if wbs_material_details.wbs_list_id:
                                check_wbs_boq_status(request,wbs_material_details.wbs_list_id,organization_id)
                            bulk_data['updated_by'] = request.user.id
                            serializer = WBSMaterialSerializer(wbs_material_details, data=bulk_data)
                            if serializer.is_valid():
                                serializer.save()
                                # update_wbs_cost(bulk_data['wbs_list'])
                                return_data.append(serializer.data)
                            else:
                                raise APIException({'request_status': 0, 'msg': serializer.errors})
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'Data': return_data,},
                                    'msg': "Sucessfully updated",
                                    'status': status.HTTP_202_ACCEPTED,
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})
        elif method.lower() == 'delete':
            """
            Delete a WBS Material
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if WBSMaterial.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                            wbs_material_details = WBSMaterial.cmobjects.get(
                                pk=id, organization_id=organization_id)
                            if wbs_material_details.wbs_list_id:
                                check_wbs_boq_status(request,wbs_material_details.wbs_list_id,organization_id)
                            wbs_material_details.updated_by = request.user
                            wbs_material_details.is_deleted = True
                            wbs_material_details.save()
                            # update_wbs_cost(wbs_material_details.wbs_list_id)
                            return_data.append(WBSMaterial.objects.filter(pk=id, organization_id=organization_id).values())
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'wbs_material': return_data,},
                                    'msg': 'Successfully deleted WBS Material',
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})



class WBSPlantMachineryAPIView(APIView):
    """
    CRUD API for WBS Plant Machinery model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all WBS Plant Machinery
        """
        boq_permit = check_editor_permissions(request,0,1)
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order', 'id')
        search = {}
        if not boq_permit:
            search['wbs_list__boq'] = None
        if id:
            search['id'] = id
            wbs_plant_machinery_details = WBSPlantMachinery.cmobjects.filter(**search).first()
            serializer = WBSPlantMachinerySerializer(wbs_plant_machinery_details)
            return Response(serializer.data)
        
        search = custom_filters(self.request, search, [])

        wbs_plant_machinery_list = WBSPlantMachinery.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = WBSPlantMachinerySerializer(wbs_plant_machinery_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_plant_machinery_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WBSPlantMachinerySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new WBS Plant Machinery
        """
        if isinstance(request.data, list):
            with transaction.atomic():
                return_data = []
                for bulk_data in request.data:
                    if bulk_data['wbs_list']:
                        check_wbs_boq_status(request,bulk_data['wbs_list'],bulk_data['organization'])
                    bulk_data['created_by'] = request.user.id
                    serializer = WBSPlantMachinerySerializer(data=bulk_data)
                    if serializer.is_valid():
                        serializer.save()
                        # update_wbs_cost(bulk_data['wbs_list'])
                        return_data.append(serializer.data)
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
                return Response({'results': {'Data': return_data,},
                                'msg': 'Successfully created',
                                'status': status.HTTP_201_CREATED,
                                "request_status": 1})
        else:
            raise APIException({'request_status': 0, 'msg': "Invalid body"})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        if method.lower() == 'edit':
            """
            Update a WBS Plant Machinery
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if WBSPlantMachinery.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                            wbs_plant_machinery_details = WBSPlantMachinery.cmobjects.filter(pk=id).first()
                            if wbs_plant_machinery_details.wbs_list_id:
                                check_wbs_boq_status(request,wbs_plant_machinery_details.wbs_list_id,organization_id)
                            bulk_data['updated_by'] = request.user.id
                            serializer = WBSPlantMachinerySerializer(wbs_plant_machinery_details, data=bulk_data)
                            if serializer.is_valid():
                                serializer.save()
                                # update_wbs_cost(bulk_data['wbs_list'])
                                return_data.append(serializer.data)
                            else:
                                raise APIException({'request_status': 0, 'msg': serializer.errors})
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'Data': return_data,},
                                    'msg': "Sucessfully updated",
                                    'status': status.HTTP_202_ACCEPTED,
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})
        elif method.lower() == 'delete':
            """
            Delete a WBS Plant Machinery
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if WBSPlantMachinery.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                            wbs_plant_machinery_details = WBSPlantMachinery.cmobjects.get(
                                pk=id, organization_id=organization_id)
                            if wbs_plant_machinery_details.wbs_list_id:
                                check_wbs_boq_status(request,wbs_plant_machinery_details.wbs_list_id,organization_id)
                            wbs_plant_machinery_details.updated_by = request.user
                            wbs_plant_machinery_details.is_deleted = True
                            wbs_plant_machinery_details.save()
                            # update_wbs_cost(wbs_plant_machinery_details.wbs_list_id)
                            return_data.append(WBSPlantMachinery.objects.filter(pk=id, organization_id=organization_id).values())
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'wbs_plant_machinery': return_data,},
                                    'msg': 'Successfully deleted WBS Plant Machinery',
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})


class WBSIndirectCostAPIView(APIView):
    """
    CRUD API for WBS Indirect Cost model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all WBS Indirect Cost
        """
        boq_permit = check_editor_permissions(request,0,1)
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order', 'id')
        search = {}
        if not boq_permit:
            search['wbs_list__boq'] = None
        if id:
            search['id'] = id
            wbs_indirect_cost_details = WBSIndirectCost.cmobjects.filter(**search).first()
            serializer = WBSIndirectCostSerializer(wbs_indirect_cost_details)
            return Response(serializer.data)
        
        search = custom_filters(self.request, search, [])

        wbs_indirect_cost_list = WBSIndirectCost.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = WBSIndirectCostSerializer(wbs_indirect_cost_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_indirect_cost_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WBSIndirectCostSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new WBS Indirect Cost
        """
        if isinstance(request.data, list):
            with transaction.atomic():
                return_data = []
                for bulk_data in request.data:
                    if bulk_data['wbs_list']:
                        check_wbs_boq_status(request,bulk_data['wbs_list'],bulk_data['organization'])
                    bulk_data['created_by'] = request.user.id
                    serializer = WBSIndirectCostSerializer(data=bulk_data)
                    if serializer.is_valid():
                        serializer.save()
                        # update_wbs_cost(bulk_data['wbs_list'])
                        return_data.append(serializer.data)
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
                return Response({'results': {'Data': return_data,},
                                'msg': 'Successfully created',
                                'status': status.HTTP_201_CREATED,
                                "request_status": 1})
        else:
            raise APIException({'request_status': 0, 'msg': "Invalid body"})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        if method.lower() == 'edit':
            """
            Update a WBS Indirect Cost
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if WBSIndirectCost.cmobjects.filter(pk=id,organization_id=organization_id).exists():
                            wbs_indirect_cost_details = WBSIndirectCost.cmobjects.filter(pk=id).first()
                            if wbs_indirect_cost_details.wbs_list_id:
                                check_wbs_boq_status(request,wbs_indirect_cost_details.wbs_list_id,organization_id)
                            bulk_data['updated_by'] = request.user.id
                            serializer = WBSIndirectCostSerializer(wbs_indirect_cost_details, data=bulk_data)
                            if serializer.is_valid():
                                serializer.save()
                                # update_wbs_cost(bulk_data['wbs_list'])
                                return_data.append(serializer.data)
                            else:
                                raise APIException({'request_status': 0, 'msg': serializer.errors})
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'Data': return_data,},
                                    'msg': "Sucessfully updated",
                                    'status': status.HTTP_202_ACCEPTED,
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})
        elif method.lower() == 'delete':
            """
            Delete a WBS Indirect Cost
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if WBSIndirectCost.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                            wbs_indirect_cost_details = WBSIndirectCost.cmobjects.get(
                                pk=id, organization_id=organization_id)
                            if wbs_indirect_cost_details.wbs_list_id:
                                check_wbs_boq_status(request,wbs_indirect_cost_details.wbs_list_id,organization_id)
                            wbs_indirect_cost_details.updated_by = request.user
                            wbs_indirect_cost_details.is_deleted = True
                            wbs_indirect_cost_details.save()
                            # update_wbs_cost(wbs_indirect_cost_details.wbs_list_id)
                            return_data.append(WBSIndirectCost.objects.filter(pk=id, organization_id=organization_id).values())
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'wbs_indirect_cost': return_data,},
                                    'msg': 'Successfully deleted WBS Indirect Cost',
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})



class WbsIndirectCostPlaningAPIView(APIView):
    """
    WbsIndirectCostPlaning CURD API
    """
    
    

    def get(self, request):
        """ Get a list of all WbsIndirectCostPlaning """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = WbsIndirectCostPlaning.cmobjects.filter(id=id).first()
            serializer = WbsIndirectCostPlaningSerializer(_details)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])

        _list = WbsIndirectCostPlaning.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = WbsIndirectCostPlaningSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WbsIndirectCostPlaningSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """ Create a new WbsIndirectCostPlaning """
        request.data['created_by_id'] = request.user.id
        serializer = WbsIndirectCostPlaningSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """ Edit a WbsIndirectCostPlaning """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """ Update """
                if WbsIndirectCostPlaning.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    work_indent_details = WbsIndirectCostPlaning.cmobjects.filter(pk=id).first()

                    serializer = WbsIndirectCostPlaningSerializer(work_indent_details, data=request.data, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """ Delete """
                if WbsIndirectCostPlaning.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    work_indent_details = WbsIndirectCostPlaning.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    work_indent_details.is_deleted = True
                    work_indent_details.save()

                    return Response({'results': {
                        'data': WbsIndirectCostPlaning.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class WbsTempPlaningAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = WbsTempPlaning.cmobjects.filter(id=id).first()
            serializer = WbsTempPlaningSerializer(_details)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])

        _list = WbsTempPlaning.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = WbsTempPlaningSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WbsTempPlaningSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by_id'] = request.user.id
        serializer = WbsTempPlaningSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if WbsTempPlaning.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    work_indent_details = WbsTempPlaning.cmobjects.filter(pk=id).first()

                    serializer = WbsTempPlaningSerializer(work_indent_details, data=request.data, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if WbsTempPlaning.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    work_indent_details = WbsTempPlaning.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    work_indent_details.is_deleted = True
                    work_indent_details.save()

                    return Response({'results': {
                        'data': WbsTempPlaning.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class WBSListDetailsAPIView(APIView):
    """
    Details API for WBS List model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all WBS List
        """
        wbs_parts = ['WBSLabour','WBSMaterial','WBSPlantMachinery','WBSIndirectCost']
        check_editor_permissions(request,0)
        id = self.request.query_params.get('id', None)
        search = {}
        if id:
            response_data = []
            search['pk'] = id
            boq_details = BOQ.cmobjects.filter(**search).order_by('-id').first()
            boq_serializer = BOQSerializer(boq_details)
            boq_data = [boq_serializer.data]
            for boq_values in boq_data:
                wbs_list = []
                wbs_list_details = WBSList.cmobjects.filter(boq=boq_values['id'])
                wbs_list_serializer = WBSListSerializer(wbs_list_details, many=True)
                for wbs_list_values in wbs_list_serializer.data:
                    for parts in wbs_parts:
                        details = eval(parts+'.cmobjects.filter(wbs_list=wbs_list_values["id"])')
                        parts_serializer = eval(parts+'Serializer(details, many=True)')
                        wbs_list_values[parts] = parts_serializer.data
                    wbs_list.append(wbs_list_values)
                boq_values['wbs_list'] = wbs_list
                response_data.append(boq_values)
            return Response(response_data)
        else:
            raise APIException({'request_status': 0, 'msg': "Not Found"})


class ScheduleHAPIView(APIView):
    """
    Details API for ScheduleH
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                file_name = request.data.get('file_name', None)
                fields = request.data.get('fields', None) # fields is required to search in excel file
                organization_id = self.request.query_params.get('organization_id', None)
                field_groups = request.data.get('field_groups', None)
                if organization_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization Id not provided"})
                if file_name is None:
                    raise APIException({'request_status': 0, 'msg': "file_name is required"})
                if fields is None:
                    raise APIException({'request_status': 0, 'msg': "fields is required"})
                if field_groups is None:
                    raise APIException({'request_status': 0, 'msg': "field_groups is required"})
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException({'request_status': 0, 'msg': "file not found"})
                sheet_xlsx = pd.read_excel(path)
                fields = fields.split(',')
                for field in fields:
                    sheet_xlsx[field] = sheet_xlsx[field].ffill(axis=0)
                sheet_xlsx = sheet_xlsx.replace(np.nan, None)
                data = {}
                for field_group in field_groups:
                    for key,value in sheet_xlsx[field_group['name']].items():
                        data[value] = {
                            "parent": str(sheet_xlsx[field_group['parent']][key]) if field_group['parent'] else None,
                            "code": str(sheet_xlsx[field_group['code']][key]) if field_group['code'] else None,
                            "name": str(value),
                            "percentage": str(sheet_xlsx[field_group['percentage']][key] ) if field_group['percentage'] else None,
                            "amount": str(sheet_xlsx[field_group['amount']][key]) if field_group['amount'] else None
                        }
                if data:
                    current_user = request.user.id
                    schedule_h_main = ScheduleH.objects.create(organization_id=organization_id,code="",name="",created_by_id=current_user)
                    # schedule_h_main.code = "Schedule-H-"+str(schedule_h_main.id)
                    # schedule_h_main.code = generate_all_code(schedule_h_main,['Schedule-H'])
                    # schedule_h_main.save()
                    for key,entry in data.items():
                        entry['created_by'] = current_user
                        entry['organization'] = organization_id
                        entry['schedule_h'] = schedule_h_main.id
                        try:
                            entry['percentage'] = float(entry['percentage'])
                        except Exception as e:
                            entry['percentage'] = 0
                        try:
                            entry['amount'] = float(entry['amount'])
                        except Exception as e:
                            entry['amount'] = 0
                        if not entry['parent'] is None:
                            schedule_h_parent = ScheduleHItems.cmobjects.filter(
                                organization_id=organization_id,
                                name=entry['parent'],
                                schedule_h = schedule_h_main.id
                            ).first()
                            entry['parent'] = schedule_h_parent.id if schedule_h_parent else None
                        serializer = ScheduleHItemsSerializer(data=entry)
                        if serializer.is_valid():
                            serializer.save()
                        else:
                            raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': 'Data not found'})
                return Response(
                    {'results': {
                        'Data': data,
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class BOQImportAPIView(APIView):
    """
    Details API for BOQImportAPIView
    """
    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                sheet_list = [
                    ['Labour ( L )','WBSLabour','labour','name','LabourMaster'],
                    ['Materials ( M )','WBSMaterial','material','material_name','VendorMaterialMaster'],
                    ['Plant Machinery ( P )','WBSPlantMachinery','plant_machinery_group','name','PlantMachineryGroup'],
                    # ['Indirect cost ( IDC-I )','WBSIndirectCost','indirect_cost','name','IndirectCostMaster']
                ]
                count_data = {}
                organization_id = self.request.query_params.get('organization_id', None)
                boq_id = self.request.query_params.get('boq_id', None)
                wbs_list_id = self.request.query_params.get('wbs_list_id', None)
                chainage_id = self.request.query_params.get('chainage_id', None)
                wbs_list_id_list = []
                if organization_id is None or boq_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID or BOQ ID not provided"})
                file = request.data['file']
                path = 'media/excel/' + file.name
                if not os.path.exists('media/excel'):
                    os.makedirs('media/excel')
                with open(path, 'wb+') as destination:
                    for chunk in file.chunks():
                        destination.write(chunk)
                
                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x
                
                wbs_code_list = pd.DataFrame(BOQChainageExecutiveSummeryData.cmobjects.filter(organization_id=organization_id,boq_id=boq_id,type='C').values('id','wbs','form','value'))
                wbs_code_list = wbs_code_list.fillna(np.nan).replace([np.nan], [None])
                wbs_code_list = wbs_code_list.applymap(lambda x: process_str(x))
                wbs_code_list = wbs_code_list.replace([np.nan], [None])
                uom_list = pd.DataFrame(UnitOfMesurement.cmobjects.filter(organization_id=organization_id).values('id','formal_name','symbol'))
                uom_list = uom_list.fillna(np.nan).replace([np.nan], [None])
                uom_list = uom_list.applymap(lambda x: process_str(x))
                uom_list = uom_list.replace([np.nan], [None])
                for sheet_name in sheet_list:
                    count_data[sheet_name[0]] = {'add': 0, 'edit': 0}
                    field_name = sheet_name[2]+'__'+sheet_name[3]
                    sheet_xlsx = pd.read_excel(path,sheet_name=sheet_name[0])
                    if len(sheet_xlsx.index) > 0:
                        for column in ['WBS Code', sheet_name[0], 'UOM', 'Qty per BOQ UOM', 'Wastage(%)', 'Rate', 'Productivity', 'Efficiency Loss - Monsoon', 'Efficiency - Normal Condn.', 'Fuel Efficiency', 'Working Hrs per Month', 'Fuel Norms', 'Machine Rental']:
                            if not column in sheet_xlsx:
                                sheet_xlsx[column] = np.nan
                            sheet_xlsx[column] = sheet_xlsx[column].ffill(axis=0)
                        records = pd.DataFrame(eval(f"{sheet_name[1]}.cmobjects.filter(organization_id=organization_id,wbs_list__boq_id=boq_id).values('id','{field_name}','{sheet_name[2]}_id','wbs_list_id')"))
                        entry = pd.DataFrame(eval(f"{sheet_name[4]}.cmobjects.filter(organization_id=organization_id).values()"))
                        sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                        records = records.fillna(np.nan).replace([np.nan], [None])
                        entry = entry.fillna(np.nan).replace([np.nan], [None])

                        sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                        records = records.applymap(lambda x: process_str(x))
                        entry = entry.applymap(lambda x: process_str(x))

                        sheet_xlsx['Qty per BOQ UOM'] = pd.to_numeric(sheet_xlsx['Qty per BOQ UOM'], errors='coerce')
                        sheet_xlsx['Wastage(%)'] = pd.to_numeric(sheet_xlsx['Wastage(%)'], errors='coerce')
                        sheet_xlsx['Rate'] = pd.to_numeric(sheet_xlsx['Rate'], errors='coerce')
                        sheet_xlsx['Productivity'] = pd.to_numeric(sheet_xlsx['Productivity'], errors='coerce')
                        sheet_xlsx['Efficiency Loss - Monsoon'] = pd.to_numeric(sheet_xlsx['Efficiency Loss - Monsoon'], errors='coerce')
                        sheet_xlsx['Efficiency - Normal Condn.'] = pd.to_numeric(sheet_xlsx['Efficiency - Normal Condn.'], errors='coerce')
                        sheet_xlsx['Fuel Efficiency'] = pd.to_numeric(sheet_xlsx['Fuel Efficiency'], errors='coerce')
                        sheet_xlsx['Working Hrs per Month'] = pd.to_numeric(sheet_xlsx['Working Hrs per Month'], errors='coerce')
                        sheet_xlsx['Fuel Norms'] = pd.to_numeric(sheet_xlsx['Fuel Norms'], errors='coerce') #
                        sheet_xlsx['Machine Rental'] = pd.to_numeric(sheet_xlsx['Machine Rental'], errors='coerce') #

                        sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                        records = records.replace([np.nan], [None])
                        entry = entry.replace([np.nan], [None])

                        sheet_xlsx['Qty per BOQ UOM'] = sheet_xlsx['Qty per BOQ UOM'].replace([None], [0])
                        sheet_xlsx['Wastage(%)'] = sheet_xlsx['Wastage(%)'].replace([None], [0])
                        sheet_xlsx['Rate'] = sheet_xlsx['Rate'].replace([None], [0])
                        sheet_xlsx['Productivity'] = sheet_xlsx['Productivity'].replace([None], [0])
                        sheet_xlsx['Efficiency Loss - Monsoon'] = sheet_xlsx['Efficiency Loss - Monsoon'].replace([None], [0])
                        sheet_xlsx['Efficiency - Normal Condn.'] = sheet_xlsx['Efficiency - Normal Condn.'].replace([None], [0])
                        sheet_xlsx['Fuel Efficiency'] = sheet_xlsx['Fuel Efficiency'].replace([None], [0])
                        sheet_xlsx['Working Hrs per Month'] = sheet_xlsx['Working Hrs per Month'].replace([None], [0])
                        sheet_xlsx['Fuel Norms'] = sheet_xlsx['Fuel norms'].replace([None], [0])
                        sheet_xlsx['Machine Rental'] = sheet_xlsx['Machine Rental'].replace([None], [0])

                        def check_wbs_list(row):
                            result = None
                            if 'value' in wbs_code_list and row['WBS Code']:
                                temp = list(wbs_code_list.loc[(wbs_code_list['value'].values == process_str(row['WBS Code']))]['wbs'].items())
                                if len(temp) > 0:
                                    result = temp[0][1]
                            return result
                        def check_chainage(row):
                            result = None
                            if 'value' in wbs_code_list and row['WBS Code']:
                                temp = list(wbs_code_list.loc[(wbs_code_list['value'].values == process_str(row['WBS Code']))]['form'].items())
                                if len(temp) > 0:
                                    result = temp[0][1]
                            return result
                        def check_uom(row):
                            result = None
                            if 'symbol' in uom_list and row['UOM']:
                                temp = list(uom_list.loc[(uom_list['symbol'].values == process_str(row['UOM']))]['id'].items())
                                if len(temp) > 0:
                                    result = temp[0][1]
                            return result
                        def check_entry(row):
                            result = None
                            if sheet_name[3] in entry and row[sheet_name[0]]:
                                temp = list(entry.loc[(entry[sheet_name[3]].values == process_str(row[sheet_name[0]]))]['id'].items())
                                if len(temp) > 0:
                                    result = temp[0][1]
                            return result
                        def check_record(row):
                            result = None
                            if 'wbs_list_id' in records and sheet_name[2]+'_id' in records and (row['entry_id']) and (row['wbs_list_id']):
                                temp = list(records.loc[(records['wbs_list_id'].values == int(row['wbs_list_id'])) & (records[sheet_name[2]+'_id'].values == int(row['entry_id']))]['id'].items())
                                if len(temp) > 0:
                                    result = temp[0][1]
                            return result
                        def check_fuel_norms(row):
                            result = 0
                            if sheet_name[3] in entry and row[sheet_name[0]]:
                                temp = list(entry.loc[(entry[sheet_name[3]].values == process_str(row[sheet_name[0]]))]['norms'].items())
                                if len(temp) > 0:
                                    result = temp[0][1]
                            return result
                        def check_machine_rental_depreciation_charges_per_month(row):
                            result = 0
                            if sheet_name[3] in entry and row[sheet_name[0]]:
                                temp = list(entry.loc[(entry[sheet_name[3]].values == process_str(row[sheet_name[0]]))]['depreciation_norms_per_month'].items())
                                if len(temp) > 0:
                                    result = temp[0][1]
                            return result
                        if not wbs_list_id:
                            sheet_xlsx['wbs_list_id'] = sheet_xlsx.apply(lambda row: check_wbs_list(row), axis=1)
                        else:
                            sheet_xlsx['wbs_list_id'] = wbs_list_id
                        if not chainage_id:
                            sheet_xlsx['chainage_id'] = sheet_xlsx.apply(lambda row: check_chainage(row), axis=1)
                        else:
                            sheet_xlsx['chainage_id'] = chainage_id
                        sheet_xlsx['uom_id'] = sheet_xlsx.apply(lambda row: check_uom(row), axis=1)
                        sheet_xlsx['entry_id'] = sheet_xlsx.apply(lambda row: check_entry(row), axis=1)
                        sheet_xlsx['record_id'] = sheet_xlsx.apply(lambda row: check_record(row), axis=1)
                        if sheet_name[0] == 'Plant Machinery ( P )':
                            # sheet_xlsx['fuel_norms'] = sheet_xlsx.apply(lambda row: check_fuel_norms(row), axis=1)
                            # sheet_xlsx['machine_rental_depreciation_charges_per_month'] = sheet_xlsx.apply(lambda row: check_machine_rental_depreciation_charges_per_month(row), axis=1)
                            sheet_xlsx['fuel_norms'] = sheet_xlsx['Fuel Norms']
                            sheet_xlsx['machine_rental_depreciation_charges_per_month'] = sheet_xlsx['Machine Rental']

                            sheet_xlsx['Qty per BOQ UOM'] = 1
                            sheet_xlsx['Wastage(%)'] = 0
                        else:
                            sheet_xlsx['fuel_norms'] = 0
                            sheet_xlsx['machine_rental_depreciation_charges_per_month'] = 0
                        sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                        data_add = []
                        for index, row in sheet_xlsx.iterrows():
                            wbs_list_id_list.append(sheet_xlsx.at[index, 'wbs_list_id'])
                            data = {
                                'organization_id': organization_id,
                                'wbs_list_id': sheet_xlsx.at[index, 'wbs_list_id'],
                                'chainage_id': sheet_xlsx.at[index, 'chainage_id'],
                                'uom_id': sheet_xlsx.at[index, 'uom_id'],
                                'quantity': row['Qty per BOQ UOM'],
                                'rate': row['Rate'],
                                'wastage': row['Wastage(%)'],
                                'productivity': row['Productivity'],
                                'efficiency_loss_monsoon': row['Efficiency Loss - Monsoon'],
                                'efficiency_normal_condn': row['Efficiency - Normal Condn.'],
                                'fuel_efficiency': row['Fuel Efficiency'],
                                'working_hrs_per_month': row['Working Hrs per Month'],
                                'fuel_norms': sheet_xlsx.at[index, 'fuel_norms'],
                                'machine_rental_depreciation_charges_per_month': sheet_xlsx.at[index, 'machine_rental_depreciation_charges_per_month'],
                                sheet_name[2]+'_id': sheet_xlsx.at[index, 'entry_id'],
                            }
                            if row[sheet_name[0]]:
                                if not sheet_xlsx.at[index, 'entry_id']:
                                    new_id = None
                                    entity = eval(f"{sheet_name[4]}.objects.create(organization_id=organization_id, created_by_id=request.user.id, {sheet_name[3]}=row[sheet_name[0]], )")
                                    if entity:
                                        new_id = entity.id
                                    sheet_xlsx['entry_id'] = sheet_xlsx.apply(lambda row1: (new_id if row[sheet_name[0]] and row1[sheet_name[0]] and (row[sheet_name[0]] == row1[sheet_name[0]]) else None) if (not row1['entry_id']) else row1['entry_id'], axis=1)
                                    sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                                    data[sheet_name[2]+'_id'] = new_id
                                if (not sheet_xlsx.at[index, 'record_id']):
                                    data_add.append(eval(f"{sheet_name[1]}(created_by_id=request.user.id, **data)"))
                                    count_data[sheet_name[0]]['add'] += 1
                                else:
                                    instance = eval(f"{sheet_name[1]}.cmobjects.filter(pk=sheet_xlsx.at[index, 'record_id']).update(updated_by_id=request.user.id, **data)")
                                    count_data[sheet_name[0]]['edit'] += 1
                        exec(f"{sheet_name[1]}.objects.bulk_create(data_add, batch_size=1000, ignore_conflicts=False)")
                
                for wbs_list_id_data in list(set(wbs_list_id_list)):
                    wbs_list = WBSList.cmobjects.filter(pk=wbs_list_id_data).first()
                    wbs_list.updated_by_id = request.user.id
                    wbs_list.save()

                return Response(
                    {'results': {
                        'Data': count_data,
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})

class BOQWBSImportAPIView(APIView):
    """
    BOQ WBS Import API
    """
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():

                count_data = {
                    "items_created": 0,
                    "items_updated": 0,
                    "errors": 0,
                }
                errors = []
                organization_id = request.query_params.get("organization_id")
                boq_id = request.query_params.get("boq_id")
                wbs_list_id = request.query_params.get("wbs_list_id")

                if not organization_id or not boq_id or not wbs_list_id:
                    raise APIException("organization_id, boq_id, wbs_list_id are required.")
                file_name = request.data.get("file_name")
                field_map = request.data.get("field_map", {})
                if not file_name:
                    raise APIException("file_name is required.")
                if not field_map:
                    raise APIException("field_map is required.")
                file_path = os.path.join("media/excel/", file_name)
                if not os.path.exists(file_path):
                    raise APIException("Excel file not found.")
                df = pd.read_excel(file_path)
                if df.empty:
                    raise APIException("Excel file is empty.")
                required_columns = [
                    field_map["boq_code"],
                    field_map["boq_no"],
                    field_map["wbs"]
                ]
                for col in required_columns:
                    if col not in df.columns:
                        raise APIException(f"Missing required column in Excel: {col}")
                df = df.where(pd.notnull(df), None)
                df = df.apply(lambda col: col.map(lambda x: x.strip() if isinstance(x, str) else x))
                for num_field in ["rate", "budgeted_quantity"]:
                    if num_field in field_map:
                        df[field_map[num_field]] = pd.to_numeric(df[field_map[num_field]], errors="coerce")
                def process_str(x):
                    if isinstance(x, str):
                        return x.lower().strip().replace(" ", "")
                    return x
                def get_parent_code(code):
                    if not code:
                        return None
                    code = str(code).strip()
                    if "." in code:
                        return ".".join(code.split(".")[:-1])
                    return None

                existing_wbs_qs = WBSList.objects.filter(
                    organization_id=organization_id,
                    boq_id=boq_id,
                    root_id=wbs_list_id,
                ).values("id", "boq_code")
                existing_wbs_map = {
                    str(obj["boq_code"]).strip(): obj["id"]
                    for obj in existing_wbs_qs if obj["boq_code"]
                }
                excel_code_map = {}
                uom_list = pd.DataFrame(
                    UnitOfMesurement.cmobjects.filter(
                        organization_id=organization_id
                    ).values("id", "formal_name", "symbol")
                )
                uom_list = uom_list.fillna(np.nan).replace([np.nan], [None])
                uom_list["symbol"] = uom_list["symbol"].map(lambda x: process_str(x))
                def check_uom(row):
                    if "uom" in field_map:
                        uom_value = row.get(field_map["uom"])
                        if uom_value:
                            symbol = process_str(uom_value)
                            match = uom_list.loc[uom_list["symbol"] == symbol]
                            if not match.empty:
                                return int(match.iloc[0]["id"])
                    return None
                df["uom_id"] = df.apply(check_uom, axis=1)
                created_map = {}
                df = df.replace([np.nan], [None])
                for index, row in df.iterrows():
                    row_index = index + 2
                    boq_code = row.get(field_map["boq_code"])
                    boq_no = row.get(field_map["boq_no"])
                    wbs_name = row.get(field_map["wbs"])
                    if not boq_code or not boq_no or not wbs_name:
                        errors.append(
                            f"Row {row_index}: boq_code, boq_no, and Particulars are required"
                        )
                        count_data["errors"] += 1
                        continue
                    boq_code = str(boq_code).strip()
                    if not re.fullmatch(r"\d+(?:\.\d+)*", boq_code):
                        errors.append(
                            f"Row {row_index}: BOQ code must be format like - 1, 1.1, 1.2 etc."
                        )
                        count_data["errors"] += 1
                        continue
                    # Excel duplicate validation
                    if boq_code in excel_code_map:
                        first_row = excel_code_map[boq_code]
                        errors.append(
                            f"Row {row_index}: BOQ code '{boq_code}' already used in Row {first_row}"
                        )
                        count_data["errors"] += 1
                        continue
                    else:
                        excel_code_map[boq_code] = row_index
                    quantity = row.get(field_map.get("budgeted_quantity"))
                    rate = row.get(field_map.get("rate"))
                    parent_id = wbs_list_id
                    parent_code = get_parent_code(boq_code)
                    if parent_code:
                        if parent_code in created_map:
                            parent_id = created_map[parent_code]
                        elif parent_code in existing_wbs_map:
                            parent_id = existing_wbs_map[parent_code]
                    data = {
                        "organization_id": organization_id,
                        "boq_id": boq_id,
                        "parent_id": parent_id,
                        "uom_id": None if pd.isna(row["uom_id"]) else row["uom_id"],
                        "boq_code": boq_code,
                        "boq_no": boq_no,
                        "wbs": wbs_name,
                        "rate": float(rate) if rate and not pd.isna(rate) else 0,
                        "budgeted_quantity": float(quantity) if quantity and not pd.isna(quantity) else 0,
                        "total_labour": row.get(field_map.get("total_labour")),
                        "total_material": row.get(field_map.get("total_material")),
                        "total_machinery": row.get(field_map.get("total_machinery")),
                        "total_overheads": row.get(field_map.get("total_overheads")),
                    }
                    existing_id = existing_wbs_map.get(boq_code)
                    if existing_id:
                        WBSList.cmobjects.filter(
                            pk=existing_id,
                            organization_id=organization_id
                        ).update(
                            updated_by_id=request.user.id,
                            **data
                        )
                        created_map[boq_code] = existing_id
                        BOQChainageExecutiveSummeryData.cmobjects.update_or_create(
                            organization_id=organization_id,
                            boq_id=boq_id,
                            wbs_id=existing_id,
                            type="Q", defaults={"value" : quantity})
                        count_data["items_updated"] += 1
                    else:
                        instance = WBSList.objects.create(
                            created_by_id=request.user.id,
                            **data
                        )
                        created_map[boq_code] = instance.id
                        existing_wbs_map[boq_code] = instance.id
                        count_data["items_created"] += 1
                return Response(
                    {
                        "data": count_data,
                        "errors": errors,
                        "msg": "BOQ WBS import completed successfully.",
                        "status": status.HTTP_201_CREATED,
                        "request_status": 1,
                    }
                )
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})

class BOQWBSImportAPIViewBack(APIView):
    """
    Details API for BOQWBSImportAPIView
    """
    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'wbs_add': 0, 'wbs_edit': 0, 'executive_add_edit': 0}
                organization_id = self.request.query_params.get('organization_id', None)
                boq_id = self.request.query_params.get('boq_id', None)
                wbs_list_id = self.request.query_params.get('wbs_list_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                if organization_id is None or boq_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID or BOQ ID not provided"})
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")
                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x
                
                return_list = []
                parent_list = list(set(list(WBSList.cmobjects.filter(pk=wbs_list_id,organization_id=organization_id,boq_id=boq_id,boq__is_deleted=False).values_list('id', flat=True))))
                all_list = WBSList.cmobjects.values()
                return_list = get_all_child(parent_list,return_list,all_list)

                # print("return_list ####", return_list)

                wbs_list = pd.DataFrame(WBSList.cmobjects.filter(id__in=return_list).values('id','wbs','parent'))
                chainage_list = pd.DataFrame(BOQChainage.cmobjects.filter(organization_id=organization_id,boq_id=boq_id,wbs__in=return_list,boq__is_deleted=False,wbs__is_deleted=False).values('id','name'))
                chainage_code_list = pd.DataFrame(BOQChainageExecutiveSummeryData.cmobjects.filter(organization_id=organization_id,boq_id=boq_id,wbs__in=return_list,type='C',boq__is_deleted=False,wbs__is_deleted=False,form__is_deleted=False).values('wbs','form','value','wbs__parent',))
                uom_list = pd.DataFrame(UnitOfMesurement.cmobjects.filter(organization_id=organization_id).values('id','formal_name','symbol'))
                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                    # sheet_xlsx[column] = sheet_xlsx[column].ffill(axis=0)
                chainage_count = len(sheet_xlsx.columns[pd.Series(sheet_xlsx.columns).str.startswith(field_map['chainage'])])
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                wbs_list = wbs_list.fillna(np.nan).replace([np.nan], [None])
                chainage_list = chainage_list.fillna(np.nan).replace([np.nan], [None])
                uom_list = uom_list.fillna(np.nan).replace([np.nan], [None])
                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                wbs_list = wbs_list.applymap(lambda x: process_str(x))
                chainage_list = chainage_list.applymap(lambda x: process_str(x))
                uom_list = uom_list.applymap(lambda x: process_str(x))
                sheet_xlsx[field_map['budgeted_quantity']] = pd.to_numeric(sheet_xlsx[field_map['budgeted_quantity']], errors='coerce')
                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                wbs_list = wbs_list.replace([np.nan], [None])
                chainage_list = chainage_list.replace([np.nan], [None])
                uom_list = uom_list.replace([np.nan], [None])
                def convert_pattern(code,parent=False):
                    # print(code)
                    try:
                        code_arr = process_str(code).split("-")
                        code_arr[int(code_arr.index("cp"))+1] = r'\d{2}'
                        if parent:
                            code_arr.pop()
                        code = '-'.join(code_arr)
                    except Exception as e:
                        print(e)
                    # print(code)
                    return code
                def check_wbs_list(row):
                    result = None
                    if 'value' in chainage_code_list and row[field_map['chainage_wbs_code']]:
                        temp = list(chainage_code_list.loc[chainage_code_list['value'].str.contains(r'^'+convert_pattern(row[field_map['chainage_wbs_code']], False)+'$')]['wbs'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_parent_wbs_list(row):
                    result = None
                    if 'value' in chainage_code_list and row[field_map['chainage_wbs_code']]:
                        temp = list(chainage_code_list.loc[chainage_code_list['value'].str.contains(r'^'+convert_pattern(row[field_map['chainage_wbs_code']], True)+'$')]['wbs'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_uom(row):
                    result = None
                    if 'symbol' in uom_list and row[field_map['uom']]:
                        temp = list(uom_list.loc[(uom_list['symbol'].values == process_str(row[field_map['uom']]))]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_chainage(row,index):
                    result = None
                    column_name = field_map['chainage']
                    if not index == 0:
                        column_name += '.'+str(index)
                    if 'name' in chainage_list and row[column_name]:
                        temp = list(chainage_list.loc[(chainage_list['name'].values == process_str(row[column_name]))]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                sheet_xlsx['id'] = sheet_xlsx.apply(lambda row: check_wbs_list(row), axis=1)
                sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row: check_parent_wbs_list(row), axis=1)
                sheet_xlsx['uom_id'] = sheet_xlsx.apply(lambda row: check_uom(row), axis=1)
                for index in range(0,chainage_count):
                    sheet_xlsx['chainage_id_'+str(index)] = sheet_xlsx.apply(lambda row: check_chainage(row,index), axis=1)
                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                for index, row in sheet_xlsx.iterrows():
                    if sheet_xlsx.at[index, field_map['wbs']] and sheet_xlsx.at[index, field_map['chainage']] and sheet_xlsx.at[index, 'chainage_id_0'] and sheet_xlsx.at[index, field_map['chainage_wbs_code']]:
                        
                        print("DATA ####", sheet_xlsx.at[index, 'parent_id'] if sheet_xlsx.at[index, 'parent_id'] else wbs_list_id)
                        
                        data = {
                            'organization_id': organization_id,
                            'boq_id': boq_id,
                            'parent_id': sheet_xlsx.at[index, 'parent_id'] if sheet_xlsx.at[index, 'parent_id'] else wbs_list_id,
                            'uom_id': sheet_xlsx.at[index, 'uom_id'],
                            'boq_code': row[field_map['boq_code']],
                            'boq_no': row[field_map['boq_no']],
                            'wbs': row[field_map['wbs']],
                            'rate': row[field_map['rate']] if row[field_map['rate']] else 0.0,
                            'budgeted_quantity': row[field_map['budgeted_quantity']] if row[field_map['budgeted_quantity']] else 0.0,
                            'total_labour': row[field_map['total_labour']],
                            'total_material': row[field_map['total_material']],
                            'total_machinery': row[field_map['total_machinery']],
                            'total_overheads': row[field_map['total_overheads']],
                        }
                        if sheet_xlsx.at[index, 'id']:
                            WBSList.objects.filter(pk=sheet_xlsx.at[index, 'id']).update(updated_by_id=request.user.id, **data)
                            count_data['wbs_edit'] += 1
                        else:
                            instance = WBSList.objects.create(created_by_id=request.user.id, **data)
                            sheet_xlsx['id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['chainage_wbs_code']] and row1[field_map['chainage_wbs_code']] and (convert_pattern(row[field_map['chainage_wbs_code']], False) == convert_pattern(row1[field_map['chainage_wbs_code']], False)) else None) if (not row1['id']) else row1['id'], axis=1)
                            sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['chainage_wbs_code']] and row1[field_map['chainage_wbs_code']] and (convert_pattern(row[field_map['chainage_wbs_code']], False) == convert_pattern(row1[field_map['chainage_wbs_code']], True)) else None) if (not row1['parent_id']) else row1['parent_id'], axis=1)
                            sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                            count_data['wbs_add'] += 1
                        for index1 in range(0,chainage_count):
                            chainage_wbs_code_column_name = field_map['chainage_wbs_code']
                            chainage_quantity_column_name = field_map['chainage_quantity']
                            if not index1 == 0:
                                chainage_wbs_code_column_name += '.'+str(index1)
                                chainage_quantity_column_name += '.'+str(index1)
                            chainage_data = {
                                'organization_id': organization_id,
                                'boq_id': boq_id,
                                'wbs_id': sheet_xlsx.at[index, 'id'],
                                'form_id': sheet_xlsx.at[index, 'chainage_id_'+str(index1)],
                                'updated_by_id': request.user.id,
                            }
                            chainage_data['type'] = 'C'
                            chainage_data_value = copy.copy(chainage_data)
                            chainage_data_value['value'] = row[chainage_wbs_code_column_name]
                            # print('-'*120)
                            # print(chainage_data)
                            # print('='*120)
                            # print(chainage_data_value)
                            # print('-'*120)
                            BOQChainageExecutiveSummeryData.objects.update_or_create(**chainage_data_value,defaults=chainage_data)
                            chainage_data['type'] = 'Q'
                            chainage_data_value = copy.copy(chainage_data)
                            chainage_data_value['value'] = row[chainage_quantity_column_name]
                            # print('-'*120)
                            # print(chainage_data)
                            # print('='*120)
                            # print(chainage_data_value)
                            # print('-'*120)
                            BOQChainageExecutiveSummeryData.objects.update_or_create(**chainage_data_value,defaults=chainage_data)
                            count_data['executive_add_edit'] += 2 
                        print(data)
                        # print('#'*120)

                # print(sheet_xlsx)
                return Response(
                    {'results': {
                        'Data': count_data,
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


from boq.helper import planning_tender_link
class PlanningTenderAPIView(APIView):

    def post(self, request, format=None):
        project_id = self.request.data.get('project_id', None)
        tender_id = self.request.data.get('tender_id', None)
        organization_id = self.request.query_params.get('organization_id', None)

        planning_tender_link(request, project_id, tender_id, organization_id)

        return Response({"msg": "success"})


class BOQMaterialReportAPIView(APIView):
    
    
    def get(self, request):
        try:
            order_by = self.request.query_params.get('order_by', '-id')
            search = custom_filters(self.request, {}, [])
            resp = WBSMaterial.cmobjects.select_related(
                'wbs_list','material','uom','wbs_list__uom'
            ).filter(*search).order_by(*str(order_by).split(",")).values(
                'wbs_list__boq_code', 'wbs_list__boq_no', 'wbs_list__wbs', 'wbs_list__uom__symbol',
                'wbs_list__budgeted_quantity', 'material__material_name', 'uom__symbol',
                'wastage', 'budgeted_quantity', 'rate'
            )
            return Response(resp)
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
class DrawingCategoryAPIView(APIView):
    """
    CRUD API for Drawing Categories
    """
    
    

    def get(self, request):
        """
        Retrieve Drawing Category details or a list of Drawing Categories
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            drawing_category = DrawingCategory.cmobjects.filter(id=id).first()
            serializer = DrawingCategorySerializer(drawing_category)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = DrawingCategory.cmobjects.select_related('organization', 'project').filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = DrawingCategorySerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = DrawingCategorySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Drawing Category entry
        """
        request.data['created_by'] = request.user.id
        serializer = DrawingCategorySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a Drawing Category entry
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        drawing_category_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Drawing Category entry
                """
                if DrawingCategory.cmobjects.filter(pk=drawing_category_id, organization_id=organization_id,).exists():
                    details = DrawingCategory.cmobjects.filter(pk=drawing_category_id,organization_id=organization_id).first()
                    request.data['updated_by'] = request.user.id

                    serializer = DrawingCategorySerializer(details, data=request.data, partial=True, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully updated.',
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            elif method.lower() == 'delete':
                """
                Delete a Drawing Category entry
                """
                if DrawingCategory.cmobjects.filter(pk=drawing_category_id, organization_id=organization_id,).exists():
                    details = DrawingCategory.cmobjects.filter(pk=drawing_category_id, organization_id=organization_id,).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': DrawingCategory.objects.filter(pk=drawing_category_id, organization_id=organization_id,).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})


class DrawingTrackerAPIView(APIView):
    """
    CRUD API for DrawingTracker
    """
    
    

    def get(self, request):
        """
        Get a list of DrawingTracker 
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            entry = DrawingTracker.cmobjects.filter(id=id).first()
            serializer = DrawingTrackerSerializer(entry)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])
        
        _list = DrawingTracker.cmobjects.select_related(
            'organization', 'planning_tender', 'boq', 'parent', 'wbs', 'form'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = DrawingTrackerSerializer(_list, many=True)
            print(serializer.data)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = DrawingTrackerSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


    def post(self, request):
        """
        Bulk create or update DrawingTrackers.
        """
        new_data = request.data

        if not isinstance(new_data, list):
            new_data = [new_data]

        results = {"success": [], "errors": []}  

        with transaction.atomic():
            for data in new_data:
                entry_id = data.get('id', None)  
                organization_id = data.get('organization', None) 

                data['updated_by'] = request.user.id
                if not entry_id:
                    data['created_by'] = request.user.id  
                try:
                    if entry_id:
                        tracker_instance = DrawingTracker.cmobjects.filter(id=entry_id, organization_id=organization_id).first()
                        if not tracker_instance:
                            results["errors"].append({
                                "data": data,
                                "error": f"Entry with ID {entry_id} not found",
                                "msg": "Failed to update the entry"
                            })
                            continue
                            
                        serializer = DrawingTrackerSerializer(
                            tracker_instance, data=data, partial=True, context={'request': request}
                        )
                        if serializer.is_valid():
                            serializer.save()
                            results["success"].append({
                                "data": serializer.data,
                                "msg": "Successfully updated"
                            })
                        else:
                            results["errors"].append({
                                "data": data,
                                "error": serializer.errors,
                                "msg": "Validation failed during update"
                            })
                        continue  
                    else:
                        serializer = DrawingTrackerSerializer(data=data, context={'request': request})
                        if serializer.is_valid():
                            serializer.save()
                            results["success"].append({
                                "data": serializer.data,
                                "msg": "Successfully created"
                            })
                        else:
                            results["errors"].append({
                                "data": data,
                                "error": serializer.errors,
                                "msg": "Validation failed during creation"
                            })

                except Exception as e:
                    results["errors"].append({
                        "data": data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })

        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED ,
            "request_status": 1 
        })

    def put(self, request):
        """
        Bulk edit or delete DrawingTrackers.
        """
        method = request.query_params.get('method', '').lower()
        organization_id = request.query_params.get('organization_id', None)

        entries = request.data
        if not isinstance(entries, list):
            entries = [entries]

        results = {"success": [], "errors": []}  

        with transaction.atomic():
            if method == 'edit':
                for entry_data in entries:
                    entry_id = entry_data.get('id', None)
                    if not entry_id:
                        results["errors"].append({
                            "data": entry_data,
                            "error": "Entry ID not provided",
                            "msg": "Failed to update the entry"
                        })
                        continue

                    tracker_instance = DrawingTracker.cmobjects.filter(pk=entry_id, organization_id=organization_id).first()
                    if not tracker_instance:
                        results["errors"].append({
                            "data": entry_data,
                            "error": f"Entry with ID {entry_id} not found",
                            "msg": "Failed to update the entry"
                        })
                        continue

                    entry_data['updated_by'] = request.user.id
                    serializer = DrawingTrackerSerializer(tracker_instance, data=entry_data, partial=True, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                            results["success"].append({
                                "data": serializer.data,
                                "msg": "Successfully updated"
                            })
                        except Exception as e:
                            results["errors"].append({
                                "data": entry_data,
                                "error": str(e),
                                "msg": "Failed to save the entry"
                            })
                    else:
                        results["errors"].append({
                            "data": entry_data,
                            "error": serializer.errors,
                            "msg": "Validation failed"
                        })

                return Response({
                    'results': results,
                    'status': status.HTTP_202_ACCEPTED ,
                    "request_status": 1 
                })

            elif method == 'delete':
                for entry_data in entries:
                    entry_id = entry_data.get('id', None)
                    if not entry_id:
                        results["errors"].append({
                            "data": entry_data,
                            "error": "Entry ID not provided",
                            "msg": "Failed to delete the entry"
                        })
                        continue

                    tracker_instance = DrawingTracker.cmobjects.filter(pk=entry_id, organization_id=organization_id).first()
                    if not tracker_instance:
                        results["errors"].append({
                            "data": entry_data,
                            "error": f"Entry with ID {entry_id} not found",
                            "msg": "Failed to delete the entry"
                        })
                        continue

                    try:
                        tracker_instance.is_deleted = True
                        tracker_instance.updated_by_id = request.user.id
                        tracker_instance.save()
                        results["success"].append({
                            "id": entry_id,
                            "msg": "Successfully deleted"
                        })
                    except Exception as e:
                        results["errors"].append({
                            "data": entry_data,
                            "error": str(e),
                            "msg": "Something went wrong. If the problem persists, please contact support."
                        })

                return Response({
                    'results': results,
                    'status': status.HTTP_202_ACCEPTED ,
                    "request_status": 1 
                })

            else:
                raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support."'})            

# class DrawingTrackerBulkImportAPIView(APIView):
#     """
#     API for importing DrawingTracker and DrawingTrackerDocuments data from an Excel file.
#     """
#     
#     

#     def post(self, request, *args, **kwargs):
#         try:
#             with transaction.atomic():
#                 count_data = {'drawing_tracker_add': 0, 'drawing_tracker_documents_add': 0, 
#                               'drawing_tracker_update': 0, 'drawing_tracker_documents_update': 0}
#                 organization_id = request.query_params.get('organization_id', None)
#                 project_id = request.query_params.get('project_id', None)
#                 file_name = request.data.get('file_name', None)
#                 field_map = request.data.get('field_map', {})

#                 if not organization_id and not project_id:
#                     raise APIException({'request_status': 0, 'msg': "Organization ID and Project ID are required"})

#                 path = f'media/excel/{file_name}'
#                 if not os.path.exists(path):
#                     raise APIException("File not found")

#                 sheet_xlsx = pd.read_excel(path)
#                 if len(sheet_xlsx.index) <= 0:
#                     raise APIException({'request_status': 0, 'msg': 'Empty file'})

#                 sheet_xlsx = sheet_xlsx.fillna('').replace([pd.NaT, None], '')

#                 latest_boq_id = get_latest_boq(project_id)
#                 if not latest_boq_id:
#                     raise APIException({'request_status': 0, 'msg': "No BOQ found for the project"})

#                 def process_str(x):
#                     if isinstance(x, str):
#                         x = x.lower().strip().replace(' ', '')
#                     return x

#                 def handle_date(value, default=None):
#                     if pd.isna(value) or value == "":
#                         return default
#                     try:
#                         return pd.to_datetime(value, errors='coerce')
#                     except Exception as e:
#                         return default

#                 wbs_list = WBSList.cmobjects.filter(boq_id=latest_boq_id, organization_id=organization_id).values('id', 'wbs')
#                 wbs_df = pd.DataFrame(wbs_list)

#                 form_list = BOQChainage.cmobjects.filter(boq_id=latest_boq_id, organization_id=organization_id).values('id', 'name', 'wbs_id')
#                 form_df = pd.DataFrame(form_list)

#                 def check_wbs(wbs_name):
#                     result = None
#                     if wbs_name:
#                         temp = wbs_df[wbs_df['wbs'].str.contains(r'^' + str(wbs_name).strip() + '$', case=False, na=False)]
#                         if not temp.empty:
#                             result = temp.iloc[0]['id']
#                     return result

#                 def check_form(wbs_id, form_name):
#                     result = None
#                     # if wbs_id and form_name:
#                     #     temp = form_df[(form_df['wbs_id'] == wbs_id) & (form_df['name'].str.contains(r'^' + str(form_name).strip() + '$', case=False, na=False))]
#                     #     if not temp.empty:
#                     #         result = temp.iloc[0]['id']
#                     if form_name:
#                         temp = form_df[(form_df['name'].str.contains(r'^' + str(form_name).strip() + '$', case=False, na=False))]
#                         if not temp.empty:
#                             result = temp.iloc[0]['id']        
#                     return result

#                 def format_status(value, choices):
#                     """
#                     Formats the status field to match the defined choices.
                   
#                     """
#                     if not value:
#                         return None
#                     value = str(value).strip().capitalize()
#                     valid_choices = [choice[0] for choice in choices]
#                     # print(value)
#                     return value if value in valid_choices else None

#                 def format_side(value):
#                     """
#                     Formats the side field to be uppercase.
#                     """
#                     if not value:
#                         return None
#                     return str(value).strip().upper()
#                 tracker_id_map = {}

#                 for index, row in sheet_xlsx.iterrows():
#                     wbs_name = row.get(field_map.get('wbs'), None)
#                     form_name = row.get(field_map.get('form'), None)

#                     wbs_id = check_wbs(wbs_name)
#                     form_id = check_form(wbs_id, form_name)

#                     data = {
#                         'organization_id': organization_id,
#                         'boq_id': latest_boq_id,
#                         'wbs_id': wbs_id,
#                         'form_id': form_id,
#                         'side': format_side(row.get(field_map.get('side'))),
#                         'title': row.get(field_map.get('title'), None),
#                         'number': row.get(field_map.get('number'), None),
#                         'status': format_status(row.get(field_map.get('status')), DrawingTracker.STATUS),
#                         'remarks': row.get(field_map.get('remarks'), None),
#                         'final_approval_date': handle_date(row.get(field_map.get('final_approval_date')), None),
#                     }


#                     if wbs_id and form_id and row.get(field_map.get('side')):

#                         drawing_tracker_obj = DrawingTracker.cmobjects.filter(
#                             wbs_id=wbs_id,
#                             form_id=form_id,
#                             side=row.get(field_map.get('side'))
#                         ).first()

#                         if drawing_tracker_obj:
#                             for key, value in data.items():
#                                 setattr(drawing_tracker_obj, key, value)
#                             drawing_tracker_obj.updated_by_id = request.user.id
#                             drawing_tracker_obj.save()
#                             count_data['drawing_tracker_update'] += 1

#                         else:
#                             drawing_tracker_obj = DrawingTracker.objects.create(created_by_id=request.user.id, **data)
#                             count_data['drawing_tracker_add'] += 1

#                         tracker_id_map[index] = drawing_tracker_obj.id
#                         sheet_xlsx.at[index, 'drawing_tracker_id'] = drawing_tracker_obj.id  


#                 sheet_xlsx['drawing_tracker_id'].ffill(inplace=True)

#                 drawing_tracker_documents_data = []
#                 for index, row in sheet_xlsx.iterrows():
#                     drawing_tracker_id = row.get('drawing_tracker_id')
#                     if drawing_tracker_id:
#                         data = {
#                             'organization_id': organization_id,
#                             'drawing_tracker_id': drawing_tracker_id,
#                             'current_version': handle_nan(row.get(field_map.get('current_version')), 0),
#                             'target_date_as_per_work_order': handle_date(row.get(field_map.get('target_date_as_per_work_order')), None),
#                             'designer_to_sinpl': handle_date(row.get(field_map.get('designer_to_sinpl')), None),
#                             'designer_to_sinpl_status': format_status(row.get(field_map.get('designer_to_sinpl_status')), DrawingTrackerDocuments.STATUS),
#                             'designer_to_sinpl_remarks': row.get(field_map.get('designer_to_sinpl_remarks'), None),
#                             'sinpl_to_proof_consultant': handle_date(row.get(field_map.get('sinpl_to_proof_consultant')), None),
#                             'sinpl_to_proof_consultant_status': format_status(row.get(field_map.get('sinpl_to_proof_consultant_status')), DrawingTrackerDocuments.STATUS),
#                             'sinpl_to_proof_consultant_remarks': row.get(field_map.get('sinpl_to_proof_consultant_remarks'), None),
#                             'proof_consultant_to_sinpl': handle_date(row.get(field_map.get('proof_consultant_to_sinpl')), None),
#                             'proof_consultant_to_sinpl_status': format_status(row.get(field_map.get('proof_consultant_to_sinpl_status')), DrawingTrackerDocuments.STATUS),
#                             'proof_consultant_to_sinpl_remarks': row.get(field_map.get('proof_consultant_to_sinpl_remarks'), None),
#                             'sinpl_to_client': handle_date(row.get(field_map.get('sinpl_to_client')), None),
#                             'sinpl_to_client_status': format_status(row.get(field_map.get('sinpl_to_client_status')), DrawingTrackerDocuments.STATUS),
#                             'sinpl_to_client_remarks': row.get(field_map.get('sinpl_to_client_remarks'), None),
#                             'created_by_id': request.user.id
#                         }

#                         existing_document = DrawingTrackerDocuments.cmobjects.filter(
#                             drawing_tracker_id=drawing_tracker_id,
#                             current_version=row.get(field_map.get('current_version'))
#                         ).first()

#                         if existing_document:
#                             for key, value in data.items():
#                                 setattr(existing_document, key, value)
#                             existing_document.updated_by_id = request.user.id     
#                             existing_document.save()
#                             count_data['drawing_tracker_documents_update'] += 1

#                         else:
#                             drawing_tracker_documents_data.append(DrawingTrackerDocuments(**data))

#                 if drawing_tracker_documents_data:
#                     DrawingTrackerDocuments.objects.bulk_create(drawing_tracker_documents_data, batch_size=1000, ignore_conflicts=False)
#                     count_data['drawing_tracker_documents_add'] = len(drawing_tracker_documents_data)

#                 return Response({
#                     'results': {'Data': count_data},
#                     'msg': 'Successfully imported',
#                     'status': status.HTTP_201_CREATED,
#                     'request_status': 1,
#                 })

#         except Exception as e:
#             error_message = str(e.args[0]) if e.args else str(e)
#             raise APIException({'request_status': 0, 'msg': error_message})
class DrawingTrackerBulkImportAPIView(APIView):
    """
    API for bulk import of DrawingTracker 
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {
                    'drawing_tracker_add': 0,
                    'drawing_tracker_edit': 0,
                    # 'drawing_tracker_documents_add': 0,
                    # 'drawing_tracker_documents_edit': 0
                }
                organization_id = self.request.query_params.get('organization_id', None)
                project_id = self.request.query_params.get('project_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})

                if not organization_id or not project_id or not file_name:
                    raise APIException({'request_status': 0, 'msg': "Organization ID, Project ID, or file name not provided"})

                file_path = os.path.join('media/excel', file_name)
                if not os.path.exists(file_path):
                    raise APIException("File not found")

                sheet_xlsx = pd.read_excel(file_path)
                if sheet_xlsx.empty:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                sheet_xlsx = sheet_xlsx.fillna("").applymap(lambda x: x.strip() if isinstance(x, str) else x)

                latest_boq_id = get_latest_boq(project_id)
                if not latest_boq_id:
                    raise APIException({'request_status': 0, 'msg': "No BOQ found for the project"})
                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x

                def handle_date(value, default=None):
                    if pd.isna(value) or value == "":
                        return default
                    try:
                        return pd.to_datetime(value, errors='coerce')
                    except Exception as e:
                        return default
                def format_status(value, choices):
                    """
                    Formats the status field to match the defined choices.
                   
                    """
                    if not value:
                        return None
                    value = str(value).strip().capitalize()
                    valid_choices = [choice[0] for choice in choices]
                    return value if value in valid_choices else None    
                wbs_list = pd.DataFrame(WBSList.cmobjects.filter(
                    boq_id=latest_boq_id,
                    organization_id=organization_id
                ).values('id', 'wbs'))
                # wbs_dict = dict(zip(wbs_list['wbs'], wbs_list['id']))

                form_list = pd.DataFrame(BOQChainage.cmobjects.filter(
                    boq_id=latest_boq_id,
                    organization_id=organization_id
                ).values('id', 'name'))
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                wbs_list = wbs_list.fillna(np.nan).replace([np.nan], [None])
                form_list = form_list.fillna(np.nan).replace([np.nan], [None])
                # form_dict = dict(zip(form_list['name'], form_list['id']))
                wbs_list = wbs_list.replace([np.nan], [None])
                form_list = form_list.replace([np.nan], [None])
                def check_wbs(row):
                    result = None
                    wbs_name = row.get(field_map.get('wbs'))
      
                    if pd.notna(wbs_name):  
                        # processed_name = process_str(wbs_name)  
                        # print('processed_name',processed_name)
                        temp = wbs_list[wbs_list['wbs'].str.contains(r'^' + str(wbs_name).strip() + '$', case=False, na=False)]  # Regex match for exact wbs_name
                        print('temp',temp)
                        if not temp.empty:
                            result = temp.iloc[0]['id'] 
                            print('result',result)
                    return result
                    
                def check_form(row):
                    result = None
                    form_name = row.get(field_map.get('form'))
                    if pd.notna(form_name):  
                        # processed_name = process_str(form_name) 
                        temp = form_list[(form_list['name'].str.contains(r'^' + str(form_name).strip() + '$', case=False, na=False))]

                        if not temp.empty:
                            result = temp.iloc[0]['id']  
                    return result
                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx['wbs_id'] = sheet_xlsx.apply(lambda row: check_wbs(row), axis=1)

                sheet_xlsx['form_id'] = sheet_xlsx.apply(lambda row: check_form(row), axis=1)
                # print(sheet_xlsx['wbs_id'])
                
                # tracker_id_map = {}

                for index, row in sheet_xlsx.iterrows():
                    wbs_id =  sheet_xlsx.at[index, 'wbs_id']
                    form_id = sheet_xlsx.at[index, 'form_id']
                    side = row.get(field_map.get('side', ''))
                    current_version = handle_nan(row.get(field_map.get('current_version')), 0)

                    # print(wbs_id,form_id,side)
                    tracker_data = {
                        'organization_id': organization_id,
                        'boq_id': latest_boq_id,
                        'wbs_id': wbs_id,
                        'form_id': form_id,
                        'title': row.get(field_map.get('title', '')),
                        'number': row.get(field_map.get('number', '')),
                        'status': row.get(field_map.get('status', 'Return')).capitalize() if row.get(field_map.get('status', 'Return')) else 'Return',
                        'remarks': row.get(field_map.get('remarks', '')),
                        'side': side,
                        'final_approval_date': handle_date(row.get(field_map.get('final_approval_date')), None),

    
                        'initiation_date_as_per_work_order': handle_date(row.get(field_map.get('initiation_date_as_per_work_order')), None),
                        'actual_initiation_date': handle_date(row.get(field_map.get('actual_initiation_date')), None),

                        'target_date_as_per_work_order': handle_date(row.get(field_map.get('target_date_as_per_work_order')), None),
                        'designer_to_sinpl': handle_date(row.get(field_map.get('designer_to_sinpl')), None),
                        'designer_to_sinpl_status': format_status(row.get(field_map.get('designer_to_sinpl_status')), DrawingTracker.SINPL_STATUS),
                        'designer_to_sinpl_remarks': row.get(field_map.get('designer_to_sinpl_remarks'), None),
                        'sinpl_to_proof_consultant': handle_date(row.get(field_map.get('sinpl_to_proof_consultant')), None),
                        'sinpl_to_proof_consultant_status': format_status(row.get(field_map.get('sinpl_to_proof_consultant_status')), DrawingTracker.SINPL_STATUS),
                        'sinpl_to_proof_consultant_remarks': row.get(field_map.get('sinpl_to_proof_consultant_remarks'), None),
                        'proof_consultant_to_sinpl': handle_date(row.get(field_map.get('proof_consultant_to_sinpl')), None),
                        'proof_consultant_to_sinpl_status': format_status(row.get(field_map.get('proof_consultant_to_sinpl_status')), DrawingTracker.SINPL_STATUS),
                        'proof_consultant_to_sinpl_remarks': row.get(field_map.get('proof_consultant_to_sinpl_remarks'), None),
                        'sinpl_to_client': handle_date(row.get(field_map.get('sinpl_to_client')), None),
                        'sinpl_to_client_status': format_status(row.get(field_map.get('sinpl_to_client_status')), DrawingTracker.SINPL_STATUS),
                        'sinpl_to_client_remarks': row.get(field_map.get('sinpl_to_client_remarks'), None),
                    }
                    
                    if wbs_id and form_id and side and current_version:
                        tracker_created = None 
                        tracker_instance, tracker_created = DrawingTracker.objects.update_or_create(
                            wbs_id=wbs_id,
                            form_id=form_id,
                            side=side,
                            current_version=current_version,
                            defaults={
                                **tracker_data,
                                'updated_by_id': request.user.id if not tracker_created else None,
                                'created_by_id': request.user.id if tracker_created else None,
                            }
                        )

                        count_data['drawing_tracker_add' if tracker_created else 'drawing_tracker_edit'] += 1
                     
                       
                return Response({
                    'results': {'Data': count_data},
                    'msg': 'Successfully imported',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1
                })
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
        
class WBSGanttAPIView(APIView):
    """
    CRUD API for WBSGantt
    """
    
    

    def get(self, request):
        """
        Get a list of WBSGantt
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            wbs = WBSGantt.cmobjects.filter(id=id).first()
            serializer = WBSGanttSerializer(wbs)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])
        _list = WBSGantt.cmobjects.select_related(
            'organization',
            'parent',
            'uom'
        ).prefetch_related(
            'boq_wbs_gantt_depends_wbs_gantt',
            'boq_wbs_gantt_depends_linked_wbs_gantt'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = WBSGanttSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WBSGanttSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new WBSGantt
        """
        request.data['created_by'] = request.user.id
        serializer = WBSGanttSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a WBSGantt
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        entry_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if WBSGantt.cmobjects.filter(pk=entry_id, organization_id=organization_id).exists():
                    wbs = WBSGantt.objects.filter(pk=entry_id,organization_id=organization_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = WBSGanttSerializer(wbs, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if WBSGantt.cmobjects.filter(pk=entry_id, organization_id=organization_id).exists():
                    wbs = WBSGantt.objects.filter(pk=entry_id, organization_id=organization_id).first()
                    wbs.is_deleted = True
                    wbs.updated_by_id = request.user.id
                    wbs.save()
                    return Response({'results': {'Data': WBSGantt.objects.filter(pk=entry_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class InvoiceScheduleAPIView(APIView):
    """
    CRUD API for Invoice Schedule
    """
    
    

    def get(self, request):
        """
        Retrieve Invoice Schedule details
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = InvoiceSchedule.cmobjects.filter(id=id).first()
            serializer = InvoiceScheduleSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = InvoiceSchedule.cmobjects.select_related(
            "organization", "project"
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = InvoiceScheduleSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = InvoiceScheduleSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Invoice Schedule entry
        """
        request.data['created_by'] = request.user.id
        serializer = InvoiceScheduleSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created.',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete an Invoice Schedule entry
        """
        method = request.query_params.get('method', '').lower()
        id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            details = InvoiceSchedule.cmobjects.filter(pk=id, organization_id=organization_id).first()

            if not details:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            if method == 'edit':
                request.data['updated_by'] = request.user.id
                serializer = InvoiceScheduleSerializer(details, data=request.data, partial=True, context={'request': request})

                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})

                    return Response(
                        {'results': serializer.data,
                         'msg': 'Successfully updated.',
                         'status': status.HTTP_202_ACCEPTED,
                         "request_status": 1})
                raise APIException({'request_status': 0, 'msg': serializer.errors})

            elif method == 'delete':
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()

                return Response({
                    'results': {'Data': InvoiceSchedule.objects.filter(pk=id, organization_id=organization_id).values()},
                    'msg': 'Successfully deleted.',
                    "request_status": 1
                })

            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

class InvoiceScheduleItemsAPIView(APIView):
    """
    CRUD API for Invoice Schedule Items
    """
    
    

    def get(self, request):
        """
        Retrieve Invoice Schedule Items details
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = InvoiceScheduleItems.cmobjects.filter(id=id).first()
            serializer = InvoiceScheduleItemsSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = InvoiceScheduleItems.cmobjects.select_related(
            "organization", "invoice_schedule", "parent"
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = InvoiceScheduleItemsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = InvoiceScheduleItemsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Invoice Schedule Item
        """
        request.data['created_by'] = request.user.id
        serializer = InvoiceScheduleItemsSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created.',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete an Invoice Schedule Item
        """
        method = request.query_params.get('method', '').lower()
        id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            details = InvoiceScheduleItems.cmobjects.filter(pk=id, organization_id=organization_id).first()

            if not details:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            if method == 'edit':
                request.data['updated_by'] = request.user.id
                serializer = InvoiceScheduleItemsSerializer(details, data=request.data, partial=True, context={'request': request})

                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})

                    return Response(
                        {'results': serializer.data,
                         'msg': 'Successfully updated.',
                         'status': status.HTTP_202_ACCEPTED,
                         "request_status": 1})
                raise APIException({'request_status': 0, 'msg': serializer.errors})

            elif method == 'delete':
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()

                return Response({
                    'results': {'Data': InvoiceScheduleItems.objects.filter(pk=id, organization_id=organization_id).values()},
                    'msg': 'Successfully deleted.',
                    "request_status": 1
                })

            else:
                raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})            
            

class InvoiceScheduleWBSTagAPIView(APIView):
    """
    CRUD API for InvoiceScheduleWBSTag - Bulk create and update
    """
    
    

    def get(self, request):
        """
        Get a list of InvoiceScheduleWBSTag
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = InvoiceScheduleWBSTag.cmobjects.filter(id=id).first()
            serializer = InvoiceScheduleWBSTagSerializer(_details)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = InvoiceScheduleWBSTag.cmobjects.select_related(
            'organization', 'invoice_schedule_items', 'wbs'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = InvoiceScheduleWBSTagSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = InvoiceScheduleWBSTagSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Bulk Create & Update InvoiceScheduleWBSTag Data
        """
        request_data = request.data if isinstance(request.data, list) else [request.data]
        results = {"success": [], "errors": []}

        with transaction.atomic():
            try:
                for data in request_data:
                    serializer = None

                    if 'id' in data:
                        instance = InvoiceScheduleWBSTag.cmobjects.filter(pk=data['id']).first()
                        data['updated_by'] = request.user.id
                        serializer = InvoiceScheduleWBSTagSerializer(instance, data=data, partial=True, context={'request': request})
                    else:
                        data['created_by'] = request.user.id
                        serializer = InvoiceScheduleWBSTagSerializer(data=data, context={'request': request})

                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": data,
                            "error": serializer.errors,
                            "msg": "Validation failed"
                        })

            except Exception as e:
                results["errors"].append({
                    "error": str(e),
                    "msg": "Something went wrong. If the problem persists, please contact support."
                })

        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })

    def put(self, request):
        """
        Delete InvoiceScheduleWBSTag Entry
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)

        with transaction.atomic():
            if method and method.lower() == 'delete' and id and organization_id:
                instance = InvoiceScheduleWBSTag.cmobjects.filter(pk=id, organization_id=organization_id).first()
                if instance:
                    instance.is_deleted = True
                    instance.updated_by_id = request.user.id
                    instance.save()
                    return Response({
                        'results': {'Data': InvoiceScheduleWBSTag.objects.filter(pk=id).values()},
                        'msg': 'Successfully deleted.',
                        "request_status": 1
                    })
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})


# Multiple Delete During Unselect Items
class InvoiceScheduleWBSTagAllDeleteAPIView(APIView):
    """
    API View for bulk soft-deletion of InvoiceScheduleWBSTag entries.
    """
    
    

    def put(self, request):
        method = request.query_params.get('method')
        organization_id = request.query_params.get('organization_id')

        if not method or method.lower() != 'delete':
            raise APIException({
                'request_status': 0,
                'msg': 'Invalid method. Use ?method=delete'
            })

        if not organization_id:
            raise APIException({
                'request_status': 0,
                'msg': 'Missing organization_id in query parameters.'
            })
        item_ids_raw = request.data.get('item_ids', [])

        item_ids = []

        if isinstance(item_ids_raw, str):
            try:
                item_ids = [int(x.strip()) for x in item_ids_raw.split(',') if x.strip()]
            except ValueError:
                raise APIException({
                    'request_status': 0,
                    'msg': '"item_ids" must be a list of integers or a comma-separated string of integers.'
                })

        elif isinstance(item_ids_raw, list):
            item_ids = item_ids_raw
        else:
            raise APIException({
                'request_status': 0,
                'msg': '"item_ids" must be a list or comma-separated string of integers.'
            })

        if not item_ids:
            raise APIException({
                'request_status': 0,
                'msg': '"item_ids" cannot be empty.'
            })

        with transaction.atomic():
            instances = InvoiceScheduleWBSTag.cmobjects.filter(
                pk__in=item_ids,
                organization_id=organization_id
            )

            if not instances.exists():
                raise APIException({
                    'request_status': 0,
                    'msg': 'No valid records found to delete.'
                })

            updated_count = instances.update(
                is_deleted=True,
                updated_by_id=request.user.id
            )

            deleted_items = InvoiceScheduleWBSTag.objects.filter(pk__in=item_ids).values()

        return Response({
            'results': {'Data': list(deleted_items)},
            'msg': f'Successfully deleted {updated_count} item(s).',
            'request_status': 1
        })

class InvoiceScheduleCertifiedFTMAPIView(APIView):
    """
    API for InvoiceScheduleCertifiedFTM 
    """
    
    

    def get(self, request):
        """
        Get a list of InvoiceScheduleCertifiedFTM
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = InvoiceScheduleCertifiedFTM.cmobjects.filter(id=id).first()
            serializer = InvoiceScheduleCertifiedFTMSerializer(_details)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = InvoiceScheduleCertifiedFTM.cmobjects.select_related(
            'organization', 'invoice_schedule_items',
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = InvoiceScheduleCertifiedFTMSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = InvoiceScheduleCertifiedFTMSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
       
        organization_id = request.data.get('organization',None)
        date = request.data.get('date',None)
        invoice_schedule_items_id = request.data.get('invoice_schedule_items',None)

        try:
            if not all([date, organization_id, invoice_schedule_items_id]):
                raise APIException({'request_status': 0, 'msg': 'date, organization, and invoice_schedule_items are required.'})
            instance = InvoiceScheduleCertifiedFTM.cmobjects.filter(
                organization_id=organization_id,
                date=date,
                invoice_schedule_items_id=invoice_schedule_items_id
            ).first()
            if instance:
                request.data['updated_by'] = request.user.id
                serializer = InvoiceScheduleCertifiedFTMSerializer(instance, data=request.data, partial=True, context={'request': request})
            else:
                request.data['created_by'] = request.user.id
                serializer = InvoiceScheduleCertifiedFTMSerializer(data=request.data, context={'request': request})
            if serializer.is_valid():
                serializer.save()
                return Response({
                    'results': {'Data': serializer.data},
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1
                })
            else:
                raise APIException({'request_status': 0, 'msg': serializer.errors})

        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})

 


class BOQMonthlyPlanningDataImportAPIView(APIView):
    """
    Details API for BOQMonthlyPlanningData Import
    """
    
    
    
    def post(self, request, *args, **kwargs):
        try:

            with transaction.atomic():
                count_data = {'wbs_add': 0, 'wbs_edit': 0, 'executive_add_edit': 0}
                organization_id = self.request.query_params.get('organization_id', None)
                boq_id = self.request.query_params.get('boq_id', None)
                wbs_list_id = self.request.query_params.get('wbs_list_id', None)
                date = self.request.query_params.get('date', None)

                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                if organization_id is None or boq_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID or BOQ ID not provided"})
                
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")
                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})
                
                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x
                
                return_list = []
                parent_list = list(set(list(WBSList.cmobjects.filter(pk=wbs_list_id,organization_id=organization_id,boq_id=boq_id,boq__is_deleted=False).values_list('id', flat=True))))
                all_list = WBSList.cmobjects.values()
                return_list = get_all_child(parent_list,return_list,all_list)

                chainage_code_list = pd.DataFrame(BOQChainageExecutiveSummeryData.cmobjects.filter(organization_id=organization_id,boq_id=boq_id,wbs__in=return_list,type='C',boq__is_deleted=False,wbs__is_deleted=False,form__is_deleted=False).values('wbs','form','value','wbs__parent'))
                
                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                    

                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                
                chainage_code_list = chainage_code_list.fillna(np.nan).replace([np.nan], [None])
                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)

                chainage_code_list = chainage_code_list.applymap(lambda x: process_str(x))
                sheet_xlsx[field_map['value']] = pd.to_numeric(sheet_xlsx[field_map['value']], errors='coerce')
                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                chainage_code_list = chainage_code_list.replace([np.nan], [None])
    
                def convert_pattern(code,parent=False):
                    # print(code)
                    try:
                        code_arr = process_str(code).split("-")
                        code_arr[int(code_arr.index("cp"))+1] = r'\d{2}'
                        if parent:
                            code_arr.pop()
                        code = '-'.join(code_arr)
                    except Exception as e:
                        print(e)
                    # print(code)
                    return code
                
                def check_wbs_list(row):
                    result = None
                    if 'value' in chainage_code_list and row[field_map['chainage_wbs_code']]:
                        temp = list(chainage_code_list.loc[chainage_code_list['value'].str.contains(r'^'+convert_pattern(row[field_map['chainage_wbs_code']], False)+'$')]['wbs'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                
                sheet_xlsx['wbs_id'] = sheet_xlsx.apply(lambda row: check_wbs_list(row), axis=1)

                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                for index, row in sheet_xlsx.iterrows():
                    if sheet_xlsx.at[index, field_map['chainage_wbs_code']]:
                        data = {
                            'organization_id': organization_id,
                            'boq_id': boq_id,
                            'wbs_id': sheet_xlsx.at[index, 'wbs_id'],
                            'date': date
                        }

                        BOQMonthlyPlanningData.objects.update_or_create(**data, defaults={'value' : row[field_map['value']] if row[field_map['value']] else 0.0, 'created_by' : self.request.user, 'is_latest': True})
                        count_data['executive_add_edit'] += 1


                # print(sheet_xlsx)
                return Response(
                    {'results': {
                        'Data': count_data,
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
    
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})
        


# BOQ INVOICE SCHEDULE IMPORT API
class BOQInvoiceScheduleImportAPIView(APIView):
    """
    API view to import invoice schedule items from an Excel file.
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {
                    'items_created': 0,
                    'items_updated': 0,
                    'errors': 0,
                }

                organization_id = request.query_params.get('organization_id')
                invoice_schedule_id = request.query_params.get('invoice_schedule_id')

                if not organization_id or not invoice_schedule_id:
                    raise APIException({
                        'request_status': 0,
                        'msg': 'Missing required query parameters: organization_id or invoice_schedule_id'
                    })

                try:
                    invoice_schedule = InvoiceSchedule.objects.get(
                        id=invoice_schedule_id,
                        organization_id=organization_id
                    )
                except InvoiceSchedule.DoesNotExist:
                    raise APIException({
                        'request_status': 0,
                        'msg': 'Invalid Invoice Schedule or Organization ID'
                    })

                file_name = request.data.get('file_name')
                field_map = request.data.get('field_map', {})

                path = os.path.join('media', 'excel', file_name)
                if not os.path.exists(path):
                    raise APIException("File not found")

                sheet_xlsx = pd.read_excel(path)
                if sheet_xlsx.empty:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                for column in field_map.values():
                    if column not in sheet_xlsx.columns:
                        sheet_xlsx[column] = np.nan

                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])

                if 'quantity' in field_map:
                    sheet_xlsx[field_map['quantity']] = pd.to_numeric(
                        sheet_xlsx[field_map['quantity']], errors='coerce'
                    )

                if 'rate' in field_map:
                    sheet_xlsx[field_map['rate']] = pd.to_numeric(
                        sheet_xlsx[field_map['rate']], errors='coerce'
                    )

                name_col = field_map.get('name')
                if name_col:
                    sheet_xlsx = sheet_xlsx[
                        sheet_xlsx[name_col].notna() & (sheet_xlsx[name_col].astype(str).str.strip() != "")
                    ].reset_index(drop=True)

                for index, row in sheet_xlsx.iterrows():
                    try:
                        code = row.get(field_map.get('code'))
                        name = row.get(field_map.get('name'))
                        uom = row.get(field_map.get('uom'))
                        quantity = row.get(field_map.get('quantity'), 0) or 0.0
                        rate = row.get(field_map.get('rate'), 0) or 0.0
                        parent_name = row.get(field_map.get('parent'))

                        if not name:
                            count_data['errors'] += 1
                            continue

                        quantity = row.get(field_map.get('quantity'))
                        if pd.isna(quantity):
                            quantity = 0.0  

                        rate = row.get(field_map.get('rate'))
                        if pd.isna(rate):
                            rate = 0.0 

                        parent = None
                        if parent_name:
                            parent = InvoiceScheduleItems.cmobjects.filter(
                                invoice_schedule=invoice_schedule,
                                organization_id=organization_id,
                                name__iexact=parent_name
                            ).first()
                        
                        item_data = {
                            'parent': parent,
                            'code': code,
                            'name': name,
                            'uom': uom,
                            'quantity': float(quantity),
                            'rate': float(rate),
                            'updated_by_id': request.user.id,
                        }

                        obj, created = InvoiceScheduleItems.cmobjects.update_or_create(
                            invoice_schedule=invoice_schedule,
                            organization_id=organization_id,
                            code=code, 
                            defaults=item_data
                        )

                        if created:
                            obj.created_by = self.request.user
                            obj.save(update_fields=['created_by'])
                            count_data['items_created'] += 1
                        else:
                            count_data['items_updated'] += 1


                    except Exception as e:
                        count_data['errors'] += 1
                        continue

                return Response({
                    'request_status': 1,
                    'msg': 'Data imported successfully',
                    'data': count_data,
                }, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({
                'request_status': 0,
                'msg': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)
        
        
class BOQMonthlyProgressDataAPIView(APIView):
    """
    GET API for BOQMonthlyProgressData 
    """
    
    

    def get(self, request):
        """
        Get a list of BOQMonthlyProgressData
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = BOQMonthlyProgressData.cmobjects.filter(id=id).first()
            serializer = BOQMonthlyProgressDataSerializer(_details)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = BOQMonthlyProgressData.cmobjects.select_related(
            'organization', 'planning_tender', 'boq', 'wbs'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = BOQMonthlyProgressDataSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BOQMonthlyProgressDataSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create or update BOQMonthlyProgressData .
        """
        new_data = request.data
        if not isinstance(new_data, list):
            new_data = [new_data]

        results = {"success": [], "errors": []}

        with transaction.atomic():
            for data in new_data:
                try:
                    organization_id = data.get("organization")
                    wbs_id = data.get("wbs")
                    date = data.get("date")

                    if not (organization_id and wbs_id and date):
                        results["errors"].append({
                            "data": data,
                            "error": "Fields 'organization', 'wbs', and 'date' are required.",
                            "msg": "Missing required fields"
                        })
                        continue

                    defaults = {
                        "planning_tender_id": data.get("planning_tender",None),
                        "boq_id": data.get("boq",None),
                        "value": data.get("value",None),
                        "updated_by_id": request.user.id,
                    }

                    obj, created = BOQMonthlyProgressData.cmobjects.update_or_create(
                        organization_id=organization_id,
                        wbs_id=wbs_id,
                        date=date,
                        defaults=defaults
                    )

                    if created:
                        obj.created_by_id = request.user.id
                        obj.save()

                    serializer = BOQMonthlyProgressDataSerializer(obj)
                    results["success"].append({
                        "data": serializer.data,
                        "msg": "Successfully created" if created else "Successfully updated"
                    })

                except Exception as e:
                    results["errors"].append({
                        "data": data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })

        return Response({
            "results": results,
            "status": status.HTTP_201_CREATED,
            "request_status": 1
        })
    def put(self, request):
        """
        Delete BOQMonthlyProgressData Entry
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)

        with transaction.atomic():
            if method and method.lower() == 'delete' and id and organization_id:
                instance = BOQMonthlyProgressData.cmobjects.filter(pk=id, organization_id=organization_id).first()
                if instance:
                    instance.is_deleted = True
                    instance.updated_by_id = request.user.id
                    instance.save()
                    return Response({
                        'results': {'Data': BOQMonthlyProgressData.objects.filter(pk=id).values()},
                        'msg': 'Successfully deleted.',
                        "request_status": 1
                    })
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})





# BOQ Monthly Cost Data
class BOQMonthlyCostDataAPIView(APIView):
    """
    CRUD API for BOQMonthlyCostData
    """
    
    
    
    def get(self, request):
        """
        Get a list of BOQMonthlyCostData
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            instance = BOQMonthlyCostData.cmobjects.filter(id=id).first()
            serializer = BOQMonthlyCostDataSerializer(instance)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])
        _list = BOQMonthlyCostData.objects.select_related('organization', 'boq').filter(*search).order_by(*order_by.split(","))

        if all == 'true':
            serializer = BOQMonthlyCostDataSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BOQMonthlyCostDataSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new BOQMonthlyCostData
        """
        request.data['created_by'] = request.user.id
        serializer = BOQMonthlyCostDataSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a BOQMonthlyCostData
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        entry_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if BOQMonthlyCostData.cmobjects.filter(pk=entry_id, organization_id=organization_id).exists():
                    details = BOQMonthlyCostData.objects.filter(pk=entry_id,organization_id=organization_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = BOQMonthlyCostDataSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if BOQMonthlyCostData.cmobjects.filter(pk=entry_id, organization_id=organization_id).exists():
                    details = BOQMonthlyCostData.objects.filter(pk=entry_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'Data': BOQMonthlyCostData.objects.filter(pk=entry_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class BOQInvoiceScheduleReportAPIView(APIView):
   
    
    

    def get(self, request, format=None):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        ref_date = request.query_params.get('ref_date', datetime.today().strftime('%Y-%m-%d'))
        search = custom_filters(request, {}, ['ref_date'])
        ref_date = datetime.strptime(ref_date, '%Y-%m-%d')
        # print(ref_date)
        first_date = ref_date - timedelta(days=int(ref_date.strftime("%d")) - 1)
        # print(first_date)
        _list = InvoiceScheduleItems.cmobjects.annotate(
                # invoice_schedule__date=Subquery(InvoiceSchedule.cmobjects.filter(
                #     id=OuterRef('invoice_schedule__pk')
                # ).values('date')),
                wbs__budgeted_quantity = Coalesce(Sum(Subquery(
                    WBSList.cmobjects.filter(
                        id=OuterRef('boq_invoice_schedule_wbs_tag_invoice_schedule_items__wbs__pk'),
                        ).values('id').annotate(
                            value=Sum('budgeted_quantity')
                        ).values('value')
                )), Value(0), output_field=FloatField()),
                ref_date__quantity = Coalesce(Sum(Subquery(
                    BOQMonthlyProgressData.cmobjects.filter(
                        wbs_id=OuterRef('boq_invoice_schedule_wbs_tag_invoice_schedule_items__wbs__pk'),
                        date=ref_date,
                        ).values('wbs').annotate(
                            final_value=Sum('value')
                        ).values('final_value')
                )), Value(0), output_field=FloatField()),## progress for the day qty(in dpr)
                till_ref_date__quantity = Coalesce(Sum(Subquery(
                    BOQMonthlyProgressData.cmobjects.filter(
                        wbs_id=OuterRef('boq_invoice_schedule_wbs_tag_invoice_schedule_items__wbs__pk'),
                        date__lt=ref_date,
                        date__gte=first_date,
                        ).values('wbs').annotate(
                            final_value=Sum('value')
                        ).values('final_value')
                )), Value(0), output_field=FloatField()),
                till_last_month__quantity = Coalesce(Sum(Subquery(
                    BOQMonthlyProgressData.cmobjects.filter(
                        wbs_id=OuterRef('boq_invoice_schedule_wbs_tag_invoice_schedule_items__wbs__pk'),
                        date__lt=first_date,
                        ).values('wbs').annotate(
                            final_value=Sum('value')
                        ).values('final_value')
                )), Value(0), output_field=FloatField()),
                planned__quantity = Coalesce(Sum(Subquery(
                    BOQMonthlyPlanningData.cmobjects.filter(
                        wbs_id=OuterRef('boq_invoice_schedule_wbs_tag_invoice_schedule_items__wbs__pk'),
                        date=first_date,
                        ).values('wbs').annotate(
                            final_value=Sum('value')
                        ).values('final_value')
                    )), Value(0), output_field=FloatField()),
                current_planned__quantity = Coalesce(Sum(Subquery(
                    BOQMonthlyPlanningData.cmobjects.filter(
                        wbs_id=OuterRef('boq_invoice_schedule_wbs_tag_invoice_schedule_items__wbs__pk'),
                        date=first_date,
                        ).values('wbs').annotate(
                            final_value=Sum('current_value')
                        ).values('final_value')
                    )), Value(0), output_field=FloatField()),## current plan qty(in dpr),
                wbs_count=Coalesce(
                    Subquery(
                        InvoiceScheduleWBSTag.cmobjects
                        .filter(invoice_schedule_items_id=OuterRef('pk'))
                        .values('invoice_schedule_items')
                        .annotate(value=Count('wbs', distinct=True))
                        .values('value')
                    ),
                    Value(0), output_field=IntegerField()
                ),
                total_wbs_wise_quantity=Case(
                    When(
                        wbs_count__gt=0,
                        then=Coalesce(
                            Subquery(
                                InvoiceScheduleWBSTag.cmobjects
                                .filter(invoice_schedule_items_id=OuterRef('pk'))
                                .values('invoice_schedule_items')
                                .annotate(total=Sum('invoice_schedule_items__quantity'))
                                .values('total')
                            ),
                            Value(0), output_field=FloatField()
                        )
                    ),
                    default=F('quantity'),
                    output_field=FloatField()
                ),
                certified_ftm__quantity = Coalesce(
                    Subquery(
                        InvoiceScheduleCertifiedFTM.cmobjects.filter(
                            invoice_schedule_items_id=OuterRef('pk'),
                            date=first_date
                        ).values('invoice_schedule_items')
                        .annotate(total=Sum('quantity'))
                        .values('total')
                    ),
                    Value(0), output_field=FloatField()
                )

                ).filter(*search).values(
                    'id', 'name', 'code', 'uom','quantity','rate',
                    'parent',
                    # 'invoice_schedule__date', 
                    'ref_date__quantity', 'till_ref_date__quantity', 'till_last_month__quantity',
                    'wbs__budgeted_quantity','planned__quantity','current_planned__quantity',
                    'total_wbs_wise_quantity','certified_ftm__quantity','invoice_schedule__version',
                    # 'boq_invoice_schedule_wbs_tag_invoice_schedule_items__wbs_id'
                ).order_by(*order_by.split(","))
        if all == 'true':
            return Response({'results': _list})

        page_size = int(request.query_params.get('page_size', 10))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': list(page.object_list),
        })
    