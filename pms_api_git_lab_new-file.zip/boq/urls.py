from django.urls import path
from boq import views


urlpatterns = [

    path('boq/', views.BOQAPIView.as_view()),
    path('wbs-list/', views.WBSListAPIView.as_view()),
    path('wbs-list-new/', views.WBSListNewAPIView.as_view()),
    path('wbs-labour/', views.WBSLabourAPIView.as_view()),
    path('wbs-material/', views.WBSMaterialAPIView.as_view()),
    path('wbs-plant-machinery/', views.WBSPlantMachineryAPIView.as_view()),
    path('wbs-indirect-cost/', views.WBSIndirectCostAPIView.as_view()),
    path('wbs-indirect-cost-planing/', views.WbsIndirectCostPlaningAPIView.as_view()), # new
    path('wbs-temp-planing/', views.WbsTempPlaningAPIView.as_view()),
    path('wbs-list-details/', views.WBSListDetailsAPIView.as_view()),
    path('schedule-h/', views.ScheduleHAPIView.as_view()),
    path('boq-chainage-executive-summery/', views.BOQChainageExecutiveSummeryDataAPIView.as_view()),
    path('boq-monthly-planning/', views.BOQMonthlyPlanningDataAPIView.as_view()),
    path('boq-chainage/', views.BOQChainageAPIView.as_view()),
    path('boq-import/', views.BOQImportAPIView.as_view()),
    path('boq-wbs-import/', views.BOQWBSImportAPIView.as_view()),
    path('planning-tender-link/', views.PlanningTenderAPIView.as_view()),
    path('boq-material-report/', views.BOQMaterialReportAPIView.as_view()),
    # path('check-boq-replicate/', views.CheckBoqReplicateAPIView.as_view()),
    path('boq-drawing-tracker/', views.DrawingTrackerAPIView.as_view()),
    path('boq-drawing-category/', views.DrawingCategoryAPIView.as_view()),
    path('boq-drawing-tracker-bulk-import/', views.DrawingTrackerBulkImportAPIView.as_view()),
    # path('boq-drawing-tracker-bulk-import-new/', views.DrawingTrackerBulkImportNewAPIView.as_view()),
    path('boq-wbs-gantt/', views.WBSGanttAPIView.as_view()),
    path('boq-invoice-schedule/', views.InvoiceScheduleAPIView.as_view()),
    path('boq-invoice-schedule-items/', views.InvoiceScheduleItemsAPIView.as_view()),
    path('boq-invoice-schedule-wbs-tag/', views.InvoiceScheduleWBSTagAPIView.as_view()),
    path('boq-invoice-schedule-wbs-tag-delete-all/', views.InvoiceScheduleWBSTagAllDeleteAPIView.as_view()),
    path('boq-monthly-planning-import/', views.BOQMonthlyPlanningDataImportAPIView.as_view()),
    path('boq-invoice-schedule-report/', views.BOQInvoiceScheduleReportAPIView.as_view()),
    path('boq-invoice-schedule-certified-ftm/', views.InvoiceScheduleCertifiedFTMAPIView.as_view()),
    # Invoice Schedule Items Import
    path('boq-invoice-schedule-import/', views.BOQInvoiceScheduleImportAPIView.as_view()),
    path('boq-monthly-progress-data/', views.BOQMonthlyProgressDataAPIView.as_view()),
    

    
    path('boq-monthly-cost-data/', views.BOQMonthlyCostDataAPIView.as_view()),


]