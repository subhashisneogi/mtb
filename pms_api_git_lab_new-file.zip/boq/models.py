from django.db import models
from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from administrations.models import *
from tender.models import *
from project_and_planning.models import *
from material_master.models import *
from labour_master.models import *
from plant_machinery.models import PlantMachineryMachine,PlantMachineryGroup
from indirect_cost_master.models import *

# Create your models here.

class PlanningTender(BaseAbstractStructure):
    """
    Planning Tender
    """
    organization = models.ForeignKey(Organization, related_name='boq_planning_tender_organization',
                                     on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='boq_planning_tender_project', on_delete=models.CASCADE)
    tender = models.ForeignKey(TenderMasterNew, related_name='boq_planning_tender_tender', on_delete=models.CASCADE,
                              null=True, blank=True)


    class Meta:
        unique_together = ('organization','project',)
        db_table = "boq_planning_tender"

class BOQ(BaseAbstractStructure):
    """
    BOQ Master
    """
    STATUS = (
        ('pending', 'Pending for approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('cancelled', 'Cancelled'),
    )
    organization = models.ForeignKey(Organization, related_name='boq_organization',
                                     on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='boq_project', on_delete=models.CASCADE)
    status = models.CharField(max_length=150, choices=STATUS, blank=True, null=True, default="pending")
    name = models.CharField(max_length=255)
    version = models.IntegerField(default=1)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    approver = models.ManyToManyField(PmsUser, null=True, blank=True)
    parent_tender = models.ForeignKey(TenderMasterNew, related_name='boq_parent_tender', on_delete=models.CASCADE, null=True, blank=True)
    parent_boq = models.ForeignKey('self', related_name='boq_parent_boq', on_delete=models.CASCADE, null=True, blank=True)
    parent_planning_tender = models.ForeignKey(PlanningTender, related_name='boq_parent_planning_tender', on_delete=models.CASCADE, null=True, blank=True)
    source = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return str(self.name)

    class Meta:
        unique_together = ('organization','project','name',)
        db_table = "boq"

class BOQApprovalDetails(BaseAbstractStructure):
    """
    BOQApprovalDetails
    """
    STATUS = (
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('cancelled', 'Cancelled'),
    )
    organization = models.ForeignKey(Organization, related_name='boq_approval_details_organization', on_delete=models.CASCADE, null=True, blank=True)
    boq = models.ForeignKey(BOQ, related_name='boq_approval_details_boq', on_delete=models.CASCADE, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=150,choices=STATUS, blank=True, null=True, default="approved")

    def __str__(self):
        return str(self.boq)

    class Meta:
        db_table = "boq_approval_details"




class WBSList(BaseAbstractStructure):
    """
    List for WBS for Tender/BOQ
    """
    CATEGORY = (
        ('highway', 'Highway'),
        ('structure', 'Structure'),
        ('volumetric', 'Volumetric'),
        ('others', 'Others'),
    )
    organization = models.ForeignKey(Organization, related_name='wbs_list_organization', on_delete=models.CASCADE)
    category = models.CharField(max_length=100, choices=CATEGORY, default='highway')
    by_order = models.IntegerField(default=1)
    after_this = models.ForeignKey('self', related_name="boq_wbs_after_this", on_delete=models.CASCADE, null=True, blank=True)
    boq_code = models.CharField(max_length=255,null=True, blank=True)
    boq_no = models.CharField(max_length=255,null=True, blank=True)
    #wbs = models.ForeignKey(TenderWBSKeyScopes, related_name='wbs_list_wbs_key_scopes', on_delete=models.DO_NOTHING)
    wbs = models.TextField()
    planning_tender = models.ForeignKey(PlanningTender, related_name='boq_planning_tender', on_delete=models.CASCADE, null=True, blank=True)
    boq = models.ForeignKey(BOQ, related_name='wbs_list_boq', on_delete=models.CASCADE,
                             null=True, blank=True)
    tender = models.ForeignKey(TenderMasterNew, related_name='wbs_list_tender', on_delete=models.CASCADE,
                              null=True, blank=True)
    parent = models.ForeignKey('self', related_name='wbs_list_parent', on_delete=models.CASCADE,
                              null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='wbs_list_uom', on_delete=models.CASCADE,
                              null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    priority = models.CharField(max_length=255,null=True, blank=True)
    short_name = models.CharField(max_length=255,null=True, blank=True)
    opening_done_quantity = models.FloatField(default=0)
    opening_undone_quantity = models.FloatField(default=0)
    tender_quantity = models.CharField(max_length=255,null=True, blank=True)
    budgeted_quantity = models.FloatField(default=0)
    ra_bill_rate = models.FloatField(default=0)
    escalation_type = models.CharField(max_length=255,null=True, blank=True)
    escalation_per = models.FloatField(default=0)
    bidding_type = models.CharField(max_length=255,null=True, blank=True)
    bidding_per = models.FloatField(default=0)
    rate = models.CharField(max_length=255,null=True, blank=True)
    cost = models.CharField(max_length=255,null=True, blank=True)
    manual_rate = models.FloatField(default=0)
    manual_cost = models.FloatField(default=0)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    duration = models.FloatField(default=0)
    replicate_from = models.CharField(max_length=255,null=True, blank=True)
    total_labour = models.CharField(max_length=255,null=True, blank=True)
    total_material = models.CharField(max_length=255,null=True, blank=True)
    total_machinery = models.CharField(max_length=255,null=True, blank=True)
    total_overheads = models.CharField(max_length=255,null=True, blank=True)
    root = models.ForeignKey('self', related_name='root_node', on_delete=models.CASCADE,null=True, blank=True)
    
    def clean(self):
        # if self.boq is None and self.tender is None and self.planning_tender is None:
        #     raise ValidationError("Either boq or planning_tender must be specified, but not both.")
        # elif self.boq is not None and self.tender is not None and self.planning_tender is not None:
        #     raise ValidationError("Both boq and planning_tender cannot be specified simultaneously.")

        # Check if more than one field is specified
        specified_fields = [self.boq, self.tender, self.planning_tender]
        specified_count = sum(1 for field in specified_fields if field is not None)

        if specified_count == 0:
            raise ValidationError("Either boq or tender or planning_tender must be specified.")
        elif specified_count > 1:
            raise ValidationError("Only one of boq, tender, or planning_tender can be specified.")

        super().clean()

    def save(self, *args, **kwargs):
        self.full_clean()
        # if not self.cost:
        #     self.cost = 0
        # if not self.budgeted_quantity:
        #     self.budgeted_quantity = 0
        # if self.cost != 0 and self.budgeted_quantity != 0:
        #     self.rate = float(self.cost)/float(self.budgeted_quantity)
        # else:
        #     self.rate = 0 
        
        if not self.manual_rate:
            self.manual_rate = 0
        if not self.budgeted_quantity:
            self.budgeted_quantity = 0
        if self.manual_rate != 0 and self.budgeted_quantity != 0:
            self.manual_cost = float(self.manual_rate)*float(self.budgeted_quantity)
        else:
            self.manual_cost = 0

        if self.parent:
            self.root = self.parent.root if self.parent.root else self.parent
            super().save(*args, **kwargs)
        else:
            self.root = None   
            super().save(*args, **kwargs)
            if self.root is None:
                self.root = self
                super().save(update_fields=['root'])

    def __str__(self):
        # return str(self.wbs) + " (" + str(self.category) + ") " + str(self.parent)
        return str(self.wbs)
    class Meta:
        # unique_together = ('organization','tender','boq','wbs',)
        db_table = "boq_wbs"

class BOQChainage(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_chainage_organization', on_delete=models.CASCADE)
    planning_tender = models.ForeignKey(PlanningTender, related_name='boq_chainage_planning_tender', on_delete=models.CASCADE, null=True, blank=True)
    boq = models.ForeignKey(BOQ, related_name='boq_chainage_boq',on_delete=models.CASCADE, null=True, blank=True)
    wbs = models.ForeignKey(WBSList, related_name='boq_chainage_wbs',on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    start = models.FloatField(blank=True, null=True, default=0)
    end = models.FloatField(blank=True, null=True, default=0)
    chainage_value = models.FloatField(blank=True, null=True, default=0)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.start:
            self.start = 0.
        if not self.end:
            self.end = 0.
        self.chainage_value = float(self.end)-float(self.start)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "boq_chainage"

class BOQChainageExecutiveSummeryData(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_chainage_executivesummery_organization', on_delete=models.CASCADE)
    planning_tender = models.ForeignKey(PlanningTender, related_name='boq_chainage_executive_planning_tender', on_delete=models.CASCADE, null=True, blank=True)
    boq = models.ForeignKey(BOQ, related_name='boq_chainage_executivesummery_boq',on_delete=models.CASCADE, null=True, blank=True)
    wbs = models.ForeignKey(WBSList, related_name='boq_chainage_executivesummery_wbs',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(BOQChainage, related_name='boq_chainage_executivesummery_form',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)
    type = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return str(self.value) + " (" + str(self.type) + ") "

    class Meta:
        db_table = "boq_chainage_executivesummery"

class BOQMonthlyPlanningData(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_monthly_planning_organization', on_delete=models.CASCADE)
    planning_tender = models.ForeignKey(PlanningTender, related_name='boq_monthly_planning_planning_tender', on_delete=models.CASCADE, null=True, blank=True)
    boq = models.ForeignKey(BOQ, related_name='boq_monthly_planning_boq',on_delete=models.CASCADE, null=True, blank=True)
    wbs = models.ForeignKey(WBSList, related_name='boq_monthly_planning_wbs',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(BOQChainage, related_name='boq_monthly_planning_form',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)
    current_value = models.CharField(max_length=200, blank=True, null=True)
    date = models.DateField(null=True, blank=True)
    side = models.CharField(max_length=200, blank=True, null=True)
    is_latest = models.BooleanField(default=True)

    version = models.IntegerField(default=1)
    previous_version = models.ForeignKey('self', related_name='boq_monthly_planning_previous_version', on_delete=models.CASCADE, 
                                         null=True, blank=True)

    class Meta:
        db_table = "boq_monthly_planning"

class WBSExtraFields(models.Model):
    chainage = models.ForeignKey(BOQChainage, related_name='+', on_delete=models.CASCADE, blank=True, null=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='+', on_delete=models.CASCADE, blank=True, null=True)
    quantity = models.FloatField(default=0)
    quantity_without_wastage = models.FloatField(default=0)
    wastage = models.FloatField(default=0)
    budgeted_quantity = models.FloatField(default=0)
    consumed_quantity = models.FloatField(default=0)
    balance_quantity = models.FloatField(default=0)

    productivity = models.FloatField(default=0)
    working_hrs_km = models.FloatField(default=0)
    efficiency_loss_monsoon = models.FloatField(default=0)
    efficiency_normal_condn = models.FloatField(default=0)
    fuel_efficiency = models.FloatField(default=0)
    working_hrs_km_considering_efficiency = models.FloatField(default=0)
    working_hrs_of_fuel_considering_efficiency = models.FloatField(default=0)
    hsd_rate = models.FloatField(default=0)
    fuel_norms = models.FloatField(default=0)
    fuel_cost = models.FloatField(default=0)
    fuel_unit_cost = models.FloatField(default=0)
    working_hrs_per_month = models.FloatField(default=0)
    machine_rental_depreciation_charges_per_month = models.FloatField(default=0)
    machine_rental_depreciation_cost_per_uom = models.FloatField(default=0)
    machinery_cost = models.FloatField(default=0)
    machinery_unit_cost = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    cost = models.FloatField(default=0)
    
    class Meta:
        abstract = True
        ordering = ('id',)
    
    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.quantity:
            self.quantity = 0
        if not self.quantity_without_wastage:
            self.quantity_without_wastage = 0
        if not self.wastage:
            self.wastage = 0
        if not self.budgeted_quantity:
            self.budgeted_quantity = 0
        if not self.consumed_quantity:
            self.consumed_quantity = 0
        if not self.cost:
            self.cost = 0
        
        if not self.productivity:
            self.productivity = 0
        if not self.working_hrs_km:
            self.working_hrs_km = 0
        if not self.efficiency_loss_monsoon:
            self.efficiency_loss_monsoon = 0
        if not self.efficiency_normal_condn:
            self.efficiency_normal_condn = 0
        if not self.fuel_efficiency:
            self.fuel_efficiency = 0
        if not self.working_hrs_km_considering_efficiency:
            self.working_hrs_km_considering_efficiency = 0
        if not self.working_hrs_of_fuel_considering_efficiency:
            self.working_hrs_of_fuel_considering_efficiency = 0
        if not self.hsd_rate:
            self.hsd_rate = 0
        if not self.fuel_norms:
            self.fuel_norms = 0
        if not self.fuel_cost:
            self.fuel_cost = 0
        if not self.fuel_unit_cost:
            self.fuel_unit_cost = 0
        if not self.working_hrs_per_month:
            self.working_hrs_per_month = 0
        if not self.machine_rental_depreciation_charges_per_month:
            self.machine_rental_depreciation_charges_per_month = 0
        if not self.machine_rental_depreciation_cost_per_uom:
            self.machine_rental_depreciation_cost_per_uom = 0
        if not self.machinery_cost:
            self.machinery_cost = 0
        if not self.machinery_unit_cost:
            self.machinery_unit_cost = 0
        # if not self.total_unit_cost:
        #     self.total_unit_cost = 0

        self.balance_quantity = float(self.budgeted_quantity)-float(self.consumed_quantity)
        super().save(*args, **kwargs)

class WBSLabour(BaseAbstractStructure,WBSExtraFields):
    """
    Labour for WBS
    """
    organization = models.ForeignKey(Organization, related_name='wbs_labour_organization', on_delete=models.CASCADE)
    wbs_list = models.ForeignKey(WBSList, related_name='wbs_labour_wbs_list', on_delete=models.CASCADE)
    labour = models.ForeignKey(LabourMaster, related_name='wbs_labour_labour', on_delete=models.CASCADE)

    def __str__(self):
        return str(self.labour.name) + ' ( ' + str(self.wbs_list.wbs) + ' )'

    class Meta:
        # unique_together = ('organization','labour','wbs_list',)
        db_table = "boq_wbs_labour"

class WBSMaterial(BaseAbstractStructure,WBSExtraFields):
    """
    Material for WBS
    """
    organization = models.ForeignKey(Organization, related_name='wbs_material_organization', on_delete=models.CASCADE)
    wbs_list = models.ForeignKey(WBSList, related_name='wbs_material_wbs_list', on_delete=models.CASCADE)
    material = models.ForeignKey(VendorMaterialMaster, related_name='wbs_material_material', on_delete=models.CASCADE)

    def __str__(self):
        return str(self.material.material_name) + ' ( ' + str(self.wbs_list.wbs) + ' )'

    class Meta:
        # unique_together = ('organization','material','wbs_list',)
        db_table = "boq_wbs_material"

class WBSPlantMachinery(BaseAbstractStructure,WBSExtraFields):
    """
    Plant Machinery for WBS
    """
    organization = models.ForeignKey(Organization, related_name='wbs_plant_machinery_organization', on_delete=models.CASCADE)
    wbs_list = models.ForeignKey(WBSList, related_name='wbs_plant_machinery_wbs_list', on_delete=models.CASCADE)
    plant_machinery = models.ForeignKey(PlantMachineryMachine, related_name='wbs_plant_machinery_plant_machinery', on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='wbs_plant_machinery_plant_machinery_group',on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        try:
            if self.plant_machinery_id:
                return str(self.plant_machinery.equipment_description) + ' ( ' + str(self.wbs_list.wbs) + ' )'
        except Exception as e:
            print('WBSPlantMachineryWBSPlantMachinery: ERROR', e)
        return '%s object (%s)' % (self.__class__.__name__, self.pk)

    class Meta:
        # unique_together = ('organization','plant_machinery','wbs_list',)
        db_table = "boq_wbs_plant_machinery"

class WBSIndirectCost(BaseAbstractStructure,WBSExtraFields):
    """
    Indirect Cost for WBS
    """
    organization = models.ForeignKey(Organization, related_name='wbs_indirect_cost_organization', on_delete=models.CASCADE)
    wbs_list = models.ForeignKey(WBSList, related_name='wbs_indirect_cost_wbs_list', on_delete=models.CASCADE)
    indirect_cost = models.ForeignKey(IndirectCostMaster, related_name='wbs_indirect_cost_indirect_cost', on_delete=models.CASCADE)

    def __str__(self):
        return str(self.indirect_cost.name) + ' ( ' + str(self.wbs_list.wbs) + ' )'

    class Meta:
        # unique_together = ('organization','indirect_cost','wbs_list',)
        db_table = "boq_wbs_indirect_cost"

class ScheduleH(BaseAbstractStructure):
    """
    Schedule H
    """
    organization = models.ForeignKey(Organization, related_name='boq_schedule_h_organization',
                                     on_delete=models.CASCADE)
    code = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return str(self.code) + ' | ' + str(self.name)

    class Meta:
        db_table = "boq_schedule_h"

class ScheduleHItems(BaseAbstractStructure):
    """
    Schedule H Items
    """
    organization = models.ForeignKey(Organization, related_name='boq_schedule_h_items_organization',
                                     on_delete=models.CASCADE)
    schedule_h = models.ForeignKey(ScheduleH, related_name='boq_schedule_h_items',
                                     on_delete=models.CASCADE, blank=True, null=True)
    parent = models.ForeignKey('self', related_name='boq_schedule_h_items_parent',
                                     on_delete=models.CASCADE, blank=True, null=True)
    code = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255)
    percentage = models.FloatField(default=0)
    amount = models.FloatField(default=0)

    def __str__(self):
        return str(self.code) + ' | ' + str(self.name)

    class Meta:
        db_table = "boq_schedule_h_items"


class WbsIndirectCostPlaning(BaseAbstractStructure):
    """
    Indirect Cost New (PMS-BOQ/BUDGET-LMPI-Discussion-MOM of the Meeting)
    """
    organization = models.ForeignKey(Organization, related_name='boq_indirect_cost_planing_organization', on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='boq_indirect_cost_planing_project', on_delete=models.CASCADE)
    parent = models.ForeignKey('self', related_name='boq_indirect_cost_planing_parent', on_delete=models.CASCADE, null=True, blank=True)
    indirect_cost = models.CharField(max_length=200, blank=True, null=True)
    wbs_code = models.CharField(max_length=200, blank=True, null=True)
    cost_value = models.FloatField(default=0.)
    cost_center = models.ForeignKey(CostCenter, related_name='boq_indirect_cost_planing_cost_center', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return str(self.pk) + ' ( ' + str(self.wbs_code) + ' - ' + str(self.cost_value) + ' )'

    class Meta:
        db_table = "boq_indirect_cost_planing"
        ordering = ('id',)


class WbsTempPlaning(BaseAbstractStructure):
    TYPE = (
        ('material', 'Material'),
        ('machinery', 'Machinery'),
    )
    organization = models.ForeignKey(Organization, related_name='boq_temp_planing_organization', on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='boq_temp_planing_project', on_delete=models.CASCADE)
    parent = models.ForeignKey('self', related_name='boq_temp_planing_parent', on_delete=models.CASCADE, null=True, blank=True)
    type = models.CharField(max_length=100, choices=TYPE, blank=True, null=True, default="material")
    temp_cost = models.CharField(max_length=200, blank=True, null=True)
    wbs_code = models.CharField(max_length=200, blank=True, null=True)
    cost_center = models.ForeignKey(CostCenter, related_name='boq_temp_planing_cost_center', on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        db_table = "boq_temp_planing"


class DrawingCategory(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_drawing_category_organization', on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='boq_drawing_category_project', on_delete=models.CASCADE)
    name = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return str(self.name)

    class Meta:
        db_table = "boq_drawing_category"


class DrawingTracker(BaseAbstractStructure):
    STATUS = (
        ('Return', 'Return'),
        ('Approved', 'Approved'),
    )
    SINPL_STATUS = (
        ('Return', 'Return'),
        ('Forward', 'Forward'),
    )
    SIDE_CHOICE = (
        ('LHS', 'LHS'),
        ('RHS', 'RHS'),
        ('BHS', 'BHS'),

    )
    organization = models.ForeignKey(Organization, related_name='boq_drawing_tracker_organization', on_delete=models.CASCADE)
    drawing_category = models.ForeignKey(DrawingCategory, related_name='boq_drawing_tracker_drawing_category', on_delete=models.CASCADE, null=True, blank=True)
    planning_tender = models.ForeignKey(PlanningTender, related_name='boq_drawing_tracker_planning_tender', on_delete=models.CASCADE, null=True, blank=True)
    boq = models.ForeignKey(BOQ, related_name='boq_drawing_tracker_boq',on_delete=models.CASCADE, null=True, blank=True)
    parent = models.ForeignKey(WBSList, related_name='boq_drawing_tracker_parent',on_delete=models.CASCADE, null=True, blank=True)
    wbs = models.ForeignKey(WBSList, related_name='boq_drawing_tracker_wbs',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(BOQChainage, related_name='boq_drawing_tracker_form',on_delete=models.CASCADE, blank=True, null=True)
    side = models.CharField(max_length=200,choices=SIDE_CHOICE, blank=True, null=True)
    title = models.CharField(max_length=200, blank=True, null=True)
    number = models.CharField(max_length=200, blank=True, null=True)
 
    # attachment = models.FileField(upload_to='boq/drawing_tracker/', null=True, blank=True)
    # mime_type = models.CharField(max_length=200, null=True, blank=True)
    # file_data = models.TextField(null=True, blank=True)

    current_version = models.IntegerField(default=0)
    initiation_date_as_per_work_order = models.DateField(null=True, blank=True)
    actual_initiation_date = models.DateField(null=True, blank=True)
    target_date_as_per_work_order = models.DateField(null=True, blank=True)
    designer_to_sinpl = models.DateField(null=True, blank=True)
    designer_to_sinpl_status = models.CharField(max_length=150, choices=SINPL_STATUS, blank=True, null=True, default="Return")
    designer_to_sinpl_remarks = models.TextField(null=True, blank=True)
    sinpl_to_proof_consultant = models.DateField(null=True, blank=True)
    sinpl_to_proof_consultant_status = models.CharField(max_length=150, choices=SINPL_STATUS, blank=True, null=True, default="Return")
    sinpl_to_proof_consultant_remarks = models.TextField(null=True, blank=True)
    proof_consultant_to_sinpl = models.DateField(null=True, blank=True)
    proof_consultant_to_sinpl_status = models.CharField(max_length=150, choices=SINPL_STATUS, blank=True, null=True, default="Return")
    proof_consultant_to_sinpl_remarks = models.TextField(null=True, blank=True)
    sinpl_to_client = models.DateField(null=True, blank=True)
    sinpl_to_client_status = models.CharField(max_length=150, choices=SINPL_STATUS, blank=True, null=True, default="Return")
    sinpl_to_client_remarks = models.TextField(null=True, blank=True)
    
    status = models.CharField(max_length=150, choices=STATUS, blank=True, null=True, default="Return")
    remarks = models.TextField(null=True, blank=True)
    final_approval_date = models.DateField(null=True, blank=True)
    
    
    class Meta:
        db_table = "boq_drawing_tracker"


class DrawingTrackerDocuments(BaseAbstractStructure):
 
    organization = models.ForeignKey(Organization, related_name='boq_drawing_tracker_documents_organization', on_delete=models.CASCADE)
    drawing_tracker = models.ForeignKey(DrawingTracker, related_name='boq_drawing_tracker_documents_drawing_tracker', on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='boq/drawing_tracker/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    is_final = models.BooleanField(default=False)
    name = models.CharField(max_length=200, null=True, blank=True)
    class Meta:
        db_table = "boq_drawing_tracker_documents"


class WBSGantt(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_wbs_gantt_organization', on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='boq_wbs_gantt_project', on_delete=models.CASCADE)
    by_order = models.IntegerField(default=1)
    boq_code = models.CharField(max_length=255,null=True, blank=True)
    boq_no = models.CharField(max_length=255,null=True, blank=True)
    wbs = models.CharField(max_length=255)
    parent = models.ForeignKey('self', related_name='boq_wbs_gantt_parent', on_delete=models.CASCADE, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='boq_wbs_gantt_uom', on_delete=models.CASCADE, null=True, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    duration = models.FloatField(default=0)
    is_activity = models.BooleanField(default=False)

    def __str__(self):
        return str(self.wbs)

    class Meta:
        db_table = "boq_wbs_gantt"


class WBSGanttDepends(BaseAbstractStructure):
    TYPE_CHOICE = (
        ('FS', 'FS'),
        ('FF', 'FF'),
        ('SF', 'SF'),
        ('SS', 'SS'),
    )
    organization = models.ForeignKey(Organization, related_name='boq_wbs_gantt_depends_organization', on_delete=models.CASCADE)
    wbs_gantt = models.ForeignKey(WBSGantt, related_name='boq_wbs_gantt_depends_wbs_gantt', on_delete=models.CASCADE, null=True, blank=True)
    linked_wbs_gantt = models.ForeignKey(WBSGantt, related_name='boq_wbs_gantt_depends_linked_wbs_gantt', on_delete=models.CASCADE, null=True, blank=True)
    linked_type = models.CharField(max_length=200,choices=TYPE_CHOICE, blank=True, null=True)
    lag = models.FloatField(default=0)

    # def __str__(self):
    #     return str(self.wbs)

    class Meta:
        db_table = "boq_wbs_gantt_depends"


class InvoiceSchedule(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_invoice_schedule_organization',on_delete=models.CASCADE)
    project = models.ForeignKey(ProjectMaster, related_name='boq_invoice_schedule_project', on_delete=models.CASCADE)
    previous_version = models.ForeignKey('self', related_name='boq_invoice_schedule_previous_version',on_delete=models.CASCADE, blank=True, null=True)
    version = models.IntegerField(default=1)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    class Meta:
        db_table = "boq_invoice_schedule"



class InvoiceScheduleItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_invoice_schedule_items_organization',on_delete=models.CASCADE)
    invoice_schedule = models.ForeignKey(InvoiceSchedule, related_name='boq_invoice_schedule_items',on_delete=models.CASCADE, blank=True, null=True)
    parent = models.ForeignKey('self', related_name='boq_invoice_schedule_items_parent',on_delete=models.CASCADE, blank=True, null=True)
    code = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255)
    uom = models.CharField(max_length=255, blank=True, null=True)
    quantity = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    ftm_quantity = models.FloatField(default=0)
    ftm_amount = models.FloatField(default=0)

    class Meta:
        db_table = "boq_invoice_schedule_items"

class InvoiceScheduleWBSTag(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_invoice_schedule_wbs_tag_organization',on_delete=models.CASCADE)
    invoice_schedule_items = models.ForeignKey(InvoiceScheduleItems, related_name='boq_invoice_schedule_wbs_tag_invoice_schedule_items',on_delete=models.CASCADE, blank=True, null=True)
    wbs = models.ForeignKey(WBSList, related_name='boq_invoice_schedule_wbs_tag_wbs',on_delete=models.CASCADE, null=True, blank=True)
    class Meta:
        db_table = "boq_invoice_schedule_wbs_tag"
class InvoiceScheduleCertifiedFTM(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_invoice_schedule_certified_ftm_organization',on_delete=models.CASCADE)
    invoice_schedule_items = models.ForeignKey(InvoiceScheduleItems, related_name='boq_invoice_schedule_certified_ftm_invoice_schedule_items',on_delete=models.CASCADE, blank=True, null=True)
    date = models.DateField(null=True, blank=True)
    quantity = models.FloatField(default=0)

    class Meta:
        db_table = "boq_invoice_schedule_certified_ftm"



class BOQMonthlyProgressData(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_monthly_progress_organizations', on_delete=models.CASCADE)
    planning_tender = models.ForeignKey(PlanningTender, related_name='boq_monthly_progress_planning_tenders', on_delete=models.CASCADE, null=True, blank=True)
    boq = models.ForeignKey(BOQ, related_name='boq_monthly_progress_boq',on_delete=models.CASCADE, null=True, blank=True)
    wbs = models.ForeignKey(WBSList, related_name='boq_monthly_progress_wbs',on_delete=models.CASCADE, null=True, blank=True)
    value = models.CharField(max_length=200, blank=True, null=True)
    date = models.DateField(null=True, blank=True)

    class Meta:
        db_table = "boq_monthly_progress"




class BOQMonthlyCostData(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='boq_monthly_cost_data_organization', on_delete=models.CASCADE)
    boq = models.ForeignKey(BOQ, related_name='boq_monthly_cost_data_boq',on_delete=models.CASCADE, null=True, blank=True)
    value =  models.FloatField(default=0)
    date = models.DateField(null=True, blank=True)

    class Meta:
        db_table = "boq_monthly_cost_data"