from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline

from .models import *
# Register your models here.
class ScheduleHItemsAdmin(StackedInline):
    model = ScheduleHItems
    fk_name = 'schedule_h'
@admin.register(ScheduleH)
class ScheduleHAdmin(ModelAdmin):
    list_display = ['code', 'name', 'is_deleted']
    search_fields = ('name',)
    inlines = (ScheduleHItemsAdmin,)
@admin.register(ScheduleHItems)
class ScheduleHItemsAdmin(ModelAdmin):
    list_display = ['parent', 'code', 'name', 'percentage', 'amount', 'is_deleted']
    search_fields = ('name','parent__name',)
class BOQApprovalDetailsAdminInline(StackedInline):
    model = BOQApprovalDetails
    fk_name = 'boq'
@admin.register(BOQ)
class BOQAdmin(ModelAdmin):
    list_display = ['project', 'name', 'version', 'parent_tender', 'parent_boq', 'start_date', 'end_date', 'status', 'is_deleted']
    search_fields = ('name','status',)
    inlines = (BOQApprovalDetailsAdminInline,)


class WBSLabourAdminInline(StackedInline):
    model = WBSLabour
    fk_name = 'wbs_list'
class WBSMaterialAdminInline(StackedInline):
    model = WBSMaterial
    fk_name = 'wbs_list'
class WBSPlantMachineryAdminInline(StackedInline):
    model = WBSPlantMachinery
    fk_name = 'wbs_list'
class WBSIndirectCostAdminInline(StackedInline):
    model = WBSIndirectCost
    fk_name = 'wbs_list'
@admin.register(WBSList)
class WBSListAdmin(ModelAdmin):
    list_display = ['id','wbs', 'boq_id', 'boq_code', 'parent_id', 'root_id', 'uom', 'budgeted_quantity', 'rate', 'total_labour', 'total_material', 'total_machinery', 'total_overheads', 'is_deleted']
    search_fields = ('wbs','boq__name', 'wbs_material_wbs_list__material__material_name__icontains')
    inlines = (WBSLabourAdminInline,WBSMaterialAdminInline,WBSPlantMachineryAdminInline,WBSIndirectCostAdminInline,)


@admin.register(BOQChainageExecutiveSummeryData)
class BOQChainageExecutiveSummeryDataAdmin(ModelAdmin):
    search_fields = ('wbs__wbs','boq__name', 'form__name', 'value')
    list_display = ['id', 'boq_id', 'wbs_id', 'form_id', 'value', 'type']


@admin.register(BOQChainage)
class BOQChainageAdmin(ModelAdmin):
    search_fields = ('wbs__wbs','boq__name', 'name')
    list_display = ['id', 'boq_id', 'wbs_id', 'name', 'start', 'end', 'chainage_value']


@admin.register(PlanningTender)
class PlanningTenderAdmin(ModelAdmin):
    list_display = ['id', 'organization', 'project', 'tender']


@admin.register(WbsIndirectCostPlaning)
class WbsIndirectCostPlaningAdmin(ModelAdmin):
    search_fields = ('wbs_code','indirect_cost')
    list_display = ['id', 'organization', 'project', 'parent', 'indirect_cost', 'wbs_code', 'cost_value']


@admin.register(WbsTempPlaning)
class WbsTempPlaningAdmin(ModelAdmin):
    search_fields = ('wbs_code','temp_cost')
    list_display = ['id', 'organization', 'project', 'parent', 'temp_cost', 'wbs_code']


@admin.register(BOQMonthlyPlanningData)
class BOQMonthlyPlanningDataAdmin(ModelAdmin):
    # search_fields = ('month','year')
    list_filter = ['is_latest', 'is_deleted']
    list_display = ['id', 'boq', 'wbs', 'form', 'date', 'side', 'value', 'is_latest', 'is_deleted']


@admin.register(DrawingCategory)
class DrawingCategoryAdmin(ModelAdmin):
    search_fields = ['name']
    list_display = ['id', 'project', 'name', 'is_deleted']

class DrawingTrackerDocumentsAdminInline(StackedInline):
    model = DrawingTrackerDocuments
    fk_name = 'drawing_tracker'
@admin.register(DrawingTracker)
class DrawingTrackerAdmin(ModelAdmin):
    list_display = ['id', 'boq', 'wbs', 'form', 'side', 'title', 'number', 'status', 'final_approval_date', 'is_deleted']
    list_filter = ['status', 'is_deleted']
    inlines = (DrawingTrackerDocumentsAdminInline,)

admin.site.register(DrawingTrackerDocuments,ModelAdmin)

class WBSGanttDependsAdminInline(StackedInline):
    model = WBSGanttDepends
    fk_name = 'wbs_gantt'
@admin.register(WBSGantt)
class WBSGanttAdmin(ModelAdmin):
    list_display = ['id','project', 'by_order','boq_code','boq_no', 'wbs','is_deleted']
    # list_filter = ['boq_code', 'is_deleted']
    inlines = (WBSGanttDependsAdminInline,)

admin.site.register(WBSGanttDepends,ModelAdmin)
class InvoiceScheduleItemsAdminInline(StackedInline):
    model = InvoiceScheduleItems
    fk_name = 'invoice_schedule'

@admin.register(InvoiceSchedule)
class InvoiceScheduleAdmin(ModelAdmin):
    list_display = ['id', 'project','is_deleted']
    list_filter = ['project', 'is_deleted']
    inlines = (InvoiceScheduleItemsAdminInline,)

@admin.register(InvoiceScheduleWBSTag)
class InvoiceScheduleWBSTagAdmin(ModelAdmin):
    list_display = ['id', 'wbs','invoice_schedule_items','is_deleted']
    list_filter = ['invoice_schedule_items','wbs','is_deleted']
@admin.register(InvoiceScheduleCertifiedFTM)
class InvoiceScheduleCertifiedFTMAdmin(ModelAdmin):
    list_display = ['id', 'date','invoice_schedule_items','quantity','is_deleted']
    list_filter = ['invoice_schedule_items','date','is_deleted']

@admin.register(BOQMonthlyProgressData)
class BOQMonthlyProgressDataAdmin(ModelAdmin):
    list_display = ['id', 'wbs','boq','date','value','is_deleted']
    list_filter = ['boq','wbs','date','value','is_deleted']



@admin.register(BOQMonthlyCostData)
class BOQMonthlyCostDataAdmin(ModelAdmin):
    list_display = ['id', 'boq','date','value','is_deleted']
    list_filter = ['boq', 'date','value','is_deleted']