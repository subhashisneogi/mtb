from django.apps import AppConfig


class MaterialMasterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'boq'
    def ready(self):
        import boq.signals
