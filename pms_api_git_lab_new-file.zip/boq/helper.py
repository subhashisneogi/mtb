from rest_framework import status
from rest_framework.exceptions import APIException
from django.db import transaction
from django.db.models import Q, OuterRef, Subquery, F
from .models import *
from .serializers import *
from user_permissions.models import *
from project_and_planning.models import *
from project_and_planning.serializers import *
import pandas as pd
import numpy as np
from django.db.models import Max, IntegerField, Value
from django.db.models.functions import Cast
from django.db.models import Func

def check_editor_permissions(request,approve=0,respond=0):
    user = request.user
    if user:
        permission_items = ['boq-approver']
        if approve == 0:
            permission_items.append('boq-editor')
            if request.method.upper() == 'GET':
                permission_items.append('boq-viewer')

        has_permission = UserWiseModulePermissions.objects.filter(
            user=user,
            module_item__unique_id__in=permission_items,
            level_permission=True,
            is_deleted=False
        ).exists()

        if respond:
            return has_permission
        else:
            if not has_permission:
                raise APIException({'request_status': 0, 'msg': "User does not have permission for this action"})

def check_boq_status(request,id,organization_id):
    if BOQ.cmobjects.filter(pk=id,organization_id=organization_id).exists():
        boq_details = BOQ.cmobjects.filter(pk=id).first()
        approve = 0
        if boq_details.status:
            if boq_details.status != 'pending':
                approve = 1
        check_editor_permissions(request,approve)
        if not boq_details.status == "pending":
            raise APIException({'request_status': 0, 'msg': "BOQ already "+boq_details.status})
    else:
        raise APIException({'request_status': 0, 'msg': "BOQ not found"})

def check_wbs_boq_status(request,id,organization_id):
    if WBSList.cmobjects.filter(pk=id,organization_id=organization_id).exists():
        wbs_list_details = WBSList.cmobjects.filter(pk=id).first()
        if wbs_list_details.boq_id:
            check_boq_status(request,wbs_list_details.boq_id,organization_id)
    else:
        raise APIException({'request_status': 0, 'msg': "WBS List not found"})

def update_wbs_cost(id):
    wbs_parts = ['WBSLabour','WBSMaterial','WBSPlantMachinery','WBSIndirectCost']
    if WBSList.cmobjects.filter(pk=id).exists():
        total_cost = 0
        wbs_list_details = WBSList.cmobjects.filter(pk=id).first()

        for parts in wbs_parts:
            details = eval(parts+'.cmobjects.filter(wbs_list=id)')
            serializer = eval(parts+'Serializer(details, many=True)')
            for values in serializer.data:
                if not values['rate']:
                    values['rate'] = 0
                if not values['budgeted_quantity']:
                    values['budgeted_quantity'] = 0
                total_cost += (float(values['rate'])*float(values['budgeted_quantity']))
        wbs_list_details.cost = total_cost
        wbs_list_details.save()

def temp(sheet_xlsx):
        sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
        sheet_xlsx['rate'] = sheet_xlsx['rate'].replace([None], [0])
        sheet_xlsx['cost'] = sheet_xlsx['cost'].replace([None], [0])
        sheet_xlsx['tender_quantity'] = sheet_xlsx['tender_quantity'].replace([None], [0])
        sheet_xlsx['budgeted_quantity'] = sheet_xlsx['budgeted_quantity'].replace([None], [0])
        sheet_xlsx['total_labour'] = sheet_xlsx['total_labour'].replace([None], [0])
        sheet_xlsx['total_material'] = sheet_xlsx['total_material'].replace([None], [0])
        sheet_xlsx['total_machinery'] = sheet_xlsx['total_machinery'].replace([None], [0])
        sheet_xlsx['total_overheads'] = sheet_xlsx['total_overheads'].replace([None], [0])
        sheet_xlsx['budgeted_quantity'] = sheet_xlsx['budgeted_quantity'].apply(lambda x: float(x) if not x=='' else 0.0)
        sheet_xlsx['budgeted_quantity'] = sheet_xlsx['budgeted_quantity'].replace([None], [0.0])
        sheet_xlsx = sheet_xlsx.applymap(lambda x: str(x))
        sheet_xlsx = sheet_xlsx.replace([np.nan], ['None'])
        sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        sheet_xlsx = sheet_xlsx.replace([np.nan], ['None'])
        # sheet_xlsx = sheet_xlsx.sort_values('replicate_from')
        sheet_xlsx = sheet_xlsx.reindex(sorted(sheet_xlsx.columns), axis=1)
        sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
        return sheet_xlsx

def dict_keys_to_str(d):
    if isinstance(d, dict):
        return {
            str(k): dict_keys_to_str(v) for k,v in d.items()
        }
    return d

def temp2(data_dict):
    sheet_temp = pd.DataFrame(data_dict)
    sheet_temp["boq"] = None
    sheet_temp["organization"] = 1
    sheet_temp = sheet_temp.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    sheet_temp = sheet_temp.reindex(sorted(sheet_temp.columns), axis=1)
    return sheet_temp

def validate_boq_replicate(planning_tender_id, boq_id):

    wbs_list1 = WBSList.objects.filter(planning_tender_id=planning_tender_id).annotate(parent_name=F('parent_id__wbs'), after_this_name=F('after_this__wbs')).values('parent_name', 'is_deleted', 'category', 'by_order', 'after_this_name', 'boq_code', 'boq_no', 'wbs', 'uom_id', 'short_name',  'tender_quantity','budgeted_quantity', 'rate', 'cost', 'total_labour', 'total_material', 'total_machinery', 'total_overheads', 'organization').order_by('id')
        
    wbs_xlsx1 = pd.DataFrame(wbs_list1)
    wbs_xlsx1 = temp(wbs_xlsx1)

    wbs_list2 = WBSList.objects.filter(boq_id=boq_id).annotate(parent_name=F('parent_id__wbs'), after_this_name=F('after_this__wbs')).values('parent_name', 'is_deleted', 'category', 'by_order', 'after_this_name', 'boq_code', 'boq_no', 'wbs', 'uom_id', 'short_name','tender_quantity','budgeted_quantity', 'rate', 'cost', 'total_labour', 'total_material', 'total_machinery', 'total_overheads', 'organization').order_by('replicate_from')

    
    wbs_xlsx2 = pd.DataFrame(wbs_list2)
    wbs_xlsx2 = temp(wbs_xlsx2)

    x = wbs_xlsx2.reset_index(drop=True).compare(wbs_xlsx1.reset_index(drop=True))
    print(x)
    x = x.fillna(np.nan).replace([np.nan], [None])
    x = x.groupby(level=0, group_keys=True).apply(lambda df: df.xs(df.name).to_dict()).to_dict()

    x_str_keys = dict_keys_to_str(x)


# Compare boq_chainage

    boq_chainage1 = BOQChainage.objects.annotate(wbs_name=F('wbs__wbs')).filter(
                    planning_tender_id=planning_tender_id
                ).values('wbs_name', 'name', 'start', 'end', 'chainage_value', 'is_deleted', 'organization')
    
    boq_chainage2 = BOQChainage.objects.annotate(wbs_name=F('wbs__wbs')).filter(
                    boq_id=boq_id
                ).values('wbs_name', 'name', 'start', 'end', 'chainage_value', 'is_deleted', 'organization')

    boq_chainage_sheet1 = pd.DataFrame(boq_chainage1)
    boq_chainage_sheet1 = boq_chainage_sheet1.reindex(sorted(boq_chainage_sheet1.columns), axis=1)

    boq_chainage_sheet2 = pd.DataFrame(boq_chainage2)
    boq_chainage_sheet2 = boq_chainage_sheet2.reindex(sorted(boq_chainage_sheet2.columns), axis=1)

    tx = boq_chainage_sheet1.reset_index(drop=True).compare(boq_chainage_sheet2.reset_index(drop=True))
    tx = tx.groupby(level=0, group_keys=True).apply(lambda df: df.xs(df.name).to_dict()).to_dict()

    tx_str_keys = dict_keys_to_str(tx)


#  Compare boq_chainage_executive_summery

    boq_chainage_executive_summery1 = BOQChainageExecutiveSummeryData.objects.annotate(wbs_name=F('wbs__wbs'), form_name=F('form__name')).filter(planning_tender_id=planning_tender_id).values('organization', 'wbs_name', 'form_name', 'type', 'value', 'is_deleted')

    boq_chainage_executive_summery2 = BOQChainageExecutiveSummeryData.objects.annotate(wbs_name=F('wbs__wbs'), form_name=F('form__name')).filter(boq_id=boq_id).values('organization', 'wbs_name', 'form_name', 'type', 'value', 'is_deleted')


    boq_chainage_executive_summery_sheet1 = pd.DataFrame(boq_chainage_executive_summery1)
    boq_chainage_executive_summery_sheet1 = boq_chainage_executive_summery_sheet1.reindex(sorted(boq_chainage_executive_summery_sheet1.columns), axis=1)

    boq_chainage_executive_summery_sheet2 = pd.DataFrame(boq_chainage_executive_summery2)
    boq_chainage_executive_summery_sheet2 = boq_chainage_executive_summery_sheet2.reindex(sorted(boq_chainage_executive_summery_sheet2.columns), axis=1)

    
    ex = boq_chainage_executive_summery_sheet1.reset_index(drop=True).compare(boq_chainage_executive_summery_sheet2.reset_index(drop=True))
    ex = ex.groupby(level=0, group_keys=True).apply(lambda df: df.xs(df.name).to_dict()).to_dict()
    print(ex)

    ex_str_keys = dict_keys_to_str(ex)
    # print("**************", x_str_keys)
    combined_str_keys ={}
    combined_str_keys['wbs_list'] = x_str_keys
    combined_str_keys['boq_chainage'] = tx_str_keys
    combined_str_keys['boq_chainage_executive_summery'] = ex_str_keys

    return combined_str_keys


    




def validate_tender_replicate(planning_tender_id):
    planning_tender_id = planning_tender_id
    planning_tender_obj = PlanningTender.objects.filter(id=planning_tender_id).first()
    if not planning_tender_obj:
        raise APIException({'request_status': 0, 'msg': "Planning Tender does not exist"})

    tender_id = planning_tender_obj.tender_id
    print("tender_id", tender_id)

    # Start  Compare combined_query(TenderWBS, ExecutiveSummeryData) with WBSList
    
    summery_subquery = ExecutiveSummeryData.objects.filter(wbs_id=OuterRef('id'))
        
    combined_query = TenderWBS.objects.filter(tender_id=tender_id).annotate(
        tender_quantity=Subquery(summery_subquery.filter(form__form_internal_name='qty').values('value')),
        budgeted_quantity=Subquery(summery_subquery.filter(form__form_internal_name='qty').values('value')),
        rate=Subquery(summery_subquery.filter(form__form_internal_name='rate_incl__indirect_cost').values('value')),
        cost=Subquery(summery_subquery.filter(form__form_internal_name='sale_amount').values('value')),
        total_labour=Subquery(summery_subquery.filter(form__form_internal_name='labour').values('value')),
        total_material=Subquery(summery_subquery.filter(form__form_internal_name='material').values('value')),
        total_machinery=Subquery(summery_subquery.filter(form__form_internal_name='machinery').values('value')),
        total_overheads=Subquery(summery_subquery.filter(form__form_internal_name='overheads').values('value')), wbs=F('wbs_name'), replicate_from=F('id'), parent_name=F('parent_id__wbs_name'), after_this_name=F('after_this__wbs_name'), 
        ).select_related('uom', 'parent_id', 'after_this').values('parent_name', 'is_deleted', 'category','by_order', 'after_this_name', 'boq_code', 'boq_no', 'wbs', 'uom_id', 'short_name', 'replicate_from', 'tender_quantity','budgeted_quantity', 'rate', 'cost', 'total_labour', 'total_material', 'total_machinery', 'total_overheads')
    
    sheet_xlsx_temp = pd.DataFrame(combined_query)
    sheet_xlsx_temp["boq"] = None
    sheet_xlsx_temp["organization"] = 1
    sheet_xlsx_temp = temp(sheet_xlsx_temp)

    wbs_list = WBSList.objects.filter(planning_tender_id=planning_tender_id).annotate(parent_name=F('parent_id__wbs'), after_this_name=F('after_this__wbs')).values('parent_name', 'is_deleted', 'category', 'by_order', 'after_this_name', 'boq_code',
    'boq_no', 'wbs', 'uom_id', 'short_name', 'replicate_from', 'tender_quantity','budgeted_quantity', 'rate', 'cost', 'total_labour', 'total_material', 'total_machinery', 'total_overheads',
    'boq', 'organization')
    
    wbs_xlsx = pd.DataFrame(wbs_list)
    wbs_xlsx = temp(wbs_xlsx)

    x = sheet_xlsx_temp.reset_index(drop=True).compare(wbs_xlsx.reset_index(drop=True))
    x = x.groupby(level=0, group_keys=True).apply(lambda df: df.xs(df.name).to_dict()).to_dict()

    x_str_keys = dict_keys_to_str(x)

    # End  Compare combined_query(TenderWBS, ExecutiveSummeryData) with WBSList

    # Start  Compare tender_chainage with boq_chainage

    tender_chainage = TenderChainage.objects.annotate(wbs_name=F('wbs__wbs_name')).filter(
                    tender_id=tender_id
                ).values('wbs_name', 'name', 'start', 'end', 'chainage_value', 'is_deleted')
    
    boq_chainage = BOQChainage.objects.annotate(wbs_name=F('wbs__wbs')).filter(
                    planning_tender_id=planning_tender_id
                ).values('wbs_name', 'name', 'start', 'end', 'chainage_value', 'is_deleted', 'boq', 'organization')
    
    tender_chainage_sheet = temp2(tender_chainage)
    print("tender_chainage_sheet", tender_chainage_sheet)

    boq_chainage_sheet = pd.DataFrame(boq_chainage)
    boq_chainage_sheet = boq_chainage_sheet.reindex(sorted(boq_chainage_sheet.columns), axis=1)
    print("boq_chainage_sheet", boq_chainage_sheet)

    tx = tender_chainage_sheet.reset_index(drop=True).compare(boq_chainage_sheet.reset_index(drop=True))
    tx = tx.groupby(level=0, group_keys=True).apply(lambda df: df.xs(df.name).to_dict()).to_dict()

    tx_str_keys = dict_keys_to_str(tx)

    # End Compare tender_chainage with boq_chainage

    # Start  Compare chainage_executive_summery with boq_chainage_executive_summery


    chainage_executive_summery = ChainageExecutiveSummeryData.objects.annotate(wbs_name=F('wbs__wbs_name'), form_name=F('form__name')).filter(tender_id=tender_id).values('wbs_name', 'form_name', 'type', 'value', 'is_deleted')

    boq_chainage_executive_summery = BOQChainageExecutiveSummeryData.objects.annotate(wbs_name=F('wbs__wbs'), form_name=F('form__name')).filter(planning_tender_id=planning_tender_id).values('boq', 'organization', 'wbs_name', 'form_name', 'type', 'value', 'is_deleted')

    chainage_executive_summery_sheet = temp2(chainage_executive_summery)
    print("chainage_executive_summery_sheet", chainage_executive_summery_sheet)

    boq_chainage_executive_summery_sheet = pd.DataFrame(boq_chainage_executive_summery)
    boq_chainage_executive_summery_sheet = boq_chainage_executive_summery_sheet.reindex(sorted(boq_chainage_executive_summery_sheet.columns), axis=1)
    print("boq_chainage_executive_summery_sheet", boq_chainage_executive_summery_sheet)

    ex = chainage_executive_summery_sheet.reset_index(drop=True).compare(boq_chainage_executive_summery_sheet.reset_index(drop=True))
    ex = ex.groupby(level=0, group_keys=True).apply(lambda df: df.xs(df.name).to_dict()).to_dict()
    print(ex)

    ex_str_keys = dict_keys_to_str(ex)

    combined_str_keys ={}
    combined_str_keys['wbs_list'] = x_str_keys
    combined_str_keys['boq_chainage'] = tx_str_keys
    combined_str_keys['boq_chainage_executive_summery'] = ex_str_keys

    # End Compare chainage_executive_summery with boq_chainage_executive_summery

    # return Response({"msg": "success", "s": sheet_xlsx_temp.to_dict('records')})
    return combined_str_keys


def planning_tender_link(request, project_id, tender_id, organization_id):
    planning_tender = PlanningTender.objects.filter(project_id=project_id, tender_id=tender_id).first()
    if planning_tender:
         raise APIException({'request_status': 0, 'msg': "Planning tender already exists"})
    planning_tender_obj  = PlanningTender.objects.create(project_id=project_id, tender_id=tender_id, organization_id=organization_id)
    replicate_wbs_list(None,tender_id,None,"executive_summary", planning_tender_obj.id)
    mismatch_records = validate_tender_replicate(planning_tender_obj.id)
    return mismatch_records


def replicate_wbs_list(boq_id,replicate_tender,replicate_boq,source, planning_tender_id):
    try:
        if source == '':
            with transaction.atomic():
                wbs_parts = ['WBSLabour','WBSMaterial','WBSPlantMachinery','WBSIndirectCost']
                search = {}
                replicate_planning_tender = planning_tender_id
                if replicate_tender:
                    search['tender_id'] = replicate_tender
                if replicate_boq:
                    search['boq_id'] = replicate_boq
                if replicate_planning_tender:
                    search['planning_tender_id'] = replicate_planning_tender
                wbs_ids_map = {}
                boq_chainage_map = {}
                wbs_list_details = WBSList.objects.filter(**search).order_by('parent')
                wbs_list_serializer = WBSListSerializer(wbs_list_details, many=True)
                for wbs_list_values in wbs_list_serializer.data:
                    parent_id = None
                    if wbs_list_values['parent']:
                        if wbs_list_values['parent'] in wbs_ids_map:
                            parent_id = wbs_ids_map[wbs_list_values['parent']]
                    after_this = None
                    if wbs_list_values['after_this']:
                        if wbs_list_values['after_this'] in wbs_ids_map:
                            after_this = wbs_ids_map[wbs_list_values['after_this']]
                    old_wbs_list_id = wbs_list_values['id']
                    data = wbs_list_values
                    del data['id']
                    data['pk'] = None
                    data['tender'] = None
                    data['planning_tender'] = None
                    data['boq'] = boq_id
                    data['parent'] = parent_id
                    data['replicate_from'] = old_wbs_list_id
                    serializer = WBSListSerializer(data=data)
                    if serializer.is_valid():
                        obj = serializer.save()
                        wbs_ids_map[old_wbs_list_id] = obj.id
                    else:
                        print('WBSListSerializer.errors')
                        print(serializer.errors)
                search_parts = {}
                if replicate_tender:
                    search_parts['wbs_list__tender_id'] = replicate_tender
                if replicate_boq:
                    search_parts['wbs_list__boq_id'] = replicate_boq
                if replicate_planning_tender:
                    search_parts['wbs_list__planning_tender_id'] = replicate_planning_tender
                for parts in wbs_parts:
                    details = eval(parts+'.objects.filter(**search_parts)')
                    parts_serializer = eval(parts+'Serializer(details, many=True)')
                    for values in parts_serializer.data:
                        old_wbs_list_id = values['wbs_list']
                        data_new = values
                        del data_new['id']
                        data_new['pk'] = None
                        data_new['wbs_list'] = wbs_ids_map[old_wbs_list_id] if old_wbs_list_id in wbs_ids_map else None
                        temp_serializer = eval(parts+'Serializer(data=data_new)')
                        if temp_serializer.is_valid():
                            temp_serializer.save()
                        else:
                            print(parts+'Serializer.errors')
                            print(temp_serializer.errors)
                boq_chainage_details = BOQChainage.objects.filter(**search)
                boq_chainage_serializer = BOQChainageSerializer(boq_chainage_details, many=True)
                for boq_chainage_values in boq_chainage_serializer.data:
                    old_wbs_list_id = boq_chainage_values['wbs']
                    old_boq_chainage_id = boq_chainage_values['id']
                    data = boq_chainage_values
                    del data['id']
                    data['pk'] = None
                    data['planning_tender'] = None
                    data['boq'] = boq_id
                    data['wbs'] = wbs_ids_map[old_wbs_list_id] if old_wbs_list_id in wbs_ids_map else None
                    boq_chainage_serializer = BOQChainageSerializer(data=data)
                    if boq_chainage_serializer.is_valid():
                        obj = boq_chainage_serializer.save()
                        boq_chainage_map[old_boq_chainage_id] = obj.id
                    else:
                        print('BOQChainageSerializer.errors')
                        print(boq_chainage_serializer.errors)
                boq_chainage_executive_details = BOQChainageExecutiveSummeryData.objects.filter(**search)
                boq_chainage_executive_serializer = BOQChainageExecutiveSummeryDataSerializer(boq_chainage_executive_details, many=True)
                for boq_chainage_executive_values in boq_chainage_executive_serializer.data:
                    old_wbs_list_id = boq_chainage_executive_values['wbs']
                    old_boq_chainage_id = boq_chainage_executive_values['form']
                    data = boq_chainage_executive_values
                    del data['id']
                    data['pk'] = None
                    data['planning_tender'] = None
                    data['boq'] = boq_id
                    data['wbs'] = wbs_ids_map[old_wbs_list_id] if old_wbs_list_id in wbs_ids_map else None
                    data['form'] = boq_chainage_map[old_boq_chainage_id] if old_boq_chainage_id in boq_chainage_map else None
                    boq_chainage_executive_serializer = BOQChainageExecutiveSummeryDataSerializer(data=data)
                    if boq_chainage_executive_serializer.is_valid():
                        obj = boq_chainage_executive_serializer.save()
                    else:
                        print('BOQChainageExecutiveSummeryDataSerializer.errors')
                        print(boq_chainage_executive_serializer.errors)
                if replicate_boq:
                    planning_peacon_stats_srtip_details = PlanningPeaconStatsSrtip.objects.filter(boq_chainage__boq_id=replicate_boq)
                    planning_peacon_stats_srtip_serializer = PlanningPeaconStatsSrtipSerializer(planning_peacon_stats_srtip_details, many=True)
                    for planning_peacon_stats_srtip_values in planning_peacon_stats_srtip_serializer.data:
                        if planning_peacon_stats_srtip_values['boq_code']:
                            old_wbs_list_id = planning_peacon_stats_srtip_values['boq_code']
                            new_wbs_list_id = wbs_ids_map[old_wbs_list_id] if old_wbs_list_id in wbs_ids_map else None
                            PlanningPeaconStatsSrtip.objects.filter(pk=planning_peacon_stats_srtip_values['id']).update(boq_code=new_wbs_list_id)
                        if planning_peacon_stats_srtip_values['boq_chainage']:
                            old_boq_chainage_id = planning_peacon_stats_srtip_values['boq_chainage']
                            new_boq_chainage_id = boq_chainage_map[old_boq_chainage_id] if old_boq_chainage_id in boq_chainage_map else None
                            PlanningPeaconStatsSrtip.objects.filter(pk=planning_peacon_stats_srtip_values['id']).update(boq_chainage=new_boq_chainage_id)
        else:
            if replicate_tender:
                with transaction.atomic():
                    wbs_ids_map = {}
                    boq_chainage_map = {}
                    organization = None
                    tender = TenderMaster.objects.filter(pk=replicate_tender).first()
                    if tender:
                        organization = tender.organization.id
                    wbs_list_details = TenderWBS.objects.filter(Q(tender=replicate_tender) | Q(is_default=True)).order_by('parent_id').values(
                        'id',
                        'parent_id_id',
                        'category',
                        'by_order',
                        'after_this_id',
                        'boq_code',
                        'boq_no',
                        'wbs_name',
                        'uom_id',
                        'short_name',
                        'is_deleted',
                    )
                    print("total TenderWbs count", wbs_list_details.count())
                    executive_summery = ExecutiveSummeryData.objects.filter(
                        form__form_internal_name__in=['qty','rate_incl__indirect_cost','sale_amount','labour','material','machinery','overheads'],
                        tender_id=replicate_tender
                    ).values('wbs_id', 'form__form_internal_name', 'value', 'is_deleted')  
                    tender_chainage = TenderChainage.objects.filter(
                        tender_id=replicate_tender
                    ).values('id', 'wbs_id', 'name', 'start', 'end', 'chainage_value', 'is_deleted')
                    chainage_executive_summery = ChainageExecutiveSummeryData.objects.filter(
                        tender_id=replicate_tender
                    ).values('wbs_id', 'form_id', 'type', 'value', 'is_deleted')
                    count = 0
                    for wbs_list_values in wbs_list_details:
                        parent_id = None
                        if wbs_list_values['parent_id_id']:
                            # new_parent = WBSList.objects.filter(boq=boq_id,replicate_from=wbs_list_values['parent_id_id']).first()
                            # if new_parent:
                            #     parent_id = new_parent.id
                            if wbs_list_values['parent_id_id'] in wbs_ids_map:
                                parent_id = wbs_ids_map[wbs_list_values['parent_id_id']]
                        after_this = None
                        if wbs_list_values['after_this_id']:
                            if wbs_list_values['after_this_id'] in wbs_ids_map:
                                after_this = wbs_ids_map[wbs_list_values['after_this_id']]
                        wbs_executive_summery = list(filter(lambda item: item['wbs_id'] == wbs_list_values['id'], executive_summery))
                        # wbs_chainage_executive_summery = list(filter(lambda item: item['wbs_id'] == wbs_list_values['id'], chainage_executive_summery))
                        data = {
                            'organization': organization,
                            'is_deleted': wbs_list_values['is_deleted'],
                            'category': wbs_list_values['category'],
                            'by_order': wbs_list_values['by_order'],
                            'after_this': after_this,
                            'boq_code': wbs_list_values['boq_code'],
                            'boq_no': wbs_list_values['boq_no'],
                            'wbs': wbs_list_values['wbs_name'],
                            'planning_tender': planning_tender_id,
                            'boq': boq_id,
                            'tender': None,
                            'parent': parent_id,
                            'uom': wbs_list_values['uom_id'],
                            'short_name': wbs_list_values['short_name'],
                            'replicate_from': wbs_list_values['id'],
                            'tender_quantity': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'qty'), 0),
                            'budgeted_quantity': next((filter_input(item['value']) for item in wbs_executive_summery if item['form__form_internal_name'] == 'qty'), 0),
                            'rate': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'rate_incl__indirect_cost'), 0),
                            'cost': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'sale_amount'), 0),
                            'total_labour': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'labour'), 0),
                            'total_material': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'material'), 0),
                            'total_machinery': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'machinery'), 0),
                            'total_overheads': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'overheads'), 0),
                        }
                        serializer = WBSListSerializer(data=data)
                        if serializer.is_valid():
                            obj = serializer.save()
                            count = count + 1
                            wbs_ids_map[wbs_list_values['id']] = obj.id
                        else:
                            print('WBSListSerializer.errors')
                            print(serializer.errors)
                    print("total count of wbslist", count)
                    for tender_chainage_data in tender_chainage:
                        boq_chainage_data = {
                            'organization': organization,
                            'is_deleted': tender_chainage_data['is_deleted'],
                            'planning_tender': planning_tender_id,
                            'boq': boq_id,
                            'wbs': wbs_ids_map[tender_chainage_data['wbs_id']] if tender_chainage_data['wbs_id'] in wbs_ids_map else None,
                            'name': tender_chainage_data['name'],
                            'start': tender_chainage_data['start'],
                            'end': tender_chainage_data['end'],
                            'chainage_value': tender_chainage_data['chainage_value'],
                        }
                        boq_chainage_serializer = BOQChainageSerializer(data=boq_chainage_data)
                        if boq_chainage_serializer.is_valid():
                            obj = boq_chainage_serializer.save()
                            boq_chainage_map[tender_chainage_data['id']] = obj.id
                        else:
                            print('BOQChainageSerializer.errors')
                            print(boq_chainage_serializer.errors)
                    chainage_executive_summery_bulk = []
                    for chainage_executive_summery_data in chainage_executive_summery:
                        chainage_executive_summery_bulk.append(
                            BOQChainageExecutiveSummeryData(
                                organization_id = organization,
                                is_deleted = chainage_executive_summery_data['is_deleted'],
                                planning_tender_id = planning_tender_id,
                                boq_id = boq_id,
                                wbs_id = wbs_ids_map[chainage_executive_summery_data['wbs_id']] if chainage_executive_summery_data['wbs_id'] in wbs_ids_map else None,
                                form_id = boq_chainage_map[chainage_executive_summery_data['form_id']] if chainage_executive_summery_data['form_id'] in boq_chainage_map else None,
                                value = chainage_executive_summery_data['value'],
                                type = chainage_executive_summery_data['type'],
                            )
                        )
                    try:
                        BOQChainageExecutiveSummeryData.objects.bulk_create(chainage_executive_summery_bulk, batch_size=100)
                    except Exception as e:
                        print('BOQChainageExecutiveSummeryData.errors')
                        print(e)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
                    
    except Exception as e:
        error_message = str(e.args[0]) if e.args else str(e)
        print(e)
        raise APIException({'request_status': 0, 'msg': error_message})



def replicate_wbs_list__back(boq_id,replicate_tender,replicate_boq,source, planning_tender_id):
    try:
        if source == '':
            with transaction.atomic():
                wbs_parts = ['WBSLabour','WBSMaterial','WBSPlantMachinery','WBSIndirectCost']
                search = {}
                replicate_planning_tender = planning_tender_id
                if replicate_tender:
                    search['tender_id'] = replicate_tender
                if replicate_boq:
                    search['boq_id'] = replicate_boq
                if replicate_planning_tender:
                    search['planning_tender_id'] = replicate_planning_tender
                wbs_ids_map = {}
                boq_chainage_map = {}
                wbs_list_details = WBSList.objects.filter(**search).order_by('parent')
                wbs_list_serializer = WBSListSerializer(wbs_list_details, many=True)
                for wbs_list_values in wbs_list_serializer.data:
                    parent_id = None
                    if wbs_list_values['parent']:
                        if wbs_list_values['parent'] in wbs_ids_map:
                            parent_id = wbs_ids_map[wbs_list_values['parent']]
                    after_this = None
                    if wbs_list_values['after_this']:
                        if wbs_list_values['after_this'] in wbs_ids_map:
                            after_this = wbs_ids_map[wbs_list_values['after_this']]
                    old_wbs_list_id = wbs_list_values['id']
                    data = wbs_list_values
                    del data['id']
                    data['pk'] = None
                    data['tender'] = None
                    data['planning_tender'] = None
                    data['boq'] = boq_id
                    data['parent'] = parent_id
                    data['replicate_from'] = old_wbs_list_id
                    serializer = WBSListSerializer(data=data)
                    if serializer.is_valid():
                        obj = serializer.save()
                        wbs_ids_map[old_wbs_list_id] = obj.id
                    else:
                        print('WBSListSerializer.errors')
                        print(serializer.errors)
                search_parts = {}
                if replicate_tender:
                    search_parts['wbs_list__tender_id'] = replicate_tender
                if replicate_boq:
                    search_parts['wbs_list__boq_id'] = replicate_boq
                if replicate_planning_tender:
                    search_parts['wbs_list__planning_tender_id'] = replicate_planning_tender
                for parts in wbs_parts:
                    details = eval(parts+'.objects.filter(**search_parts)')
                    parts_serializer = eval(parts+'Serializer(details, many=True)')
                    for values in parts_serializer.data:
                        old_wbs_list_id = values['wbs_list']
                        data_new = values
                        del data_new['id']
                        data_new['pk'] = None
                        data_new['wbs_list'] = wbs_ids_map[old_wbs_list_id] if old_wbs_list_id in wbs_ids_map else None
                        temp_serializer = eval(parts+'Serializer(data=data_new)')
                        if temp_serializer.is_valid():
                            temp_serializer.save()
                        else:
                            print(parts+'Serializer.errors')
                            print(temp_serializer.errors)
                boq_chainage_details = BOQChainage.objects.filter(**search)
                boq_chainage_serializer = BOQChainageSerializer(boq_chainage_details, many=True)
                for boq_chainage_values in boq_chainage_serializer.data:
                    old_wbs_list_id = boq_chainage_values['wbs']
                    old_boq_chainage_id = boq_chainage_values['id']
                    data = boq_chainage_values
                    del data['id']
                    data['pk'] = None
                    data['planning_tender'] = None
                    data['boq'] = boq_id
                    data['wbs'] = wbs_ids_map[old_wbs_list_id] if old_wbs_list_id in wbs_ids_map else None
                    boq_chainage_serializer = BOQChainageSerializer(data=data)
                    if boq_chainage_serializer.is_valid():
                        obj = boq_chainage_serializer.save()
                        boq_chainage_map[old_boq_chainage_id] = obj.id
                    else:
                        print('BOQChainageSerializer.errors')
                        print(boq_chainage_serializer.errors)
                boq_chainage_executive_details = BOQChainageExecutiveSummeryData.objects.filter(**search)
                boq_chainage_executive_serializer = BOQChainageExecutiveSummeryDataSerializer(boq_chainage_executive_details, many=True)
                for boq_chainage_executive_values in boq_chainage_executive_serializer.data:
                    old_wbs_list_id = boq_chainage_executive_values['wbs']
                    old_boq_chainage_id = boq_chainage_executive_values['form']
                    data = boq_chainage_executive_values
                    del data['id']
                    data['pk'] = None
                    data['planning_tender'] = None
                    data['boq'] = boq_id
                    data['wbs'] = wbs_ids_map[old_wbs_list_id] if old_wbs_list_id in wbs_ids_map else None
                    data['form'] = boq_chainage_map[old_boq_chainage_id] if old_boq_chainage_id in boq_chainage_map else None
                    boq_chainage_executive_serializer = BOQChainageExecutiveSummeryDataSerializer(data=data)
                    if boq_chainage_executive_serializer.is_valid():
                        obj = boq_chainage_executive_serializer.save()
                    else:
                        print('BOQChainageExecutiveSummeryDataSerializer.errors')
                        print(boq_chainage_executive_serializer.errors)
                if replicate_boq:
                    planning_peacon_stats_srtip_details = PlanningPeaconStatsSrtip.objects.filter(boq_chainage__boq_id=replicate_boq)
                    planning_peacon_stats_srtip_serializer = PlanningPeaconStatsSrtipSerializer(planning_peacon_stats_srtip_details, many=True)
                    for planning_peacon_stats_srtip_values in planning_peacon_stats_srtip_serializer.data:
                        if planning_peacon_stats_srtip_values['boq_code']:
                            old_wbs_list_id = planning_peacon_stats_srtip_values['boq_code']
                            new_wbs_list_id = wbs_ids_map[old_wbs_list_id] if old_wbs_list_id in wbs_ids_map else None
                            PlanningPeaconStatsSrtip.objects.filter(pk=planning_peacon_stats_srtip_values['id']).update(boq_code=new_wbs_list_id)
                        if planning_peacon_stats_srtip_values['boq_chainage']:
                            old_boq_chainage_id = planning_peacon_stats_srtip_values['boq_chainage']
                            new_boq_chainage_id = boq_chainage_map[old_boq_chainage_id] if old_boq_chainage_id in boq_chainage_map else None
                            PlanningPeaconStatsSrtip.objects.filter(pk=planning_peacon_stats_srtip_values['id']).update(boq_chainage=new_boq_chainage_id)
        else:
            if replicate_tender:
                with transaction.atomic():
                    wbs_ids_map = {}
                    boq_chainage_map = {}
                    organization = None
                    tender = TenderMaster.objects.filter(pk=replicate_tender).first()
                    if tender:
                        organization = tender.organization.id
                    wbs_list_details = TenderWBS.objects.filter(Q(tender=replicate_tender) | Q(is_default=True)).order_by('parent_id').values(
                        'id',
                        'parent_id_id',
                        'category',
                        'by_order',
                        'after_this_id',
                        'boq_code',
                        'boq_no',
                        'wbs_name',
                        'uom_id',
                        'short_name',
                        'is_deleted',
                    )
                    print("total TenderWbs count", wbs_list_details.count())
                    executive_summery = ExecutiveSummeryData.objects.filter(
                        form__form_internal_name__in=['qty','rate_incl__indirect_cost','sale_amount','labour','material','machinery','overheads'],
                        tender_id=replicate_tender
                    ).values('wbs_id', 'form__form_internal_name', 'value', 'is_deleted')  
                    tender_chainage = TenderChainage.objects.filter(
                        tender_id=replicate_tender
                    ).values('id', 'wbs_id', 'name', 'start', 'end', 'chainage_value', 'is_deleted')
                    chainage_executive_summery = ChainageExecutiveSummeryData.objects.filter(
                        tender_id=replicate_tender
                    ).values('wbs_id', 'form_id', 'type', 'value', 'is_deleted')
                    count = 0
                    for wbs_list_values in wbs_list_details:
                        parent_id = None
                        if wbs_list_values['parent_id_id']:
                            # new_parent = WBSList.objects.filter(boq=boq_id,replicate_from=wbs_list_values['parent_id_id']).first()
                            # if new_parent:
                            #     parent_id = new_parent.id
                            if wbs_list_values['parent_id_id'] in wbs_ids_map:
                                parent_id = wbs_ids_map[wbs_list_values['parent_id_id']]
                        after_this = None
                        if wbs_list_values['after_this_id']:
                            if wbs_list_values['after_this_id'] in wbs_ids_map:
                                after_this = wbs_ids_map[wbs_list_values['after_this_id']]
                        wbs_executive_summery = list(filter(lambda item: item['wbs_id'] == wbs_list_values['id'], executive_summery))
                        # wbs_chainage_executive_summery = list(filter(lambda item: item['wbs_id'] == wbs_list_values['id'], chainage_executive_summery))
                        data = {
                            'organization': organization,
                            'is_deleted': wbs_list_values['is_deleted'],
                            'category': wbs_list_values['category'],
                            'by_order': wbs_list_values['by_order'],
                            'after_this': after_this,
                            'boq_code': wbs_list_values['boq_code'],
                            'boq_no': wbs_list_values['boq_no'],
                            'wbs': wbs_list_values['wbs_name'],
                            'planning_tender': planning_tender_id,
                            'boq': boq_id,
                            'tender': None,
                            'parent': parent_id,
                            'uom': wbs_list_values['uom_id'],
                            'short_name': wbs_list_values['short_name'],
                            'replicate_from': wbs_list_values['id'],
                            'tender_quantity': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'qty'), 0),
                            'budgeted_quantity': next((filter_input(item['value']) for item in wbs_executive_summery if item['form__form_internal_name'] == 'qty'), 0),
                            'rate': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'rate_incl__indirect_cost'), 0),
                            'cost': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'sale_amount'), 0),
                            'total_labour': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'labour'), 0),
                            'total_material': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'material'), 0),
                            'total_machinery': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'machinery'), 0),
                            'total_overheads': next((item['value'] for item in wbs_executive_summery if item['form__form_internal_name'] == 'overheads'), 0),
                        }
                        serializer = WBSListSerializer(data=data)
                        if serializer.is_valid():
                            obj = serializer.save()
                            count = count + 1
                            wbs_ids_map[wbs_list_values['id']] = obj.id
                        else:
                            print('WBSListSerializer.errors')
                            print(serializer.errors)
                    print("total count of wbslist", count)
                    for tender_chainage_data in tender_chainage:
                        boq_chainage_data = {
                            'organization': organization,
                            'is_deleted': tender_chainage_data['is_deleted'],
                            'planning_tender': planning_tender_id,
                            'boq': boq_id,
                            'wbs': wbs_ids_map[tender_chainage_data['wbs_id']] if tender_chainage_data['wbs_id'] in wbs_ids_map else None,
                            'name': tender_chainage_data['name'],
                            'start': tender_chainage_data['start'],
                            'end': tender_chainage_data['end'],
                            'chainage_value': tender_chainage_data['chainage_value'],
                        }
                        boq_chainage_serializer = BOQChainageSerializer(data=boq_chainage_data)
                        if boq_chainage_serializer.is_valid():
                            obj = boq_chainage_serializer.save()
                            boq_chainage_map[tender_chainage_data['id']] = obj.id
                        else:
                            print('BOQChainageSerializer.errors')
                            print(boq_chainage_serializer.errors)
                    chainage_executive_summery_bulk = []
                    for chainage_executive_summery_data in chainage_executive_summery:
                        chainage_executive_summery_bulk.append(
                            BOQChainageExecutiveSummeryData(
                                organization_id = organization,
                                is_deleted = chainage_executive_summery_data['is_deleted'],
                                planning_tender_id = planning_tender_id,
                                boq_id = boq_id,
                                wbs_id = wbs_ids_map[chainage_executive_summery_data['wbs_id']] if chainage_executive_summery_data['wbs_id'] in wbs_ids_map else None,
                                form_id = boq_chainage_map[chainage_executive_summery_data['form_id']] if chainage_executive_summery_data['form_id'] in boq_chainage_map else None,
                                value = chainage_executive_summery_data['value'],
                                type = chainage_executive_summery_data['type'],
                            )
                        )
                    try:
                        BOQChainageExecutiveSummeryData.objects.bulk_create(chainage_executive_summery_bulk, batch_size=100)
                    except Exception as e:
                        print('BOQChainageExecutiveSummeryData.errors')
                        print(e)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
                    
    except Exception as e:
        error_message = str(e.args[0]) if e.args else str(e)
        print(e)
        raise APIException({'request_status': 0, 'msg': error_message})

def filter_input(value):
    new_value = 0
    try:
        new_value = float(value.replace(',', '').strip()) if value else 0
    except Exception as e:
        print(e)
    return new_value


def get_all_child(parent_list,return_list,all_list):
    if len(parent_list) == 0:
        return return_list
    else:
        return_list.extend(parent_list)
        new_parent_list = []
        for data in all_list:
            if data['parent_id'] in parent_list:
                new_parent_list.append(data['id'])
        parent_list = list(set(new_parent_list))
    return get_all_child(parent_list,return_list,all_list)

def create_boq_chainge(wbs_id, boq_id, organization):
    try:
        data = {
            'organization': organization,
            'boq': boq_id,
            "wbs" : wbs_id,
        }
        with transaction.atomic():
            boq_chainage_serializer = BOQChainageSerializer(data=data)
            if boq_chainage_serializer.is_valid():
                obj = boq_chainage_serializer.save()
            else:
                raise APIException({'request_status': 0, 'msg': boq_chainage_serializer.errors})
            
            data['form'] = obj.pk
            data['type'] = "C"
            boq_chainage_executive_serializer = BOQChainageExecutiveSummeryDataSerializer(data=data)
            if boq_chainage_executive_serializer.is_valid():
                boq_chainage_executive_serializer.save()
            else:
                raise APIException({'request_status': 0, 'msg': boq_chainage_executive_serializer.errors})
            
    except Exception as e:
        error_message = str(e.args[0]) if e.args else str(e)
        raise APIException({'request_status': 0, 'msg': error_message})

class SubstringIndex(Func):
    function = "SUBSTRING_INDEX"
    arity = 3

def generate_chainage_code(instance):
    """
        Generate chainage code
    """
    BASE_CODE = "CG-01-CP"
    if not instance.parent:
        return BASE_CODE
    parent_exec = BOQChainageExecutiveSummeryData.cmobjects.filter(wbs=instance.parent,boq=instance.boq,type="C").values("value").first()
    parent_code = parent_exec["value"] if parent_exec else BASE_CODE
    prefix = f"{parent_code}-"
    max_seq = BOQChainageExecutiveSummeryData.cmobjects.filter(boq=instance.boq,type="C",value__startswith=prefix ).annotate(
        seq=Cast(
            SubstringIndex("value", Value("-"), Value(-1)),
            IntegerField()
        )
    ).aggregate(max_seq=Max("seq"))["max_seq"]
    next_number = (max_seq or 0) + 1
    return f"{prefix}{str(next_number).zfill(2)}"


