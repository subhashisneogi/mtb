from colorama import Back, Style
from rest_framework import serializers
from .models import *
from django.db import transaction
from plant_machinery.serializers import CommonFilterListSerializer
from procurement.helper import process_attachments , get_details_from_instance ,get_project_data

class BOQApprovalDetailsSerializer(serializers.ModelSerializer):
    """"
    BOQApprovalDetails Serializer
    """

    class Meta:
        model = BOQApprovalDetails
        fields = '__all__'


class BOQSerializer(serializers.ModelSerializer):
    """"
    BOQ Serializer
    """
    id = serializers.IntegerField(required=False)
    approval_details = BOQApprovalDetailsSerializer(many=True, required=False, source='boq_approval_details_boq')

    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])

        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.get('boq_approval_details_boq', [])
        # existing_items = instance.boq_approval_details_boq.all()

        for item_data in items_data:
            BOQApprovalDetails.objects.create(
                created_by=current_user,
                organization=instance.organization,
                boq=instance,
                **item_data
            )
        #     item_id = item_data.get('id')
        #     existing_item = next((item for item in existing_items if item.id == item_id), None)
        #     if not existing_item:
        #         BOQApprovalDetails.objects.create(
        #             created_by=current_user,
        #             organization=instance.organization,
        #             boq=instance,
        #             **item_data
        #         )
        #     else:
        #         for field in existing_item._meta.fields:
        #             field_name = field.name
        #             if field_name in item_data:
        #                 setattr(existing_item, field_name, item_data[field_name])
        #         setattr(existing_item, 'updated_by', current_user)
        #         existing_item.save()

        # for existing_item in existing_items:
        #     if existing_item.id not in [data.get('id') for data in items_data]:
        #         existing_item.delete()
        approver_ids = validated_data.pop('approver', None)
        if approver_ids:
            instance.approver.clear()
            for approver_id in approver_ids:
                instance.approver.add(approver_id)

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        approval_details = representation.pop('approval_details', [])
        representation['approval_details'] = approval_details
        return representation

    class Meta:
        model = BOQ
        fields = '__all__'

class WBSLabourSerializer(serializers.ModelSerializer):
    """"
    WBSLabour Serializer
    """
    wbs_list = serializers.PrimaryKeyRelatedField(queryset=WBSList.objects.all(), required=False, allow_null=True)

    class Meta:
        model = WBSLabour
        fields = '__all__'


class WBSMaterialSerializer(serializers.ModelSerializer):
    """"
    WBSMaterial Serializer
    """
    wbs_list = serializers.PrimaryKeyRelatedField(queryset=WBSList.objects.all(), required=False, allow_null=True)

    class Meta:
        model = WBSMaterial
        fields = '__all__'


class WBSPlantMachinerySerializer(serializers.ModelSerializer):
    """"
    WBSPlantMachinery Serializer
    """
    wbs_list = serializers.PrimaryKeyRelatedField(queryset=WBSList.objects.all(), required=False, allow_null=True)

    class Meta:
        model = WBSPlantMachinery
        fields = '__all__'


class WBSIndirectCostSerializer(serializers.ModelSerializer):
    """"
    WBSIndirectCost Serializer
    """
    wbs_list = serializers.PrimaryKeyRelatedField(queryset=WBSList.objects.all(), required=False, allow_null=True)

    class Meta:
        model = WBSIndirectCost
        fields = '__all__'

class BOQChainageSerializer(serializers.ModelSerializer):
    """"
    BOQChainage Serializer
    """

    class Meta:
        model = BOQChainage
        fields = '__all__'

class BOQChainageExecutiveSummeryDataSerializer(serializers.ModelSerializer):
    """"
    BOQChainageExecutiveSummeryData Serializer
    """

    class Meta:
        model = BOQChainageExecutiveSummeryData
        fields = '__all__'

class BOQMonthlyPlanningDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = BOQMonthlyPlanningData
        fields = '__all__'


class WBSListSerializer(serializers.ModelSerializer):
    """"
    WBSList Serializer
    """
    id = serializers.IntegerField(required=False)
    labour = WBSLabourSerializer(many=True, required=False, source='wbs_labour_wbs_list', read_only=True)
    material = WBSMaterialSerializer(many=True, required=False, source='wbs_material_wbs_list', read_only=True)
    plant_machinery = WBSPlantMachinerySerializer(many=True, required=False, source='wbs_plant_machinery_wbs_list', read_only=True)
    indirect_cost = WBSIndirectCostSerializer(many=True, required=False, source='wbs_indirect_cost_wbs_list', read_only=True)
    uom_name = serializers.SerializerMethodField()
    invoice_schedule_details = serializers.SerializerMethodField()

    def get_uom_name(self, instance):
        if instance.uom:
            return instance.uom.symbol
        else:
            return ""

    def get_invoice_schedule_details(self, instance):
        return InvoiceScheduleWBSTag.cmobjects.filter(wbs_id=instance.id).values(
            'invoice_schedule_items__name',
            'invoice_schedule_items__quantity',
        )

    ## custom method
    # siblings = serializers.SerializerMethodField()
    # children = serializers.SerializerMethodField()

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        labour_data = representation.pop('labour', [])
        representation['labour'] = labour_data
        material_data = representation.pop('material', [])
        representation['material'] = material_data
        plant_machinery_data = representation.pop('plant_machinery', [])
        representation['plant_machinery'] = plant_machinery_data
        indirect_cost_data = representation.pop('indirect_cost', [])
        representation['indirect_cost'] = indirect_cost_data
        return representation

    # def get_siblings(self, instance):
    #     _sibling = []
    #     if instance.parent and instance.parent_id:
    #         if WBSList.cmobjects.filter(pk=instance.parent_id).exists():
    #             childs = WBSList.cmobjects.filter(parent=instance.parent_id)
    #             for child in childs:
    #                 if instance.pk != child.pk:
    #                     _sibling.append(int(child.pk))
    #     _sibling = sorted(_sibling)
    #     return _sibling

    # def get_children(self, instance):
    #     _children = []
    #     if WBSList.cmobjects.filter(parent=instance.pk).exists():
    #         childs = WBSList.cmobjects.filter(parent=instance.pk)
    #         for child in childs:
    #             if instance.pk != child.pk:
    #                 _children.append(int(child.pk))
    #     _children = sorted(_children)
    #     return _children


    class Meta:
        model = WBSList
        fields = '__all__'
class WBSListNewSerializer(serializers.ModelSerializer):
    """
    WBSList New Serializer
    """
    id = serializers.IntegerField(required=False)
    labour = WBSLabourSerializer(many=True, required=False, source='wbs_labour_wbs_list', )
    material = WBSMaterialSerializer(many=True, required=False, source='wbs_material_wbs_list', )
    plant_machinery = WBSPlantMachinerySerializer(many=True, required=False, source='wbs_plant_machinery_wbs_list', )
    indirect_cost = WBSIndirectCostSerializer(many=True, required=False, source='wbs_indirect_cost_wbs_list', )
    uom_name = serializers.SerializerMethodField()

    def get_uom_name(self, instance):
        if instance.uom:
            return instance.uom.symbol
        else:
            return ""

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        labour_data = representation.pop('labour', [])
        representation['labour'] = labour_data
        material_data = representation.pop('material', [])
        representation['material'] = material_data
        plant_machinery_data = representation.pop('plant_machinery', [])
        representation['plant_machinery'] = plant_machinery_data
        indirect_cost_data = representation.pop('indirect_cost', [])
        representation['indirect_cost'] = indirect_cost_data
        return representation

    @transaction.atomic
    def create(self, validated_data):
        labour_data = validated_data.pop('wbs_labour_wbs_list', [])
        material_data = validated_data.pop('wbs_material_wbs_list', [])
        plant_machinery_data = validated_data.pop('wbs_plant_machinery_wbs_list', [])
        indirect_cost_data = validated_data.pop('wbs_indirect_cost_wbs_list', [])
        
        wbs_list = WBSList.objects.create(**validated_data)
        
        for labour in labour_data:
            print(labour)
            WBSLabour.objects.create(wbs_list=wbs_list, **labour)
            
        
        for material in material_data:
            WBSMaterial.objects.create(wbs_list=wbs_list, **material)
        
        for plant_machinery in plant_machinery_data:
            WBSPlantMachinery.objects.create(wbs_list=wbs_list, **plant_machinery)
        
        for indirect_cost in indirect_cost_data:
            WBSIndirectCost.objects.create(wbs_list=wbs_list, **indirect_cost)
        
        return wbs_list

    @transaction.atomic
    def update(self, instance, validated_data):
        labour_data = validated_data.pop('wbs_labour_wbs_list', [])
        material_data = validated_data.pop('wbs_material_wbs_list', [])
        plant_machinery_data = validated_data.pop('wbs_plant_machinery_wbs_list', [])
        indirect_cost_data = validated_data.pop('wbs_indirect_cost_wbs_list', [])

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        def update_or_create_related_objects(model, related_instance_list, related_data, wbs_list_instance):
            existing_ids = [item.id for item in related_instance_list]
            new_ids = [item.get('id') for item in related_data if item.get('id')]

            for existing_item in related_instance_list:
                if existing_item.id not in new_ids:
                    existing_item.is_deleted = True
                    existing_item.save()

           
            for item_data in related_data:
                item_id = item_data.pop('id', None)
                if item_id and item_id in existing_ids:
                    item_instance = model.objects.get(id=item_id)
                    for attr, value in item_data.items():
                        setattr(item_instance, attr, value)
                    item_instance.is_deleted = False
                    item_instance.save()
                else:
                    model.objects.create(wbs_list=wbs_list_instance, **item_data)

        update_or_create_related_objects(WBSLabour, instance.wbs_labour_wbs_list.all(), labour_data, instance)
        update_or_create_related_objects(WBSMaterial, instance.wbs_material_wbs_list.all(), material_data, instance)
        update_or_create_related_objects(WBSPlantMachinery, instance.wbs_plant_machinery_wbs_list.all(), plant_machinery_data, instance)
        update_or_create_related_objects(WBSIndirectCost, instance.wbs_indirect_cost_wbs_list.all(), indirect_cost_data, instance)

        return instance

    class Meta:
        model = WBSList
        fields = '__all__'

class WBSListSerializer_2(serializers.ModelSerializer):
    """"
        WBSList Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = WBSList
        fields = '__all__'

class ScheduleHItemsSerializer(serializers.ModelSerializer):
    """"
    ScheduleHItems Serializer
    """

    class Meta:
        model = ScheduleHItems
        fields = '__all__'


class ScheduleHSerializer(serializers.ModelSerializer):
    """"
    ScheduleH Serializer
    """

    class Meta:
        model = ScheduleH
        fields = '__all__'


class WbsIndirectCostPlaningSerializer(serializers.ModelSerializer):
    """"
    WbsIndirectCostPlaning Serializer
    """
    cost_center_details = serializers.SerializerMethodField()
    def get_cost_center_details(self, instance):
        if instance.cost_center:
            return instance.cost_center.name
        else:
            return ""
    class Meta:
        model = WbsIndirectCostPlaning
        fields = '__all__'


class WbsTempPlaningSerializer(serializers.ModelSerializer):
    cost_center_details = serializers.SerializerMethodField()
    def get_cost_center_details(self, instance):
        if instance.cost_center:
            return instance.cost_center.name
        else:
            return ""
    class Meta:
        model = WbsTempPlaning
        fields = '__all__'

class DrawingTrackerDocumentsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False) 
    class Meta:
        model = DrawingTrackerDocuments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class DrawingTrackerSerializer(serializers.ModelSerializer):
    wbs_details=serializers.SerializerMethodField()
    form_details=serializers.SerializerMethodField()
    latest=serializers.SerializerMethodField()

    documents = DrawingTrackerDocumentsSerializer(
        many=True,
        required=False,
        source='boq_drawing_tracker_documents_drawing_tracker'
    )

    class Meta:
        model = DrawingTracker
        fields = '__all__'
    def get_wbs_details(self, instance):
   
        return get_details_from_instance(instance.wbs,extras=[], type="dict")
    def get_form_details(self, instance):
   
        return get_details_from_instance(instance.form,extras=[], type="dict")
    def get_latest(self, instance):
        ref = DrawingTracker.cmobjects.filter(
            wbs_id = instance.wbs.id,
            form_id = instance.form.id,
            side = instance.side,
        ).order_by('current_version').first()
        return ref.current_version if ref else None
    @transaction.atomic
    def create(self, validated_data):
        documents_data = validated_data.pop('boq_drawing_tracker_documents_drawing_tracker', [])
       
        drawing_tracker = DrawingTracker.objects.create(**validated_data)
        current_user = drawing_tracker.created_by if drawing_tracker.created_by else None
        for document_data in documents_data:
            processed_document_attachment = process_attachments(document_data)
            document_data.pop('mime_type', None)
            document_data.pop('file_data', None)
            DrawingTrackerDocuments.objects.create(
                **document_data,
                drawing_tracker=drawing_tracker,
                attachment=processed_document_attachment if processed_document_attachment else None,
                created_by=current_user,
            )

        return drawing_tracker

    @transaction.atomic
    def update(self, instance, validated_data):
        documents_data = validated_data.pop('boq_drawing_tracker_documents_drawing_tracker', [])

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        current_user = instance.updated_by if instance.updated_by else None

        existing_documents = instance.boq_drawing_tracker_documents_drawing_tracker.filter(is_deleted=False)

        for document_data in documents_data:
            document_id = document_data.get('id')
            processed_attachment = process_attachments(document_data)

            existing_document = next((item for item in existing_documents if item.id == document_id), None)

            if existing_document:
                for attr, value in document_data.items():
                    setattr(existing_document, attr, value)
                if processed_attachment:
                    existing_document.attachment = processed_attachment
                    existing_document.file_data = ""
                    existing_document.mime_type = ""
                existing_document.updated_by = current_user
                existing_document.save()
            else:
                document_data.pop('mime_type', None)
                document_data.pop('file_data', None)
                DrawingTrackerDocuments.objects.create(
                    **document_data,
                    drawing_tracker=instance,
                    attachment=processed_attachment if processed_attachment else None,
                    created_by=current_user,
                )

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['documents'] = representation.pop('documents', [])
        return representation
    


class WBSGanttDependsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    wbs_gantt__wbs=serializers.SerializerMethodField()
    linked_wbs_gantt__wbs=serializers.SerializerMethodField()

    def get_wbs_gantt__wbs(self, instance):
        return instance.wbs_gantt.wbs if instance.wbs_gantt else None

    def get_linked_wbs_gantt__wbs(self, instance):
        return instance.linked_wbs_gantt.wbs if instance.linked_wbs_gantt else None

    class Meta:
        model = WBSGanttDepends
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class WBSGanttSerializer(serializers.ModelSerializer):
    successors=serializers.SerializerMethodField()
    depends = WBSGanttDependsSerializer(
        many=True,
        required=False,
        source='boq_wbs_gantt_depends_wbs_gantt'
    )
    
    def get_successors(self, instance):
        # return WBSGanttDepends.cmobjects.filter(linked_wbs_gantt_id=instance.id).values('id','wbs_gantt','linked_type','lag')
        # return WBSGanttDependsSerializer(ref, many=True).data
        successors = instance.boq_wbs_gantt_depends_linked_wbs_gantt.filter(is_deleted=False).values('id', 'wbs_gantt', 'linked_type', 'lag')
        return list(successors)
    class Meta:
        model = WBSGantt
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        depends_data = validated_data.pop('boq_wbs_gantt_depends_wbs_gantt', [])
        wbs_gantt = WBSGantt.objects.create(**validated_data)
        current_user = wbs_gantt.created_by if wbs_gantt.created_by else None

        for depend_data in depends_data:
            WBSGanttDepends.objects.create(
                **depend_data,
                wbs_gantt=wbs_gantt,
                created_by=current_user,
            )
        return wbs_gantt

    @transaction.atomic
    def update(self, instance, validated_data):
        depends_data = validated_data.pop('boq_wbs_gantt_depends_wbs_gantt', [])

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        current_user = instance.updated_by if instance.updated_by else None
        existing_depends = instance.boq_wbs_gantt_depends_wbs_gantt.filter(is_deleted=False)

        for depend_data in depends_data:
            depend_id = depend_data.get('id')
            existing_depend = next((item for item in existing_depends if item.id == depend_id), None)

            if existing_depend:
                for attr, value in depend_data.items():
                    setattr(existing_depend, attr, value)
                existing_depend.updated_by = current_user
                existing_depend.save()
            else:
                WBSGanttDepends.objects.create(
                    **depend_data,
                    wbs_gantt=instance,
                    created_by=current_user,
                )

        for existing_depend in existing_depends:
            if existing_depend.id not in [depend.get('id') for depend in depends_data]:
                existing_depend.is_deleted = True
                existing_depend.updated_by = current_user
                existing_depend.save()

        return instance
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['depends'] = representation.pop('depends', [])
        return representation
    



class DrawingCategorySerializer(serializers.ModelSerializer):
    project_details=serializers.SerializerMethodField()

    class Meta:
        model = DrawingCategory
        fields = '__all__'
    def get_project_details(self, instance):
        project = instance.project
        if project:
            return get_project_data(instance.project.id)
        return None
    
class InvoiceScheduleSerializer(serializers.ModelSerializer):
    project_details=serializers.SerializerMethodField()

    class Meta:
        model = InvoiceSchedule
        fields = '__all__'
    def get_project_details(self, instance):
        project = instance.project
        if project:
            return get_project_data(instance.project.id)
        return None    
    

class InvoiceScheduleItemsSerializer(serializers.ModelSerializer):
    invoice_schedule_details=serializers.SerializerMethodField()

    class Meta:
        model = InvoiceScheduleItems
        fields = '__all__'
    def get_invoice_schedule_details(self,instance):
        return get_details_from_instance(instance.invoice_schedule, type="dict")
    


class InvoiceScheduleWBSTagSerializer(serializers.ModelSerializer):
    invoice_schedule_items_details=serializers.SerializerMethodField()
    wbs_details=serializers.SerializerMethodField()
    class Meta:
        model = InvoiceScheduleWBSTag
        fields = '__all__'

    def get_invoice_schedule_items_details(self,instance):
        return get_details_from_instance(instance.invoice_schedule_items, type="dict")
    
    def get_wbs_details(self,instance):
        return get_details_from_instance(instance.wbs, type="dict")
    
class InvoiceScheduleCertifiedFTMSerializer(serializers.ModelSerializer):
    invoice_schedule_items_details=serializers.SerializerMethodField()
    class Meta:
        model = InvoiceScheduleCertifiedFTM
        fields = '__all__'

    def get_invoice_schedule_items_details(self,instance):
        return get_details_from_instance(instance.invoice_schedule_items, type="dict")
    

class BOQMonthlyProgressDataSerializer(serializers.ModelSerializer):
    boq_details=serializers.SerializerMethodField()
    wbs_details=serializers.SerializerMethodField()
    class Meta:
        model = BOQMonthlyProgressData
        fields = '__all__'

    def get_boq_details(self,instance):
        return get_details_from_instance(instance.boq, type="dict")
    
    def get_wbs_details(self,instance):
        return get_details_from_instance(instance.wbs, type="dict")
    




## BOQMonthlyCostData
class BOQMonthlyCostDataSerializer(serializers.ModelSerializer):
    boq_details=serializers.SerializerMethodField()
    boq_id = serializers.PrimaryKeyRelatedField(
        queryset=BOQ.objects.all(), write_only=True, source='boq', required=False
    )
    class Meta:
        model = BOQMonthlyCostData
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']

    def get_boq_details(self,instance):
        return get_details_from_instance(instance.boq, type="dict")

