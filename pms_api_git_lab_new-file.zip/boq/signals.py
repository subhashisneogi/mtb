from django.db.models.signals import post_save, pre_delete
from django.db import transaction
from django.db.models import F,Func
from django.dispatch import receiver
from .models import *
from .serializers import *
from .helper import *
import random
import time

def change_lmpi_data(wbs_list_id,budgeted_quantity):
    class Round(Func):
        function = 'ROUND'
        arity = 2
    if wbs_list_id:
        if not budgeted_quantity:
            budgeted_quantity = 0.0
        data = {
            'quantity_without_wastage': Round((Round(F('quantity'), 3)*round(float(budgeted_quantity), 3)), 3),
            'budgeted_quantity': Round((Round((Round(F('quantity'), 3)*round(float(budgeted_quantity), 3)), 3)+Round((Round((Round(F('quantity'), 3)*round(float(budgeted_quantity), 3)), 3)*(F('wastage')/100)), 3)), 3),
            'cost': Round((Round(F('rate'), 2)*Round((Round((Round(F('quantity'), 3)*round(float(budgeted_quantity), 3)), 3)+Round((Round((Round(F('quantity'), 3)*round(float(budgeted_quantity), 3)), 3)*(F('wastage')/100)), 3)), 3)), 2),
            'balance_quantity': (Round((Round((Round(F('quantity'), 3)*round(float(budgeted_quantity), 3)), 3)+Round((Round((Round(F('quantity'), 3)*round(float(budgeted_quantity), 3)), 3)*(F('wastage')/100)), 3)), 3)-F('consumed_quantity'))
        }
        WBSLabour.cmobjects.filter(wbs_list_id=wbs_list_id).update(**data)
        WBSMaterial.cmobjects.filter(wbs_list_id=wbs_list_id).update(**data)
        WBSLabour.cmobjects.filter(wbs_list_id=wbs_list_id).update(**data)
        WBSLabour.cmobjects.filter(wbs_list_id=wbs_list_id).update(**data)


@receiver(pre_save, sender=WBSList)
def wbs_validate_unique(sender, instance, **kwargs):
    if instance.parent and instance.parent.boq_id != instance.boq_id:
        raise APIException({"request_status": 0, "msg": "Parent WBS must belong to the same BOQ as the current WBS."})
    if not instance.organization_id or not instance.boq_id or not instance.boq_code:
        return
    root_id = instance.root_id or (instance.root.pk if instance.root else None)
    if not root_id:
        return
    qs = WBSList.cmobjects.filter(organization_id=instance.organization_id,boq_id=instance.boq_id,root_id=root_id,boq_code=instance.boq_code)
    if instance.pk:
        qs = qs.exclude(pk=instance.pk)
    if qs.exists():
        raise APIException({
            'request_status': 0,
            'msg': f"WBS: BOQ Code {instance.boq_code} must be unique per BOQ"
        })

@receiver(post_save, sender=WBSList)
def handle_wbs_chainage(sender, instance, created, **kwargs):
    change_lmpi_data(instance.id,instance.budgeted_quantity)
    if not instance.boq:
        return
    if created and instance.parent is None:
        BOQChainage.objects.get_or_create(organization=instance.organization,boq=instance.boq,wbs=instance,
            defaults={"name": f"CH-{instance.boq.id}-{instance.pk}","start": 0,"end": 1})
    if instance.parent and instance.root:
        parent_chainage = BOQChainage.cmobjects.filter(boq=instance.boq, wbs=instance.root).first()
        if not parent_chainage:
            return
        if created:
            auto_value = generate_chainage_code(instance)
            BOQChainageExecutiveSummeryData.objects.get_or_create(organization=instance.organization,boq=instance.boq,wbs=instance,type="C", value__isnull=True, 
                defaults={"value": auto_value,"form": parent_chainage})
        if instance.budgeted_quantity:
            qty_obj, created_q = BOQChainageExecutiveSummeryData.objects.get_or_create(
                organization=instance.organization,boq=instance.boq,wbs=instance,type="Q",defaults={"value": instance.budgeted_quantity,"form": parent_chainage,})
            if not created_q:
                qty_obj.value = instance.budgeted_quantity
                qty_obj.save(update_fields=["value"])

@receiver(post_save, sender=BOQChainageExecutiveSummeryData)
def signal_update_wbs_list(sender, instance, **kwargs):
    print("in signal BOQChainageExecutiveSummeryData")
    if instance.wbs:
        change_lmpi_data(instance.wbs_id, instance.wbs.budgeted_quantity)

@receiver(post_save, sender=BOQMonthlyPlanningData)
def signal_boq_monthly_planning(sender, instance, created, **kwargs):
    with transaction.atomic():
        if created:
            filter_data = {}

            if instance.boq:
                filter_data['boq_id'] = instance.boq.id
            if instance.wbs:
                filter_data['wbs_id'] = instance.wbs.id
            if instance.form:
                filter_data['form_id'] = instance.form.id
            if instance.date:
                filter_data['date'] = instance.date
            if instance.side:
                filter_data['side'] = instance.side

            latest_entry = BOQMonthlyPlanningData.objects.filter(**filter_data).exclude(pk=instance.id).order_by('-version').first()

            if latest_entry:
                instance.version = latest_entry.version + 1
                instance.previous_version = latest_entry
                instance.save(update_fields=['version', 'previous_version'])

            BOQMonthlyPlanningData.objects.filter(**filter_data).exclude(pk=instance.id).update(is_latest=False)