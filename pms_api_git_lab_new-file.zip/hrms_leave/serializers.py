from rest_framework import serializers
from administrations.models import *


from .models import *
from attendance.models import *
import pdb


class LeaveAllocationSerializer(serializers.ModelSerializer):
    """
    Leave allocation Serializer
    """

    class Meta:
        model = LeaveAllocation
        fields = '__all__'


class EmployeeLeaveSerializer(serializers.ModelSerializer):
    full_status = serializers.SerializerMethodField(source='get_status_display', required=False)
    full_leave_type = serializers.ChoiceField(choices=EmployeeLeave.LEAVE_TYPES, source='get_leave_type_display', required=False)

    class Meta:
        model = EmployeeLeave
        fields = '__all__'
        extra_fields = ['full_status', 'full_leave_type']
        # extra_kwargs = {
        #     'full_status': {'required': False},
        #     'full_leave_type': {'required': False},
        # }

    def get_full_status(self, obj):
        return dict(EmployeeLeave.STATUS_CHOICES).get(obj.status)

    def get_leave_type_display(self, obj):
        return obj.get_leave_type_display()
    
    
class UserLeaveAllocationSerializer(serializers.ModelSerializer):

    class Meta:
        model = UserLeaveAllocation
        fields = '__all__'
