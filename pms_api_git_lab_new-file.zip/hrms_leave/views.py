from django.shortcuts import render
from rest_framework import status

from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response

from .models import *
from .serializers import *
# Create your views here.
import pdb


class LeaveAllocationViewSet(ModelViewSet):
    queryset = LeaveAllocation.objects.all()
    serializer_class = LeaveAllocationSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data.get('user')
        if not PmsUser.objects.filter(pk=user.pk).exists():
            raise serializers.ValidationError(
                "No user with the given id exists")
        year = serializer.validated_data.get('year')
        month = serializer.validated_data.get('month')
        leave_type = serializer.validated_data.get('leave_type')
        leave_exists = LeaveAllocation.objects.filter(
            user=user, year=year, month=month, leave_type=leave_type).exists()
        if leave_exists:
            raise serializers.ValidationError(
                "Leave record already exists for the user")

        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        method = request.query_params.get('method')
        print(method)
        if method == 'edit':
            return self.edit(request, *args, **kwargs)
        elif method == 'delete':
            return self.delete(request, *args, **kwargs)
        else:
            return Response({'error': 'Invalid method'}, status=status.HTTP_400_BAD_REQUEST)

    def edit(self, request, *args, **kwargs):

        instance = self.get_object()
        serializer = self.get_serializer(
            instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)

        allowed_fields = ['year', 'month', 'leave_type', 'amount']
        updated_data = {field: serializer.validated_data.get(
            field) for field in allowed_fields if field in serializer.validated_data}
        print(updated_data)
        serializer.update(instance, updated_data)
        return Response(serializer.data)

    def delete(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class EmployeeLeaveViewSet(ModelViewSet):
    queryset = EmployeeLeave.objects.all()
    serializer_class = EmployeeLeaveSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(created_by=self.request.user)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        method = request.query_params.get('method')
        # print(method)
        if method == 'edit':
            return self.edit(request, *args, **kwargs)
        elif method == 'delete':
            return self.deleted(request, *args, **kwargs)
        else:
            return Response({'error': 'Invalid method'}, status=status.HTTP_400_BAD_REQUEST)

    def edit(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(
            instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        serializer.save(updated_by=self.request.user)
        return Response(serializer.data)

    def deleted(self, request, *args, **kwargs):

        instance = self.get_object()
        # print(instance)
        instance.is_deleted = True
        instance.save()
        return Response({'msg': "Sucessfully deleted"}, status=status.HTTP_204_NO_CONTENT)


class UserLeaveAllocationViewSet(ModelViewSet):
    queryset = UserLeaveAllocation.objects.all()
    serializer_class = UserLeaveAllocationSerializer

    def update(self, request, *args, **kwargs):
        method = request.query_params.get('method')
        print(method)
        if method == 'edit':
            return self.edit(request, *args, **kwargs)
        elif method == 'delete':
            return self.delete(request, *args, **kwargs)
        else:
            return Response({'error': 'Invalid method'}, status=status.HTTP_400_BAD_REQUEST)

    def edit(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(
            instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def delete(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
