from django.apps import AppConfig


class HrmsLeaveConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hrms_leave'
