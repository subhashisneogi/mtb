from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from .models import *
# Register your models here.


@admin.register(LeaveAllocation)
class LeaveAllocationAdmin(ModelAdmin):
    pass


@admin.register(EmployeeLeave)
class EmployeeLeaveAdmin(ModelAdmin):
    pass


@admin.register(UserLeaveAllocation)
class UserLeaveAllocationAdmin(ModelAdmin):
    pass
