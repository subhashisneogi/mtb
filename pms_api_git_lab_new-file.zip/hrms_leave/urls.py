from . import views
from django.urls import path, include
from rest_framework import routers
from rest_framework.routers import DefaultRouter
from pprint import pprint
router = routers.DefaultRouter()
router.register('leaveallocation', views.LeaveAllocationViewSet,
                basename='leaveallocation')
router.register('EmployeeLeave', views.EmployeeLeaveViewSet,
                basename='EmployeeLeave')
router.register('UserLeaveAllocation', views.UserLeaveAllocationViewSet,
                basename='UserLeaveAllocation')
pprint(router)
urlpatterns = [
    path('', include(router.urls)),
]
