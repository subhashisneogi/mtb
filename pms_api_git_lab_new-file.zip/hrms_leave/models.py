from django.db import models
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.validators import FileExtensionValidator

from administrations.models import BaseAbstractStructure, PmsUser
from attendance.models import Attendance
from dynamic_media import get_directory_path
from validators import validate_file_extension
# Create your models here.


class EmployeeLeave(BaseAbstractStructure):
    employee = models.ForeignKey(
        PmsUser, related_name='leave_owned_by_employee', on_delete=models.CASCADE)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    LEAVE_TYPES = [
        ('CL', 'casual leave'),
        ('EL', 'earned leave'),
        ('AB', 'Absent'),
        ('AL', 'All Leave'),
        ('MT', 'Maternity'),
        ('BT', 'Bereavement'),
        ('CO', 'Covid'),
    ]
    leave_type = models.CharField(max_length=2, choices=LEAVE_TYPES)
    reason = models.TextField(max_length=255, blank=True, null=True)
    STATUS_CHOICES = [
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('R', 'Rejected')
    ]

    status = models.CharField(max_length=1, choices=STATUS_CHOICES)
    CATEGORY_CHOICES = [
        ('N', 'Normal'),
        ('S', 'Special'),
    ]
    category = models.CharField(max_length=1, choices=CATEGORY_CHOICES)
    remarks = models.TextField(blank=True, null=True)
    requested_on = models.DateTimeField(auto_now_add=True)
    approver = models.ForeignKey(
        PmsUser, related_name='leave_approver', on_delete=models.CASCADE, blank=True, null=True)
    document = models.FileField(upload_to=get_directory_path,
                                default=None,
                                blank=True, null=True,
                                validators=[validate_file_extension]
                                )

    def __str__(self):
        return f"{self.employee}'s {self.leave_type} leave from {self.start_date} to {self.end_date}"


class LeaveAllocation(models.Model):
    user = models.ForeignKey(
        PmsUser, related_name='leave_allocation', on_delete=models.CASCADE)
    year = models.PositiveIntegerField()
    month = models.PositiveIntegerField()
    leave_type = models.CharField(max_length=50)
    amount = models.PositiveIntegerField()


class UserLeaveAllocation(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='user_leave_allocation', on_delete=models.CASCADE)

    year = models.PositiveIntegerField()
    month = models.PositiveIntegerField()
    attendance = models.ManyToManyField('attendance.Attendance')
    leave_allocation = models.ManyToManyField(LeaveAllocation)

    def total_attendance_days(self):
        return self.attendance.filter(status='present').count()

    def total_leave_days(self):
        return sum(allocation.amount for allocation in self.leave_allocation.all())

    def available_leave_days(self):
        return self.total_leave_days() - self.total_attendance_days()





# @receiver(post_save, sender=EmployeeLeave)
# # sender, instance, created, **kwargs
# def create_deviation_on_advance_leave(instance, created, **kwargs):
#     """
#     Signal to create a Deviation on advance leave
#     """
#     from attendance.models import AttendenceDeviation, HrmsMaster
#     from administrations.utils import all_even_saturdays, all_odd_saturdays

#     import pandas as pd
#     from datetime import datetime

#     hr_master_details = HrmsMaster.objects.filter(
#             organization_id=instance.employee.organization_id).first()
    
#     start_date = instance.start_date
#     end_date = instance.end_date

#     if hr_master_details.saturday_off_type == 'even':
#         start_days_sat = all_even_saturdays(
#                     start_date.year, start_date.month)
#         end_days_sat = all_even_saturdays(
#                     end_date.year, end_date.month)
        
#         sat_list = [start_days_sat.get('second_saturday', None), start_days_sat.get('fourth_saturday', None),
#                             end_days_sat.get('second_saturday', None), end_days_sat.get('fourth_saturday', None)]

