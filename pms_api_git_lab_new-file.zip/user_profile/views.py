from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from rest_framework.parsers import FileUploadParser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.db.models import F, Value, CharField
from django.db.models.functions import Concat
import pandas as pd
import numpy as np
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from administrations.models import PmsUser,Organization
from knox.auth import TokenAuthentication
from rest_framework import generics
from django.core.paginator import Paginator
from django.utils import timezone
from .models import *
from .serializers import *
import datetime

from custom_decorator import *
from pagination import *
import os
from django.db.models import Value as V
from django.db.models.functions import Concat
from django.core.paginator import Paginator
from procurement.helper import custom_filters , password_expiry_date_reset
from administrations.utils import create_userwise_permissions
from project_and_planning.models import ProjectMaster
from procurement.models import StoreMaster, SiteMaster

class UsersRegistration(generics.ListCreateAPIView):
    
    
    # pagination_class =CSPageNumberPagination
    queryset = PmsUser.objects.filter(is_deleted=False)
    serializer_class = UserCreateSerializer


class UserDeletedListView(generics.ListAPIView):
    
    
    queryset = PmsUser.objects.filter(is_deleted=True)
    serializer_class = UserListSerializer
    pagination_class = OnOffPagination

    def get_queryset(self):
        organisation = self.request.query_params.get('organisation', None)
        queryset = self.queryset.filter(organization_id=organisation)
        return queryset



class EditUserView(generics.RetrieveUpdateAPIView):
    """
    View for user update
    using user ID
    login user and provided user must be same.. or must be admin
    email, cu_emp_code and username only change by admin
    if img is exist and need to update, than, it will be deleted fast and than update
    """
    
    
    serializer_class = EditUserSerializer
    lookup_field = 'id'
    
    def get_queryset(self):
        user_id = self.kwargs["id"]
        # if str(self.request.user.id) == user_id or self.request.user.is_superuser:
        return PmsUser.objects.filter(is_deleted=False)
        # else:
        #     raise APIException({'request_status': 0, 'msg': 'Login user is different'})
        
class PmsUserDeleteView(APIView):
    def put(self, request):
        method = request.query_params.get('method', None)
        id = request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                user =  PmsUser.objects.filter(pk=id).first()
                print(user)
                user.is_deleted = True
                user.is_active = False
                user.deleted_by = request.user
                user.deleted_on = datetime.datetime.now()
                user.save()
                return Response({'message': 'User deleted successfully'}, status=status.HTTP_200_OK)
            elif method.lower() == 'undelete':
                user = PmsUser.objects.filter(pk=id).first()
                user.is_deleted = False
                user.is_active = True
                user.deleted_by = None
                user.deleted_on = None
                user.save()
                return Response({'message': 'User undeleted successfully'}, status=status.HTTP_200_OK)
            
            else:
                return Response({'error': 'Invalid method'}, status=status.HTTP_400_BAD_REQUEST)
            
class PmsUserListView(generics.ListAPIView):
    
    
    queryset = PmsUser.objects.filter(is_deleted=False)
    serializer_class = UserListSerializer
    pagination_class = OnOffPagination

    def get_queryset(self):
        organisation = self.request.query_params.get('organisation', None)
        id = self.request.query_params.get('id', None)
        company_id = self.request.query_params.get('company_id', None)
        email_id = self.request.query_params.get('email_id', None)
        username = self.request.query_params.get('username', None)
        search = self.request.query_params.get('search', None)
        profile = self.request.query_params.get('profile', None)
        ##################### Getlist Query Parameters Not For Multiselect #######################
        # department_ids = self.request.query_params.get('department', None)
        # designation_ids = self.request.query_params.get('designation', None)
        # employement_type_ids = self.request.query_params.get('employement_type', None)
        # role_ids = self.request.query_params.get('role_id', None)
        # state_ids = self.request.query_params.get('state_id', None)
        # city_ids = self.request.query_params.get('city_id', None)
        # zone_ids = self.request.query_params.get('zone_id', None)
        ##########################################################################################

        #zone_ids = self.request.query_params.getlist('zone_id', [])

        ##################### Getlist Query Parameters For Multiselect #######################
        department_ids = self.request.query_params.getlist('department', [])
        designation_ids = self.request.query_params.getlist('designation', [])
        employement_type_ids = self.request.query_params.getlist('employement_type', [])
        role_ids = self.request.query_params.getlist('role_id', [])
        state_ids = self.request.query_params.getlist('state_id', [])
        city_ids = self.request.query_params.getlist('city_id', [])
        zone_ids = self.request.query_params.getlist('zone_id', [])

        ######################################################################################


        department_ids = [int(department_id) if department_id else 0 for department_id in department_ids]
        designation_ids = [int(designation_id) if designation_id else 0 for designation_id in designation_ids]
        employement_type_ids = [int(employement_type_id) if employement_type_id else 0 for employement_type_id in employement_type_ids]
        role_ids = [int(roleid) if roleid else 0 for roleid in role_ids]
        zone_ids = [int(zone_id) if zone_id else 0 for zone_id in zone_ids]
        state_ids = [int(state_id) if state_id else 0 for state_id in state_ids]
        city_ids = [int(city_id) if city_id else 0 for city_id in city_ids]

        # print(department_ids)
        from django.db.models import Value as V
        from django.db.models.functions import Concat

        filter = {}
        if organisation:
            filter['organization_id'] = organisation
        if designation_ids and not 0 in designation_ids:
            filter['designation_id__in'] = designation_ids
        if department_ids and not 0 in department_ids:
            filter['department_id__in'] = department_ids
        if id:
            filter['id'] = id
        if company_id:
            filter['company_name_id'] = company_id
        if employement_type_ids and not 0 in employement_type_ids:
            filter['employement_type_id__in'] = employement_type_ids
        if email_id:
            filter['email'] = email_id
        if username:
            filter['username__iexact'] = username
        if role_ids and not 0 in role_ids:
            filter['role_id__in'] = role_ids
        if state_ids and not 0 in state_ids:
            filter['state_id__in'] = state_ids
        if city_ids and not 0 in city_ids:
            filter['city_id__in'] = city_ids
        if zone_ids and not 0 in zone_ids:
            filter['zone_id__in'] = zone_ids

        field_name = self.request.query_params.get('field_name', None)
        order_by = self.request.query_params.get('order_by', None)

        if not field_name:
            sort_field = '-id'
        else:
            if field_name == 'name':
                if order_by == 'asc':
                    sort_field = 'full_name'
                else:
                    sort_field = '-full_name'
            else:
                if order_by == 'asc':
                    sort_field = field_name
                else:
                    sort_field = '-' + str(field_name)
        if not profile:
            if search:
                search = search.lstrip()
                search = search.rstrip()
            
                user_ids = list(UserProfile.objects.filter(phone_no__icontains=search).values_list('user_id', flat=True))
                result= PmsUser.objects.annotate(full_name=Concat('first_name', V(' '), 'last_name'))
                result = result.filter((Q(full_name__icontains=search)|\
                                                Q(email__icontains=search)|Q(id__in=user_ids)),**filter).exclude(id=self.request.user.id).order_by(sort_field)
                # result = self.queryset.filter((Q(first_name__icontains=search)|Q(last_name__icontains=search)|\
                #                                Q(email__icontains=search)|Q(id__in=user_ids)),**filter).exclude(id=self.request.user.id).order_by(sort_field)
            else:
                result = self.queryset.annotate(full_name=Concat('first_name', V(' '), 'last_name')).filter(**filter).exclude(id=self.request.user.id).order_by(sort_field)
        else:
            if search:
                search = search.lstrip()
                search = search.rstrip()
            
                user_ids = list(UserProfile.objects.filter(phone_no__icontains=search).values_list('user_id', flat=True))
                result= PmsUser.objects.annotate(full_name=Concat('first_name', V(' '), 'last_name'))
                result = result.filter((Q(full_name__icontains=search)|\
                                                Q(email__icontains=search)|Q(id__in=user_ids)),**filter).order_by(sort_field)
                # result = self.queryset.filter((Q(first_name__icontains=search)|Q(last_name__icontains=search)|\
                #                                Q(email__icontains=search)|Q(id__in=user_ids)),**filter).exclude(id=self.request.user.id).order_by(sort_field)
            else:
                result = self.queryset.annotate(full_name=Concat('first_name', V(' '), 'last_name')).filter(**filter).order_by(sort_field)
        return result

    def get(self, request, *args, **kwargs):
        #return super(__class__, self).get(self, request, *args, **kwargs)
        from django.core.paginator import Paginator

        all = self.request.query_params.get('all', None)
        is_active = self.request.query_params.get('is_active', None)
        queryset = self.filter_queryset(self.get_queryset())

        is_active_true_count = queryset.filter(is_active=True).count()
        is_active_false_count = queryset.filter(is_active=False).count()

        if is_active:
            if is_active == "true":
                queryset = queryset.filter(is_active=True)
            else:
                queryset = queryset.filter(is_active=False)            

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = self.get_serializer(page, many=True)

        if all == 'true':
            serializer = self.get_serializer(queryset, many=True)
            return Response({'results': serializer.data})

        response_data = {
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
            'active_count': is_active_true_count,
            'inactive_count': is_active_false_count,
        }
        return Response(response_data)
    

class UserCustomListAPIView(APIView):
    """
    CRUD API for PMS USER LIST
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all PMS USER LIST
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            user = PmsUser.objects.filter(id = id).first()
            serializer = UserCustomListSerializer(user)
            return Response(serializer.data)

        search = {'is_deleted': False}
        search = custom_filters(self.request, search, [])
        user_list = PmsUser.objects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = UserCustomListSerializer(user_list, many=True)
            return Response({
                'results': serializer.data,
            })
        serializer = UserCustomListSerializer(user_list, many=True)
        return Response(serializer.data)
    

class UserCustomUpdatedListAPIView(APIView):
    """
    CRUD API for PMS USER LIST
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all PMS USER LIST
        """
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        user_list = PmsUser.objects.select_related(
            'company_name',
            'department',
            'designation',
        ).prefetch_related(
            'user_profile',
            'user_reporting_manager',
        ).annotate(
            phone_no=F('user_profile__phone_no'),
            company_name_name=F('company_name__name'),
            department_name=F('department__department'),
            designation_name=F('designation__designation'),
            full_name=Concat('first_name',Value(' '),'last_name'),
            zone_name=F('zone__zone_name'),
            state_name=F('state__name'),
            city_name=F('city__name'),
            reporting_manager_name=Concat('reporting_manager__first_name',Value(' '),'reporting_manager__last_name'),
            role_name=F('role__role_name'),
        ).filter(
            *search,
            is_deleted=False
        ).order_by(*str(order_by).split(",")).values().distinct()

        if all == 'true':
            return Response({'results': user_list})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(user_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': page.object_list,
        })
    

class UserCustomListByPermissionAPIView(APIView):
    """
    CRUD API for PMS USER LIST
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all PMS USER LIST
        """
        permissions_list = []
        permissions = self.request.query_params.get('permissions', None)
        if permissions:
            permissions_list = permissions.split(',')
        organization_id = self.request.query_params.get('organization_id', None)
        user_list = UserWiseModulePermissions.cmobjects.annotate(
            full_name = Concat(F('user__first_name'),Value(' '),F('user__last_name'))
        ).filter(
            organization_id = organization_id,
            level_permission=True,
            module_item__unique_id__in=permissions_list,
        ).values('user_id','full_name')
        return Response([dict(t) for t in {tuple(d.items()) for d in user_list}])

class UserBulkImportAPI(APIView):
    
    
    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {
                    'items_created': 0,
                    'items_updated': 0,
                    'errors': 0,
                    'sheets_processed': [],
                    'sector_data_count': {}
                }
                errors = []
                organization_id = request.query_params.get('organization_id')
                if not organization_id:
                    raise APIException({'request_status': 0, 'msg': "Organization ID is required"})
                
                store_id = request.data.get('store_id')
                store_dict = {}
                if store_id:
                    store_queryset = StoreMaster.cmobjects.select_related('site__project').filter(
                        organization_id=organization_id,
                        id=store_id
                    ).values('id', 'site_id', 'site__project_id').first()
                    store_dict = store_queryset
                user_ids = []
                file_name = request.data.get('file_name')
                field_map = request.data.get('field_map')
                if not file_name or not field_map:
                    raise APIException({'request_status': 0, 'msg': "Missing file_name or field_map"})
                file_path = os.path.join('media', 'excel', file_name)
                if not os.path.exists(file_path):
                    raise APIException({'request_status': 0, 'msg': f"File '{file_name}' not found on server"})

                try:
                    excel_file = pd.ExcelFile(file_path)
                    all_sheets = {}
                    for sheet_name in excel_file.sheet_names:
                        sheet_df = pd.read_excel(excel_file, sheet_name=sheet_name)
                        sheet_df = sheet_df.fillna("").applymap(lambda x: x.strip() if isinstance(x, str) else x)
                        sheet_df = sheet_df.fillna(np.nan).replace([np.nan], [None])
                        all_sheets[sheet_name] = sheet_df
                except Exception as e:
                    raise APIException({'request_status': 0, 'msg': f"Error reading and cleaning Excel: {str(e)}"})

                pms_users_list = pd.DataFrame(PmsUser.objects.filter(is_deleted=False).values('id', 'employe_code', 'email', 'username', 'first_name', 'last_name', 'pan_number'))
                user_type_list = pd.DataFrame(UserType.cmobjects.filter(organization_id=organization_id).values('id', 'user_type'))
                company_list = pd.DataFrame(Company.cmobjects.filter(organization_id=organization_id, users__in=[request.user]).values('id', 'name'))
                department_list = pd.DataFrame(Department.cmobjects.filter(organization_id=organization_id).values('id', 'department'))
                designation_list = pd.DataFrame(Role.cmobjects.filter(organization_id=organization_id).values('id', 'designation'))
                profle_list = pd.DataFrame(Profile.cmobjects.filter(organization_id=organization_id).values('id', 'role_name'))
                state_list = pd.DataFrame(State.objects.all().values('state_id', 'name'))
                country_list = pd.DataFrame(Country.objects.all().values('country_id', 'name'))
                city_list = pd.DataFrame(City.objects.all().values('city_id', 'name'))
                zone_list = pd.DataFrame(Zone.cmobjects.filter(organization_id=organization_id).values('id', 'zone_name'))

                def process_str(x):
                    if isinstance(x, str):
                        # x = x.lower().strip().replace(' ', '')
                        x = x.strip()
                    return x
                
                def handle_date(value, default=None):
                    if pd.isna(value) or value is None:
                        return default
                    if isinstance(value, (pd.Timestamp, pd._libs.tslibs.timestamps.Timestamp, pd._libs.tslibs.nattype.NaTType)):
                        if pd.isna(value):
                            return default
                        return value.date()
                    if isinstance(value, str):
                        first_date_str = value.split('&')[0].strip()
                    else:
                        first_date_str = str(value).split('&')[0].strip()
                    try:
                        dt = pd.to_datetime(first_date_str, errors='coerce')
                        if pd.isna(dt):
                            return default
                        return dt.date()
                    except Exception:
                        return default
                    
                def process_numeric(value, default=0.0):
                    if pd.isna(value) or value == "":
                        return default
                    try:
                        return float(value)
                    except (ValueError, TypeError):
                        return default

                def check_pms_users(email=None, employe_code=None, username=None, reporting_manager=None, pan_number=None):
                    match = None
                    if email:
                        email_clean = str(email).strip().lower()
                        match = pms_users_list[pms_users_list['email'].str.strip().str.lower() == email_clean]
                    elif employe_code:
                        employe_code_clean = str(employe_code).strip().lower()
                        match = pms_users_list[pms_users_list['employe_code'].str.strip().str.lower() == employe_code_clean]
                    elif username:
                        username_clean = str(username).strip().lower()
                        match = pms_users_list[pms_users_list['username'].str.strip().str.lower() == username_clean]
                    elif reporting_manager:
                        parts = str(reporting_manager).strip().lower().split(" ", 1)
                        if len(parts) == 2:
                            first_name_clean, last_name_clean = parts
                            match = pms_users_list[
                                (pms_users_list['first_name'].str.strip().str.lower() == first_name_clean) &
                                (pms_users_list['last_name'].str.strip().str.lower() == last_name_clean)
                            ]
                    elif pan_number:
                        pan_number_clean = str(pan_number).strip().lower()
                        match = pms_users_list[pms_users_list['pan_number'].str.strip().str.lower() == pan_number_clean]

                    return match.iloc[0]['id'] if match is not None and not match.empty else None

                def check_user_type(name):
                    name_clean = str(name).strip().lower()
                    match = user_type_list[user_type_list['user_type'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None
                def check_department(name):
                    name_clean = str(name).strip().lower()
                    match = department_list[department_list['department'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None
                def check_company(name):
                    name_clean = str(name).strip().lower()
                    match = company_list[company_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None
                def check_designation(name):
                    name_clean = str(name).strip().lower()
                    match = designation_list[designation_list['designation'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None
                def check_profle(name):
                    name_clean = str(name).strip().lower()
                    match = profle_list[profle_list['role_name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None
                def check_state(name):
                    name_clean = str(name).strip().lower()
                    match = state_list[state_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['state_id'] if not match.empty else None
                def check_country(name):
                    name_clean = str(name).strip().lower()
                    match = country_list[country_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['country_id'] if not match.empty else None
                def check_city(name):
                    name_clean = str(name).strip().lower()
                    match = city_list[city_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['city_id'] if not match.empty else None
                def check_zone(name):
                    name_clean = str(name).strip().lower()
                    match = zone_list[zone_list['zone_name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None

                for sheet_name, sheet_df in all_sheets.items():
                    if sheet_df.empty:
                        continue
                    sheet_df.columns = [str(col).strip() for col in sheet_df.columns]
                    count_data['sheets_processed'].append(sheet_name)
                    for index, row in sheet_df.iterrows():
                        row_data = {col: row[col] for col in sheet_df.columns}
                        row_no = index + 2
                        if not field_map.get('email'):
                            errors.append(f"Email column Not Found for {index}")
                            count_data['errors'] += 1
                            continue
                        email = str(row_data.get(field_map.get('email'), "")).strip().lower()
                        if not email:
                            errors.append(f"Email Not Found for row {row_no}")
                            count_data['errors'] += 1
                            continue
                        employee_code = str(row_data.get(field_map.get('employee_code'))).strip()
                        employement_type = str(row_data.get(field_map.get('employement_type'), "").strip().lower())
                        employement_type_id = check_user_type(employement_type)
                        company_name = str(row_data.get(field_map.get('company_name'), "").strip().lower())
                        company_id = check_company(company_name)
                        department = str(row_data.get(field_map.get('department'), "").strip().lower())
                        department_id = check_department(department)
                        profile = str(row_data.get(field_map.get('profile'), "").strip().lower())
                        profile_id = check_profle(profile)
                        # designation=Role
                        designation = str(row_data.get(field_map.get('designation'), "").strip().lower())
                        designation_id = check_designation(designation)
                        country = str(row_data.get(field_map.get('country'), "").strip().lower())
                        country_id = check_country(country)
                        state = str(row_data.get(field_map.get('state'), "").strip().lower())
                        state_id = check_state(state)
                        city = str(row_data.get(field_map.get('city'), "").strip().lower())
                        city_id = check_city(city)
                        zone = str(row_data.get(field_map.get('zone'), "").strip().lower())
                        zone_id = check_zone(zone)
                        reporting_manager = str(row_data.get(field_map.get('reporting_manager'), "").strip().lower())
                        reporting_manager_id = check_pms_users(reporting_manager)
                        defaults = {
                            'organization_id': organization_id,
                            'email' : email,
                            'username' : email if email else employee_code,
                            'employe_code' : employee_code,
                            'employement_type_id' : employement_type_id,
                            'company_name_id' : company_id,
                            'department_id' : department_id,
                            'reporting_manager_id' : reporting_manager_id,
                            'designation_id' : designation_id,
                            'role_id' : profile_id,
                            'state_id': state_id,   
                            'city_id' : city_id,
                            'country_id' : country_id,
                            'zone_id' : zone_id,
                            "aadhar_number": str(row_data.get(field_map.get('aadhar_number', ''), '')),
                            "first_name": str(row_data.get(field_map.get('first_name', ''), '')),
                            "last_name": str(row_data.get(field_map.get('last_name', ''), '')),
                            "gender": str(row_data.get(field_map.get('gender', ''), '')),
                            "blood_group": str(row_data.get(field_map.get('blood_group', ''), '')),
                            "notice_period": str(row_data.get(field_map.get('notice_period', ''), '')),
                            "pan_number": str(row_data.get(field_map.get('pan_number'), "")),
                            "joining_date": handle_date(row_data.get(field_map.get('joining_date'))),
                            "last_working_date" : handle_date(row_data.get(field_map.get('last_working_date'))), 
                            "date_of_birth" : handle_date(row_data.get(field_map.get('date_of_birth'))),
                            "address_line_1": str(row_data.get(field_map.get('address_line_1', ''), '')),
                            "address_line_2": str(row_data.get(field_map.get('address_line_2', ''), '')),
                            "hrms_user_id" : process_numeric(row_data.get(field_map.get('hrms_user_id'))),
                            "sap_personnel_no" : str(row_data.get(field_map.get('sap_personnel_no', ''), '')),
                            "mothers_name" : str(row_data.get(field_map.get('mothers_name', ''), '')),
                            "fathers_name" : str(row_data.get(field_map.get('fathers_name', ''), '')),
                            "emergency_contact_relation" : str(row_data.get(field_map.get('emergency_contact_relation', ''), '')),
                            "emergency_contact_name" : str(row_data.get(field_map.get('emergency_contact_name', ''), '')),
                            "emergency_contact_phone_no" : str(row_data.get(field_map.get('emergency_contact_phone_no', ''), '')),
                            "maratial_status" : str(row_data.get(field_map.get('maratial_status', ''), '')),
                        }
                        user_lookup = {
                            "organization_id": organization_id,
                            "is_deleted": False,
                            "email" : email,
                        }
                        obj, created = PmsUser.objects.update_or_create(
                            defaults=defaults,
                            **user_lookup
                        )
                        if created:
                            defaults["created_by"] = request.user
                            count_data["items_created"] += 1
                        else:
                            obj.updated_by = request.user
                            obj.set_password("Secret@123")
                            obj.password_expiry_date = password_expiry_date_reset()
                            obj.save()
                            count_data["items_updated"] += 1
                        user_ids.append(obj.id)

                        UserProfile.objects.update_or_create(
                            user=obj,
                            defaults={
                                "email": email,
                                "first_name": str(row_data.get(field_map.get("first_name", ""), "")),
                                "last_name": str(row_data.get(field_map.get("last_name", ""), "")),
                                "phone_no": str(row_data.get(field_map.get("phone_no", ""), "")),
                                "password_to_know": "Secret@123",
                            }
                        )
                        if obj and profile_id:
                            create_userwise_permissions(profile_id, obj.id, organization_id)

                        uidb64 = urlsafe_base64_encode(smart_bytes(obj.id))
                        token = PasswordResetTokenGenerator().make_token(obj)
                        absurl = str(os.getenv("FE_FORGET_PASSWORD", "")) + uidb64 + "/" + token

                        if email:
                            trigger_notifications(
                                action="RESET-PASSWORD-NEW-USER",
                                subject="PMS Account Created",
                                user_list=[obj.id],
                                context={
                                    "reset_link": absurl,
                                    "email": email,
                                    "password": "Secret@123",
                                    "first_name": str(row_data.get(field_map.get("first_name", ""), "")),
                                },
                            )

                if user_ids and store_dict:
                    store_instance = StoreMaster.cmobjects.filter(
                        id=store_dict['id'],
                        organization_id=organization_id
                    ).first()
                    site_instance = None
                    project_instance = None
                    if store_dict.get('site_id'):
                        site_instance = SiteMaster.cmobjects.filter(
                            id=store_dict['site_id'],
                            organization_id=organization_id
                        ).first()
                    if store_dict.get('site__project_id'):
                        project_instance = ProjectMaster.cmobjects.filter(
                            id=store_dict['site__project_id'],
                            organization_id=organization_id
                        ).first()
                    users = PmsUser.objects.filter(id__in=user_ids)
                    if store_instance:
                        store_instance.users.add(*users)
                    if site_instance:
                        site_instance.users.add(*users)
                    if project_instance:
                        project_instance.users.add(*users)

                return Response({
                    'request_status': 1,
                    'msg': 'User data imported successfully.',
                    'data': count_data,
                    'errors': errors,
                })
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e)})

class ExcelUploadView(APIView):
    
    
    
    parser_class = (FileUploadParser,)
    """
    This class represents a file upload in Excel format and represents the data
    """
    def post(self, request, *args, **kwargs):
        file = request.data['file']
        path = 'media/excel/' + file.name
        if not os.path.exists('media/excel'):
            os.makedirs('media/excel')
        with open(path, 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)
        df = pd.read_excel(path)
        file = pd.ExcelFile(path)
        print(file.sheet_names)
        column_names = df.columns.tolist()
        return Response(column_names, status=status.HTTP_201_CREATED)

class ExcelDataMapperView(APIView):
    
    
    
    """
    This class is accountable for transforming data from excel into a format specified by the user, 
    and then inserting it into the database.
    """
    
    def post(self, request, *args, **kwargs):
        file_name = request.data.get('file_name', None)
        fields = request.data.get('fields', None) # fields is required to search in excel file
        organization_id = self.request.query_params.get('organization_id', None)
        if not organization_id or organization_id == "null":
            return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
        if file_name is None:
            return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
        if fields is None:
            return Response({'error': 'fields is required'}, status=status.HTTP_400_BAD_REQUEST)
        path = 'media/excel/' + file_name
        if not os.path.exists(path):
            return Response({'error': 'file not found'}, status=status.HTTP_404_NOT_FOUND)
        
        df = pd.read_excel(path)
        df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
        df = df.fillna('None')
        fields = fields.split(',')  # fields list to columns
        data = df[fields].to_dict(orient='records') # convert Excel data to dictionary
        field_map = {
            'first_name': request.data.get('first_name', None), 
            'last_name': request.data.get('last_name', None),
            'email': request.data.get('email', None),
            # 'username':request.data.get('username', None),
            'phone_no':request.data.get('phone_no', None),
            #'password':request.data.get('password', None),
            'gender':request.data.get('gender', None),
            'blood_group':request.data.get('blood_group', None),
            'notice_period':request.data.get('notice_period', None),
            'employe_code':request.data.get('employe_code', None),
            #'zone' :request.data.get('zone', None),
            'employement_type' :request.data.get('employement_type', None),
            'company_name' :request.data.get('company_name', None),
            'designation' :request.data.get('designation', None),
            'department' :request.data.get('department', None),
            #'role' :request.data.get('role', None),
            # 'country' :request.data.get('country', None),
            # 'state' :request.data.get('state', None),
            # 'city' :request.data.get('city', None),
            'aadhar_number':request.data.get('aadhar_number', None),
            'pan_number' :request.data.get('pan_number', None),
            # 'mothers_name' : request.data.get('mothers_name', None),
            # 'fathers_name' : request.data.get('fathers_name', None),
            # 'emergency_contact_relation' : request.data.get('emergency_contact_relation', None),
            # 'emergency_contact_name' : request.data.get('emergency_contact_name', None),
            # 'emergency_contact_phone_no' : request.data.get('emergency_contact_phone_no', None),
            # 'maratial_status' : request.data.get('maratial_status', None),
            'joining_date' : request.data.get('joining_date', None),
            'last_working_date' : request.data.get('last_working_date', None),
            'date_of_birth' : request.data.get('date_of_birth', None),
            'reporting_manager' : request.data.get('reporting_manager', None),
            'address_line_1' : request.data.get('address_line_1', None),
            'address_line_2' : request.data.get('address_line_2', None),
            'hrms_user_id' : request.data.get('hrms_user_id', None),
            'sap_personnel_no' : request.data.get('sap_personnel_no', None),
            
        } # field_map is required for mappning frontend field to excel column
        failed_username = [] 
        field_blank = []
        #missing_objs = []
        for item in data:
            reporting_manager_id = None
            first_name = item.get(field_map.get('first_name'), None)
            last_name = item.get(field_map.get('last_name'), None)
            email = item.get(field_map.get('email'), None)
            # username = item.get(field_map.get('username'), None)
            #username = email
            phone_no= item.get(field_map.get('phone_no'), None)
            #password = item.get(field_map.get('password'), None)
            gender = item.get(field_map.get('gender'), None)
            blood_group = item.get(field_map.get('blood_group'), None)
            notice_period= item.get(field_map.get('notice_period'), None)
            employe_code= item.get(field_map.get('employe_code'), None)
            ################### Updated fields ################# on 04-05-2022 #################################
            
            ############## Commented on 05-05-2023 #################################################################
            # mothers_name = item.get(field_map.get('mothers_name'), None)
            # fathers_name = item.get(field_map.get('fathers_name'), None)
            # emergency_contact_relation = item.get(field_map.get('emergency_contact_relation'), None)
            # emergency_contact_name = item.get(field_map.get('emergency_contact_name'), None)
            # emergency_contact_phone_no = item.get(field_map.get('emergency_contact_phone_no'), None)
            # maratial_status = item.get(field_map.get('maratial_status'), None)
            ############## Commented on 05-05-2023  end#################################################################
            
            joining_date = item.get(field_map.get('joining_date'), None)
            last_working_date = item.get(field_map.get('last_working_date'), None)
            date_of_birth = item.get(field_map.get('date_of_birth'), None)
            reporting_manager = item.get(field_map.get('reporting_manager'), None)
            address_line_1 = item.get(field_map.get('address_line_1'), None)
            address_line_2 = item.get(field_map.get('address_line_2'), None)
            hrms_user_id = item.get(field_map.get('hrms_user_id'), None)
            sap_personnel_no = item.get(field_map.get('sap_personnel_no'), None)
            
            ################### Updated fields ends ################# on 04-05-2022 #################################
            # try:
            #     zone = Zone.objects.get(zone_name=item.get(field_map.get('zone'), None))
            # except Zone.DoesNotExist:
            #     missing_objs.append('zone')
            # reporting_manager_parts = reporting_manager.strip().split()
            # print(reporting_manager_parts)
            try:
                # reporting_manager = PmsUser.objects.filter(Q(user_full_name__iexact=reporting_manager.strip())).first()
                reporting_manager = PmsUser.objects.annotate(user_full_name_updated=Concat('user_profile__first_name', Value(' '), 'user_profile__last_name', output_field=CharField())).filter(Q(user_full_name_updated__iexact=reporting_manager.strip())).first()
                # if len(reporting_manager_parts) == 2:
                #     first_name_strip, last_name_strip = reporting_manager_parts
                #     reporting_manager = PmsUser.objects.filter(
                #     Q(user_profile__last_name__iexact=last_name_strip) | Q(user_profile__first_name__iexact=first_name_strip) 
                #     ).first()
                # else:
                #     reporting_manager = PmsUser.objects.filter(
                #         Q(user_profile__last_name__iexact=reporting_manager.strip()) | Q(user_profile__first_name__iexact=reporting_manager.strip()) | Q(user_profile__email__iexact=reporting_manager.strip())
                #     ).first()
                # reporting_manager= reporting_manager.id
                # print(reporting_manager)
                if reporting_manager:
                    reporting_manager_id = reporting_manager.id
                
            except PmsUser.DoesNotExist:
                return Response({'msg':"Invalid reporting manager"})
            try:
                employement_type = UserType.objects.filter(user_type=item.get(field_map.get('employement_type'), None),\
                                                           organization_id=organization_id).first()
            except UserType.DoesNotExist:
                employement_type = UserType.objects.create(user_type=item.get(field_map.get('employement_type'), None),\
                                                                   organization_id=organization_id)
                employement_type.save()

            try:
                company_name = Company.objects.filter(name=item.get(field_map.get('company_name'), None),\
                                                   organization_id=organization_id).first()
            except Company.DoesNotExist:
                company_name = Company.objects.create(name=item.get(field_map.get('company_name'), None),\
                                                                   organization_id=organization_id)
                company_name.save()

            try:
                designation = Role.objects.filter(designation=item.get(field_map.get('designation'), None),\
                                                      organization_id=organization_id).first()
            except Role.DoesNotExist:
                designation = Role.objects.create(designation=item.get(field_map.get('designation'), None),\
                                                                   organization_id=organization_id)
                designation.save()

            try:
                department = Department.objects.filter(department=item.get(field_map.get('department'), None),\
                                                    organization_id=organization_id).first()
            except Department.DoesNotExist:
                department = Department.objects.create(department=item.get(field_map.get('department'), None),\
                                                                   organization_id=organization_id)
                department.save()

            # try:
            #     role = Profile.objects.get(role_name=item.get(field_map.get('role'), None))
            # except Profile.DoesNotExist:
            #     missing_objs.append('role')

            # try:
            #     country = Country.objects.get(name=item.get(field_map.get('country'), None))
            # except Country.DoesNotExist:
            #     missing_objs.append('country')

            # try:
            #     state = State.objects.get(name=item.get(field_map.get('state'), None))
            # except State.DoesNotExist:
            #     missing_objs.append('state')

            # try:
            #     city = City.objects.get(name=item.get(field_map.get('city'), None))
            # except City.DoesNotExist:
            #     missing_objs.append('city')
                    
            # if missing_objs:
            #     message = 'Invalid objects: {}'.format(', '.join(missing_objs))
            #     return Response({'message': message,'status':status.HTTP_400_BAD_REQUEST,}, status=status.HTTP_400_BAD_REQUEST)

            aadhar_number = item.get(field_map.get('aadhar_number'), None)
            pan_number = item.get(field_map.get('pan_number'), None)

            if PmsUser.objects.filter(email=email, is_deleted=True).exists(): # Username already exists validation
                return Response({'message': 'Email ' + str(email) + ' already exists in deleted user list, if you wish to restore please restore it from deleted user list!','status':status.HTTP_400_BAD_REQUEST,},\
                                status=status.HTTP_400_BAD_REQUEST)

            if PmsUser.objects.filter(email=email, is_deleted=False).exists(): # Username already exists validation
                return Response({'message': 'email already exists','status':status.HTTP_400_BAD_REQUEST,},\
                                status=status.HTTP_400_BAD_REQUEST)
            # print(first_name, last_name, email, phone_no)
            if any(field in ["None", ''] for field in [first_name, last_name, email, phone_no]):
                field_blank.append(email)
            else:
            # Create a user instance
                # password = PmsUser.objects.make_random_password()
                password = 'secret@1234'
                user = PmsUser.objects.create(email=email,first_name=first_name,last_name=last_name, 
                              organization_id=organization_id,gender=gender,blood_group=blood_group,notice_period=notice_period,employe_code=employe_code,\
                                employement_type=employement_type, company_name=company_name, designation=designation,\
                                department=department,aadhar_number=aadhar_number,pan_number=pan_number,\
                                ################### Updated fields ################# on 04-05-2022 #################################
                                ################### Updated fields ################# on 04-05-2022 #################################
                                
                                # mothers_name = mothers_name,fathers_name = fathers_name,emergency_contact_relation = emergency_contact_relation,\
                                # emergency_contact_name = emergency_contact_name,emergency_contact_phone_no = emergency_contact_phone_no,maratial_status = maratial_status,\
                                ################### Updated fields ################# on 04-05-2022 #################################
                                joining_date = joining_date,\
                                last_working_date = last_working_date,date_of_birth = date_of_birth,reporting_manager_id = reporting_manager_id,\
                                address_line_1 = address_line_1,address_line_2 = address_line_2,hrms_user_id = hrms_user_id,sap_personnel_no = sap_personnel_no)
                                ################### Updated fields ################# on 04-05-2022 #################################
                user.first_name = first_name
                user.last_name = last_name
                user.set_password(password)
                user.save()
            # Create a user profile instance
                user_profile = UserProfile.objects.create(user=user, first_name=first_name, 
                                last_name=last_name, email=email, phone_no=phone_no, password_to_know = password)

                user_profile.save()
        # print(field_blank)
        # print(failed_username)

        if failed_username or field_blank:
            message = 'Out of {} records, {} records imported successfully, {}  records failed to import'.format(len(data), len(data) - len(failed_username) - len(field_blank), len(failed_username) + len(field_blank))

            # if failed_username:
            #     message += ' but {} records failed to be created with username: {}'.format(len(failed_username), failed_username)
            # if field_blank:
            #     message += ' and {} fields were blank with username: {}'.format(len(field_blank),field_blank)
            return Response({'message': message,'status':status.HTTP_206_PARTIAL_CONTENT,}, status=status.HTTP_206_PARTIAL_CONTENT)
        else:
            return Response({'message': 'All data added successfully','status':status.HTTP_200_OK,}, status=status.HTTP_200_OK)

class GroupAPIView(APIView):
    """
    CRUD API for Group
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all group
        """
        id = self.request.query_params.get('id', None)
        if id:
            group_details = Group.cmobjects.filter(id = id).first()
            serializer = GroupSerializer(group_details)
            return Response(serializer.data)
        
        
        organization_details = self.request.query_params.get('organization_id', None)
        is_active = self.request.query_params.get('is_active', None)

        group_list = Group.cmobjects.filter(organization_id = organization_details).order_by('-id')

        if is_active:
            if is_active == 'true':
                group_list = Group.cmobjects.filter(organization_id = organization_details, \
                                                    is_active=True).order_by('-id')
            elif is_active == 'false':
                group_list = Group.cmobjects.filter(organization_id = organization_details, \
                                                    is_active=False).order_by('-id')

        # group_list = Group.objects.all()

        from django.core.paginator import Paginator

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(group_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)


        serializer = GroupSerializer(page, many=True)

        active_count = group_list.filter(is_active=True).count()
        inactive_count = group_list.filter(is_active=False).count()


        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
            'active_count': active_count,
            'inactive_count' : inactive_count
        })

    def post(self, request, format=None):
        """
        Create a new Group
        """
        # serializer = GroupSerializer(data=request.data)
        # if serializer.is_valid():
        #     serializer.save()

        group_name = request.data.get('group_name', None)
        organization_id = request.data.get('organization', None)
        user_ids = request.data.get('user_ids' ,[])

        with transaction.atomic():
         
            if Group.cmobjects.filter(group_name=group_name,organization=organization_id).exists():
                 return Response({
                                    'msg': "Group already exist",
                                    'status':status.HTTP_400_BAD_REQUEST,
                                    "request_status": 0})
            else:
                created = Group.objects.create(group_name=group_name, \
                                            organization_id=organization_id)
                created.save()

                for item in user_ids:
                    created_usr_grps = UsersGroup.objects.create(user_id=item,\
                                                                group=created)
                    created_usr_grps.save()
                group_details = Group.cmobjects.filter(id = created.id).first()
                serializer = GroupSerializer(group_details)
                return Response({'results':{
                                            'Data':serializer.data ,
                                            },
                                            'msg': 'Successfully created',
                                            'status':status.HTTP_201_CREATED,
                                            "request_status": 1})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Group
                """
                group_name = request.data.get('group_name', None)
                is_active = request.data.get('is_active', None)
                user_ids = request.data.get('user_ids' ,[])
                

                if Group.cmobjects.filter(pk=id,organization=organization_id).exists():
                    group = Group.cmobjects.get(pk=id)
                    # serializer = GroupSerializer(group, data=request.data)
                    # if serializer.is_valid():
                    #     serializer.save()

                    if Group.objects.filter(group_name=group_name, \
                                            organization_id=organization_id).exclude(
                                                group_name=group.group_name).exists():
                        return Response({
                                        'msg': "Group already exist",
                                        'status':status.HTTP_400_BAD_REQUEST,
                                        "request_status": 0})

                    with transaction.atomic():
                        created = Group.cmobjects.filter(organization_id=organization_id, \
                                                       pk=id).update(group_name=group_name,\
                                                                     is_active=is_active)
                     
                        from administrations.utils import create_dependent_formvalues_on_master_crud_operations
                        create_dependent_formvalues_on_master_crud_operations('executive_commitee', group.group_name, group.id)
                        
                        if UsersGroup.objects.filter(group=group).exists():
                            UsersGroup.objects.filter(group=group).delete()


                        for item in user_ids:
                            created_usr_grps = UsersGroup.objects.create(user_id=item,\
                                                                        group=group)
                            created_usr_grps.save()

                        serializer = GroupSerializer(group)

                        return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': "Successfully updated",
                                        'status': status.HTTP_202_ACCEPTED,
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg':"Group Does not Exists",
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a group
                """
                if Group.cmobjects.filter(pk=id,organization=organization_id).exists():
                    group = Group.cmobjects.get(pk=id,organization=organization_id)
                    group.is_deleted = True
                    group.save()

                    serializer = GroupSerializer(group)
                    return Response({'results':{
                                        'group':serializer.data ,
                                        },
                                        'msg': 'Successfully deleted',
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                    'status':status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})


class UsersGroupAPIView(APIView):
    """
    CRUD API for UsersGroup
    """
    
    
    
    def get(self, request, format=None):
        """
        Get a list of all zones
        """
        organization_details = self.request.query_params.get('organization_id', None)
        group_list = UsersGroup.objects.filter(organization_id = organization_details).order_by('id')
        serializer = UserGroupSerializer(group_list, many=True)
        return Response(serializer.data)
    def post(self, request, format=None):
        """
        Create a new Group
        """
        serializer = GroupSerializer(data=request.data)
        
        if serializer.is_valid():
            serializer.save()
            return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Successfully created',
                                        'status':status.HTTP_201_CREATED,
                                        "request_status": 1})
        return Response({'results': {
                                        'Data':serializer.errors ,
                                        },
                                    'msg': "Something went wrong. If the problem persists, please contact support.",
                                    'status':status.HTTP_400_BAD_REQUEST,
                                    "request_status": 0})
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Group
                """
                if Group.cmobjects.filter(pk=id,organization=organization_id).exists():
                    group = Group.cmobjects.get(pk=id)
                    serializer = GroupSerializer(group, data=request.data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Successfully created',
                                        'status':status.HTTP_201_CREATED,
                                        "request_status": 1})
                    return Response({'results': {
                                        'Data':serializer.errors ,
                                        },
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                    'status':status.HTTP_400_BAD_REQUEST,
                                    "request_status": 0})
                else:
                    return Response({'results': [],
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                    'status':status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
            elif method.lower() == 'delete':
                """
                Delete a group
                """
                if Group.cmobjects.filter(pk=id,organization=organization_id).exists():
                    group = Group.cmobjects.get(pk=id,organization=organization_id)
                    group.is_deleted = True
                    group.save()
                    return Response({'results':{
                                        'group':group ,
                                        },
                                        'msg': 'Successfully deleted',
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                    'status':status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})






# Change password API
class ChangePasswordView(generics.UpdateAPIView):
    """
    For changing password.
    password is changing using login user token.
    needs old password and new password,
    check old password is exiest or not
    if exiest than it works
    """
    serializer_class = ChangePasswordSerializer
    model = PmsUser
    
    
    def get_object(self, queryset=None):
        obj = self.request.user
        return obj
    def update(self, request, *args, **kwargs):
        self.object = self.get_object()
        serializer = self.get_serializer(data=request.data)
        # import pdb
        # pdb.set_trace()
        if serializer.is_valid():
            user_data = self.request.user
            #mail_id = user_data.email
            print('user',user_data)
            if not self.object.check_password(serializer.data.get("old_password")):
                return Response({'request_status': 1, 'msg': "Old Password is incorrect!"}, status=status.HTTP_400_BAD_REQUEST)
            self.object.set_password(serializer.data.get("new_password"))
            self.object.password_expiry_date=password_expiry_date_reset()
            self.object.save()
            user_details_data = UserProfile.objects.filter(user=self.request.user)
            
            user_details_data.update(password_to_know = serializer.data.get("new_password"))
            return Response({'request_status': 0, 'msg': "New Password Save Success..."}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

class UserProfileEditView(APIView):
    """
    User Profile Edit View
    """
    
    

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method
        """
        organization_id = self.request.query_params.get('organization_id')

        user_instance = PmsUser.objects.filter(organization_id=organization_id, id=request.user.id, is_active=True).first()

        first_name = request.data.get('first_name', user_instance.first_name)
        last_name = request.data.get('last_name', user_instance.last_name)
        date_of_birth = request.data.get('date_of_birth', user_instance.date_of_birth)
        phone_number = request.data.get('phone_number', None)
        mothers_name = request.data.get('mothers_name', user_instance.mothers_name)
        fathers_name = request.data.get('fathers_name', user_instance.fathers_name)
        address_line_1 = request.data.get('address_line_1', user_instance.address_line_1)
        address_line_2 = request.data.get('address_line_2', user_instance.address_line_2)
        country = request.data.get('country', user_instance.country_id)
        state = request.data.get('state', user_instance.state_id)
        city = request.data.get('city', user_instance.city_id)
        aadhar_number = request.data.get('aadhar_number', user_instance.aadhar_number)
        pan_number = request.data.get('pan_number', user_instance.pan_number)
        gender = request.data.get('gender', user_instance.gender)
        maratial_status = request.data.get('maratial_status', user_instance.maratial_status)
        blood_group = request.data.get('blood_group', user_instance.blood_group)
        emergency_contact_relation = request.data.get('emergency_contact_relation', user_instance.emergency_contact_relation)
        emergency_contact_name = request.data.get('emergency_contact_name', user_instance.emergency_contact_name)
        emergency_contact_phone_no = request.data.get('emergency_contact_phone_no', user_instance.emergency_contact_relation)

        user_profile_details = UserProfile.objects.filter(user_id=user_instance.id).first()

        with transaction.atomic():
    
            existing_images = '.' + settings.MEDIA_URL + str(user_profile_details.image)

            if request.data.get('image'):
                print('os.path.isfile(existing_images)::', os.path.isfile(existing_images))
                if os.path.isfile(existing_images):
                    os.remove(existing_images)
                user_instance.image = request.data.get("image", None)
                user_profile_details.image = request.data.get("image", None)

            user_instance.first_name = first_name
            user_instance.last_name = last_name
            user_instance.date_of_birth = date_of_birth
            user_instance.mothers_name = mothers_name
            user_instance.fathers_name = fathers_name
            user_instance.address_line_1 = address_line_1
            user_instance.address_line_2 = address_line_2
            user_instance.country_id = country
            user_instance.state_id = state
            user_instance.city_id = city
            user_instance.aadhar_number = aadhar_number
            user_instance.pan_number = pan_number
            user_instance.gender = gender
            user_instance.maratial_status = maratial_status
            user_instance.blood_group = blood_group
            user_instance.emergency_contact_relation = emergency_contact_relation
            user_instance.emergency_contact_name = emergency_contact_name
            user_instance.emergency_contact_phone_no = emergency_contact_phone_no

            user_instance.save()

            user_profile_details.phone_no = phone_number
            user_profile_details.first_name = first_name
            user_profile_details.last_name = last_name

            user_profile_details.save()

        return Response({'request_status': 0, 'msg': "Data Updated successfully"})



class AcademicQualificationPost(APIView):
    """
    Academic Qualification API View
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            method = self.request.query_params.get('method', None)

            if method.lower() == 'edit':
                user_id = self.request.data.get('user', None)
                qualifications_id = self.request.data.get('qualifications', None)
                details = self.request.data.get('details', None)
                file = self.request.FILES.get('file', None)

                if file:
                    AcademicQualification.objects.update_or_create(user_id=user_id, qualifications_id=qualifications_id, is_deleted=False,\
                                                            defaults={'details' : details, 'file' : file})
                else:
                    AcademicQualification.objects.update_or_create(user_id=user_id, qualifications_id=qualifications_id, is_deleted=False,\
                                                            defaults={'details' : details})

                
                
                academic_data = AcademicQualification.objects.filter(user_id=user_id, \
                                                                     qualifications_id=qualifications_id).first()

                serializer = AcademicSerializer(academic_data)

                return Response(
                                {'results':{
                                            'Data':serializer.data,
                                            },
                                            'msg': 'Academic Details Successfully Updated',
                                            'status':status.HTTP_201_CREATED,
                                            "request_status": 1})
            
            if method.lower() == 'delete':
                id = self.request.query_params.get('id', None)

                if AcademicQualification.cmobjects.filter(pk=id).exists():
                    academic = AcademicQualification.cmobjects.filter(pk=id).first()
                    academic.is_deleted = True
                    academic.save()

                    return Response({'results':{
                                        'academic_details':AcademicQualification.objects.filter(pk=id).values(),
                                        },
                                        'msg': 'Success',
                                        "request_status": 1})
                
                else:
                    return Response({'results': [],
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
                
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
    

class LicensePost(APIView):
    """
    LicenseAndCertificate API View
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            method = self.request.query_params.get('method', None)

            if method.lower() == 'edit':
                user_id = self.request.data.get('user', None)
                license_name = self.request.data.get('license_name', None)
                file = self.request.FILES.get('file', None)
                id = self.request.data.get('id', None)

                with transaction.atomic():
                    if id:
                        if file:
                            LicenseAndCertificate.objects.update_or_create(user_id=user_id, id=id, is_deleted=False,\
                                                                    defaults={'file' : file, 'license_name' : license_name})
                        else:
                            LicenseAndCertificate.objects.update_or_create(user_id=user_id, id=id, is_deleted=False,\
                                                                    defaults={'license_name' : license_name})
                    else:
                        created = LicenseAndCertificate.objects.create(user_id=user_id, license_name=license_name,\
                                                                       file=file)
                        created.save()

                
                license_data = LicenseAndCertificate.objects.filter(user_id=user_id, \
                                                                     license_name=license_name).first()

                serializer = LicenseSerializer(license_data)

                return Response(
                                {'results':{
                                            'Data':serializer.data ,
                                            },
                                            'msg': 'License and Certificate Details Successfully Updated',
                                            'status':status.HTTP_201_CREATED,
                                            "request_status": 1})
            
            if method.lower() == 'delete':
                id = self.request.query_params.get('id', None)

                if LicenseAndCertificate.cmobjects.filter(pk=id).exists():
                    academic = LicenseAndCertificate.cmobjects.filter(pk=id).first()
                    academic.is_deleted = True
                    academic.save()

                    return Response({'results':{
                                        'license_details':LicenseAndCertificate.objects.filter(pk=id).values(),
                                        },
                                        'msg': 'Success',
                                        "request_status": 1})
                
                else:
                    return Response({'results': [],
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
                
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
    

class OtherDocumentsPost(APIView):
    """
    Other Documents API View
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            method = self.request.query_params.get('method', None)

            if method.lower() == 'edit':
                user_id = self.request.data.get('user', None)
                document_name = self.request.data.get('document_name', None)
                file = self.request.FILES.get('file', None)
                id = self.request.data.get('id', None)
                    
                with transaction.atomic():
                    if id:
                        if file:
                            OtherDocuments.objects.update_or_create(user_id=user_id, id=id, is_deleted=False,\
                                                                defaults={'file' : file, 'document_name' : document_name})
                        else:
                            OtherDocuments.objects.update_or_create(user_id=user_id, id=id, is_deleted=False,\
                                                                defaults={'document_name' : document_name})
                    else:
                        created = OtherDocuments.objects.create(user_id=user_id, document_name=document_name,\
                                                                       file=file)
                        created.save()
                
                other_data = OtherDocuments.objects.filter(user_id=user_id, \
                                                                     document_name=document_name).first()

                serializer = OtherDocumentSerializer(other_data)

                return Response(
                                {'results':{
                                            'Data':serializer.data,
                                            },
                                            'msg': 'Other Document Successfully Updated',
                                            'status':status.HTTP_201_CREATED,
                                            "request_status": 1})
            
            if method.lower() == 'delete':
                id = self.request.query_params.get('id', None)

                if OtherDocuments.cmobjects.filter(pk=id).exists():
                    academic = OtherDocuments.cmobjects.filter(pk=id).first()
                    academic.is_deleted = True
                    academic.save()

                    return Response({'results':{
                                        'other_document_details':OtherDocuments.objects.filter(pk=id).values(),
                                        },
                                        'msg': 'Success',
                                        "request_status": 1})
                
                else:
                    return Response({'results': [],
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
                
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class WorkExperiencePost(APIView):
    """
    WorkExperience API View
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            method = self.request.query_params.get('method', None)

            if method.lower() == 'edit':
                user_id = self.request.data.get('user', None)
                organization_name = self.request.data.get('organization_name', None)
                file = self.request.FILES.get('file', None)
                id = self.request.data.get('id', None)
                    
                with transaction.atomic():
                    if id:
                        if file:
                            WorkExperience.objects.update_or_create(user_id=user_id, id=id, is_deleted=False,\
                                                                defaults={'file' : file, 'organization_name' : organization_name})
                        else:
                            WorkExperience.objects.update_or_create(user_id=user_id, id=id, is_deleted=False,\
                                                                defaults={'organization_name' : organization_name})
                    else:
                        created = WorkExperience.objects.create(user_id=user_id, organization_name=organization_name,\
                                                                       file=file)
                        created.save()
                
                work_data = WorkExperience.objects.filter(user_id=user_id, \
                                                                     organization_name=organization_name).first()

                serializer = WorkExperienceSerializer(work_data)

                return Response(
                                {'results':{
                                            'Data':serializer.data ,
                                            },
                                            'msg': 'Work Experience Details Successfully Updated',
                                            'status':status.HTTP_201_CREATED,
                                            "request_status": 1})
            
            if method.lower() == 'delete':
                id = self.request.query_params.get('id', None)

                if WorkExperience.cmobjects.filter(pk=id).exists():
                    academic = WorkExperience.cmobjects.filter(pk=id).first()
                    academic.is_deleted = True
                    academic.save()

                    return Response({'results':{
                                        'work_experience_details':WorkExperience.objects.filter(pk=id).values(),
                                        },
                                        'msg': 'Success',
                                        "request_status": 1})
                
                else:
                    return Response({'results': [],
                                    'msg': 'Something went wrong. If the problem persists, please contact support.',
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
                
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        



from django.db.models import Prefetch
    
class PmsUserListNewView(generics.ListAPIView):
    
    
    queryset = PmsUser.objects.filter(is_deleted=False)
    serializer_class = UserListNewSerializer  # Add this line
    pagination_class = OnOffPagination

    def get_queryset(self):
        organisation = self.request.query_params.get('organisation', None)
        id = self.request.query_params.get('id', None)
        company_id = self.request.query_params.get('company_id', None)
        email_id = self.request.query_params.get('email_id', None)
        username = self.request.query_params.get('username', None)
        search = self.request.query_params.get('search', None)
        profile = self.request.query_params.get('profile', None)
       
        department_ids = self.request.query_params.getlist('department', [])
        designation_ids = self.request.query_params.getlist('designation', [])
        employement_type_ids = self.request.query_params.getlist('employement_type', [])
        role_ids = self.request.query_params.getlist('role_id', [])
        state_ids = self.request.query_params.getlist('state_id', [])
        city_ids = self.request.query_params.getlist('city_id', [])
        zone_ids = self.request.query_params.getlist('zone_id', [])

        # Convert query parameters to integers or set to 0 if empty
        department_ids = [int(department_id) if department_id else 0 for department_id in department_ids]
        designation_ids = [int(designation_id) if designation_id else 0 for designation_id in designation_ids]
        employement_type_ids = [int(employement_type_id) if employement_type_id else 0 for employement_type_id in employement_type_ids]
        role_ids = [int(roleid) if roleid else 0 for roleid in role_ids]
        zone_ids = [int(zone_id) if zone_id else 0 for zone_id in zone_ids]
        state_ids = [int(state_id) if state_id else 0 for state_id in state_ids]
        city_ids = [int(city_id) if city_id else 0 for city_id in city_ids]

        # Define filter dictionary for queryset filtering
        filter = {}
        if organisation:
            filter['organization_id'] = organisation
        if designation_ids and not 0 in designation_ids:
            filter['designation_id__in'] = designation_ids
        if department_ids and not 0 in department_ids:
            filter['department_id__in'] = department_ids
        if id:
            filter['id'] = id
        if company_id:
            filter['company_name_id'] = company_id
        if employement_type_ids and not 0 in employement_type_ids:
            filter['employement_type_id__in'] = employement_type_ids
        if email_id:
            filter['email'] = email_id
        if username:
            filter['username__iexact'] = username
        if role_ids and not 0 in role_ids:
            filter['role_id__in'] = role_ids
        if state_ids and not 0 in state_ids:
            filter['state_id__in'] = state_ids
        if city_ids and not 0 in city_ids:
            filter['city_id__in'] = city_ids
        if zone_ids and not 0 in zone_ids:
            filter['zone_id__in'] = zone_ids

        # Define sorting field based on query parameters
        field_name = self.request.query_params.get('field_name', None)
        order_by = self.request.query_params.get('order_by', None)
        
        if not field_name:
            sort_field = '-id'
        else:
            if field_name == 'name':
                if order_by == 'asc':
                    sort_field = 'full_name'
                else:
                    sort_field = '-full_name'
            else:
                if order_by == 'asc':
                    sort_field = field_name
                else:
                    sort_field = '-' + str(field_name)

        # Annotate queryset with full name concatenation and prefetch zones
        queryset = PmsUser.objects.annotate(full_name=Concat('first_name', V(' '), 'last_name')).prefetch_related(
            Prefetch('zone', queryset=Zone.objects.filter(organization_id=organisation))
        )

        # Filter queryset based on filter dictionary and exclude current user
        if not profile:
            if search:
                search = search.strip()
                user_ids = list(UserProfile.objects.filter(phone_no__icontains=search).values_list('user_id', flat=True))
                queryset = queryset.filter((Q(full_name__icontains=search) | Q(email__icontains=search) | Q(id__in=user_ids)), **filter).exclude(id=self.request.user.id).order_by(sort_field)
            else:
                queryset = queryset.filter(**filter).exclude(id=self.request.user.id).order_by(sort_field)
        else:
            if search:
                search = search.strip()
                user_ids = list(UserProfile.objects.filter(phone_no__icontains=search).values_list('user_id', flat=True))
                queryset = queryset.filter((Q(full_name__icontains=search) | Q(email__icontains=search) | Q(id__in=user_ids)), **filter).order_by(sort_field)
            else:
                queryset = queryset.filter(**filter).order_by(sort_field)

        return queryset

    def get(self, request, *args, **kwargs):
        all = self.request.query_params.get('all', None)
        is_active = self.request.query_params.get('is_active', None)
        queryset = self.filter_queryset(self.get_queryset())

        is_active_true_count = queryset.filter(is_active=True).count()
        is_active_false_count = queryset.filter(is_active=False).count()

        if is_active:
            if is_active == "true":
                queryset = queryset.filter(is_active=True)
            else:
                queryset = queryset.filter(is_active=False)            

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = self.get_serializer(page, many=True)

        if all == 'true':
            serializer = self.get_serializer(queryset, many=True)
            return Response({'results': serializer.data})

        response_data = {
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
            'active_count': is_active_true_count,
            'inactive_count': is_active_false_count,
        }
        return Response(response_data)


class PersonalDetailsAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            sap_master = PersonalDetails.cmobjects.filter(id=id).first()
            serializer = PersonalDetailsSerializer(sap_master)
            return Response(serializer.data)
           
        search = custom_filters(self.request, {}, [])
        _list = PersonalDetails.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PersonalDetailsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PersonalDetailsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Bulk create or update PersonalDetails.
        """
    
        if isinstance(request.data, list):
            request_datas = request.data
        else:
            request_datas = [request.data]

        results = {"success": [], "errors": []}

        with transaction.atomic():
            try:
                for request_data in request_datas:
                    serializer = None
                    # print(request_data)
                    if 'id' not in request_data:
                        request_data['created_by'] = request.user.id
                        serializer = PersonalDetailsSerializer(data=request_data,context={'request': request})
                    else:
                        details =PersonalDetails.cmobjects.filter(pk=request_data['id']).first()
                        request_data['updated_by'] = request.user.id
                        serializer = PersonalDetailsSerializer(details, data=request_data, partial=True,context={'request': request})
                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": request_data,
                            "error": serializer.errors,
                            "msg": "Something went wrong. If the problem persists, please contact support."
                        })
            except Exception as e:
                    results["errors"].append({
                        "data": request_data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })
        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        ref_id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                if PersonalDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).exists():
                    details = PersonalDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': PersonalDetails.objects.filter(pk=ref_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})
                
class AcademicCredentialDetailsAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = AcademicCredentialDetails.cmobjects.filter(id=id).first()
            serializer = AcademicCredentialDetailsSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = AcademicCredentialDetails.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = AcademicCredentialDetailsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AcademicCredentialDetailsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Bulk create or update AcademicCredentialDetails.
        """
    
        if isinstance(request.data, list):
            request_datas = request.data
        else:
            request_datas = [request.data]

        results = {"success": [], "errors": []}

        with transaction.atomic():
            try:
                for request_data in request_datas:
                    serializer = None
                    print(request_data)
                    if 'id' not in request_data:
                        request_data['created_by'] = request.user.id
                        serializer = AcademicCredentialDetailsSerializer(data=request_data,context={'request': request})
                    else:
                        details = AcademicCredentialDetails.cmobjects.filter(pk=request_data['id']).first()
                        request_data['updated_by'] = request.user.id
                        serializer = AcademicCredentialDetailsSerializer(details, data=request_data, partial=True,context={'request': request})
                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": request_data,
                            "error": serializer.errors,
                            "msg": "Something went wrong. If the problem persists, please contact support."
                        })
            except Exception as e:
                    results["errors"].append({
                        "data": request_data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })
        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        ref_id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                if AcademicCredentialDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).exists():
                    details = AcademicCredentialDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': AcademicCredentialDetails.objects.filter(pk=ref_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})
                
class EmergencyContactDetailsAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = EmergencyContactDetails.cmobjects.filter(id=id).first()
            serializer = EmergencyContactDetailsSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = EmergencyContactDetails.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = EmergencyContactDetailsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AcademicCredentialDetailsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Bulk create or update EmergencyContactDetails.
        """
    
        if isinstance(request.data, list):
            request_datas = request.data
        else:
            request_datas = [request.data]

        results = {"success": [], "errors": []}

        with transaction.atomic():
            try:
                for request_data in request_datas:
                    serializer = None
                    print(request_data)
                    if 'id' not in request_data:
                        request_data['created_by'] = request.user.id
                        serializer = EmergencyContactDetailsSerializer(data=request_data,context={'request': request})
                    else:
                        details = EmergencyContactDetails.cmobjects.filter(pk=request_data['id']).first()
                        request_data['updated_by'] = request.user.id
                        serializer = EmergencyContactDetailsSerializer(details, data=request_data, partial=True,context={'request': request})
                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": request_data,
                            "error": serializer.errors,
                            "msg": "Something went wrong. If the problem persists, please contact support."
                        })
            except Exception as e:
                    results["errors"].append({
                        "data": request_data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })
        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        ref_id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                if EmergencyContactDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).exists():
                    details = EmergencyContactDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': EmergencyContactDetails.objects.filter(pk=ref_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})                
                

class FamilyDetailsAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = FamilyDetails.cmobjects.filter(id=id).first()
            serializer = FamilyDetailsSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = FamilyDetails.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = FamilyDetailsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = FamilyDetailsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Bulk create or update FamilyDetails.
        """
    
        if isinstance(request.data, list):
            request_datas = request.data
        else:
            request_datas = [request.data]

        results = {"success": [], "errors": []}

        with transaction.atomic():
            try:
                for request_data in request_datas:
                    serializer = None
                    if 'id' not in request_data:
                        request_data['created_by'] = request.user.id
                        serializer = FamilyDetailsSerializer(data=request_data, context={'request': request})
                    else:
                        details = FamilyDetails.cmobjects.filter(pk=request_data['id']).first()
                        request_data['updated_by'] = request.user.id
                        serializer = FamilyDetailsSerializer(details, data=request_data, partial=True, context={'request': request})
                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": request_data,
                            "error": serializer.errors,
                            "msg": "Something went wrong. If the problem persists, please contact support."
                        })
            except Exception as e:
                    results["errors"].append({
                        "data": request_data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })
        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        ref_id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                if FamilyDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).exists():
                    details = FamilyDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': FamilyDetails.objects.filter(pk=ref_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

class BankDetailsAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = BankDetails.cmobjects.filter(id=id).first()
            serializer = BankDetailsSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = BankDetails.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = BankDetailsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BankDetailsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Bulk create or update BankDetails.
        """
    
        if isinstance(request.data, list):
            request_datas = request.data
        else:
            request_datas = [request.data]

        results = {"success": [], "errors": []}

        with transaction.atomic():
            try:
                for request_data in request_datas:
                    serializer = None
                    if 'id' not in request_data:
                        request_data['created_by'] = request.user.id
                        serializer = BankDetailsSerializer(data=request_data, context={'request': request})
                    else:
                        details = BankDetails.cmobjects.filter(pk=request_data['id']).first()
                        request_data['updated_by'] = request.user.id
                        serializer = BankDetailsSerializer(details, data=request_data, partial=True, context={'request': request})
                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": request_data,
                            "error": serializer.errors,
                            "msg": "Something went wrong. If the problem persists, please contact support."
                        })
            except Exception as e:
                    results["errors"].append({
                        "data": request_data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })
        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        ref_id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                if BankDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).exists():
                    details = BankDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': BankDetails.objects.filter(pk=ref_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

class ProfessionalDetailsAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = ProfessionalDetails.cmobjects.filter(id=id).first()
            serializer = ProfessionalDetailsSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = ProfessionalDetails.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = ProfessionalDetailsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = ProfessionalDetailsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Bulk create or update ProfessionalDetails.
        """
    
        if isinstance(request.data, list):
            request_datas = request.data
        else:
            request_datas = [request.data]

        results = {"success": [], "errors": []}

        with transaction.atomic():
            try:
                for request_data in request_datas:
                    serializer = None
                    if 'id' not in request_data:
                        request_data['created_by'] = request.user.id
                        serializer = ProfessionalDetailsSerializer(data=request_data, context={'request': request})
                    else:
                        details = ProfessionalDetails.cmobjects.filter(pk=request_data['id']).first()
                        request_data['updated_by'] = request.user.id
                        serializer = ProfessionalDetailsSerializer(details, data=request_data, partial=True, context={'request': request})
                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": request_data,
                            "error": serializer.errors,
                            "msg": "Something went wrong. If the problem persists, please contact support."
                        })
            except Exception as e:
                    results["errors"].append({
                        "data": request_data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })
        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        ref_id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                if ProfessionalDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).exists():
                    details = ProfessionalDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': ProfessionalDetails.objects.filter(pk=ref_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})
                
class AttachmentDetailsAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            details = AttachmentDetails.cmobjects.filter(id=id).first()
            serializer = AttachmentDetailsSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = AttachmentDetails.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = AttachmentDetailsSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AttachmentDetailsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Bulk create or update AttachmentDetails.
        """
    
        if isinstance(request.data, list):
            request_datas = request.data
        else:
            request_datas = [request.data]

        results = {"success": [], "errors": []}

        with transaction.atomic():
            try:
                for request_data in request_datas:
                    serializer = None
                    if 'id' not in request_data:
                        request_data['created_by'] = request.user.id
                        serializer = AttachmentDetailsSerializer(data=request_data, context={'request': request})
                    else:
                        details = AttachmentDetails.cmobjects.filter(pk=request_data['id']).first()
                        request_data['updated_by'] = request.user.id
                        serializer = AttachmentDetailsSerializer(details, data=request_data, partial=True, context={'request': request})
                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": request_data,
                            "error": serializer.errors,
                            "msg": "Something went wrong. If the problem persists, please contact support."
                        })
            except Exception as e:
                    results["errors"].append({
                        "data": request_data,
                        "error": str(e),
                        "msg": "Something went wrong. If the problem persists, please contact support."
                    })
        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        ref_id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                if AttachmentDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).exists():
                    details = AttachmentDetails.cmobjects.filter(pk=ref_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': AttachmentDetails.objects.filter(pk=ref_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})
