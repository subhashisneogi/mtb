import datetime
from PIL import Image
import sys
import os
from io import BytesIO

from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from django.core.files.uploadedfile import InMemoryUploadedFile

from adminpanel.models import *
from administrations.models import *

# Create your models here.

class UserProfile(models.Model):
    """ Custom User Profile model """

    date = models.DateTimeField(auto_now_add=True)
    user = models.OneToOneField(settings.AUTH_USER_MODEL, related_name='user_profile', on_delete=models.CASCADE)
    first_name = models.CharField(max_length=32, blank=True, null=True)
    last_name = models.CharField(max_length=32, blank=True, null=True)
    email = models.EmailField(max_length=70, unique=True, blank=True, null=True)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{6,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    phone_no = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True) # validators should be a list
    image = models.ImageField(
        upload_to='user/profile_image', null=True, blank=True, help_text='Image Size 130 x 130')
    password_to_know = models.CharField(max_length=200, null=True, blank=True)
    device_id = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return str(self.user)

    class Meta:
        app_label = 'user_profile'

    def save(self, *args, **kwargs):
        if self.image:
            temp_image = Image.open(self.image).convert('RGB')
            output_io_stream = BytesIO()
            temp_resized_image = temp_image.resize((500, 500))
            temp_resized_image.save(
                output_io_stream, format='JPEG', quality=60)
            output_io_stream.seek(0)
            self.image = InMemoryUploadedFile(output_io_stream,
                                                    'ImageField', "%s.jpg" % self.image.name.split('.')[0], 'image/jpeg', sys.getsizeof(output_io_stream), None)
        return super().save(*args, **kwargs)


class Group(BaseAbstractStructure):
    """ Group model  """

    
    organization = models.ForeignKey('administrations.Organization', related_name='group_organization', on_delete=models.CASCADE, null=True, blank=True)
    group_name = models.CharField(max_length=255, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    def __str__(self):
        return str(self.group_name)
    class Meta:
        app_label = 'user_profile'


class UsersGroup(models.Model):
    """ Users Group model  """
    user = models.ForeignKey(PmsUser, related_name='user_group', on_delete=models.DO_NOTHING)
    group = models.ForeignKey(Group, related_name='user_group_name',on_delete=models.CASCADE)


    def __str__(self):
        return str(self.group)
    class Meta:
        app_label = 'user_profile'


class PersonalDetails(BaseAbstractStructure):
    MARITAL_STATUS = (
        ('Single', 'Single'),
        ('Married', 'Married'),
        ('Widowed', 'Widowed'),
        ('Divorced', 'Divorced'),
        ('Separated', 'Separated'),
        ('Others', 'Others')
    )
    organization = models.ForeignKey(Organization, related_name='user_personal_details_organization', on_delete=models.CASCADE)
    user = models.ForeignKey(PmsUser, related_name='user_personal_details_user', on_delete=models.CASCADE)
    father_name = models.CharField(max_length=200, blank=True, null=True)
    date_of_application = models.DateField(null=True, blank=True)
    email = models.CharField(max_length=200, blank=True, null=True)
    marital_status = models.CharField(max_length=100, choices=MARITAL_STATUS , blank=True, null=True, default="Single")
    alternate_no = models.CharField(max_length=200, blank=True, null=True)
    landline_no = models.CharField(max_length=200, blank=True, null=True)
    aadhar_no = models.CharField(max_length=200, blank=True, null=True)
    permanent_address = models.TextField(max_length=500, blank=True, null=True)
    medical_history = models.TextField(max_length=500, blank=True, null=True)
    mark_of_indentification = models.TextField(max_length=500, blank=True, null=True)
    height = models.CharField(max_length=200, blank=True, null=True)
    weight = models.CharField(max_length=200, blank=True, null=True)
    
    class Meta:
        db_table = "user_personal_details"


class AcademicCredentialDetails(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='user_academic_credential_details_organization', on_delete=models.CASCADE)
    user = models.ForeignKey(PmsUser, related_name='user_academic_credential_details_user', on_delete=models.CASCADE)
    exam_degree = models.CharField(max_length=200, blank=True, null=True)
    subject_specialization = models.CharField(max_length=200, blank=True, null=True)
    institute_college = models.CharField(max_length=200, blank=True, null=True)
    university_board = models.CharField(max_length=200, blank=True, null=True)
    month_year = models.CharField(max_length=200, blank=True, null=True)
    marks_dgpa = models.FloatField(default=0.0)
    
    class Meta:
        db_table = "user_academic_credential_details"


class EmergencyContactDetails(BaseAbstractStructure):
    RELATION = (
        ('Father', 'Father'),
        ('Mother', 'Mother'),
        ('Legal Guardian', 'Legal Guardian'),
        ('Spouse', 'Spouse'),
        ('Child', 'Child'),
        ('Sibling', 'Sibling'),
    )
    organization = models.ForeignKey(Organization, related_name='user_emergency_contact_details_organization', on_delete=models.CASCADE)
    user = models.ForeignKey(PmsUser, related_name='user_emergency_contact_details_user', on_delete=models.CASCADE)
    contact_name = models.CharField(max_length=200, blank=True, null=True)
    contact_relation = models.CharField(max_length=100, choices=RELATION, blank=True, null=True, default="Father")
    contact_address = models.TextField(max_length=500, blank=True, null=True)
    contact_number = models.CharField(max_length=200, blank=True, null=True)
    
    class Meta:
        db_table = "user_emergency_contact_details"


class FamilyDetails(BaseAbstractStructure):
    RELATION = (
        ('Father', 'Father'),
        ('Mother', 'Mother'),
        ('Legal Guardian', 'Legal Guardian'),
        ('Spouse', 'Spouse'),
        ('Child', 'Child'),
        ('Sibling', 'Sibling'),
    )
    organization = models.ForeignKey(Organization, related_name='user_family_details_organization', on_delete=models.CASCADE)
    user = models.ForeignKey(PmsUser, related_name='user_family_details_user', on_delete=models.CASCADE)
    name = models.CharField(max_length=200, blank=True, null=True)
    relation = models.CharField(max_length=100, choices=RELATION, blank=True, null=True, default="Father")
    address = models.TextField(max_length=500, blank=True, null=True)
    date_of_birth = models.DateField(null=True, blank=True)
    
    class Meta:
        db_table = "user_family_details"


class BankDetails(BaseAbstractStructure):
    OPERATION_MODE = (
        ('Single', 'Single'),
        ('Joint', 'Joint')
    )
    organization = models.ForeignKey(Organization, related_name='user_bank_details_organization', on_delete=models.CASCADE)
    user = models.ForeignKey(PmsUser, related_name='user_bank_details_user', on_delete=models.CASCADE)
    account_no = models.CharField(max_length=200, blank=True, null=True)
    ifsc_code= models.CharField(max_length=200, blank=True, null=True)
    branch_address = models.TextField(max_length=500, blank=True, null=True)
    primary_account_holder = models.CharField(max_length=200, blank=True, null=True)
    previous_uan = models.CharField(max_length=200, blank=True, null=True)
    previous_ip_no = models.CharField(max_length=200, blank=True, null=True)
    mode_of_operation = models.CharField(max_length=100, choices=OPERATION_MODE , blank=True, null=True, default="Single")
    
    class Meta:
        db_table = "user_bank_details"


class ProfessionalDetails(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='user_professional_details_organization', on_delete=models.CASCADE)
    user = models.ForeignKey(PmsUser, related_name='user_professional_details_user', on_delete=models.CASCADE)
    company_name = models.CharField(max_length=200, blank=True, null=True)
    company_location = models.CharField(max_length=200, blank=True, null=True)
    job_location = models.CharField(max_length=200, blank=True, null=True)
    position = models.CharField(max_length=200, blank=True, null=True)
    area_of_work = models.TextField(max_length=500, blank=True, null=True)
    leave_reason = models.TextField(max_length=500, blank=True, null=True)
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    ctc = models.FloatField(default=0.0)
    
    class Meta:
        db_table = "user_professional_details"


class AttachmentDetails(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='user_attachment_details_organization', on_delete=models.CASCADE)
    user = models.ForeignKey(PmsUser, related_name='user_attachment_details_user', on_delete=models.CASCADE)
    file_name = models.CharField(max_length=200, blank=True, null=True)
    remark = models.TextField(max_length=500, blank=True, null=True)
    attachment = models.FileField(upload_to='user_profile/attachments', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    
    class Meta:
        db_table = "user_attachment_details"