from django.urls import path
from user_profile import views

urlpatterns = [

    path('add_user/', views.UsersRegistration.as_view()),
    path('pms_user_list/', views.PmsUserListView.as_view()),
    path('pms_user_list_new/', views.PmsUserListNewView.as_view()),
    path('pms_deleted_user_list/', views.UserDeletedListView.as_view()),
    path('pms_custom_user_updated_list/', views.UserCustomUpdatedListAPIView.as_view()),
    path('pms_custom_user_list/', views.UserCustomListAPIView.as_view()),
    path('pms_custom_user_list_by_permissions/', views.UserCustomListByPermissionAPIView.as_view()),
    path('pms_user_manage/', views.PmsUserDeleteView.as_view()),
    path('user/edit/<id>/', views.EditUserView.as_view()),
    path('bulk_import_upload/', views.ExcelUploadView.as_view(), name='bulk_import_upload'),
    
    path('bulk-import-users/', views.UserBulkImportAPI.as_view()),

    path('bulk_import_db_add/', views.ExcelDataMapperView.as_view(), name='bulk_import_db_add'),
    path("group/",views.GroupAPIView.as_view(),name="group_list"),

    #path("user/group/",views.GroupAPIView.as_view(),name="user_group"),

    path('change_password/', views.ChangePasswordView.as_view()),
    path('user_profile_edit/', views.UserProfileEditView.as_view()),
    path('academic_add/', views.AcademicQualificationPost.as_view()),
    path('license_add/', views.LicensePost.as_view()),
    path('work_experience_add/', views.WorkExperiencePost.as_view()),
    path('other_document_add/', views.OtherDocumentsPost.as_view()),

    path('user-personal-details/', views.PersonalDetailsAPIView.as_view()),
    path('user-academic-credential-details/', views.AcademicCredentialDetailsAPIView.as_view()),
    path('user-emergency-contact-details/', views.EmergencyContactDetailsAPIView.as_view()),
    path('user-family-details/', views.FamilyDetailsAPIView.as_view()),
    path('user-bank-details/', views.BankDetailsAPIView.as_view()),
    path('user-professional-details/', views.ProfessionalDetailsAPIView.as_view()),
    path('user-attachment-details/', views.AttachmentDetailsAPIView.as_view()),

]
