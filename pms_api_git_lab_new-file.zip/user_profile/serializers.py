import datetime
import json
import os

from django.contrib.auth.models import *
from django.db import transaction, IntegrityError
from django.conf import settings
from django.db.models import F, Q

from django.contrib.auth.models import AbstractUser
from django.contrib.auth import authenticate

from threading import Thread   #for threading
from dataclasses import fields
from modulefinder import Module

# FOR DJANGO REST FRAMEWORK
from rest_framework import serializers
from django.db.models import F
from rest_framework.serializers import ModelSerializer
from rest_framework.exceptions import APIException

from user_profile.models import *
from user_permissions.models import *
from adminpanel.models import *
from administrations.models import *
from adminpanel.serializers import *
from administrations.utils import schedule_generic_mail, is_string_an_url , trigger_notifications
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.encoding import smart_str, force_str, smart_bytes, DjangoUnicodeDecodeError
from procurement.helper import process_attachments , password_expiry_date_reset
from procurement.models import StoreMaster, SiteMaster, ProjectMaster

class UserWisePermissionsSerializer(serializers.ModelSerializer):
    """ User Permission Serializer"""
    itemName = serializers.SerializerMethodField()
    view = serializers.SerializerMethodField()
    add = serializers.SerializerMethodField()
    edit = serializers.SerializerMethodField()
    delete = serializers.SerializerMethodField()
    export = serializers.SerializerMethodField()
    level_permission = serializers.SerializerMethodField()
    sub_menu_permissions = serializers.SerializerMethodField()
    role_details = serializers.SerializerMethodField()

    def get_role_details(self,instance):
        if instance.role_id:
            details = Profile.objects.filter(id=instance.role_id).values()
            return details
        else:
            return None


    def get_itemName(self,instance):
        if instance.menu_id:
            result = MenuMaster.objects.get(id=instance.menu_id).menu_name
            return result
        else:
            return None
        
    def get_view(self,instance):
        return instance.has_view_permission
    
    def get_add(self,instance):
        return instance.has_add_permission
    
    def get_edit(self,instance):
        return instance.has_edit_permission
    
    def get_delete(self,instance):
        return instance.has_delete_permission
    
    def get_export(self,instance):
        return instance.has_export_permission
    
    def get_level_permission(self,instance):
        return instance.level_permission
    
    def get_sub_menu_permissions(self,instance):
        if instance.menu_id:
            result = UserWiseSubModulePermissions.cmobjects.filter(menu_id=instance.menu_id, \
                                                             user_id=instance.user_id).annotate(itemName=F('sub_menu__sub_menu_name'), view=F('has_view_permission'),\
                                                             add=F('has_add_permission'), edit=F('has_edit_permission'), \
                                                                delete=F('has_delete_permission'), \
                                                                    export=F('has_export_permission'), role_name = F('role__role_name')).values('id','itemName',\
                                                                        'view','add','edit','delete','export','level_permission',\
                                                                            'sub_menu_id', 'role_name', 'role_id').order_by('sub_menu__sub_menu_name')
            return result
        else:
            return []
        
        
    class Meta:
        model = UserWisePermissions
        fields = ('id', 'menu_id','itemName', 'view', 'add', 'edit', 'delete', 'export', \
                  'level_permission', 'sub_menu_permissions','role_details')
class UserPermissionsSerializer(serializers.ModelSerializer):
    """ User Permission Serializer"""
    itemName = serializers.SerializerMethodField()
    view = serializers.SerializerMethodField()
    add = serializers.SerializerMethodField()
    edit = serializers.SerializerMethodField()
    delete = serializers.SerializerMethodField()
    export = serializers.SerializerMethodField()
    level_permission = serializers.SerializerMethodField()
    sub_menu_permissions = serializers.SerializerMethodField()
    role_details = serializers.SerializerMethodField()

    def get_role_details(self,instance):
        if instance.role_id:
            details = Profile.objects.filter(id=instance.role_id).values()
            return details
        else:
            return None


    def get_itemName(self,instance):
        if instance.menu_id:
            result = MenuMaster.objects.get(id=instance.menu_id).menu_name
            return result
        else:
            return None
        
    def get_view(self,instance):
        return instance.has_view_permission
    
    def get_add(self,instance):
        return instance.has_add_permission
    
    def get_edit(self,instance):
        return instance.has_edit_permission
    
    def get_delete(self,instance):
        return instance.has_delete_permission
    
    def get_export(self,instance):
        return instance.has_export_permission
    
    def get_level_permission(self,instance):
        return instance.level_permission
    
    def get_sub_menu_permissions(self,instance):
        if instance.menu_id:
            result = UserSubModulePermissions.cmobjects.filter(menu_id=instance.menu_id, \
                                                             role_id=instance.role_id).annotate(itemName=F('sub_menu__sub_menu_name'), view=F('has_view_permission'),\
                                                             add=F('has_add_permission'), edit=F('has_edit_permission'), \
                                                                delete=F('has_delete_permission'), \
                                                                    export=F('has_export_permission'), role_name = F('role__role_name')).values('id','itemName',\
                                                                        'view','add','edit','delete','export','level_permission',\
                                                                            'sub_menu_id', 'role_name', 'role_id')
            return result
        else:
            return []
        

    # def get_sub_menu_permissions_formatted(self,instance):
    #     if instance.menu_id:
    #         sub_menu_list = []
    #         result = UserSubModulePermissions.cmobjects.filter(menu_id=instance.menu_id, \
    #                                                          role_id=instance.role_id).annotate(itemName=F('sub_menu__sub_menu_name'), view=F('has_view_permission'),\
    #                                                          add=F('has_add_permission'), edit=F('has_edit_permission'), \
    #                                                             delete=F('has_delete_permission'), \
    #                                                                 export=F('has_export_permission'), role_name = F('role__role_name'))
            
    #         for item in result:
    #             # result_dict = {}
    #             # result_dict[item.itemName] = {'add' : item.add, 'view' : item.view, 'edit' : item.edit, \
    #             #                               'delete' : item.delete, 'export' : item.export}
    #             # sub_menu_list.append(result_dict)

    #             result_dict = {str(item.itemName) : {'add' : item.add, 'view' : item.view, 'edit' : item.edit, \
    #                                           'delete' : item.delete, 'export' : item.export}}

    #         return result_dict
    #     else:
    #         return []
        
    class Meta:
        model = UserPermissions
        fields = ('id', 'menu_id','itemName', 'view', 'add', 'edit', 'delete', 'export', \
                  'level_permission', 'sub_menu_permissions','role_details')


class RoleSerilizer(serializers.ModelSerializer):
    """
    ROle Serializer Basically for Get Method
    """
    organization_name = serializers.SerializerMethodField()
    user_permissions_details = serializers.SerializerMethodField()
    user_administrative_permissions = serializers.SerializerMethodField()
    user_module_permission = serializers.SerializerMethodField()
    user_count = serializers.SerializerMethodField()
    user_setting_permission = serializers.SerializerMethodField()
    user_list = serializers.SerializerMethodField()


    def get_organization_name(self,instance):
        if instance.organization_id:
            details = Organization.objects.filter(pk=instance.organization_id).values()
            return details
        else:
            return None

    def get_user_permissions_details(self,instance):
        if instance.id:
            details = UserPermissions.cmobjects.filter(role_id=instance.id)
            serializer = UserPermissionsSerializer(details, many=True)
            return serializer.data
        else:
            return None

    def get_user_administrative_permissions(self,instance):
        if instance.id:
            details = UserAdministrativePermissions.cmobjects.annotate(itemName=F('admin_item__name')).filter(\
                role_id=instance.id).values('id', 'organization_id','organization__name','role_id','role__role_name',\
                                            'itemName','admin_item_id','has_import_permission','has_approval_permission',\
                                                'has_approval_submit_permission','has_export_permission',\
                                                    'level_permission')
            return details
        else:
            return None
        
    def get_user_module_permission(self,instance):
        if instance.id:
            details = UserModulePermissions.cmobjects.annotate(itemName=F('module_item__name'),\
                                                             permission_for=F('module_item__permission_for'),\
                                                                unique_id=F('module_item__unique_id')).filter(\
                role_id=instance.id).values('id', 'organization_id','organization__name','role_id','role__role_name',\
                                            'itemName','module_item_id', 'permission_for', 'unique_id',
                                                    'level_permission')
            return details
        else:
            return None
        
    def get_user_setting_permission(self,instance):
        if instance.id:
            result = UserSettingsPermissions.cmobjects.filter(role_id=instance.id).annotate(itemName=F('setting_item__name'), view=F('has_view_permission'),\
                                                             add=F('has_add_permission'), edit=F('has_edit_permission'), \
                                                                delete=F('has_delete_permission'), \
                                                                    export=F('has_export_permission'), role_name = F('role__role_name')).values('id','itemName',\
                                                                        'view','add','edit','delete','export','level_permission',\
                                                                            'role_name', 'role_id','setting_item_id')
            return result
        else:
            return []
        
    def get_user_count(self,instance):
        if instance.id:
            user_count = PmsUser.objects.filter(role_id=instance.id, \
                                                is_deleted=False).count()
            return user_count
        else:
            return None
        
    def get_user_list(self,instance):
        if instance.id:
            user_list = PmsUser.objects.filter(role_id=instance.id,\
                                               is_deleted=False).values('id', 'username',\
                                                                           'first_name','last_name','email')
            return user_list
        else:
            return None

    class Meta:
        model = Profile
        fields = "__all__"


class RoleUserWiseSerilizer(serializers.ModelSerializer):
    """
    ROle Serializer Basically for Get Method
    """
    organization_name = serializers.SerializerMethodField()
    user_permissions_details = serializers.SerializerMethodField()
    user_administrative_permissions = serializers.SerializerMethodField()
    user_module_permission = serializers.SerializerMethodField()
    user_setting_permission = serializers.SerializerMethodField()
    role_name = serializers.SerializerMethodField()
    user_id = serializers.SerializerMethodField()

    def get_user_id(self,instance):
        if instance.id:
            return instance.id
        else:
            return ''

    def get_role_name(self,instance):
        if instance.role_id:
            details = Profile.objects.get(id=instance.role_id)
            return details.role_name
        else:
            return ''

    def get_organization_name(self,instance):
        if instance.organization_id:
            details = Organization.objects.filter(pk=instance.organization_id).values()
            return details
        else:
            return ''

    def get_user_permissions_details(self,instance):
        if instance.id:
            details = UserWisePermissions.cmobjects.filter(user_id=instance.id).order_by('menu__menu_name')
            serializer = UserWisePermissionsSerializer(details, many=True)
            return serializer.data
        else:
            return []
        
    def get_user_setting_permission(self,instance):
        if instance.id:
            result = UserWiseSettingPermissions.cmobjects.filter(user_id=instance.id).annotate(itemName=F('setting_item__name'), view=F('has_view_permission'),\
                                                             add=F('has_add_permission'), edit=F('has_edit_permission'), \
                                                                delete=F('has_delete_permission'), \
                                                                    export=F('has_export_permission'), role_name = F('role__role_name')).values('id','itemName',\
                                                                        'view','add','edit','delete','export','level_permission',\
                                                                            'role_name', 'role_id','setting_item_id').order_by('setting_item__name')
            return result
        else:
            return []

    def get_user_administrative_permissions(self,instance):
        if instance.id:
            details = UserWiseAdministrativePermissions.cmobjects.annotate(itemName=F('admin_item__name')).filter(\
                user_id=instance.id).values('id', 'organization_id','organization__name','role_id','role__role_name',\
                                            'itemName','admin_item_id','has_import_permission','has_approval_permission',\
                                                'has_approval_submit_permission','has_export_permission',\
                                                    'level_permission')
            return details
        else:
            return []
        
    def get_user_module_permission(self,instance):
        if instance.id:
            details = UserWiseModulePermissions.cmobjects.annotate(itemName=F('module_item__name'),\
                                                             permission_for=F('module_item__permission_for'),\
                                                                unique_id=F('module_item__unique_id')).filter(\
                user_id=instance.id).values('id', 'organization_id','organization__name','role_id','role__role_name',\
                                            'itemName','module_item_id', 'permission_for', 'unique_id', 'level_permission').order_by('module_item__name')
            return details
        else:
            return []

    class Meta:
        model = PmsUser
        fields = ('organization_name', 'user_permissions_details', 'user_administrative_permissions', 'user_id', 'role_id', \
                  'role_name','user_setting_permission','user_module_permission')


class UserListSerializer(serializers.ModelSerializer):
    organization_name = serializers.SerializerMethodField()
    role_details = serializers.SerializerMethodField()
    zone_details = serializers.SerializerMethodField()
    country_details = serializers.SerializerMethodField()
    state_details = serializers.SerializerMethodField()
    city_details = serializers.SerializerMethodField()
    designation_details = serializers.SerializerMethodField()
    company_details = serializers.SerializerMethodField()
    department_details = serializers.SerializerMethodField()
    profile_pic_url = serializers.SerializerMethodField()
    phone_no = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()
    state = serializers.SerializerMethodField()
    city = serializers.SerializerMethodField()
    zone = serializers.SerializerMethodField()
    gender = serializers.SerializerMethodField()
    blood_group = serializers.SerializerMethodField()
    notice_period = serializers.SerializerMethodField()
    employe_code = serializers.SerializerMethodField()
    pan_number = serializers.SerializerMethodField()
    aadhar_number = serializers.SerializerMethodField()
    age = serializers.SerializerMethodField()
    reporting_manager_details = serializers.SerializerMethodField()
    academic_qualifications = serializers.SerializerMethodField()
    license_details = serializers.SerializerMethodField()
    work_experience = serializers.SerializerMethodField()
    other_documents = serializers.SerializerMethodField()
    stores = serializers.SerializerMethodField()

    def get_stores(self, instance):
        stores = StoreMaster.cmobjects.filter(users__id=instance.id).values_list('id', flat=True)
        return stores or []
    
    def get_other_documents(self, instance):
        if OtherDocuments.cmobjects.filter(user_id=instance.id).exists():
            other_details = OtherDocuments.cmobjects.filter(user_id=instance.id).values()
            return other_details
        else:
            return []

    def get_license_details(self, instance):
        if LicenseAndCertificate.cmobjects.filter(user_id=instance.id).exists():
            licence_details = LicenseAndCertificate.cmobjects.filter(user_id=instance.id).values()
            return licence_details
        else:
            return []
        
    def get_academic_qualifications(self, instance):
        if AcademicQualification.cmobjects.filter(user_id=instance.id).exists():
            academic_details = AcademicQualification.cmobjects.annotate(\
                qualifications_name=F('qualifications__name')).filter(user_id=instance.id).values()
            return academic_details
        else:
            return []
        
    def get_work_experience(self, instance):
        if WorkExperience.cmobjects.filter(user_id=instance.id).exists():
            work_details = WorkExperience.cmobjects.filter(user_id=instance.id).values()
            return work_details
        else:
            return []


    def get_age(self, instance):
        from datetime import date
        if instance.date_of_birth:
            today = date.today()
            return today.year - instance.date_of_birth.year - ((today.month, today.day) < (instance.date_of_birth.month, instance.date_of_birth.day))
        else:
            return ""
        
    def get_reporting_manager_details(self, instance):
        if instance.reporting_manager_id:
            user_details = PmsUser.objects.filter(id=instance.reporting_manager_id).values('id', 'email', 'first_name', 'last_name')
            return user_details
        else:
            return []


    def get_notice_period(self, instance):
        if instance.notice_period:
            return instance.notice_period
        else:
            return ''
        
    def get_employe_code(self, instance):
        if instance.employe_code:
            return instance.employe_code
        else:
            return ''
        
    def get_pan_number(self, instance):
        if instance.pan_number:
            return instance.pan_number
        else:
            return ''
        
    def get_aadhar_number(self, instance):
        if instance.aadhar_number:
            return instance.aadhar_number
        else:
            return ''
        
    def get_gender(self, instance):
        if instance.gender:
            return instance.gender
        else:
            return ''
        
    def get_blood_group(self, instance):
        if instance.blood_group:
            return instance.blood_group
        else:
            return ''
    
    def get_country(self, instance):
        if instance.country_id:
            return instance.country_id
        else:
            return ''
        
    def get_state(self, instance):
        if instance.state_id:
            return instance.state_id
        else:
            return ''
        
    def get_city(self, instance):
        if instance.city_id:
            return instance.city_id
        else:
            return ''
        
    def get_zone(self, instance):
        if instance.zone_id:
            return instance.zone_id
        else:
            return ''


    def get_role_details(self, instance):
        if instance.id:
            user_details = PmsUser.objects.filter(id=instance.id).first()
            serializer = RoleUserWiseSerilizer(user_details)
            return serializer.data
        else:
            return ''

    def get_zone_details(self, instance):
        if instance.zone_id:
            zone_details = Zone.objects.filter(id=instance.zone_id).first()
            serializer = ZoneSerializer(zone_details)
            return serializer.data
        else:
            return ''

    def get_country_details(self, instance):
        if instance.country_id:
            country_details = Country.objects.filter(id=instance.country_id).first()
            serializer = CountrySerializer(country_details)
            return serializer.data
        else:
            return ''

    def get_state_details(self, instance):
        if instance.state_id:
            state_details = State.objects.filter(state_id=instance.state_id).first()
            serializer = StateSerializer(state_details)
            return serializer.data
        else:
            return ''

    def get_city_details(self, instance):
        if instance.city_id:
            city_details = City.objects.filter(city_id=instance.city_id).first()
            serializer = CitySerializer(city_details)
            return serializer.data
        else:
            return ''

    def get_organization_name(self,instance):
        if instance.organization_id:
            details = Organization.objects.filter(pk=instance.organization_id).values()
            return details
        else:
            return ''


    def get_company_details(self,instance):
        if instance.company_name_id:
            details = Company.objects.filter(pk=instance.company_name_id).values()
            return details
        else:
            return ''

    def get_designation_details(self,instance):
        if instance.designation_id:
            details = Role.objects.filter(pk=instance.designation_id).values()
            return details
        else:
            return ''


    def get_department_details(self,instance):
        if instance.department_id:
            details = Department.objects.filter(pk=instance.department_id).values()
            return details
        else:
            return ''

    def get_profile_pic_url(self,instance):
        user_details = UserProfile.objects.filter(user_id=instance.id).first()
        if user_details:
            request = self.context.get('request')
            profile_pic = request.build_absolute_uri(user_details.image.url) if user_details.image else ''
        else:
            profile_pic = ''
        return profile_pic

    def get_phone_no(self,instance):
        user_details = UserProfile.objects.filter(user_id=instance.id).first()
        if user_details:
            phone_no = user_details.phone_no
        else:
            phone_no = ''
        return phone_no


    class Meta:
        model = PmsUser
        fields = "__all__"


class UserCustomListSerializer(serializers.ModelSerializer):
    """
    User Custom List Serializer
    """
    permission_list = serializers.SerializerMethodField()
    phone_no = serializers.SerializerMethodField()
    full_name = serializers.SerializerMethodField()

    def get_permission_list(self,instance):
        return UserWiseModulePermissions.cmobjects.filter(user_id=instance.id,level_permission=True).values('module_item__unique_id')

    def get_phone_no(self,instance):
        user_details = UserProfile.objects.filter(user_id=instance.id).first()
        if user_details:
            phone_no = user_details.phone_no
        else:
            phone_no = ''
        return phone_no
    
    def get_full_name(self,instance):
        if instance.first_name:
            name = str(instance.first_name) + " " + str(instance.last_name)
        else:
            name = ''
        return name
    
    class Meta:
        model = PmsUser
        fields = ('id', 'email', 'phone_no', 'full_name', 'first_name', 'last_name', 'permission_list', 'employe_code')

class UserCreateSerializer(serializers.ModelSerializer):
    """ 
    This Serializer is for Adding User , 
    PmsUser and UserProfile table

    """
    organization = serializers.CharField(required=False,allow_null=True)
    zone = serializers.CharField(required=False,allow_null=True)
    employement_type = serializers.CharField(required=False,allow_null=True)
    company_name = serializers.CharField(required=False,allow_null=True)
    designation = serializers.CharField(required=False,allow_null=True)
    department = serializers.CharField(required=False,allow_null=True)
    reporting_manager = serializers.CharField(required=False, allow_null=True)
    role = serializers.CharField(required=False,allow_null=True)
    country = serializers.CharField(required=False,allow_null=True)
    state = serializers.CharField(required=False,allow_null=True)
    city = serializers.CharField(required=False,allow_null=True)
    aadhar_number = serializers.CharField(required=False,allow_null=True)
    pan_number = serializers.CharField(required=False,allow_null=True)
    gender = serializers.CharField(required=False,allow_null=True)
    blood_group = serializers.CharField(required=False,allow_null=True)
    phone_no = serializers.CharField(required=False,allow_null=True)
    notice_period = serializers.CharField(required=False,allow_null=True)
    employe_code = serializers.CharField(required=False,allow_null=True)
    image = serializers.ImageField(required=False, max_length=None, 
                                     allow_empty_file=True, use_url=True)

    class Meta:
        model = PmsUser
        fields = ('id','organization','zone','employement_type','company_name','designation', 'department', 'reporting_manager',
        'role','country','state','city','image',
        'aadhar_number','pan_number','gender','blood_group', 'email','first_name','last_name', 'phone_no','notice_period','employe_code',
            'joining_date', 'last_working_date','date_of_birth','address_line_1','address_line_2','maratial_status','mothers_name',
            'fathers_name','emergency_contact_relation','emergency_contact_name','emergency_contact_phone_no')
        
        # Remove required=True from the following fields:
        extra_kwargs = {
            'aadhar_number': {'required': False},
            'pan_number': {'required': False},
            'image': {'required': False},
        }

    def create(self, validated_data):
        try:
            print('validated_data',validated_data)
           
            if not validated_data.get('organization') or \
                validated_data.get('organization') == "null":
                raise APIException("Organization Id not provided")


            logdin_user_id = self.context['request'].user.id


            email = '' if validated_data['email'] == 'null' else validated_data['email']
            # username = validated_data['username']
            #validated_data['username'] = email

            # if validated_data.get('password',None):
            #     password = validated_data['password']

            # password = PmsUser.objects.make_random_password()
            password = 'secret@1234'

            if validated_data.get('pan_number',None):
                pan_number= validated_data['pan_number']
            else:
                pan_number = None

            organization=validated_data['organization']
            # if PmsUser.objects.filter(Q(username=username) | Q(email=email) | Q(pan_number=pan_number)).exists(): #check existing username or email id
            #     raise APIException("Username or Email or Pan number is already exist")
            # if PmsUser.objects.filter(username=validated_data['username']).exists(): #check existing username 
            #     raise APIException("Username already exist")
                # return Response({'message': 'A user with that username already exists'}, status=status.HTTP_400_BAD_REQUEST)
            if PmsUser.objects.filter(email=email, is_deleted=True).exists(): # Username already exists validation
                msg = f"Email {str(email)} already exists in deleted user list, if you wish to restore please restore it from deleted user list!"
                raise APIException( msg )
            
            if PmsUser.objects.filter(email=email, is_deleted=False).exists(): #check existing  email id
                raise APIException("Email  is already exist")
                # return Response({'message': 'Email  is already exist'}, status=status.HTTP_400_BAD_REQUEST)
            if pan_number and PmsUser.objects.filter(pan_number=validated_data['pan_number'], \
                                                                         organization=organization, is_deleted=False).exists():
                raise APIException("Pan number is already exist")
                # return Response({'message': 'Pan number is already exist'}, status=status.HTTP_400_BAD_REQUEST)

            with transaction.atomic():
                user = PmsUser.objects.create(
                    email=email,
                    first_name = validated_data.get('first_name', None),
                    last_name = validated_data.get('last_name', None),
                    organization_id = validated_data.get('organization', None),
                    zone_id = validated_data.get('zone', None),
                    employement_type_id = validated_data.get('employement_type', None),
                    company_name_id = validated_data.get('company_name', None),
                    designation_id = validated_data.get('designation', None),
                    department_id = validated_data.get('department', None),
                    reporting_manager_id = validated_data.get('reporting_manager', None),
                    role_id = validated_data.get('role', None),
                    country_id = validated_data.get('country', None),
                    state_id = validated_data.get('state', None),
                    city_id = validated_data.get('city', None),
                    aadhar_number = validated_data.get('aadhar_number', None),
                    pan_number = validated_data.get('pan_number', None),
                    gender = validated_data.get('gender', None),
                    blood_group = validated_data.get('blood_group', None),
                    notice_period = validated_data.get('notice_period', None),
                    employe_code = validated_data.get('employe_code', None),
                    joining_date = validated_data.get('joining_date', None),
                    last_working_date = validated_data.get('last_working_date', None),
                    date_of_birth = validated_data.get('date_of_birth', None),
                    address_line_1 = validated_data.get('address_line_1', None),
                    address_line_2 = validated_data.get('address_line_2', None),
                    #maratial_status = validated_data.get('maratial_status', None),
                    created_by_id = logdin_user_id
                )
                print('user_save: ', user)
                # print("check 3",user.role,user.designation,user.zone,user.city,user.country,\
                #       user.state,user.organization,user.company_name,user.employement_type)

                #if validated_data.get('password'):
                user.set_password(password)
                user.password_expiry_date=password_expiry_date_reset()
                user.save()
                if user:
                    userdetail_save = UserProfile.objects.create(
                        user = user,
                        email=email,
                        first_name = validated_data.get('first_name', None),
                        last_name = validated_data.get('last_name', None),
                        image = validated_data.get('image', None),
                        phone_no = validated_data.get('phone_no', None),
                        password_to_know = password
                        )
                    print('userdetail_save',userdetail_save)

                    if user.role_id:
                        from administrations.utils import create_userwise_permissions
                        create_userwise_permissions(user.role_id, user.id, validated_data.get('organization', None))

                    ## send account creation and reset password link message
                    uidb64 = urlsafe_base64_encode(smart_bytes(user.id))
                    token = PasswordResetTokenGenerator().make_token(user)
                    absurl=str(os.getenv('FE_FORGET_PASSWORD',''))+uidb64 + "/" +token
                    print(absurl)
                    trigger_notifications(action='RESET-PASSWORD-NEW-USER', subject='PMS Account Created', user_list=[user.id], context={'reset_link': absurl, 'email': userdetail_save.email, 'password': userdetail_save.password_to_know, 'first_name': userdetail_save.first_name})

                    # schedule_generic_mail(subject='PMS Account Created', to_mail_list=[userdetail_save.email], context={'reset_link': absurl, 'email': userdetail_save.email, 'password': userdetail_save.password_to_know, 'first_name': userdetail_save.first_name}, template_name='RESET-PASSWORD-NEW-USER')

            return validated_data
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})



######### Update user details ################
class EditUserSerializer(serializers.ModelSerializer):
    # updated_by = serializers.HiddenField(default=serializers.CurrentUserDefault())
    image_action = serializers.CharField(required=False,allow_null=True)
    phone_no = serializers.CharField(required=False,allow_null=True)
    stores = serializers.ListField(
        child=serializers.CharField(allow_blank=True), 
        required=False,
        allow_empty=True,
        write_only=True
    )
    class Meta:
        model = PmsUser
        fields = ('id','zone','employement_type','company_name','designation', 'department', 'reporting_manager',
        'role','country','state','city', 'image', 'phone_no','is_active','image_action',
        'aadhar_number','pan_number','gender','blood_group', 'email','first_name','last_name', 'phone_no','notice_period','employe_code',
        'joining_date', 'last_working_date','date_of_birth','address_line_1','address_line_2','maratial_status','mothers_name',
            'fathers_name','emergency_contact_relation','emergency_contact_name','emergency_contact_phone_no',
        'is_allow_multiple_device','is_allow_otp_login', 'stores')
        lookup_field = 'user_id'

    def update(self, instance, validated_data):
        try:
            if PmsUser.objects.filter(email=validated_data.get('email', instance.email), \
                                        is_deleted=False).exclude(email=instance.email).exists(): #check existing  email id
                # raise APIException({'request_status': 0, 'msg': "Email already exist"})
                raise APIException("Email already exist")
            
            if PmsUser.objects.filter(email=validated_data.get('email', instance.email), \
                                        is_deleted=True).exclude(email=instance.email).exists(): # Username already exists validation
                msg = f"Email  {str(validated_data.get('email', instance.email))} already exists in deleted user list, if you wish to restore please restore it from deleted user list!"
                raise APIException(msg)
            
            with transaction.atomic():
                #email = validated_data.pop('email') if "email" in validated_data else ""

                instance.email= validated_data.get('email', instance.email)
                instance.first_name = validated_data.get('first_name', instance.first_name)
                instance.last_name = validated_data.get('last_name', instance.last_name)

                if validated_data.get('zone', instance.zone_id) != "null":
                    instance.zone = validated_data.get('zone', instance.zone)
                else:
                    instance.zone = instance.zone

                instance.employement_type = validated_data.get('employement_type', instance.employement_type)
                instance.designation = validated_data.get('designation', instance.designation)
                instance.department = validated_data.get('department', instance.department)
                

                ######################### New User Fields Added on (03/05/2023) #############################
                from datetime import date
                instance.reporting_manager = validated_data.get('reporting_manager', instance.reporting_manager)
                instance.joining_date = validated_data.get('joining_date', instance.joining_date)

                if validated_data.get('last_working_date', None) == 'null':
                    instance.last_working_date = None
                else:
                    instance.last_working_date = validated_data.get('last_working_date', None)

                instance.date_of_birth = validated_data.get('date_of_birth', instance.date_of_birth)
                instance.address_line_1 = validated_data.get('address_line_1', instance.address_line_1)
                instance.address_line_2 = validated_data.get('address_line_2', instance.address_line_2)
                #instance.maratial_status = validated_data.get('maratial_status', instance.maratial_status)
                ######################### ################################### #############################

                if validated_data.get('role', instance.role_id) != "null":
                    instance.role = validated_data.get('role', instance.role)
                else:
                    instance.role = instance.role

                if validated_data.get('company_name', instance.company_name_id) != "null":
                    instance.company_name = validated_data.get('company_name', instance.company_name)
                else:
                    instance.company_name = instance.company_name


                if validated_data.get('country', instance.country_id) != "null":
                    instance.country = validated_data.get('country', instance.country)
                else:
                    instance.country = instance.country

                if validated_data.get('state', instance.state_id) != "null":
                    instance.state = validated_data.get('state', instance.state)
                else:
                    instance.state = instance.state

                if validated_data.get('city', instance.city_id) != "null":
                    instance.city = validated_data.get('city', instance.city)
                else:
                    instance.city = instance.city

                instance.aadhar_number = validated_data.get('aadhar_number', instance.aadhar_number)
                instance.pan_number = validated_data.get('pan_number', instance.pan_number)
                instance.gender = validated_data.get('gender', instance.gender)

                if validated_data.get('blood_group', instance.blood_group) != "null":
                    instance.blood_group = validated_data.get('blood_group', instance.blood_group)
                else:
                    instance.blood_group = instance.blood_group

                instance.notice_period = validated_data.get('notice_period', instance.notice_period)
                instance.employe_code = validated_data.get('employe_code', instance.employe_code)
                instance.is_active = validated_data.get('is_active', instance.is_active)
                instance.is_allow_multiple_device = validated_data.get('is_allow_multiple_device', instance.is_allow_multiple_device)
                instance.is_allow_otp_login = validated_data.get('is_allow_otp_login', instance.is_allow_otp_login)

                user_profile_details = UserProfile.objects.filter(user_id=instance.id).first()

                existing_images = '.' + settings.MEDIA_URL + str(user_profile_details.image)

                if not validated_data.get('image'):
                    print("No Image")

                if validated_data.get('image_action') == 'delete':
                    if validated_data.get('image'):
                        print('os.path.isfile(existing_images)::', os.path.isfile(existing_images))
                        if os.path.isfile(existing_images):
                            os.remove(existing_images)
                        instance.image = validated_data.get("image", None)
                        user_profile_details.image = validated_data.get("image", None)
                    else:
                        instance.image = None
                        user_profile_details.image = None
                else:
                    if validated_data.get('image'):
                        print('os.path.isfile(existing_images)::', os.path.isfile(existing_images))
                        if os.path.isfile(existing_images):
                            os.remove(existing_images)
                        instance.image = validated_data.get("image", None)
                        user_profile_details.image = validated_data.get("image", None)

                # store 
                store_ids = validated_data.get('stores', [])
                if store_ids:
                    raw_value = store_ids[0]
                    if raw_value: 
                        store_ids = [int(x) for x in raw_value.split(',') if x.strip()]
                    else:
                        store_ids = []
                else:
                    store_ids = []
                if not isinstance(store_ids, list):
                    raise APIException("Stores must be a list of integers")
                for store in StoreMaster.cmobjects.all():
                    store.users.remove(instance)
                for site in SiteMaster.cmobjects.all():
                    site.users.remove(instance)
                for project in ProjectMaster.cmobjects.all():
                    project.users.remove(instance)
                for store in StoreMaster.cmobjects.filter(id__in=store_ids):
                    store.users.add(instance)
                    if store.site:
                        store.site.users.add(instance)
                        if store.site.project:
                            store.site.project.users.add(instance)

                user_profile_details.phone_no = validated_data.get('phone_no', user_profile_details.phone_no)
                user_profile_details.email = validated_data.get('email', instance.email)
                user_profile_details.first_name = validated_data.get('first_name', instance.first_name)
                user_profile_details.last_name = validated_data.get('last_name', instance.last_name)

                # if instance.role_id:
                #     from administrations.utils import create_userwise_permissions
                #     create_userwise_permissions(instance.role_id.id, instance.id, instance.organization_id)
                user_profile_details.save()
                instance.save()
                from administrations.utils import create_dependent_formvalues_on_master_crud_operations
                full_name = str(instance.first_name) + " " + str(instance.last_name)
                create_dependent_formvalues_on_master_crud_operations('pmsuser', full_name, instance.id)

                data_dict = {}
                data_dict['id'] = instance.id
                data_dict['phone_no'] = user_profile_details.phone_no
                data_dict['image'] = user_profile_details.image
                data_dict['gender'] = instance.gender
                data_dict['username'] = instance.username
                data_dict['email'] = instance.email
                data_dict['name'] = instance.first_name + " " + instance.last_name
                data_dict['status'] = instance.is_active
                return data_dict

        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

class GroupSerializer(serializers.ModelSerializer):
    """
    Serializer for Group objects
    """
    user_groups = serializers.SerializerMethodField()
    level_list = serializers.SerializerMethodField()


    def get_level_list(self, instance):
        if instance.id:
            user_group_count = UsersGroup.objects.filter(\
                group_id=instance.id).count()
            level_list = []
            for i in range(1,user_group_count + 1):
                level_str = "Level " + str(i)
                level_list.append(level_str)
                
            return level_list
        else:
            return []


    def get_user_groups(self, instance):
        from django.db.models import Value as V
        from django.db.models.functions import Concat
        if instance.id:
            user_group_details = UsersGroup.objects.annotate(full_name=Concat('user__first_name', V(' '), 'user__last_name')).filter(\
                group_id=instance.id).values('user_id', 'user__username','full_name')
            return user_group_details
        else:
            return []
    class Meta:
        model = Group
        fields = '__all__'


class UserGroupSerializer(serializers.ModelSerializer):
    """
    User Serializer for Group objects
    """
    class Meta:
        model = UsersGroup
        fields = '__all__'


class AcademicSerializer(serializers.ModelSerializer):
    """ AcademicQualification Model Serializer"""

    class Meta:
        model = AcademicQualification
        fields = '__all__'



class LicenseSerializer(serializers.ModelSerializer):
    """ LicenseAndCertificate Model Serializer"""

    class Meta:
        model = LicenseAndCertificate
        fields = '__all__'


class WorkExperienceSerializer(serializers.ModelSerializer):
    """ WorkExperience Model Serializer"""

    class Meta:
        model = WorkExperience
        fields = '__all__'


class OtherDocumentSerializer(serializers.ModelSerializer):
    """ OtherDocument Model Serializer"""

    class Meta:
        model = OtherDocuments
        fields = '__all__'

class ChangePasswordSerializer(serializers.Serializer):
    """
    Serializer for password change endpoint.
    """
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)


class UserListNewSerializer(serializers.ModelSerializer):
    organization_name = serializers.SerializerMethodField()
    role_details = serializers.SerializerMethodField()
    country_details = serializers.SerializerMethodField()
    state_details = serializers.SerializerMethodField()
    city_details = serializers.SerializerMethodField()
    designation_details = serializers.SerializerMethodField()
    company_details = serializers.SerializerMethodField()
    department_details = serializers.SerializerMethodField()
    profile_pic_url = serializers.SerializerMethodField()
    phone_no = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()
    state = serializers.SerializerMethodField()
    city = serializers.SerializerMethodField()
    zone = serializers.SerializerMethodField()
    gender = serializers.SerializerMethodField()
    blood_group = serializers.SerializerMethodField()
    notice_period = serializers.SerializerMethodField()
    employe_code = serializers.SerializerMethodField()
    pan_number = serializers.SerializerMethodField()
    aadhar_number = serializers.SerializerMethodField()
    age = serializers.SerializerMethodField()
    reporting_manager_details = serializers.SerializerMethodField()
    academic_qualifications = serializers.SerializerMethodField()
    license_details = serializers.SerializerMethodField()
    work_experience = serializers.SerializerMethodField()
    other_documents = serializers.SerializerMethodField()


    def get_other_documents(self, instance):
        if OtherDocuments.cmobjects.filter(user_id=instance.id).exists():
            other_details = OtherDocuments.cmobjects.filter(user_id=instance.id).values()
            return other_details
        else:
            return []

    def get_license_details(self, instance):
        if LicenseAndCertificate.cmobjects.filter(user_id=instance.id).exists():
            licence_details = LicenseAndCertificate.cmobjects.filter(user_id=instance.id).values()
            return licence_details
        else:
            return []
        
    def get_academic_qualifications(self, instance):
        if AcademicQualification.cmobjects.filter(user_id=instance.id).exists():
            academic_details = AcademicQualification.cmobjects.annotate(\
                qualifications_name=F('qualifications__name')).filter(user_id=instance.id).values()
            return academic_details
        else:
            return []
        
    def get_work_experience(self, instance):
        if WorkExperience.cmobjects.filter(user_id=instance.id).exists():
            work_details = WorkExperience.cmobjects.filter(user_id=instance.id).values()
            return work_details
        else:
            return []


    def get_age(self, instance):
        from datetime import date
        if instance.date_of_birth:
            today = date.today()
            return today.year - instance.date_of_birth.year - ((today.month, today.day) < (instance.date_of_birth.month, instance.date_of_birth.day))
        else:
            return ""
        
    def get_reporting_manager_details(self, instance):
        if instance.reporting_manager_id:
            user_details = PmsUser.objects.filter(id=instance.reporting_manager_id).values('id', 'email', 'first_name', 'last_name')
            return user_details
        else:
            return []


    def get_notice_period(self, instance):
        if instance.notice_period:
            return instance.notice_period
        else:
            return ''
        
    def get_employe_code(self, instance):
        if instance.employe_code:
            return instance.employe_code
        else:
            return ''
        
    def get_pan_number(self, instance):
        if instance.pan_number:
            return instance.pan_number
        else:
            return ''
        
    def get_aadhar_number(self, instance):
        if instance.aadhar_number:
            return instance.aadhar_number
        else:
            return ''
        
    def get_gender(self, instance):
        if instance.gender:
            return instance.gender
        else:
            return ''
        
    def get_blood_group(self, instance):
        if instance.blood_group:
            return instance.blood_group
        else:
            return ''
    
    def get_country(self, instance):
        if instance.country_id:
            return instance.country_id
        else:
            return ''
        
    def get_state(self, instance):
        if instance.state_id:
            return instance.state_id
        else:
            return ''
        
    def get_city(self, instance):
        if instance.city_id:
            return instance.city_id
        else:
            return ''
        
    def get_zone(self, instance):
        if instance.zone_id:
            return instance.zone_id
        else:
            return ''


    def get_role_details(self, instance):
        if instance.id:
            user_details = PmsUser.objects.filter(id=instance.id).first()
            serializer = RoleUserWiseSerilizer(user_details)
            return serializer.data
        else:
            return ''

  

    def get_country_details(self, instance):
        if instance.country_id:
            country_details = Country.objects.filter(id=instance.country_id).first()
            serializer = CountrySerializer(country_details)
            return serializer.data
        else:
            return ''

    def get_state_details(self, instance):
        if instance.state_id:
            state_details = State.objects.filter(state_id=instance.state_id).first()
            serializer = StateSerializer(state_details)
            return serializer.data
        else:
            return ''

    def get_city_details(self, instance):
        if instance.city_id:
            city_details = City.objects.filter(city_id=instance.city_id).first()
            serializer = CitySerializer(city_details)
            return serializer.data
        else:
            return ''

    def get_organization_name(self,instance):
        if instance.organization_id:
            details = Organization.objects.filter(pk=instance.organization_id).values()
            return details
        else:
            return ''


    def get_company_details(self,instance):
        if instance.company_name_id:
            details = Company.objects.filter(pk=instance.company_name_id).values()
            return details
        else:
            return ''

    def get_designation_details(self,instance):
        if instance.designation_id:
            details = Role.objects.filter(pk=instance.designation_id).values()
            return details
        else:
            return ''


    def get_department_details(self,instance):
        if instance.department_id:
            details = Department.objects.filter(pk=instance.department_id).values()
            return details
        else:
            return ''

    def get_profile_pic_url(self,instance):
        user_details = UserProfile.objects.filter(user_id=instance.id).first()
        if user_details:
            request = self.context.get('request')
            profile_pic = request.build_absolute_uri(user_details.image.url) if user_details.image else ''
        else:
            profile_pic = ''
        return profile_pic

    def get_phone_no(self,instance):
        user_details = UserProfile.objects.filter(user_id=instance.id).first()
        if user_details:
            phone_no = user_details.phone_no
        else:
            phone_no = ''
        return phone_no


    class Meta:
        model = PmsUser
        fields = "__all__"    


class PersonalDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = PersonalDetails
        fields = '__all__'

class AcademicCredentialDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AcademicCredentialDetails
        fields = '__all__'

class EmergencyContactDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmergencyContactDetails
        fields = '__all__'
class FamilyDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = FamilyDetails
        fields = '__all__'
class BankDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BankDetails
        fields = '__all__'

class ProfessionalDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProfessionalDetails
        fields = '__all__'
class AttachmentDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttachmentDetails
        fields = '__all__'
    
    @transaction.atomic
    def create(self, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
        else:
            processed_attachment = None

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        instance = AttachmentDetails.objects.create(**validated_data)

        if processed_attachment:
            instance.attachment = processed_attachment
        instance.save()

        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
            if processed_attachment:
                instance.attachment = processed_attachment

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        for field, value in validated_data.items():
            setattr(instance, field, value)

        instance.save()
        return instance
