from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from .models import *
# Register your models here.

admin.site.register(UserProfile,ModelAdmin)
admin.site.register(Group,ModelAdmin)
admin.site.register(UsersGroup,ModelAdmin)

admin.site.register(PersonalDetails,ModelAdmin)
admin.site.register(AcademicCredentialDetails,ModelAdmin)
admin.site.register(EmergencyContactDetails,ModelAdmin)
admin.site.register(FamilyDetails,ModelAdmin)
admin.site.register(BankDetails,ModelAdmin)
admin.site.register(ProfessionalDetails,ModelAdmin)
admin.site.register(AttachmentDetails,ModelAdmin)
