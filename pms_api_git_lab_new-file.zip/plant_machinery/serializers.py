from rest_framework import serializers
import calendar
from .models import *
from datetime import date, timedelta , datetime, time
from django.db import transaction
from django.db.models import F, Subquery, OuterRef, Count, Value, FloatField, Sum , Case, When , IntegerField, ExpressionWrapper, Min, Max, Avg
from django.db.models.functions import Coalesce
from administrations.models import *
from project_and_planning.models import ProjectMaster , ProjectData
from procurement.models import SiteMaster,StoreMaster , MultiStageSetting
from email_config.models import *
from django.template import Template, Context
from procurement.helper import get_project_data, get_plant_machinery_data,process_attachments, generate_all_code, get_details_from_instance, get_vendor_data, parent_fields, generate_rfq_link, multi_stage_stage_details, multi_stage_status_details, date_diff_handle
def represents_int(s):
    try: 
        int(s)
    except ValueError:
        return False
    else:
        return True


# class CommonFilterListSerializer(serializers.ListSerializer):
#     """
#     ListSerializer
#     cmobject: is_deleted=False
#     """
#     def to_representation(self, data):
#         data = data.filter(is_deleted=False)
#         return super(CommonFilterListSerializer, self).to_representation(data)
class CommonFilterListSerializer(serializers.ListSerializer):
    """
    ListSerializer
    cmobject: is_deleted=False
    """
    def to_representation(self, data):
      
        if hasattr(data, 'object_list'):
            data.object_list = [item for item in data.object_list if not item.is_deleted]
        else:
            print("check without pagination")
            data = data.filter(is_deleted=False)
        
        return super().to_representation(data)
class PlantMachineryDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryData
        fields = '__all__'


class PlantMachineryMasterSerializer(serializers.ModelSerializer):
    plant_machinery_data = serializers.SerializerMethodField()

    def get_plant_machinery_data(self, instance):
        form_menu_type = self.context.get("form_menu_type", None)
        form_group_id = self.context.get("form_group_id", None)

        master_list = list(FormMenuMaster.objects.filter(is_display=True).values_list('form_type_name', flat=True))

        group_list_ids = list(FormGroupMastr.cmobjects.filter(form_type__in=master_list).values_list('id', flat=True))

        if form_menu_type and form_group_id:
            form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id, \
                                                     organization_id=self.context["organization_id"], \
                                                        form_type='plant_and_machinery').order_by('form_group_id', \
                                                                                                                                                'sort_orders')
        elif form_menu_type:
            group_ids = list(FormGroupMastr.cmobjects.filter(form_type=form_menu_type).values_list('id', flat=True))
            form_datas = FormMaster.cmobjects.filter(form_group_id__in=group_ids, \
                                                     organization_id=self.context["organization_id"], \
                                                        form_type='plant_and_machinery').order_by('form_group_id', \
                                                                                                  'sort_orders')
        elif form_group_id:
            form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id, \
                                                     organization_id=self.context["organization_id"], \
                                                    form_type='plant_and_machinery').order_by('form_group_id', \
                                                                                              'sort_orders')
        else:
            form_datas = FormMaster.cmobjects.filter(organization_id=self.context["organization_id"], \
                                                     form_group_id__in=group_list_ids,\
                                                            form_type='plant_and_machinery').order_by('form_group_id', \
                                                                                                      'sort_orders')

        plant_machinery_datas = []
        # for item in form_datas:
        #     plant_machinery_data_details = PlantMachineryData.cmobjects.select_related('form').filter(form_id=item.id, \
        #                                                                                               plantmachinery_id=instance.id).first()
        #     plant_machinery_dict = dict()
        #     plant_machinery_dict['id'] = plant_machinery_data_details.id if plant_machinery_data_details else ""
        #     plant_machinery_dict['form_label'] = item.form_label
        #     if plant_machinery_data_details:
        #         if plant_machinery_data_details.value and represents_int(plant_machinery_data_details.value):
        #             final_value = FormDropdownChoices.objects.filter(id=int(plant_machinery_data_details.value)).first()
        #             if final_value and plant_machinery_data_details.form.form_input_type == 'dropdown':
        #                 plant_machinery_dict['value'] = final_value.option
        #             elif plant_machinery_data_details.form.form_internal_name in ['depriciation_cost', 'sum_(e=a+b+c+d)']:
        #                 plant_machinery_dict['value'] = round(float(plant_machinery_data_details.value), 2)
        #             else:
        #                 plant_machinery_dict['value'] = format(int(plant_machinery_data_details.value), '.2f')
        #         else:
        #             if plant_machinery_data_details.form.form_internal_name in ['depriciation_cost', 'sum_(e=a+b+c+d)']:
        #                 plant_machinery_dict['value'] = round(float(plant_machinery_data_details.value), 2)
        #             else:
        #                 plant_machinery_dict['value'] = plant_machinery_data_details.value
        #     else:
        #         plant_machinery_dict['value'] = ""
        #     plant_machinery_dict['document'] = plant_machinery_data_details.document.url if plant_machinery_data_details and plant_machinery_data_details.document else ""
        #     plant_machinery_dict['internal_name'] = item.form_internal_name
        #     plant_machinery_dict['form_group_id'] = item.form_group_id
        #     plant_machinery_datas.append(plant_machinery_dict)
        for item in form_datas:
            plant_machinery_dict = dict()

            plant_machinery_details = PlantMachineryData.cmobjects.select_related('form').filter(form_id=item.id, \
                                                                                                    plantmachinery_id=instance.id).first()

            plant_machinery_dict['id'] = plant_machinery_details.id if plant_machinery_details else ""
            plant_machinery_dict['form_label'] = item.form_label
            if plant_machinery_details:
                if plant_machinery_details.value and represents_int(plant_machinery_details.value):
                    final_value = FormDropdownChoices.objects.filter(id=int(plant_machinery_details.value),\
                                                                    form__form_type='plant_and_machinery').first()
                    
                    if final_value and plant_machinery_details.form.form_input_type in ['dropdown','radio']:
                        plant_machinery_dict['value'] = final_value.option
                        plant_machinery_dict['value_id'] = final_value.id
                    else:
                        if plant_machinery_details.form.form_input_type in ['reference']:
                            final_value1 = FormDependentChoices.objects.filter(option_id=int(plant_machinery_details.value),\
                                                                        form__form_type='plant_and_machinery',form_id=item.id).first()
                            if final_value1:
                                plant_machinery_dict['value'] = final_value1.name
                                plant_machinery_dict['value_id'] = plant_machinery_details.value
                            else:
                                plant_machinery_dict['value'] = plant_machinery_details.value
                                plant_machinery_dict['value_id'] = ""
                        else:
                            plant_machinery_dict['value'] = plant_machinery_details.value
                            plant_machinery_dict['value_id'] = ""
                else:
                    plant_machinery_dict['value'] = plant_machinery_details.value
                    plant_machinery_dict['value_id'] = ""
            else:
                plant_machinery_dict['value'] = ""
                plant_machinery_dict['value_id'] = ""
            plant_machinery_dict['document'] = plant_machinery_details.document.url if plant_machinery_details and plant_machinery_details.document else ""
            plant_machinery_dict['internal_name'] = item.form_internal_name
            plant_machinery_dict['form_group_id'] = item.form_group_id
            plant_machinery_datas.append(plant_machinery_dict)
        return plant_machinery_datas

    class Meta:
        model = PlantMachineryMaster
        fields = '__all__'


class PlantMachineryGroupSerializer(serializers.ModelSerializer):
    """ New plant machinery group model serializer or machine category serializer"""
    # machines_details = serializers.SerializerMethodField()
    machines_count = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryGroup
        fields = '__all__'
    def get_machines_count(self, instance):
        # print(self.context)
        filter={'is_deleted':False,'is_active':True}
        project_id = self.context.get('project_id', None)
        if project_id:
            filter['project_id'] = project_id
        return instance.plant_machinery_group_plant_machinery_machine.filter(**filter).count()

class PlantMachinerySerializer(serializers.ModelSerializer):
    """ New plant machinery model serializer"""
    class Meta:
        model = PlantMachinery
        fields = '__all__'


class PlantMachineryDprSerializer(serializers.ModelSerializer):
    """ PlantMachineryDpr model serializer"""
    class Meta:
        model = PlantMachineryDpr
        fields = '__all__'
# class PlantMachineryDprMasterSerializer(serializers.ModelSerializer):
#     project_details = serializers.SerializerMethodField()
#     site_details = serializers.SerializerMethodField()
#
#     class Meta:
#         model = PlantMachineryDprMaster
#         fields = '__all__'
#
#     def get_project_details(self, instance):
#         project = instance.project
#         if project:
#             return get_project_data(instance.project.id)
#         return None
#
#     def get_site_details(self, instance):
#         site = instance.site
#         if site:
#             return SiteMaster.objects.filter(pk=site.id).values().first()
#         return None
#
#     def to_representation(self, instance):
#         representation = super().to_representation(instance)
#         representation['project_details'] = self.get_project_details(instance)
#         representation['site_details'] = self.get_site_details(instance)
#         return representation


class PlantMachineryDprNewSerializer(serializers.ModelSerializer):
    """ PlantMachineryDprNew model serializer"""

    project_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()


    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)
        return None

    def get_site_details(self, instance):
        site = instance.site
        if site :
            return SiteMaster.cmobjects.filter(pk=site.id).values().first()
        return None

    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine:
            return PlantMachineryMachine.cmobjects.filter(pk=instance.plant_machinery_machine.id).values().first()
        return None
   
    class Meta:
        model = PlantMachineryDprNew
        fields = '__all__'


class PlantMachineryDprMasterSerializer(serializers.ModelSerializer):
    project_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    dpr_new_details = PlantMachineryDprNewSerializer(many=True, required=False, source='dpr_master_plant_machinery_dpr_new')
    class Meta:
        model = PlantMachineryDprMaster
        fields = '__all__'

    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)
        return None

    def get_site_details(self, instance):
        site = instance.site
        if site:
            return SiteMaster.objects.filter(pk=site.id).values().first()
        return None

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['project_details'] = self.get_project_details(instance)
        representation['site_details'] = self.get_site_details(instance)
        return representation

class PlantMachineryDeletedDocumentSerializer(serializers.ModelSerializer):
    updated_by_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryDocumentUpload
        fields = '__all__'
        
    def get_updated_by_details(self, instance):
        _details = None
        if instance.updated_by and instance.updated_by_id:
            _details = PmsUser.objects.filter(pk=instance.updated_by_id).values('first_name', 'last_name', 'email').first()
        return _details

    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_document_upload_master and instance.plant_machinery_document_upload_master.plant_machinery_machine:
            machine = instance.plant_machinery_document_upload_master.plant_machinery_machine
            return PlantMachineryMachine.cmobjects.filter(pk=machine.id).values().first()
            # return get_details_from_instance(machine)
        return None

class PlantMachineryDocumentUploadSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PlantMachineryDocumentUpload
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
   

class PlantMachineryDocumentUploadMasterSerializer(serializers.ModelSerializer):
    attachments = PlantMachineryDocumentUploadSerializer(many=True, required=False, source='document_upload_master_plant_machinery_document_upload')
    plant_machinery_group_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryDocumentUploadMaster
        fields = '__all__'
    def get_plant_machinery_group_details(self, instance):
        
        # if instance.plant_machinery_group:
        #     print(instance.plant_machinery_group)
        #     return PlantMachineryGroup.cmobjects.filter(pk=instance.plant_machinery_group.pk).values().first()
        # return None
        if instance.plant_machinery_group and not getattr(instance.plant_machinery_group, "is_deleted", False):
            return {"name": instance.plant_machinery_group.name \
                    if instance.plant_machinery_group.name else None,}
        return None
    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine and not getattr(instance.plant_machinery_machine, "is_deleted", False):
            # return PlantMachineryMachine.cmobjects.filter(pk=instance.plant_machinery_machine.id).values().first()
            return {'equipment_description':instance.plant_machinery_machine.equipment_number if instance.plant_machinery_machine.equipment_number else None,
                    'machine_number' :instance.plant_machinery_machine.machine_number if instance.plant_machinery_machine.machine_number else None
                    }
        return None

    @transaction.atomic
    def create(self, validated_data):
        attachments_data = validated_data.pop('document_upload_master_plant_machinery_document_upload', [])
        document_upload_master = PlantMachineryDocumentUploadMaster.objects.create(**validated_data)
        current_user = document_upload_master.created_by if document_upload_master.created_by else None

        for attachment_data in attachments_data:
            processed_attachment = process_attachments(attachment_data)
            if processed_attachment:
                PlantMachineryDocumentUpload.objects.create(
                    organization=document_upload_master.organization,
                    plant_machinery_document_upload_master=document_upload_master,
                    document_name=attachment_data.get('document_name'),
                    exp_date=attachment_data.get('exp_date'),
                    remarks=attachment_data.get('remarks'),
                    attachment=processed_attachment,
                    mime_type= '',
                    file_data='',
                    created_by=current_user,
                )
        return document_upload_master

    @transaction.atomic
    def update(self, instance, validated_data):
        attachments_data = validated_data.pop('document_upload_master_plant_machinery_document_upload', [])
        # print(attachments_data)
       
        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        existing_attachments = instance.document_upload_master_plant_machinery_document_upload.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                existing_attachment = PlantMachineryDocumentUpload.objects.create(
                    organization=instance.organization,
                    plant_machinery_document_upload_master=instance,
                    document_name=attachment_data.get('document_name'),
                    exp_date=attachment_data.get('exp_date'),
                    remarks=attachment_data.get('remarks'),
                    attachment=temp_attach_data,
                    mime_type='',
                    file_data='',
                    created_by=current_user,
                )

            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'document_name', attachment_data.get('document_name', None))
                setattr(existing_attachment, 'exp_date', attachment_data.get('exp_date', None))
                setattr(existing_attachment, 'remarks', attachment_data.get('remarks', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()
        
        instance.save()                   
        return instance
    def to_representation(self, instance):
        representation = super().to_representation(instance)

        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data

      
        return representation
    
class PlantMachineryServiceGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryServiceGroup
        fields = '__all__'

class PlantMachineryServiceItemSerializer(serializers.ModelSerializer):
    service_group_details= serializers.SerializerMethodField()
    plant_machinery_machine_details= serializers.SerializerMethodField()
    def get_service_group_details(self, instance):
    #     service_group = instance.plant_machinery_service_group
    #     if service_group:
    #         return PlantMachineryServiceGroup.cmobjects.filter(pk=service_group.id).values().first()
        
    #     return None
        return get_details_from_instance(instance.plant_machinery_service_group,extras=[], type="dict")
    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine and not getattr(instance.plant_machinery_machine, "is_deleted", False):
            return {'id':instance.plant_machinery_machine.id if instance.plant_machinery_machine.id  else None,
                    'machine_number':instance.plant_machinery_machine.machine_number if instance.plant_machinery_machine.machine_number else None ,
                    'equipment_description':instance.plant_machinery_machine.equipment_description if instance.plant_machinery_machine.equipment_description else None
                    }
        return None
    class Meta:
        model = PlantMachineryServiceItem
        fields = '__all__'
class PlantMachineryInactiveTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryInactiveType
        fields = '__all__'
class PlantMachineryObjectiveIndicationTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryObjectiveIndicationType
        fields = '__all__'
class PlantMachineryTruckAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryTruckAccount
        fields = '__all__'

class PlantMachineryTdsTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryTdsType
        fields = '__all__'
        
class PlantMachineryMachineServiceSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryMachineServices
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer    
class PlantMachineryMachineTransferSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryMachineTransfer
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer   
class PlantMachineryMachineDriverSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryMachineDriver
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer     
class PlantMachineryMachineRentSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryMachineRent
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer   

class PlantMachineryMachineDepreciationSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryMachineDepreciation
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer           
class PlantMachineryMachineServiceScheduleSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryMachineServiceSchedule
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer                                    
class PlantMachineryMachineSerializer(serializers.ModelSerializer):
    site_details = serializers.SerializerMethodField()
    # machine_location_details = serializers.SerializerMethodField()
    uom_productivity_details = serializers.SerializerMethodField()
    hsd_norms_uom_details = serializers.SerializerMethodField()
    # plant_machinery_details=serializers.SerializerMethodField()
    plant_machinery_group_details=serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    # owner_tds_type_details = serializers.SerializerMethodField()
    # truck_account_details=serializers.SerializerMethodField()
    # objective_indication_type_details = serializers.SerializerMethodField()

    services = PlantMachineryMachineServiceSerializer(many=True, required=False, source='plant_machinery_machine_plant_machinery_machine_services')
    transfers = PlantMachineryMachineTransferSerializer(many=True, required=False, source='plant_machinery_machine_plant_machinery_machine_transfer')
    drivers = PlantMachineryMachineDriverSerializer(many=True, required=False, source='plant_machinery_machine_plant_machinery_machine_driver')
    rents = PlantMachineryMachineRentSerializer(many=True, required=False, source='plant_machinery_machine_plant_machinery_machine_rent')
    service_schedules = PlantMachineryMachineServiceScheduleSerializer(many=True, required=False, source='plant_machinery_machine_plant_machinery_machine_service_schedule')
    depreciations = PlantMachineryMachineDepreciationSerializer(many=True, required=False, source='plant_machinery_machine_plant_machinery_machine_depreciation')

    def get_site_details(self, instance):
        # site = instance.site
        # if site:
        #     return SiteMaster.cmobjects.filter(pk=site.id).values().first()
        # return None
        site = instance.site
        if site:
            return {"site_name": site.site_name if site.site_name else None}
        return None
    # def get_objective_indication_type_details(self, instance):
    #     details = instance.plant_machinery_objective_indication_type
    #     if details:
    #         return PlantMachineryObjectiveIndicationType.cmobjects.filter(pk=details.id).values().first()
    #     return None
    # def get_machine_location_details(self, instance):
    #     machine_location = instance.machine_location
    #     if machine_location:
    #         return StoreMaster.cmobjects.filter(pk=machine_location.id).values().first()
    #     return None
    # def get_plant_machinery_details(self, instance):
    #     if instance.plant_machinery:
    #         return get_plant_machinery_data(instance.plant_machinery.pk)
    #     return None
    def get_plant_machinery_group_details(self, instance):
        
        if instance.plant_machinery_group and not getattr(instance.plant_machinery_group, "is_deleted", False):
            # print(instance.plant_machinery_group)
            # return PlantMachineryGroup.cmobjects.filter(pk=instance.plant_machinery_group.pk).values().first()
            return {"name": instance.plant_machinery_group.name if instance.plant_machinery_group.name else None,
                    "machine_type":instance.plant_machinery_group.machine_type if instance.plant_machinery_group.machine_type else None}
        return None
    def get_uom_productivity_details(self, instance):
        # uom_detail = None
        # if instance.uom_productivity:
        #     if instance.uom_productivity.id:
        #         uom_detail = UnitOfMesurement.cmobjects.filter(pk=instance.uom_productivity.id).values().first()
        # return uom_detail
        if instance.uom_productivity and not getattr(instance.uom_productivity, "is_deleted", False):
            return {"symbol": instance.uom_productivity.symbol if instance.uom_productivity.symbol else None}
        return None
    def get_hsd_norms_uom_details(self, instance):
        # hsd_norms_uom_detail = None
        # if instance.hsd_norms_uom:
        #     if instance.hsd_norms_uom.id:
        #         hsd_norms_uom_detail = UnitOfMesurement.cmobjects.filter(pk=instance.hsd_norms_uom.id).values().first()
        # return hsd_norms_uom_detail
        if instance.hsd_norms_uom and not getattr(instance.hsd_norms_uom, "is_deleted", False):
                return {"symbol": instance.hsd_norms_uom.symbol if instance.hsd_norms_uom.symbol else None}
        return None
    # def get_owner_tds_type_details(self, instance):
    #     details = None
    #     if instance.owner_tds_type:
    #         if instance.owner_tds_type.id:
    #             details = PlantMachineryTdsType.cmobjects.filter(pk=instance.owner_tds_type.id).values().first()
    #     return details
    # def get_truck_account_details(self, instance):
    #     details = None
    #     if instance.truck_account:
    #         if instance.truck_account.id:
    #             details = PlantMachineryTruckAccount.cmobjects.filter(pk=instance.truck_account.id).values().first()
    #     return details
    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, extras=[], type="dict")

    class Meta:
        model = PlantMachineryMachine
        fields = '__all__'    

    @transaction.atomic
    def create(self, validated_data):
        services_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_services', [])
        transfers_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_transfer', [])
        drivers_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_driver', [])
        rents_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_rent', [])
        depreciations_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_depreciation', [])
        service_schedules_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_service_schedule', [])
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')
        
        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data) if validated_data else None
        else:
            processed_attachment = None
        # processed_attachment = process_attachments(validated_data) if validated_data else None
        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''
        plant_machinery_machine = PlantMachineryMachine.objects.create(**validated_data)
        if processed_attachment:
            plant_machinery_machine.attachment = processed_attachment
            plant_machinery_machine.save()
        current_user = plant_machinery_machine.created_by if plant_machinery_machine.created_by else None
        for service_data in services_data:
            PlantMachineryMachineServices.objects.create(plant_machinery_machine=plant_machinery_machine,\
                                                         created_by=current_user,\
                                                          **service_data)
        for transfer_data in transfers_data:
            processed_attachment = process_attachments(transfer_data) if transfer_data else None


            transfer_data['mime_type'] = '' 
            transfer_data['file_data'] = '' 
            PlantMachineryMachineTransfer.objects.create(
                plant_machinery_machine=plant_machinery_machine,
                created_by=current_user,
                attachment=processed_attachment if processed_attachment else '',
                **transfer_data

            )
        for driver_data in drivers_data:
            PlantMachineryMachineDriver.objects.create(
                plant_machinery_machine=plant_machinery_machine,
                created_by=current_user,
                **driver_data
            )   
        for rent_data in rents_data:
            PlantMachineryMachineRent.objects.create(
                plant_machinery_machine=plant_machinery_machine,
                created_by=current_user,
                **rent_data
            ) 
        for depreciation_data in depreciations_data:
            PlantMachineryMachineDepreciation.objects.create(
                plant_machinery_machine=plant_machinery_machine,
                created_by=current_user,
                **depreciation_data
            )     
        for schedule_data in service_schedules_data:
            PlantMachineryMachineServiceSchedule.objects.create(plant_machinery_machine=plant_machinery_machine, 
            created_by=current_user, 
            **schedule_data)        
        return plant_machinery_machine

    @transaction.atomic
    def update(self, instance, validated_data):
        services_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_services', [])
        transfers_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_transfer', [])
        drivers_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_driver', [])
        rents_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_rent', [])
        depreciations_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_depreciation', [])
        service_schedules_data = validated_data.pop('plant_machinery_machine_plant_machinery_machine_service_schedule', [])

        # Process attachment for the main instance
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data) if validated_data else None
            if processed_attachment:
                instance.attachment = processed_attachment
        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        for field, value in validated_data.items():
            setattr(instance, field, value)
        
       
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        existing_services = instance.plant_machinery_machine_plant_machinery_machine_services.filter(is_deleted=False)
        existing_service_ids = [service.id for service in existing_services]
        new_service_ids = [service_data['id'] for service_data in services_data if 'id' in service_data]

        

        for service_data in services_data:
            if 'id' in service_data and service_data['id'] in existing_service_ids:
                service = PlantMachineryMachineServices.cmobjects.filter(id=service_data['id']).first()
                for attr, value in service_data.items():
                    setattr(service, attr, value)
                service.updated_by = current_user
                service.save()
            else:
                
                PlantMachineryMachineServices.objects.create(
                    plant_machinery_machine=instance,
                    created_by=current_user,
                    **service_data
                )
        for service in existing_services:
            if service.id not in new_service_ids:
                service.is_deleted = True
                service.updated_by = current_user
                service.save()
        ## transer update code        
        existing_transfers = instance.plant_machinery_machine_plant_machinery_machine_transfer.filter(is_deleted=False)
        existing_transfer_ids = [transfer.id for transfer in existing_transfers]
        new_transfer_ids = [transfer_data['id'] for transfer_data in transfers_data if 'id' in transfer_data]

        for transfer_data in transfers_data:
            processed_attachment = process_attachments(transfer_data) if transfer_data else None

            if 'id' in transfer_data and transfer_data['id'] in existing_transfer_ids:
                transfer = PlantMachineryMachineTransfer.cmobjects.filter(id=transfer_data['id']).first()
                for attr, value in transfer_data.items():
                    setattr(transfer, attr, value)
                if processed_attachment:
                    transfer.attachment = processed_attachment
                    transfer.mime_type=''
                    transfer.file_data=''
                    
                transfer.updated_by = current_user
                transfer.save()
            else:
                transfer_data['mime_type'] = '' 
                transfer_data['file_data'] = '' 
                PlantMachineryMachineTransfer.objects.create(
                    plant_machinery_machine=instance,
                    created_by=current_user,
                    attachment=processed_attachment if processed_attachment else '',
                    **transfer_data

                )

        for transfer in existing_transfers:
            if transfer.id not in new_transfer_ids:
                transfer.is_deleted = True
                transfer.updated_by = current_user
                transfer.save()
        #driver        
        existing_drivers = instance.plant_machinery_machine_plant_machinery_machine_driver.filter(is_deleted=False)
        existing_driver_ids = [driver.id for driver in existing_drivers]
        new_driver_ids = [driver_data['id'] for driver_data in drivers_data if 'id' in driver_data]

        for driver_data in drivers_data:
            if 'id' in driver_data and driver_data['id'] in existing_driver_ids:
                driver = PlantMachineryMachineDriver.cmobjects.filter(id=driver_data['id']).first()
                for attr, value in driver_data.items():
                    setattr(driver, attr, value)
                driver.updated_by = current_user
                driver.save()
            else:
                PlantMachineryMachineDriver.objects.create(
                    plant_machinery_machine=instance,
                    created_by=current_user,
                    **driver_data
                )
        for driver in existing_drivers:
            if driver.id not in new_driver_ids:
                driver.is_deleted = True
                driver.updated_by = current_user
                driver.save()
        #rent        
        existing_rents = instance.plant_machinery_machine_plant_machinery_machine_rent.filter(is_deleted=False)
        existing_rent_ids = [rent.id for rent in existing_rents]
        new_rent_ids = [rent_data['id'] for rent_data in rents_data if 'id' in rent_data]

        for rent_data in rents_data:
            if 'id' in rent_data and rent_data['id'] in existing_rent_ids:
                rent = PlantMachineryMachineRent.cmobjects.filter(id=rent_data['id']).first()
                for attr, value in rent_data.items():
                    setattr(rent, attr, value)
                rent.updated_by = current_user
                rent.save()
            else:
                PlantMachineryMachineRent.objects.create(
                    plant_machinery_machine=instance,
                    created_by=current_user,
                    **rent_data
                )
        for rent in existing_rents:
            if rent.id not in new_rent_ids:
                rent.is_deleted = True
                rent.updated_by = current_user
                rent.save()  
        #depreciation        
        existing_depreciations = instance.plant_machinery_machine_plant_machinery_machine_depreciation.filter(is_deleted=False)
        existing_depreciation_ids = [depreciation.id for depreciation in existing_depreciations]
        new_depreciation_ids = [depreciation_data['id'] for depreciation_data in depreciations_data if 'id' in depreciation_data]

        for depreciation_data in depreciations_data:
            if 'id' in depreciation_data and depreciation_data['id'] in existing_depreciation_ids:
                depreciation = PlantMachineryMachineDepreciation.cmobjects.filter(id=depreciation_data['id']).first()
                for attr, value in depreciation_data.items():
                    setattr(depreciation, attr, value)
                depreciation.updated_by = current_user
                depreciation.save()
            else:
                PlantMachineryMachineDepreciation.objects.create(
                    plant_machinery_machine=instance,
                    created_by=current_user,
                    **depreciation_data
                )
        for depreciation in existing_depreciations:
            if depreciation.id not in new_depreciation_ids:
                depreciation.is_deleted = True
                depreciation.updated_by = current_user
                depreciation.save()          
        # Service Schedules
        existing_service_schedules = instance.plant_machinery_machine_plant_machinery_machine_service_schedule.filter(is_deleted=False)
        existing_service_schedule_ids = [schedule.id for schedule in existing_service_schedules]
        new_service_schedule_ids = [schedule_data['id'] for schedule_data in service_schedules_data if 'id' in schedule_data]

        for schedule_data in service_schedules_data:
            if 'id' in schedule_data and schedule_data['id'] in existing_service_schedule_ids:
                schedule = PlantMachineryMachineServiceSchedule.cmobjects.\
                    filter(id=schedule_data['id']).first()
                for attr, value in schedule_data.items():
                    setattr(schedule, attr, value)
                schedule.updated_by = current_user
                schedule.save()
            else:
                PlantMachineryMachineServiceSchedule.objects.create(plant_machinery_machine=instance,
                 created_by=current_user, **schedule_data)

        for schedule in existing_service_schedules:
            if schedule.id not in new_service_schedule_ids:
                schedule.is_deleted = True
                schedule.updated_by = current_user
                schedule.save()      
        return instance
    

class PlantMachineryServiceScheduleSerializer(serializers.ModelSerializer):
    service_group_details = serializers.SerializerMethodField()
    service_item_details = serializers.SerializerMethodField()
    service_unit_details = serializers.SerializerMethodField()
    plant_machinery_group_details = serializers.SerializerMethodField()

    def get_service_group_details(self, instance):
        service_group = instance.plant_machinery_service_group
        if service_group:
            return PlantMachineryServiceGroup.cmobjects.filter(pk=service_group.id).values().first()
        return None

    def get_service_item_details(self, instance):
        # service_item = instance.plant_machinery_service_item
        # if service_item:
        #     return PlantMachineryServiceItem.cmobjects.filter(pk=service_item.id).values().first()
        # return None
        return get_details_from_instance(instance.plant_machinery_service_item,extras=[], type="dict")
    def get_service_unit_details(self, instance):
        # service_unit = instance.service_unit
        # if service_unit:
        #     return UnitOfMesurement.cmobjects.filter(pk=service_unit.id).values().first()
        # return None
        return get_details_from_instance(instance.service_unit,extras=[], type="dict")
    def get_plant_machinery_group_details(self, instance):
        # plant_machinery_group = instance.plant_machinery_group
        # if plant_machinery_group:
        #     return PlantMachineryGroup.cmobjects.filter(pk=plant_machinery_group.id).values().first()
        # return None
        return get_details_from_instance(instance.plant_machinery_group,extras=[], type="dict")
    class Meta:
        model = PlantMachineryServiceSchedule
        fields = '__all__'    


class PlantMachineryMachineMaintenanceItemServiceGroupSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PlantMachineryMachineMaintenanceItemServiceGroup
        fields = '__all__'    
        read_only_fields = ['id']

class PlantMachineryMachineMaintenanceItemGroupSerializer(serializers.ModelSerializer):
    service_group = PlantMachineryMachineMaintenanceItemServiceGroupSerializer(many=True,source="plant_machinery_machine_maintenance_item_group")
    created_by_details = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryMachineMaintenanceItemGroup
        fields = '__all__'    
        
    def get_created_by_details(self, instance):
        _details = None
        if instance.created_by and instance.created_by_id:
            _details = PmsUser.objects.filter(pk=instance.created_by_id).values('first_name', 'last_name', 'email')
        return _details

    @transaction.atomic
    def create(self, validated_data):
        print(validated_data)
        requested_items_data = validated_data.pop('plant_machinery_machine_maintenance_item_group')
        item_group_request = PlantMachineryMachineMaintenanceItemGroup.objects.create(**validated_data)
        current_user = item_group_request.created_by if item_group_request.created_by else None

        for requested_item_data in requested_items_data:
            requested_item = PlantMachineryMachineMaintenanceItemServiceGroup.objects.create(item_group_master=item_group_request, created_by=current_user, **requested_item_data)

        item_group_request.save()
        return item_group_request
    
    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        items_data = validated_data.get('plant_machinery_machine_maintenance_item_group', [])
        print("items_data*******************", items_data)

        existing_items = instance.plant_machinery_machine_maintenance_item_group.filter(is_deleted=False)
        print("existing Items >>>>>>>>>>>>>>>>>>>>>", existing_items)

        for item_data in items_data:
            item_id = item_data.get('id')
            print("item_id", item_id)
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            print("******existing_item", existing_item)
            if not existing_item:
                existing_item = PlantMachineryMachineMaintenanceItemServiceGroup.objects.create(item_group_master=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        instance.save()
        return instance
    
    def to_representation(self, instance):
        representation = super().to_representation(instance)

        requested_items_data = representation.pop('service_group', [])
        representation['service_group'] = requested_items_data
        
        return representation
    

class PlantMachineryJobSheetServiceSerializer(serializers.ModelSerializer):

    id = serializers.IntegerField(required=False)
    plant_machinery_service_item_details = serializers.SerializerMethodField()
    unit_details = serializers.SerializerMethodField()
    
    def get_plant_machinery_service_item_details(self, instance):
        # if instance.plant_machinery_service_item:
        #     return PlantMachineryServiceItem.cmobjects.filter(pk=instance.plant_machinery_service_item.pk).values().first()
        # return None
        return get_details_from_instance(instance.plant_machinery_service_item,extras=[], type="dict")
    
    def get_unit_details(self, instance):
        return get_details_from_instance(instance.unit,extras=[], type="dict")

    class Meta:
        model = PlantMachineryJobSheetService
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer 
class PlantMachineryJobSheetSerializer(serializers.ModelSerializer):
    plant_machinery_machine_details = serializers.SerializerMethodField()
    plant_machinery_group_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    machine_location_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    plant_machinery_service_group_details = serializers.SerializerMethodField()
    services = PlantMachineryJobSheetServiceSerializer(many=True, required=False, source='plant_machinery_job_sheet_plant_machinery_job_sheet_service')

    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine and not getattr(instance.plant_machinery_machine, "is_deleted", False):
            return {'id':instance.plant_machinery_machine.id if instance.plant_machinery_machine.id  else None,
                    'machine_number':instance.plant_machinery_machine.machine_number if instance.plant_machinery_machine.machine_number else None ,
                    'equipment_description':instance.plant_machinery_machine.equipment_description if instance.plant_machinery_machine.equipment_description else None
                    }
        return None
    def get_plant_machinery_group_details(self, instance):
        # if instance.plant_machinery_group:
        #     return PlantMachineryGroup.cmobjects.filter(pk=instance.plant_machinery_group.pk).values().first()
        # return None
        return get_details_from_instance(instance.plant_machinery_group,extras=[], type="dict")

    def get_vendor_details(self, instance):
        # if instance.vendor:
        #     return VendorMasterV2.cmobjects.filter(pk=instance.vendor.pk).values().first()
        # return None
        return get_details_from_instance(instance.vendor,extras=[], type="dict")
    def get_machine_location_details(self, instance):
        # if instance.machine_location:
        #     return StoreMaster.cmobjects.filter(pk=instance.machine_location.pk).values().first()
        # return None
        return get_details_from_instance(instance.machine_location,extras=[], type="dict")
    def get_site_details(self, instance):
        # if instance.site:
        #     return SiteMaster.cmobjects.filter(pk=instance.site.pk).values().first()
        # return None
        return get_details_from_instance(instance.site,extras=[], type="dict")
    def get_plant_machinery_service_group_details(self, instance):
        # if instance.plant_machinery_service_group:
        #     return PlantMachineryServiceGroup.cmobjects.filter(pk=instance.plant_machinery_service_group.pk).values().first()
        # return None
        return get_details_from_instance(instance.plant_machinery_service_group,extras=[], type="dict")
    class Meta:
        model = PlantMachineryJobSheet
        fields = '__all__'
    
    @transaction.atomic
    def create(self, validated_data):
        services_data = validated_data.pop('plant_machinery_job_sheet_plant_machinery_job_sheet_service', [])
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')
        
        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data) if validated_data else None
        else:
            processed_attachment = None
        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''
        jobsheet = PlantMachineryJobSheet.objects.create(**validated_data)
        # jobsheet.jobsheet_number = generate_all_code(jobsheet,['JS'])

        if processed_attachment:
            jobsheet.attachment = processed_attachment
        jobsheet.save()
        current_user = jobsheet.created_by if jobsheet.created_by else None
        for service_data in services_data:
            PlantMachineryJobSheetService.objects.create(
                plant_machinery_job_sheet=jobsheet,
                created_by=current_user,
                **service_data
            )
        return jobsheet

    @transaction.atomic
    def update(self, instance, validated_data):
        services_data = validated_data.pop('plant_machinery_job_sheet_plant_machinery_job_sheet_service', [])
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data) if validated_data else None
            if processed_attachment:
                instance.attachment = processed_attachment
        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        for field, value in validated_data.items():
            setattr(instance, field, value)

        
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        existing_services = instance.plant_machinery_job_sheet_plant_machinery_job_sheet_service.filter(is_deleted=False)
        existing_service_ids = [service.id for service in existing_services]
        new_service_ids = [service_data['id'] for service_data in services_data if 'id' in service_data]

        for service_data in services_data:
            if 'id' in service_data and service_data['id'] in existing_service_ids:
                service = PlantMachineryJobSheetService.cmobjects.filter(id=service_data['id']).first()
                for attr, value in service_data.items():
                    setattr(service, attr, value)
                service.updated_by = current_user
                service.save()
            else:
                PlantMachineryJobSheetService.objects.create(
                    plant_machinery_job_sheet=instance,
                    created_by=current_user,
                    **service_data
                )
        for service in existing_services:
            if service.id not in new_service_ids:
                service.is_deleted = True
                service.updated_by = current_user
                service.save()
        return instance       
    


class PlantMachineryMeterResetLogSerializer(serializers.ModelSerializer):
    plant_machinery_machine_details = serializers.SerializerMethodField()

    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine:
            return PlantMachineryMachine.cmobjects.filter(pk=instance.plant_machinery_machine.id).values().first()
        return None
   
    class Meta:
        model = PlantMachineryMeterResetLog
        fields = '__all__'  


class PlantMachineryTyreSerializer(serializers.ModelSerializer):
    plant_machinery_group_details = serializers.SerializerMethodField()
    brand_details = serializers.SerializerMethodField()
    model_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()
    vendor_master_data = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryTyre
        fields = '__all__'
    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine and not getattr(instance.plant_machinery_machine, "is_deleted", False):
            data = {
                'id': instance.plant_machinery_machine.pk,
                'machine_number': instance.plant_machinery_machine.machine_number,
                'equipment_description': instance.plant_machinery_machine.equipment_description,
            }
           
            return data
        return None
    def get_plant_machinery_group_details(self, instance):
        # if instance.plant_machinery_group:
        #     return PlantMachineryGroup.cmobjects.filter(pk=instance.plant_machinery_group.pk).values().first()
        # return None
        return get_details_from_instance(instance.plant_machinery_group,extras=[], type="dict")
    def get_brand_details(self, instance):
        # if instance.brand:
        #     return Brand.cmobjects.filter(pk=instance.brand.pk).values().first()
        # return None
        return get_details_from_instance(instance.brand,extras=[], type="dict")
    def get_model_details(self, instance):
        # if instance.model:
        #     return Model.cmobjects.filter(pk=instance.model.pk).values().first()
        # return None
        return get_details_from_instance(instance.model,extras=[], type="dict")
   

    def get_vendor_master_data(self, instance):
        return get_details_from_instance(instance.vendor,extras=[], type="dict")
class PlantMachineryLogBookWbsChainageSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    wbs_chainage_details = serializers.SerializerMethodField()
    wbs_details = serializers.SerializerMethodField()
    indirect_chainage_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryLogBookWbsChainage
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    def get_wbs_chainage_details(self, obj):
        if obj.wbs_chainage and not getattr(obj.wbs_chainage, "is_deleted", False):
            return {
                'id': obj.wbs_chainage.id,
                'wbs__wbs': obj.wbs_chainage.wbs.wbs if obj.wbs_chainage.wbs else None,
                'wbs_id': obj.wbs_chainage.wbs_id,
                'wbs__parent_id': obj.wbs_chainage.wbs.parent_id if obj.wbs_chainage.wbs else None,
                'value': obj.wbs_chainage.value,
                'boq': obj.wbs_chainage.boq.id if obj.wbs_chainage.boq else None,
                'form': obj.wbs_chainage.form.id if obj.wbs_chainage.form else None,
                'type': obj.wbs_chainage.type,
                'form__name': obj.wbs_chainage.form.name if obj.wbs_chainage.form else None,
                'form__start': obj.wbs_chainage.form.start if obj.wbs_chainage.form else 0,
                'form__end': obj.wbs_chainage.form.end if obj.wbs_chainage.form else 0,
                'form__chainage_value': obj.wbs_chainage.form.chainage_value if obj.wbs_chainage.form else 0
            }
        return None

    def get_indirect_chainage_details(self, obj):
        if obj.indirect_chainage and not getattr(obj.indirect_chainage, "is_deleted", False): 
            return {
                'id': obj.indirect_chainage.id,
                'indirect_cost': obj.indirect_chainage.indirect_cost if obj.indirect_chainage.indirect_cost is not None else 0,
                'wbs_code': obj.indirect_chainage.wbs_code if obj.indirect_chainage.wbs_code else None,
                'cost_value': obj.indirect_chainage.cost_value if obj.indirect_chainage.cost_value is not None else 0
            }
        return None

    def get_wbs_details(self, obj):
        if obj.wbs and not getattr(obj.wbs, "is_deleted", False):
            return {
                'id': obj.wbs.id,
                'wbs': obj.wbs.wbs if obj.wbs.wbs else None,
                'boq_code': obj.wbs.boq_code if obj.wbs.boq_code else None,
                'boq_no': obj.wbs.boq_no if obj.wbs.boq_no else None,
            }
        return None
class PlantMachineryLogBookSerializer(serializers.ModelSerializer):
    organization_details=serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()
    plant_machinery_group_details = serializers.SerializerMethodField()
    driver_operator_details = serializers.SerializerMethodField()
    # location_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    wbs_chainage = PlantMachineryLogBookWbsChainageSerializer(many=True, source='plant_machinery_log_book_plant_machinery_log_book_wbs_chainage')

    class Meta:
        model = PlantMachineryLogBook
        fields = '__all__'

  
    def get_organization_details(self, instance):
        # key_list = Organization.objects.filter(pk=instance.organization_id).values()
        # _key_list = list(key_list)
       
        # return _key_list
        organization = instance.organization 
        if organization :
            return [{
                "name": organization.name if organization.name else None,
            }]
        return []
    def get_plant_machinery_machine_details(self, instance):
        # if instance.plant_machinery_machine:
    
            # machine = PlantMachineryMachine.cmobjects.filter(pk=instance.plant_machinery_machine.pk)\
            #     .first()
            # if machine:
            #     serializer = PlantMachineryMachineSerializer(machine)
            #     return serializer.data
            # machine = PlantMachineryMachine.objects.filter(pk=instance.plant_machinery_machine.pk)\
            #     .select_related('hsd_norms_uom')\
            #     .values('equipment_number', 'machine_number', 'equipment_description', 'registration_no', 'hsd_norms_uom__formal_name')\
            #     .first()
            # if machine:
            #     machine['hsd_norms_uom_formal_name'] = machine.pop('hsd_norms_uom__formal_name')
            # return machine
            machine = instance.plant_machinery_machine
            if machine and not getattr(machine, "is_deleted", False):
                return {
                    "equipment_number": machine.equipment_number if machine.equipment_number else None,
                    "machine_number": machine.machine_number if machine.machine_number else None,
                    "equipment_description": machine.equipment_description if machine.equipment_description else None,
                    "registration_no": machine.registration_no if machine.registration_no else None,
                    "machine_info_standard_norms_ltr_km": machine.machine_info_standard_norms_ltr_km if machine.machine_info_standard_norms_ltr_km else None,
                    "hsd_norms_uom_formal_name": 
                        machine.hsd_norms_uom.formal_name if machine.hsd_norms_uom and machine.hsd_norms_uom.formal_name else None
                    ,
                }
            return None
        # return None
    def get_plant_machinery_group_details(self, instance):
        group = instance.plant_machinery_machine.plant_machinery_group if instance.plant_machinery_machine else None
        if group and not getattr(group, "is_deleted", False):
            return {"id": group.id if group.id else None, "name": group.name if group.name else None, "machine_type": group.machine_type if group.machine_type else None}
        return None

    def get_driver_operator_details(self, instance):
        driver = instance.driver_operator
        if driver and not getattr(driver, "is_deleted", False):
            return {"name": driver.name if driver.name else None}
        return None

    # def get_location_details(self, instance):
    #     if instance.location:
    #         return StoreMaster.cmobjects.filter(pk=instance.location.pk).values().first()
    #     return None

    def get_site_details(self, instance):
        site = instance.site
        if site and not getattr(site, "is_deleted", False):
            return {"site_name": site.site_name if site.site_name else None}
        return None
    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)
        return None
    @transaction.atomic
    def create(self, validated_data):
        wbs_chainage_data = validated_data.pop('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage', [])

        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')
        
        if file_data and mime_type:
            # Process the attachment if both fields are provided
            processed_attachment = process_attachments(validated_data) if validated_data else None
        else:
            processed_attachment = None
       
        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''
        logbook = PlantMachineryLogBook.objects.create(**validated_data)
        # logbook.request_code = generate_all_code(logbook,['LB'])
        current_user = logbook.created_by if logbook.created_by else None

        for wbs_chainage in wbs_chainage_data:
            PlantMachineryLogBookWbsChainage.objects.create(plant_machinery_log_book=logbook, 
                                                            created_by=current_user,\
                                                             **wbs_chainage)
        
        if processed_attachment:
            logbook.attachment = processed_attachment
        logbook.save()
        return logbook

    @transaction.atomic
    def update(self, instance, validated_data):
        wbs_chainage_data = validated_data.pop('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage', [])

        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            # Process the attachment if both fields are provided
            processed_attachment = process_attachments(validated_data) if validated_data else None
            if processed_attachment:
                instance.attachment = processed_attachment
        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''
        
        for field, value in validated_data.items():
            setattr(instance, field, value)
        instance.save() 
        current_user = instance.updated_by if instance.updated_by else None   
            # Update existing WBS Chainage entries and create new ones
        existing_wbs_chainage = instance.plant_machinery_log_book_plant_machinery_log_book_wbs_chainage.filter(is_deleted=False)
        existing_wbs_chainage_ids = [chainage.id for chainage in existing_wbs_chainage]
        new_wbs_chainage_ids = [chainage['id'] for chainage in wbs_chainage_data if 'id' in chainage]

        for chainage_data in wbs_chainage_data:
            if 'id' in chainage_data and chainage_data['id'] in existing_wbs_chainage_ids:
                chainage_instance = existing_wbs_chainage.get(id=chainage_data['id'])
                for attr, value in chainage_data.items():
                    setattr(chainage_instance, attr, value)
                chainage_instance.updated_by = current_user    
                chainage_instance.save()
            else:
                PlantMachineryLogBookWbsChainage.objects.create(
                    plant_machinery_log_book=instance,created_by=current_user,
                    **chainage_data
                )

        # Mark WBS Chainage entries as deleted if they were removed
        for chainage_id in existing_wbs_chainage_ids:
            if chainage_id not in new_wbs_chainage_ids:
                chainage_instance = existing_wbs_chainage.get(id=chainage_id)
                chainage_instance.is_deleted = True
                chainage_instance.updated_by = current_user
                chainage_instance.save()

        instance.save()
        return instance


class PlantMachineryInsuranceMasterSerializer(serializers.ModelSerializer):
    plant_machinery_machine_details= serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryInsuranceMaster
        fields = '__all__'    
   
    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine and not getattr(instance.plant_machinery_machine, "is_deleted", False) :
            data = {
                'id': instance.plant_machinery_machine.pk,
                'machine_number': instance.plant_machinery_machine.machine_number,
                'equipment_description': instance.plant_machinery_machine.equipment_description,
                'plant_machinery_group__id': instance.plant_machinery_machine.plant_machinery_group.pk if instance.plant_machinery_machine.plant_machinery_group else None,
                'plant_machinery_group__name': instance.plant_machinery_machine.plant_machinery_group.name if instance.plant_machinery_machine.plant_machinery_group else None,
            }
           
            return data
        return None

class PlantMachineryMachineWorkingMeterResetSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryMachineWorkingMeterReset
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer   

class PlantMachineryMachineWorkingFuelIssueSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryMachineWorkingFuelIssue
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer   

class PlantMachineryMachineWorkingChildSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    driver_operator_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryMachineWorkingChild
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
    def get_driver_operator_details(self, instance):
        # details = instance.driver_operator
        # if details:
        #     return PlantMachineryMachineDriver.objects.filter(pk=details.id).values().first()
        # return None  
        return get_details_from_instance(instance.driver_operator,extras=[], type="dict") 
class PlantMachineryMachineWorkingIdleBdSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    driver_operator_details = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryMachineWorkingIdleBd
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
    def get_driver_operator_details(self, instance):
        # details = instance.driver_operator
        # if details:
        #     return PlantMachineryMachineDriver.cmobjects.filter(pk=details.id).values().first()
        # return None    
        return get_details_from_instance(instance.driver_operator,extras=[], type="dict") 

class PlantMachineryMachineWorkingSerializer(serializers.ModelSerializer):
    plant_machinery_machine_details = serializers.SerializerMethodField()
    plant_machinery_group_details =serializers.SerializerMethodField()
    machine_location_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    meter_resets = PlantMachineryMachineWorkingMeterResetSerializer(many=True, required=False, source='plant_machinery_machine_working_plant_machinery_machine_working_meter_reset')
    fuel_issues = PlantMachineryMachineWorkingFuelIssueSerializer(many=True, required=False, source='plant_machinery_machine_working_plant_machinery_machine_working_fuel_issue')
    working_child = PlantMachineryMachineWorkingChildSerializer(many=True, required=False, source='plant_machinery_machine_working_plant_machinery_machine_working_child')
    idle_bds = PlantMachineryMachineWorkingIdleBdSerializer(many=True, required=False, source='plant_machinery_machine_working_plant_machinery_machine_working_idle_bd')  
    class Meta:
        model = PlantMachineryMachineWorking
        fields = '__all__'
    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine :
            return PlantMachineryMachine.cmobjects.filter(pk=instance.plant_machinery_machine.id).values().first()
        return None
    def get_site_details(self, instance):
        site = instance.site
        if site:
            return SiteMaster.cmobjects.filter(pk=site.id).values().first()
        return None

    def get_machine_location_details(self, instance):
        machine_location = instance.machine_location
        if machine_location:
            return StoreMaster.cmobjects.filter(pk=machine_location.id).values().first()
        return None
   
    def get_plant_machinery_group_details(self, instance):
        
        if instance.plant_machinery_group:
            print(instance.plant_machinery_group)
            return PlantMachineryGroup.cmobjects.filter(pk=instance.plant_machinery_group.pk).values().first()
        return None
    

    @transaction.atomic
    def create(self, validated_data):
        meter_reset_data = validated_data.pop('plant_machinery_machine_working_plant_machinery_machine_working_meter_reset', [])
        fuel_issues_data = validated_data.pop('plant_machinery_machine_working_plant_machinery_machine_working_fuel_issue', [])
        working_child_data = validated_data.pop('plant_machinery_machine_working_plant_machinery_machine_working_child', [])
        idle_bds_data = validated_data.pop('plant_machinery_machine_working_plant_machinery_machine_working_idle_bd', []) 

        mime_type = validated_data.get('mime_type', '')
        file_data = validated_data.get('file_data', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data) if validated_data else None
        else:
            processed_attachment = None

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        plant_machinery_machine_working = PlantMachineryMachineWorking.objects.create(**validated_data)

        if processed_attachment:
            plant_machinery_machine_working.attachment = processed_attachment
            plant_machinery_machine_working.save()

        current_user = plant_machinery_machine_working.created_by if plant_machinery_machine_working.created_by else None

        for meter_reading_data in meter_reset_data:
            PlantMachineryMachineWorkingMeterReset.objects.create(
                plant_machinery_machine_working=plant_machinery_machine_working,
                created_by=current_user,
                **meter_reading_data
            )
        
        for fuel_issue_data in fuel_issues_data:
            PlantMachineryMachineWorkingFuelIssue.objects.create(
                plant_machinery_machine_working=plant_machinery_machine_working,
                created_by=current_user,
                **fuel_issue_data
            )
        
        for child_data in working_child_data:
            PlantMachineryMachineWorkingChild.objects.create(
                plant_machinery_machine_working=plant_machinery_machine_working,
                created_by=current_user,
                **child_data
            )
        for idle_bd_data in idle_bds_data:
            PlantMachineryMachineWorkingIdleBd.objects.create(
                plant_machinery_machine_working=plant_machinery_machine_working,
                created_by=current_user,
                **idle_bd_data
            )
        
        return plant_machinery_machine_working

    @transaction.atomic
    def update(self, instance, validated_data):
        meter_reset_data = validated_data.pop('plant_machinery_machine_working_plant_machinery_machine_working_meter_reset', [])
        fuel_issues_data = validated_data.pop('plant_machinery_machine_working_plant_machinery_machine_working_fuel_issue', [])
        working_child_data = validated_data.pop('plant_machinery_machine_working_plant_machinery_machine_working_child', [])
        idle_bds_data = validated_data.pop('plant_machinery_machine_working_plant_machinery_machine_working_idle_bd', []) 

        mime_type = validated_data.get('mime_type', '')
        file_data = validated_data.get('file_data', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data) if validated_data else None
        else:
            processed_attachment = None

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        for field, value in validated_data.items():
            setattr(instance, field, value)
        instance.save()

        if processed_attachment:
            instance.attachment = processed_attachment
            instance.save()

        current_user = instance.updated_by if instance.updated_by else None

       
        existing_meter_reset= instance.plant_machinery_machine_working_plant_machinery_machine_working_meter_reset.filter(is_deleted=False)
        existing_meter_reset_ids = [data.id for data in existing_meter_reset]
        new_meter_reset_ids = [data['id'] for data in meter_reset_data if 'id' in data]
        for data in meter_reset_data:
            if 'id' in data and data['id'] in existing_meter_reset_ids:
                meter_reset_instance = PlantMachineryMachineWorkingMeterReset.cmobjects.filter(id=data['id']).first()
                for attr, value in data.items():
                    setattr(meter_reset_instance, attr, value)
                meter_reset_instance.updated_by = current_user
                meter_reset_instance.save()
            else:
                PlantMachineryMachineWorkingMeterReset.objects.create(
                    plant_machinery_machine_working=instance,
                    created_by=current_user,
                    **data
                )
        
        for meter_reset_id in existing_meter_reset_ids:
            if meter_reset_id not in new_meter_reset_ids:
                meter_reset_instance = PlantMachineryMachineWorkingMeterReset.cmobjects.filter(id=meter_reset_id).first()
                meter_reset_instance.is_deleted = True
                meter_reset_instance.updated_by = current_user
                meter_reset_instance.save()
        # Handling fuel_issues_data
        
        existing_fuel_issue= instance.plant_machinery_machine_working_plant_machinery_machine_working_fuel_issue.filter(is_deleted=False)
        existing_fuel_issue_ids = [data.id for data in existing_fuel_issue]
        new_fuel_issue_ids = [data['id'] for data in fuel_issues_data if 'id' in data]
        for data in fuel_issues_data:
            if 'id' in data and data['id'] in existing_fuel_issue_ids:
                fuel_issue_instance = PlantMachineryMachineWorkingFuelIssue.cmobjects.filter(id=data['id']).first()
                for attr, value in data.items():
                    setattr(fuel_issue_instance, attr, value)
                fuel_issue_instance.updated_by = current_user
                fuel_issue_instance.save()
            else:
                PlantMachineryMachineWorkingFuelIssue.objects.create(
                    plant_machinery_machine_working=instance,
                    created_by=current_user,
                    **data
                )
        
        for fuel_issue_id in existing_fuel_issue_ids:
            if fuel_issue_id not in new_fuel_issue_ids:
                fuel_issue_instance = PlantMachineryMachineWorkingFuelIssue.cmobjects.filter(id=fuel_issue_id).first()
                fuel_issue_instance.is_deleted = True
                fuel_issue_instance.updated_by = current_user
                fuel_issue_instance.save()

        # Handling working_child_data
       
        
        existing_child= instance.plant_machinery_machine_working_plant_machinery_machine_working_child.filter(is_deleted=False)
        existing_child_ids = [data.id for data in existing_child]
        new_child_ids = [data['id'] for data in working_child_data if 'id' in data]
        for data in working_child_data:
            if 'id' in data and data['id'] in existing_child_ids:
                child_instance = PlantMachineryMachineWorkingChild.cmobjects.filter(id=data['id']).first()
                for attr, value in data.items():
                    setattr(child_instance, attr, value)
                child_instance.updated_by = current_user
                child_instance.save()
            else:
                PlantMachineryMachineWorkingChild.objects.create(
                    plant_machinery_machine_working=instance,
                    created_by=current_user,
                    **data
                )
        
        for child_id in existing_child_ids:
            if child_id not in new_child_ids:
                child_instance = PlantMachineryMachineWorkingChild.cmobjects.filter(id=child_id).first()
                child_instance.is_deleted = True
                child_instance.updated_by = current_user
                child_instance.save()
        ## handle idle bd        
       
        existing_idle_bd = instance.plant_machinery_machine_working_plant_machinery_machine_working_idle_bd.filter(is_deleted=False)
        existing_idle_bd_ids = [data.id for data in existing_idle_bd]
        new_idle_bd_ids = [data['id'] for data in idle_bds_data if 'id' in data]
        for data in idle_bds_data:
            if 'id' in data and data['id'] in existing_idle_bd_ids:
                idle_bd_instance = PlantMachineryMachineWorkingIdleBd.cmobjects.filter(id=data['id']).first()
                for attr, value in data.items():
                    setattr(idle_bd_instance, attr, value)
                idle_bd_instance.updated_by = current_user
                idle_bd_instance.save()
            else:
                PlantMachineryMachineWorkingIdleBd.objects.create(
                    plant_machinery_machine_working=instance,
                    created_by=current_user,
                    **data
                )
        
        for idle_bd_id in existing_idle_bd_ids:
            if idle_bd_id not in new_idle_bd_ids:
                idle_bd_instance = PlantMachineryMachineWorkingIdleBd.cmobjects.filter(id=idle_bd_id).first()
                idle_bd_instance.is_deleted = True
                idle_bd_instance.updated_by = current_user
                idle_bd_instance.save()

        return instance
    
class PlantMachineryManpowerSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryManpower
        fields = '__all__'


class PlantMachineryActivityGroupItemsSerializer(serializers.ModelSerializer):
    """
    Plant Machinery Activity Group Items Serializer
    """
    id = serializers.IntegerField(required=False)
    plant_machinery_machine_details = serializers.SerializerMethodField()
    plant_machinery_group_details = serializers.SerializerMethodField()
    uom_details=serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryActivityGroupItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
    def get_plant_machinery_machine_details(self, instance):
        details = {}
        try:
            if instance.plant_machinery_machine and instance.plant_machinery_machine.id:
                
                details = PlantMachineryMachine.cmobjects.filter(pk=instance.plant_machinery_machine.id).values().first()
                
                # serializer = PlantMachineryMachineSerializer(machine_details)
                # details = serializer.data
        except Exception as e:
            pass
        return details
    def get_plant_machinery_group_details(self, instance):
        details = {}
        try:
            if instance.plant_machinery_group and instance.plant_machinery_group.id:
                
                details = PlantMachineryGroup.cmobjects.filter(pk=instance.plant_machinery_group.id).values().first()
                
                # serializer = PlantMachineryMachineSerializer(machine_details)
                # details = serializer.data
        except Exception as e:
            pass
        return details
    def get_uom_details(self, instance):
        # if instance.uom:
        #     if instance.uom.id:
        #         return  UnitOfMesurement.cmobjects.filter(pk=instance.uom.id).values().first()
        # return None 
        return get_details_from_instance(instance.uom,extras=[], type="dict")


class PlantMachineryActivityGroupItemsSerializer2(serializers.ModelSerializer):
    """
    Plant Machinery Activity Group Items Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PlantMachineryActivityGroupItems
        fields = '__all__'
        read_only_fields = ['id']

class PlantMachineryActivityGroupSerializer(serializers.ModelSerializer):
    """
    Plant Machinery Activity Group Serializer
    """
    plant_machinery_activity_group_items = PlantMachineryActivityGroupItemsSerializer(many=True, required=False, source='plant_machinery_activity_group_plant_machinery_activity_group_items')

    class Meta:
        model = PlantMachineryActivityGroup
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        activity_group_items_data = validated_data.pop('plant_machinery_activity_group_plant_machinery_activity_group_items', [])
        
        activity_group = PlantMachineryActivityGroup.objects.create(**validated_data)
        current_user = activity_group.created_by if activity_group.created_by else None

        for item_data in activity_group_items_data:
            PlantMachineryActivityGroupItems.objects.create(plant_machinery_activity_group=activity_group, created_by=current_user, **item_data)

        return activity_group

    @transaction.atomic
    def update(self, instance, validated_data):
        activity_group_items_data = validated_data.pop('plant_machinery_activity_group_plant_machinery_activity_group_items', [])
        

        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None
        existing_items = instance.plant_machinery_activity_group_plant_machinery_activity_group_items.filter(is_deleted=False)

        for item_data in activity_group_items_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            if not existing_item:
                PlantMachineryActivityGroupItems.objects.create(plant_machinery_activity_group=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in activity_group_items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        return instance

    # def to_representation(self, instance):
    #     representation = super().to_representation(instance)
    #     items_data = representation.pop('plant_machinery_activity_group_items', [])
    #     representation['plant_machinery_activity_group_items'] = items_data
    #     return representation

class PlantMachineryServiceScheduleNewChildSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    plant_machinery_service_item_details=serializers.SerializerMethodField()
    unit_details=serializers.SerializerMethodField()
    
    def get_plant_machinery_service_item_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_service_item,extras=[], type="dict")
    
    def get_unit_details(self, instance):
        return get_details_from_instance(instance.unit,extras=[], type="dict")

    class Meta:
        model = PlantMachineryServiceScheduleNewChild
        fields = '__all__'
        read_only_fields = ['id']    
        list_serializer_class = CommonFilterListSerializer


class PlantMachineryServiceScheduleNewSerializer(serializers.ModelSerializer):
    plant_machinery_service_schedule_new_child = PlantMachineryServiceScheduleNewChildSerializer(
        many=True, required=False, source="plant_machinery_service_schedule_plant_machinery_service_schedule_new_child")
    plant_machinery_machine_details=serializers.SerializerMethodField()
    plant_machinery_group_details=serializers.SerializerMethodField()
    plant_machinery_service_group_details=serializers.SerializerMethodField()
    vendor_master_data=serializers.SerializerMethodField()
    
    def get_plant_machinery_machine_details(self, instance):
      
        return get_details_from_instance(instance.plant_machinery_machine,extras=[], type="dict")
    
    def get_plant_machinery_group_details(self, instance):
      
        return get_details_from_instance(instance.plant_machinery_group,extras=[], type="dict")
    
    def get_plant_machinery_service_group_details(self, instance):
      
        return get_details_from_instance(instance.plant_machinery_service_group,extras=[], type="dict")

    def get_vendor_master_data(self, instance):
        _details = None
        try:
            if instance.vendor and not getattr(instance.vendor, "is_deleted", False):
                data = get_vendor_data(instance.vendor)
                _details = {"vendor_id": instance.vendor.pk, "data": data}
        except Exception as e:
            print('ERROR', e)
        return _details
    class Meta:
        model = PlantMachineryServiceScheduleNew
        fields = '__all__'
    
    @transaction.atomic
    def create(self, validated_data):
        children_data = validated_data.pop('plant_machinery_service_schedule_plant_machinery_service_schedule_new_child', [])
        service_schedule = PlantMachineryServiceScheduleNew.objects.create(**validated_data)
        current_user = service_schedule.created_by if service_schedule.created_by else None

        for child_data in children_data:
            PlantMachineryServiceScheduleNewChild.objects.create(
                plant_machinery_service_schedule=service_schedule, created_by=current_user,**child_data
            )
        
        return service_schedule

    @transaction.atomic
    def update(self, instance, validated_data):
        children_data = validated_data.pop('plant_machinery_service_schedule_plant_machinery_service_schedule_new_child', [])
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        existing_children = instance.plant_machinery_service_schedule_plant_machinery_service_schedule_new_child.filter(is_deleted=False)

        for child_data in children_data:
            child_id = child_data.get('id')
            existing_child = next((child for child in existing_children if child.id == child_id), None)
            if not existing_child:
                PlantMachineryServiceScheduleNewChild.objects.create(
                    plant_machinery_service_schedule=instance, **child_data,created_by=current_user
                )
            else:
                for field in existing_child._meta.fields:
                    field_name = field.name
                    if field_name in child_data:
                        setattr(existing_child, field_name, child_data[field_name])
                setattr(existing_child, 'updated_by', current_user)

                existing_child.save()

        for existing_child in existing_children:
            if existing_child.id not in [data.get('id') for data in children_data]:
                setattr(existing_child, 'is_deleted', True)
                setattr(existing_child, 'updated_by', current_user)
                existing_child.save()

        return instance


class PlantMachineryNotificationsSerializer(serializers.ModelSerializer):
    def to_representation(self, instance):
        return {
            'id': instance.id,
            'ref_type': instance.ref_type,
            'ref_id': instance.ref_id,
            'data': instance.data,
            'seen': instance.seen,
        }
    class Meta:
        model = PlantMachineryNotifications
        fields = '__all__'


class PlantMachineryMISSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryMIS
        fields = '__all__'


class PlantMachineryHireBillSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlantMachineryHireBill
        fields = '__all__'
    @transaction.atomic
    def create(self, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
        else:
            processed_attachment = None

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        hire_bill_entry = PlantMachineryHireBill.objects.create(**validated_data)

        if processed_attachment:
            hire_bill_entry.attachment = processed_attachment
        hire_bill_entry.save()

        return hire_bill_entry

    @transaction.atomic
    def update(self, instance, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
            if processed_attachment:
                instance.attachment = processed_attachment

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        for field, value in validated_data.items():
            setattr(instance, field, value)

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        return representation

class PlantMachineryBatterySerializer(serializers.ModelSerializer):
    organization_details = serializers.SerializerMethodField()
    plant_machinery_group_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()
    brand_details = serializers.SerializerMethodField()
    model_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryBattery
        fields = '__all__'

    def get_organization_details(self, instance):
        return get_details_from_instance(instance.organization, extras=[], type="dict")

    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group, extras=[], type="dict")

    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine and not getattr(instance.plant_machinery_machine, "is_deleted", False):
            return {
                'id': instance.plant_machinery_machine.pk,
                'machine_number': instance.plant_machinery_machine.machine_number,
                'equipment_description': instance.plant_machinery_machine.equipment_description,
            }
        return None

    def get_brand_details(self, instance):
        return get_details_from_instance(instance.brand, extras=[], type="dict")

    def get_model_details(self, instance):
        return get_details_from_instance(instance.model, extras=[], type="dict")

    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, extras=[], type="dict")



class PlantMachineryComplianceMasterDetailSerializer(serializers.ModelSerializer):
    """
    Serializer for PlantMachineryComplianceMasterDetail
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryComplianceMasterDetail
        fields = '__all__'
        read_only_fields = ['id']    
        list_serializer_class = CommonFilterListSerializer

class PlantMachineryComplianceMasterSerializer(serializers.ModelSerializer):
    """
    Serializer for PlantMachineryComplianceMaster and its child table details
    """
   
      
    compliance_master_details = PlantMachineryComplianceMasterDetailSerializer(
        many=True, required=False, source="compliance_master_plant_machinery_compliance_master_detail"
    )

    class Meta:
        model = PlantMachineryComplianceMaster
        fields = '__all__'
       
    @transaction.atomic
    def create(self, validated_data):
        details_data = validated_data.pop('compliance_master_plant_machinery_compliance_master_detail', [])
        compliance_master = PlantMachineryComplianceMaster.objects.create(**validated_data)
        current_user = compliance_master.created_by if compliance_master.created_by else None

        for detail_data in details_data:
            PlantMachineryComplianceMasterDetail.objects.create(
                compliance_master=compliance_master, created_by=current_user, **detail_data
            )

        return compliance_master

    @transaction.atomic
    def update(self, instance, validated_data):
        details_data = validated_data.pop('compliance_master_plant_machinery_compliance_master_detail', [])
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        current_user = instance.updated_by if instance.updated_by else None

        existing_details = instance.compliance_master_plant_machinery_compliance_master_detail.filter(is_deleted=False)

        for detail_data in details_data:
            detail_id = detail_data.get('id')
            existing_detail = next((detail for detail in existing_details if detail.id == detail_id), None)
            if not existing_detail:
                PlantMachineryComplianceMasterDetail.objects.create(
                    compliance_master=instance, **detail_data, created_by=current_user
                )
            else:
                for field in existing_detail._meta.fields:
                    field_name = field.name
                    if field_name in detail_data:
                        setattr(existing_detail, field_name, detail_data[field_name])
                setattr(existing_detail, 'updated_by', current_user)
                existing_detail.save()

        for existing_detail in existing_details:
            if existing_detail.id not in [data.get('id') for data in details_data]:
                setattr(existing_detail, 'is_deleted', True)
                setattr(existing_detail, 'updated_by', current_user)
                existing_detail.save()

        return instance
class PlantMachineryComplianceMasterNewSerializer(serializers.ModelSerializer):
    site_details=serializers.SerializerMethodField()

    def get_site_details(self, instance):
        return get_details_from_instance(instance.site)
    class Meta:
        model = PlantMachineryComplianceMasterNew
        fields = "__all__"
    
class PlantMachineryComplianceReportItemSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    vendor_details=serializers.SerializerMethodField()
    compliance_master_detail_data=serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryComplianceReportItem
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

    # def get_vendor_details(self, instance):
    #     return get_details_from_instance(instance.vendor, extras=[], type="dict")
    def get_compliance_master_detail_data(self, instance):
        _details = {}
        try:
            if instance.compliance_master_detail and not getattr(instance.compliance_master_detail, "is_deleted", False):
               
                _details = {"id":instance.compliance_master_detail.id,
                    "name": instance.compliance_master_detail.name if instance.compliance_master_detail else None}  
        except Exception as e:
            print('ERROR:', e)
        return _details
    def get_vendor_details(self, instance):
        vendor_details = {}
        try:
            if instance.vendor_id and not getattr(instance.vendor, "is_deleted", False):
               
                vendor_details = {"id":instance.vendor.id,
                    "vendor_name": instance.vendor.vendor_name if instance.vendor else None}  
        except Exception as e:
            print('ERROR:', e)
        return vendor_details

class PlantMachineryComplianceReportSerializer(serializers.ModelSerializer):
    compliance_items = PlantMachineryComplianceReportItemSerializer(
        many=True,
        required=False,
        source='compilance_report_plant_machinery_compliance_report_item'
    )
    plant_machinery_machine_details = serializers.SerializerMethodField()
    compilance_master_data= serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryComplianceReport
        fields = '__all__'

    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine and not getattr(instance.plant_machinery_machine, "is_deleted", False):
            return {
                'id': instance.plant_machinery_machine.pk,
                'machine_number': instance.plant_machinery_machine.machine_number,
                'equipment_description': instance.plant_machinery_machine.equipment_description,
            }
        return None
    def get_compilance_master_data(self, instance):
        if instance.compliance_master and not getattr(instance.compliance_master, "is_deleted", False):
            return {
                'id': instance.compliance_master.pk,
                'name': instance.compliance_master.name,
            }
        return None

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('compilance_report_plant_machinery_compliance_report_item', [])
        compliance_report = PlantMachineryComplianceReport.objects.create(**validated_data)
        current_user = compliance_report.created_by if compliance_report.created_by else None

        for item_data in items_data:
            processed_attachment = process_attachments(item_data)
            item_data.pop('mime_type', None)
            item_data.pop('file_data', None)
            PlantMachineryComplianceReportItem.objects.create(
                **item_data,
                compliance_report=compliance_report,
                attachment=processed_attachment if processed_attachment else None,
                created_by=current_user,
                mime_type= '',
                file_data='',
            )
        return compliance_report

    @transaction.atomic
    def update(self, instance, validated_data):
        items_data = validated_data.pop('compilance_report_plant_machinery_compliance_report_item', [])
        
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        current_user = instance.updated_by if instance.updated_by else None
        existing_items = instance.compilance_report_plant_machinery_compliance_report_item.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            processed_attachment = process_attachments(item_data)

            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if existing_item:
                # Update existing item
                for attr, value in item_data.items():
                    setattr(existing_item, attr, value)
                if processed_attachment:
                    existing_item.attachment = processed_attachment
                    existing_item.file_data=""
                    existing_item.mime_type=""
                existing_item.updated_by = current_user
                existing_item.save()
            else:
                item_data.pop('mime_type', None)
                item_data.pop('file_data', None)
                PlantMachineryComplianceReportItem.objects.create(
                    **item_data,
                    compliance_report=instance,
                    attachment=processed_attachment if processed_attachment else None,
                    created_by=current_user,
                    mime_type='',
                    file_data='',
                )

        for existing_item in existing_items:
            if existing_item.id not in [item.get('id') for item in items_data]:
                existing_item.is_deleted = True
                existing_item.updated_by = current_user
                existing_item.save()

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['compliance_items'] = representation.pop('compliance_items', [])
        return representation


class PlantMachineryCallibrationReportSerializer(serializers.ModelSerializer):
    vendor_details = serializers.SerializerMethodField()
    plant_machinery_machine_details=serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryCallibrationReport
        fields = '__all__'

    def get_plant_machinery_machine_details(self, instance):
        if instance.plant_machinery_machine and not getattr(instance.plant_machinery_machine, "is_deleted", False):
            return {
                'id': instance.plant_machinery_machine.pk,
                'machine_number': instance.plant_machinery_machine.machine_number,
                'equipment_description': instance.plant_machinery_machine.equipment_description,
            }
        return None

    def get_vendor_details(self, instance):
        vendor_details = {}
        try:
            if instance.vendor_id and not getattr(instance.vendor, "is_deleted", False):
               
                vendor_details = {"id":instance.vendor.id,
                    "vendor_name": instance.vendor.vendor_name if instance.vendor else None}  
        except Exception as e:
            print('ERROR:', e)
        return vendor_details
    # Custom create method
    @transaction.atomic
    def create(self, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
        else:
            processed_attachment = None

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        callibration = PlantMachineryCallibrationReport.objects.create(**validated_data)

        if processed_attachment:
            callibration.attachment = processed_attachment
        callibration.save()

        return callibration

    @transaction.atomic
    def update(self, instance, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
            if processed_attachment:
                instance.attachment = processed_attachment

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        for field, value in validated_data.items():
            setattr(instance, field, value)

        instance.save()
        return instance
    


class PlantMachineryFuelTransactionSerializer(serializers.ModelSerializer):
    """
    Serializer for PlantMachineryFuelTransaction
    """
    project_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryFuelTransaction
        fields = '__all__'
    
    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)
        return None
    
class PlantMachineryBudgetMasterSerializer(serializers.ModelSerializer):
    """
    Serializer for PlantMachineryBudgetMaster
    """
    project_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryBudgetMaster
        fields = '__all__'

    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)  
        return None

class PlantMachineryMachineBudgetSerializer(serializers.ModelSerializer):
    """
    Serializer for PlantMachineryMachineBudget
    """
    project_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()
    plant_machinery_group_details = serializers.SerializerMethodField()
    budget_master_details = serializers.SerializerMethodField()
    actual_cost_details = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryMachineBudget
        fields = '__all__'
    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group,extras=[], type="dict")

    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)  
        return None

    def get_plant_machinery_machine_details(self, instance):
        
        machine = instance.plant_machinery_machine
        if machine and not getattr(machine, "is_deleted", False):
            return {
                "equipment_number": machine.equipment_number if machine.equipment_number else None,
                "machine_number": machine.machine_number if machine.machine_number else None,
                "equipment_description": machine.equipment_description if machine.equipment_description else None,
                "registration_no": machine.registration_no if machine.registration_no else None,
                'plant_machinery_group__id': instance.plant_machinery_machine.plant_machinery_group.pk if instance.plant_machinery_machine.plant_machinery_group else None,
                'plant_machinery_group__name': instance.plant_machinery_machine.plant_machinery_group.name if instance.plant_machinery_machine.plant_machinery_group else None,

            
            }
        return None

    def get_budget_master_details(self, instance):
      
        return get_details_from_instance( instance.budget_master,extras=[], type="dict")
    
   
    def get_actual_cost_details(self, instance):
        if (instance.project and not getattr(instance.project, "is_deleted", False) and instance.plant_machinery_group and not getattr(instance.plant_machinery_group, "is_deleted", False)):
            plant_machinery_group_id = instance.plant_machinery_group.id
            project_id = instance.project.id

            actual_cost_query = PlantMachineryLogBook.cmobjects.filter(
                project_id=project_id,
                plant_machinery_machine__is_active=True,
                plant_machinery_machine__is_deleted=False,
                plant_machinery_machine__plant_machinery_group__is_deleted=False,
                plant_machinery_machine__plant_machinery_group_id=plant_machinery_group_id
            ).exclude(in_service='Breakdown').values('plant_machinery_machine','log_book_date').annotate(
                log_book_count=Count('log_book_date', distinct=True),
                # rent_amount=Coalesce(Sum(
                #     Subquery(
                #         PlantMachineryMachineRent.cmobjects.filter(
                #             rent_date__lte=OuterRef('log_book_date'),
                #             rent_to_date__gte=OuterRef('log_book_date'),
                #             plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                #         ).order_by('-rent_to_date').values('rent_amount')[:1]
                #     )),
                #     Value(0, output_field=FloatField())
                # ),
                rent_amount=Coalesce(
                    Subquery(
                        PlantMachineryMachineRent.cmobjects.filter(
                            rent_date__lte=OuterRef('log_book_date'),
                            rent_to_date__gte=OuterRef('log_book_date'),
                            plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                        )
                        .values('rent_date','plant_machinery_machine_id',)
                        .annotate(total=Sum('rent_amount'))
                        .values('total')[:1]
                    ),
                    Value(0, output_field=FloatField())
                ),
                actual_cost=F('log_book_count') * F('rent_amount')
            )
            
           
            if actual_cost_query:
                return actual_cost_query
        return []
        
class PlantMachineryElectricityBudgetSerializer(serializers.ModelSerializer):
    """
    Serializer for PlantMachineryElectricityBudget
    """
    project_details = serializers.SerializerMethodField()
    budget_master_details = serializers.SerializerMethodField()
    actual_cost_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryElectricityBudget
        fields = '__all__'

    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id) 
        return None

    def get_budget_master_details(self, instance):
        return get_details_from_instance(instance.budget_master, extras=[], type="dict")
    
    def get_actual_cost_details(self, instance):
        if instance.project and not getattr(instance.project, "is_deleted", False):
            return PlantMachineryElectricityEntry.cmobjects.\
                filter(project_id=instance.project.id,date=instance.date).values()
        return None
class PlantMachineryFuelBudgetSerializer(serializers.ModelSerializer):
    """
    Serializer for PlantMachineryFuelBudget
    """
    project_details = serializers.SerializerMethodField()
    budget_master_details = serializers.SerializerMethodField()
    actual_cost_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryFuelBudget
        fields = '__all__'

    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)  
        return None

    def get_budget_master_details(self, instance):
        return get_details_from_instance(instance.budget_master, extras=[], type="dict") 
    
    def get_actual_cost_details(self, instance):
        if instance.project and instance.fuel_type:
            actual_cost_query = PlantMachineryLogBook.cmobjects.filter(
                project_id=instance.project.id,
                fueltype=('diesel' if instance.fuel_type == 'HSD' else 'petrol'),
            ).values('project').annotate(
                actual_cost=Coalesce(Sum('total_fuel_filled'), Value(0), output_field=FloatField()),
            )
            if actual_cost_query:
                return actual_cost_query
        return []


# class PlantMachineryElectricityEntrySerializer(serializers.ModelSerializer):
#     project_details = serializers.SerializerMethodField()

#     class Meta:
#         model = PlantMachineryElectricityEntry
#         fields = '__all__'

#     def get_project_details(self, instance):
#         project = instance.project
#         if project:
#             return get_project_data(instance.project.id)  
#         return None

#     @transaction.atomic
#     def create(self, validated_data):
#         file_data = validated_data.get('file_data', '')
#         mime_type = validated_data.get('mime_type', '')

#         if file_data and mime_type:
#             processed_attachment = process_attachments(validated_data)
#         else:
#             processed_attachment = None

#         validated_data['mime_type'] = ''
#         validated_data['file_data'] = ''

#         electricity_entry = PlantMachineryElectricityEntry.objects.create(**validated_data)

#         if processed_attachment:
#             electricity_entry.attachment = processed_attachment
#         electricity_entry.save()

#         return electricity_entry

#     @transaction.atomic
#     def update(self, instance, validated_data):
#         file_data = validated_data.get('file_data', '')
#         mime_type = validated_data.get('mime_type', '')

#         if file_data and mime_type:
#             processed_attachment = process_attachments(validated_data)
#             if processed_attachment:
#                 instance.attachment = processed_attachment

#         validated_data['mime_type'] = ''
#         validated_data['file_data'] = ''

#         for field, value in validated_data.items():
#             setattr(instance, field, value)

#         instance.save()
#         return instance

class PlantMachineryElectricityEntryAttachmentSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)  
    class Meta:
        model = PlantMachineryElectricityEntryAttachment
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PlantMachineryElectricityEntrySerializer(serializers.ModelSerializer):
    attachments = PlantMachineryElectricityEntryAttachmentSerializer(
        many=True,
        required=False,
        source='electricity_entry_plant_machinery_electricity_entry_attachment'
    )

    class Meta:
        model = PlantMachineryElectricityEntry
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        attachments_data = validated_data.pop('electricity_entry_plant_machinery_electricity_entry_attachment', [])
        electricity_entry = PlantMachineryElectricityEntry.objects.create(**validated_data)
        current_user = electricity_entry.created_by if electricity_entry.created_by else None

        for attachment_data in attachments_data:
            processed_attachment = process_attachments(attachment_data)
            attachment_data.pop('mime_type', None)
            attachment_data.pop('file_data', None)
            PlantMachineryElectricityEntryAttachment.objects.create(
                **attachment_data,
                electricity_entry=electricity_entry,
                attachment=processed_attachment if processed_attachment else None,
                created_by=current_user,
            )
        return electricity_entry

    @transaction.atomic
    def update(self, instance, validated_data):
        attachments_data = validated_data.pop('electricity_entry_plant_machinery_electricity_entry_attachment', [])
        
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        current_user = instance.updated_by if instance.updated_by else None
        existing_attachments = instance.electricity_entry_plant_machinery_electricity_entry_attachment.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            processed_attachment = process_attachments(attachment_data)

            existing_attachment = next((item for item in existing_attachments if item.id == attachment_id), None)

            if existing_attachment:
                for attr, value in attachment_data.items():
                    setattr(existing_attachment, attr, value)
                if processed_attachment:
                    existing_attachment.attachment = processed_attachment
                    existing_attachment.file_data=""
                    existing_attachment.mime_type=""
                existing_attachment.updated_by = current_user
                existing_attachment.save()
            else:
                attachment_data.pop('mime_type', None)
                attachment_data.pop('file_data', None)
                PlantMachineryElectricityEntryAttachment.objects.create(
                    **attachment_data,
                    electricity_entry=instance,
                    attachment=processed_attachment if processed_attachment else None,
                    created_by=current_user,
                )

        # for existing_attachment in existing_attachments:
        #     if existing_attachment.id not in [attachment.get('id') for attachment in attachments_data]:
        #         existing_attachment.is_deleted = True
        #         existing_attachment.updated_by = current_user
        #         existing_attachment.save()

        return instance

    
    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['attachments'] = representation.pop('attachments', [])
        return representation

class PlantMachineryHsdIssuedReportItemSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)  
    class Meta:
        model = PlantMachineryHsdIssuedReportItem
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class PlantMachineryHsdIssuedReportSerializer(serializers.ModelSerializer):
    items = PlantMachineryHsdIssuedReportItemSerializer(
        many=True,
        required=False,
        source='plant_machinery_hsd_issued_report_item_plant_machinery_hsd_issued_report'
    )
    project_details = serializers.SerializerMethodField()
    issued_quantity = serializers.SerializerMethodField()

    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)  
        return None
    
    def get_issued_quantity(self, instance):
        if instance.project and not getattr(instance.project, "is_deleted", False):
            actual_cost_query = PlantMachineryLogBook.cmobjects.filter(
                project_id=instance.project.id,
                fueltype='diesel',
                log_book_date__gte=instance.start_date,
                log_book_date__lte=instance.end_date,
            ).values('project').annotate(
                actual_cost=Coalesce(Sum('total_fuel_filled'), Value(0), output_field=FloatField()),
            )
            if actual_cost_query:
                return actual_cost_query
        return []
    class Meta:
        model = PlantMachineryHsdIssuedReport
        fields = '__all__'    
    
    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('plant_machinery_hsd_issued_report_item_plant_machinery_hsd_issued_report', [])

        issued_report = PlantMachineryHsdIssuedReport.objects.create(**validated_data)
        issued_report.save()
        current_user = issued_report.created_by if issued_report.created_by else None

        for item_data in items_data:
            PlantMachineryHsdIssuedReportItem.objects.create(
                **item_data,
                plant_machinery_hsd_issued_report=issued_report,
                created_by=current_user,
            )

        return issued_report

    @transaction.atomic
    def update(self, instance, validated_data):
        items_data = validated_data.pop('plant_machinery_hsd_issued_report_item_plant_machinery_hsd_issued_report', [])

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        current_user = instance.updated_by if instance.updated_by else None
        existing_items = instance.plant_machinery_hsd_issued_report_item_plant_machinery_hsd_issued_report.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')

            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if existing_item:
                for attr, value in item_data.items():
                    setattr(existing_item, attr, value)
                existing_item.updated_by = current_user
                existing_item.save()
            else:
                PlantMachineryHsdIssuedReportItem.objects.create(
                    **item_data,
                    plant_machinery_hsd_issued_report=instance,
                    created_by=current_user,
                )

        for existing_item in existing_items:
            if existing_item.id not in [item.get('id') for item in items_data]:
                existing_item.is_deleted = True
                existing_item.updated_by = current_user
                existing_item.save()

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['items'] = representation.pop('items', [])
        return representation
 
class PlantMachineryRepairSerializer(serializers.ModelSerializer):
    project_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()

    class Meta:
        model = PlantMachineryRepair
        fields = '__all__'
    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)  
        return None
    def get_plant_machinery_machine_details(self, instance):
        
        machine = instance.plant_machinery_machine
        if machine and not getattr(machine, "is_deleted", False):
            return {
                "equipment_number": machine.equipment_number if machine.equipment_number else None,
                "machine_number": machine.machine_number if machine.machine_number else None,
                "equipment_description": machine.equipment_description if machine.equipment_description else None,
                "registration_no": machine.registration_no if machine.registration_no else None,
                'plant_machinery_group__id': instance.plant_machinery_machine.plant_machinery_group.pk if instance.plant_machinery_machine.plant_machinery_group else None,
                'plant_machinery_group__name': instance.plant_machinery_machine.plant_machinery_group.name if instance.plant_machinery_machine.plant_machinery_group else None,

            
            }
        return None
    @transaction.atomic
    def create(self, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
        else:
            processed_attachment = None

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        repair_entry = PlantMachineryRepair.objects.create(**validated_data)

        if processed_attachment:
            repair_entry.attachment = processed_attachment
        repair_entry.save()

        return repair_entry

    @transaction.atomic
    def update(self, instance, validated_data):
        file_data = validated_data.get('file_data', '')
        mime_type = validated_data.get('mime_type', '')

        if file_data and mime_type:
            processed_attachment = process_attachments(validated_data)
            if processed_attachment:
                instance.attachment = processed_attachment

        validated_data['mime_type'] = ''
        validated_data['file_data'] = ''

        for field, value in validated_data.items():
            setattr(instance, field, value)

        instance.save()
        return instance


class PlantMachineryRepairBudgetSerializer(serializers.ModelSerializer):
    project_details = serializers.SerializerMethodField()
    plant_machinery_group_details = serializers.SerializerMethodField()
    budget_master_details = serializers.SerializerMethodField()
    actual_cost_details = serializers.SerializerMethodField()
    # monthly_rm_cost = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryRepairBudget
        fields = '__all__'

    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)
        return None

    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group, extras=[], type="dict")

    def get_budget_master_details(self, instance):
        return get_details_from_instance(instance.budget_master, extras=[], type="dict")
    
    def get_actual_cost_details(self, instance):
        if (instance.project and instance.plant_machinery_group and not getattr(instance.project, "is_deleted", False) and not getattr(instance.plant_machinery_group, "is_deleted", False)) :
            end_date = datetime(instance.date.year, instance.date.month, calendar.monthrange(instance.date.year, instance.date.month)[1])
            return PlantMachineryRepair.cmobjects.filter(
                project_id = instance.project.id,
                date__gte = instance.date,
                date__lte = end_date,
                plant_machinery_machine__plant_machinery_group_id = instance.plant_machinery_group.id,
            ).values()
        return None
    # def get_monthly_rm_cost(self, instance):
      
    #     if not instance.date or not instance.plant_machinery_group:
    #         return 0

    #     start_date = date(instance.date.year, instance.date.month, 1)
    #     end_date = date(
    #         instance.date.year,
    #         instance.date.month,
    #         calendar.monthrange(instance.date.year, instance.date.month)[1]
    #     )
    #     _details = PlantMachineryLogBook.cmobjects.filter(
    #         project_id=instance.project.id,
    #         log_book_date__gte=start_date,
    #         log_book_date__lte=end_date,
    #         plant_machinery_group__is_deleted=False,
    #         plant_machinery_group=instance.plant_machinery_group,
    #         plant_machinery_group__machine_type__in=['machine', 'vehicle']
    #     ).aggregate(
    #         monthly_running=Sum(
    #             Case(
    #                 When(plant_machinery_group__machine_type='machine', then='total_working_hrs'),
    #                 When(plant_machinery_group__machine_type='vehicle', then='total_km_run'),
    #                 default=Value(0),
    #                 output_field=FloatField()
    #             )
    #         )
    #     )
    #     print(_details)
    #     monthly_running = _details.get('monthly_running') or 0
    #     r_and_m_norms = instance.plant_machinery_group.r_and_m_norms or 0

    #     return monthly_running * r_and_m_norms
class PlantMachineryAssetRequisitionStagesSerializer(serializers.ModelSerializer):
    """
    PlantMachinery CSTStages Serializer
    """
    id = serializers.IntegerField(required=False)
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    
    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    
    class Meta:
        model = PlantMachineryAssetRequisitionStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryAssetRequisitionItemSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    plant_machinery_group_details = serializers.SerializerMethodField()
    
    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group, extras=[], type="dict")
    class Meta:
        model = PlantMachineryAssetRequisitionItem
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryAssetRequisitionAttachmentSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)  
    class Meta:
        model = PlantMachineryAssetRequisitionAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class PlantMachineryAssetRequisitionSerializer(serializers.ModelSerializer):
    stages = PlantMachineryAssetRequisitionStagesSerializer(
        many=True,
        required=False,
        source='asset_requisition_plant_machinery_asset_requisition_stages'
    )
    items = PlantMachineryAssetRequisitionItemSerializer(
        many=True,
        required=False,
        source='asset_requisition_plant_machinery_asset_requisition_item'
    )
    attachments = PlantMachineryAssetRequisitionAttachmentSerializer(
        many=True,
        required=False,
        source='asset_requisition_plant_machinery_asset_requisition_attachment'
    )
    project_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    organization_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    multi_stage_details = serializers.SerializerMethodField()
    status_details = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryAssetRequisition
        fields = '__all__'
    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)

    def get_status_details(self, instance):
        return multi_stage_status_details(instance, self.get_multi_stage_details(instance), 'checked')
    
    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)
        return None
    def get_site_details(self, instance):
        return get_details_from_instance(instance.site,extras=[], type="dict") 
    def get_store_details(self, instance):
        return get_details_from_instance(instance.store,extras=[], type="dict")
    def get_organization_details(self, instance):
        key_list = get_details_from_instance(instance.organization)
        city_name = None
        if instance.organization and instance.organization.org_city:
            city_obj = get_details_from_instance(instance.organization.org_city, type="dict")
            city_name = city_obj['name'] if city_obj else None
        state_name = None
        if instance.organization and instance.organization.org_state:
            state_obj = get_details_from_instance(instance.organization.org_state, type="dict")
            state_name = state_obj['name'] if state_obj else None
        country_name = None
        if instance.organization and instance.organization.org_country:
            country_obj = get_details_from_instance(instance.organization.org_country, type="dict")
            country_name = country_obj['name'] if country_obj else None

        address = f"{city_name} {state_name} {country_name}"
        key_list.append({'organization_address': address})
        return key_list
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('asset_requisition_plant_machinery_asset_requisition_item', [])
        attachments_data = validated_data.pop('asset_requisition_plant_machinery_asset_requisition_attachment', [])

        asset_requisition = PlantMachineryAssetRequisition.objects.create(**validated_data)
        # asset_requisition.request_code = generate_all_code(asset_requisition,['AR'])
        # asset_requisition.save()
        current_user = asset_requisition.created_by if asset_requisition.created_by else None

        for item_data in items_data:
            plant_machinery_machines = item_data.pop('plant_machinery_machines', [])
            item_instance=PlantMachineryAssetRequisitionItem.objects.create(
                **item_data,
                asset_requisition=asset_requisition,
                created_by=current_user,
            )
            item_instance.plant_machinery_machines.set(plant_machinery_machines) if plant_machinery_machines else None
            item_instance.save()
        for attachment_data in attachments_data:
            processed_attachment = process_attachments(attachment_data)
            attachment_data.pop('mime_type',None)
            attachment_data.pop('file_data', None)
            print(processed_attachment)
            PlantMachineryAssetRequisitionAttachments.objects.create(
                **attachment_data,
                asset_requisition=asset_requisition,
                attachment=processed_attachment if processed_attachment else None,
                created_by=current_user,
            )    
        return asset_requisition

    @transaction.atomic
    def update(self, instance, validated_data):
        items_data = validated_data.pop('asset_requisition_plant_machinery_asset_requisition_item', [])
        attachments_data = validated_data.pop('asset_requisition_plant_machinery_asset_requisition_attachment', [])
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
       
        instance.save()

        current_user = instance.updated_by if instance.updated_by else None
        existing_items = instance.asset_requisition_plant_machinery_asset_requisition_item.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            plant_machinery_machines = item_data.pop('plant_machinery_machines', [])
            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if existing_item:
                for attr, value in item_data.items():
                    setattr(existing_item, attr, value)
                existing_item.updated_by = current_user
                if plant_machinery_machines:
                    existing_item.plant_machinery_machines.clear()
                    existing_item.plant_machinery_machines.set(plant_machinery_machines)
                existing_item.save()
            else:
                item_instance=PlantMachineryAssetRequisitionItem.objects.create(
                    **item_data,
                    asset_requisition=instance,
                    created_by=current_user,
                )
                if plant_machinery_machines:
                    item_instance.plant_machinery_machines.clear()
                    item_instance.plant_machinery_machines.set(plant_machinery_machines)
                    item_instance.save()

        for existing_item in existing_items:
            if existing_item.id not in [item.get('id') for item in items_data]:
                existing_item.is_deleted = True
                existing_item.updated_by = current_user
                existing_item.save()
        existing_attachments = instance.asset_requisition_plant_machinery_asset_requisition_attachment.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            processed_attachment = process_attachments(attachment_data)

            existing_attachment = next((att for att in existing_attachments if att.id == attachment_id), None)

            if existing_attachment:
                for attr, value in attachment_data.items():
                    setattr(existing_attachment, attr, value)
                if processed_attachment:
                    existing_attachment.attachment = processed_attachment
                    existing_attachment.file_data = ""
                    existing_attachment.mime_type = ""
                existing_attachment.updated_by = current_user
                existing_attachment.save()
            else:
                attachment_data.pop('mime_type', "")
                attachment_data.pop('file_data', "")
                PlantMachineryAssetRequisitionAttachments.objects.create(
                    **attachment_data,
                    asset_requisition=instance,
                    attachment=processed_attachment if processed_attachment else None,
                    created_by=current_user,
                )

        # for existing_attachment in existing_attachments:
        #     if existing_attachment.id not in [att.get('id') for att in attachments_data]:
        #         existing_attachment.is_deleted = True
        #         existing_attachment.updated_by = current_user
        #         existing_attachment.save()

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['items'] = representation.pop('items', [])
        representation['attachments'] = representation.pop('attachments', [])
        stages_data = representation.pop('stages', [])
        representation['stages'] = stages_data

        return representation

class PlantMachineryRFQVendorsItemsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    plant_machinery_group_details = serializers.SerializerMethodField()
    
    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group, extras=[], type="dict")
    
    class Meta:
        model = PlantMachineryRFQVendorsItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class PlantMachineryRFQVendorsSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery RFQVendors Serializer
    """
    id = serializers.IntegerField(required=False)
    items = PlantMachineryRFQVendorsItemsSerializer(many=True, source="plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items")

    mail_details = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    # quot_count = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    linked_docs = serializers.SerializerMethodField()
    asset_requisitions_details = serializers.SerializerMethodField()
    plant_machinery_cst_details = serializers.SerializerMethodField()
    # selected_quotation_list = serializers.SerializerMethodField()
    # def get_selected_quotation_list(self, instance):
    #     return instance.procurement_purchase_order_rfq_vendor.values_list('quotation_id', flat=True)
    def get_plant_machinery_cst_details(self, instance):
        
        return PlantMachineryCST.cmobjects.filter(plant_machinery_rfq_vendor_id=instance.id).values('id','status','current_stage')
    def get_asset_requisitions_details(self, instance):
       
        return get_details_from_instance(instance.asset_requisitions,extras=[], type="list")

  
    def get_linked_docs(self, instance):
        return parent_fields(instance,'plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items')
    
    # def get_quot_count(self, instance):
    #     _quot_count = instance.procurement_rfq_quotation.exclude(status__in=['rejected','cancelled']).aggregate(total_count=Count('id'))
    #     return _quot_count['total_count'] if _quot_count['total_count'] else 0.0

    def get_vendor_details(self, instance):
        details = []
        for vendor_details in instance.vendor.filter(is_deleted=False):
            details.append(get_vendor_data(vendor_details))
        return details

    def get_mail_details(self, instance):
        mail_details = None
        if instance.id:
            email_template = EmailTemplates.cmobjects.get(template_name='PNMRFQ')
            htmly = Template(email_template.body if email_template else '')
            mail_details = instance.plant_machiner_rfq_vendors_plant_machinery_rfq_vendor_mail.filter(is_deleted=False).values(
                'id',
                'vendor_id',
                'email_send__is_sent',
                'email_send__subject',
                'email_send__context',
                'allow_revision',
                'plant_machinery_rfq_vendor_id',
                'organization_id',
            )
            for mail_detail in mail_details:
                mail_detail['email_send__processed_message'] = htmly.render(Context(mail_detail['email_send__context']))
                mail_detail['email_send__context'] = ''
                mail_detail['quotation_url'] = generate_rfq_link(mail_detail['vendor_id'],mail_detail['plant_machinery_rfq_vendor_id'],mail_detail['organization_id'],'pnm','non-gst')
                mail_detail['quotation_url_with_gst'] = generate_rfq_link(mail_detail['vendor_id'],mail_detail['plant_machinery_rfq_vendor_id'],mail_detail['organization_id'],'pnm','gst')
        return mail_details

   
    vendor_ids = serializers.ListField(child=serializers.IntegerField(), write_only=True)

    def validate_vendor_ids(self, value):
        errors = []
        for id in value:
            try:
                VendorMasterV2.cmobjects.get(pk=id)
            except VendorMasterV2.DoesNotExist:
                errors.append(f"Vendor with ID {id} does not exist.")
        if errors:
            raise serializers.ValidationError(errors)
        return value

    def get_project_details(self, instance):
        _details = None
        if instance.project and not getattr(instance.project, "is_deleted", False):
            try:
                data = get_project_data(instance.project_id)
                _details = {"project_id": instance.project_id, "data": data}
            except Exception as e:
                print('ERROR', e)
        return _details

    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details

    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details

    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details

    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details

    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details

    @transaction.atomic
    def create(self, validated_data):
        requested_items_data = validated_data.pop('plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items', [])
        id = validated_data.get('id')
        existing_record = PlantMachineryRFQVendors.cmobjects.filter(pk=id).first()
        vendor_ids = validated_data.pop('vendor_ids')
        current_user = validated_data.get('updated_by', None)
        asset_requisitions = validated_data.pop('asset_requisitions', [])

        if existing_record:
            for field in existing_record._meta.fields:
                field_name = field.name
                if field_name in validated_data:
                    setattr(existing_record, field_name, validated_data[field_name])
            setattr(existing_record, 'updated_by', current_user)
            
            existing_record.vendor.clear()
            for vendor_id in vendor_ids:
                vendor = VendorMasterV2.objects.filter(pk=vendor_id).first()
                existing_record.vendor.add(vendor)
               
            for requested_item_data in requested_items_data:
                plant_machinery_machines = requested_item_data.pop('plant_machinery_machines', [])
                requested_item_data['updated_by']=current_user
                requested_item_data['plant_machinery_rfq_vendor']=existing_record
                last_item = PlantMachineryRFQVendorsItems.cmobjects.filter(
                    plant_machinery_rfq_vendor=existing_record,
                    # requested_material=requested_item_data['requested_material']
                    plant_machinery_group = requested_item_data['plant_machinery_group']

                ).last() 
                
                if last_item:
                    for key, value in requested_item_data.items():
                        setattr(last_item, key, value)
                    if plant_machinery_machines:
                        last_item.plant_machinery_machines.clear()  
                        last_item.plant_machinery_machines.set(plant_machinery_machines)    
                    last_item.save()
                else:
                    item_instance=PlantMachineryRFQVendorsItems.objects.create(**requested_item_data)
                    item_instance.plant_machinery_machines.set(plant_machinery_machines) if plant_machinery_machines else None
                    item_instance.save()
            if asset_requisitions:
                existing_record.asset_requisitions.clear()
                existing_record.asset_requisitions.set(asset_requisitions)
            existing_record.save()
            return existing_record
        else:
            record = PlantMachineryRFQVendors.objects.create(**validated_data)
            # record.request_code = generate_all_code(record,['PNMENQUIRY'])
            setattr(record, 'created_by', current_user)

            for vendor_id in vendor_ids:
                vendor = VendorMasterV2.cmobjects.filter(pk=vendor_id).first()
                record.vendor.add(vendor)
            for requested_item_data in requested_items_data:
                plant_machinery_machines = requested_item_data.pop('plant_machinery_machines', [])
                requested_item_data['created_by']=current_user
                item = PlantMachineryRFQVendorsItems.objects.create(plant_machinery_rfq_vendor=record, **requested_item_data)
                item.plant_machinery_machines.set(plant_machinery_machines) if plant_machinery_machines else None
                item.save()
            record.asset_requisitions.set(asset_requisitions) if asset_requisitions else None

            record.save()
            return record

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        requested_items_data = representation.pop('items', [])
        representation['items'] = requested_items_data

        return representation

    class Meta:
        model = PlantMachineryRFQVendors
        fields = '__all__'


class PlantMachineryQuotationTermsAndConditionsSerializer(serializers.ModelSerializer):
    """
    PlantMachinery QuotationTermsAndConditions Serializer
    """
    id = serializers.IntegerField(required=False)
    
    class Meta:
        model = PlantMachineryQuotationTermsAndConditions
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PlantMachineryQuotationAttachmentsSerializer(serializers.ModelSerializer):
    """
    PlantMachinery QuotationAttachments Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryQuotationAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class PlantMachineryQuotationItemsSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery Quotation Serializer
    """
    id = serializers.IntegerField(required=False)
    plant_machinery_group_details = serializers.SerializerMethodField()
    
    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group, extras=[], type="dict")
    # material_details = serializers.SerializerMethodField()
    # purchase_order_items = serializers.SerializerMethodField()

    # def get_purchase_order_items(self, instance):
    #     return PurchaseOrderItems.cmobjects.filter(quotation_item_id=instance.id).values_list('id',flat=True)

    # def get_material_details(self, instance):
    #     return_details = {}
    #     try:
    #         if instance.requested_material:
    #             # details = VendorMaterialMaster.cmobjects.filter(pk=instance.requested_material_id).first()
    #             # serializer = VendorMaterialMasterSerializer(details)
    #             serializer = VendorMaterialMasterSerializer(instance.requested_material)
    #             return_details = serializer.data
    #     except Exception as e:
    #         print('ERROR', e)

    #     return return_details

    class Meta:
        model = PlantMachineryQuotationItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PlantMachineryQuotationTaxDetailsSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery Quotation Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryQuotationTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PlantMachineryQuotationExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery Quotation Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryQuotationExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class PlantMachineryQuotationSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery Quotation Serializer
    """
    
    linked_docs = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()
    asset_requisitions_details = serializers.SerializerMethodField()
    # cst_details = serializers.SerializerMethodField()


    # def get_cst_details(self, instance):
    #     cst_details = None
    #     if instance.rfq_vendor:
    #         cst_details = CST.cmobjects.filter(rfq_vendor_id=instance.rfq_vendor.id).values()
    #     return cst_details
    
    
    def get_asset_requisitions_details(self, instance):
       
        return get_details_from_instance(instance.asset_requisitions,extras=[], type="list")
    def get_linked_docs(self, instance):
        return parent_fields(instance,'plant_machinery_quotation_plant_machinery_quotation_items')
    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, type="dict")
    

    def get_project_name(self, instance):
      
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.project.project_name if instance.project and not getattr(instance.project, "is_deleted", False) else ''
    
    def get_project_code(self, instance):
       
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.project.project_code if instance.project else ''

    quotation_items =PlantMachineryQuotationItemsSerializer(many=True, source="plant_machinery_quotation_plant_machinery_quotation_items")
    quotation_tax = PlantMachineryQuotationTaxDetailsSerializer(many=True, required=False, source="plant_machinery_quotation_plant_machinery_quotation_tax_details")
    quotation_expense = PlantMachineryQuotationExpenseDetailsSerializer(many=True, required=False, source="plant_machinery_quotation_plant_machinery_quotation_expense_details")
    attachments = PlantMachineryQuotationAttachmentsSerializer(many=True, required=False, source="plant_machinery_quotation_plant_machinery_quotation_attachment")
    quotation_tnc = PlantMachineryQuotationTermsAndConditionsSerializer(many=True, required=False, source="plant_machinery_quotation_plant_machinery_quotation_terms_and_conditions")

    def calculate_totals(self, instance):
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.plant_machinery_quotation_plant_machinery_quotation_items.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount

        for item in instance.plant_machinery_quotation_plant_machinery_quotation_expense_details.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

        for item in instance.plant_machinery_quotation_plant_machinery_quotation_tax_details.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.total_amount_for_required_duration = instance.total_amount * instance.required_duration
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('plant_machinery_quotation_plant_machinery_quotation_items', [])
        tax_data = validated_data.pop('plant_machinery_quotation_plant_machinery_quotation_tax_details', [])
        expense_data = validated_data.pop('plant_machinery_quotation_plant_machinery_quotation_expense_details', [])
        requested_attachment = validated_data.pop('plant_machinery_quotation_plant_machinery_quotation_attachment', [])
        tnc_data = validated_data.pop('plant_machinery_quotation_plant_machinery_quotation_terms_and_conditions', [])
        asset_requisitions = validated_data.pop('asset_requisitions', [])

        quotation = PlantMachineryQuotation.objects.create(**validated_data)
        quotation.asset_requisitions.set(asset_requisitions) if asset_requisitions else None
        current_user = quotation.created_by if quotation.created_by else None
        

        for requested_attachment_data in requested_attachment:
            try:
                PlantMachineryQuotationAttachments.objects.create(
                    organization=quotation.organization,
                    plant_machinery_quotation=quotation,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        for quotation_item_data in items_data:
            plant_machinery_machines = quotation_item_data.pop('plant_machinery_machines', [])
            item_instance=PlantMachineryQuotationItems.objects.create(plant_machinery_quotation=quotation, created_by=current_user, **quotation_item_data)
            item_instance.plant_machinery_machines.set(plant_machinery_machines) if plant_machinery_machines else None
            item_instance.save()
        self.calculate_totals(quotation)
        for quotation_expense_data in expense_data:
            print(quotation_expense_data)
            PlantMachineryQuotationExpenseDetails.objects.create(plant_machinery_quotation=quotation, created_by=current_user, **quotation_expense_data)
        self.calculate_totals(quotation)
        for quotation_tax_data in tax_data:
            PlantMachineryQuotationTaxDetails.objects.create(plant_machinery_quotation=quotation, created_by=current_user, **quotation_tax_data)
        for quotation_tnc_data in tnc_data:
            PlantMachineryQuotationTermsAndConditions.objects.create(plant_machinery_quotation=quotation, created_by=current_user, **quotation_tnc_data)

        self.calculate_totals(quotation)
        quotation.save()
        return quotation

    @transaction.atomic
    def update(self, instance, validated_data):
        asset_requisitions = validated_data.pop('asset_requisitions', [])
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        if  asset_requisitions:
            instance.asset_requisitions.clear()
            instance.asset_requisitions.set(asset_requisitions)
        current_user = instance.updated_by if instance.updated_by else None

        quotation_item_data = validated_data.get('plant_machinery_quotation_plant_machinery_quotation_items', [])
        quotation_tax_data = validated_data.get('plant_machinery_quotation_plant_machinery_quotation_tax_details', [])
        quotation_expense_data = validated_data.get('plant_machinery_quotation_plant_machinery_quotation_expense_details', [])
        quotation_tnc_data = validated_data.get('plant_machinery_quotation_plant_machinery_quotation_terms_and_conditions', [])
        attachments_data = validated_data.get('plant_machinery_quotation_plant_machinery_quotation_attachment', [])
        existing_attachments = instance.plant_machinery_quotation_plant_machinery_quotation_attachment.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = PlantMachineryQuotationAttachments.objects.create(
                        organization=instance.organization,
                        plant_machinery_quotation=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()

        existing_items = instance.plant_machinery_quotation_plant_machinery_quotation_items.filter(is_deleted=False)
        existing_taxes = instance.plant_machinery_quotation_plant_machinery_quotation_tax_details.filter(is_deleted=False)
        existing_expense = instance.plant_machinery_quotation_plant_machinery_quotation_expense_details.filter(is_deleted=False)
        existing_tncs = instance.plant_machinery_quotation_plant_machinery_quotation_terms_and_conditions.filter(is_deleted=False)
        print(existing_items)
        for item_data in quotation_tnc_data:
            item_id = item_data.get('id')
            
            # item_data['created_by'] = current_user
            existing_item = next((item for item in existing_tncs if item.id == item_id), None)

            if not existing_item:
                existing_item = PlantMachineryQuotationTermsAndConditions.objects.create(plant_machinery_quotation=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_tncs:
            if existing_item.id not in [item_data.get('id') for item_data in quotation_tnc_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for item_data in quotation_item_data:
            item_id = item_data.get('id')
            plant_machinery_machines = item_data.pop('plant_machinery_machines', [])

            existing_item = next((item for item in existing_items if item.id == item_id), None)
            print(existing_item)
            if not existing_item:
                existing_item = PlantMachineryQuotationItems.objects.create(plant_machinery_quotation=instance, created_by=current_user, **item_data)
                if plant_machinery_machines:
                    existing_item.plant_machinery_machines.clear()
                    existing_item.plant_machinery_machines.set(plant_machinery_machines)
                    existing_item.save()
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                if plant_machinery_machines:
                    existing_item.plant_machinery_machines.clear()
                    existing_item.plant_machinery_machines.set(plant_machinery_machines)
                existing_item.save() 

        for existing_item in existing_items:
            if existing_item.id not in [item_data.get('id') for item_data in quotation_item_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        self.calculate_totals(instance)
        
        for item_data in quotation_expense_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_expense if item.id == item_id), None)

            if not existing_item:
                existing_item = PlantMachineryQuotationExpenseDetails.objects.create(plant_machinery_quotation=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_expense:
            if existing_item.id not in [item_data.get('id') for item_data in quotation_expense_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        self.calculate_totals(instance)
        
        for item_data in quotation_tax_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_taxes if item.id == item_id), None)

            if not existing_item:
                existing_item = PlantMachineryQuotationTaxDetails.objects.create(plant_machinery_quotation=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_taxes:
            if existing_item.id not in [item_data.get('id') for item_data in quotation_tax_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        self.calculate_totals(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        quotation_items_data = representation.pop('quotation_items', [])
        representation['quotation_items'] = quotation_items_data
        quotation_tax_data = representation.pop('quotation_tax', [])
        representation['quotation_tax'] = quotation_tax_data
        quotation_expense_data = representation.pop('quotation_expense', [])
        representation['quotation_expense'] = quotation_expense_data
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data
        quotation_tnc_data = representation.pop('quotation_tnc', [])
        representation['quotation_tnc'] = quotation_tnc_data

        return representation

    class Meta:
        model = PlantMachineryQuotation
        fields = '__all__'


class PlantMachineryCSTStagesSerializer(serializers.ModelSerializer):
    """
    PlantMachinery CSTStages Serializer
    """
    id = serializers.IntegerField(required=False)
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    
    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    
    class Meta:
        model = PlantMachineryCSTStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryCSTItemsSerializer(serializers.ModelSerializer):
    """
    PlantMachinery CSTItems Serializer
    """
    id = serializers.IntegerField(required=False)
    plant_machinery_group_details = serializers.SerializerMethodField()
    
    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group, extras=[], type="dict")
    class Meta:
        model = PlantMachineryCSTItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryCSTSerializer(serializers.ModelSerializer):
    """
    Serializer for Plant machinery Comparison Statement (CST)
    """
    stages = PlantMachineryCSTStagesSerializer(many=True, required=False, source="plant_machinery_cst_plant_machinery_cst_stages")
    items = PlantMachineryCSTItemsSerializer(many=True, required=False, source="plant_machinery_cst_plant_machinery_cst_item")

    organization_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    project_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    asset_requisitions_details = serializers.SerializerMethodField()

    multi_stage_details = serializers.SerializerMethodField()
    status_details = serializers.SerializerMethodField()
    # is_pnm_budgeted = serializers.SerializerMethodField()
    # def get_is_pnm_budgeted(self, instance):
    #     return  PlantMachineryCSTItems.cmobjects.filter(
    #                 plant_machinery_cst_id=instance.id,
    #                 plant_machinery_group__in=PlantMachineryMachineBudget.cmobjects.filter(
    #                     project_id=instance.project.id,
    #                     budget_master__is_deleted=False,
    #                     budget_master__latest=True
    #                 ).values('plant_machinery_group_id')
    #             ).exists()
    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)

    def get_status_details(self, instance):
        return multi_stage_status_details(instance, self.get_multi_stage_details(instance), 'checked')
    
    def get_asset_requisitions_details(self, instance):
       
        return get_details_from_instance(instance.asset_requisitions,extras=[], type="list")
    def get_organization_details(self, instance):
        key_list = get_details_from_instance(instance.organization)
        city_name = None
        if instance.organization and instance.organization.org_city:
            city_obj = get_details_from_instance(instance.organization.org_city, type="dict")
            city_name = city_obj['name'] if city_obj else None
        state_name = None
        if instance.organization and instance.organization.org_state:
            state_obj = get_details_from_instance(instance.organization.org_state, type="dict")
            state_name = state_obj['name'] if state_obj else None
        country_name = None
        if instance.organization and instance.organization.org_country:
            country_obj = get_details_from_instance(instance.organization.org_country, type="dict")
            country_name = country_obj['name'] if country_obj else None

        address = f"{city_name} {state_name} {country_name}"
        key_list.append({'organization_address': address})
        return key_list

    def get_store_details(self, instance):
        details = None
        if instance.store:
            details = get_details_from_instance(instance.store)
        return details

    def get_project_details(self, instance):
        project = instance.project
        if project:
            return get_project_data( instance.project.id)
        return None

    def get_site_details(self, instance):
        details = None
        if instance.site:
            details = get_details_from_instance(instance.site)
        return details

    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        stages_data = representation.pop('stages', [])
        representation['stages'] = stages_data
        return representation
    
    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('plant_machinery_cst_plant_machinery_cst_item', [])
        asset_requisitions = validated_data.pop('asset_requisitions', [])

        cst = PlantMachineryCST.objects.create(**validated_data)
        # cst.request_code = generate_all_code(cst,['PNMCST'])

        cst.asset_requisitions.set(asset_requisitions) if asset_requisitions else None
        current_user = cst.created_by if cst.created_by else None
        plant_machinery_group_list = []

        for item_data in items_data:
            plant_machinery_machines = item_data.pop('plant_machinery_machines', [])
            item_instance=PlantMachineryCSTItems.objects.create(plant_machinery_cst=cst, **item_data,created_by=current_user)
            item_instance.plant_machinery_machines.set(plant_machinery_machines) if plant_machinery_machines else None
            item_instance.save()
            if item_instance.plant_machinery_group:
                plant_machinery_group_list.append(item_instance.plant_machinery_group.id)
        
        cst.is_budgeted = PlantMachineryMachineBudget.cmobjects.filter(
            project_id=cst.project.id,
            plant_machinery_group__in=plant_machinery_group_list,
            budget_master__is_deleted=False,
            budget_master__latest=True,
            # budget_master__from_date__lte=cst.date,
            # budget_master__to_date__gte=cst.date,
        ).exists()
        cst.save()    
        return cst
    @transaction.atomic
    def update(self, instance, validated_data):
        items_data = validated_data.pop('plant_machinery_cst_plant_machinery_cst_item', [])
        asset_requisitions = validated_data.pop('asset_requisitions', [])

        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        if  asset_requisitions:
            instance.asset_requisitions.clear()
            instance.asset_requisitions.set(asset_requisitions)
        current_user = instance.updated_by if instance.updated_by else None
      

        existing_items = instance.plant_machinery_cst_plant_machinery_cst_item.filter(is_deleted=False)
        for item_data in items_data:
            item_id = item_data.get('id')
            plant_machinery_machines = item_data.pop('plant_machinery_machines', [])
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            print("existing",existing_item)
            if not existing_item:
                item_instance=PlantMachineryCSTItems.objects.create(plant_machinery_cst=instance, created_by=current_user, **item_data)
                if  plant_machinery_machines:
                    item_instance.plant_machinery_machines.clear()
                    item_instance.plant_machinery_machines.set(plant_machinery_machines)
                    item_instance.save()
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                if plant_machinery_machines:
                    existing_item.plant_machinery_machines.clear()
                    existing_item.plant_machinery_machines.set(plant_machinery_machines)
                existing_item.save()  
        for existing_item in existing_items:
            if existing_item.id not in [data.get('id') for data in items_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        instance.save()
        return instance

    class Meta:
        model = PlantMachineryCST
        fields = '__all__'        


class PlantMachineryWorkOrderTermsAndConditionsSerializer(serializers.ModelSerializer):
    """
    PlantMachinery WorkOrderTermsAndConditions Serializer
    """
    id = serializers.IntegerField(required=False)
    
    class Meta:
        model = PlantMachineryWorkOrderTermsAndConditions
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer




class PlantMachineryWorkOrderItemsSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery WorkOrder Serializer
    """
    id = serializers.IntegerField(required=False)
    plant_machinery_group_details = serializers.SerializerMethodField()
    
    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group, extras=[], type="dict")
   

    class Meta:
        model = PlantMachineryWorkOrderItems
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryWorkOrderTaxDetailsSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery Quotation Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryWorkOrderTaxDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class PlantMachineryWorkOrderExpenseDetailsSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery Work Order Expense Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryWorkOrderExpenseDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryWorkOrderPaymentScheduleSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery Work Order Payment Schedule Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryWorkOrderPaymentSchedule
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer  
class PlantMachineryWorkOrderDeliveryLocationSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery Work Order Delivery Location Serializer
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryWorkOrderDeliveryLocation
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer   
class PlantMachineryWorkOrderAttachmentsSerializer(serializers.ModelSerializer):
    """
    Procurement PlantMachinery WorkOrder Attachments Serializer 
    """
    id = serializers.IntegerField(required=False)

    class Meta:
        model = PlantMachineryWorkOrderAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer        
class PlantMachineryWorkOrderSerializer(serializers.ModelSerializer):
    """"
    PlantMachinery WorkOrder Serializer
    """
    
    linked_docs = serializers.SerializerMethodField()
    vendor_details = serializers.SerializerMethodField()
    project_name = serializers.SerializerMethodField()
    project_code = serializers.SerializerMethodField()
    asset_requisitions_details = serializers.SerializerMethodField()

    def get_asset_requisitions_details(self, instance):
        return get_details_from_instance(instance.asset_requisitions,extras=[], type="list")
    def get_linked_docs(self, instance):
        return parent_fields(instance,'plant_machinery_work_order_plant_machinery_work_order_items')
    def get_vendor_details(self, instance):
        return get_details_from_instance(instance.vendor, type="dict")
    

    def get_project_name(self, instance):
      
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_name').first()
        # project_name = projectdata.value if projectdata else ''
        return instance.project.project_name if instance.project and not getattr(instance.project, "is_deleted", False) else ''
    
    def get_project_code(self, instance):
       
        # projectdata = ProjectData.cmobjects.filter(project__id=instance.project_id,\
        #              form__form_type='project_details', form__form_internal_name='project_id').first()
        # project_code = projectdata.value if projectdata else ''
        return instance.project.project_code if instance.project and not getattr(instance.project, "is_deleted", False) else ''

    work_order_items =PlantMachineryWorkOrderItemsSerializer(many=True, source="plant_machinery_work_order_plant_machinery_work_order_items")
    work_order_tnc = PlantMachineryWorkOrderTermsAndConditionsSerializer(many=True, required=False, source="plant_machinery_work_order_plant_machinery_work_order_terms_and_conditions")
    work_order_tax = PlantMachineryWorkOrderTaxDetailsSerializer(many=True, required=False, source="plant_machinery_work_order_plant_machinery_work_order_tax_details")
    work_order_expense = PlantMachineryWorkOrderExpenseDetailsSerializer(many=True, required=False, source="plant_machinery_work_order_plant_machinery_work_order_expense_details")
    work_order_payment_schedule = PlantMachineryWorkOrderPaymentScheduleSerializer(many=True, required=False, source="plant_machinery_work_order_plant_machinery_work_order_payment_schedule")
    work_order_delivery_location = PlantMachineryWorkOrderDeliveryLocationSerializer(many=True, required=False, source="plant_machinery_work_order_plant_machinery_work_order_delivery_location")
    attachments = PlantMachineryWorkOrderAttachmentsSerializer(many=True, required=False, source="plant_machinery_work_order_plant_machinery_work_order_attachments")

    def calculate_totals(self, instance):
        instance.total_item_item_quantity = 0
        instance.total_item_item_amount = 0
        instance.total_item_disc_amount = 0
        instance.total_item_taxable_amount = 0
        instance.total_item_excise_tax_amount = 0
        instance.total_item_tax_amount = 0
        instance.total_item_sgst_amount = 0
        instance.total_item_cgst_amount = 0
        instance.total_item_igst_amount = 0
        instance.total_item_utgst_amount = 0
        instance.total_item_cess_amount = 0
        instance.total_item_total_amount = 0
        instance.total_tax_tax_amount = 0
        instance.total_tax_sgst_amount = 0
        instance.total_tax_cgst_amount = 0
        instance.total_tax_igst_amount = 0
        instance.total_tax_utgst_amount = 0
        instance.total_tax_cess_amount = 0
        instance.total_tax_total_tax_amount = 0
        instance.total_expense_expense_amount = 0
        instance.total_expense_sgst_amount = 0
        instance.total_expense_cgst_amount = 0
        instance.total_expense_igst_amount = 0
        instance.total_expense_utgst_amount = 0
        instance.total_expense_cess_amount = 0
        instance.total_expense_total_expense_amount = 0
        for item in instance.plant_machinery_work_order_plant_machinery_work_order_items.filter(is_deleted=False):
            if not item.is_deleted:
                instance.total_item_item_quantity = instance.total_item_item_quantity+item.quantity
                instance.total_item_item_amount = instance.total_item_item_amount+item.item_amount
                instance.total_item_disc_amount = instance.total_item_disc_amount+item.disc_amount
                instance.total_item_taxable_amount = instance.total_item_taxable_amount+item.taxable_amount
                instance.total_item_excise_tax_amount = instance.total_item_excise_tax_amount+item.excise_tax_amount
                instance.total_item_tax_amount = instance.total_item_tax_amount+item.tax_amount
                instance.total_item_sgst_amount = instance.total_item_sgst_amount+item.sgst_amount
                instance.total_item_cgst_amount = instance.total_item_cgst_amount+item.cgst_amount
                instance.total_item_igst_amount = instance.total_item_igst_amount+item.igst_amount
                instance.total_item_utgst_amount = instance.total_item_utgst_amount+item.utgst_amount
                instance.total_item_cess_amount = instance.total_item_cess_amount+item.cess_amount
                instance.total_item_total_amount = instance.total_item_total_amount+item.total_amount

        for item in instance.plant_machinery_work_order_plant_machinery_work_order_expense_details.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount+item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount+item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount+item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount+item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount+item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount+item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount+item.total_expense_amount
                    else:
                        instance.total_expense_expense_amount = instance.total_expense_expense_amount-item.expense_amount
                        instance.total_expense_sgst_amount = instance.total_expense_sgst_amount-item.sgst_amount
                        instance.total_expense_cgst_amount = instance.total_expense_cgst_amount-item.cgst_amount
                        instance.total_expense_igst_amount = instance.total_expense_igst_amount-item.igst_amount
                        instance.total_expense_utgst_amount = instance.total_expense_utgst_amount-item.utgst_amount
                        instance.total_expense_cess_amount = instance.total_expense_cess_amount-item.cess_amount
                        instance.total_expense_total_expense_amount = instance.total_expense_total_expense_amount-item.total_expense_amount

        for item in instance.plant_machinery_work_order_plant_machinery_work_order_tax_details.filter(is_deleted=False):
            if not item.is_deleted:
                if item.included:
                    if item.add:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount+item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount+item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount+item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount+item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount+item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount+item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount+item.total_tax_amount
                    else:
                        instance.total_tax_tax_amount = instance.total_tax_tax_amount-item.tax_amount
                        instance.total_tax_sgst_amount = instance.total_tax_sgst_amount-item.sgst_amount
                        instance.total_tax_cgst_amount = instance.total_tax_cgst_amount-item.cgst_amount
                        instance.total_tax_igst_amount = instance.total_tax_igst_amount-item.igst_amount
                        instance.total_tax_utgst_amount = instance.total_tax_utgst_amount-item.utgst_amount
                        instance.total_tax_cess_amount = instance.total_tax_cess_amount-item.cess_amount
                        instance.total_tax_total_tax_amount = instance.total_tax_total_tax_amount-item.total_tax_amount
        instance.total_amount = instance.total_item_total_amount+instance.total_tax_total_tax_amount+instance.total_expense_total_expense_amount
        instance.total_amount_for_required_duration = instance.total_amount * instance.required_duration
        instance.save()

     

    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('plant_machinery_work_order_plant_machinery_work_order_items', [])
        tax_data = validated_data.pop('plant_machinery_work_order_plant_machinery_work_order_tax_details', [])
        expense_data = validated_data.pop('plant_machinery_work_order_plant_machinery_work_order_expense_details', [])
        tnc_data = validated_data.pop('plant_machinery_work_order_plant_machinery_work_order_terms_and_conditions', [])
        payment_schedule_data = validated_data.pop('plant_machinery_work_order_plant_machinery_work_order_payment_schedule', [])
        delivery_location_data = validated_data.pop('plant_machinery_work_order_plant_machinery_work_order_delivery_location', [])
        requested_attachment = validated_data.pop('plant_machinery_work_order_plant_machinery_work_order_attachments', [])

        asset_requisitions = validated_data.pop('asset_requisitions', [])

        work_order = PlantMachineryWorkOrder.objects.create(**validated_data)
        work_order.asset_requisitions.set(asset_requisitions) if asset_requisitions else None
        current_user = work_order.created_by if work_order.created_by else None
        for requested_attachment_data in requested_attachment:
            try:
                PlantMachineryWorkOrderAttachments.objects.create(
                    organization=work_order.organization,
                    plant_machinery_work_order=work_order,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type="", attachment_name=requested_attachment_data.get('attachment_name', None),
                    created_by=current_user
                )

            except Exception as e:
                print(f"exception: {e}")
        for work_order_item_data in items_data:
            PlantMachineryWorkOrderItems.objects.create(plant_machinery_work_order=work_order, created_by=current_user, **work_order_item_data)
        self.calculate_totals(work_order)
        
        for work_order_expense_data in expense_data:
            PlantMachineryWorkOrderExpenseDetails.objects.create(plant_machinery_work_order=work_order, created_by=current_user, **work_order_expense_data)
        self.calculate_totals(work_order)
        for work_order_tax_data in tax_data:
            PlantMachineryWorkOrderTaxDetails.objects.create(plant_machinery_work_order=work_order, created_by=current_user, **work_order_tax_data)
        for work_order_tnc_data in tnc_data:
            PlantMachineryWorkOrderTermsAndConditions.objects.create(plant_machinery_work_order=work_order, created_by=current_user, **work_order_tnc_data)
        for work_order_payment_schedule_data in payment_schedule_data:
            PlantMachineryWorkOrderPaymentSchedule.objects.create(plant_machinery_work_order=work_order, created_by=current_user, **work_order_payment_schedule_data)
        for work_order_delivery_location_data in delivery_location_data:
            PlantMachineryWorkOrderDeliveryLocation.objects.create(plant_machinery_work_order=work_order, created_by=current_user, **work_order_delivery_location_data)

        self.calculate_totals(work_order)
        work_order.save()
        return work_order

    @transaction.atomic
    def update(self, instance, validated_data):
        asset_requisitions = validated_data.pop('asset_requisitions', [])
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()
        if  asset_requisitions:
            instance.asset_requisitions.clear()
            instance.asset_requisitions.set(asset_requisitions)
        current_user = instance.updated_by if instance.updated_by else None

        work_order_item_data = validated_data.get('plant_machinery_work_order_plant_machinery_work_order_items', [])
        work_order_tnc_data = validated_data.get('plant_machinery_work_order_plant_machinery_work_order_terms_and_conditions', [])
        work_order_tax_data = validated_data.get('plant_machinery_work_order_plant_machinery_work_order_tax_details', [])
        work_order_expense_data = validated_data.get('plant_machinery_work_order_plant_machinery_work_order_expense_details', [])
        work_order_payment_schedule_data = validated_data.get('plant_machinery_work_order_plant_machinery_work_order_payment_schedule', [])
        work_order_delivery_location_data = validated_data.get('plant_machinery_work_order_plant_machinery_work_order_delivery_location', [])

        existing_taxes = instance.plant_machinery_work_order_plant_machinery_work_order_tax_details.filter(is_deleted=False)
        existing_expense = instance.plant_machinery_work_order_plant_machinery_work_order_expense_details.filter(is_deleted=False)                                                    

        existing_items = instance.plant_machinery_work_order_plant_machinery_work_order_items.filter(is_deleted=False)
        existing_tncs = instance.plant_machinery_work_order_plant_machinery_work_order_terms_and_conditions.filter(is_deleted=False)
        existing_payment_schedule = instance.plant_machinery_work_order_plant_machinery_work_order_payment_schedule.filter(is_deleted=False)
        existing_delivery_location = instance.plant_machinery_work_order_plant_machinery_work_order_delivery_location.filter(is_deleted=False)
        attachments_data = validated_data.get('plant_machinery_work_order_plant_machinery_work_order_attachments', [])
        existing_attachments = instance.plant_machinery_work_order_plant_machinery_work_order_attachments.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = PlantMachineryWorkOrderAttachments.objects.create(
                        organization=instance.organization,
                        plant_machinery_work_order=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type="", attachment_name=attachment_data.get('attachment_name', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()
        for item_data in work_order_tnc_data:
            item_id = item_data.get('id')
            # item_data['created_by'] = current_user
            existing_item = next((item for item in existing_tncs if item.id == item_id), None)

            if not existing_item:
                existing_item = PlantMachineryWorkOrderTermsAndConditions.objects.create(plant_machinery_work_order=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_tncs:
            if existing_item.id not in [item_data.get('id') for item_data in work_order_tnc_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for item_data in work_order_item_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)
            print(existing_item)
            if not existing_item:
                existing_item = PlantMachineryWorkOrderItems.objects.create(plant_machinery_work_order=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_items:
            if existing_item.id not in [item_data.get('id') for item_data in work_order_item_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
        for item_data in work_order_expense_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_expense if item.id == item_id), None)

            if not existing_item:
                existing_item = PlantMachineryWorkOrderExpenseDetails.objects.create(plant_machinery_work_order=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_expense:
            if existing_item.id not in [item_data.get('id') for item_data in work_order_expense_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()
                       
        self.calculate_totals(instance)
        
        for item_data in work_order_tax_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_taxes if item.id == item_id), None)

            if not existing_item:
                existing_item = PlantMachineryWorkOrderTaxDetails.objects.create(plant_machinery_work_order=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_taxes:
            if existing_item.id not in [item_data.get('id') for item_data in work_order_tax_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()  
        for item_data in work_order_payment_schedule_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_payment_schedule if item.id == item_id), None)

            if not existing_item:
                existing_item = PlantMachineryWorkOrderPaymentSchedule.objects.create(plant_machinery_work_order=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_payment_schedule:
            if existing_item.id not in [item_data.get('id') for item_data in work_order_payment_schedule_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()    
        for item_data in work_order_delivery_location_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_delivery_location if item.id == item_id), None)

            if not existing_item:
                existing_item = PlantMachineryWorkOrderDeliveryLocation.objects.create(plant_machinery_work_order=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_delivery_location:
            if existing_item.id not in [item_data.get('id') for item_data in work_order_delivery_location_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()   

                         
        self.calculate_totals(instance)
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        work_order_items_data = representation.pop('work_order_items', [])
        representation['work_order_items'] = work_order_items_data
        work_order_tax_data = representation.pop('work_order_tax', [])
        representation['work_order_tax'] = work_order_tax_data
        work_order_expense_data = representation.pop('work_order_expense', [])
        representation['work_order_expense'] = work_order_expense_data
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data
        work_order_tnc_data = representation.pop('work_order_tnc', [])
        representation['work_order_tnc'] = work_order_tnc_data
        work_order_payment_schedule_data = representation.pop('work_order_payment_schedule', [])
        representation['work_order_payment_schedule'] = work_order_payment_schedule_data
        work_order_delivery_location_data = representation.pop('work_order_delivery_location', [])
        representation['work_order_delivery_location'] = work_order_delivery_location_data

        return representation

    class Meta:
        model = PlantMachineryWorkOrder
        fields = '__all__'

class PlantMachineryMajorActivitySerializer(serializers.ModelSerializer):

    class Meta:
        model = PlantMachineryMajorActivity
        fields = "__all__"


class PlantMachineryMajorActivityAchievedSerializer(serializers.ModelSerializer):
    created_by_details = serializers.SerializerMethodField()

    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    class Meta:
        model = PlantMachineryMajorActivityAchieved
        fields = "__all__"

class PlantMachineryUtilizationBudgetSerializer(serializers.ModelSerializer):
    project_details = serializers.SerializerMethodField()
    plant_machinery_group_details = serializers.SerializerMethodField()
    budget_master_details = serializers.SerializerMethodField()

    def get_project_details(self, instance):
        return get_details_from_instance(instance.project,extras=[], type="dict")

    def get_plant_machinery_group_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_group,extras=[], type="dict")

    def get_budget_master_details(self, instance):
      
        return get_details_from_instance( instance.budget_master,extras=[], type="dict")
    
    class Meta:
        model = PlantMachineryUtilizationBudget
        fields = "__all__"
        
class PlantMachineryTaxInvoiceSerializer(serializers.ModelSerializer):
    project_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    plant_machinery_machine_details = serializers.SerializerMethodField()
    tax_head_details = serializers.SerializerMethodField()

    def get_project_details(self, instance):
        return get_details_from_instance(instance.project, extras=[], type="dict")

    def get_site_details(self, instance):
        return get_details_from_instance(instance.site, extras=[], type="dict")

    def get_store_details(self, instance):
        return get_details_from_instance(instance.store, extras=[], type="dict")

    def get_plant_machinery_machine_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_machine, extras=[], type="dict")

    def get_tax_head_details(self, instance):
        return get_details_from_instance(instance.tax_head, extras=[], type="dict")

    class Meta:
        model = PlantMachineryTaxInvoice
        fields = "__all__"        


class PlantMachineryHireBillInvoiceStagesSerializer(serializers.ModelSerializer):
    """
    PlantMachineryHireBillInvoice Serializer
    """
    id = serializers.IntegerField(required=False)
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    
    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    
    class Meta:
        model = PlantMachineryHireBillInvoiceStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryHireBillInvoiceAttachmentsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = PlantMachineryHireBillInvoiceAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer 

class PlantMachineryHireBillInvoiceItemSerializer(serializers.ModelSerializer):
    attachments = PlantMachineryHireBillInvoiceAttachmentsSerializer(
        many=True, required=False, source="plant_machinery_hire_bill_invoice_attachments"
    )
    id = serializers.IntegerField(required=False)
    tax_invoice_details = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryHireBillInvoiceItem
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer 

    def get_tax_invoice_details(self, instance):
      
        if instance.tax_invoice and not getattr(instance.tax_invoice, "is_deleted", False):
        
            log_book__total_breakdown_days = 0
            if (instance.tax_invoice.plant_machinery_machine and instance.tax_invoice.from_date and instance.tax_invoice.to_date):
                log_book__total_breakdown_days = (
                PlantMachineryLogBook.cmobjects.filter(
                    plant_machinery_machine_id=instance.tax_invoice.plant_machinery_machine_id,
                    log_book_date__gte=instance.tax_invoice.from_date,
                    log_book_date__lte=instance.tax_invoice.to_date,
                )
                .annotate(
                    day_running=Case(
                        When(in_service='Breakdown', then=Value(1)),
                        default=Value(0),
                        output_field=IntegerField(),
                    )
                )
                .aggregate(
                    total=Coalesce(Sum('day_running'), Value(0))
                )['total']
            )
            return {
                'plant_machinery_machine_id': instance.tax_invoice.plant_machinery_machine.id if instance.tax_invoice.plant_machinery_machine else None,
                'plant_machinery_machine__equipment_description': instance.tax_invoice.plant_machinery_machine.equipment_description if instance.tax_invoice.plant_machinery_machine else None,
                'plant_machinery_machine__machine_number': instance.tax_invoice.plant_machinery_machine.machine_number if instance.tax_invoice.plant_machinery_machine else None,
                'work_order_number': instance.tax_invoice.work_order_number,
                'plant_machinery_machine__vendor_code': instance.tax_invoice.plant_machinery_machine.vendor.vendor_code if instance.tax_invoice.plant_machinery_machine and instance.tax_invoice.plant_machinery_machine.vendor else None,
                'plant_machinery_machine__vendor_name': instance.tax_invoice.plant_machinery_machine.vendor.vendor_name if instance.tax_invoice.plant_machinery_machine and instance.tax_invoice.plant_machinery_machine.vendor else None,
                'invoice_date': instance.tax_invoice.invoice_date,
                'invoice_number': instance.tax_invoice.invoice_number,
                'from_date': instance.tax_invoice.from_date,
                'to_date': instance.tax_invoice.to_date,
                'request_code': instance.tax_invoice.request_code,
                'log_book__total_breakdown_days':log_book__total_breakdown_days,
            }
        return None
class PlantMachineryHireBillInvoiceSerializer(serializers.ModelSerializer):
    stages = PlantMachineryHireBillInvoiceStagesSerializer(many=True, required=False, source="plant_machinery_hire_bill_invoice_stages")
    items = PlantMachineryHireBillInvoiceItemSerializer(
        many=True, source='plant_machinery_hire_bill_invoice_item'
    )
    project_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    multi_stage_details = serializers.SerializerMethodField()
    status_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None 
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)

    def get_status_details(self, instance):
        return multi_stage_status_details(instance, self.get_multi_stage_details(instance), 'pending')
    
    def get_project_details(self, instance):
        return get_details_from_instance(instance.project, extras=[], type="dict")

    def get_site_details(self, instance):
        return get_details_from_instance(instance.site, extras=[], type="dict")

    def get_store_details(self, instance):
        return get_details_from_instance(instance.store, extras=[], type="dict")
    
    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('plant_machinery_hire_bill_invoice_item', [])
        invoice = PlantMachineryHireBillInvoice.objects.create(**validated_data)
        current_user = invoice.created_by if invoice.created_by else None
        invoice.save()
        for item_data in items_data:
            attachments_data = item_data.pop('plant_machinery_hire_bill_invoice_attachments', [])
            item = PlantMachineryHireBillInvoiceItem.objects.create(
                plant_machinery_hire_bill_invoice=invoice, created_by=current_user, **item_data
            )

            for attachment_data in attachments_data:
                PlantMachineryHireBillInvoiceAttachments.objects.create(
                    organization=invoice.organization,
                    plant_machinery_hire_bill_invoice_item=item,
                    attachment=process_attachments(attachment_data),
                    mime_type="",
                    file_data="",
                    attachment_name=attachment_data.get('attachment_name', ''),
                    type=attachment_data.get('type'),
                    created_by=current_user
                )

        return invoice

    @transaction.atomic
    def update(self, instance, validated_data):
        items_data = validated_data.pop('plant_machinery_hire_bill_invoice_item', [])
        current_user = instance.updated_by if instance.updated_by else None

        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])
        instance.save()

        existing_items = list(instance.plant_machinery_hire_bill_invoice_item.filter(is_deleted=False))
        for item_data in items_data:
            item_id = item_data.get('id')
            attachments_data = item_data.pop('plant_machinery_hire_bill_invoice_attachments', [])
            existing_item = next((i for i in existing_items if i.id == item_id), None)

            if existing_item:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                existing_item.updated_by = current_user
                existing_item.save()
            else:
                existing_item = PlantMachineryHireBillInvoiceItem.objects.create(
                    plant_machinery_hire_bill_invoice=instance, created_by=current_user, **item_data
                )

            # Handle attachments per item
            existing_attachments = list(existing_item.plant_machinery_hire_bill_invoice_attachments.filter(is_deleted=False))
            for attachment_data in attachments_data:
                attachment_id = attachment_data.get('id')
                existing_attachment = next((a for a in existing_attachments if a.id == attachment_id), None)
                if existing_attachment:
                    if attachment_data.get('attachment'):
                        existing_attachment.attachment = process_attachments(attachment_data)
                    existing_attachment.attachment_name = attachment_data.get('attachment_name', existing_attachment.attachment_name)
                    existing_attachment.type = attachment_data.get('type', existing_attachment.type)
                    existing_attachment.updated_by = current_user
                    existing_attachment.save()
                else:
                    PlantMachineryHireBillInvoiceAttachments.objects.create(
                        organization=instance.organization,
                        plant_machinery_hire_bill_invoice_item=existing_item,
                        attachment=process_attachments(attachment_data),
                        mime_type='',
                        file_data='',
                        attachment_name=attachment_data.get('attachment_name', ''),
                        type=attachment_data.get('type'),
                        created_by=current_user
                    )
            for existing_attachment in existing_attachments:
                if existing_attachment.id not in [item.get('id') for item in attachments_data]:
                    setattr(existing_attachment, 'is_deleted', True)
                    setattr(existing_attachment, 'updated_by', current_user)
                    existing_attachment.save()   
       
        return instance

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        # rep['items'] = [
        #     {
        #         **i,
        #         'attachments': i.get('attachments', [])
        #     }
        #     for i in rep.get('items', [])
        # ]
        return rep

    class Meta:
        model = PlantMachineryHireBillInvoice
        fields = '__all__'


class PlantMachineryHSDApprovalStagesSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    
    # approved_by
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    
    class Meta:
        model = PlantMachineryHSDApprovalStages
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryHSDApprovalItemSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    plant_machinery_machine_details = serializers.SerializerMethodField()
    last_approved_requirement = serializers.SerializerMethodField()
    total_hrs_kms = serializers.SerializerMethodField()
    fuel_issued = serializers.SerializerMethodField()
    uom = serializers.SerializerMethodField()
    standard_avg = serializers.SerializerMethodField()
    actual_avg = serializers.SerializerMethodField()
    total_days = serializers.SerializerMethodField()
    total_requirement = serializers.SerializerMethodField()

    def ref_log_book_data(self, instance, field):
        resp = None
        log_book_data = PlantMachineryLogBook.cmobjects.values(
            'plant_machinery_machine__id',
            'plant_machinery_machine__machine_number',
            'plant_machinery_machine__equipment_description',
            'plant_machinery_machine__registration_no',
            'plant_machinery_machine__machine_info_standard_norms_ltr_km',
            'plant_machinery_machine__hsd_norms_uom__symbol',
            'plant_machinery_machine__plant_machinery_group__machine_type',
            'project',
        ).annotate(
            start_reading=Min(Case(
                When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=F('start_hrs')),
                default=F('start_kms'),
                output_field=FloatField()
            )),
            close_reading=Max(Case(
                When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=F('close_hrs')),
                default=F('close_kms'),
                output_field=FloatField()
            )),
            avg_standard_norms=Coalesce(Avg('standard_norms', output_field=models.FloatField()), Value(0), output_field=FloatField()),
            sum_total_fuel_filled=Coalesce(Sum('total_fuel_filled', output_field=models.FloatField()), Value(0), output_field=FloatField()),
            sum_total_production_qty_cum=Coalesce(Sum((F('total_production_qty_ton')*1.133)+F('total_production_qty_cum'), output_field=models.FloatField()), Value(0), output_field=FloatField()),
            sum_number_of_trips=Coalesce(Sum('number_of_trips', output_field=models.FloatField()), Value(0), output_field=FloatField()),
            sum_plan=Coalesce(Sum(Case(
                When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=F('plan_hrs')),
                default=F('plan_km'),
                output_field=FloatField()
            )), Value(0), output_field=FloatField()),
            total_reading=ExpressionWrapper(F('close_reading')-F('start_reading'), output_field=models.FloatField()),
            avg_actual_norms=Case(
                When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=Case(
                    When(total_reading=0, then=Value(0)),
                    default=(F('sum_total_fuel_filled')/F('total_reading')),
                    output_field=FloatField()
                )),
                default=Case(
                    When(sum_total_fuel_filled=0, then=Value(0)),
                    default=(F('total_reading')/F('sum_total_fuel_filled')),
                    output_field=FloatField()
                ),
                output_field=FloatField()
            ),
            deviation=ExpressionWrapper((F('plant_machinery_machine__machine_info_standard_norms_ltr_km')-F('avg_actual_norms')), output_field=models.FloatField()),
            utilization=ExpressionWrapper(((F('total_reading')/F('sum_plan'))*100), output_field=models.FloatField()),
        ).filter(
            log_book_date__gte=instance.from_date,
            log_book_date__lte=instance.to_date,
            plant_machinery_machine_id=instance.plant_machinery_machine.id,
            project_id=instance.hsd_approval.project.id,
            site_id=instance.hsd_approval.site.id,
            # location_id=instance.hsd_approval.store.id,
        ).values(field)
        if log_book_data:
            resp = log_book_data[0][field]
        return resp
    
    def get_last_approved_requirement(self, instance):
        temp = PlantMachineryHSDApprovalItem.cmobjects.exclude(pk=instance.id).filter(
            hsd_approval__is_deleted=False,
            hsd_approval__status='approved',
            to_date__lte=instance.from_date,
            plant_machinery_machine_id=instance.plant_machinery_machine.id,
            hsd_approval__project_id=instance.hsd_approval.project.id,
            hsd_approval__site_id=instance.hsd_approval.site.id,
            # hsd_approval__store_id=instance.hsd_approval.store.id,
        ).annotate(
            tot_req=F('requirement_per_day')*ExpressionWrapper(
                    date_diff_handle(F('to_date'), F('from_date')),
                    output_field=FloatField()
                ),
        ).order_by('-to_date').first()
        return temp.tot_req if temp else 0
    
    def get_total_hrs_kms(self, instance):
        return self.ref_log_book_data(instance, 'total_reading')
    
    def get_fuel_issued(self, instance):
        return self.ref_log_book_data(instance, 'sum_total_fuel_filled')
    
    def get_uom(self, instance):
        return self.ref_log_book_data(instance, 'plant_machinery_machine__hsd_norms_uom__symbol')
    
    def get_standard_avg(self, instance):
        return self.ref_log_book_data(instance, 'avg_standard_norms')
    
    def get_actual_avg(self, instance):
        return self.ref_log_book_data(instance, 'avg_actual_norms')
    
    def get_total_days(self, instance):
        total_days = 0
        if instance.from_date and instance.to_date:
            temp = instance.to_date-instance.from_date
            total_days = temp.days
        return total_days
    
    def get_total_requirement(self, instance):
        return (self.get_total_days(instance)*instance.requirement_per_day)
    
    def get_plant_machinery_machine_details(self, instance):
        return get_details_from_instance(instance.plant_machinery_machine, extras=[], type="dict")
    class Meta:
        model = PlantMachineryHSDApprovalItem
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
class PlantMachineryHSDApprovalAttachmentSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)  
    class Meta:
        model = PlantMachineryHSDApprovalAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class PlantMachineryHSDApprovalSerializer(serializers.ModelSerializer):
    stages = PlantMachineryHSDApprovalStagesSerializer(
        many=True,
        required=False,
        source='hsd_approval_plant_machinery_hsd_approval_stages'
    )
    items = PlantMachineryHSDApprovalItemSerializer(
        many=True,
        required=False,
        source='hsd_approval_plant_machinery_hsd_approval_item'
    )
    attachments = PlantMachineryHSDApprovalAttachmentSerializer(
        many=True,
        required=False,
        source='hsd_approval_plant_machinery_hsd_approval_attachment'
    )
    project_details = serializers.SerializerMethodField()
    site_details = serializers.SerializerMethodField()
    store_details = serializers.SerializerMethodField()
    organization_details = serializers.SerializerMethodField()
    created_by_details = serializers.SerializerMethodField()
    checked_by_details = serializers.SerializerMethodField()
    cancelled_by_details = serializers.SerializerMethodField()
    close_by_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    multi_stage_details = serializers.SerializerMethodField()
    status_details = serializers.SerializerMethodField()
    total_petrol = serializers.SerializerMethodField()
    total_hsd = serializers.SerializerMethodField()
    grand_total = serializers.SerializerMethodField()
    class Meta:
        model = PlantMachineryHSDApproval
        fields = '__all__'
    
    def get_total_petrol(self, instance):
        temp = instance.hsd_approval_plant_machinery_hsd_approval_item.filter(plant_machinery_machine__machine_info_fuel_type='Petrol').annotate(
            tot_req=F('requirement_per_day')*ExpressionWrapper(
                    date_diff_handle(F('to_date'), F('from_date')),
                    output_field=FloatField()
                ),
        ).aggregate(Sum('tot_req'))['tot_req__sum']
        return float(temp) if temp else 0.0
    
    def get_total_hsd(self, instance):
        temp = instance.hsd_approval_plant_machinery_hsd_approval_item.filter(plant_machinery_machine__machine_info_fuel_type='Diesel').annotate(
            tot_req=F('requirement_per_day')*ExpressionWrapper(
                    date_diff_handle(F('to_date'), F('from_date')),
                    output_field=FloatField()
                ),
        ).aggregate(Sum('tot_req'))['tot_req__sum']
        return float(temp) if temp else 0.0
    
    def get_grand_total(self, instance):
        return (self.get_total_petrol(instance)*instance.fuel_rate_petrol)+(self.get_total_hsd(instance)*instance.fuel_rate_hsd)
    
    def get_multi_stage_details(self, instance):
        return multi_stage_stage_details(instance)

    def get_status_details(self, instance):
        return multi_stage_status_details(instance, self.get_multi_stage_details(instance), 'checked')
    
    def get_project_details(self, instance):
        project = instance.project
        if project and not getattr(project, "is_deleted", False):
            return get_project_data(instance.project.id)
        return None
    def get_site_details(self, instance):
        return get_details_from_instance(instance.site,extras=[], type="dict") 
    def get_store_details(self, instance):
        return get_details_from_instance(instance.store,extras=[], type="dict")
    def get_organization_details(self, instance):
        key_list = get_details_from_instance(instance.organization)
        city_name = None
        if instance.organization and instance.organization.org_city:
            city_obj = get_details_from_instance(instance.organization.org_city, type="dict")
            city_name = city_obj['name'] if city_obj else None
        state_name = None
        if instance.organization and instance.organization.org_state:
            state_obj = get_details_from_instance(instance.organization.org_state, type="dict")
            state_name = state_obj['name'] if state_obj else None
        country_name = None
        if instance.organization and instance.organization.org_country:
            country_obj = get_details_from_instance(instance.organization.org_country, type="dict")
            country_name = country_obj['name'] if country_obj else None

        address = f"{city_name} {state_name} {country_name}"
        key_list.append({'organization_address': address})
        return key_list
    def get_created_by_details(self, instance):
        details = None
        if instance.created_by :
            details = []
            details.append({
                "first_name": instance.created_by.first_name,
                "last_name": instance.created_by.last_name,
                "email": instance.created_by.email,

            })
        return details
    
    def get_checked_by_details(self, instance):
        details = None
        if instance.checked_by :
            details = []
            details.append({
                "first_name": instance.checked_by.first_name,
                "last_name": instance.checked_by.last_name,
                "email": instance.checked_by.email,

            })
        return details
    
    def get_cancelled_by_details(self, instance):
        details = None
        if instance.cancelled_by :
            details = []
            details.append({
                "first_name": instance.cancelled_by.first_name,
                "last_name": instance.cancelled_by.last_name,
                "email": instance.cancelled_by.email,

            })
        return details
    
    
    def get_close_by_details(self, instance):
        details = None
        if instance.close_by :
            details = []
            details.append({
                "first_name": instance.close_by.first_name,
                "last_name": instance.close_by.last_name,
                "email": instance.close_by.email,

            })
        return details
    
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by :
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,

            })
        return details
    
    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by :
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,

            })
        return details
    @transaction.atomic
    def create(self, validated_data):
        items_data = validated_data.pop('hsd_approval_plant_machinery_hsd_approval_item', [])
        attachments_data = validated_data.pop('hsd_approval_plant_machinery_hsd_approval_attachment', [])

        hsd_approval = PlantMachineryHSDApproval.objects.create(**validated_data)
        current_user = hsd_approval.created_by if hsd_approval.created_by else None

        for item_data in items_data:
            item_instance=PlantMachineryHSDApprovalItem.objects.create(
                **item_data,
                hsd_approval=hsd_approval,
                created_by=current_user,
            )
            item_instance.save()
        for attachment_data in attachments_data:
            processed_attachment = process_attachments(attachment_data)
            attachment_data.pop('mime_type',None)
            attachment_data.pop('file_data', None)
            print(processed_attachment)
            PlantMachineryHSDApprovalAttachments.objects.create(
                **attachment_data,
                hsd_approval=hsd_approval,
                attachment=processed_attachment if processed_attachment else None,
                created_by=current_user,
            )    
        return hsd_approval

    @transaction.atomic
    def update(self, instance, validated_data):
        items_data = validated_data.pop('hsd_approval_plant_machinery_hsd_approval_item', [])
        attachments_data = validated_data.pop('hsd_approval_plant_machinery_hsd_approval_attachment', [])
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
       
        instance.save()

        current_user = instance.updated_by if instance.updated_by else None
        existing_items = instance.hsd_approval_plant_machinery_hsd_approval_item.filter(is_deleted=False)

        for item_data in items_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_items if item.id == item_id), None)

            if existing_item:
                for attr, value in item_data.items():
                    setattr(existing_item, attr, value)
                existing_item.updated_by = current_user
                existing_item.save()
            else:
                item_instance=PlantMachineryHSDApprovalItem.objects.create(
                    **item_data,
                    hsd_approval=instance,
                    created_by=current_user,
                )

        for existing_item in existing_items:
            if existing_item.id not in [item.get('id') for item in items_data]:
                existing_item.is_deleted = True
                existing_item.updated_by = current_user
                existing_item.save()
        existing_attachments = instance.hsd_approval_plant_machinery_hsd_approval_attachment.filter(is_deleted=False)
        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            processed_attachment = process_attachments(attachment_data)

            existing_attachment = next((att for att in existing_attachments if att.id == attachment_id), None)

            if existing_attachment:
                for attr, value in attachment_data.items():
                    setattr(existing_attachment, attr, value)
                if processed_attachment:
                    existing_attachment.attachment = processed_attachment
                    existing_attachment.file_data = ""
                    existing_attachment.mime_type = ""
                existing_attachment.updated_by = current_user
                existing_attachment.save()
            else:
                attachment_data.pop('mime_type', "")
                attachment_data.pop('file_data', "")
                PlantMachineryHSDApprovalAttachments.objects.create(
                    **attachment_data,
                    hsd_approval=instance,
                    attachment=processed_attachment if processed_attachment else None,
                    created_by=current_user,
                )

        # for existing_attachment in existing_attachments:
        #     if existing_attachment.id not in [att.get('id') for att in attachments_data]:
        #         existing_attachment.is_deleted = True
        #         existing_attachment.updated_by = current_user
        #         existing_attachment.save()

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['items'] = representation.pop('items', [])
        representation['attachments'] = representation.pop('attachments', [])
        stages_data = representation.pop('stages', [])
        representation['stages'] = stages_data

        return representation
