from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from .models import *
from procurement.models import MultiStageSetting, MultiStageSettingStages
# Register your models here.
@admin.register(PlantMachineryMaster)
class PlantMachineryMaster(ModelAdmin):
    list_display = ('id', 'is_deleted',)

@admin.register(PlantMachineryData)
class PlantMachineryData(ModelAdmin):
    pass

@admin.register(PlantMachinery)
class PlantMachinery(ModelAdmin):
    list_display = ('id','equipment_description','uom_productivity','hsd_norms_uom', 'is_deleted')

@admin.register(PlantMachineryGroup)
class PlantMachineryGroupAdmin(ModelAdmin):
    list_display = ('id','name','parent', 'is_deleted')

@admin.register(PlantMachineryDpr)
class PlantMachineryDpr(ModelAdmin):
    list_display = ('id', 'master', 'is_deleted')

@admin.register(PlantMachineryDprMaster)
class PlantMachineryDprMaster(ModelAdmin):
    list_display = ('id', 'organization','site','project', 'is_deleted')

@admin.register(PlantMachineryDprNew)
class PlantMachineryDprNew(ModelAdmin):
    list_display = ('id','dpr_master','plant_machinery_machine','organization','site','project', 'is_deleted')

class PlantMachineryDocumentUploadAdmin(StackedInline):
    model = PlantMachineryDocumentUpload
    fk_name = 'plant_machinery_document_upload_master'

@admin.register(PlantMachineryDocumentUploadMaster)
class PlantMachineryDocumentUploadMasterAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine', 'plant_machinery_group',  'is_deleted']
    inlines = [PlantMachineryDocumentUploadAdmin]   
@admin.register(PlantMachineryServiceGroup)
class PlantMachineryServiceGroupAdmin(ModelAdmin):
    list_display = ['organization', 'name',  'is_deleted']
@admin.register(PlantMachineryServiceItem)
class PlantMachineryServiceItemAdmin(ModelAdmin):
    list_display = ['organization','plant_machinery_service_group','name', 'is_deleted']    
@admin.register(PlantMachineryMachine)
class PlantMachineryMachineAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_group','owner_type', 'equipment_description',  'is_deleted']
@admin.register(PlantMachineryMachineServices)
class PlantMachineryMachineServicesAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine',  'is_deleted']

@admin.register(PlantMachineryMachineTransfer)
class PlantMachineryMachineTransferAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine',  'is_deleted']
@admin.register(PlantMachineryMachineDriver)
class PlantMachineryMachineDriverAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine', 'name', 'is_deleted']
@admin.register(PlantMachineryMachineRent)
class PlantMachineryMachineRentAdmin(ModelAdmin):
    list_filter = ['is_deleted']
    search_fields = ('plant_machinery_machine__equipment_description',)
    list_display = ['organization', 'plant_machinery_machine', 'rent_amount','rent_date', 'is_deleted']    

@admin.register(PlantMachineryMachineDepreciation)
class PlantMachineryMachineDepreciationAdmin(ModelAdmin):
    list_filter = ['is_deleted']
    search_fields = ('plant_machinery_machine__equipment_description',)
    list_display = ['organization', 'plant_machinery_machine', 'amount','date', 'to_date','is_deleted']     
@admin.register(PlantMachineryInactiveType)
class PlantMachineryInactiveTypeAdmin(ModelAdmin):
    list_display = ['organization', 'name',  'is_deleted']

@admin.register(PlantMachineryTruckAccount)
class PlantMachineryTruckAccountAdmin(ModelAdmin):
    list_display = ['organization', 'name',  'is_deleted']    
@admin.register(PlantMachineryTdsType)
class PlantMachineryTdsTypeAdmin(ModelAdmin):
    list_display = ['organization', 'name',  'is_deleted']  
@admin.register(PlantMachineryServiceSchedule)
class PlantMachineryServiceScheduleAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_group', 'plant_machinery_service_group', 'plant_machinery_service_item','is_deleted']      

@admin.register(PlantMachineryMachineMaintenanceItemGroup)
class PlantMachineryMachineMaintenanceItemGroupAdmin(ModelAdmin):
    list_display = ['organization', 'is_deleted']    

@admin.register(PlantMachineryJobSheet)
class PlantMachineryJobSheetAdmin(ModelAdmin):
    list_display = ['id', 'organization_id', 'jobsheet_number', 'plant_machinery_group', 'plant_machinery_service_group', 'is_deleted']
    search_fields = ('jobsheet_number',)
    
@admin.register(PlantMachineryJobSheetService)
class PlantMachineryJobSheetServiceAdmin(ModelAdmin):
    list_display = ['id', 'organization_id', 'plant_machinery_job_sheet',  'is_deleted']
  
@admin.register(PlantMachineryMachineMaintenanceItemServiceGroup)
class PlantMachineryMachineMaintenanceItemServiceGroupAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_service_group']    

@admin.register(PlantMachineryMeterResetLog)
class PlantMachineryMeterResetLogAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine','is_deleted' ] 


@admin.register(PlantMachineryTyre)
class PlantMachineryTyreAdmin(ModelAdmin):
    list_display = ['id','organization', 'plant_machinery_group','is_deleted' ] 



class PlantMachineryLogBookWbsChainageAdmin(StackedInline):
    model = PlantMachineryLogBookWbsChainage
    fk_name = 'plant_machinery_log_book'
@admin.register(PlantMachineryLogBook)
class PlantMachineryLogBookAdmin(ModelAdmin):
    list_filter = ['in_service', 'is_deleted']
    list_display = ['id','organization','project','site','plant_machinery_group','plant_machinery_machine','log_book_date', 'owner','start_hrs','start_kms','in_service','plan_hrs','plan_km','is_deleted']
    inlines = (PlantMachineryLogBookWbsChainageAdmin,)
    search_fields = ('plant_machinery_machine__equipment_description',)
admin.site.register(PlantMachineryLogBookWbsChainage,ModelAdmin)


@admin.register(PlantMachineryInsuranceMaster)
class PlantMachineryInsuranceMasterAdmin(ModelAdmin):
    list_display = ('id','insurance_head_name','insurance_head_short_name','parent','plant_machinery_machine', 'is_deleted')


@admin.register(PlantMachineryDocumentUpload)
class PlantMachineryDocumentUploadAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_document_upload_master',  'is_deleted']


##Machine working start ##
@admin.register(PlantMachineryMachineWorking)
class PlantMachineryMachineWorkingAdmin(ModelAdmin):
    list_display = ['organization','plant_machinery_machine' , 'plant_machinery_group', 'is_deleted']
@admin.register(PlantMachineryMachineWorkingMeterReset)
class PlantMachineryMachineWorkingMeterResetAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine', 'plant_machinery_machine_working', 'is_deleted']    
@admin.register(PlantMachineryMachineWorkingFuelIssue)
class PlantMachineryMachineWorkingFuelIssueAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine', 'plant_machinery_machine_working', 'is_deleted'] 
@admin.register(PlantMachineryMachineWorkingChild)
class PlantMachineryMachineWorkingChildAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine', 'plant_machinery_machine_working', 'is_deleted']           
@admin.register(PlantMachineryMachineWorkingIdleBd)
class PlantMachineryMachineWorkingIdleBdAdmin(ModelAdmin):
    list_display = ['organization', 'plant_machinery_machine', 'plant_machinery_machine_working', 'is_deleted']           
##end##

@admin.register(PlantMachineryObjectiveIndicationType)
class PlantMachineryObjectiveIndicationTypeAdmin(ModelAdmin):
    list_display = ['organization', 'name','type',  'is_deleted']   

@admin.register(PlantMachineryManpower)
class PlantMachineryManpowerAdmin(ModelAdmin):
    list_display = ['organization', 'employee_id','designation','is_deleted']     


class PlantMachineryActivityGroupItemsAdmin(StackedInline):
    model = PlantMachineryActivityGroupItems
    fk_name = 'plant_machinery_activity_group'
@admin.register(PlantMachineryActivityGroup)
class PlantMachineryActivityGroupAdmin(ModelAdmin):
    list_display = ['code', 'is_deleted']
    inlines = (PlantMachineryActivityGroupItemsAdmin,)

@admin.register(PlantMachineryActivityGroupItems)
class PlantMachineryActivityGroupItemsAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'organization', 'plant_machinery_activity_group']

class PlantMachineryServiceScheduleNewChildAdmin(StackedInline):
    model = PlantMachineryServiceScheduleNewChild
    fk_name = 'plant_machinery_service_schedule'
@admin.register(PlantMachineryServiceScheduleNew)
class PlantMachineryServiceScheduleNewAdmin(ModelAdmin):
    list_display = ['id', 'plant_machinery_group', 'plant_machinery_machine', 'is_deleted']
    inlines = (PlantMachineryServiceScheduleNewChildAdmin,)


@admin.register(PlantMachineryFuelTransaction)
class PlantMachineryFuelTransactionAdmin(ModelAdmin):
    list_display = ['id', 'ref_id', 'project', 'plant_machinery_machine', 'is_deleted']
    search_fields = ['ref_type']
    list_filter = ['project', 'is_deleted']


@admin.register(PlantMachineryNotifications)
class PlantMachineryNotificationsAdmin(ModelAdmin):
    list_display = ['id', 'ref_type', 'ref_id', 'is_deleted']
    search_fields = ('ref_type', 'ref_id',)


@admin.register(PlantMachineryMIS)
class PlantMachineryMISAdmin(ModelAdmin):
    list_display = ['id', 'type']


@admin.register(PlantMachineryHireBill)
class PlantMachineryHireBillAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted']

@admin.register(PlantMachineryBattery)
class PlantMachineryBatteryAdmin(ModelAdmin):
    list_display = ['id','organization', 'plant_machinery_group','is_deleted' ] 


@admin.register(PlantMachineryComplianceMasterNew)
class PlantMachineryComplianceMasterNewAdmin(ModelAdmin):
    list_display = ['id','project','plant_machinery_group','site','employee_id','is_deleted']
    list_filter = ['is_deleted']
    search_fields = ('employee_id',)

class PlantMachineryComplianceMasterDetailAdmin(StackedInline):
    model = PlantMachineryComplianceMasterDetail
    fk_name = 'compliance_master'
@admin.register(PlantMachineryComplianceMaster)
class PlantMachineryComplianceMasterAdmin(ModelAdmin):
    list_display = ['id','name' ,'is_deleted']
    inlines = (PlantMachineryComplianceMasterDetailAdmin,)    

class PlantMachineryComplianceReportItemAdmin(StackedInline):
    model = PlantMachineryComplianceReportItem
    fk_name = 'compliance_report'
@admin.register(PlantMachineryComplianceReport)
class PlantMachineryComplianceReportAdmin(ModelAdmin):
    list_display = ['id','project', 'plant_machinery_machine','is_deleted']
    inlines = (PlantMachineryComplianceReportItemAdmin,)        

@admin.register(PlantMachineryComplianceReportItem)
class PlantMachineryComplianceReportItemAdmin(ModelAdmin):
    list_display = ['id','organization', 'compliance_report','is_deleted' ] 


@admin.register(PlantMachineryCallibrationReport)
class PlantMachineryCallibrationReportAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','callibration_type','is_deleted' ] 

@admin.register(PlantMachineryBudgetMaster)
class PlantMachineryBudgetMasterAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','name','is_deleted' ] 

@admin.register(PlantMachineryMachineBudget)
class PlantMachineryMachineBudgetAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','plant_machinery_group','budget_master','is_deleted' ] 

@admin.register(PlantMachineryElectricityBudget)
class PlantMachineryElectricityBudgetAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','budget_master','is_deleted' ]     

@admin.register(PlantMachineryFuelBudget)
class PlantMachineryFuelBudgetAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','budget_master','fuel_type','is_deleted' ]        

class PlantMachineryElectricityEntryAttachmentAdmin(StackedInline):
    model = PlantMachineryElectricityEntryAttachment
    fk_name = 'electricity_entry'
@admin.register(PlantMachineryElectricityEntry)
class PlantMachineryElectricityEntryAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','date','is_deleted' ]     
    inlines = (PlantMachineryElectricityEntryAttachmentAdmin,)        


class PlantMachineryHsdIssuedReportItemAdmin(StackedInline):
    model = PlantMachineryHsdIssuedReportItem
    fk_name = 'plant_machinery_hsd_issued_report'
@admin.register(PlantMachineryHsdIssuedReport)
class PlantMachineryHsdIssuedReportAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','start_date','end_date','is_deleted' ]
    inlines = (PlantMachineryHsdIssuedReportItemAdmin,) 
@admin.register(PlantMachineryRepair)
class PlantMachineryRepairAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','plant_machinery_machine','is_deleted' ]

@admin.register(PlantMachineryRepairBudget)
class PlantMachineryRepairBudgetAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','budget_master','date','is_deleted' ]

class PlantMachineryAssetRequisitionItemAdmin(StackedInline):
    model = PlantMachineryAssetRequisitionItem
    fk_name = 'asset_requisition'

class PlantMachineryAssetRequisitionAttachmentsAdmin(StackedInline):
    model = PlantMachineryAssetRequisitionAttachments
    fk_name = 'asset_requisition'

class PlantMachineryAssetRequisitionStagesAdmin(StackedInline):
    model = PlantMachineryAssetRequisitionStages
    fk_name = 'asset_requisition'

class AssetRequisitionIndicatorFilter(admin.SimpleListFilter):
    title = 'Indicator'
    parameter_name = 'indicator'
    def lookups(self, request, model_admin):
        return [('True', 'True'), ('False', 'False')]
    def queryset(self, request, queryset):
        ids_with_indicator = [
            instance.id for instance in queryset
            if MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.asset_requisition.ref_stage_type, employee__in=[instance.created_by_id]).exists()
        ]
        if self.value() == 'True':
            return queryset.filter(id__in=ids_with_indicator)
        if self.value() == 'False':
            return queryset.exclude(id__in=ids_with_indicator)
        return queryset

class PlantMachineryAssetRequisitionStagesAdmin2(ModelAdmin):
    list_display = ['id','asset_requisition','stage','status','is_web','created_by__username','asset_requisition__ref_stage_type__multi_stage_name','is_deleted','indicator']
    list_filter = ['is_web', 'is_deleted', AssetRequisitionIndicatorFilter]
    def indicator(self, instance):
        return MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.asset_requisition.ref_stage_type, employee__in=[instance.created_by_id]).exists()
    indicator.boolean = True
admin.site.register(PlantMachineryAssetRequisitionStages, PlantMachineryAssetRequisitionStagesAdmin2)

@admin.register(PlantMachineryAssetRequisition)
class PlantMachineryAssetRequisitionItemAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','request_code','status','is_deleted']     
    inlines = (PlantMachineryAssetRequisitionItemAdmin,PlantMachineryAssetRequisitionAttachmentsAdmin,PlantMachineryAssetRequisitionStagesAdmin)        


class PlantMachineryRFQVendorsMailListAdmin(StackedInline):
    model = PlantMachineryRFQVendorsMailList
    fk_name = 'plant_machinery_rfq_vendor' 

class PlantMachineryRFQVendorsItemsAdmin(StackedInline):
    model = PlantMachineryRFQVendorsItems
    fk_name = 'plant_machinery_rfq_vendor'  

@admin.register(PlantMachineryRFQVendors)
class PlantMachineryRFQVendorsAdmin(ModelAdmin):
    list_display = ['id', 'organization', 'project', 'request_code', 'status', 'is_deleted']
    search_fields = ['request_code', 'manual_slip_number', 'enquiry_subject']
    list_filter = ['organization', 'status', 'date']
    inlines = (PlantMachineryRFQVendorsMailListAdmin, PlantMachineryRFQVendorsItemsAdmin)  
class PlantMachineryQuotationItemsAdmin(StackedInline):
    model = PlantMachineryQuotationItems
    fk_name = 'plant_machinery_quotation'  
class PlantMachineryQuotationTermsAndConditionsAdmin(StackedInline):
    model = PlantMachineryQuotationTermsAndConditions
    fk_name = 'plant_machinery_quotation'
class PlantMachineryQuotationAttachmentsAdmin(StackedInline):
    model = PlantMachineryQuotationAttachments
    fk_name = 'plant_machinery_quotation'
    extra = 1
class PlantMachineryQuotationTaxDetailsAdmin(StackedInline):
    model = PlantMachineryQuotationTaxDetails
    fk_name = 'plant_machinery_quotation'
class PlantMachineryQuotationExpenseDetailsAdmin(StackedInline):
    model = PlantMachineryQuotationExpenseDetails
    fk_name = 'plant_machinery_quotation'
@admin.register(PlantMachineryQuotation)
class PlantMachineryQuotationAdmin(ModelAdmin):
    list_display = ['id', 'organization', 'project', 'request_code', 'vendor', 'status', 'date', 'is_deleted']
    search_fields = ['request_code', 'vendor_quotation_number', 'remarks']
    list_filter = ['organization', 'status', 'date']
    inlines = (
        PlantMachineryQuotationItemsAdmin,
        PlantMachineryQuotationTermsAndConditionsAdmin,
        PlantMachineryQuotationAttachmentsAdmin,
        PlantMachineryQuotationTaxDetailsAdmin,
        PlantMachineryQuotationExpenseDetailsAdmin
    )
class PlantMachineryCSTItemsAdmin(StackedInline):
    model = PlantMachineryCSTItems
    fk_name = 'plant_machinery_cst'  
class PlantMachineryCSTStagesAdmin(StackedInline):
    model = PlantMachineryCSTStages
    fk_name = 'plant_machinery_cst'
@admin.register(PlantMachineryCST)
class PlantMachineryCSTAdmin(ModelAdmin):
    list_display = ['id', 'organization', 'project', 'request_code', 'status', 'title', 'current_stage', 'is_deleted']
    search_fields = ['request_code', 'title', 'remarks']
    list_filter = ['organization', 'status', 'project']
    inlines = (PlantMachineryCSTItemsAdmin, PlantMachineryCSTStagesAdmin) 

class PlantMachineryCSTIndicatorFilter(admin.SimpleListFilter):
    title = 'Indicator'
    parameter_name = 'indicator'
    def lookups(self, request, model_admin):
        return [('True', 'True'), ('False', 'False')]
    def queryset(self, request, queryset):
        ids_with_indicator = [
            instance.id for instance in queryset
            if MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.plant_machinery_cst.ref_stage_type, employee__in=[instance.created_by_id]).exists()
        ]
        if self.value() == 'True':
            return queryset.filter(id__in=ids_with_indicator)
        if self.value() == 'False':
            return queryset.exclude(id__in=ids_with_indicator)
        return queryset

class PlantMachineryCSTStagesAdmin2(ModelAdmin):
    list_display = ['id','plant_machinery_cst','stage','status','is_web','created_by__username','plant_machinery_cst__ref_stage_type__multi_stage_name','is_deleted','indicator']
    list_filter = ['is_web', 'is_deleted', PlantMachineryCSTIndicatorFilter]
    def indicator(self, instance):
        return MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.plant_machinery_cst.ref_stage_type, employee__in=[instance.created_by_id]).exists()
    indicator.boolean = True
admin.site.register(PlantMachineryCSTStages, PlantMachineryCSTStagesAdmin2)

class PlantMachineryWorkOrderItemsAdmin(StackedInline):
    model = PlantMachineryWorkOrderItems
    fk_name = 'plant_machinery_work_order'  
class PlantMachineryWorkOrderTermsAndConditionsAdmin(StackedInline):
    model = PlantMachineryWorkOrderTermsAndConditions
    fk_name = 'plant_machinery_work_order'
class PlantMachineryWorkOrderTaxDetailsAdmin(StackedInline):
    model = PlantMachineryWorkOrderTaxDetails
    fk_name = 'plant_machinery_work_order'
class PlantMachineryWorkOrderExpenseDetailsAdmin(StackedInline):
    model = PlantMachineryWorkOrderExpenseDetails
    fk_name = 'plant_machinery_work_order'
class PlantMachineryWorkOrderPaymentScheduleAdmin(StackedInline):
    model = PlantMachineryWorkOrderPaymentSchedule
    fk_name = 'plant_machinery_work_order'
class PlantMachineryWorkOrderDeliveryLocationAdmin(StackedInline):
    model = PlantMachineryWorkOrderDeliveryLocation
    fk_name = 'plant_machinery_work_order'    
@admin.register(PlantMachineryWorkOrder)
class PlantMachineryWorkOrderAdmin(ModelAdmin):
    list_display = ['id', 'organization', 'project', 'request_code', 'vendor', 'status', 'date', 'is_deleted']
    search_fields = ['request_code', 'vendor_work_order_number', 'remarks']
    list_filter = ['organization', 'status', 'date']
    inlines = (
        PlantMachineryWorkOrderItemsAdmin,
        PlantMachineryWorkOrderTermsAndConditionsAdmin,
        PlantMachineryWorkOrderTaxDetailsAdmin,
        PlantMachineryWorkOrderExpenseDetailsAdmin,
        PlantMachineryWorkOrderPaymentScheduleAdmin,
        PlantMachineryWorkOrderDeliveryLocationAdmin
    )

@admin.register(PlantMachineryManpowerDesignation)
class PlantMachineryManpowerDesignationAdmin(ModelAdmin):
    list_display = ['id','name','is_deleted']
    list_filter = ['is_deleted']
    search_fields = ('name',)
    list_editable = ['name', 'is_deleted',]

@admin.register(PlantMachineryMajorActivity)
class PlantMachineryMajorActivityAdmin(ModelAdmin):
    list_display = ['id','project','major_activity','uom','project_planning','is_deleted']
    list_filter = ['is_deleted']
    search_fields = ('major_activity',)
@admin.register(PlantMachineryMajorActivityAchieved)
class PlantMachineryMajorActivityAchievedAdmin(ModelAdmin):
    list_display = ['id','plant_machinery_major_activity','achieved','date','is_deleted']
    list_filter = ['is_deleted']
    search_fields = ('plant_machinery_major_activity',)

@admin.register(PlantMachineryTaxInvoice)
class PlantMachineryTaxInvoiceAdmin(ModelAdmin):
    list_display = ['id', 'project', 'site', 'store', 'plant_machinery_machine', 'request_code', 'invoice_number', 'invoice_date', 'work_order_number', 'work_order_date', 'work_order_validity_date', 'total_tax_amount','is_deleted']
    list_filter = ['project', 'site', 'store', 'invoice_date']
    search_fields = ['invoice_number', 'request_code','plant_machinery_machine__machine_number']


class PlantMachineryHireBillInvoiceItemAdmin(StackedInline):
    model = PlantMachineryHireBillInvoiceItem
    fk_name = 'plant_machinery_hire_bill_invoice'  

class PlantMachineryHireBillInvoiceStagesAdmin(StackedInline):
    model = PlantMachineryHireBillInvoiceStages
    fk_name = 'plant_machinery_hire_bill_invoice'
@admin.register(PlantMachineryHireBillInvoice)
class PlantMachineryHireBillInvoiceAdmin(ModelAdmin):
    list_display = ['id', 'organization', 'project', 'request_code', 'status', 'current_stage', 'is_deleted']
    search_fields = ['request_code','remarks']
    list_filter = ['organization', 'status', 'project']
    inlines = (PlantMachineryHireBillInvoiceItemAdmin, PlantMachineryHireBillInvoiceStagesAdmin)

class PlantMachineryHSDApprovalItemAdmin(StackedInline):
    model = PlantMachineryHSDApprovalItem
    fk_name = 'hsd_approval'

class PlantMachineryHSDApprovalAttachmentsAdmin(StackedInline):
    model = PlantMachineryHSDApprovalAttachments
    fk_name = 'hsd_approval'

class PlantMachineryHSDApprovalStagesAdmin(StackedInline):
    model = PlantMachineryHSDApprovalStages
    fk_name = 'hsd_approval'

@admin.register(PlantMachineryHSDApproval)
class PlantMachineryHSDApprovalItemAdmin(ModelAdmin):
    list_display = ['id','organization', 'project','request_code','status','is_deleted']
    inlines = (PlantMachineryHSDApprovalItemAdmin,PlantMachineryHSDApprovalAttachmentsAdmin,PlantMachineryHSDApprovalStagesAdmin)

class PNMHireBillInvoiceIndicatorFilter(admin.SimpleListFilter):
    title = 'Indicator'
    parameter_name = 'indicator'
    def lookups(self, request, model_admin):
        return [('True', 'True'), ('False', 'False')]
    def queryset(self, request, queryset):
        ids_with_indicator = [
            instance.id for instance in queryset
            if MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.plant_machinery_hire_bill_invoice.ref_stage_type, employee__in=[instance.created_by_id]).exists()
        ]
        if self.value() == 'True':
            return queryset.filter(id__in=ids_with_indicator)
        if self.value() == 'False':
            return queryset.exclude(id__in=ids_with_indicator)
        return queryset

class PlantMachineryHireBillInvoiceStagesAdmin2(ModelAdmin):
    list_display = ['id','plant_machinery_hire_bill_invoice','stage','status','is_web','created_by__username','plant_machinery_hire_bill_invoice__ref_stage_type__multi_stage_name','is_deleted','indicator']
    list_filter = ['is_web', 'is_deleted', PNMHireBillInvoiceIndicatorFilter]
    def indicator(self, instance):
        return MultiStageSettingStages.cmobjects.filter(stage=instance.stage, multi_stage_setting=instance.plant_machinery_hire_bill_invoice.ref_stage_type, employee__in=[instance.created_by_id]).exists()
    indicator.boolean = True
admin.site.register(PlantMachineryHireBillInvoiceStages, PlantMachineryHireBillInvoiceStagesAdmin2)



