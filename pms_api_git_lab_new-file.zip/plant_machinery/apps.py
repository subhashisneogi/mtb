from django.apps import AppConfig


class PlantMachineryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'plant_machinery'
    def ready(self):
        import plant_machinery.signals