from django.db.models.signals import post_save, pre_delete, pre_save 
from django.db import transaction
from django.dispatch import receiver
# from administrations.utils import hrms_request
from .models import *
# from .serializers import *
# from .helper import *

@receiver(post_save, sender=PlantMachineryQuotation)
def signal_update_vendor_status(sender, instance, created, **kwargs):
    with transaction.atomic():
        if created and instance.plant_machinery_rfq_vendor and instance.vendor:
            PlantMachineryRFQVendorsMailList.objects.filter(plant_machinery_rfq_vendor_id=instance.plant_machinery_rfq_vendor.id,vendor_id=instance.vendor.id).update(allow_revision=False)

@receiver(post_save, sender=PlantMachineryBudgetMaster)
def trigger_notifications_created(sender, instance, created, **kwargs):
    with transaction.atomic():
        if created:
            latest_instance = sender.objects.filter(project_id=instance.project_id).order_by('-from_date','-name').first()
            sender.objects.filter(project_id=instance.project_id).exclude(pk=latest_instance.id).update(latest=False)

@receiver(post_save, sender=PlantMachineryHSDApproval)
def procurement_mark_pnmhsda_ref_stage_type(sender, instance, **kwargs):
    from procurement.helper import set_ref_stage_type_instance
    set_ref_stage_type_instance(instance,'pnmhsda')

@receiver(post_save, sender=PlantMachineryAssetRequisition)
def procurement_mark_pnmar_ref_stage_type(sender, instance, **kwargs):
    from procurement.helper import set_ref_stage_type_instance
    set_ref_stage_type_instance(instance,'pnmar')

@receiver(post_save, sender=PlantMachineryHireBillInvoice)
def procurement_mark_pnmhbi_ref_stage_type(sender, instance, **kwargs):
    from procurement.helper import set_ref_stage_type_instance
    set_ref_stage_type_instance(instance,'pnmhbi')

@receiver(post_save, sender=PlantMachineryCST)
def procurement_mark_pnmcst_ref_stage_type(sender, instance, **kwargs):
    from procurement.helper import mark_pnmcst_ref_stage_type
    mark_pnmcst_ref_stage_type(instance)

@receiver(post_save, sender=PlantMachineryQuotationItems)
def procurement_mark_pnmcst_ref_stage_type_quotation(sender, instance, **kwargs):
    from procurement.helper import mark_pnmcst_ref_stage_type
    if instance.is_selected_by_cst:
        cst_instance = PlantMachineryCST.cmobjects.filter(plant_machinery_rfq_vendor_id=instance.plant_machinery_rfq_vendor_item.plant_machinery_rfq_vendor.id,latest=True).first()
        if cst_instance:
            mark_pnmcst_ref_stage_type(cst_instance)
