import collections
import os
import pprint
import requests
import urllib3
from requests.auth import HTTPBasicAuth
import calendar
import copy
from functools import wraps , reduce
import operator

from datetime import date, timedelta , datetime, time
import threading
import logging
from procurement.helper import GroupConcat
from django.db.models import Sum, Case, When, FloatField, F, ExpressionWrapper, CharField, BooleanField, IntegerField, Min, Max, Avg, Q, Value, Count, Window, Exists, OuterRef, Subquery , DateField,Func
from django.db.models.functions import TruncMonth, Concat, LastValue, FirstValue, ExtractYear, ExtractMonth , Coalesce , TruncYear , Cast , Greatest, Least
from django.core.serializers.json import DjangoJSONEncoder
from dateutil.relativedelta import relativedelta
import numpy as np
import pandas as pd
from collections import defaultdict
import json        
import calendar
import colorama
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException
from administrations.models import *
from administrations.utils import schedule_generic_mail , trigger_notifications
from user_permissions.models import UserWiseSubModulePermissions
from .helper import *
from .models import *
from .serializers import *
from procurement.helper import custom_filters, update_query_for_user_search ,convert_to_boolean, process_filters_response , process_pnm_rfq_mail , check_editor_permissions ,check_store_site,date_diff_handle
import pandas as pd
import numpy as np
from custom_management.models import *
from procurement.models import ProjectData,MultiStageSettingStages
from boq.models import BOQ,BOQChainage,WBSList,BOQChainageExecutiveSummeryData,WbsIndirectCostPlaning
from user_permissions.models import UserWiseModulePermissions
from django.utils import timezone


# Create your views here.
class PlantMachineryMasterAPI(APIView):
    """ Plant Machinery Master API View """

    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all plant machinery master records
        """
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        form_menu_type = request.query_params.get('form_menu_type', None)
        form_group_id = request.query_params.get('form_group_id', None)
        if id:
            plant_machinery_master = PlantMachineryMaster.cmobjects.filter(id=id).first()
            if form_menu_type and form_group_id:
                serializer = PlantMachineryMasterSerializer(plant_machinery_master, context={"organization_id": organization_id, "form_menu_type": form_menu_type, "form_group_id": form_group_id})
            elif form_menu_type:
                serializer = PlantMachineryMasterSerializer(plant_machinery_master, context={"organization_id": organization_id, "form_menu_type": form_menu_type})
            elif form_group_id:
                serializer = PlantMachineryMasterSerializer(plant_machinery_master, context={"organization_id": organization_id, "form_group_id": form_group_id})
            else:
                serializer = PlantMachineryMasterSerializer(plant_machinery_master, context={"organization_id": organization_id})
            return Response(serializer.data)

        plant_machinery_master = PlantMachineryMaster.cmobjects.filter(organization_id=organization_id).order_by('id')
        if all == 'true':
            serializer = PlantMachineryMasterSerializer(plant_machinery_master, many=True, context={"organization_id": organization_id})
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(plant_machinery_master, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = PlantMachineryMasterSerializer(page, many=True, context={"organization_id": organization_id})
        
        
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new plant machinery master record
        """
        try:
            organization_id = request.query_params.get('organization_id', None)
            form_type = request.query_params.get('form_type', None)
            organization_id = Organization.objects.get(id=organization_id)

            with transaction.atomic():
                plant_machinery_master_create = PlantMachineryMaster.objects.create(organization=organization_id, created_by=request.user)
                plant_machinery_master_create.save()

                for key, value in request.data.items():
                    form_details = FormMaster.objects.filter(id=key).first()

                    if form_details.form_input_type == 'file':
                        created = PlantMachineryData.objects.create(plantmachinery=plant_machinery_master_create, form_id=key, document=value, created_by=request.user)
                    else:
                        created = PlantMachineryData.objects.create(plantmachinery=plant_machinery_master_create, form_id=key, value=value, created_by=request.user)
                    
                    created.save()

            serializer = PlantMachineryMasterSerializer(plant_machinery_master_create, context={"organization_id": organization_id})

            form_type_list = list(FormMenuMaster.cmobjects.filter(is_display=True).order_by('sort_order').values_list('form_type_name', flat=True).distinct())
            print(form_type_list)
            next_form_type = ''

            for num, value in enumerate(form_type_list, start=0):
                if form_type == value:
                    next_form_type = form_type_list[num + 1]

            return Response({'results': {'Data': serializer.data },
                             'next': next_form_type,
                             'msg': 'Added Successfully',
                             'status': status.HTTP_200_OK,
                             "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e)})

    def put(self, request, *args, **kwargs):
        """
        Update an existing plant machinery master record
        """
        try:
            method = request.query_params.get('method', None)
            organization_id = request.query_params.get('organization_id', None)
            plant_machinery_id = request.query_params.get('plant_machinery_id', None)
            form_type = request.query_params.get('form_type', None)

            with transaction.atomic():
                if method and method.lower() == 'delete':
                    plant_machinery_details = PlantMachineryMaster.cmobjects.filter(organization_id=organization_id, id=plant_machinery_id).first()
                    plant_machinery_details.is_deleted = True
                    plant_machinery_details.save()

                    serializer = PlantMachineryMasterSerializer(plant_machinery_details, context={"organization_id": organization_id})

                    return Response({'results': {'Data': serializer.data },
                                'msg': 'Data Deleted Successfully',
                                'status': status.HTTP_200_OK,
                                "request_status": 0})

                else:
                    if plant_machinery_id is not None and plant_machinery_id != 'null':
                        plant_machinery_details = PlantMachineryMaster.cmobjects.filter(organization_id=organization_id, id=plant_machinery_id).first()
                    else:
                        plant_machinery_details = PlantMachineryMaster.objects.create(organization_id=organization_id, created_by=request.user)
                        plant_machinery_details.save()

                    for key, value in request.data.items():
                        formatted_key = str(key).split("_")
                        form_id = formatted_key[0]
                        sort_count = formatted_key[1]
                        form_details = FormMaster.objects.select_related('form_group').filter(id=int(form_id)).first()

                        if form_details.form_group.is_multiple:
                            if form_details.form_input_type == 'file':
                                created = PlantMachineryData.objects.create(plantmachinery=plant_machinery_details, form_id=form_id, document=value, created_by=request.user, by_order=sort_count)
                            else:
                                created = PlantMachineryData.objects.create(plantmachinery=plant_machinery_details, form_id=form_id, value=value, created_by=request.user, by_order=sort_count)
                        else:
                            if form_details.form_input_type == 'file':
                                created = PlantMachineryData.objects.update_or_create(plantmachinery=plant_machinery_details, form_id=form_id, defaults={'document': value, 'created_by': request.user})
                            else:
                                created = PlantMachineryData.objects.update_or_create(plantmachinery=plant_machinery_details, form_id=form_id, defaults={'value': value, 'created_by': request.user})

                serializer = PlantMachineryMasterSerializer(plant_machinery_details, context={"organization_id": organization_id})

                form_type_list = list(FormMenuMaster.cmobjects.filter(is_display=True).order_by('sort_order').values_list('form_type_name', flat=True).distinct())

                next_form_type = ''

                try:
                    for num, value in enumerate(form_type_list, start=0):
                        if form_type == value:
                            next_form_type = form_type_list[num + 1]
                except Exception as ex:
                    next_form_type = "last"

                return Response({'results': {'Data': serializer.data },
                                'next': next_form_type,
                                'msg': 'Updated Successfully',
                                'status': status.HTTP_200_OK,
                                "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e)})


class PlantMachineryGroupAPIView(APIView):
    """
    CRUD API for plant machinery group or machine category model
    """
    
    

    def get(self, request):
        """
        Get a list of all plant machinery group or category
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        project_id = request.query_params.get('project_id', None)
        if id:
            queryset = PlantMachineryGroup.cmobjects.filter(id=id).first()
            serializer = PlantMachineryGroupSerializer(queryset, context={"project_id": project_id})
            return Response(serializer.data)
        search = custom_filters(request, {}, ['project_id'])
        queryset = PlantMachineryGroup.cmobjects.select_related('organization')\
            .prefetch_related('plant_machinery_group_plant_machinery_machine',\
            'plant_machinery_group_plant_machinery_document_upload_master',
            'plant_machinery_group_plant_machinery_service_schedule',
            'plant_machinery_group_plant_machinery_job_sheet',
            'plant_machinery_group_plant_machinery_tyre',
            'plant_machinery_group_plant_machinery_log_book',
            'plant_machinery_group_plant_machinery_machine_working',
           ).filter(*search).order_by('-id').distinct()
        if all == 'true':
            serializer = PlantMachineryGroupSerializer(queryset,context={"project_id":project_id},many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryGroupSerializer(page, many=True)

        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new plant machinery group
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryGroupSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a plant machinery group details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get(
            'organization_id', None)
        plant_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a plant machinery group
                """
                if PlantMachineryGroup.cmobjects.filter(pk=plant_id, organization_id=organization_id).exists():
                    details = PlantMachineryGroup.cmobjects.filter(pk=plant_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryGroupSerializer(details, data=request.data,partial=True,)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a plant machinery group
                """
                if PlantMachineryGroup.cmobjects.filter(pk=plant_id, organization_id=organization_id).exists():
                    details = PlantMachineryGroup.cmobjects.filter(
                        pk=plant_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': PlantMachineryGroup.objects.filter(pk=plant_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryGroupImportAPIView(APIView):
    """
    API for importing PlantMachineryGroup data from an Excel file.
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'group_add': 0, 'group_edit': 0}
                organization_id = request.query_params.get('organization_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})

                if organization_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID not provided"})

                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x

                parent_groups = pd.DataFrame(
                    PlantMachineryGroup.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
                print(sheet_xlsx) 
                for column in field_map.values():
                    if column not in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                print('after loop',sheet_xlsx) 
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                parent_groups = parent_groups.fillna(np.nan).replace([np.nan], [None])
                parent_groups = parent_groups.applymap(lambda x: process_str(x))

                def check_parent(row):
                    result = None
                    parent_name = row[field_map.get('parent')]
                    if parent_name:
                        processed_name = process_str(parent_name)
                        temp = parent_groups[parent_groups['name'].str.contains(r'^' + processed_name + '$')]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result

                sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row: check_parent(row), axis=1)
                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])

                # Convert numeric fields
                numeric_fields = [
                    'standard_km_run_month',
                    'standard_hrs_run_month',
                    'standard_mileage_km_ltr',
                    'standard_mileage_ltr_hr',
                    'display_order_no',
                    'unit_per_hour',
                    'working_rate'
                ]
                for field in numeric_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_numeric(sheet_xlsx[field_map[field]], errors='coerce')
                print(sheet_xlsx)   
                for index, row in sheet_xlsx.iterrows():
             
                    data = {
                        'organization_id': organization_id,
                        'name': row[field_map['name']],
                        'average_base': row[field_map['average_base']],
                        'standard_km_run_month': row[field_map['standard_km_run_month']] if pd.notna(row[field_map['standard_km_run_month']]) else 0.0,
                        'standard_hrs_run_month': row[field_map['standard_hrs_run_month']] if pd.notna(row[field_map['standard_hrs_run_month']]) else 0.0,
                        'standard_mileage_km_ltr': row[field_map['standard_mileage_km_ltr']] if pd.notna(row[field_map['standard_mileage_km_ltr']]) else 0.0,
                        'standard_mileage_ltr_hr': row[field_map['standard_mileage_ltr_hr']] if pd.notna(row[field_map['standard_mileage_ltr_hr']]) else 0.0,
                        'remarks': row[field_map['remarks']],
                        'use_for': row[field_map['use_for']],
                        'display_order_no': row[field_map['display_order_no']] if pd.notna(row[field_map['display_order_no']]) else 0,
                        'machine_type': row[field_map['machine_type']],
                        'is_applicable': row[field_map['is_applicable']] if row[field_map['is_applicable']] is not None else False,
                        'insurance': row[field_map['insurance']] if row[field_map['insurance']] is not None else False,
                        'permit': row[field_map['permit']] if row[field_map['permit']] is not None else False,
                        'fitness': row[field_map['fitness']] if row[field_map['fitness']] is not None else False,
                        'tax': row[field_map['tax']] if row[field_map['tax']] is not None else False,
                        'puc': row[field_map['puc']] if row[field_map['puc']] is not None else False,
                        'welfare': row[field_map['welfare']] if row[field_map['welfare']] is not None else False,
                        'i_form': row[field_map['i_form']] if row[field_map['i_form']] is not None else False,
                        'green_tax': row[field_map['green_tax']] if row[field_map['green_tax']] is not None else False,
                        'unit_per_hour': row[field_map['unit_per_hour']] if pd.notna(row[field_map['unit_per_hour']]) else 0.0,
                        'working_rate': row[field_map['working_rate']] if pd.notna(row[field_map['working_rate']]) else 0.0,
                        'parent_id': sheet_xlsx.at[index, 'parent_id'],
                    }

                    if not PlantMachineryGroup.cmobjects.filter(name=row[field_map['name']]).exists() :
                        instance=PlantMachineryGroup.objects.create(created_by_id=request.user.id, **data)
                        sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['name']] and row1[field_map['parent']] and (row[field_map['name']] == row1[field_map['parent']]) else None) if (not row1['parent_id']) else row1['parent_id'], axis=1)
                        sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                        count_data['group_add'] += 1
                        
                    else:
                        PlantMachineryGroup.cmobjects.filter(name=row[field_map['name']]).update(updated_by_id=request.user.id, **data)
                        count_data['group_edit'] += 1
                 

                return Response(
                    {'results': {'Data': count_data},
                     'msg': 'Successfully created',
                     'status': status.HTTP_201_CREATED,
                     'request_status': 1})

        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})

class PlantMachineryAPIView(APIView):
    """
    CRUD API for plant machinery model
    """
    
    

    def get(self, request):
        """
        Get a list of all plant machinery
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        if id:
            queryset = PlantMachinery.cmobjects.filter(id=id).first()
            serializer = PlantMachinerySerializer(queryset)
            return Response(serializer.data)
        search = custom_filters(request, {}, [])
        queryset = PlantMachinery.cmobjects.filter(*search).order_by('-id')
        if all == 'true':
            serializer = PlantMachinerySerializer(queryset, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachinerySerializer(page, many=True)

        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new plant machinery
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachinerySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a plant machinery details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get(
            'organization_id', None)
        plant_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a plant machinery 
                """
                if PlantMachinery.cmobjects.filter(pk=plant_id, organization_id=organization_id).exists():
                    details = PlantMachinery.cmobjects.filter(pk=plant_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachinerySerializer(details, data=request.data,partial=True,)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a plant machinery
                """
                if PlantMachinery.cmobjects.filter(pk=plant_id, organization_id=organization_id).exists():
                    details = PlantMachinery.cmobjects.filter(
                        pk=plant_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': PlantMachinery.objects.filter(pk=plant_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryDprMasterAPIView(APIView):
    """
    CRUD API for PlantMachineryDprMaster model
    """
    
    

    def get(self, request):
        """
            Get a list PlantMachineryDprMaster
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryDprMaster.cmobjects.filter(id=id).first()
            serializer = PlantMachineryDprMasterSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        # _list = PlantMachineryDprMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        _list = PlantMachineryDprMaster.objects.select_related('organization', 'project', 'site').prefetch_related('dpr_master_plant_machinery_dpr_new').\
            filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryDprMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryDprMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryDprMaster
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryDprMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryDprMaster details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        dpr_master_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryDprMaster 
                """
                if PlantMachineryDprMaster.cmobjects.filter(pk=dpr_master_id, organization_id=organization_id).exists():
                    details = PlantMachineryDprMaster.cmobjects.filter(pk=dpr_master_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryDprMasterSerializer(details, data=request.data, partial=True)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryDprMaster
                """
                if PlantMachineryDprMaster.cmobjects.filter(pk=dpr_master_id, organization_id=organization_id).exists():
                    details = PlantMachineryDprMaster.cmobjects.filter(pk=dpr_master_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryDprMaster.objects.filter(pk=dpr_master_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
class PlantMachineryDprNewAPIView(APIView):
    """
        CRUD API for model: PlantMachineryDprNew
    """
    
    

    def get(self, request):
        """
            Get a list PlantMachineryDprNew
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryDprNew.cmobjects.filter(id=id).first()
            serializer = PlantMachineryDprNewSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryDprNew.cmobjects.select_related(
            'organization',
            'plant_machinery_machine',
            'project',
            'site',
            'dpr_master'
        ).filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryDprNewSerializer(_list, many=True)
            return Response({'results': serializer.data})
           
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryDprNewSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryDprNew
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryDprNewSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})


    def put(self, request):
        """
        Edit a PlantMachineryDprNew details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        dpr_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryDprNew 
                """
                if PlantMachineryDprNew.cmobjects.filter(pk=dpr_id, organization_id=organization_id).exists():
                    details = PlantMachineryDprNew.cmobjects.filter(pk=dpr_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryDprNewSerializer(details, data=request.data, partial=True,context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryDprNew
                """
                if PlantMachineryDprNew.cmobjects.filter(pk=dpr_id, organization_id=organization_id).exists():
                    details = PlantMachineryDprNew.cmobjects.filter(pk=dpr_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryDprNew.objects.filter(pk=dpr_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class PlantMachineryDocumentUploadMainAPIView(APIView):
    """
    API: Get document info per machine
    """
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by','-plant_machinery_machine_id')
        search = custom_filters(request, {}, [])

        _list = PlantMachineryDocumentUploadMaster.cmobjects.select_related(
            'plant_machinery_machine','plant_machinery_group','project'
        ).values(
            'plant_machinery_machine_id',
            'plant_machinery_machine__machine_number',
            'plant_machinery_machine__registration_no',
            'plant_machinery_machine__equipment_description',
            'plant_machinery_machine__machine_info_make',
            'plant_machinery_machine__machine_info_model',
            'plant_machinery_machine__machine_info_chassis_no',
        ).distinct()
        annotations = {}
        purposes = [
            choice[0] for choice in PlantMachineryDocumentUploadMaster._meta.get_field('purpose').choices
        ]
        for purpose in purposes:
            prefix = purpose.lower().replace(' ', '_')
            latest_docs = PlantMachineryDocumentUpload.cmobjects.filter(
                plant_machinery_document_upload_master__plant_machinery_machine_id=OuterRef('plant_machinery_machine__pk'),
                plant_machinery_document_upload_master__purpose=purpose
            ).order_by('-created_at')
            annotations[f"{prefix}__plant_machinery_document_upload_master_id"] = Subquery(latest_docs.values('plant_machinery_document_upload_master_id')[:1])
            # annotations[f"{prefix}__id"] = Subquery(latest_docs.values('id')[:1])
            annotations[f"{prefix}__expiry_date"] = Subquery(latest_docs.values('exp_date')[:1])
            annotations[f"{prefix}__attachment"] = Subquery(latest_docs.values('attachment')[:1])
            # annotations[f"{prefix}__remarks"] = Subquery(latest_docs.values('remarks'))
        _list = _list.annotate(**annotations).filter(*search).order_by(*str(order_by).split(","))
       
        if all == 'true':
            return Response({'results': list(_list)})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': list(page.object_list),
            },
        })

class PlantMachineryDocumentUploadMasterAPIView(APIView):
    """
    CRUD API for Plant Machinery Document Upload Master model
    """
    
    

    def get(self, request):
        """
        Get a list of all Plant Machinery Document Upload Masters
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            document_master = PlantMachineryDocumentUploadMaster.cmobjects.filter(id=id).first()
            serializer = PlantMachineryDocumentUploadMasterSerializer(document_master)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])
        document_master_list = PlantMachineryDocumentUploadMaster.cmobjects.select_related(
            'organization',
            'plant_machinery_group', 
            'plant_machinery_machine'
        ).filter(*search).distinct().order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryDocumentUploadMasterSerializer(document_master_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(document_master_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryDocumentUploadMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Plant Machinery Document Upload Master
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryDocumentUploadMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Plant Machinery Document Upload Master
        """
      
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        document_master_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Plant Machinery Document Upload Master
                """
                request.data['updated_by'] = request.user.id
                if PlantMachineryDocumentUploadMaster.cmobjects.filter(pk=document_master_id, organization_id=organization_id).exists():
                    document_master = PlantMachineryDocumentUploadMaster.cmobjects.filter(pk=document_master_id).first()
                    serializer = PlantMachineryDocumentUploadMasterSerializer(document_master, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Plant Machinery Document Upload Master
                """
                if PlantMachineryDocumentUploadMaster.cmobjects.filter(pk=document_master_id, organization_id=organization_id).exists():
                    document_master = PlantMachineryDocumentUploadMaster.cmobjects.get(pk=document_master_id, organization_id=organization_id)
                    document_master.is_deleted = True
                    document_master.updated_by = request.user
                    document_master.save()

                    return Response({'results': {
                        'document_master': PlantMachineryDocumentUploadMaster.objects.filter(pk=document_master_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Plant Machinery Document Upload Master',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})      
class PlantMachineryDocumentUploadAPIView(APIView):
    """
    CRUD API for Plant Machinery Document Upload  model(child table )
    """
   

    def put(self, request):
        """
        Delete a Plant Machinery Document Upload 
        """
      
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        document_id = request.query_params.get('id', None)

        with transaction.atomic():
          
            if method.lower() == 'delete':
                """
                Delete a Plant Machinery Document Upload 
                """
                if PlantMachineryDocumentUpload.cmobjects.filter(pk=document_id, organization_id=organization_id).exists():
                    document = PlantMachineryDocumentUpload.cmobjects.get(pk=document_id, organization_id=organization_id)
                    document.is_deleted = True
                    document.updated_by = request.user
                    document.save()

                    return Response({'results': {
                        'data': PlantMachineryDocumentUpload.objects.filter(pk=document_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Plant Machinery Document Upload ',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryDeletedDocumentAPIView(APIView):
    """
    CRUD API for Plant Machinery Document Upload  model
    """
    
    

    def get(self, request):
        """
        Get a list of all deleted Plant Machinery Document Uploads
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        updated_by__full_name__icontains = request.query_params.get('updated_by__full_name__icontains', None)
        # updated_at = request.query_params.get('updated_at', None)

        print(updated_by__full_name__icontains)
        if id:
            document = PlantMachineryDocumentUpload.objects.filter(id=id, is_deleted=True).first()
            serializer = PlantMachineryDeletedDocumentSerializer(document)
            return Response(serializer.data)

        search = {'is_deleted': True}
        # search={}
        _exclude = ['updated_by__full_name__icontains',]
        search = custom_filters(request, search, _exclude)
        # search = custom_filters(request, search, [])

        document_list = PlantMachineryDocumentUpload.objects.select_related(
            'organization',
            'plant_machinery_document_upload_master',
            'updated_by'
        ).filter(*search).order_by(*str(order_by).split(","))
        # print(document_list.query)
        print(document_list.values('updated_at'))

        if updated_by__full_name__icontains:
            document_list = update_query_for_user_search(updated_by__full_name__icontains, document_list, 'updated_by')
        # if updated_at:
        #     try:
        #         document_list = filter_by_date(document_list, 'updated_at', updated_at)
        #     except ValueError as e:
        #         pass
        #         print(e)
   
        if all == 'true':
            serializer = PlantMachineryDeletedDocumentSerializer(document_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(document_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryDeletedDocumentSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })                             


class PlantMachineryNotificationTrigger(APIView):
    """
    Plant and Machinery Notification Trigger Api
    """
    
    
    permission_classes = (AllowAny,)

    def post(self, request):
        """ Plant and Machinery Notification Trigger Api """

        # organization_id = request.data.get("organization", None)
        organization_id = request.query_params.get("organization", None)
        is_universal = request.query_params.get("is_universal", False)
        no_of_days = request.query_params.get("no_of_days", 60)

        today = date.today()

        query_date = today + timedelta(days=no_of_days)
        # {today.strftime('%d/%m/%Y')}
        doc_idss = []
        master_idss = []
        url = f"{os.getenv('FE_BASE','')}#/pms/plant_machinary/document-upload/edit/"
        # 0-> [document name] # 1-> <no_of_days> # 2-> [expire date] # 3-> <url>
        _msg_template = "Hi! Please be informed that the plant and Machinery `{0}` document will expire in {1} days, on {2}. Please check the details {3}."

        # 1-> [User_Name]
        # 2-> ([Document_Name])
        # 3-> [No_of_days]
        # 4-> [Expiry_Date]
        # 5-> [click here]
        _email_template = """
                Dear {0},
        Please be informed that the Plant and Machinery {1} document will expired in {2} days, on {3}.
        Please check the details """

        with transaction.atomic():
            try:
                document_queryset = PlantMachineryDocumentUpload.cmobjects.filter(
                    exp_date__lte=query_date,
                    is_notification_sent=False
                ).values('pk', 'plant_machinery_document_upload_master__id')

                tuple_list = [(item['pk'], item['plant_machinery_document_upload_master__id'], ) for item in document_queryset]

                ''' p&m-> users list '''
                users_queryset = UserWiseSubModulePermissions.cmobjects.filter(menu__menu_name__icontains='plant & machinery', level_permission=True, has_view_permission=True)
                users_list = list(users_queryset.values_list('user__id', flat=True).distinct())
                print('p&m users_list', users_list)
                if is_universal is False:
                    notifications = []
                    for u_id in users_list:
                        for (id, master_id) in tuple_list:
                            print('(id, master_id)', id, master_id)
                            doc_idss.append(id)
                            master_idss.append(master_id)
                            obj = PlantMachineryDocumentUpload.cmobjects.get(pk=id)
                            doc_name = obj.document_name if obj else ''
                            _expire_date = obj.exp_date if obj and obj.exp_date else None
                            # print('_expire_date', _expire_date, type(_expire_date))
                            expire_date = obj.exp_date.strftime('%d/%m/%Y') if obj else ''
                            no_of_days_left_from_today = abs((today - _expire_date).days) if _expire_date else None

                            print('no_of_days_left_from_today', no_of_days_left_from_today)
                            notifications.append(
                                NotificationMaster(
                                    organization_id=organization_id,
                                    notification=_msg_template.format(doc_name, no_of_days_left_from_today, expire_date, f'<a href=\"{url}{master_id}/{id}\">here</a>'),
                                    # 0-> [document name] # 1-> <no_of_days> # 2-> [expire date] # 3-> <url>
                                    notified_users_id=u_id,
                                    is_universal=False,
                                    is_manual=True
                                )
                            )
                else:
                    notifications = []
                    for (id, master_id) in tuple_list:
                        print('(id, master_id)', id, master_id)
                        doc_idss.append(id)
                        master_idss.append(master_id)
                        obj = PlantMachineryDocumentUpload.cmobjects.get(pk=id)
                        doc_name = obj.document_name if obj else ''
                        _expire_date = obj.exp_date if obj and obj.exp_date else None
                        expire_date = obj.exp_date.strftime('%d/%m/%Y') if obj else ''
                        no_of_days_left_from_today = abs((today - _expire_date).days) if _expire_date else None
                        notifications.append(
                            NotificationMaster(
                                organization_id=organization_id,
                                notification=_msg_template.format(doc_name, no_of_days_left_from_today, expire_date, f'<a href=\"{url}{master_id}/{id}\">here</a>'),
                                is_universal=True,  # <---
                                is_manual = True
                            )
                        )

                # Bulk create
                NotificationMaster.cmobjects.bulk_create(notifications)

                # Update is_notification_sent for relevant documents/ commented as per new business logic
                # PlantMachineryDocumentUpload.cmobjects.filter(pk__in=doc_idss).update(is_notification_sent=True)
                print('----is_universal---- ', is_universal)

                """
                EMAIL
                """
                for (id, master_id) in tuple_list:
                    print('EMAIL')
                    print('(id, master_id)', id, master_id)
                    # doc_idss.append(id)
                    # master_idss.append(master_id)
                    obj = PlantMachineryDocumentUpload.cmobjects.get(pk=id)
                    doc_name = obj.document_name if obj else ''
                    _expire_date = obj.exp_date if obj and obj.exp_date else None
                    expire_date = obj.exp_date.strftime('%d/%m/%Y') if obj else ''
                    no_of_days_left_from_today = abs((today - _expire_date).days) if _expire_date else None
                    url_mail = f"{os.getenv('FE_BASE','')}#/pms/plant_machinary/document-upload"
                    click_here = f'<a href=\"{url_mail}\">click here</a> .'
                    user_emails = list(users_queryset.values_list('user__email', flat=True).distinct())
                    subject = f"Plant & Equipments-Reminder-{doc_name}, about to expire on {expire_date}"


                    for user_email in user_emails:
                        # 1-> [user_name]
                        # 2-> ([document_name])
                        # 3-> [no_of_days]
                        # 4-> [expiry_date]
                        # 5-> [url]
                        user = PmsUser.objects.get(email=user_email)
                        user_name = user.user_full_name
                        document_name = doc_name
                        # no_of_days
                        # url_mail
                        notification_text = _email_template.format(user_name, document_name, no_of_days_left_from_today, expire_date)
                        trigger_notifications(action='P&M', subject=subject, user_list=[user.id], context={'notification_text ': notification_text, 'click_here':click_here})

                        # schedule_generic_mail(subject=subject, to_mail_list=[user_email], context={'notification_text ': notification_text, 'click_here':click_here}, template_name='P&M')

                        print('notification_text',)
                        print(notification_text)
                        print('subject: ', subject)

                print(f'{"-" * 10}x{"-" * 10}')
            except Exception as e:
                print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                # raise APIException({'request_status': 0, 'msg': str(e)})
        return Response(
            {'results': {
                'Data': tuple_list,
            },
                'msg': 'Successfully updated',
                'status': status.HTTP_202_ACCEPTED,
                "request_status": 1
            })

    def put(self, request):
        """ Plant and Machinery Notification Trigger Api EDIT"""

        # organization_id = request.data.get("organization", None)
        organization_id = request.query_params.get("organization", None)
        is_universal = request.query_params.get("is_universal", False)
        no_of_days = request.query_params.get("no_of_days", 60)

        notified_users = request.query_params.get("notified_users", None)


        today = date.today()

        query_date = today + timedelta(days=no_of_days)
        with transaction.atomic():
            try:
                notified_user_list = notified_users.split(',') if notified_users else None
                notification_master = NotificationMaster.cmobjects.filter(notified_users__in=notified_user_list).update(notification_master=False,)

                print(f'{"_" * 10}x{"_" * 10}')
            except Exception as e:
                print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                # raise APIException({'request_status': 0, 'msg': str(e)})

        return Response(
            {'results': {
                'Data': None,
            },
                'msg': 'Successfully updated...',
                'status': status.HTTP_202_ACCEPTED,
                "request_status": 1
            })


class PlantMachineryServiceGroupAPIView(APIView):
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryServiceGroup.cmobjects.filter(id=id).first()
            serializer = PlantMachineryServiceGroupSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryServiceGroup.cmobjects.select_related(
            'organization',  
        ).filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryServiceGroupSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryServiceGroupSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryServiceGroupSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        group_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryServiceGroup.cmobjects.filter(pk=group_id, organization_id=organization_id).exists():
                    details = PlantMachineryServiceGroup.cmobjects.filter(pk=group_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryServiceGroupSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryServiceGroup.cmobjects.filter(pk=group_id, organization_id=organization_id).exists():
                    details = PlantMachineryServiceGroup.cmobjects.filter(pk=group_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by = request.user
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryServiceGroup.objects.filter(pk=group_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryServiceGroupImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with (transaction.atomic()):
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                organization_id = request.query_params.get('organization_id', None)
                if not organization_id or organization_id == "null":
                    return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.keys():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                count = sheet_xlsx.shape[0]

                master = list()
                master_to_be_update = list()
                for i, item in enumerate(sheet_xlsx.to_dict('records')):
                    def get_value(key):
                        return item.get(field_map.get(key), '')

                    print('i-> ', i)
                    print('item-> ', item)

                    field_map_dic = {}
                    for column in field_map.keys():
                        if 'timestamp' in str(type(get_value(column))):
                            field_map_dic[column] = get_value(column).strftime('%Y-%m-%d')
                        else:
                            field_map_dic[column] = get_value(column)

                    if not PlantMachineryServiceGroup.cmobjects.filter(name=field_map_dic['name']).exists():
                        print('CREATE')
                        print('field_map_dic')
                        print(field_map_dic)

                        master.append(
                            PlantMachineryServiceItem(
                                organization_id=organization_id,
                                created_by=request.user,
                                **field_map_dic
                            )
                        )
                    else:
                        # master_to be_update
                        print('UPDATE')
                        print('field_map_dic')
                        print(field_map_dic)

                        obj = PlantMachineryServiceGroup.cmobjects.filter(name=field_map_dic['name']).first()
                        obj.organization_id = organization_id
                        obj.updated_by = request.user
                        for _key, _val in field_map_dic.items():
                            setattr(obj, _key, _val)
                        master_to_be_update.append(obj)

                    print('--------')
                print('----x-----')

                created_data = []
                updated_data = []
                with transaction.atomic():
                    try:
                        # Bulk create
                        masters = PlantMachineryServiceGroup.cmobjects.bulk_create(master, batch_size=1000, ignore_conflicts=False)
                        created_data = PlantMachineryServiceGroupSerializer(masters, many=True).data

                        # Bulk update
                        _fields = [i for i in field_map.keys() if i not in ('id', 'organization_id')]
                        PlantMachineryServiceGroup.cmobjects.bulk_update(master_to_be_update, _fields, batch_size=1000)
                        updated_data = PlantMachineryServiceGroupSerializer(master_to_be_update, many=True).data

                    except Exception as e:
                        print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                        'created_data': created_data,
                        'updated_data': updated_data
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class PlantMachineryServiceItemAPIView(APIView):
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryServiceItem.cmobjects.filter(id=id).first()
            serializer = PlantMachineryServiceItemSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryServiceItem.cmobjects.select_related(
            'organization', 'plant_machinery_service_group', 
            'gst_tax', 
        ).filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryServiceItemSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryServiceItemSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryServiceItemSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        item_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryServiceItem.cmobjects.filter(pk=item_id, organization_id=organization_id).exists():
                    details = PlantMachineryServiceItem.cmobjects.filter(pk=item_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryServiceItemSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryServiceItem.cmobjects.filter(pk=item_id, organization_id=organization_id).exists():
                    details = PlantMachineryServiceItem.cmobjects.filter(pk=item_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by = request.user
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryServiceItem.objects.filter(pk=item_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})                


class PlantMachineryServiceItemImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with (transaction.atomic()):
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                organization_id = request.query_params.get('organization_id', None)
                if not organization_id or organization_id == "null":
                    return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.keys():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                count = sheet_xlsx.shape[0]

                master = list()
                master_to_be_update = list()
                for i, item in enumerate(sheet_xlsx.to_dict('records')):
                    def get_value(key):
                        return item.get(field_map.get(key), '')

                    print('i-> ', i)
                    print('item-> ', item)

                    field_map_dic = {}
                    for column in field_map.keys():
                        if 'plant_machinery_service_group' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_plantmachineryservicegroup_by_name(str(_name).strip())
                        elif 'gst_tax' == column:
                            _name = get_value(column)
                            field_map_dic[column] = get_tax_head_by_name(_name)
                        elif 'timestamp' in str(type(get_value(column))):
                            field_map_dic[column] = get_value(column).strftime('%Y-%m-%d')
                        else:
                            field_map_dic[column] = get_value(column)

                    if not PlantMachineryServiceItem.cmobjects.filter(name=field_map_dic['name']).exists():
                        print('CREATE')
                        print('field_map_dic')
                        print(field_map_dic)

                        master.append(
                            PlantMachineryServiceItem(
                                organization_id=organization_id,
                                created_by=request.user,
                                **field_map_dic
                            )
                        )
                    else:
                        # master_to be_update
                        print('UPDATE')
                        print('field_map_dic')
                        print(field_map_dic)

                        obj = PlantMachineryServiceItem.cmobjects.filter(name=field_map_dic['name']).first()
                        obj.organization_id = organization_id
                        obj.updated_by = request.user
                        for _key, _val in field_map_dic.items():
                            setattr(obj, _key, _val)
                        master_to_be_update.append(obj)

                    print('--------')
                print('----x-----')

                created_data = []
                updated_data = []
                with transaction.atomic():
                    try:
                        # Bulk create
                        masters = PlantMachineryServiceItem.cmobjects.bulk_create(master, batch_size=1000,
                                                                               ignore_conflicts=False)
                        created_data = PlantMachineryServiceItemSerializer(masters, many=True).data

                        # Bulk update
                        _fields = [i for i in field_map.keys() if i not in ('id', 'organization_id')]
                        PlantMachineryServiceItem.cmobjects.bulk_update(master_to_be_update, _fields, batch_size=1000)
                        updated_data = PlantMachineryServiceItemSerializer(master_to_be_update, many=True).data

                    except Exception as e:
                        print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                        'created_data': created_data,
                        'updated_data': updated_data
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class PlantMachineryMachineAPIView(APIView):
    """
        CRUD API for model: PlantMachineryMachine
    """
    
    

    def get(self, request):
        """
            Get a list PlantMachineryMachine
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryMachine.cmobjects.filter(id=id).first()
            serializer = PlantMachineryMachineSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryMachine.cmobjects.select_related(
            'organization', 'plant_machinery_group', 'site', 
            'machine_info_cubic_capacity_unit', 'machine_info_tare_weight_unit',
            'uom_productivity', 'hsd_norms_uom'
        ).prefetch_related(
            'plant_machinery_machine_plant_machinery_machine_services',
            'plant_machinery_machine_plant_machinery_machine_driver',
            'plant_machinery_machine_plant_machinery_machine_rent',
            'plant_machinery_machine_plant_machinery_machine_service_schedule',
            'plant_machinery_machine_plant_machinery_job_sheet',
            'plant_machinery_machine_plant_machinery_meter_reset_log',
            'plant_machinery_machine_plant_machinery_log_book',
            'plant_machinery_machine_plant_machinery_insurance_master',
            'plant_machinery_machine_plant_machinery_machine_working',
            'plant_machinery_machine_plant_machinery_machine_working_fuel_issue',
            'plant_machinery_machine_plant_machinery_machine_working_idle_bd',
            'plant_machinery_machine_plant_machinery_activity_group_items').filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryMachineSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryMachineSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryMachine
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryMachineSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryMachine details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        machine_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryMachine
                """
                if PlantMachineryMachine.cmobjects.filter(pk=machine_id, organization_id=organization_id).exists():
                    details = PlantMachineryMachine.cmobjects.filter(pk=machine_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryMachineSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryMachine
                """
                if PlantMachineryMachine.cmobjects.filter(pk=machine_id, organization_id=organization_id).exists():
                    details = PlantMachineryMachine.cmobjects.filter(pk=machine_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by = request.user
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryMachine.objects.filter(pk=machine_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class PlantMachineryMachineImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                organization_id = request.query_params.get('organization_id', None)

                if not organization_id or organization_id == "null":
                    return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                count = sheet_xlsx.shape[0]

                master = list()
                master_to_be_update = list()
                for i, item in enumerate(sheet_xlsx.to_dict('records')):
                    def get_value(key):
                        return item.get(field_map.get(key), '')

                    print('i-> ', i)
                    # print('item-> ', item)

                    field_map_dic = {}
                    for column in field_map.keys():
                        # if "_id" not in column:
                        if 'plant_machinery_group' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_plantmachinerygroup_by_name(str(_name).strip())
                        elif 'hsd_norms_uom' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_uom_by_symbol(str(_name).strip())
                        elif 'uom_productivity' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_uom_by_symbol(str(_name).strip())
                        elif 'site' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_site_by_name(str(_name).strip())
                        elif 'plant_machinery_objective_indication_type' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_objective_indication_type_by_name(str(_name).strip())
                        elif 'machine_location' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_store_by_name(str(_name).strip())

                        elif 'timestamp' in str(type(get_value(column))):
                            field_map_dic[column] = get_value(column).strftime('%Y-%m-%d')
                        else:
                            field_map_dic[column] = get_value(column)
                    # print('field_map_dic',  field_map_dic)

                    if field_map_dic['equipment_description'] and not PlantMachineryMachine.cmobjects.filter(equipment_description=field_map_dic['equipment_description']).exists():
                        print('CREATE')
                        master.append(
                            PlantMachineryMachine(
                                organization_id=organization_id,
                                created_by=request.user,
                                **field_map_dic
                            )
                        )
                    else:
                        # master_to be_update
                        if field_map_dic['equipment_description']:
                            print('UPDATE')
                            obj = PlantMachineryMachine.cmobjects.filter(equipment_description=field_map_dic['equipment_description']).first()
                            obj.organization_id = organization_id
                            obj.updated_by = request.user

                            for _key, _val in field_map_dic.items():
                                setattr(obj, _key, _val)
                            master_to_be_update.append(obj)
                    print('--------')
                print('----x-----')

                created_data = []
                updated_data = []
                with transaction.atomic():
                    try:
                        # Bulk create
                        masters = PlantMachineryMachine.cmobjects.bulk_create(master, batch_size=1000, ignore_conflicts=False)
                        created_data = PlantMachineryMachineSerializer(masters, many=True).data

                        # Bulk update
                        _fields = [i for i in field_map.keys() if i not in ('id', 'organization_id')]
                        PlantMachineryMachine.cmobjects.bulk_update(master_to_be_update, _fields, batch_size=1000)
                        updated_data = PlantMachineryMachineSerializer(master_to_be_update,  many=True).data
                        # pass
                    except Exception as e:
                        print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                        'created_data': created_data,
                        'updated_data': updated_data
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class PlantMachineryInactiveTypeAPIView(APIView):
    """
        Plant machinery inactive type model
    """
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryInactiveType.cmobjects.filter(id=id).first()
            serializer = PlantMachineryInactiveTypeSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryInactiveType.cmobjects.select_related(
            'organization',  
        ).filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryInactiveTypeSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryInactiveTypeSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })                
    def post(self, request):
        """
        Create a new PlantMachineryInactiveType
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryInactiveTypeSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryInactiveType details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        inactive_type_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryInactiveType
                """
                if PlantMachineryInactiveType.cmobjects.filter(pk=inactive_type_id, organization_id=organization_id).exists():
                    details = PlantMachineryInactiveType.cmobjects.filter(pk=inactive_type_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryInactiveTypeSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryInactiveType
                """
                if PlantMachineryInactiveType.cmobjects.filter(pk=inactive_type_id, organization_id=organization_id).exists():
                    details = PlantMachineryInactiveType.cmobjects.filter(pk=inactive_type_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by = request.user
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryInactiveType.objects.filter(pk=inactive_type_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class PlantMachineryTruckAccountAPIView(APIView):
    """
        Plant machinery truck account master model
    """
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryTruckAccount.cmobjects.filter(id=id).first()
            serializer = PlantMachineryTruckAccountSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryTruckAccount.cmobjects.\
            select_related('organization').filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryTruckAccountSerializer(_list, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryTruckAccountSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryTruckAccount
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryTruckAccountSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryTruckAccount details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        account_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryTruckAccount
                """
                if PlantMachineryTruckAccount.cmobjects.filter(pk=account_id, organization_id=organization_id).exists():
                    details = PlantMachineryTruckAccount.cmobjects.filter(pk=account_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryTruckAccountSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryTruckAccount
                """
                if PlantMachineryTruckAccount.cmobjects.filter(pk=account_id, organization_id=organization_id).exists():
                    details = PlantMachineryTruckAccount.cmobjects.filter(pk=account_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by = request.user
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryTruckAccount.objects.filter(pk=account_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})                


class PlantMachineryServiceScheduleAPIView(APIView):
    """
    Plant machinery service schedule category-wise or group-wise model
    """
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryServiceSchedule.cmobjects.filter(id=id).first()
            serializer = PlantMachineryServiceScheduleSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])
        _list = PlantMachineryServiceSchedule.cmobjects.select_related(
            'organization', 'plant_machinery_service_group', 
            'plant_machinery_service_item', 'service_unit', 'plant_machinery_group'
        ).filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryServiceScheduleSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryServiceScheduleSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

   
    @transaction.atomic
    def post(self, request):
        data = request.data
        res1 = res2 = 0
        errors = []
        schedules_to_create = []

        if not isinstance(data, list):
            raise APIException({'request_status': 0, 'msg': 'Input data must be a list'})

        # try:
        with transaction.atomic():

            # Collect IDs of organization and plant machinery group from request data
            organization_ids = set(item.get('organization') for item in data if 'organization' in item)
            plant_machinery_group_ids = set(item.get('plant_machinery_group') for item in data if 'plant_machinery_group' in item)

            # existing_schedules_to_update = PlantMachineryServiceSchedule.cmobjects.filter(
            #     organization_id__in=organization_ids,
            #     plant_machinery_group_id__in=plant_machinery_group_ids
            # )

            schedules_in_request = set(item.get('id') for item in data if 'id' in item)

            # Mark schedules not in request data for deletion
            existing_schedules_to_delete = PlantMachineryServiceSchedule.cmobjects.filter(
                organization_id__in=organization_ids,
                plant_machinery_group_id__in=plant_machinery_group_ids).exclude(
                id__in=schedules_in_request
            )
            # ).exclude(
            #     id__in=existing_schedules_to_update.values_list('id', flat=True)
            

            for schedule in existing_schedules_to_delete:
                schedule.is_deleted = True
                schedule.updated_by = request.user
                schedule.save()
                res1 += 1
            for item in data:
                try:
                    organization_id = item.get('organization')
                    plant_machinery_group_id = item.get('plant_machinery_group')
                    plant_machinery_service_group_id = item.get('plant_machinery_service_group',None)
                    plant_machinery_service_item_id = item.get('plant_machinery_service_item',None)
                    service_unit_id = item.get('service_unit',None)
                    service_type = item.get('service_type',None)
                    repeat = item.get('repeat',None)
                    limit_kms_from = item.get('limit_kms_from',None)
                    limit_kms_to = item.get('limit_kms_to',None)
                    limit_days_from = item.get('limit_days_from',None)
                    limit_days_to = item.get('limit_days_to',None)
                    limit_hrs_from = item.get('limit_hrs_from',None)
                    limit_hrs_to = item.get('limit_hrs_to',None)
                    quantity = item.get('quantity',None)
                    chargeable = item.get('chargeable',None)
                    approx_rate = item.get('approx_rate',None)
                    approx_amount = item.get('approx_amount',None)
                    part_number = item.get('part_number',None)

                    if not (organization_id and plant_machinery_group_id ):
                        errors.append({'item': item, 'error': 'Missing required fields'})
                        res2 += 1
                        continue

                    organization_instance = Organization.objects.filter(id=organization_id).first()
                    if not organization_instance:
                        errors.append({'item': item, 'error': f'Organization with ID {organization_id} does not exist'})
                        res2 += 1
                        continue

                    plant_machinery_group_instance = PlantMachineryGroup.objects.filter(id=plant_machinery_group_id).first()
                    if not plant_machinery_group_instance:
                        errors.append({'item': item, 'error': f'Plant Machinery Group with ID {plant_machinery_group_id} does not exist'})
                        res2 += 1
                        continue

                    plant_machinery_service_group_instance = PlantMachineryServiceGroup.cmobjects.filter(id=plant_machinery_service_group_id).first()
                    plant_machinery_service_item_instance = PlantMachineryServiceItem.cmobjects.filter(id=plant_machinery_service_item_id).first()
                    service_unit_instance = UnitOfMesurement.cmobjects.filter(id=service_unit_id).first()

                    schedule_data = {
                        'organization': organization_instance,
                        'plant_machinery_group': plant_machinery_group_instance,
                        'plant_machinery_service_group': plant_machinery_service_group_instance,
                        'plant_machinery_service_item': plant_machinery_service_item_instance,
                        'service_unit': service_unit_instance,
                        'service_type': service_type,
                        'repeat': repeat,
                        'limit_kms_from': limit_kms_from,
                        'limit_kms_to': limit_kms_to,
                        'limit_days_from': limit_days_from,
                        'limit_days_to': limit_days_to,
                        'limit_hrs_from': limit_hrs_from,
                        'limit_hrs_to': limit_hrs_to,
                        'quantity': quantity,
                        'chargeable': chargeable,
                        'approx_rate': approx_rate,
                        'approx_amount': approx_amount,
                        'part_number': part_number,
                        'created_by': request.user,  
                    }

                    if 'id' in item:
                        schedule_id = item['id']
                        existing_schedule = PlantMachineryServiceSchedule.cmobjects.filter(id=schedule_id).first()
                        if existing_schedule:
                            for key, value in schedule_data.items():
                                setattr(existing_schedule, key, value)
                            existing_schedule.updated_by = request.user
                            existing_schedule.save()
                            res1 += 1
                        else:
                            errors.append({'item': item, 'error': f'Schedule with ID {schedule_id} does not exist'})
                            res2 += 1
                    else:
                        schedules_to_create.append(PlantMachineryServiceSchedule(**schedule_data))

                except Exception as e:
                    errors.append({'item': item, 'error': str(e)})
                    res2 += 1

            if schedules_to_create:
                PlantMachineryServiceSchedule.objects.bulk_create(schedules_to_create)
                res1 = len(schedules_to_create)
               

        # except Exception as e:
        #     raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})

        return Response(
            {
                'results': {
                    'processed_schedules_count': res1,
                    'errors_count': res2,
                    'errors': errors,
                },
                'msg': 'Schedules successfully processed' if res1 > 0 else 'No schedules were processed',
                'status': status.HTTP_201_CREATED if res1 > 0 else status.HTTP_400_BAD_REQUEST,
                'request_status': 1 if res1 > 0 else 0,
            }
        )


class PlantMachineryServiceScheduleImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with (transaction.atomic()):
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})

                params_check = ['organization_id',
                          'plant_machinery_group_id',
                          'plant_machinery_service_group_id',
                          'plant_machinery_service_item_id'
                ]
                for param in params_check:
                    if not request.query_params.get(param) or request.query_params.get(param, None) == "null":
                        return Response({'error': f'{param} not provided'}, status=status.HTTP_400_BAD_REQUEST)

                base_fields = {}
                for key, value in request.query_params.items():
                    base_fields[key] = value

                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.keys():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                count = sheet_xlsx.shape[0]

                master = list()
                master_to_be_update = list()
                for i, item in enumerate(sheet_xlsx.to_dict('records')):
                    def get_value(key):
                        return item.get(field_map.get(key), '')

                    print('i-> ', i)
                    # print('item-> ', item)

                    field_map_dic = {}
                    for column in field_map.keys():
                        if 'timestamp' in str(type(get_value(column))):
                            field_map_dic[column] = get_value(column).strftime('%Y-%m-%d')
                        elif 'plant_machinery_group' in column:
                            print('plant_machinery_group')
                            field_map_dic.pop('plant_machinery_group_id', None)
                        elif 'plant_machinery_service_group' in column:
                            print('plant_machinery_group')
                            field_map_dic.pop('plant_machinery_service_group_id', None)
                        else:
                            field_map_dic[column] = get_value(column)

                    master.append(
                        PlantMachineryServiceSchedule(
                            created_by=request.user,
                            **base_fields,
                            **field_map_dic
                        )
                    )

                created_data = []
                with transaction.atomic():
                    try:
                        # Bulk create
                        masters = PlantMachineryServiceSchedule.cmobjects.bulk_create(master, batch_size=1000, ignore_conflicts=False)
                        created_data = PlantMachineryServiceScheduleSerializer(masters, many=True).data

                    except Exception as e:
                        print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                        'created_data': created_data,
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class PlantMachineryTdsTypeAPIView(APIView):
    """
    Plant Machinery TDS Type model
    """
    
    
    
    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryTdsType.cmobjects.filter(id=id).first()
            serializer = PlantMachineryTdsTypeSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])
        _list = PlantMachineryTdsType.cmobjects.select_related('organization').filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryTdsTypeSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryTdsTypeSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryTdsType
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryTdsTypeSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        tds_type_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryTdsType
                """
                if PlantMachineryTdsType.cmobjects.filter(pk=tds_type_id, organization_id=organization_id).exists():
                    details = PlantMachineryTdsType.cmobjects.filter(pk=tds_type_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryTdsTypeSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryTdsType
                """
                if PlantMachineryTdsType.cmobjects.filter(pk=tds_type_id, organization_id=organization_id).exists():
                    details = PlantMachineryTdsType.cmobjects.filter(pk=tds_type_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by = request.user
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryTdsType.objects.filter(pk=tds_type_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class PlantMachineryMachineBulkCreateAPIView(APIView):
    """
    API view for bulk create of machines
    """
    
    

    def post(self, request):
        data = request.data
        created_by_id = request.user.id
        res1 = res2 = 0
        errors = []

        if not isinstance(data, list):
            raise APIException({'request_status': 0, 'msg': 'Input data must be a list'})

        machines_to_create = []

        try:
            with transaction.atomic():
                for item in data:
                    try:
                        organization_id = item.get('organization')
                        plant_machinery_group = item.get('plant_machinery_group')
                        active_date = item.get('active_date')
                        machine_number = item.get('machine_number')
                        equipment_description = item.get('equipment_description')
                        equipment_number = item.get('equipment_number')
                        machine_code = item.get('machine_code')
                        machine_no_1 = item.get('machine_no_1')
                        machine_no_2 = item.get('machine_no_2')

                        if not all([plant_machinery_group, equipment_number, machine_number, active_date, machine_no_1, machine_no_2]):
                            errors.append({'item': item, 'error': 'Missing required fields'})
                            res2 += 1
                            continue

                        machine_group_instance = PlantMachineryGroup.objects.filter(id=plant_machinery_group).first()
                        if not machine_group_instance:
                            errors.append({'item': item, 'error': f'Invalid machine_group id: {plant_machinery_group}'})
                            res2 += 1
                            continue

                        machine = PlantMachineryMachine(
                            organization_id=organization_id, 
                            plant_machinery_group=machine_group_instance,
                            active_date=active_date,
                            machine_number=machine_number,
                            equipment_description=equipment_description,
                            equipment_number=equipment_number,
                            machine_code=machine_code,
                            machine_no_1=machine_no_1,
                            machine_no_2=machine_no_2,
                            created_by_id=created_by_id
                        )
                        machines_to_create.append(machine)
                    except Exception as e:
                        errors.append({'item': item, 'error': str(e)})
                        res2 += 1

                if machines_to_create:
                    PlantMachineryMachine.objects.bulk_create(machines_to_create)
                    res1 = len(machines_to_create)

        except Exception as e:
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support. '})

        return Response(
            {
                'results': {
                    'data': {'created_machines_count': res1, 'errors_count': res2, 'errors': errors},
                },
                'msg': 'Machines successfully created' if res1 > 0 else 'No machines were created',
                'status': status.HTTP_201_CREATED if res1 > 0 else status.HTTP_400_BAD_REQUEST,
                "request_status": 1 if res1 > 0 else 0
            }
        )

class PlantMachineryMachineMaintenanceItemGroupAPIView(APIView):
    """
    CRUD API for Machine Maintenance ItemGroup
    """
    
    

    def get(self, request):
        """
        Get a list of all Machine Maintenance ItemGroup
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        created_by__full_name__icontains = request.query_params.get('created_by__full_name__icontains', None)

        if id:
            item_group_details = PlantMachineryMachineMaintenanceItemGroup.cmobjects.filter(id=id).first()
            serializer = PlantMachineryMachineMaintenanceItemGroupSerializer(item_group_details)
            return Response(serializer.data)
        _exclude = ['created_by__full_name__icontains']
        search = custom_filters(request, {}, _exclude)
        print(search)

        item_group_list = PlantMachineryMachineMaintenanceItemGroup.cmobjects.filter(*search).order_by('-id')
        if created_by__full_name__icontains:
            item_group_list = update_query_for_user_search(created_by__full_name__icontains, item_group_list, 'created_by')
            # print('item_group_list', item_group_list.query)

        if all == 'true':
            serializer = PlantMachineryMachineMaintenanceItemGroupSerializer(item_group_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(item_group_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryMachineMaintenanceItemGroupSerializer(page, many=True)

        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    

    def post(self, request):
        """
        Create a new Machine Maintenance ItemGroup
        """
        request.data['created_by'] = request.user.id
        print(request.data)
        serializer = PlantMachineryMachineMaintenanceItemGroupSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Material Request
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        item_group_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Material Request
                """
                request.data['updated_by'] = request.user.id
                if PlantMachineryMachineMaintenanceItemGroup.cmobjects.filter(pk=item_group_id, organization_id=organization_id).exists():
                    item_group_details = PlantMachineryMachineMaintenanceItemGroup.cmobjects.filter(pk=item_group_id).first()
                    serializer = PlantMachineryMachineMaintenanceItemGroupSerializer(item_group_details, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Material Request
                """
                if PlantMachineryMachineMaintenanceItemGroup.cmobjects.filter(pk=item_group_id,
                                                          organization_id=organization_id).exists():
                    item_group_details = PlantMachineryMachineMaintenanceItemGroup.cmobjects.get(
                        pk=item_group_id, organization_id=organization_id)
                    item_group_details.is_deleted = True
                    item_group_details.updated_by_id = request.user.id
                    item_group_details.save()

                    return Response({'results': {
                        'item_group': PlantMachineryMachineMaintenanceItemGroup.cmobjects.filter(pk=item_group_id,
                                                                                   organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted PlantMachinery Machine Maintenance ItemGroup',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class PlantMachineryJobSheetAPIView(APIView):
    """
        CRUD API for model: PlantMachineryJobSheet
    """
    
    

    def get(self, request):
        """
            Get a list PlantMachineryJobSheet
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryJobSheet.cmobjects.filter(id=id).first()
            serializer = PlantMachineryJobSheetSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryJobSheet.cmobjects.select_related(
            'organization', 'plant_machinery_group', 'site', 'machine_location', 'plant_machinery_service_group', 'vendor'
        ).filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryJobSheetSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryJobSheetSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryJobSheet
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryJobSheetSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryJobSheet details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        jobsheet_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryJobSheet
                """
                if PlantMachineryJobSheet.cmobjects.filter(pk=jobsheet_id, organization_id=organization_id).exists():
                    details = PlantMachineryJobSheet.cmobjects.filter(pk=jobsheet_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryJobSheetSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryJobSheet
                """
                if PlantMachineryJobSheet.cmobjects.filter(pk=jobsheet_id, organization_id=organization_id).exists():
                    details = PlantMachineryJobSheet.cmobjects.filter(pk=jobsheet_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by = request.user
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryJobSheet.objects.filter(pk=jobsheet_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})



class PlantMachineryJobSheetImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with (transaction.atomic()):
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                organization_id = request.query_params.get('organization_id', None)
                if not organization_id or organization_id == "null":
                    return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.keys():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                count = sheet_xlsx.shape[0]

                master = list()
                master_to_be_update = list()
                for i, item in enumerate(sheet_xlsx.to_dict('records')):
                    def get_value(key):
                        return item.get(field_map.get(key), '')

                    print('i-> ', i)
                    print('item-> ', item)

                    field_map_dic = {}
                    for column in field_map.keys():
                        if 'plant_machinery_group' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_plantmachinerygroup_by_name(str(_name).strip())
                        elif 'site' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_site_by_name(str(_name).strip())
                        elif 'machine_location' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_store_by_name(str(_name).strip())
                        elif 'project' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_project_by_name(str(_name).strip())
                        elif 'inspected_by' in column:
                            _name = get_value(column)
                            field_map_dic[column] = get_user_by_name(str(_name).strip().lower())
                        elif 'vendor' in column:
                            field_map_dic[column] = get_vendor_by_name(str(get_value(column)).strip())

                        elif 'timestamp' in str(type(get_value(column))):
                            field_map_dic[column] = get_value(column).strftime('%Y-%m-%d')
                        else:
                            field_map_dic[column] = get_value(column)


                    # print('field_map_dic', field_map_dic)
                    # jobsheet_number = generate_all_code(jobsheet, ['JS'])
                    # master.append(
                    #     PlantMachineryJobSheet(
                    #         organization_id=organization_id,
                    #         created_by=request.user,
                    #         **field_map_dic
                    #     )
                    # )


                    if not PlantMachineryJobSheet.cmobjects.filter(jobsheet_number=field_map_dic['jobsheet_number']).exists():
                        print('CREATE')
                        print('field_map_dic')
                        print(field_map_dic)

                        master.append(
                            PlantMachineryJobSheet(
                                organization_id=organization_id,
                                created_by=request.user,
                                **field_map_dic
                            )
                        )
                    else:
                        # master_to be_update
                        print('UPDATE')
                        print('field_map_dic')
                        print(field_map_dic)

                        obj = PlantMachineryJobSheet.cmobjects.filter(jobsheet_number=field_map_dic['jobsheet_number']).first()
                        obj.organization_id = organization_id
                        obj.updated_by = request.user
                        for _key, _val in field_map_dic.items():
                            setattr(obj, _key, _val)
                        master_to_be_update.append(obj)

                    print('--------')
                print('----x-----')

                created_data = []
                updated_data = []
                with transaction.atomic():
                    try:
                        # Bulk create
                        masters = PlantMachineryJobSheet.cmobjects.bulk_create(master, batch_size=1000, ignore_conflicts=False)
                        created_data = PlantMachineryJobSheetSerializer(masters, many=True).data

                        # Bulk update
                        _fields = [i for i in field_map.keys() if i not in ('id', 'organization_id')]
                        PlantMachineryJobSheet.cmobjects.bulk_update(master_to_be_update, _fields, batch_size=1000)
                        updated_data = PlantMachineryJobSheetSerializer(master_to_be_update, many=True).data

                        # update jobsheet_number
                        update_jobsheet_number()

                        print('............')

                    except Exception as e:
                        print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                        'created_data': created_data,
                        'updated_data': updated_data
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class PlantMachineryJobSheetImport2APIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with (transaction.atomic()):
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                organization_id = request.query_params.get('organization_id', None)
                if not organization_id or organization_id == "null":
                    return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.keys():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                count = sheet_xlsx.shape[0]

                df = sheet_xlsx.copy()
                inverted_field_map = {v: k for k, v in field_map.items()}

                df = df.rename(inverted_field_map, axis='columns')
                df = df.loc[:, ~df.columns.duplicated()].copy()  # remove-duplicate-columns

                valid_cols = [k for k in field_map.keys()]
                parent_columns = [col for col in df.columns if not col.startswith('services_data__') and col in valid_cols]
                child_columns = [col for col in df.columns if col.startswith('services_data__') and col in valid_cols]

                parent_df = df[parent_columns]
                child_df = df[child_columns]

                parent_model_class = globals()['PlantMachineryJobSheet']
                child_model_class = globals()['PlantMachineryJobSheetService']

                child_list = []
                for _, row in parent_df.iterrows():
                    updated_data = collections.OrderedDict()
                    def get_values(_row, column_name):
                        return str(_row[column_name]).strip() if column_name in df.columns else ''

                    for col in parent_columns:
                        updated_data[col] = get_values(row, col)

                    updated_data["jobsheet_date"] = row['jobsheet_date']
                    updated_data["jobsheet_time"] = row['jobsheet_time']
                    updated_data["estimated_time_days"] = row['estimated_time_days']
                    updated_data["plant_machinery_group"] = get_plantmachinerygroup_by_name(str(row['plant_machinery_group']).strip())
                    updated_data["site"] = get_site_by_name(str(row['site']).strip())
                    updated_data["machine_location"] = get_store_by_name(str(row['machine_location']).strip())
                    updated_data["project"] = get_project_by_name(str(row['project']).strip())
                    updated_data["inspected_by"] = get_user_by_name(str(row['inspected_by']).strip())
                    updated_data["vendor"] = get_vendor_by_name(str(row['vendor']).strip())
                    updated_data["plant_machinery_machine"] = get_plantmachinerymachine_by_name(str(row['plant_machinery_machine']).split())
                    updated_data["plant_machinery_service_group"] = get_plantmachineryservicegroup_by_name(str(row['plant_machinery_service_group']).strip())

                    print('CREATE')
                    if pd.notna(row['plant_machinery_group']) and pd.notna(row['site']):
                        print('updated_data',  updated_data)
                        parent = parent_model_class.cmobjects.create(
                            organization_id=organization_id,
                            **updated_data
                        )
                        # parent.jobsheet_number = generate_all_code(parent, ['JS']) if parent else ''
                        # parent.save()

                        for i in range(len(child_df) // len(parent_df)):
                            child_index = i + (_ * (len(child_df) // len(parent_df)))
                            child_list.append({'child_index': child_index, 'parent': parent})

                end = df.shape[0]
                updated_child_list = []
                for i, item in enumerate(child_list):
                    if len(child_list) - 1 == i:
                        updated_child_list.append({
                            'child_index_range': (child_list[i]["child_index"], end,),
                            'parent': item['parent']
                        })
                    else:
                        updated_child_list.append({
                            'child_index_range': (child_list[i]["child_index"], child_list[i + 1]["child_index"]),
                            'parent': item['parent']
                        })
                print('updated_child_list', updated_child_list)

                # create child
                for updated_child in updated_child_list:
                    # print(colorama.Back.GREEN, 'child: ', updated_child, colorama.Style.RESET_ALL)
                    parent = updated_child['parent']

                    for _iloc in range(updated_child['child_index_range'][0], updated_child['child_index_range'][1]):
                        print('iloc ------> ', _iloc)
                        child_data = collections.OrderedDict()
                        for col in child_columns:
                            print('ch ', str(col).replace('services_data__', '') )
                            ch_col = str(col).replace('services_data__', '')
                            child_data[ch_col] = df.iloc[_iloc][col]

                        child_data["unit"] = get_uom_by_symbol(str(df.iloc[_iloc]['services_data__unit']).strip())
                        child_data["plant_machinery_service_item"] = get_plantmachineryserviceitem_by_name(str(df.iloc[_iloc]['services_data__plant_machinery_service_item']).strip())

                        child = child_model_class.objects.create(
                            organization_id=organization_id,
                            plant_machinery_job_sheet=parent,
                            **child_data
                        )
                        print('created child :: ', child)

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class PlantMachineryJobSheetServiceImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with (transaction.atomic()):
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                organization_id = request.query_params.get('organization_id', None)
                if not organization_id or organization_id == "null":
                    return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.keys():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                count = sheet_xlsx.shape[0]

                master = list()
                master_to_be_update = list()
                for i, item in enumerate(sheet_xlsx.to_dict('records')):
                    def get_value(key):
                        return item.get(field_map.get(key), '')

                    print('i-> ', i)
                    # print('item-> ', item)

                    field_map_dic = {}
                    for column in field_map.keys():
                        # print(column)
                        if 'plant_machinery_job_sheet' == column:
                            _name = get_value(column)
                            field_map_dic[column] = get_job_sheet_by_code(str(_name).strip())
                        elif 'unit' == column:
                            _name = get_value(column)
                            field_map_dic[column] = get_uom_by_symbol(str(_name).strip())
                        elif 'timestamp' in str(type(get_value(column))):
                            field_map_dic[column] = get_value(column).strftime('%Y-%m-%d')
                        elif column.startswith('item__'):
                            print('column item__', column)
                        else:
                            field_map_dic[column] = get_value(column)

                    if not PlantMachineryJobSheetService.cmobjects.filter(plant_machinery_job_sheet=field_map_dic['plant_machinery_job_sheet']).exists():
                        print('CREATE')
                        # print('field_map_dic')
                        # print(field_map_dic)

                        master.append(
                            PlantMachineryJobSheetService(
                                organization_id=organization_id,
                                created_by=request.user,
                                **field_map_dic
                            )
                        )
                    else:
                        # master_to be_update
                        print('UPDATE')
                        # print('field_map_dic')
                        # print(field_map_dic)

                        obj = PlantMachineryJobSheetService.cmobjects.filter(plant_machinery_job_sheet=field_map_dic['plant_machinery_job_sheet']).first()
                        obj.organization_id = organization_id
                        obj.updated_by = request.user
                        for _key, _val in field_map_dic.items():
                            setattr(obj, _key, _val)
                        master_to_be_update.append(obj)

                    print('--------')
                print('----x-----')

                created_data = []
                updated_data = []
                with transaction.atomic():
                    try:
                        # Bulk create
                        masters = PlantMachineryJobSheetService.cmobjects.bulk_create(master, batch_size=1000, ignore_conflicts=False)
                        # created_data = PlantMachineryJobSheetServiceSerializer2(masters, many=True).data

                        # Bulk update
                        _fields = [i for i in field_map.keys() if i not in ('id', 'organization_id')]
                        PlantMachineryJobSheetService.cmobjects.bulk_update(master_to_be_update, _fields, batch_size=1000)
                        # updated_data = PlantMachineryJobSheetServiceSerializer2(master_to_be_update, many=True).data

                    except Exception as e:
                        print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                        'created_data': created_data,
                        'updated_data': updated_data
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class PlantMachineryMeterResetLogAPIView(APIView):
    """
        CRUD API for model: PlantMachineryMeterResetLog
    """
    
    

    def get(self, request):
        """
            Get a list PlantMachineryMeterResetLog
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryMeterResetLog.cmobjects.filter(id=id).first()
            serializer = PlantMachineryMeterResetLogSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryMeterResetLog.cmobjects.select_related(
            'organization',
            'plant_machinery_machine',   
        ).filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryMeterResetLogSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryMeterResetLogSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryMeterResetLog
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryMeterResetLogSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})


    def put(self, request):
        """
        Edit a PlantMachineryDprNew details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        log_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryMeterResetLog 
                """
                if PlantMachineryMeterResetLog.cmobjects.filter(pk=log_id, organization_id=organization_id).exists():
                    details = PlantMachineryMeterResetLog.cmobjects.filter(pk=log_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryMeterResetLogSerializer(details, data=request.data, partial=True,context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryMeterResetLog
                """
                if PlantMachineryMeterResetLog.cmobjects.filter(pk=log_id, organization_id=organization_id).exists():
                    details = PlantMachineryMeterResetLog.cmobjects.filter(pk=log_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryMeterResetLog.objects.filter(pk=log_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class PlantMachineryTyreAPIView(APIView):
    """
    CRUD API for model: PlantMachineryTyre
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryTyre
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        
        if id:
            _details = PlantMachineryTyre.cmobjects.filter(id=id).first()
            serializer = PlantMachineryTyreSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryTyre.cmobjects.select_related(
            'organization',
            'plant_machinery_group',
            'brand',
            'model',
            'vendor'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryTyreSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryTyreSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryTyre
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryTyreSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryTyre details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        tyre_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryTyre
                """
                if PlantMachineryTyre.cmobjects.filter(pk=tyre_id, organization_id=organization_id).exists():
                    details = PlantMachineryTyre.cmobjects.filter(pk=tyre_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryTyreSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryTyre
                """
                if PlantMachineryTyre.cmobjects.filter(pk=tyre_id, organization_id=organization_id).exists():
                    details = PlantMachineryTyre.cmobjects.get(pk=tyre_id, organization_id=organization_id)
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryTyre.objects.filter(pk=tyre_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})      
class PlantMachineryTyreImportAPIView(APIView):
    """
    API for importing PlantMachineryTyre data from an Excel file.
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'tyre_add': 0, 'tyre_edit': 0}
                organization_id = request.query_params.get('organization_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})

                if organization_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID not provided"})

                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("File not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                def process_str(x):
                    if pd.isna(x):
                        return None
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x

                # Convert date fields
                date_fields = [
                    'issue_date',
                    'sold_date',
                    'purchase_date'
                ]
                for field in date_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_datetime(sheet_xlsx[field_map[field]], errors='coerce')

                numeric_fields = [
                    'vehicle_km_reading',
                    'vehicle_hrs_reading',
                    # 'sold_amount',
                    'purchase_amount_cost',
                    'tread',
                    'ply_rating',
                    # 'run_at_pur',
                    'number_of_remould',
                    # 'tread_depth',
                    'grip',
                    # 'warranty_days',
                    'warranty_km',
                    # 'load_capacity',
                    # 'casing',
                    'std_psi'
                ]
                for field in numeric_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_numeric(sheet_xlsx[field_map[field]], errors='coerce')

                brands = pd.DataFrame(
                    Brand.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
                models = pd.DataFrame(
                    Model.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
                plant_machinery_groups = pd.DataFrame(
                    PlantMachineryGroup.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
                plant_machinery_machines = pd.DataFrame(
                    PlantMachineryMachine.cmobjects.filter(organization_id=organization_id).values('id', 'machine_number')
                )
                vendor_data = pd.DataFrame(
                    VendorMasterV2.cmobjects.filter(organization_id=organization_id).values('id', 'vendor_name')
                )

                brands = brands.fillna(np.nan).replace([np.nan], [None])
                models = models.fillna(np.nan).replace([np.nan], [None])
                plant_machinery_groups = plant_machinery_groups.fillna(np.nan).replace([np.nan], [None])
                plant_machinery_machines = plant_machinery_machines.fillna(np.nan).replace([np.nan], [None])
                vendor_data = vendor_data.fillna(np.nan).replace([np.nan], [None])

                brands = brands.applymap(lambda x: process_str(x) if x else x)
                models = models.applymap(lambda x: process_str(x) if x else x)
                plant_machinery_groups = plant_machinery_groups.applymap(lambda x: process_str(x) if x else x)
                plant_machinery_machines = plant_machinery_machines.applymap(lambda x: process_str(x) if x else x)
                vendor_data = vendor_data.applymap(lambda x: process_str(x) if x else x)
               
                def check_brand(row):
                    result = None
                    brand_name = row.get(field_map.get('brand'))
                    if brand_name:
                        processed_name = process_str(brand_name)
                        temp = brands[brands['name'].str.contains(r'^' + processed_name + '$')]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result

                def check_model(row):
                    result = None
                    model_name = row.get(field_map.get('model'))
                    if model_name:
                        processed_name = process_str(model_name)
                        temp = models[models['name'].str.contains(r'^' + processed_name + '$')]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result

                def check_plant_machinery_group(row):
                    result = None
                    group_name = row.get(field_map.get('plant_machinery_group'))
                    if group_name:
                        processed_name = process_str(group_name)
                        temp = plant_machinery_groups[plant_machinery_groups['name'].str.contains(r'^' + processed_name + '$')]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                
                def check_machine(row):
                    result = None
                    machine_number = row[field_map.get('plant_machinery_machine')]
                    if machine_number:
                        processed_number = str(machine_number).strip().lower()
                        temp = plant_machinery_machines[
                            plant_machinery_machines['machine_number'].apply(lambda x: str(x).strip().lower() if x is not None else '').str.contains(r'^' + processed_number + '$', na=False)
                        ]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result

                def check_vendor(row):
                    result = None
                    vendor_name = row.get(field_map.get('vendor'))
                    if vendor_name:
                        processed_name = process_str(vendor_name)
                        temp = vendor_data[vendor_data['vendor_name'].str.contains(r'^' + processed_name + '$')]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
               

                # Process each row in the DataFrame
                for index, row in sheet_xlsx.iterrows():
                    data = {
                        'organization_id': organization_id,
                        'plant_machinery_group_id': check_plant_machinery_group(row) if row.get(field_map.get('plant_machinery_group')) else None,
                        'plant_machinery_machine_id': check_machine(row) if row.get(field_map.get('plant_machinery_machine')) else None,
                        'tyre_serial_number': row.get(field_map.get('tyre_serial_number', '')),
                        'brand_id': check_brand(row) if row.get(field_map.get('brand')) else None,
                        'model_id': check_model(row) if row.get(field_map.get('model')) else None,
                        'model_text': row.get(field_map.get('model_text', '')),
                        'make_text': row.get(field_map.get('make_text', '')),
                        'vehicle_km_reading': handle_nan(row.get(field_map.get('vehicle_km_reading', 0))),
                        'vehicle_hrs_reading': handle_nan(row.get(field_map.get('vehicle_hrs_reading', 0))),
                        # 'sold_amount': row.get(field_map.get('sold_amount', 0)),
                        # 'tyre_number': row.get(field_map.get('tyre_number', '')),
                        'status': row.get(field_map.get('status', '')),
                        'vehicle_number': row.get(field_map.get('vehicle_number', '')),
                        'issue_date': row.get(field_map.get('issue_date'),None),
                        'sold_date': row.get(field_map.get('sold_date'),None),
                        'position_new': str(row.get(field_map.get('position'))).upper() if row.get(field_map.get('position')) else "" ,

                        'vendor_id': check_vendor(row) if row.get(field_map.get('vendor')) else None,
                        'purchase_date': row.get(field_map.get('purchase_date'),None),
                        'invoice_number': row.get(field_map.get('invoice_number', '')),
                        'purchase_amount_cost': handle_nan(row.get(field_map.get('purchase_amount_cost', 0))),
                        'size': row.get(field_map.get('size', '')),
                        'tread': handle_nan(row.get(field_map.get('tread', 0))),
                        'ply_rating': handle_nan(row.get(field_map.get('ply_rating', 0))),
                        # 'run_at_pur': row.get(field_map.get('run_at_pur', 0)),
                        'number_of_remould': handle_nan(row.get(field_map.get('number_of_remould', 0))),
                        # 'tread_depth': row.get(field_map.get('tread_depth', 0)),
                        'grip': handle_nan(row.get(field_map.get('grip', 0))),
                        # 'warranty_days': row.get(field_map.get('warranty_days', 0)),
                        'warranty_km': handle_nan(row.get(field_map.get('warranty_km', 0))),
                        # 'load_capacity': row.get(field_map.get('load_capacity', 0)),
                        # 'casing': row.get(field_map.get('casing', 0)),
                        'tyre_type': str(row.get(field_map.get('tyre_type'))).upper() if row.get(field_map.get('tyre_type')) else "",
                        'tyre_type1': str(row.get(field_map.get('tyre_type1'))).upper() if row.get(field_map.get('tyre_type1')) else "",
                        'tyre_type2': str(row.get(field_map.get('tyre_type2'))).upper() if row.get(field_map.get('tyre_type2')) else "",
                        'std_psi': handle_nan(row.get(field_map.get('std_psi', 0))),
                        # 'other_remark': row.get(field_map.get('other_remark', '')),
                    }
                    

                    if row.get('id'):
                        PlantMachineryTyre.cmobjects.filter(pk=row['id']).update(updated_by_id=request.user.id, **data)
                        count_data['tyre_edit'] += 1
                    else:
                        PlantMachineryTyre.objects.create(created_by_id=request.user.id, **data)
                        count_data['tyre_add'] += 1

                return Response(
                    {'results': {'Data': count_data},
                     'msg': 'Successfully processed',
                     'status': status.HTTP_201_CREATED,
                     'request_status': 1})

        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})

class PlantMachineryLogBookMainAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        created_by__full_name__icontains = request.query_params.get('created_by__full_name__icontains', None)

        search = {}
        _exclude = ['created_by__full_name__icontains']
        search = custom_filters(request, search, _exclude)
      
        _list = PlantMachineryLogBook.cmobjects.select_related(
            'organization', 'plant_machinery_machine', 'plant_machinery_group',
            'driver_operator', 'site', 'project'
        ).prefetch_related('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage').annotate(
            wbs_code=Case(
                    When(plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__cost_type='normal',
                        then=F('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__wbs_chainage__value')),
                    When(plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__cost_type='indirect',
                        then=F('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__indirect_chainage__wbs_code')),
                    output_field=CharField()
                ),
            wbs_name=Case(
                    When(plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__cost_type='normal',
                        then=F('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__wbs_chainage__wbs__wbs')),
                    When(plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__cost_type='indirect',
                        then=F('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__indirect_chainage__indirect_cost')),
                    output_field=CharField()
                ),
            boq_type=Case(
                    When(plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__cost_type='normal',
                        then=F('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__wbs__wbs')),
                    When(plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__cost_type='indirect',
                        then=Value('Indirect Exp.')),
                    output_field=CharField()
                ),    
            wbs_lot_no=Case(
                When(
                    plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__cost_type='normal',
                    then=F('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__wbs_chainage__form__name')
                ),
                default=Value(''),
                output_field=CharField()
            ),
          
            wbs_working_kms = Case(
                When(
                    ~Q(plant_machinery_machine__plant_machinery_group__machine_type='machine'),
                    then=F('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__working_kms')
                ),
                default=Value(0),
                output_field=FloatField()
            ),
            wbs_working_hrs = Case(
                When(
                    plant_machinery_machine__plant_machinery_group__machine_type='machine',
                    then=F('plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__working_hrs')
                ),
                default=Value(0),
                output_field=FloatField()
            ),
        ).values(
            'id','log_book_date', 'site__site_name','plant_machinery_machine__plant_machinery_group__machine_type',
            'plant_machinery_group__name', 'plant_machinery_machine__machine_number',
            'plant_machinery_machine__equipment_description', 'plant_machinery_machine__registration_no',
            'plan_hrs', 'plan_km', 'start_hrs', 'close_hrs', 'working_hrs', 'extra_working_hrs',
            'total_working_hrs', 'bd_hrs', 'idle_hrs', 'start_kms', 'close_kms', 'total_km_run',
            'total_fuel_filled', 'plant_machinery_machine__machine_info_standard_norms_ltr_km',
            'actual_norms','standard_norms','difference_norms', 'driver_operator__name',
            'total_production_qty_cum', 'total_production_qty_ton', 'gsb_aggregate_trips',
            'dbm_bc_trips', 'pqc_dlc_trips', 'soil_bt_cuttingmisc_trips', 'wmm_trips',
            'number_of_trips', 'last_entry_date', 'remark', 'boq',
            'from_chainage', 'to_chainage',
            'plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__pk',
            'wbs_code', 'wbs_name', 'wbs_lot_no', 'wbs_working_kms', 'wbs_working_hrs','boq_type',
            'plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__from_chainage',
            'plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__to_chainage',
            'plant_machinery_log_book_plant_machinery_log_book_wbs_chainage__wbs__wbs'
        ).filter(*search).distinct().order_by(*str(order_by).split(','))

        if all == 'true':
            return Response({'results': list(_list)})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': list(page.object_list),
            },
        })


class PlantMachineryLogBookMainV2APIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        # start_date = request.query_params.get('log_book_date__gte', None)
        # end_date = request.query_params.get('log_book_date__lte', None)

        search = custom_filters(request, {}, [])
        _list =  PlantMachineryLogBook.cmobjects.select_related(
                    'organization', 'site', 'location', 'plant_machinery_machine',
                    'driver_operator', 'project'
                ).filter(*search).annotate(
                start_value=Case(
                    When(plant_machinery_machine__plant_machinery_group__machine_type='machine', then=F('start_hrs')),
                    When(plant_machinery_machine__plant_machinery_group__machine_type='vehicle', then=F('start_kms')),
                    default=Value(0),
                    output_field=FloatField()
                ),
                close_value=Case(
                    When(plant_machinery_machine__plant_machinery_group__machine_type='machine', then=F('close_hrs')),
                    When(plant_machinery_machine__plant_machinery_group__machine_type='vehicle', then=F('close_kms')),
                    default=Value(0),
                    output_field=FloatField()
                ),
                monthly_rent=Coalesce(
                    Sum(
                        Subquery(
                            PlantMachineryMachineRent.cmobjects.filter(
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                rent_date__lte=OuterRef('log_book_date'),
                                rent_to_date__gte=OuterRef('log_book_date'),
                            )
                            .values('rent_date')
                            .annotate(daily_avg=Avg('rent_amount'))
                            # .order_by('rent_date') 
                            .values('daily_avg')
                        )
                    ),
                    Value(0.0),
                    output_field=FloatField()
                ),
            ).values(
                'id',
                'log_book_date',
                'request_code',
                'site_id',
                'project_id',
                'plant_machinery_machine_id',
                'plant_machinery_machine__equipment_description',
                'plant_machinery_machine__plant_machinery_group__machine_type',
                'plant_machinery_machine__machine_number',
                'plant_machinery_machine__registration_no',
                'plant_machinery_machine__hsn_code',
                'plant_machinery_machine__vendor_id',
                'plant_machinery_machine__vendor__vendor_name',
                'total_fuel_filled',
                'remark',
                'in_service',
                'hire_bill_remarks',
                'start_value',
                'close_value',
                'monthly_rent',
            ).order_by(*str(order_by).split(','))

        if all == 'true':
            return Response({'results': _list})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': page.object_list,
            },
        })
        
class PlantMachineryLogBookAPIView(APIView):
    """
    CRUD API for model: PlantMachineryLogBook
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryLogBook
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        created_by__full_name__icontains = request.query_params.get('created_by__full_name__icontains', None)

        if id:
            _details = PlantMachineryLogBook.cmobjects.filter(id=id).first()
            serializer = PlantMachineryLogBookSerializer(_details)
            return Response(serializer.data)

        search = {}
        _exclude = ['created_by__full_name__icontains']
        search = custom_filters(request, search, _exclude)

        _list = PlantMachineryLogBook.cmobjects.select_related(
            'organization',
            'plant_machinery_machine',
            'plant_machinery_group',
            'driver_operator',
            'location',
            'site'
        ).annotate(total=Sum(
                Case(
                    When(plant_machinery_group__machine_type='machine', then='total_working_hrs'),
                    When(plant_machinery_group__machine_type='vehicle', then='total_km_run'),
                    default=Value(0),
                    output_field=FloatField(),
                )
            ),
            plan=Sum(
                Case(
                    When(plant_machinery_group__machine_type='machine', then='plan_hrs'),
                    When(plant_machinery_group__machine_type='vehicle', then='plan_km'),
                    default=Value(0),
                    output_field=FloatField(),
                )
            ),
            utilization=ExpressionWrapper(
                Case(
                    When(plan__gt=0, then=F('total') * 100 / F('plan')),
                    default=Value(0),
                    output_field=FloatField(),
                ),
                output_field=FloatField()
            )).filter(*search).order_by(*str(order_by).split(","))

        if created_by__full_name__icontains:
            _list = update_query_for_user_search(created_by__full_name__icontains, _list, 'created_by')
            # print('_list', _list.query)

        if all == 'true':
            serializer = PlantMachineryLogBookSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryLogBookSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryLogBook
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryLogBookSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryLogBook details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        log_book_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryLogBook
                """
                if PlantMachineryLogBook.cmobjects.filter(pk=log_book_id, organization_id=organization_id).exists():
                    details = PlantMachineryLogBook.cmobjects.filter(pk=log_book_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryLogBookSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryLogBook
                """
                if PlantMachineryLogBook.cmobjects.filter(pk=log_book_id, organization_id=organization_id).exists():
                    details = PlantMachineryLogBook.cmobjects.get(pk=log_book_id, organization_id=organization_id)
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryLogBook.objects.filter(pk=log_book_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})                

class PlantMachineryLogBookImportAPIView(APIView):
    """
    API for importing PlantMachineryLogBook data from an Excel file.
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'logbook_add': 0, 'logbook_edit': 0,'wbs_chainage_add':0,'wbs_chainage_edit':0}
                organization_id = request.query_params.get('organization_id', None)
                project_id = request.query_params.get('project_id', None)
                site_id = request.query_params.get('site_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                if organization_id and project_id and site_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID  ,Project ID  and Site ID are not provided"})
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                def process_str(x):
                    # if isinstance(x, str):
                    #     x = x.lower().strip().replace(' ', '')
                    # return x
                    x = str(x) if x is not None else ''
                    x = x.lower().strip().replace(' ', '').replace('nat', '')
                        
                    return x

                date_fields = ['log_book_date', 'allotment_date']
                for field in date_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_datetime(sheet_xlsx[field_map[field]], errors='coerce')
                # Convert numeric fields
                numeric_fields = [
                    'number_of_trips', 'quantity', 'plan_hrs', 'purchase_amount_cost', 'tread',
                    'ply_rating', 'run_at_pur', 'number_of_remould', 'tread_depth', 'grip',
                    'warranty_days', 'warranty_km', 'load_capacity', 'casing', 'start_hrs',
                    'close_hrs', 'working_hrs', 'total_working_hrs', 'bd_hrs', 'idle_hrs',
                    'extra_working_hrs', 'start_kms', 'close_kms', 'total_km_run',
                    'total_fuel_filled', 'standard_norms', 'actual_norms', 'difference_norms',
                    'total_production_qty_cum', 'total_production_qty_ton', 'gsb_aggregate_trips',
                    'dbm_bc_trips', 'pqc_dlc_trips', 'soil_bt_cuttingmisc_trips', 'wmm_trips',
                    'total_trips','wbs_chainage_working_hrs'
                ]
                for field in numeric_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_numeric(sheet_xlsx[field_map[field]], errors='coerce')
                sheet_xlsx['log_book_id'] = None
                plant_machinery_machines = pd.DataFrame(
                    PlantMachineryMachine.cmobjects.filter(organization_id=organization_id).values('id', 'machine_number','plant_machinery_group_id','plant_machinery_group__machine_type')
                )
                # plant_machinery_groups = pd.DataFrame(
                #     PlantMachineryGroup.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                # )
                drivers = pd.DataFrame(
                    PlantMachineryMachineDriver.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
             
                locations = pd.DataFrame(
                    StoreMaster.cmobjects.filter(organization_id=organization_id).values('id', 'store_name', 'site_id')
                )
                print(locations)
              
                wbs_data = pd.DataFrame(
                    WBSList.cmobjects.filter(organization_id=organization_id).values('id', 'wbs','boq_code')
                )
                wbs_chainage_details = pd.DataFrame(
                    BOQChainageExecutiveSummeryData.cmobjects.filter(organization_id=organization_id).values('id', 'value')
                )
                indirect_chainage_data = pd.DataFrame(
                    WbsIndirectCostPlaning.cmobjects.filter(organization_id=organization_id).values('id', 'wbs_code')
                )
                boq_chainage_data = pd.DataFrame(
                    BOQChainage.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
                for column in field_map.values():
                    if column not in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])

                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                plant_machinery_machines = plant_machinery_machines.fillna(np.nan).replace([np.nan], [None])
                plant_machinery_machines = plant_machinery_machines.applymap(lambda x: process_str(x))
                # plant_machinery_groups = plant_machinery_groups.fillna(np.nan).replace([np.nan], [None])
                # plant_machinery_groups = plant_machinery_groups.applymap(lambda x: process_str(x))
                drivers = drivers.fillna(np.nan).replace([np.nan], [None])
                drivers = drivers.applymap(lambda x: process_str(x))

                locations = locations.fillna(np.nan).replace([np.nan], [None])
                locations = locations.applymap(lambda x: process_str(x))
                wbs_data = wbs_data.fillna(np.nan).replace([np.nan], [None])
                wbs_data = wbs_data.applymap(lambda x: process_str(x) if x else x)
                
                wbs_chainage_details= wbs_chainage_details.fillna(np.nan).replace([np.nan], [None])
                wbs_chainage_details = wbs_chainage_details.applymap(lambda x: process_str(x) if x else x)
                indirect_chainage_data= indirect_chainage_data.fillna(np.nan).replace([np.nan], [None])
                indirect_chainage_data = indirect_chainage_data.applymap(lambda x: process_str(x) if x else x)
                boq_chainage_data= boq_chainage_data.fillna(np.nan).replace([np.nan], [None])
                boq_chainage_data = boq_chainage_data.applymap(lambda x: process_str(x) if x else x)
                # def check_plant_machinery_group(row):
                #     result = None
                #     group_name = row[field_map.get('plant_machinery_group')]
                #     if group_name:
                #         processed_name = process_str(group_name)
                #         temp = plant_machinery_groups[plant_machinery_groups['name'].str.contains(r'^' + processed_name + '$')]
                        
                #         if not temp.empty:
                #             result = temp.iloc[0]['id']
                #     return result    
                def check_machine(row):
                    result = None
                    plant_machinery_group_id = None
                    plant_machinery_group__machine_type = None
                    machine_number = row[field_map.get('plant_machinery_machine')]
                    if machine_number:
                        processed_number = str(machine_number).strip().lower()
                        print(processed_number)
                        temp = plant_machinery_machines[
                            plant_machinery_machines['machine_number'].apply(lambda x: str(x).strip().lower() if x is not None else '').str.contains(r'^' + processed_number + '$', na=False)
                        ]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                            plant_machinery_group_id = temp.iloc[0]['plant_machinery_group_id']
                            plant_machinery_group__machine_type = temp.iloc[0]['plant_machinery_group__machine_type']
                    return result, plant_machinery_group_id, plant_machinery_group__machine_type
                def check_driver(row):
                    result = None
                    driver_name = row[field_map.get('driver_operator')]
                    if driver_name:
                        processed_name = process_str(driver_name)
                        temp = drivers[drivers['name'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                def check_location(row):
                    result = None
                    store_name = row[field_map.get('location')]
                    if store_name:
                        processed_name = process_str(store_name)
                        temp = locations[locations['store_name'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                def check_wbs(row):
                    result = None
                    wbs_name = row.get(field_map.get('wbs'))
                    if pd.notna(wbs_name):  
                        processed_name = process_str(wbs_name)
                        temp = wbs_data[wbs_data['wbs'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                def check_wbs_chainage(row):
                    result = None
                    wbs_chainage_name = row.get(field_map.get('wbs_code'))
                    if pd.notna(wbs_chainage_name):  
                        processed_name = process_str(wbs_chainage_name)
                        print(type(processed_name))
                        temp = wbs_chainage_details[wbs_chainage_details['value'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    
                    return result
                def check_indirect_chainage(row):
                    result = None
                    indirect_chainage_name = row.get(field_map.get('wbs_code'))
                    if pd.notna(indirect_chainage_name):  
                        processed_name = process_str(indirect_chainage_name)
                        temp = indirect_chainage_data[indirect_chainage_data['wbs_code'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                def check_boq_chainage(row):
                    result = None
                    boq_chainage_name = row.get(field_map.get('boq_chainage'))
                    if pd.notna(boq_chainage_name):  
                        processed_name = process_str(boq_chainage_name)
                        temp = boq_chainage_data[boq_chainage_data['name'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                for index, row in sheet_xlsx.iterrows():
                    machine_id, group_id, machine_type = check_machine(row) if row.get(field_map.get('plant_machinery_machine')) else (None, None, None)
                    data = {
                            # 'organization_id': organization_id,
                            'log_book_date': handle_date(row.get(field_map.get('log_book_date')), None),
                            'owner': row.get(field_map.get('owner')).lower() if row.get(field_map.get('owner')) else None,
                            # 'plant_machinery_machine_id': check_machine(row) if row.get(field_map.get('plant_machinery_machine')) else None ,
                            # 'plant_machinery_group_id': check_plant_machinery_group(row) if row.get(field_map.get('plant_machinery_group')) else None,
                            # 'plant_machinery_group_type': row.get(field_map.get('plant_machinery_group_type'), None),
                            'plant_machinery_machine_id': machine_id,
                            'plant_machinery_group_id': group_id,  
                            'plant_machinery_group_type': machine_type,
                            'driver_operator_id': check_driver(row) if row.get(field_map.get('driver_operator')) else None,
                            'location_id': check_location(row) if row.get(field_map.get('location')) else None,
                            'shift': row.get(field_map.get('shift'), None),
                            'remark': row.get(field_map.get('remark'), None),
                            'number_of_trips': handle_nan(row.get(field_map.get('number_of_trips')), 0),
                            'quantity': handle_nan(row.get(field_map.get('quantity')), 0.0),
                            'plan_hrs': handle_nan(row.get(field_map.get('plan_hrs')), 0.0),
                            'plan_km': handle_nan(row.get(field_map.get('plan_km')), 0.0),
                            'start_hrs': handle_nan(row.get(field_map.get('start_hrs')), 0.0),
                            'close_hrs': handle_nan(row.get(field_map.get('close_hrs')), 0.0),
                            'working_hrs': handle_nan(row.get(field_map.get('working_hrs')), 0.0),
                            'total_working_hrs': handle_nan(row.get(field_map.get('total_working_hrs')), 0.0),
                            'bd_hrs': handle_nan(row.get(field_map.get('bd_hrs')), 0.0),
                            'idle_hrs': handle_nan(row.get(field_map.get('idle_hrs')), 0.0),
                            'extra_working_hrs': handle_nan(row.get(field_map.get('extra_working_hrs')), 0.0),
                            'start_kms': handle_nan(row.get(field_map.get('start_kms')), 0.0),
                            'close_kms': handle_nan(row.get(field_map.get('close_kms')), 0.0),
                            'total_km_run': handle_nan(row.get(field_map.get('total_km_run')), 0.0),
                            'total_fuel_filled': handle_nan(row.get(field_map.get('total_fuel_filled')), 0.0),
                            'standard_norms': handle_nan(row.get(field_map.get('standard_norms')), 0.0),
                            'actual_norms': handle_nan(row.get(field_map.get('actual_norms')), 0.0),
                            'difference_norms': handle_nan(row.get(field_map.get('difference_norms')), 0.0),
                            'total_production_qty_cum': handle_nan(row.get(field_map.get('total_production_qty_cum')), 0.0),
                            'total_production_qty_ton': handle_nan(row.get(field_map.get('total_production_qty_ton')), 0.0),
                            'gsb_aggregate_trips': handle_nan(row.get(field_map.get('gsb_aggregate_trips')), 0),
                            'dbm_bc_trips': handle_nan(row.get(field_map.get('dbm_bc_trips')), 0),
                            'pqc_dlc_trips': handle_nan(row.get(field_map.get('pqc_dlc_trips')), 0),
                            'soil_bt_cuttingmisc_trips': handle_nan(row.get(field_map.get('soil_bt_cuttingmisc_trips')), 0),
                            'wmm_trips': handle_nan(row.get(field_map.get('wmm_trips')), 0),
                            'total_trips': handle_nan(row.get(field_map.get('total_trips')), 0),
                            'last_entry_date': handle_date(row.get(field_map.get('last_entry_date')), None),
                            'boq': row.get(field_map.get('boq'), None),
                            'from_location': row.get(field_map.get('from_location'), None),
                            'from_chainage': row.get(field_map.get('from_chainage'), None),
                            'to_location': row.get(field_map.get('to_location'), None),
                            'to_chainage': row.get(field_map.get('to_chainage'), None),
                            'fueltype': process_str(row.get(field_map.get('fueltype'), '')).lower() if row.get(field_map.get('fueltype')) else '',
                    }
                    if data['log_book_date'] and data['plant_machinery_machine_id']:
                        if machine_type:
                            group_type = str(machine_type).lower()
                            if group_type == 'vehicle':
                                data['plan_km'] = 100
                                data['plan_hrs'] = 0
                            elif group_type == 'machine':
                                data['plan_hrs'] = 10
                                data['plan_km'] = 0 
                        
                        logbook, created = PlantMachineryLogBook.cmobjects.update_or_create(
                            organization_id=organization_id,
                            project_id=project_id,
                            site_id=site_id,
                            log_book_date=data['log_book_date'],
                            plant_machinery_machine_id=data['plant_machinery_machine_id'],
                            defaults=data
                        )
                        if created:
                            logbook.created_by_id = request.user.id
                            count_data['logbook_add'] += 1
                        else:
                            logbook.updated_by_id = request.user.id
                            count_data['logbook_edit'] += 1
                        logbook.save()
                        if logbook:
                            # print(f"Type of logbook.id: {type(logbook.id)}")
                            sheet_xlsx.at[index, 'log_book_id'] = logbook.id
                            # print("Updated DataFrame:",logbook.id)
                            # print(sheet_xlsx)
                            
                sheet_xlsx['log_book_id'].ffill(inplace=True)
                sheet_xlsx['log_book_id'] = sheet_xlsx['log_book_id'].replace({np.nan: None})
                log_book_ids = set()
                for index, row in sheet_xlsx.iterrows():
                    log_book_id = row.get('log_book_id')
                    cost_type = process_str(row.get(field_map.get('cost_type'), '')).lower() if row.get(field_map.get('cost_type')) else ''
                    if log_book_id and cost_type :
                        wbs_chainage_data = {
                            'wbs_id':check_wbs(row) if row.get(field_map.get('wbs')) else None,
                            'boq_chainage_id':check_boq_chainage(row) if row.get(field_map.get('boq_chainage')) else None,
                            'cost_type': cost_type,
                            'from_chainage': handle_nan(row.get(field_map.get('wbs_chainage_from_chainage')), 0.0),
                            'to_chainage': handle_nan(row.get(field_map.get('wbs_chainage_to_chainage')), 0.0),
                            'working_hrs': handle_nan(row.get(field_map.get('wbs_chainage_working_hrs')), 0.0),
                            'working_kms': handle_nan(row.get(field_map.get('wbs_chainage_working_kms')), 0.0),
                        }
                        if cost_type == 'normal':
                            wbs_chainage_id = check_wbs_chainage(row) if row.get(field_map.get('wbs_code')) else None 
                            wbs_chainage_data.update({
                                'wbs_chainage_id': wbs_chainage_id,
                                'indirect_chainage_id': None
                            })
                        elif cost_type == 'indirect':
                            indirect_chainage_id = check_indirect_chainage(row) if row.get(field_map.get('wbs_code')) else None
                            wbs_chainage_data.update({
                                'wbs_chainage_id': None,
                                'indirect_chainage_id': indirect_chainage_id
                            })
                        else:
                            continue 
                        wbs_chainage_obj, created = PlantMachineryLogBookWbsChainage.cmobjects.update_or_create(
                            organization_id = organization_id ,plant_machinery_log_book_id=log_book_id,
                            defaults=wbs_chainage_data,
                        )
                        # print(wbs_chainage_obj,log_book_id)
                        if created:
                            wbs_chainage_obj.created_by_id = request.user.id
                            count_data['wbs_chainage_add'] += 1
                        else:
                            wbs_chainage_obj.updated_by_id = request.user.id
                            count_data['wbs_chainage_edit'] += 1
                        wbs_chainage_obj.save()    
                        log_book_ids.add(log_book_id)
                if log_book_ids:
                    PlantMachineryLogBook.cmobjects.filter(id__in=log_book_ids).update(tag_wbs=True)
                return Response(
                    {'results': {'Data': count_data},
                     'msg': 'Successfully created',
                     'status': status.HTTP_201_CREATED,
                     'request_status': 1})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
        
class PlantMachineryLogBookImportTestAPIView(APIView):
    """
    API for importing PlantMachineryLogBook data from an Excel file.
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'logbook_add': 0, 'logbook_edit': 0,'wbs_chainage_add':0}
                organization_id = request.query_params.get('organization_id', None)
                project_id = request.query_params.get('project_id', None)
                site_id = request.query_params.get('site_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})

                if organization_id and project_id and site_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID  ,Project ID  and Site ID are not provided"})

                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                def process_str(x):
                    # if isinstance(x, str):
                    #     x = x.lower().strip().replace(' ', '')
                    # return x
                    x = str(x) if x is not None else ''
                    x = x.lower().strip().replace(' ', '').replace('nat', '')
                        
                    return x

                date_fields = ['log_book_date', 'allotment_date']
                for field in date_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_datetime(sheet_xlsx[field_map[field]], errors='coerce')
                # Convert numeric fields
                numeric_fields = [
                    'number_of_trips', 'quantity', 'plan_hrs', 'purchase_amount_cost', 'tread',
                    'ply_rating', 'run_at_pur', 'number_of_remould', 'tread_depth', 'grip',
                    'warranty_days', 'warranty_km', 'load_capacity', 'casing', 'start_hrs',
                    'close_hrs', 'working_hrs', 'total_working_hrs', 'bd_hrs', 'idle_hrs',
                    'extra_working_hrs', 'start_kms', 'close_kms', 'total_km_run',
                    'total_fuel_filled', 'standard_norms', 'actual_norms', 'difference_norms',
                    'total_production_qty_cum', 'total_production_qty_ton', 'gsb_aggregate_trips',
                    'dbm_bc_trips', 'pqc_dlc_trips', 'soil_bt_cuttingmisc_trips', 'wmm_trips',
                    'total_trips','wbs_chainage_working_hrs'
                ]
                for field in numeric_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_numeric(sheet_xlsx[field_map[field]], errors='coerce')
                sheet_xlsx['log_book_id'] = None
                # Fetch existing data for checks
                plant_machinery_machines = pd.DataFrame(
                    PlantMachineryMachine.cmobjects.filter(organization_id=organization_id).values('id', 'machine_number')
                )
                plant_machinery_groups = pd.DataFrame(
                    PlantMachineryGroup.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
                drivers = pd.DataFrame(
                    PlantMachineryMachineDriver.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
                # sites = pd.DataFrame(
                #     SiteMaster.cmobjects.filter(organization_id=organization_id).values('id', 'site_name')
                # )
                locations = pd.DataFrame(
                    StoreMaster.cmobjects.filter(organization_id=organization_id).values('id', 'store_name', 'site_id')
                )
                print(locations)
                # project_data = pd.DataFrame(
                #     ProjectData.cmobjects.filter(project__organization_id=organization_id,
                #         form__form_type='project_details',
                #     ).select_related('form').values('project_id', 'form__form_internal_name', 'value')
                # )
                # boq_data = pd.DataFrame(
                #     BOQ.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                # )
                wbs_data = pd.DataFrame(
                    WBSList.cmobjects.filter(organization_id=organization_id).values('id', 'wbs','boq_code')
                )
                wbs_chainage_details = pd.DataFrame(
                    BOQChainageExecutiveSummeryData.cmobjects.filter(organization_id=organization_id).values('id', 'value')
                )
                indirect_chainage_data = pd.DataFrame(
                    WbsIndirectCostPlaning.cmobjects.filter(organization_id=organization_id).values('id', 'wbs_code')
                )
                boq_chainage_data = pd.DataFrame(
                    BOQChainage.cmobjects.filter(organization_id=organization_id).values('id', 'name')
                )
                print(wbs_chainage_details,"wbs chainage data")

               
                for column in field_map.values():
                    if column not in sheet_xlsx:
                        sheet_xlsx[column] = np.nan

                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                # sheet_xlsx = sheet_xlsx.where(pd.notnull(sheet_xlsx), None)

                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)

                plant_machinery_machines = plant_machinery_machines.fillna(np.nan).replace([np.nan], [None])
                plant_machinery_machines = plant_machinery_machines.applymap(lambda x: process_str(x))
                plant_machinery_groups = plant_machinery_groups.fillna(np.nan).replace([np.nan], [None])
                plant_machinery_groups = plant_machinery_groups.applymap(lambda x: process_str(x))
                drivers = drivers.fillna(np.nan).replace([np.nan], [None])
                drivers = drivers.applymap(lambda x: process_str(x))

                # sites = sites.fillna(np.nan).replace([np.nan], [None])
                # sites = sites.applymap(lambda x: process_str(x))

                locations = locations.fillna(np.nan).replace([np.nan], [None])
                locations = locations.applymap(lambda x: process_str(x))

                # boq_data = boq_data.fillna(np.nan).replace([np.nan], [None])
                # boq_data = boq_data.applymap(lambda x: process_str(x))

                # project_data = project_data.fillna(np.nan).replace([np.nan], [None])
                # project_data = project_data.applymap(lambda x: process_str(x) if x else x)

                wbs_data = wbs_data.fillna(np.nan).replace([np.nan], [None])
                wbs_data = wbs_data.applymap(lambda x: process_str(x) if x else x)
                
                wbs_chainage_details= wbs_chainage_details.fillna(np.nan).replace([np.nan], [None])
                wbs_chainage_details = wbs_chainage_details.applymap(lambda x: process_str(x) if x else x)
                indirect_chainage_data= indirect_chainage_data.fillna(np.nan).replace([np.nan], [None])
                indirect_chainage_data = indirect_chainage_data.applymap(lambda x: process_str(x) if x else x)
                boq_chainage_data= boq_chainage_data.fillna(np.nan).replace([np.nan], [None])
                boq_chainage_data = boq_chainage_data.applymap(lambda x: process_str(x) if x else x)
                def check_plant_machinery_group(row):
                    result = None
                    group_name = row[field_map.get('plant_machinery_group')]
                    if group_name:
                        processed_name = process_str(group_name)
                        temp = plant_machinery_groups[plant_machinery_groups['name'].str.contains(r'^' + processed_name + '$')]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result    
                def check_machine(row):
                    result = None
                    machine_number = row[field_map.get('plant_machinery_machine')]
                    if machine_number:
                        processed_number = str(machine_number).strip().lower()
                        temp = plant_machinery_machines[
                            plant_machinery_machines['machine_number'].apply(lambda x: str(x).strip().lower() if x is not None else '').str.contains(r'^' + processed_number + '$', na=False)
                        ]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result

                def check_driver(row):
                    result = None
                    driver_name = row[field_map.get('driver_operator')]
                    if driver_name:
                        processed_name = process_str(driver_name)
                        temp = drivers[drivers['name'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result

                def check_location(row):
                    result = None
                    store_name = row[field_map.get('location')]
                    if store_name:
                        processed_name = process_str(store_name)
                        temp = locations[locations['store_name'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result

                
                def check_wbs(row):
                    result = None
                    wbs_name = row.get(field_map.get('wbs'))
                    if pd.notna(wbs_name):  
                        processed_name = process_str(wbs_name)
                        temp = wbs_data[wbs_data['wbs'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                def check_wbs_chainage(row):
                    result = None
                    wbs_chainage_name = row.get(field_map.get('wbs_code'))
                    if pd.notna(wbs_chainage_name):  
                        processed_name = process_str(wbs_chainage_name)
                        print(type(processed_name))
                        temp = wbs_chainage_details[wbs_chainage_details['value'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    
                    return result
                def check_indirect_chainage(row):
                    result = None
                    indirect_chainage_name = row.get(field_map.get('wbs_code'))
                    if pd.notna(indirect_chainage_name):  
                        processed_name = process_str(indirect_chainage_name)
                        temp = indirect_chainage_data[indirect_chainage_data['wbs_code'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                def check_boq_chainage(row):
                    result = None
                    boq_chainage_name = row.get(field_map.get('boq_chainage'))
                    if pd.notna(boq_chainage_name):  
                        processed_name = process_str(boq_chainage_name)
                        temp = boq_chainage_data[boq_chainage_data['name'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result
                wbs_chainage_data_add = []
                for index, row in sheet_xlsx.iterrows():
                    data = {
                            'organization_id': organization_id,
                            'log_book_date': handle_date(row.get(field_map.get('log_book_date')), None),
                            'owner': row.get(field_map.get('owner'), None),
                            'plant_machinery_machine_id': check_machine(row) if row.get(field_map.get('plant_machinery_machine')) else None ,
                            'plant_machinery_group_id': check_plant_machinery_group(row) if row.get(field_map.get('plant_machinery_group')) else None,
                            'driver_operator_id': check_driver(row) if row.get(field_map.get('driver_operator')) else None,
                            'plant_machinery_group_type': row.get(field_map.get('plant_machinery_group_type'), None),
                            'location_id': check_location(row) if row.get(field_map.get('location')) else None,
                            'shift': row.get(field_map.get('shift'), None),
                            'remark': row.get(field_map.get('remark'), None),
                            'number_of_trips': handle_nan(row.get(field_map.get('number_of_trips')), 0),
                            'quantity': handle_nan(row.get(field_map.get('quantity')), 0.0),
                            # 'project_id': check_project(row) or None,
                            'plan_hrs': handle_nan(row.get(field_map.get('plan_hrs')), 0.0),
                            'plan_km': handle_nan(row.get(field_map.get('plan_km')), 0.0),
                            'start_hrs': handle_nan(row.get(field_map.get('start_hrs')), 0.0),
                            'close_hrs': handle_nan(row.get(field_map.get('close_hrs')), 0.0),
                            'working_hrs': handle_nan(row.get(field_map.get('working_hrs')), 0.0),
                            'total_working_hrs': handle_nan(row.get(field_map.get('total_working_hrs')), 0.0),
                            'bd_hrs': handle_nan(row.get(field_map.get('bd_hrs')), 0.0),
                            'idle_hrs': handle_nan(row.get(field_map.get('idle_hrs')), 0.0),
                            'extra_working_hrs': handle_nan(row.get(field_map.get('extra_working_hrs')), 0.0),
                            'start_kms': handle_nan(row.get(field_map.get('start_kms')), 0.0),
                            'close_kms': handle_nan(row.get(field_map.get('close_kms')), 0.0),
                            'total_km_run': handle_nan(row.get(field_map.get('total_km_run')), 0.0),
                            'total_fuel_filled': handle_nan(row.get(field_map.get('total_fuel_filled')), 0.0),
                            'standard_norms': handle_nan(row.get(field_map.get('standard_norms')), 0.0),
                            'actual_norms': handle_nan(row.get(field_map.get('actual_norms')), 0.0),
                            'difference_norms': handle_nan(row.get(field_map.get('difference_norms')), 0.0),
                            'total_production_qty_cum': handle_nan(row.get(field_map.get('total_production_qty_cum')), 0.0),
                            'total_production_qty_ton': handle_nan(row.get(field_map.get('total_production_qty_ton')), 0.0),
                            'gsb_aggregate_trips': handle_nan(row.get(field_map.get('gsb_aggregate_trips')), 0),
                            'dbm_bc_trips': handle_nan(row.get(field_map.get('dbm_bc_trips')), 0),
                            'pqc_dlc_trips': handle_nan(row.get(field_map.get('pqc_dlc_trips')), 0),
                            'soil_bt_cuttingmisc_trips': handle_nan(row.get(field_map.get('soil_bt_cuttingmisc_trips')), 0),
                            'wmm_trips': handle_nan(row.get(field_map.get('wmm_trips')), 0),
                            'total_trips': handle_nan(row.get(field_map.get('total_trips')), 0),
                            'last_entry_date': handle_date(row.get(field_map.get('last_entry_date')), None),
                            'boq': row.get(field_map.get('boq'), None),
                            'from_location': row.get(field_map.get('from_location'), None),
                            'from_chainage': row.get(field_map.get('from_chainage'), None),
                            'to_location': row.get(field_map.get('to_location'), None),
                            'to_chainage': row.get(field_map.get('to_chainage'), None),
                            'fueltype': process_str(row.get(field_map.get('fueltype'), '')),
                            # 'tag_wbs': row[field_map['tag_wbs']] if row[field_map['tag_wbs']] is not None else False,
                            # 'wbs_id': check_wbs(row),
                            # 'chainage_id': check_chainage(row),
                    }
                   
                    # request_code = row.get(field_map.get('request_code'), None)
                    # log_book_date= handle_date(row.get(field_map.get('log_book_date')), None)

                    # if request_code:
                    #     logbook = PlantMachineryLogBook.objects.filter(request_code=request_code).first()
                    #     if logbook:
                    #         logbook.updated_by_id = request.user.id
                    #         for key, value in data.items():
                    #             setattr(logbook, key, value)
                    #         logbook.save()
                    #         count_data['logbook_edit'] += 1
                        # else:
                        #     logbook = PlantMachineryLogBook.objects.create(created_by_id=request.user.id, **data)
                        #     logbook.request_code = generate_all_code(logbook, ['LB'])
                        #     logbook.save()
                        #     count_data['logbook_add'] += 1
                    # if not request_code:
                    if data['log_book_date']:    
                        logbook = PlantMachineryLogBook.objects.create(
                                    project_id=project_id,site_id=site_id,created_by_id=request.user.id, **data)
                        # logbook.request_code = generate_all_code(logbook, ['LB'])
                        # logbook.save()
                      
                        count_data['logbook_add'] += 1    
                        if logbook:
                            print(f"Type of logbook.id: {type(logbook.id)}")
                            # sheet_xlsx.at[row,'log_book_id'] = logbook.id 
                            sheet_xlsx.at[index, 'log_book_id'] = logbook.id
                            print("Updated DataFrame:")
                            print(sheet_xlsx)
                            
                sheet_xlsx['log_book_id'].ffill(inplace=True)
                log_book_ids = set()
                for index, row in sheet_xlsx.iterrows():
                    log_book_id = row.get('log_book_id')
                    cost_type = process_str(row.get(field_map.get('cost_type'), ''))
                    if log_book_id and cost_type:
                        wbs_chainage_data = {
                            'organization_id': organization_id,
                            'plant_machinery_log_book_id': log_book_id,
                            'wbs_id':check_wbs(row) if row.get(field_map.get('wbs')) else None,
                            'boq_chainage_id':check_boq_chainage(row) if row.get(field_map.get('boq_chainage')) else None,
                            'cost_type': cost_type,
                            'from_chainage': handle_nan(row.get(field_map.get('wbs_chainage_from_chainage')), 0.0),
                            'to_chainage': handle_nan(row.get(field_map.get('wbs_chainage_to_chainage')), 0.0),
                            'working_hrs': handle_nan(row.get(field_map.get('wbs_chainage_working_hrs')), 0.0),
                            'working_kms': handle_nan(row.get(field_map.get('wbs_chainage_working_kms')), 0.0),
                        }

                        if cost_type == 'normal':
                            wbs_chainage_id = check_wbs_chainage(row) if row.get(field_map.get('wbs_code')) else None 
                            wbs_chainage_data.update({
                                'wbs_chainage_id': wbs_chainage_id,
                                'indirect_chainage_id': None
                            })
                        elif cost_type == 'indirect':
                            indirect_chainage_id = check_indirect_chainage(row) if row.get(field_map.get('wbs_code')) else None
                            wbs_chainage_data.update({
                                'wbs_chainage_id': None,
                                'indirect_chainage_id': indirect_chainage_id
                            })
                        else:
                           
                            continue 
                        wbs_chainage_data_add.append(PlantMachineryLogBookWbsChainage(**wbs_chainage_data))
                        count_data['wbs_chainage_add'] += 1
                        log_book_ids.add(log_book_id)
                if wbs_chainage_data_add:
                    PlantMachineryLogBookWbsChainage.objects.bulk_create(
                        wbs_chainage_data_add,
                        batch_size=1000,
                        ignore_conflicts=False
                    )
                if log_book_ids:
                    PlantMachineryLogBook.objects.filter(id__in=log_book_ids).update(tag_wbs=True)
                return Response(
                    {'results': {'Data': count_data},
                     'msg': 'Successfully created',
                     'status': status.HTTP_201_CREATED,
                     'request_status': 1})

        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
class PlantMachineryInsuranceMasterAPIView(APIView):
    """
    CRUD API for model: PlantMachineryInsuranceMaster
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryInsuranceMaster
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = PlantMachineryInsuranceMaster.cmobjects.filter(id=id).first()
            serializer = PlantMachineryInsuranceMasterSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryInsuranceMaster.cmobjects.select_related(
            'organization','plant_machinery_machine','plant_machinery_machine__plant_machinery_group',
            'plant_machinery_machine__organization'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryInsuranceMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryInsuranceMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryInsuranceMaster
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryInsuranceMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryInsuranceMaster details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        insurance_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryInsuranceMaster
                """
                if PlantMachineryInsuranceMaster.cmobjects.filter(pk=insurance_id, organization_id=organization_id).exists():
                    details = PlantMachineryInsuranceMaster.cmobjects.filter(pk=insurance_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryInsuranceMasterSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryInsuranceMaster
                """
                if PlantMachineryInsuranceMaster.cmobjects.filter(pk=insurance_id, organization_id=organization_id).exists():
                    details = PlantMachineryInsuranceMaster.cmobjects.get(pk=insurance_id, organization_id=organization_id)
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryInsuranceMaster.objects.filter(pk=insurance_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
class PlantMachineryInsuranceMasterImportAPIView(APIView):
    """
    API for importing PlantMachineryInsuranceMaster data from an Excel file.
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'insurance_add': 0, 'insurance_edit': 0}
                organization_id = request.query_params.get('organization_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})

                if organization_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID not provided"})

                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x
                 # Convert date fields
                date_fields = [
                    'insurance_expiry_date',
                    'insurance_date',
                ]
                for field in date_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_datetime(sheet_xlsx[field_map[field]], errors='coerce')

                # Fetch existing insurance master records for parent check
                parent_insurance = pd.DataFrame(
                    PlantMachineryInsuranceMaster.cmobjects.filter(organization_id=organization_id).values('id', 'insurance_head_name')
                )
                
                plant_machinery_machines = pd.DataFrame(
                    PlantMachineryMachine.cmobjects.filter(organization_id=organization_id).values('id', 'machine_number')
                )
                print(plant_machinery_machines)
                for column in field_map.values():
                    if column not in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                parent_insurance = parent_insurance.fillna(np.nan).replace([np.nan], [None])
                parent_insurance = parent_insurance.applymap(lambda x: process_str(x))
                plant_machinery_machines = plant_machinery_machines.fillna(np.nan).replace([np.nan], [None])
                plant_machinery_machines = plant_machinery_machines.applymap(lambda x: process_str(x))
                
                def check_parent(row):
                    result = None
                    parent_name = row[field_map.get('parent')]
                    if parent_name:
                        processed_name = process_str(parent_name)
                        temp = parent_insurance[parent_insurance['insurance_head_name'].str.contains(r'^' + processed_name + '$', na=False)]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    return result

                
                def check_machine(row):
                    result = None
                    machine_number = row[field_map.get('plant_machinery_machine')]
                    if machine_number:
                        processed_number = str(machine_number).strip().lower()  # Ensure it's a string and process
                        temp = plant_machinery_machines[
                            plant_machinery_machines['machine_number'].apply(lambda x: str(x).strip().lower() if x is not None else '').str.contains(r'^' + processed_number + '$', na=False)
                        ]
                        if not temp.empty:
                            result = temp.iloc[0]['id']
                    print(result)  
                    return result
                sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row: check_parent(row), axis=1)
                print(sheet_xlsx)
                for index, row in sheet_xlsx.iterrows():
                    data = {
                        'organization_id': organization_id,
                        'insurance_head_name': row.get(field_map.get('insurance_head_name')) ,
                        'insurance_head_short_name': row.get(field_map.get('insurance_head_short_name')) if row.get(field_map.get('insurance_head_short_name')) else None,
                        'category_type': row.get(field_map.get('category_type')) if row.get(field_map.get('category_type')) else None,
                        'insurance_date': handle_date(row.get(field_map.get('insurance_date')), None) if row.get(field_map.get('insurance_date')) else None,
                        'insurance_expiry_date': handle_date(row.get(field_map.get('insurance_expiry_date')), None) if row.get(field_map.get('insurance_expiry_date')) else None,
                        'parent_id': sheet_xlsx.at[index, 'parent_id'] if pd.notna(sheet_xlsx.at[index, 'parent_id']) else None,
                        'plant_machinery_machine_id': check_machine(row) if row.get(field_map.get('plant_machinery_machine')) else None
                    }
                    
                    if not PlantMachineryInsuranceMaster.cmobjects.filter(insurance_head_name=row.get(field_map.get('insurance_head_name'))).exists():
                    
                        instance = PlantMachineryInsuranceMaster.objects.create(created_by_id=request.user.id, **data)
                        sheet_xlsx['parent_id'] = sheet_xlsx.apply(
                            lambda row1: (instance.id if row[field_map['insurance_head_name']] and row1[field_map['parent']] and (row[field_map['insurance_head_name']] == row1[field_map['parent']]) else row1['parent_id']),
                            axis=1
                        )
                        sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                        count_data['insurance_add'] += 1
                    else:
                        PlantMachineryInsuranceMaster.cmobjects.filter(insurance_head_name=row.get(field_map.get('insurance_head_name'))).update(updated_by_id=request.user.id, **data)    
                        
                        count_data['insurance_edit'] += 1
                        

                return Response(
                    {'results': {'Data': count_data},
                     'msg': 'Successfully created',
                     'status': status.HTTP_201_CREATED,
                     'request_status': 1})

        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})             
class PlantMachineryMachineWorkingAPIView(APIView):
    """
        CRUD API for model: PlantMachineryMachineWorking
    """
    
    

    def get(self, request):
        """
            Get a list PlantMachineryMachineWorking
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryMachineWorking.cmobjects.filter(id=id).first()
            serializer = PlantMachineryMachineWorkingSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

       
        _list = PlantMachineryMachineWorking.objects.select_related(
            'organization',
            'plant_machinery_machine',
            'plant_machinery_group',
            'site',
            'machine_location',  
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryMachineWorkingSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryMachineWorkingSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryMachineWorking
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryMachineWorkingSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryMachineWorking details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        machine_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryMachineWorking
                """
                if PlantMachineryMachineWorking.cmobjects.filter(pk=machine_id, organization_id=organization_id).exists():
                    details = PlantMachineryMachineWorking.cmobjects.filter(pk=machine_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryMachineWorkingSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryMachineWorking
                """
                if PlantMachineryMachineWorking.cmobjects.filter(pk=machine_id, organization_id=organization_id).exists():
                    details = PlantMachineryMachineWorking.cmobjects.filter(pk=machine_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by = request.user
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryMachineWorking.objects.filter(pk=machine_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class PlantMachineryObjectiveIndicationTypeAPIView(APIView):
    """
    CRUD API for model: PlantMachineryObjectiveIndicationType
    """
    
    

    def get(self, request):
        """
        Get a list or a single instance of PlantMachineryObjectiveIndicationType
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        
        if id:
            _details = PlantMachineryObjectiveIndicationType.cmobjects.filter(id=id).first()
            serializer = PlantMachineryObjectiveIndicationTypeSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryObjectiveIndicationType.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(","))
        
        if all == 'true':
            serializer = PlantMachineryObjectiveIndicationTypeSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryObjectiveIndicationTypeSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryObjectiveIndicationType
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryObjectiveIndicationTypeSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryObjectiveIndicationType details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        objective_indication_type_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryObjectiveIndicationType
                """
                if PlantMachineryObjectiveIndicationType.cmobjects.filter(pk=objective_indication_type_id, organization_id=organization_id).exists():
                    details = PlantMachineryObjectiveIndicationType.cmobjects.filter(pk=objective_indication_type_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryObjectiveIndicationTypeSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryObjectiveIndicationType
                """
                if PlantMachineryObjectiveIndicationType.cmobjects.filter(pk=objective_indication_type_id, organization_id=organization_id).exists():
                    details = PlantMachineryObjectiveIndicationType.cmobjects.filter(pk=objective_indication_type_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryObjectiveIndicationType.objects.filter(pk=objective_indication_type_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class PlantMachineryManpowerAPIView(APIView):
    """
    CRUD API for model: PlantMachineryManpower
    """
    
    

    def get(self, request):
        """
        Get a list or a single instance of PlantMachineryManpower
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        
        if id:
            _details = PlantMachineryManpower.cmobjects.filter(id=id).first()
            serializer = PlantMachineryManpowerSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryManpower.cmobjects.select_related(
            'organization'
        ).filter(*search).order_by(*str(order_by).split(","))
        
        if all == 'true':
            serializer = PlantMachineryManpowerSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryManpowerSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryManpower
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryManpowerSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a PlantMachineryManpower details
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        manpower_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryManpower
                """
                if PlantMachineryManpower.cmobjects.filter(pk=manpower_id, organization_id=organization_id).exists():
                    details = PlantMachineryManpower.cmobjects.filter(pk=manpower_id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryManpowerSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryManpower
                """
                if PlantMachineryManpower.cmobjects.filter(pk=manpower_id, organization_id=organization_id).exists():
                    details = PlantMachineryManpower.cmobjects.filter(pk=manpower_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'data': PlantMachineryManpower.objects.filter(pk=manpower_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})   

class PlantMachineryManpowerImportAPIView(APIView):
    """
    API for importing PlantMachineryManpower data from an Excel file.
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'manpower_add': 0, 'manpower_edit': 0}
                organization_id = request.query_params.get('organization_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})

                if organization_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID not provided"})

                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("File not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})

                for column in field_map.values():
                    if column not in sheet_xlsx:
                        sheet_xlsx[column] = np.nan

                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)

                date_fields = [
                    'date_of_joining',
                    'date_of_birth',
                    'licence_issue_date',
                    'licence_validity'
                ]
                for field in date_fields:
                    if field in field_map:
                        sheet_xlsx[field_map[field]] = pd.to_datetime(sheet_xlsx[field_map[field]], errors='coerce')

                for index, row in sheet_xlsx.iterrows():
                    data = {
                        'organization_id': organization_id,
                        'current_location': row.get(field_map.get('current_location', None)),
                        'employee_id': row.get(field_map.get('employee_id')),
                        'name_of_employee': row.get(field_map.get('name_of_employee', None)),
                        'fathers_name': row.get(field_map.get('fathers_name', None)),
                        'department': row.get(field_map.get('department', None)),
                        'designation': row.get(field_map.get('designation', None)),
                        'category': row.get(field_map.get('category', None)),
                        'date_of_joining': row.get(field_map.get('date_of_joining', None)),
                        'date_of_birth': row.get(field_map.get('date_of_birth', None)),
                        'aadhar_no': row.get(field_map.get('aadhar_no', None)),
                        'pan_card_no': row.get(field_map.get('pan_card_no', None)),
                        'address': row.get(field_map.get('address', None)),
                        'licence_no': row.get(field_map.get('licence_no', None)),
                        'licence_issue_date': row.get(field_map.get('licence_issue_date', None)),
                        'licence_validity': row.get(field_map.get('licence_validity', None)),
                        'mobile_no': row.get(field_map.get('mobile_no', None)),
                        'remark': row.get(field_map.get('remark', None)),
                        'status': row.get(field_map.get('status', None)),
                    }

                    if not PlantMachineryManpower.cmobjects.filter(employee_id=row.get(field_map.get('employee_id'))).exists():
                        PlantMachineryManpower.objects.create(created_by_id=request.user.id, **data)
                        count_data['manpower_add'] += 1
                    else:
                        PlantMachineryManpower.cmobjects.filter(employee_id=row.get(field_map.get('employee_id'))).update(updated_by_id=request.user.id, **data)
                        count_data['manpower_edit'] += 1

                return Response(
                    {'results': {'Data': count_data},
                     'msg': 'Successfully processed',
                     'status': status.HTTP_201_CREATED,
                     'request_status': 1})

        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})                    


class PlantMachineryHsdDashboardAPIView(APIView):
    """
    API View to get aggregated HSD cost per hour/km month-wise by machine type
    within a specified date range.
    """
    
    

    def get(self, request):
        try:
            search = custom_filters(request, {}, [])
            start_date_str = request.query_params.get('log_book_date__gte', None)
            end_date_str = request.query_params.get('log_book_date__lte', None)

            if not start_date_str or not end_date_str:
                raise APIException({'request_status': 0, 'msg': "start_date and end_date parameters are required."})

            try:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})

            machine_types = [mt[0] for mt in PlantMachineryGroup.MACHINE_TYPE_CHOICES]
            machine_type_names = {mt: i for i, mt in enumerate(machine_types)}

            current_date = start_date.replace(day=1)
            end_date = end_date.replace(day=1)
            results = {}
            while current_date <= end_date:
                month_name = current_date.strftime('%b, %y')
                results[month_name] = {"name": month_name, "series": [
                    {"name": mt, "value": 0} for mt in machine_type_names.keys()
                ]}
                current_date += relativedelta(months=1)

            queryset = PlantMachineryLogBook.cmobjects.filter(
                plant_machinery_machine__plant_machinery_group__machine_type__in=machine_types,
                *search
            )

            monthly_data = queryset.annotate(
                month=TruncMonth('log_book_date'),
                machine_type=F('plant_machinery_machine__plant_machinery_group__machine_type')
            ).values('month', 'machine_type').annotate(
                total_fuel_filled=Sum('total_fuel_filled')
            ).order_by('month', 'machine_type')

            for entry in monthly_data:
                month_key = entry['month'].strftime('%b, %y')
                machine_type = entry['machine_type']
                total_fuel_filled = entry['total_fuel_filled'] or 0

                series_index = machine_type_names[machine_type]
                results[month_key]["series"][series_index]["value"] = total_fuel_filled

            final_results = list(results.values())

            return Response({
                'results': {'Data': final_results},
                'msg': 'HSD data',
                'request_status': 1
            })
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
    

class PlantMachineryEquipmentUtilizationDashboardAPIView(APIView):
    """
    API View to get consolidated equipment utilization percentage by PlantMachineryGroup name
    within a specified date range, along with machine type, plan value, and actual km run/hrs.
    """
    
    

    def get(self, request):
        try:
            search = custom_filters(request, {}, [])
            
            plant_machinery_groups = PlantMachineryGroup.cmobjects.all().exclude(machine_type='drilling')
            group_data = {group.id: {'name': group.name, 'type': group.machine_type} for group in plant_machinery_groups}
            
            results = {
                group['name']: {
                    'value': 0,        
                    'machine_type': group['type'],  
                    'plan_value': 0,         
                    'actual_value': 0       
                } 
                for group in group_data.values()
            }

            queryset = PlantMachineryLogBook.cmobjects.filter(
                plant_machinery_group__in=plant_machinery_groups,
                *search
            )

            consolidated_data = queryset.values('plant_machinery_group').annotate(
                total=Sum(
                    Case(
                        When(plant_machinery_group__machine_type='machine', then='total_working_hrs'),
                        When(plant_machinery_group__machine_type='vehicle', then='total_km_run'),
                        default=Value(0),
                        output_field=FloatField(),
                    )
                ),
                plan=Sum(
                    Case(
                        When(plant_machinery_group__machine_type='machine', then='plan_hrs'),
                        When(plant_machinery_group__machine_type='vehicle', then='plan_km'),
                        default=Value(0),
                        output_field=FloatField(),
                    )
                )
            )

            for entry in consolidated_data:
                total_value = entry['total'] or 0
                plan_value = entry['plan'] or 0
                utilization = (total_value / plan_value * 100) if plan_value > 0 else 0
                group_id = entry['plant_machinery_group']
                group_name = group_data[group_id]['name']
                
                results[group_name]['value'] = utilization
                results[group_name]['plan_value'] = plan_value
                results[group_name]['actual_value'] = total_value

            final_results = [
                {
                    "name": group_name, 
                    "value": data['value'], 
                    "machine_type": data['machine_type'], 
                    "plan_value": data['plan_value'], 
                    "actual_value": data['actual_value']
                } 
                for group_name, data in results.items()
            ]

            return Response({
                'results': {'Data': final_results},
                'msg': 'Equipment Utilization Data',
                'request_status': 1
            })

        except Exception as e:
            error_message = str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
class PlantMachineryEquipmentUtilizationDashboardV2APIView(APIView):
    '''
    API View to get consolidated equipment utilization percentage by PlantMachineryGroup name
    within a specified date range, along with machine type, plan value, and actual km run/hrs.
    '''
    
    

    def get(self, request):
        try:
            
            utilization_budget_filter = request.query_params.get('utilization_budget_filter', '{}')
            search = custom_filters(request, {}, ['utilization_budget_filter'])    
            _list = PlantMachineryGroup.cmobjects.exclude(machine_type='drilling').annotate(
                actual_value=Coalesce(
                    Subquery(
                        PlantMachineryLogBook.cmobjects.filter(
                            plant_machinery_group=OuterRef('pk'), *search
                        ).values('plant_machinery_group').annotate(
                            total=Sum(
                                Case(
                                    When(plant_machinery_group__machine_type='machine', then=F('total_working_hrs')),
                                    When(plant_machinery_group__machine_type='vehicle', then=F('total_km_run')),
                                    default=Value(0),
                                    output_field=FloatField(),
                                )
                            )
                        ).values('total')
                    ),
                    0.0,
                ),
                plan_value=Coalesce(
                    Subquery(
                        PlantMachineryLogBook.cmobjects.filter(
                            plant_machinery_group=OuterRef('pk'), *search
                        ).values('plant_machinery_group').annotate(
                            total=Sum(
                                Case(
                                    When(plant_machinery_group__machine_type='machine', then=F('plan_hrs')),
                                    When(plant_machinery_group__machine_type='vehicle', then=F('plan_km')),
                                    default=Value(0),
                                    output_field=FloatField(),
                                )
                            )
                        ).values('total')
                    ),
                    0.0,
                ),
                budget_value=Coalesce(
                    Subquery(
                        PlantMachineryUtilizationBudget.cmobjects.filter(
                            plant_machinery_group=OuterRef('pk'),*process_filters_response(json.loads(utilization_budget_filter))
                        ).values('plant_machinery_group').annotate(
                            total_budget=Sum('amount')
                        ).values('total_budget')
                    ),
                    0.0,
                ),
            ).annotate(
                value=Case(
                    When(plan_value__gt=0,
                         then=ExpressionWrapper(F('actual_value') * 100.0 / F('plan_value'), output_field=FloatField())),
                    default=Value(0.0),
                    output_field=FloatField(),
                )
            ).values(
                'name',
                'value',
                'machine_type',
                'plan_value',
                'actual_value',
                'budget_value',
            )

            return Response({
                'results': {'Data': list(_list)},
                'msg': 'Equipment Utilization Data',
                'request_status': 1
            })
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
class PlantMachineryProductionDashboardAPIView(APIView):
    """
    API View to get aggregated production quantity (cum and ton) month-wise
    by plant machinery group within a specified date range.
    """
    
    

    def get(self, request):
        try:
            
            projects__in = request.query_params.get('projects__in', None)
            search = custom_filters(request, {}, ['projects__in'])
            
            start_date_str = request.query_params.get('log_book_date__gte', None)
            end_date_str = request.query_params.get('log_book_date__lte', None)
            

            if not start_date_str or not end_date_str:
                raise APIException({'request_status': 0, 'msg': "log_book_date__gte and log_book_date__lte parameters are required."})

            try:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})

            all_month_keys = []
            current_date = start_date
            while current_date <= end_date:
                all_month_keys.append(current_date.strftime('%b, %y'))
                current_date += relativedelta(months=1)
            group_filter ={}
            if projects__in:
                group_filter['projects__in']=projects__in.split(',')    
            plant_machinery_groups = PlantMachineryGroup.cmobjects.filter(**group_filter)
            group_names = {group.id: group.name for group in plant_machinery_groups}
            ## as requested by Arindam sir and suman tamli####
            # group_planning_dict = dict(
            #     PlantMachineryMajorActivity.cmobjects
            #     .values('plant_machinery_group')
            #     .annotate(total_planning=Sum('project_planning'))
            #     .values_list('plant_machinery_group', 'total_planning')
            # )
            project_planning_qs = PlantMachineryMajorActivity.cmobjects.values(
                'plant_machinery_group'
            ).annotate(
                cum_qty=Coalesce(
                    Sum(
                        Case(
                            When(uom__symbol='Cum', then='project_planning'),
                            default=0,
                            output_field=FloatField()
                        ),
                        output_field=FloatField()
                    ),
                    0,
                    output_field=FloatField()
                ),
                mt_qty=Coalesce(
                    Sum(
                        Case(
                            When(uom__symbol='MT', then='project_planning'),
                            default=0,
                            output_field=FloatField()
                        ),
                        output_field=FloatField()
                    ),
                    0,
                    output_field=FloatField()
                )
            )
            group_planning_dict = {
                entry['plant_machinery_group']: {
                    'Cum': entry['cum_qty'],
                    'MT': entry['mt_qty']
                } for entry in project_planning_qs
            }

            ###########################
           
            results = {
                month: {
                    group_name: {
                        'total_production_qty_cum': 0,
                        'total_production_qty_ton': 0,
                        # 'project_planning_qty': group_planning_dict.get(group_id, 0)
                        'project_planning_qty_cum': group_planning_dict.get(group_id, {}).get('Cum', 0),
                        'project_planning_qty_mt': group_planning_dict.get(group_id, {}).get('MT', 0)
                    }
                    for group_id, group_name in group_names.items()
                }
                for month in all_month_keys
            }
            queryset = PlantMachineryLogBook.cmobjects.filter(
                plant_machinery_group__in=group_names.keys(),
                *search
            ).annotate(
                month=TruncMonth('log_book_date'),
                group_id=F('plant_machinery_group'),

            ).values('month', 'group_id').annotate(
                total_production_qty_cum=Sum('total_production_qty_cum'),
                total_production_qty_ton=Sum('total_production_qty_ton'),
            ).order_by('month', 'group_id')
            for entry in queryset:
                month_key = entry['month'].strftime('%b, %y')
                group_id = entry['group_id']
                total_production_qty_cum = entry['total_production_qty_cum'] or 0
                total_production_qty_ton = entry['total_production_qty_ton'] or 0
                group_name = group_names.get(group_id, '')
                if month_key in results:
                    if group_name in results[month_key]:
                        results[month_key][group_name]['total_production_qty_cum'] = total_production_qty_cum
                        results[month_key][group_name]['total_production_qty_ton'] = total_production_qty_ton

            return Response({
                'results': {'Data': results},
                'msg': 'Production data',
                'request_status': 1
            })

        except Exception as e:
            error_message = str(e)
            raise APIException({'request_status': 0, 'msg': error_message})



class PlantMachineryNotificationDashboardAPIView(APIView):
    """
    API View to get the count of documents expiring within specified time frames
    for each purpose (e.g., License, Fitness, Insurance, etc.).
    """
    
    

    def get(self, request):
        try:
            search = custom_filters(request, {}, ['expiry_thresholds'])
            expiry_thresholds = json.loads(request.query_params.get('expiry_thresholds', '{}'))
            current_date = datetime.now().date()

            result = {purpose: 0 for purpose in expiry_thresholds.keys()}
            queryset = PlantMachineryDocumentUpload.cmobjects.filter(
                exp_date__isnull=False,
                exp_date__gte=current_date,*search
            ).annotate(
                purpose_name=F('plant_machinery_document_upload_master__purpose')
            ).values('purpose_name').annotate(
                expiring_count=Count('id')
            ).filter(
                Q(exp_date__lte=current_date + timedelta(days=expiry_thresholds.get('license', 60))) | 
                Q(exp_date__lte=current_date + timedelta(days=expiry_thresholds.get('fitness', 60))) |
                Q(exp_date__lte=current_date + timedelta(days=expiry_thresholds.get('national_permit', 60))) |
                Q(exp_date__lte=current_date + timedelta(days=expiry_thresholds.get('pollution',30))) |
                Q(exp_date__lte=current_date + timedelta(days=expiry_thresholds.get('calibration_certificate',15)))
            )
            print(queryset)
            # 19-9-24<= 19-11-24 
            for entry in queryset:
                purpose = entry['purpose_name']
                count = entry['expiring_count']
                if purpose in result:
                    result[purpose] = count
            pending_log_entries_count = self.calculate_pending_log_entries(search, expiry_thresholds.get('pending_log_entry', 3))
            hsd_count = self.calculate_hsd_count(search)
            utilization_count = self.calculate_utilization_count(search, expiry_thresholds.get('utilization', 75))
            insurance_count = self.calculate_insurance_count(search, expiry_thresholds.get('insurance', 60))
            logbook_maintenance = self.calculate_logbook_maintenance(search, expiry_thresholds.get('logbook_maintenance', 100))


            result['pending_log_entries'] = pending_log_entries_count
            result['hsd'] = hsd_count
            result['utilization'] = utilization_count
            result['insurance'] = insurance_count

            result['maintenance'] = logbook_maintenance

            return Response({
                        'results': {'Data': result},
                        'msg': 'Notification data',
                        'request_status': 1
                    })

        except Exception as e:
            error_message = str(e)
            raise APIException({'request_status': 0, 'msg': error_message})

    def calculate_logbook_maintenance(self, search, _logbook_maintenance ):
        """
        calculate_logbook_maintenance
        """

        print("_logbook_maintenance: ", _logbook_maintenance)
        queryset = PlantMachineryLogBook.cmobjects.filter(*search).order_by(str('-id'))
        _lst = ["id", "organization_id", "log_book_date", "plant_machinery_machine_id", "plant_machinery_group_id",
                "working_hrs", "total_working_hrs", "total_km_run",
                "plant_machinery_machine__machine_number",
                "plant_machinery_machine__plant_machinery_group__name",
                "plant_machinery_machine__plant_machinery_group__machine_type"]
        logbook_list = queryset.values(*_lst)
        #################################
        if logbook_list:
            logbook_df = pd.DataFrame(logbook_list)
            logbook_df = logbook_df.fillna(np.nan).replace([np.nan], [None])
            logbook_df = logbook_df[logbook_df['plant_machinery_machine_id'].notna()]
            logbook_df = logbook_df[logbook_df['organization_id'].notna()]
        else:
            logbook_df = pd.DataFrame(columns=_lst)

        logbook_df = logbook_df.groupby(['plant_machinery_machine_id', 'organization_id']).agg({
            'id': 'first',
            'log_book_date': 'first',
            'plant_machinery_group_id': 'first',
            'working_hrs': 'sum',
            'total_working_hrs': 'sum',
            'total_km_run': 'sum',
            'plant_machinery_machine__machine_number': 'first',
            'plant_machinery_machine__plant_machinery_group__name': 'first',
            'plant_machinery_machine__plant_machinery_group__machine_type': 'first'
        }).reset_index()

        all_machine_ids = logbook_df['plant_machinery_machine_id'].unique()
        print("len all_machine_ids---> ", len(all_machine_ids))
        if len(all_machine_ids) > 1:
            queryset = PlantMachineryJobSheet.cmobjects.filter(
                plant_machinery_machine__id__in=all_machine_ids).order_by('-id')
        else:
            queryset = PlantMachineryJobSheet.cmobjects.all().order_by('-id')
        _lst2 = ["id", "organization_id", "jobsheet_number", "plant_machinery_machine_id", "pre_km_reading",
                 "pre_time_reading", ]

        jobsheet_list = queryset.values(*_lst2)
        if jobsheet_list:
            jobsheet_df = pd.DataFrame(jobsheet_list)
            jobsheet_df = jobsheet_df.fillna(np.nan).replace([np.nan], [None])
            jobsheet_df = jobsheet_df[jobsheet_df['plant_machinery_machine_id'].notna()]
            jobsheet_df = jobsheet_df[jobsheet_df['organization_id'].notna()]
            jobsheet_df = pd.DataFrame(jobsheet_df).drop_duplicates(subset=["plant_machinery_machine_id"], keep='last')
        else:
            jobsheet_df = pd.DataFrame(columns=_lst2)

        _left = jobsheet_df
        _right = logbook_df
        merged_df = pd.merge(_left, _right, left_on=['plant_machinery_machine_id', 'organization_id'],
                             right_on=['plant_machinery_machine_id', 'organization_id'], how='left')

        merged_df = merged_df.fillna(np.nan).replace([np.nan], [None])
        merged_df['total_km_run'].fillna(0., inplace=True)
        merged_df['pre_km_reading'].fillna(0., inplace=True)
        merged_df['pre_time_reading'].fillna(0., inplace=True)

        merged_df['total_working_hrs'].fillna(0., inplace=True)
        merged_df['pre_km_reading__d__total_km_run'] = merged_df['pre_km_reading'] - merged_df['total_km_run']
        merged_df['pre_time_reading__d__total_working_hrs'] = merged_df['pre_time_reading'] - merged_df[
            'total_working_hrs']

        #################################
        df_filtered_machine = merged_df.loc[lambda x: x['pre_km_reading__d__total_km_run'] <= float(_logbook_maintenance)]
        df_filtered_vehicle = merged_df.loc[lambda x: x['pre_time_reading__d__total_working_hrs'] <= float(_logbook_maintenance)]

        print('df_filtered_machine: ', len(df_filtered_machine.index))
        print('df_filtered_vehicle: ', len(df_filtered_vehicle.index))
        count = len(df_filtered_machine.index) + len(df_filtered_vehicle.index)
        ##################################

        return count

    def calculate_utilization_count(self, search, utilization_threshold):
        """
        Calculates the count of log books with utilization percent below the specified threshold.
        """
        queryset = PlantMachineryLogBook.cmobjects.filter(
            *search
        ).annotate(
            total=Sum(
                Case(
                    When(plant_machinery_group__machine_type='machine', then='total_working_hrs'),
                    When(plant_machinery_group__machine_type='vehicle', then='total_km_run'),
                    default=Value(0),
                    output_field=FloatField(),
                )
            ),
            plan=Sum(
                Case(
                    When(plant_machinery_group__machine_type='machine', then='plan_hrs'),
                    When(plant_machinery_group__machine_type='vehicle', then='plan_km'),
                    default=Value(0),
                    output_field=FloatField(),
                )
            ),
            utilization=ExpressionWrapper(
                Case(
                    When(plan__gt=0, then=F('total') * 100 / F('plan')),
                    default=Value(0),
                    output_field=FloatField(),
                ),
                output_field=FloatField()
            )
        ).filter(
            utilization__lt=utilization_threshold
        ).count()

        return queryset
    def calculate_hsd_count(self, search):
        """
        Calculates the count of HSD log books with negative deviation 
        (standard_norms - actual_norms < 0).
        """
        log_books = (
            PlantMachineryLogBook.cmobjects
            .filter(*search)
            .values('standard_norms', 'actual_norms')
        )

        # Calculate the count of entries where (standard_norms - actual_norms) < 0
        hsd_deviation_count = sum(
            1 for log_book in log_books 
            if (log_book['standard_norms'] - log_book['actual_norms']) < 0
        )

        return hsd_deviation_count
    def calculate_pending_log_entries(self, search, log_entry_threshold):
        """
        Calculates the number of pending log entries for all machines
        over the last specified number of days.
        """
        current_date = timezone.now().date()
        date_range = [current_date - timedelta(days=i) for i in range(log_entry_threshold)]
        machines = PlantMachineryMachine.cmobjects.filter(plant_machinery_group__check_pending_log=True,*search)
        machine_ids = machines.values_list('id', flat=True)

        existing_logs = (
            PlantMachineryLogBook.cmobjects
            .filter(
                plant_machinery_machine_id__in=machine_ids,
                log_book_date__in=date_range, 
                *search
            )
            .values('plant_machinery_machine_id', 'log_book_date')
            .distinct()
        )
        existing_log_entries = set(
            (log['plant_machinery_machine_id'], log['log_book_date']) for log in existing_logs
        )
        print(machine_ids)
        total_expected_entries = len(machine_ids) * len(date_range)
        actual_log_entries_count = len(existing_log_entries)
        pending_log_entries = total_expected_entries - actual_log_entries_count
        return pending_log_entries if pending_log_entries > 0 else 0

    def calculate_insurance_count(self, search, insurance_threshold):
        """
        Calculates the count of insurance records expiring within the specified threshold.
        """
        current_date = datetime.now().date()

        insurance_count = PlantMachineryInsuranceMaster.cmobjects.filter(
            insurance_expiry_date__isnull=False,
            insurance_expiry_date__gte=current_date,
            insurance_expiry_date__lte=current_date + timedelta(days=insurance_threshold),
            *search
        ).count()

        return insurance_count
class PlantMachineryPendingLogEntriesAPIView(APIView):
    def get(self, request, *args, **kwargs):
        try:
            current_date = timezone.now().date()
            search = custom_filters(request, {}, ['days'])
            days = int(request.query_params.get('days', 3))  
            date_range = [current_date - timedelta(days=i) for i in range(days)]

            machines = PlantMachineryMachine.cmobjects.filter(plant_machinery_group__check_pending_log=True,*search)
            machine_ids = machines.values_list('id', flat=True)
            
            existing_logs = (
                PlantMachineryLogBook.cmobjects
                .filter(
                    plant_machinery_machine_id__in=machine_ids,
                    log_book_date__in=date_range, 
                    *search
                )
                .values('plant_machinery_machine_id', 'log_book_date')
                .distinct()
            )
            existing_log_entries = set(
                (log['plant_machinery_machine_id'], log['log_book_date']) for log in existing_logs
            )
            total_expected_entries = len(machine_ids) * len(date_range)
            actual_log_entries_count = len(existing_log_entries)
            pending_log_entries_count = total_expected_entries - actual_log_entries_count
          
            pending_entries = []
            for machine in machines:
                machine_id = machine.id if machine else None
                equipment_description = machine.equipment_description if machine and machine.equipment_description else None
                machine_number = machine.machine_number if machine and machine.machine_number else None
                plant_machinery_group_id = machine.plant_machinery_group.id if machine and machine.plant_machinery_group else None
                plant_machinery_group_name = machine.plant_machinery_group.name if machine and machine.plant_machinery_group else None
                project = machine.project.id if machine and machine.project else None

                for date in date_range:
                    if (machine_id, date) not in existing_log_entries:
                        pending_entries.append({
                            'equipment_description': equipment_description,
                            'machine_number': machine_number,
                            'machine_id': machine_id,
                            'date': date,
                            'plant_machinery_group_id': plant_machinery_group_id,
                            'plant_machinery_group_name': plant_machinery_group_name,
                            'project': project
                        })
            
            response_data = {
                'pending_entries': pending_entries,
                'pending_log_entries_count': pending_log_entries_count if pending_log_entries_count > 0 else 0
            }
            
            return Response({
                            'results': {'Data': response_data},
                            'msg': 'Notification data',
                            'request_status': 1
                        })
        except Exception as e:
            error_message = str(e)
            raise APIException({'request_status': 0, 'msg': error_message})


# class PlantMachineryManPowerDashboardAPIView(APIView):
#     
#     

#     def get(self, request, *args, **kwargs):
#         try:
#             search = custom_filters(request, {}, [])

#             group_designation_mapping = {
#                 'BACKHOE LOADER': 'BACKHOE LOADER OPERATOR',
#                 'BATCHING PLANT': 'BATCHING PLANT OPERATOR',
#                 'CONCRETE PUMP': 'CONCRETE PUMP OPERATOR',
#                 'DIESEL TANKER': 'DRIVER DIESEL TANKER',
#                 'HYDRA': 'HYDRA OPERATOR/FARANA OPERATOR',
#                 'LMV': 'LIGHT MOTOR VEHICLE DRIVER',
#                 'MINI TANDEM ROLLER': 'ROLLER OPERATOR',
#                 'MOTOR GRADER': 'MOTOR GRADER OPERATOR',
#                 'SOIL COMPACTOR': 'ROLLER OPERATOR',
#                 'TIPPER': 'DRIVER TIPPER',
#                 'TRANSIT MIXER': 'DRIVER TRANSIT MIXER',
#                 'WEIGH BRIDGE': 'WEIGH BRIDGE OPERATOR',
#                 'WMM PLANT': 'WMM PLANT OPERATOR'
#             }
            
#             manpower_counts = (
#                 PlantMachineryManpower.cmobjects.filter(*search)
#                 .values('designation')
#                 .annotate(count=Count('id'))
#                 .order_by('designation')
#             )
            
#             manpower_counts_dict = {entry['designation']: entry['count'] for entry in manpower_counts}
            
#             machine_counts = (
#                 PlantMachineryMachine.cmobjects.filter(*search)
#                 .values('plant_machinery_group__name')
#                 .annotate(count=Count('id'))
#                 .order_by('plant_machinery_group__name')
#             )
            
#             machine_counts_dict = {entry['plant_machinery_group__name']: entry['count'] for entry in machine_counts}
            
#             ratio_data = []
#             for machine_group, designation in group_designation_mapping.items():
#                 machine_count = machine_counts_dict.get(machine_group, 0)
#                 manpower_count = manpower_counts_dict.get(designation, 0)
#                 ratio = (machine_count / manpower_count) if manpower_count > 0 else 0
#                 ratio_data.append({
#                     'name': machine_group,
#                     'designation': designation,
#                     'machine_count': machine_count,
#                     'manpower_count': manpower_count,
#                     'value': ratio
#                 })

#             # response_data = {
#             #     # 'manpower_counts': list(manpower_counts),
#             #     # 'machine_counts': list(machine_counts),
#             #     'ratios': ratio_data
#             # }
#             return Response({
#                     'results': {'Data': ratio_data},
#                     'msg': 'Production data',
#                     'request_status': 1
#                 })
#         except Exception as e:
#             error_message = str(e)
#             raise APIException({'request_status': 0, 'msg': error_message})
class PlantMachineryManPowerDashboardAPIView(APIView):
    
    

    def get(self, request, *args, **kwargs):
        try:
            search_machine = request.query_params.get('search_machine', '{}')
            search_manpower = request.query_params.get('search_manpower', '{}')
            machine_counts = (
                PlantMachineryGroup.cmobjects.filter(*process_filters_response(json.loads(search_machine)))
                .annotate(machine_count=Count('plant_machinery_group_plant_machinery_machine'))
                .values('name', 'designation', 'machine_count')
                
                
            )
            print(machine_counts.query)
            machine_counts_dict = {entry['name']: entry for entry in machine_counts}

            manpower_counts = (
                PlantMachineryManpower.cmobjects.filter(*process_filters_response(json.loads(search_manpower)))
                .values('designation')
                .annotate(count=Count('id'))
                .order_by('designation')
            )

            manpower_counts_dict = {entry['designation']: entry['count'] for entry in manpower_counts}

            ratio_data = []
            for group_name, group_data in machine_counts_dict.items():
                designation = group_data['designation']
                machine_count = group_data['machine_count']
                manpower_count = manpower_counts_dict.get(designation, 0)
                ratio = (manpower_count / machine_count) if machine_count > 0 else 0
                ratio_data.append({
                    'name': group_name,
                    'designation': designation,
                    'machine_count': machine_count,
                    'manpower_count': manpower_count,
                    'value': ratio
                })

            # response_data = {
            #     'manpower_counts': list(manpower_counts),
            #     'machine_counts': list(machine_counts),
            #     'ratios': ratio_data
            # }

            return Response({
                        'results': {'Data': ratio_data},
                        'msg': 'Manpower data',
                        'request_status': 1
                    }) 
        except Exception as e:
            error_message = str(e)
            raise APIException({'request_status': 0, 'msg': error_message}) 

class PlantMachineryManPowerDashboardV2APIView(APIView):
    
    

    def get(self, request, *args, **kwargs):
        try:
            search_machine = request.query_params.get('search_machine', '{}')
            search_manpower = request.query_params.get('search_manpower', '{}')

            manpower_sq = PlantMachineryManpower.cmobjects.filter(
                designation=OuterRef('designation'),
                *process_filters_response(json.loads(search_manpower))
            ).values('designation').order_by('designation').annotate(
                manpower_count=Count('id')
            ).values('manpower_count')

            _list = PlantMachineryGroup.cmobjects.filter(
                *process_filters_response(json.loads(search_machine))
            ).annotate(
                machine_count=Count(
                    'plant_machinery_group_plant_machinery_machine',
                    filter=Q(plant_machinery_group_plant_machinery_machine__is_deleted=False)
                ),
                manpower_count=Coalesce(Subquery(manpower_sq, output_field=FloatField()), 0.0),
            ).annotate(
                value=Case(
                    When(machine_count__gt=0,
                        then=ExpressionWrapper(
                            F('manpower_count') / F('machine_count'),
                            output_field=FloatField()
                        )),
                    default=Value(0.0),
                    output_field=FloatField()
                )
            ).values('name', 'designation', 'machine_count', 'manpower_count', 'value')

            return Response({
                'results': {'Data': list(_list)},
                'msg': 'Manpower data',
                'request_status': 1
            })

        except Exception as e:
            error_message = str(e)
            raise APIException({'request_status': 0, 'msg': error_message})        
class PlantMachineryActivityGroupAPIView(APIView):
    """
    CRUD API for Plant Machinery Activity Group model
    """
    
    

    def get(self, request):
        """
        Get a list of Plant Machinery Activity Groups
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            details = PlantMachineryActivityGroup.cmobjects.filter(id=id).first()
            serializer = PlantMachineryActivityGroupSerializer(details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryActivityGroup.cmobjects.select_related(
            'organization', 
        ).filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = PlantMachineryActivityGroupSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryActivityGroupSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Plant Machinery Activity Group
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryActivityGroupSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response({
                'results': {'Data': serializer.data},
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                'request_status': 1
            })
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Plant Machinery Activity Group
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        group_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                request.data['updated_by'] = request.user.id
                if PlantMachineryActivityGroup.cmobjects.filter(pk=group_id, organization_id=organization_id).exists():
                    group_details = PlantMachineryActivityGroup.cmobjects.filter(pk=group_id).first()
                    serializer = PlantMachineryActivityGroupSerializer(group_details, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({
                            'results': {'Data': serializer.data},
                            'msg': 'Successfully updated',
                            'status': status.HTTP_202_ACCEPTED,
                            'request_status': 1
                        })
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})

            elif method.lower() == 'delete':
                if PlantMachineryActivityGroup.cmobjects.filter(pk=group_id, organization_id=organization_id).exists():
                    group_details = PlantMachineryActivityGroup.cmobjects.filter(pk=group_id, organization_id=organization_id).first()
                    group_details.is_deleted = True
                    group_details.updated_by_id = request.user.id
                    group_details.save()
                    return Response({
                        'results': {'Data': PlantMachineryActivityGroup.objects.filter(pk=group_id, organization_id=organization_id).values()},
                        'msg': 'Successfully deleted',
                        'request_status': 1
                    })
                else:
                    raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})


class PlantMachineryLogBookDashboardAPIView(APIView):
    """

    """
    
    
    def get(self, request):
        order_by = request.query_params.get('order_by', '-id')

        _extras = ['jobsheet_service_type', 'pre_km_reading__d__total_km_run__gte', 'pre_km_reading__d__total_km_run__lte',
                   'pre_time_reading__d__total_working_hrs__gte', 'pre_time_reading__d__total_working_hrs__lte']
        search = custom_filters(request, {}, _extras)
        queryset = PlantMachineryLogBook.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        _lst = ["id", "organization_id", "project", "log_book_date", "plant_machinery_machine_id", "plant_machinery_group_id", "working_hrs", "total_working_hrs", "total_km_run",
                "plant_machinery_machine__machine_number",
                "plant_machinery_machine__plant_machinery_group__name",
                "plant_machinery_machine__plant_machinery_group__machine_type"]
        logbook_list = queryset.values(*_lst)
        #################################
        if logbook_list:
            logbook_df = pd.DataFrame(logbook_list)
            logbook_df = logbook_df.fillna(np.nan).replace([np.nan], [None])
            logbook_df = logbook_df[logbook_df['plant_machinery_machine_id'].notna()]
            logbook_df = logbook_df[logbook_df['organization_id'].notna()]
        else:
            logbook_df = pd.DataFrame(columns=_lst)

        logbook_df = logbook_df.groupby(['plant_machinery_machine_id', 'organization_id']).agg({
            'id': 'first',
            'log_book_date': 'first',
            'plant_machinery_group_id': 'first',
            'project': 'first',
            'working_hrs': 'sum',
            'total_working_hrs': 'sum',
            'total_km_run': 'sum',
            'plant_machinery_machine__machine_number': 'first',
            'plant_machinery_machine__plant_machinery_group__name': 'first',
            'plant_machinery_machine__plant_machinery_group__machine_type': 'first'
        }).reset_index()

        all_machine_ids = logbook_df['plant_machinery_machine_id'].unique()
        print("len all_machine_ids---> ", len(all_machine_ids))
        if len(all_machine_ids) > 1:
            queryset = PlantMachineryJobSheet.cmobjects.filter(plant_machinery_machine__id__in=all_machine_ids).order_by('jobsheet_date')
        else:
            queryset = PlantMachineryJobSheet.cmobjects.all().order_by('jobsheet_date')

        _lst2 = ["id", "organization_id", "project", "jobsheet_service_type", "jobsheet_number", "plant_machinery_machine_id", "pre_km_reading", "pre_time_reading",]

        jobsheet_list = queryset.values(*_lst2)
        if jobsheet_list:
            jobsheet_df = pd.DataFrame(jobsheet_list)
            jobsheet_df = jobsheet_df.fillna(np.nan).replace([np.nan], [None])
            jobsheet_df = jobsheet_df[jobsheet_df['plant_machinery_machine_id'].notna()]
            jobsheet_df = jobsheet_df[jobsheet_df['organization_id'].notna()]
            jobsheet_df = pd.DataFrame(jobsheet_df).drop_duplicates(subset=["plant_machinery_machine_id"], keep='last')
        else:
            jobsheet_df = pd.DataFrame(columns=_lst2)

        _left = jobsheet_df
        _right = logbook_df
        merged_df = pd.merge(_left, _right, left_on=['plant_machinery_machine_id', 'organization_id', 'project'], right_on=['plant_machinery_machine_id', 'organization_id', 'project'], how='left')

        merged_df = merged_df.fillna(np.nan).replace([np.nan], [None])
        merged_df['total_km_run'].fillna(0., inplace=True)
        merged_df['pre_km_reading'].fillna(0., inplace=True)
        merged_df['pre_time_reading'].fillna(0., inplace=True)

        merged_df['total_working_hrs'].fillna(0., inplace=True)
        merged_df['pre_km_reading__d__total_km_run'] = merged_df['pre_km_reading'] - merged_df['total_km_run']
        merged_df['pre_time_reading__d__total_working_hrs'] = merged_df['pre_time_reading'] - merged_df['total_working_hrs']

        #################################
        data0 = logbook_df.to_dict('records')
        data1 = jobsheet_df.to_dict('records')

        # data = merged_df.to_dict('records')
        custom_filter_keys = [
            ('pre_km_reading__d__total_km_run__gte', 'pre_km_reading__d__total_km_run', '>='),
            ('pre_km_reading__d__total_km_run__lte', 'pre_km_reading__d__total_km_run', '<='),
            ('pre_time_reading__d__total_working_hrs__gte', 'pre_time_reading__d__total_working_hrs', '>='),
            ('pre_time_reading__d__total_working_hrs__lte', 'pre_time_reading__d__total_working_hrs', '<='),
            ('jobsheet_service_type', 'jobsheet_service_type', '==')
        ]

        #############################################
        for param, key, operator in custom_filter_keys:
            if param in request.query_params.keys():
                custom_filter_val = float(request.query_params.get(param, 0)) if operator != '==' else request.query_params.get(param, 0)
                if operator == '>=':
                    merged_df = merged_df[merged_df[key] >= custom_filter_val]
                elif operator == '<=':
                    merged_df = merged_df[merged_df[key] <= custom_filter_val]
                elif operator == '==':
                    merged_df = merged_df[merged_df[key] == custom_filter_val]

        data = merged_df.to_dict('records')

        return Response({
            'results0': {'Data': data0}, # TODO: comment after testing
            'result1': {'Data1': data1}, # TODO: comment after testing

            'result': {'Data': data},
            'msg': 'PlantMachineryJobSheet//PlantMachineryLogBook data',
            'request_status': 1})



class PlantMachineryActivityItemsImportAPIView(APIView):
    """
    PlantMachineryActivityGroup and PlantMachineryActivityGroupItems
    """
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                organization_id = request.query_params.get('organization_id', None)
                project_id = request.query_params.get('project_id', None)

                if not organization_id or organization_id == "null":
                    return Response({'error': 'Organization Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if not project_id or project_id == "null":
                    return Response({'error': 'Project Id not provided'}, status=status.HTTP_400_BAD_REQUEST)
                if file_name is None:
                    return Response({'error': 'file_name is required'}, status=status.HTTP_400_BAD_REQUEST)
                if field_map is None:
                    return Response({'error': 'field_map is required'}, status=status.HTTP_400_BAD_REQUEST)
                path = 'media/excel/' + file_name

                if not os.path.exists(path):
                    raise APIException("file not found")

                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")

                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan

                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                # print('old head ', sheet_xlsx.columns.values)
                inverted_field_map = {v: k for k, v in field_map.items()}
                sheet_xlsx = sheet_xlsx.rename(inverted_field_map, axis='columns')
                valid_cols = [k for k in field_map.keys()]
                final_table_columns = [col for col in sheet_xlsx.columns if col in valid_cols]
                sheet_xlsx = sheet_xlsx.drop(columns=[col for col in sheet_xlsx if col not in final_table_columns])
                sheet_xlsx = sheet_xlsx.loc[:, ~sheet_xlsx.columns.duplicated()].copy()  # remove-duplicate-columns
                # print('new head ', sheet_xlsx.columns.values)

                count = sheet_xlsx.shape[0]

                # CREATE GROUP IF NOT EXISTS
                grp_code_lst = sheet_xlsx['plant_machinery_activity_group'].unique()
                # print('grp_code_lst', grp_code_lst)
                _grp_code_lst = list(PlantMachineryActivityGroup.cmobjects.filter(code__in=grp_code_lst).values_list('code', flat=True))
                # print('_grp_code_lst', _grp_code_lst)
                new_groups = list(set(grp_code_lst) - set(_grp_code_lst))
                # print('new_groups', list(new_groups))
                if new_groups:
                    musk = sheet_xlsx['plant_machinery_activity_group'].isin(new_groups)
                    rslt_df = sheet_xlsx[musk]
                    rslt_df.drop_duplicates(subset=['plant_machinery_activity_group',], keep='first', inplace=True)
                    print('rslt_df ', rslt_df['group__remark'])
                    grup_master = list()
                    for i, row in enumerate(rslt_df.to_dict('records')):
                        print('----CREATE GROUP IF NOT EXISTS ------',)
                        print(row)
                        grup_master.append(
                            PlantMachineryActivityGroup(
                                organization_id=organization_id,
                                project_id=project_id,
                                code=row['plant_machinery_activity_group'],
                                remark=row['group__remark'],
                            )
                        )
                    print(colorama.Back.BLUE, 'grup_master', grup_master, colorama.Style.RESET_ALL)
                    objs = PlantMachineryActivityGroup.cmobjects.bulk_create(grup_master, batch_size=1000, ignore_conflicts=False)



                # raise APIException('--------------')
                item_master = list()
                item_master_to_be_update = list()
                for i, row in enumerate(sheet_xlsx.to_dict('records')):

                    print('i-> ', i)
                    print('row-> ', row)
                    field_map_dic = {}
                    for field in row:
                        if not field.startswith('group__'):
                            print('field--> ', field, 'val: ', row[field])
                            if 'plant_machinery_activity_group' == field:
                                grp_obj = get_plantmachineryactivitygroup_by_code(row[field])
                                print('>>>group__remark', row.get('group__remark'))
                                if row.get('group__remark', None):
                                    grp_obj.remark = row.get('group__remark')
                                    grp_obj.save()
                                field_map_dic[field] = grp_obj
                            elif 'plant_machinery_machine' == field:
                                field_map_dic[field] = None
                            elif 'plant_machinery_group' == field:
                                field_map_dic[field] = get_plantmachinerygroup_by_name(row[field])
                            elif 'uom' == field:
                                field_map_dic[field] = get_uom_by_symbol(row[field])
                            elif field in ('efficiency_loss_monsoon', 'efficiency_normal_condn', 'working_hrs_per_month', 'productivity', 'fuel_norms', 'machine_rental'):
                                field_map_dic[field] = float(row[field] or 0.)
                            else:
                                field_map_dic[field] = row[field]


                    # if field_map_dic['plant_machinery_machine'].plant_machinery_group != field_map_dic['plant_machinery_group']:
                    #     raise APIException({'request_status': 0, 'msg': "Group not matching!"})

                    item_master.append(
                        PlantMachineryActivityGroupItems(
                            organization_id=organization_id,
                            created_by=request.user,
                            **field_map_dic
                        )
                    )

                created_data = []
                updated_data = []
                with transaction.atomic():
                    try:
                        # Bulk create
                        print('master',  item_master)
                        objs = PlantMachineryActivityGroupItems.cmobjects.bulk_create(item_master, batch_size=1000, ignore_conflicts=False)
                        created_data = PlantMachineryActivityGroupItemsSerializer2(objs, many=True).data

                        # Bulk update
                        #_fields = [i for i in field_map.keys() if i not in ('id', 'organization_id') and not i.startswith('group__')]
                        #PlantMachineryActivityGroupItems.cmobjects.bulk_update(item_master_to_be_update, _fields, batch_size=1000)
                        #updated_data = PlantMachineryActivityGroupItemsSerializer(master_to_be_update, many=True).data

                    except Exception as e:
                        print(colorama.Back.RED, 'ERROR ', e, colorama.Style.RESET_ALL)
                        raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict('records'),
                        'count_data': count,
                        'created_data': created_data,
                        'updated_data': updated_data
                    },
                        'msg': 'Successfully created/updated',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})

class PlantMachineryServiceScheduleNewAPIView(APIView):
    """
    CRUD API for ServiceScheduleNew model
    """
    
    

    def get(self, request):
        """
        Get a list of ServiceScheduleNew entries
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        
        if id:
            _details = PlantMachineryServiceScheduleNew.cmobjects.filter(id=id).first()
            if _details is None:
                return Response({'msg': 'Not Found', 'status': status.HTTP_404_NOT_FOUND, 'request_status': 0})
            serializer = PlantMachineryServiceScheduleNewSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryServiceScheduleNew.cmobjects.select_related(
            'organization', 'plant_machinery_machine', 'plant_machinery_group','vendor'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryServiceScheduleNewSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryServiceScheduleNewSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new ServiceScheduleNew entry
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryServiceScheduleNewSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a ServiceScheduleNew entry
        """
        method = request.query_params.get('method', None)
        id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a ServiceScheduleNew entry
                """
                request.data['updated_by'] = request.user.id
                if PlantMachineryServiceScheduleNew.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    instance = PlantMachineryServiceScheduleNew.cmobjects.filter(pk=id).first()
                    serializer = PlantMachineryServiceScheduleNewSerializer(instance, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            
            elif method.lower() == 'delete':
                """
                Delete a ServiceScheduleNew entry
                """
                if PlantMachineryServiceScheduleNew.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    instance = PlantMachineryServiceScheduleNew.cmobjects.filter(pk=id, organization_id=organization_id).first()
                    instance.is_deleted = True
                    instance.updated_by_id = request.user.id
                    instance.save()

                    return Response({'results': {'Data': PlantMachineryServiceScheduleNew.objects.filter(pk=id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryFuelTransactionAPIView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        resp = None
        if bool(int(str(os.getenv('MOBA_SYNC','0')))):
            try:
                urllib3.disable_warnings()
                url = str(os.getenv('MOBA_URL',''))
                end_date = date.today()
                start_date = end_date - timedelta(30)
                headers = {
                    'Accept': 'application/json',
                }
                data = {
                    'start_date': start_date.strftime('%Y-%m-%d'),
                    'end_date': end_date.strftime('%Y-%m-%d'),
                }
                print('-'*100)
                print('url --> ',url)
                print('data --> ',data)
                print('-'*100)
                response = requests.get(
                    url=url,
                    data=json.dumps(data),
                    headers=headers,
                    auth=HTTPBasicAuth(str(os.getenv('MOBA_USERNAME','')), str(os.getenv('MOBA_PASSWORD','')))
                )
                try:
                    resp = json.loads(response.content)
                    # Prepare the project mapping
                    project_list = pd.DataFrame(
                        ProjectMaster.cmobjects.annotate(
                            # project_code=Subquery(
                            #     ProjectData.cmobjects.filter(
                            #         project=OuterRef('pk'),
                            #         form__form_internal_name='project_id'
                            #     ).values('project').annotate(value=GroupConcat('value')).values('value')
                            # )
                        ).values()
                    )
                    plant_machinery_machine_list = pd.DataFrame(PlantMachineryMachine.cmobjects.values('id','machine_number'))
                    if resp['response_code'] == 200 and 'data' in resp:
                        for data in resp['data']:
                            organization_id = 1
                            project_id = None
                            plant_machinery_machine_id = None
                            site_name = data.get('site_name', None)
                            equipment_code = data.get('equipment_code', None)
                            project_row = project_list[project_list['project_code'] == site_name]
                            plant_machinery_machine_row = plant_machinery_machine_list[plant_machinery_machine_list['machine_number'] == equipment_code]
                            if not project_row.empty:
                                project_id = project_row.iloc[0]['id']
                                organization_id = project_row.iloc[0]['organization_id']
                            if not plant_machinery_machine_row.empty:
                                plant_machinery_machine_id = plant_machinery_machine_row.iloc[0]['id']
                            _obj, created = PlantMachineryFuelTransaction.objects.update_or_create(ref_id=data['id'], 
                                defaults={'data': data,
                                'organization_id': organization_id,
                                'project_id': project_id,
                                'plant_machinery_machine_id': plant_machinery_machine_id,
                            })
                except Exception as e:
                    print('ERROR', e)
                    print(response.content)
            except Exception as e:
                print('ERROR', e)
        return Response(resp)

class PlantMachineryFuelTransactionCummulativeAPIView(APIView):
    """
    API for fetching cumulative fuel transactions for plant machinery ( or moba hsd report cummulative).
    """
    
    

    def get(self, request):
        """
        Retrieve cumulative fuel data for a given date range.
        """
        all = request.query_params.get('all', None)
        date__gte = request.query_params.get('date__gte', None)
        date__lte = request.query_params.get('date__lte', None)
        order_by = request.query_params.get('order_by', 'data__equipment_code')
        search = custom_filters(request, {}, ['date__gte','date__lte'])
        transactions = PlantMachineryFuelTransaction.cmobjects.annotate(
            bench_mark_avg_float=Cast(F('data__bench_mark_avg'), FloatField()),
            cal_average_float=Cast(F('data__cal_average'), FloatField()),
            current_reading_float=Cast(F('data__current_reading'), FloatField()),
            previous_reading_float=Cast(F('data__previous_reading'), FloatField()),
            dispensed_fuel_float=Cast(F('data__dispensed_fuel'), FloatField())
        )

        data_list = transactions.filter(
            data__dispensed_date__gte=date__gte,
            data__dispensed_date__lte=date__lte
        ).values(
            'plant_machinery_machine_id',
            'plant_machinery_machine__equipment_description',
            'plant_machinery_machine__hsd_norms_uom__formal_name',
            'plant_machinery_machine__machine_number',
            'plant_machinery_machine__plant_machinery_group__machine_type'
        ).annotate(
            std_avg=Coalesce(Avg(F('bench_mark_avg_float')), Value(0), output_field=FloatField()),
            start_reading=Coalesce(Subquery(transactions.filter(
            plant_machinery_machine=OuterRef('plant_machinery_machine'),
            data__dispensed_date__gte=date__gte,
            data__dispensed_date__lte=date__lte
            ).order_by('data__dispensed_date')
            .values_list('previous_reading_float', flat=True)[:1]), Value(0), output_field=FloatField()),
            close_reading=Coalesce(Subquery(transactions.filter(
            plant_machinery_machine=OuterRef('plant_machinery_machine'),
            data__dispensed_date__gte=date__gte,
            data__dispensed_date__lte=date__lte
            ).order_by('-data__dispensed_date').values_list('current_reading_float', flat=True)[:1]), Value(0), output_field=FloatField()),
            total_hours_kms=Coalesce(F('close_reading') - F('start_reading'), Value(0), output_field=FloatField()),
            fuel_qty_issued=Coalesce(Sum(F('dispensed_fuel_float')), Value(0), output_field=FloatField()),
            actual_avg=Coalesce(
                Case(
                    When(plant_machinery_machine__plant_machinery_group__machine_type='machine', then=F('fuel_qty_issued')/F('total_hours_kms')),
                    When(plant_machinery_machine__plant_machinery_group__machine_type='vehicle', then=F('total_hours_kms')/F('fuel_qty_issued')),
                    default=Value(0),
                    output_field=FloatField(),
                ), Value(0), output_field=FloatField()),
            variation=Coalesce(
                Case(
                    When(plant_machinery_machine__plant_machinery_group__machine_type='machine', then=(((F('std_avg') - F('actual_avg')) / F('std_avg')) * 100)),
                    When(plant_machinery_machine__plant_machinery_group__machine_type='vehicle', then=(((F('actual_avg') - F('std_avg')) / F('std_avg')) * 100)),
                    default=Value(0),
                    output_field=FloatField(),
                ), Value(0), output_field=FloatField()),
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            return Response({'results': data_list})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(data_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': page.object_list,
            },
        })


class PlantMachineryNotificationsAPIView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request):
        try:
            count = {}
            response = {}
            data_add = []
            keep_ref_id_list = []
            today = date.today()
            _, num_days = calendar.monthrange(today.year, today.month)
            sections = {
                'HSD': {PlantMachineryReportsAPIView: {
                    'all': 'true',
                    'deviation__lt': '0',
                    'log_book_date__gte': date(today.year, today.month, 1).strftime('%Y-%m-%d'),
                    'log_book_date__lte': date(today.year, today.month, num_days).strftime('%Y-%m-%d'),
                    'order_by': 'plant_machinery_machine__plant_machinery_group__display_order_no,plant_machinery_machine__equipment_description',
                }},
                'Utilization': {PlantMachineryReportsAPIView: {
                    'all': 'true',
                    'utilization__lt': '75',
                    'log_book_date__gte': date(today.year, today.month, 1).strftime('%Y-%m-%d'),
                    'log_book_date__lte': date(today.year, today.month, num_days).strftime('%Y-%m-%d'),
                    'order_by': 'plant_machinery_machine__plant_machinery_group__display_order_no,plant_machinery_machine__equipment_description',
                }},
                'Maintenance1': {PlantMachineryLogBookDashboardAPIView: {
                    'plant_machinery_machine__plant_machinery_group__machine_type__iexact': 'machine',
                    'pre_time_reading__d__total_working_hrs__lte': '100',
                    'jobsheet_service_type': 'Service',
                }},
                'Maintenance2': {PlantMachineryLogBookDashboardAPIView: {
                    'plant_machinery_machine__plant_machinery_group__machine_type__iexact': 'vehicle',
                    'pre_km_reading__d__total_km_run__lte': '100',
                    'jobsheet_service_type': 'Service',
                }},
                'license': {PlantMachineryDocumentUploadMasterAPIView: {
                    'all': 'true',
                    # 'document_upload_master_plant_machinery_document_upload__exp_date__gt': today.strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__exp_date__lt':  (today+relativedelta(months=2)).strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__is_deleted': 'false',
                    'purpose': 'license',
                }},
                'fitness': {PlantMachineryDocumentUploadMasterAPIView: {
                    'all': 'true',
                    # 'document_upload_master_plant_machinery_document_upload__exp_date__gt': today.strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__exp_date__lt': (today+relativedelta(months=2)).strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__is_deleted': 'false',
                    'purpose': 'fitness',
                }},
                'Insurance': {PlantMachineryInsuranceMasterAPIView: {
                    'all': 'true',
                    # 'insurance_expiry_date__gt': today.strftime('%Y-%m-%d'),
                    'insurance_expiry_date__lt': (today+relativedelta(months=2)).strftime('%Y-%m-%d'),
                }},
                'national_permit': {PlantMachineryDocumentUploadMasterAPIView: {
                    'all': 'true',
                    # 'document_upload_master_plant_machinery_document_upload__exp_date__gt': today.strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__exp_date__lt': (today+relativedelta(months=2)).strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__is_deleted': 'false',
                    'purpose': 'national_permit',
                }},
                'pollution': {PlantMachineryDocumentUploadMasterAPIView: {
                    'all': 'true',
                    # 'document_upload_master_plant_machinery_document_upload__exp_date__gt': today.strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__exp_date__lt': (today+relativedelta(months=1)).strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__is_deleted': 'false',
                    'purpose': 'pollution',
                }},
                'calibration_certificate': {PlantMachineryDocumentUploadMasterAPIView: {
                    'all': 'true',
                    # 'document_upload_master_plant_machinery_document_upload__exp_date__gt': today.strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__exp_date__lt': (today+relativedelta(days=15)).strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__is_deleted': 'false',
                    'purpose': 'calibration_certificate',
                }},
                'work_order': {PlantMachineryDocumentUploadMasterAPIView: {
                    'all': 'true',
                    # 'document_upload_master_plant_machinery_document_upload__exp_date__gt': today.strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__exp_date__lt': (today+relativedelta(days=15)).strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__is_deleted': 'false',
                    'purpose': 'work_order',
                }},
                'tax_documents': {PlantMachineryDocumentUploadMasterAPIView: {
                    'all': 'true',
                    # 'document_upload_master_plant_machinery_document_upload__exp_date__gt': today.strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__exp_date__lt': (today+relativedelta(days=15)).strftime('%Y-%m-%d'),
                    'document_upload_master_plant_machinery_document_upload__is_deleted': 'false',
                    'purpose': 'tax_documents',
                }},
                'Pending Log entries': {PlantMachineryPendingLogEntriesAPIView: {
                    'days': '3',
                }},
            }
            if not request.GET._mutable:
                request.GET._mutable = True
            request.GET['organization_id'] = 1
            for section_key,section_value in sections.items():
                for model,filters in section_value.items():
                    for filter_key,filter_value in filters.items():
                        request.GET[filter_key] = filter_value
                    resp = model().get(request)
                    print(resp.data)
                    temp_resp = resp.data
                    if model == PlantMachineryReportsAPIView:
                        if 'results' in resp.data:
                            temp_resp = resp.data['results']
                    if model == PlantMachineryLogBookCumulative2APIView:
                        if 'results' in resp.data:
                            temp_resp = resp.data['results']
                    if model == PlantMachineryLogBookAPIView:
                        if 'results' in resp.data:
                            temp_resp = resp.data['results']
                    if model == PlantMachineryLogBookDashboardAPIView:
                        if 'result' in resp.data and 'Data' in resp.data['result']:
                            temp_resp = resp.data['result']['Data']
                    if model == PlantMachineryDocumentUploadMasterAPIView:
                        if 'results' in resp.data:
                            temp_resp = resp.data['results']
                    if model == PlantMachineryInsuranceMasterAPIView:
                        if 'results' in resp.data:
                            temp_resp = resp.data['results']
                    if model == PlantMachineryPendingLogEntriesAPIView:
                        if 'results' in resp.data and 'Data' in resp.data['results'] and 'pending_entries' in resp.data['results']['Data']:
                            temp_resp = resp.data['results']['Data']['pending_entries']
                    response[section_key] = temp_resp
                    for filter_key in filters.keys():
                        del request.GET[filter_key]
            existing_key_list = PlantMachineryNotifications.cmobjects.annotate(value=GroupConcat(Concat('ref_type',Value('__'),'ref_id',output_field=CharField()), distinct=True)).values_list('value', flat=True)
            for section_key,section_value in response.items():
                count[section_key] = 0
                for value in section_value:
                    ref_id = value['id'] if 'id' in value else ''
                    if section_key in ['HSD','Utilization']:
                        ref_id = value['plant_machinery_machine__id'] if 'plant_machinery_machine__id' in value else ''
                    if section_key == 'Pending Log entries':
                        ref_id = f"machine_id:{value['machine_id']},date:{value['date']}"
                    if section_key in ['Maintenance1','Maintenance2']:
                        ref_id = f"id_x:{value['id_x']},id_y:{value['id_y']}"
                    if str(section_key)+'__'+str(ref_id) in existing_key_list:
                        keep_ref_id_list.append(str(section_key)+'__'+str(ref_id))
                    else:
                        data = {
                            'ref_type': section_key,
                            'ref_id': ref_id,
                            'data': json.loads(json.dumps(value, sort_keys=True, indent=1, cls=DjangoJSONEncoder)),
                        }
                        data_add.append(PlantMachineryNotifications(**data))
                        count[section_key] += 1
            PlantMachineryNotifications.objects.annotate(reference=Concat('ref_type',Value('__'),'ref_id',output_field=CharField())).exclude(reference__in=keep_ref_id_list).delete()
            PlantMachineryNotifications.objects.bulk_create(data_add, batch_size=1000, ignore_conflicts=False)
            return Response(count)
        except Exception as e:
            print('ERROR', e)
            return Response(e)


class PlantMachineryNotificationsListAPIView(APIView):
    
    

    def get(self, request):
        counts = request.query_params.get('counts', None)
        pending_counts = request.query_params.get('pending_counts', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        search = {}
        search = custom_filters(request, search, ['counts','pending_counts'])

        list_data = PlantMachineryNotifications.cmobjects.annotate(
            seen = Exists(PlantMachineryNotifications.seen_by.through.objects.filter(
                plantmachinerynotifications_id=OuterRef('pk'),
                pmsuser_id=request.user.pk
            ))
        ).filter(*search).order_by(*str(order_by).split(","))

        if counts == 'true':
            count_data = list_data.values('ref_type').annotate(
                total_count=Count('ref_type'),
                total_seen=Sum(Case(
                    When(seen=True, then=1),
                    default=0,
                    output_field=IntegerField(),
                ))
            ).order_by('ref_type')
            return Response(count_data)

        if pending_counts == 'true':
            count_data = list_data.filter(ref_type='Pending Log entries').values('data__plant_machinery_group_name').annotate(
                total_count=Count('data__plant_machinery_group_name'),
                total_seen=Sum(Case(
                    When(seen=True, then=1),
                    default=0,
                    output_field=IntegerField(),
                ))
            ).order_by('data__plant_machinery_group_name')
            return Response(count_data)

        if all == 'true':
            serializer = PlantMachineryNotificationsSerializer(list_data, many=True)

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryNotificationsSerializer(page, many=True)

        for id in [value['id'] for value in serializer.data]:
            PlantMachineryNotifications.objects.filter(pk=id).first().seen_by.add(request.user)

        if all == 'true':
            return Response({'results': serializer.data})
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


class PlantMachineryMISAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryMIS.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryMISSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryMISSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryMISSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryMIS.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = PlantMachineryMIS.cmobjects.filter(pk=id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryMISSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryMIS.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = PlantMachineryMIS.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryReportsAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        search = {}
        search = custom_filters(request, search, [])

        list_data = PlantMachineryLogBook.cmobjects.values(
            # 'start_log_book_date',
            # 'end_log_book_date',
            'plant_machinery_machine__id',
            'plant_machinery_machine__machine_number',
            'plant_machinery_machine__equipment_description',
            'plant_machinery_machine__registration_no',
            'plant_machinery_machine__machine_info_standard_norms_ltr_km',
            'plant_machinery_machine__hsd_norms_uom__symbol',
            'plant_machinery_machine__plant_machinery_group__machine_type',
            'project',
            # 'start_reading',
            # 'close_reading',
            # 'avg_standard_norms',
            # 'sum_total_fuel_filled',
            # 'sum_total_production_qty_cum',
            # 'sum_total_production_qty_ton',
            # 'sum_number_of_trips',
            # 'sum_plan',
            # 'total_reading',
            # 'actual_avg_standard_norms',
            # 'utilization_percent',
            # 'productivity',
        ).annotate(
            start_log_book_date=Min('log_book_date'),
            end_log_book_date=Max('log_book_date'),
            start_reading=Min(Case(
                When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=F('start_hrs')),
                default=F('start_kms'),
                output_field=FloatField()
            )),
            close_reading=Max(Case(
                When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=F('close_hrs')),
                default=F('close_kms'),
                output_field=FloatField()
            )),
            avg_standard_norms=Coalesce(Avg('standard_norms', output_field=models.FloatField()), Value(0), output_field=FloatField()),
            sum_total_fuel_filled=Coalesce(Sum('total_fuel_filled', output_field=models.FloatField()), Value(0), output_field=FloatField()),
            sum_total_production_qty_cum=Coalesce(Sum((F('total_production_qty_ton')*1.133)+F('total_production_qty_cum'), output_field=models.FloatField()), Value(0), output_field=FloatField()),
            sum_number_of_trips=Coalesce(Sum('number_of_trips', output_field=models.FloatField()), Value(0), output_field=FloatField()),
            sum_plan=Coalesce(Sum(Case(
                When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=F('plan_hrs')),
                default=F('plan_km'),
                output_field=FloatField()
            )), Value(0), output_field=FloatField()),
            total_reading=ExpressionWrapper(F('close_reading')-F('start_reading'), output_field=models.FloatField()),
            avg_actual_norms=Case(
                When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=Case(
                    When(total_reading=0, then=Value(0)),
                    default=(F('sum_total_fuel_filled')/F('total_reading')),
                    output_field=FloatField()
                )),
                default=Case(
                    When(sum_total_fuel_filled=0, then=Value(0)),
                    default=(F('total_reading')/F('sum_total_fuel_filled')),
                    output_field=FloatField()
                ),
                output_field=FloatField()
            ),
            deviation=ExpressionWrapper((F('plant_machinery_machine__machine_info_standard_norms_ltr_km')-F('avg_actual_norms')), output_field=models.FloatField()),
            utilization=ExpressionWrapper(((F('total_reading')/F('sum_plan'))*100), output_field=models.FloatField()),
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            return Response({'results': list_data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': page.object_list,
        })


class PlantMachinerySummeryAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)

        search = {}
        search = custom_filters(request, search, [])

        list_data = PlantMachineryMachine.cmobjects.values('id',
            'equipment_description',
            'plant_machinery_group__name',
            'plant_machinery_group__asset_type'
        ).annotate(
            sum_hired=Sum(Case(
                When(owner_type="hired", then=1),
                default=0,
                output_field=IntegerField()
            )),
            sum_owned=Sum(Case(
                When(owner_type="owned", then=1),
                default=0,
                output_field=IntegerField()
            )),
        ).filter(*search)

        if all == 'true':
            return Response({'results': list_data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': page.object_list,
        })


class PlantMachineryHireBillAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryHireBill.cmobjects.filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryHireBillSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryHireBillSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryHireBillSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryHireBill.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = PlantMachineryHireBill.cmobjects.filter(pk=id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryHireBillSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryHireBill.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = PlantMachineryHireBill.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryStatusUpdateAPIView(APIView):
    
    

    def put(self, request):
        organization_id = request.query_params.get('organization_id', None)
        machine_id = request.query_params.get('id', None)  
        is_active = request.data.get('is_active', None) 
       
        try:
            with transaction.atomic():
                machine = PlantMachineryMachine.cmobjects.filter(
                    pk=machine_id, 
                    organization_id=organization_id
                ).first()

                if not machine:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

                machine.is_active = is_active
                machine.updated_by = request.user  
                machine.save()

                return Response({
                    'results': {
                        'data':  {
                            'id': machine.id,
                            'is_active': machine.is_active,
                        },
                    },
                    'msg': "Successfully updated",
                    'status': status.HTTP_202_ACCEPTED,
                    "request_status": 1
                })
                    
        except Exception as e:
                 raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryBatteryAPIView(APIView):
    """
    CRUD API for model: PlantMachineryBattery
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryBattery
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = PlantMachineryBattery.cmobjects.filter(id=id).first()
            serializer = PlantMachineryBatterySerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryBattery.cmobjects.select_related(
            'organization',
            'project',
            'plant_machinery_group',
            'plant_machinery_machine',
            'brand',
            'model',
            'vendor'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryBatterySerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryBatterySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryBattery
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryBatterySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryBattery
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        battery_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryBattery.cmobjects.filter(pk=battery_id, organization_id=organization_id).exists():
                    details = PlantMachineryBattery.cmobjects.filter(pk=battery_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryBatterySerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryBattery.cmobjects.filter(pk=battery_id, organization_id=organization_id).exists():
                    details = PlantMachineryBattery.cmobjects.get(pk=battery_id, organization_id=organization_id)
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'data': {}},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryComplianceMasterAPIView(APIView):
    """
    CRUD API for PlantMachineryComplianceMaster
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryComplianceMaster
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = PlantMachineryComplianceMaster.cmobjects.filter(id=id).first()
            serializer = PlantMachineryComplianceMasterSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryComplianceMaster.cmobjects.select_related(
            'organization', 
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryComplianceMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryComplianceMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryComplianceMaster
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryComplianceMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryComplianceMaster
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        compliance_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryComplianceMaster.cmobjects.filter(pk=compliance_id, organization_id=organization_id).exists():
                    details = PlantMachineryComplianceMaster.objects.filter(pk=compliance_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryComplianceMasterSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryComplianceMaster.cmobjects.filter(pk=compliance_id, organization_id=organization_id).exists():
                    details = PlantMachineryComplianceMaster.objects.get(pk=compliance_id, organization_id=organization_id)
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'data': {}},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
class PlantMachineryComplianceMasterNewAPIView(APIView):
    """
    CRUD API for PlantMachineryComplianceMasterNew
    """
    
    

    def get(self, request):
        id = request.query_params.get("id", None)
        all = request.query_params.get("all", None)
        order_by = request.query_params.get("order_by", "-id")

        if id:
            details = PlantMachineryComplianceMasterNew.cmobjects.filter(id=id).first()
            serializer = PlantMachineryComplianceMasterNewSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryComplianceMasterNew.cmobjects.select_related(
            "organization", "project", "site", "plant_machinery_group"
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == "true":
            serializer = PlantMachineryComplianceMasterNewSerializer(_list, many=True)
            return Response({"results": serializer.data})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get("page", 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryComplianceMasterNewSerializer(page, many=True)

        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": serializer.data,
        })

    def post(self, request):
        request.data["created_by"] = request.user.id
        serializer = PlantMachineryComplianceMasterNewSerializer(data=request.data, context={"request": request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {"results": {"Data": serializer.data},
                 "msg": "Successfully created.",
                 "status": status.HTTP_201_CREATED,
                 "request_status": 1}
            )
        raise APIException({"request_status": 0, "msg": serializer.errors})

    def put(self, request):
        method = request.query_params.get("method","").lower()
        id = request.query_params.get("id", None)
        with transaction.atomic():
            details = PlantMachineryComplianceMasterNew.cmobjects.filter(pk=id).first()
            if not details:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})

            if method == "edit":
                request.data["updated_by"] = request.user.id
                serializer = PlantMachineryComplianceMasterNewSerializer(
                    details, data=request.data, partial=True, context={"request": request}
                )
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})
                    return Response({
                        "results": serializer.data,
                        "msg": "Successfully updated.",
                        "status": status.HTTP_202_ACCEPTED,
                        "request_status": 1
                    }
                    )
                raise APIException({"request_status": 0, "msg": serializer.errors})

            elif method == "delete":
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()
                return Response({
                    "results": {"Data": PlantMachineryComplianceMasterNew.objects.filter(pk=id).values()},
                    "msg": "Successfully deleted.",
                    "request_status": 1
                })

            else:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})
class PlantMachineryComplianceReportAPIView(APIView):
    """
    CRUD API for model: PlantMachineryComplianceReport
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryComplianceReport
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = PlantMachineryComplianceReport.cmobjects.filter(id=id).first()
            serializer = PlantMachineryComplianceReportSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryComplianceReport.cmobjects.select_related(
            'organization',
            'project',
            'plant_machinery_machine',
            'compliance_master',
        ).prefetch_related('compilance_report_plant_machinery_compliance_report_item').filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryComplianceReportSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryComplianceReportSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryComplianceReport
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryComplianceReportSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryComplianceReport
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        compliance_report_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryComplianceReport.cmobjects.filter(pk=compliance_report_id, organization_id=organization_id).exists():
                    details = PlantMachineryComplianceReport.objects.filter(pk=compliance_report_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryComplianceReportSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryComplianceReport.cmobjects.filter(pk=compliance_report_id, organization_id=organization_id).exists():
                    details = PlantMachineryComplianceReport.objects.filter(pk=compliance_report_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'data': {}},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class PlantMachineryCallibrationReportAPIView(APIView):
    """
    CRUD API for model: PlantMachineryCallibration
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryCallibration
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = PlantMachineryCallibrationReport.cmobjects.filter(id=id).first()
            serializer = PlantMachineryCallibrationReportSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(request, search, [])

        _list = PlantMachineryCallibrationReport.cmobjects.select_related(
            'organization',
            'project',
            'plant_machinery_machine',
            'vendor'
        ).filter(*search).order_by(*str(order_by).split(","))
        print("test",_list)
        if all == 'true':
            serializer = PlantMachineryCallibrationReportSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryCallibrationReportSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryCallibration
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryCallibrationReportSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryCallibration
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        callibration_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryCallibrationReport.cmobjects.filter(pk=callibration_id, organization_id=organization_id).exists():
                    details = PlantMachineryCallibrationReport.objects.filter(pk=callibration_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryCallibrationReportSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryCallibrationReport.cmobjects.filter(pk=callibration_id, organization_id=organization_id).exists():
                    details = PlantMachineryCallibrationReport.objects.filter(pk=callibration_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'data': {}},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})



class PlantMachineryLogBookCumulativeAPIView(APIView):
    """
    API to fetch cumulative or starting values based on machine .
    """
    
    

    def get(self, request):
        fields = request.query_params.get('fields', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        search = {}
        _exclude = ['fields']

        search = custom_filters(request, search, _exclude)

        if fields:
            try:
                fields = json.loads(fields)
            except json.JSONDecodeError:
                return Response(
                    {"msg": "Invalid JSON format for fields.", "request_status": 0},
                    status=status.HTTP_400_BAD_REQUEST,
                )


        logbook_qs = (
            PlantMachineryLogBook.cmobjects.select_related(
                "organization",
                "plant_machinery_machine",
                "plant_machinery_group",
                "driver_operator",
                "location",
                "site",
                "project",
            ).annotate(
                total=Sum(
                    Case(
                        When(plant_machinery_group__machine_type='machine', then='total_working_hrs'),
                        When(plant_machinery_group__machine_type='vehicle', then='total_km_run'),
                        default=Value(0),
                        output_field=FloatField(),
                    )
                ),
                plan=Sum(
                    Case(
                        When(plant_machinery_group__machine_type='machine', then='plan_hrs'),
                        When(plant_machinery_group__machine_type='vehicle', then='plan_km'),
                        default=Value(0),
                        output_field=FloatField(),
                    )
                ),
                utilization=ExpressionWrapper(
                    Case(
                        When(plan__gt=0, then=F('total') * 100 / F('plan')),
                        default=Value(0),
                        output_field=FloatField(),
                    ),
                    output_field=FloatField()
                )
            ).filter(*search)
        )

        # Fetch aggregates for all machines

        aggregation_fields = {
            field: (
                Sum(field) if operation == "aggregate" else
                Avg(field) if operation == "average" else None
            )
            for field, operation in fields.items()
            if operation in ["aggregate", "average"]
        }
        aggregates = logbook_qs.values("plant_machinery_machine_id").annotate(**aggregation_fields)

        # machine_data_map = {
        #     logbook.plant_machinery_machine_id: {
        #         "plant_machinery_machine__id": logbook.plant_machinery_machine.id,
        #         "plant_machinery_machine__machine_number": logbook.plant_machinery_machine.machine_number,
        #         "plant_machinery_machine__equipment_description": logbook.plant_machinery_machine.equipment_description,
        #         "plant_machinery_machine__registration_number": logbook.plant_machinery_machine.registration_no,
        #     }
        #     for logbook in logbook_qs.filter(
        #         plant_machinery_machine_id__in=[agg["plant_machinery_machine_id"] for agg in aggregates]
        #     )
        # }
        machine_data_map = {
            logbook.plant_machinery_machine_id: {
                "plant_machinery_machine__id": (
                    logbook.plant_machinery_machine.id if logbook.plant_machinery_machine else None
                ),
                "plant_machinery_machine__machine_number": (
                    logbook.plant_machinery_machine.machine_number if logbook.plant_machinery_machine else None
                ),
                "plant_machinery_machine__equipment_description": (
                    logbook.plant_machinery_machine.equipment_description if logbook.plant_machinery_machine else None
                ),
                "plant_machinery_machine__registration_number": (
                    logbook.plant_machinery_machine.registration_no if logbook.plant_machinery_machine else None
                ),
                "plant_machinery_machine__plant_machinery_group__machine_type": (
                    logbook.plant_machinery_machine.plant_machinery_group.machine_type if logbook.plant_machinery_machine.plant_machinery_group else None
                ),
                "project": (
                    logbook.project.id if logbook.project else None
                ),
            }
            for logbook in logbook_qs.filter(
                plant_machinery_machine_id__in=[agg["plant_machinery_machine_id"] for agg in aggregates]
            )
        }
        result = []
        for agg in aggregates:
            # print(aggregates)
            machine_id = agg["plant_machinery_machine_id"]
            machine_data = machine_data_map.get(machine_id, {})
            
            for field, operation in fields.items():
                if operation == "aggregate":
                    machine_data[field] = agg.get(field, 0.0)
                elif operation == "average":
                    machine_data[field] = agg.get(field, 0.0)     
                elif operation == "first_value":
                    first_value = logbook_qs.filter(
                        plant_machinery_machine_id=machine_id
                    ).values_list(field, flat=True).first()
                    machine_data[field] = first_value if first_value is not None else 0.0
                elif operation == "last_value":
                    last_value = logbook_qs.filter(
                        plant_machinery_machine_id=machine_id
                    ).values_list(field, flat=True).last()
                    machine_data[field] = last_value if last_value is not None else 0.0
                else:
                    machine_data[field] = 0.0

            result.append(machine_data)

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(result, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)

        return Response(
            {
                "count": paginator.count,
                "next": page.next_page_number() if page.has_next() else None,
                "previous": page.previous_page_number() if page.has_previous() else None,
                "results": list(page),
            }
        )
    
class PlantMachineryLogBookCumulative2RawAPIView(APIView):
    
    
    ORDER_BY_MAP = {
        "plant_machinery_machine__id": "pm.id",
        "plant_machinery_machine__machine_number": "pm.machine_number",
        "plant_machinery_machine__equipment_description": "pm.equipment_description",
        "plant_machinery_machine__registration_no": "pm.registration_no",
        "plant_machinery_group__machine_type": "pmg.machine_type",
        "project": "pl.project_id",
        "log_book_date": "pl.log_book_date",
    }
    def get(self, request):
        fields = request.query_params.get('fields', None)
        all_flag = request.query_params.get('all', None)
        order_by_param = request.query_params.get('order_by', 'plant_machinery_machine__id')
        if not fields:
            raise APIException({'request_status': 0, 'msg': "Require fields."})
        try:
            fields = json.loads(fields)
        except json.JSONDecodeError:
            raise APIException({'request_status': 0, 'msg': "Invalid JSON format for fields."})
        order_by = self.ORDER_BY_MAP.get(order_by_param, "pm.id")
        select_parts = [
            "pm.id AS machine_id",
            "pm.machine_number AS plant_machinery_machine__machine_number",
            "pm.equipment_description AS plant_machinery_machine__equipment_description",
            "pm.registration_no AS plant_machinery_machine__registration_no",
            "pmg.machine_type AS plant_machinery_machine__plant_machinery_group__machine_type",
            "pl.project_id AS project"
        ]
        for field, operation in fields.items():
            if operation == 'aggregate':
                select_parts.append(f"COALESCE(SUM(pl.{field}), 0) AS {field}")
            elif operation == 'average':
                select_parts.append(f"COALESCE(AVG(pl.{field}), 0) AS {field}")
            elif operation == 'first_value':
                select_parts.append(
                    f"FIRST_VALUE(pl.{field}) OVER (PARTITION BY pm.id ORDER BY pl.log_book_date ASC) AS {field}"
                )
            elif operation == 'last_value':
                select_parts.append(
                    f"LAST_VALUE(pl.{field}) OVER (PARTITION BY pm.id ORDER BY pl.log_book_date ASC "
                    f"ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS {field}"
                )
        select_clause = ", ".join(select_parts)
        sql = f"""
            SELECT {select_clause}
            FROM plant_machinery_plant_machinery_log_book pl
            JOIN plant_machinery_machine pm 
                ON pl.plant_machinery_machine_id = pm.id
            LEFT JOIN plant_machinery_plant_machinery_group pmg 
                ON pm.plant_machinery_group_id = pmg.id
            WHERE (%s IS NULL OR pl.project_id = %s)
              AND (%s IS NULL OR pl.log_book_date >= %s)
              AND (%s IS NULL OR pl.log_book_date <= %s)
            GROUP BY pm.id, pm.machine_number, pm.equipment_description,
                     pm.registration_no, pmg.machine_type, pl.project_id
            ORDER BY {order_by}
        """
        params = [
            request.query_params.get("project"),
            request.query_params.get("project"),
            request.query_params.get("log_book_date__gte"),
            request.query_params.get("log_book_date__gte"),
            request.query_params.get("log_book_date__lte"),
            request.query_params.get("log_book_date__lte"),
        ]
        with connection.cursor() as cursor:
            cursor.execute(sql, params)
            columns = [col[0] for col in cursor.description]
            rows = cursor.fetchall()
            result = [dict(zip(columns, row)) for row in rows]
        if all_flag == 'true':
            return Response({'results': result})
        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(result, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)
        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": list(page),
        })
    
class PlantMachineryLogBookCumulative2APIView(APIView):
    def get(self, request):
        fields = request.query_params.get('fields', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if not fields:
            raise APIException({'request_status': 0, 'msg': "Require fields."})
        try:
            fields = json.loads(fields)
        except json.JSONDecodeError:
            raise APIException({'request_status': 0, 'msg': "Invalid JSON format for fields."})
        window_annotations = {}
        aggregation_fields = {}
        window_keys = []
        window_field_map = {}
        for field, operation in fields.items():
            if operation == 'aggregate':
                aggregation_fields[field] = Coalesce(Sum(field), Value(0), output_field=FloatField())
            elif operation == 'average':
                aggregation_fields[field] = Coalesce(Avg(field), Value(0), output_field=FloatField())
            elif operation == 'first_value':
                key = f"{field}_first"
                window_keys.append(key)
                window_field_map[key] = field
                window_annotations[key] = Window(expression=FirstValue(F(field)),partition_by=[F('plant_machinery_machine__id')],order_by=F('log_book_date').asc())
            elif operation == 'last_value':
                key = f"{field}_last"
                window_keys.append(key)
                window_field_map[key] = field
                window_annotations[key] = Window(expression=LastValue(F(field)),partition_by=[F('plant_machinery_machine__id')],order_by=F('log_book_date').asc())
        search = custom_filters(request, {}, ['fields'])
        base_fields = [
            'plant_machinery_machine__id',
            'plant_machinery_machine__machine_number',
            'plant_machinery_machine__equipment_description',
            'plant_machinery_machine__registration_no',
            'plant_machinery_machine__plant_machinery_group__machine_type',
            'project',
        ]
        aggregates_qs = PlantMachineryLogBook.cmobjects.values(*base_fields).annotate(**aggregation_fields).filter(*search).distinct().order_by(*str(order_by).split(","))
        window_qs = PlantMachineryLogBook.cmobjects.annotate(**window_annotations).values('plant_machinery_machine__id', *window_keys).filter(*search)
        window_map = {}
        for row in window_qs:
            machine_id = row['plant_machinery_machine__id']
            if machine_id not in window_map:
                window_map[machine_id] = {}
            for k in window_keys:
                original_field = window_field_map[k]
                window_map[machine_id][original_field] = row[k]
        final_results = []
        for row in aggregates_qs:
            machine_id = row['plant_machinery_machine__id']
            if machine_id in window_map:
                row.update(window_map[machine_id])
            final_results.append(row)
        if all == 'true':
            return Response({'results': final_results})
        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE)) 
        paginator = Paginator(final_results, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)
        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": list(page),
        })

class PlantMachineryLogBookCumulative3APIView(APIView):
    """
    API to fetch cumulative or starting values based on machine.
    """
    
    
    def get(self, request):
        fields = request.query_params.get('fields', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if not fields:
            raise APIException({'request_status': 0, 'msg': "Require fields."})
        try:
            fields = json.loads(fields)
        except json.JSONDecodeError:
            raise APIException({'request_status': 0, 'msg': "Invalid JSON format for fields."})
        window_annotations = {}
        aggregation_fields = {}
        for field, operation in fields.items():
            if operation == 'aggregate':
                aggregation_fields[field] = Coalesce(Sum(field), Value(0), output_field=FloatField())
            elif operation == 'average':
                aggregation_fields[field] = Coalesce(Avg(field), Value(0), output_field=FloatField())
            elif operation == 'first_value':
                window_annotations[f"{field}"] = Window(
                    expression=FirstValue(F(field)),
                    partition_by=[F('plant_machinery_machine__id')],
                    order_by=F('log_book_date').asc()
                )
            elif operation == 'last_value':
                window_annotations[f"{field}"] = Window(
                    expression=LastValue(F(field)),
                    partition_by=[F('plant_machinery_machine__id')],
                    order_by=F('log_book_date').asc()
                )
        search = custom_filters(request, {}, ['fields'])
        result = PlantMachineryLogBook.cmobjects.annotate(**window_annotations).values(
                'plant_machinery_machine__id',
                'plant_machinery_machine__machine_number',
                'plant_machinery_machine__equipment_description',
                'plant_machinery_machine__registration_no',
                'plant_machinery_machine__plant_machinery_group__machine_type',
                'project',
            ).annotate(**aggregation_fields).filter(*search).distinct().order_by(*str(order_by).split(","))
        
        if all == 'true':
            return Response({'results': result})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE)) 
        paginator = Paginator(result, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)
        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": list(page),
        })


class PlantMachineryLogBookCumulative2APIViewBack(APIView):
    """
    OLD VERSION API BACKUP
    API to fetch cumulative or starting values based on machine .
    """
    
    

    def get(self, request):
        result = []
        fields = request.query_params.get('fields', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if fields:
            try:
                fields = json.loads(fields)
            except json.JSONDecodeError:
                raise APIException({'request_status': 0, 'msg': "Invalid JSON format for fields."})

        aggregation_fields = {}
        for field, operation in fields.items():
            exp = None
            if operation == 'aggregate':
                exp = Coalesce(Sum(field), Value(0), output_field=FloatField())
            if operation == 'average':
                exp = Coalesce(Avg(field), Value(0), output_field=FloatField())
            if operation == 'first_value':
                exp = Window(expression=FirstValue(field), partition_by=[F('plant_machinery_machine__id')], order_by=F('log_book_date').asc())
            if operation == 'last_value':
                exp = Window(expression=LastValue(field), partition_by=[F('plant_machinery_machine__id')], order_by=F('log_book_date').asc())
            if exp is not None:
                aggregation_fields[field] = exp

        search = custom_filters(request, {}, ['fields'])
        result = PlantMachineryLogBook.cmobjects.values(
            'plant_machinery_machine__id',
            'plant_machinery_machine__machine_number',
            'plant_machinery_machine__equipment_description',
            'plant_machinery_machine__registration_no',
            'plant_machinery_machine__plant_machinery_group__machine_type',
            'project',
        ).annotate(**aggregation_fields).filter(*search).distinct().order_by(*str(order_by).split(","))
        if all == 'true':
            return Response({'results': result})
        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(result, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)
        return Response(
            {
                "count": paginator.count,
                "next": page.next_page_number() if page.has_next() else None,
                "previous": page.previous_page_number() if page.has_previous() else None,
                "results": list(page),
            }
        )


class PlantMachineryFuelTransactionCRUDAPIView(APIView):
    """
    CRUD API for PlantMachineryFuelTransaction
    """
    
    

    def get(self, request):
        """
        Retrieve PlantMachineryFuelTransaction details or a list of transactions
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            transaction = PlantMachineryFuelTransaction.cmobjects.filter(id=id).first()
            serializer = PlantMachineryFuelTransactionSerializer(transaction)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryFuelTransaction.cmobjects.select_related(
                "organization",
                "project",
            ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryFuelTransactionSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryFuelTransactionSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryFuelTransaction entry
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryFuelTransactionSerializer(data=request.data,context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryFuelTransaction entry
        """
        method = request.query_params.get('method', None)
        transaction_id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryFuelTransaction entry
                """
                if PlantMachineryFuelTransaction.cmobjects.filter(pk=transaction_id,organization_id=organization_id).exists():
                    details = PlantMachineryFuelTransaction.cmobjects.filter(pk=transaction_id,organization_id=organization_id).first()
                    request.data['updated_by'] = request.user.id

                    serializer = PlantMachineryFuelTransactionSerializer(
                        details, data=request.data, partial=True, context={'request': request}
                    )
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully updated.',
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryFuelTransaction entry
                """
                if PlantMachineryFuelTransaction.cmobjects.filter(pk=transaction_id,organization_id=organization_id).exists():
                    details = PlantMachineryFuelTransaction.cmobjects.filter(pk=transaction_id,organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': PlantMachineryFuelTransaction.objects.filter(pk=transaction_id,organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})


class PlantMachineryBudgetMasterAPIView(APIView):
    """
    CRUD API for PlantMachineryBudgetMaster
    """
    
    

    def get(self, request):
        """
        Retrieve PlantMachineryBudgetMaster details or a list of budgets
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            budget = PlantMachineryBudgetMaster.cmobjects.filter(id=id).first()
            serializer = PlantMachineryBudgetMasterSerializer(budget)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryBudgetMaster.cmobjects.select_related(
                "organization",
                "project",
            ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryBudgetMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryBudgetMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryBudgetMaster entry
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryBudgetMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryBudgetMaster entry
        """
        method = request.query_params.get('method', None)
        budget_id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryBudgetMaster entry
                """
                if PlantMachineryBudgetMaster.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    budget = PlantMachineryBudgetMaster.cmobjects.filter(pk=budget_id, organization_id=organization_id).first()
                    request.data['updated_by'] = request.user.id

                    serializer = PlantMachineryBudgetMasterSerializer(
                        budget, data=request.data, partial=True, context={'request': request}
                    )
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully updated.',
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryBudgetMaster entry
                """
                if PlantMachineryBudgetMaster.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    budget = PlantMachineryBudgetMaster.objects.filter(pk=budget_id, organization_id=organization_id).first()
                    budget.is_deleted = True
                    budget.updated_by_id = request.user.id
                    budget.save()

                    return Response({'results': {
                        'Data': PlantMachineryBudgetMaster.objects.filter(pk=budget_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

class PlantMachineryMachineBudgetAPIView(APIView):
    """
    CRUD API for PlantMachineryMachineBudget
    """
    
    

    def get(self, request):
        """
        Retrieve PlantMachineryMachineBudget details 
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            budget = PlantMachineryMachineBudget.cmobjects.filter(id=id).first()
            serializer = PlantMachineryMachineBudgetSerializer(budget)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryMachineBudget.cmobjects.select_related(
                "organization",
                "project",
                "plant_machinery_machine",
                "budget_master",
            ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryMachineBudgetSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryMachineBudgetSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryMachineBudget 
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryMachineBudgetSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            organization_id = serializer.validated_data.get('organization').id
            project_id = serializer.validated_data.get('project').id if serializer.validated_data.get('project') else None
            plant_machinery_group_id = serializer.validated_data.get('plant_machinery_group').id if serializer.validated_data.get('plant_machinery_group') else None
            budget_master_id = serializer.validated_data.get('budget_master').id if serializer.validated_data.get('budget_master') else None
            exists = PlantMachineryMachineBudget.cmobjects.filter(
                organization_id=organization_id,
                project_id=project_id,
                plant_machinery_group_id=plant_machinery_group_id,
                budget_master_id=budget_master_id,
            ).exists()

            if exists:
                raise APIException({'request_status': 0, 'msg': 'Budget already exists for the same machine.'})

            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response({
                'results': {'Data': serializer.data},
                'msg': 'Successfully created.',
                'status': status.HTTP_201_CREATED,
                "request_status": 1
            })

        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryMachineBudget 
        """
        method = request.query_params.get('method', None)
        budget_id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryMachineBudget 
                """
                if PlantMachineryMachineBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    budget = PlantMachineryMachineBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).first()
                    request.data['updated_by'] = request.user.id

                    serializer = PlantMachineryMachineBudgetSerializer(
                        budget, data=request.data, partial=True, context={'request': request}
                    )
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully updated.',
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryMachineBudget entry
                """
                if PlantMachineryMachineBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    budget = PlantMachineryMachineBudget.objects.filter(pk=budget_id, organization_id=organization_id).first()
                    budget.is_deleted = True
                    budget.updated_by_id = request.user.id
                    budget.save()

                    return Response({'results': {
                        'Data': PlantMachineryMachineBudget.objects.filter(pk=budget_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})


class PlantMachineryMachineBudgetConsumptionAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        search = custom_filters(request, {}, [])
        fuel_cost_summary = []

        fuel_budget_data = (
            PlantMachineryMachineBudget.cmobjects
            .select_related('project', 'plant_machinery_group') 
            .filter(*search)  
            .values('project_id', 'plant_machinery_group_id', 'plant_machinery_group__name', 'amount')
        )

        for budget in fuel_budget_data:
            actual_cost_details = (
                PlantMachineryLogBook.cmobjects.select_related('plant_machinery_machine','plant_machinery_machine__plant_machinery_group')
                
                .values('plant_machinery_machine__plant_machinery_group_id', 'plant_machinery_machine__plant_machinery_group__name','log_book_date__year', 'log_book_date__month',
                )
                .annotate(
                    actual_cost=Coalesce(Sum(
                        Subquery(
                            PlantMachineryMachineRent.cmobjects.filter(
                                rent_date__lte=OuterRef('log_book_date'),
                                rent_to_date__gte=OuterRef('log_book_date'),
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                            ).values('rent_date','plant_machinery_machine_id',).annotate(value=Avg('rent_amount')).values('value')[:1]
                        )),
                        Value(0), output_field=FloatField()
                    ),
                    actual_cost_owned=Coalesce(Sum(
                        Subquery(
                            PlantMachineryMachineRent.cmobjects.filter(
                                rent_date__lte=OuterRef('log_book_date'),
                                rent_to_date__gte=OuterRef('log_book_date'),
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                plant_machinery_machine__owner_type='owned'
                            ).values('rent_date','plant_machinery_machine_id',).annotate(value=Avg('rent_amount')).values('value')[:1]
                        )),
                        Value(0), output_field=FloatField()
                    ),
                    actual_cost_hired=Coalesce(Sum(
                        Subquery(
                            PlantMachineryMachineRent.cmobjects.filter(
                                rent_date__lte=OuterRef('log_book_date'),
                                rent_to_date__gte=OuterRef('log_book_date'),
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                plant_machinery_machine__owner_type='hired'
                            ).values('rent_date','plant_machinery_machine_id',).annotate(value=Avg('rent_amount')).values('value')[:1]
                        )),
                        Value(0), output_field=FloatField()
                    ),
                    depreciation_cost=Coalesce(Sum(
                        Subquery(
                            PlantMachineryMachineDepreciation.cmobjects.filter(
                                date__lte=OuterRef('log_book_date'),
                                to_date__gte=OuterRef('log_book_date'),
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                            ).values('date','plant_machinery_machine_id',).annotate(value=Avg('amount')).values('value')[:1]
                        )),
                        Value(0), output_field=FloatField()
                    ),
                    depreciation_cost_owned=Coalesce(Sum(
                        Subquery(
                            PlantMachineryMachineDepreciation.cmobjects.filter(
                                date__lte=OuterRef('log_book_date'),
                                to_date__gte=OuterRef('log_book_date'),
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                plant_machinery_machine__owner_type='owned'
                            ).values('date','plant_machinery_machine_id',).annotate(value=Avg('amount')).values('value')[:1]
                        )),
                        Value(0), output_field=FloatField()
                    ),
                    depreciation_cost_hired=Coalesce(Sum(
                        Subquery(
                            PlantMachineryMachineDepreciation.cmobjects.filter(
                                date__lte=OuterRef('log_book_date'),
                                to_date__gte=OuterRef('log_book_date'),
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                plant_machinery_machine__owner_type='hired'
                            ).values('date','plant_machinery_machine_id',).annotate(value=Avg('amount')).values('value')[:1]
                        )),
                        Value(0), output_field=FloatField()
                    ),
                    # machine_count_owned=Coalesce(
                    #     Count(
                    #         Subquery(
                    #         PlantMachineryMachine.cmobjects.filter(
                    #             id=OuterRef('plant_machinery_machine_id'),
                    #             owner_type='owned'
                    #         ).values('id')
                    #     ),distinct=True
                    #     ),
                    #     Value(0),
                    #     output_field=IntegerField()
                    # ),
                    # machine_count_hired=Coalesce(
                    #     Count(
                    #         Subquery(
                    #         PlantMachineryMachine.cmobjects.filter(
                    #             id=OuterRef('plant_machinery_machine_id'),
                    #             owner_type='hired'
                    #         ).values('id')
                    #     ),distinct=True
                    #     ),
                    #     Value(0),
                    #     output_field=IntegerField()
                    # ),
                ).filter(
                    project_id=budget['project_id'],
                    # plant_machinery_machine__is_active=True,
                    plant_machinery_machine__is_deleted=False,
                    plant_machinery_machine__plant_machinery_group__is_deleted=False,
                    plant_machinery_machine__plant_machinery_group_id=budget['plant_machinery_group_id']
                )
                .exclude(in_service='Breakdown')
                .order_by('plant_machinery_machine__plant_machinery_group_id','log_book_date__year', 'log_book_date__month',)
                .values('actual_cost', 'log_book_date__year', 'log_book_date__month', 
                'actual_cost_owned','actual_cost_hired',
                'depreciation_cost','depreciation_cost_owned','depreciation_cost_hired',
                # 'machine_count_owned','machine_count_hired'
                ).distinct()
            )
            budget['actual_cost_details'] = list(actual_cost_details)
            fuel_cost_summary.append(budget)

        if all == "true":
            return Response({"results": fuel_cost_summary})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(fuel_cost_summary, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)

        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": list(page.object_list),
        })

class PlantMachineryElectricityBudgetAPIView(APIView):
    """
    CRUD API for PlantMachineryElectricityBudget
    """
    
    

    def get(self, request):
        """
        Retrieve PlantMachineryElectricityBudget details 
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            budget = PlantMachineryElectricityBudget.cmobjects.filter(id=id).first()
            serializer = PlantMachineryElectricityBudgetSerializer(budget)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryElectricityBudget.cmobjects.select_related(
                "organization",
                "project",
                "budget_master",
            ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryElectricityBudgetSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryElectricityBudgetSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryElectricityBudget 
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryElectricityBudgetSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryElectricityBudget 
        """
        method = request.query_params.get('method', None)
        budget_id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryElectricityBudget 
                """
                if PlantMachineryElectricityBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    budget = PlantMachineryElectricityBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).first()
                    request.data['updated_by'] = request.user.id

                    serializer = PlantMachineryElectricityBudgetSerializer(
                        budget, data=request.data, partial=True, context={'request': request}
                    )
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully updated.',
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryElectricityBudget 
                """
                if PlantMachineryElectricityBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    budget = PlantMachineryElectricityBudget.objects.filter(pk=budget_id, organization_id=organization_id).first()
                    budget.is_deleted = True
                    budget.updated_by_id = request.user.id
                    budget.save()

                    return Response({'results': {
                        'Data': PlantMachineryElectricityBudget.objects.filter(pk=budget_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

class PlantMachineryElectricityBudgetConsumptionAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        search = custom_filters(request, {}, [])

        data_list = (
            PlantMachineryElectricityBudget.cmobjects
            .select_related("organization", "project", "budget_master")
              
            .annotate(
                # budgeted_amount=Coalesce(Sum("amount"), Value(0), output_field=FloatField()),
                
                actual_cost_amount=Coalesce(
                    Subquery(
                        PlantMachineryElectricityEntry.cmobjects
                        .filter(
                            project_id=OuterRef("project_id"),
                            date=OuterRef("date")
                        )
                        .values("project_id","date")
                        .annotate(
                            total_amount=Sum("amount")
                        )
                        .values("total_amount")[:1], 
                    ),
                    Value(0),
                    output_field=FloatField(),
                )
            )
            .filter(*search)
            .order_by(*str(order_by).split(","))
        ).values()
       
        if all == "true":
            return Response({"results": list(data_list)})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(data_list, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)

        return Response(
            {
                "count": paginator.count,
                "next": page.next_page_number() if page.has_next() else None,
                "previous": page.previous_page_number() if page.has_previous() else None,
                "results": list(page.object_list),
            }
        )
class PlantMachineryFuelBudgetAPIView(APIView):
    """
    CRUD API for PlantMachineryFuelBudget
    """
    
    

    def get(self, request):
        """
        Retrieve PlantMachineryFuelBudget details 
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            budget = PlantMachineryFuelBudget.cmobjects.filter(id=id).first()
            serializer = PlantMachineryFuelBudgetSerializer(budget)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryFuelBudget.cmobjects.select_related(
                "organization",
                "project",
                "budget_master",
            ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryFuelBudgetSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryFuelBudgetSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryFuelBudget 
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryFuelBudgetSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryFuelBudget 
        """
        method = request.query_params.get('method', None)
        budget_id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a PlantMachineryFuelBudget 
                """
                if PlantMachineryFuelBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    budget = PlantMachineryFuelBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).first()
                    request.data['updated_by'] = request.user.id

                    serializer = PlantMachineryFuelBudgetSerializer(
                        budget, data=request.data, partial=True, context={'request': request}
                    )
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully updated.',
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            elif method.lower() == 'delete':
                """
                Delete a PlantMachineryFuelBudget 
                """
                if PlantMachineryFuelBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    budget = PlantMachineryFuelBudget.objects.filter(pk=budget_id, organization_id=organization_id).first()
                    budget.is_deleted = True
                    budget.updated_by_id = request.user.id
                    budget.save()

                    return Response({'results': {
                        'Data': PlantMachineryFuelBudget.objects.filter(pk=budget_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

class PlantMachineryFuelBudgetConsumptionAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        search = custom_filters(request, {}, [])
        fuel_cost_summary = []
        
        fuel_budget_data = (
            PlantMachineryFuelBudget.cmobjects
            .filter(*search)  
            .values('project_id', 'fuel_type', 'amount') 
        )

        for budget in fuel_budget_data:
            budget['actual_cost_details'] = (
                PlantMachineryLogBook.cmobjects
                .filter(
                    project_id=budget['project_id'],
                    fueltype="diesel" if budget['fuel_type'] == "HSD" else "petrol"
                )
                .values('fueltype', 'log_book_date__year', 'log_book_date__month')
                .annotate(
                    total_fuel_filled=Coalesce(Sum('total_fuel_filled'), Value(0), output_field=FloatField()),
                )
                .order_by('fueltype', 'log_book_date__year', 'log_book_date__month')
                .values('total_fuel_filled', 'log_book_date__year', 'log_book_date__month')
            )
            fuel_cost_summary.append(budget)

        if all == "true":
            return Response({"results": fuel_cost_summary})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(fuel_cost_summary, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)

        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": list(page.object_list),
        })


class PlantMachineryFuelBudgetConsumptionTest1APIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        
        search = custom_filters(request, {}, [])
        
        fuel_cost_data = (
            PlantMachineryLogBook.cmobjects
            .filter(*search)
            .values('project_id', 'fueltype')
            .annotate(
                year=ExtractYear('log_book_date'),
                month=ExtractMonth('log_book_date'),
                total_fuel_filled=Coalesce(Sum('total_fuel_filled'), Value(0), output_field=FloatField()),
                fuel_type=Case(
                    When(fueltype='diesel', then=Value('HSD')),
                    default=Value('Petrol'),
                    output_field=CharField(),
                ),
                budgeted_amount=Subquery(
                    PlantMachineryFuelBudget.cmobjects
                    .filter(
                        project_id=OuterRef('project_id'),
                        fuel_type=OuterRef('fuel_type')
                    )
                    .values('amount')[:1]
                )
            )
            .values('project_id', 'fuel_type', 'year', 'month', 'total_fuel_filled', 'budgeted_amount')
        )
        print(fuel_cost_data)
        fuel_cost_summary = {}

        for entry in fuel_cost_data:
            fuel_type = entry['fuel_type']
            year = entry['year']
            month = entry['month']
            total_fuel_filled = entry['total_fuel_filled']
            budgeted_amount = entry['budgeted_amount']
            actual_cost = total_fuel_filled  if budgeted_amount else 0

            if fuel_type not in fuel_cost_summary:
                fuel_cost_summary[fuel_type] = {
                    'fuel_type': fuel_type,
                    'budgeted_amount': budgeted_amount,
                    'actual_cost_details': []
                }

            fuel_cost_summary[fuel_type]['actual_cost_details'].append({
                'month': month,
                'year': year,
                'total_fuel_filled': total_fuel_filled,
                'actual_cost': actual_cost
            })

        fuel_cost_data = list(fuel_cost_summary.values())

        if all == "true":
            return Response({"results": fuel_cost_data})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(fuel_cost_data, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)

        return Response(
            {
                "count": paginator.count,
                "next": page.next_page_number() if page.has_next() else None,
                "previous": page.previous_page_number() if page.has_previous() else None,
                "results": list(page.object_list),
            }
        )

class PlantMachineryElectricityEntryAPIView(APIView):
    """
    CRUD API for PlantMachineryElectricityEntry
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryElectricityEntry
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            entry = PlantMachineryElectricityEntry.cmobjects.filter(id=id).first()
            serializer = PlantMachineryElectricityEntrySerializer(entry)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = PlantMachineryElectricityEntry.cmobjects.select_related(
            'organization',
            'project',
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryElectricityEntrySerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryElectricityEntrySerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryElectricityEntry
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryElectricityEntrySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryElectricityEntry
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        entry_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryElectricityEntry.cmobjects.filter(pk=entry_id, organization_id=organization_id).exists():
                    entry = PlantMachineryElectricityEntry.objects.filter(pk=entry_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryElectricityEntrySerializer(entry, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryElectricityEntry.cmobjects.filter(pk=entry_id, organization_id=organization_id).exists():
                    entry = PlantMachineryElectricityEntry.objects.filter(pk=entry_id, organization_id=organization_id).first()
                    entry.is_deleted = True
                    entry.updated_by_id = request.user.id
                    entry.save()
                    return Response({'results': {'Data': PlantMachineryElectricityEntry.objects.filter(pk=entry_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class PlantMachineryHsdIssuedReportAPIView(APIView):
    """
    CRUD API for PlantMachineryHsdIssuedReport
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryHsdIssuedReport
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            report = PlantMachineryHsdIssuedReport.cmobjects.filter(id=id).first()
            serializer = PlantMachineryHsdIssuedReportSerializer(report)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = PlantMachineryHsdIssuedReport.cmobjects.select_related(
            'organization', 'project'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryHsdIssuedReportSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryHsdIssuedReportSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryHsdIssuedReport
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryHsdIssuedReportSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryHsdIssuedReport
        """
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        report_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryHsdIssuedReport.cmobjects.filter(pk=report_id, organization_id=organization_id).exists():
                    report = PlantMachineryHsdIssuedReport.cmobjects.filter(pk=report_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryHsdIssuedReportSerializer(report, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryHsdIssuedReport.cmobjects.filter(pk=report_id, organization_id=organization_id).exists():
                    report = PlantMachineryHsdIssuedReport.cmobjects.filter(pk=report_id, organization_id=organization_id).first()
                    report.is_deleted = True
                    report.updated_by_id = request.user.id
                    report.save()
                    return Response({'results': {'Data': PlantMachineryHsdIssuedReport.objects.filter(pk=report_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class PlantMachineryRepairAPIView(APIView):
    """
    CRUD API for PlantMachineryRepair
    """
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            repair = PlantMachineryRepair.cmobjects.filter(id=id).first()
            serializer = PlantMachineryRepairSerializer(repair)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = PlantMachineryRepair.cmobjects.select_related(
            'organization', 'project', 'plant_machinery_machine'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryRepairSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryRepairSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryRepairSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response({'results': {'Data': serializer.data},
                             'msg': 'Successfully created',
                             'status': status.HTTP_201_CREATED,
                             "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        repair_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryRepair.cmobjects.filter(pk=repair_id, organization_id=organization_id).exists():
                    details = PlantMachineryRepair.objects.filter(pk=repair_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryRepairSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryRepair.cmobjects.filter(pk=repair_id, organization_id=organization_id).exists():
                    details = PlantMachineryRepair.objects.filter(pk=repair_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'Data': PlantMachineryRepair.objects.filter(pk=repair_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryRepairCummulativeAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        date__gte = request.query_params.get('date__gte', None)#start date
        date__lte = request.query_params.get('date__lte', None)#end date
        order_by = request.query_params.get('order_by', '-id')
        start_date_filter = {'log_book_date__lte': date__gte} if date__gte else {}
        close_date_filter = {'log_book_date__lte': date__lte} if date__lte else {}
        search = custom_filters(request, {}, [])
        data_list = PlantMachineryRepair.cmobjects.select_related(
            'organization', 'project', 'plant_machinery_machine',
        ).values(
            'plant_machinery_machine_id', 'plant_machinery_machine__machine_number', 'plant_machinery_machine__equipment_description', 'plant_machinery_machine__registration_no', 'plant_machinery_machine__equipment_number', 'plant_machinery_machine__plant_machinery_group__machine_type', 'repair_type',
        ).annotate(
            # hmr_kmr_cumulative__sum = Coalesce(Max('hmr_kmr_cumulative')-Min('hmr_kmr_cumulative'), Value(0), output_field=FloatField()),
            start_value=Coalesce(Subquery(
                PlantMachineryLogBook.cmobjects.filter(
                    plant_machinery_machine=OuterRef('plant_machinery_machine'),
                    **start_date_filter  
                ).order_by('-log_book_date').values_list(
                    Case(
                        When(plant_machinery_machine__plant_machinery_group__machine_type="vehicle", then=F('start_kms')),
                        When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=F('start_hrs')),
                        default=Value(0),
                        output_field=FloatField()
                    ), flat=True
                )[:1]
            ), Value(0), output_field=FloatField()),

            close_value=Coalesce(Subquery(
                PlantMachineryLogBook.cmobjects.filter(
                    plant_machinery_machine=OuterRef('plant_machinery_machine'),
                    **close_date_filter  
                ).order_by('-log_book_date').values_list(
                    Case(
                        When(plant_machinery_machine__plant_machinery_group__machine_type="vehicle", then=F('close_kms')),
                        When(plant_machinery_machine__plant_machinery_group__machine_type="machine", then=F('close_hrs')),
                        default=Value(0),
                        output_field=FloatField()
                    ), flat=True
                )[:1]
            ), Value(0), output_field=FloatField()),

            hmr_kmr_cumulative__sum=F('close_value') - F('start_value'),
            spares__sum = Coalesce(Sum('spares'), Value(0), output_field=FloatField()),

            lubricants__sum = Coalesce(Sum('lubricants'), Value(0), output_field=FloatField()),
            wear_and_tear__sum = Coalesce(Sum('wear_and_tear'), Value(0), output_field=FloatField()),
            adblue__sum = Coalesce(Sum('adblue'), Value(0), output_field=FloatField()),
            labour__sum = Coalesce(Sum('labour'), Value(0), output_field=FloatField()),
            total__sum = Coalesce(Sum('total'), Value(0), output_field=FloatField()),
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            return Response({'results': data_list})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(data_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': page.object_list,
            },
        })

class PlantMachineryRepairBudgetAPIView(APIView):
    """
    CRUD API for PlantMachineryRepairBudget
    """
    
    

    def get(self, request):
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            budget = PlantMachineryRepairBudget.cmobjects.filter(id=id).first()
            serializer = PlantMachineryRepairBudgetSerializer(budget)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = PlantMachineryRepairBudget.cmobjects.select_related(
            'organization', 'project', 'budget_master', 'plant_machinery_group'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryRepairBudgetSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryRepairBudgetSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryRepairBudgetSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response({'results': {'Data': serializer.data},
                             'msg': 'Successfully created',
                             'status': status.HTTP_201_CREATED,
                             "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        budget_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryRepairBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    details = PlantMachineryRepairBudget.cmobjects.filter(pk=budget_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryRepairBudgetSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryRepairBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).exists():
                    details = PlantMachineryRepairBudget.cmobjects.filter(pk=budget_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'Data': PlantMachineryRepairBudget.objects.filter(pk=budget_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryRepairBudgetConsumptionAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        group_by = request.query_params.get('group_by', 'plant_machinery_group_id')
        values_list = ['total_amount','actual_cost',group_by]
        search = custom_filters(request, {}, ['group_by'])
        filter_list = { 'project_id': OuterRef('project_id') }
        if group_by == 'plant_machinery_group_id':
            values_list.append('plant_machinery_group__name')
            filter_list['plant_machinery_machine__plant_machinery_group_id'] = OuterRef('plant_machinery_group_id')
        else:
            filter_list['date__month'] = OuterRef('date__month')
            filter_list['date__year'] = OuterRef('date__year')
        data_list = (
            PlantMachineryRepairBudget.cmobjects
            .select_related('organization', 'project', 'plant_machinery_group')
            .values(group_by)
            .annotate(
                # total_amount=Coalesce(Sum('amount'), Value(0), output_field=FloatField()),
                actual_cost=Coalesce(
                    Subquery(
                        PlantMachineryRepair.cmobjects
                        .filter(**filter_list)
                        .values(*filter_list.keys())
                        .annotate(total_value=Coalesce(Sum('total'), Value(0), output_field=FloatField()))
                        .values('total_value')[:1]
                    ),
                    Value(0),
                    output_field=FloatField(),
                ),
                total_amount=Coalesce(
                    ExpressionWrapper(
                        Subquery(
                            PlantMachineryLogBook.cmobjects
                            .filter(
                                project_id=OuterRef('project_id'),
                                plant_machinery_group=OuterRef('plant_machinery_group'),
                                plant_machinery_group__is_deleted=False,
                                plant_machinery_group__machine_type__in=['machine', 'vehicle'],
                                log_book_date__year=OuterRef('date__year'),
                                log_book_date__month=OuterRef('date__month'),
                            )
                            .values('plant_machinery_group')
                            .annotate(
                                monthly_running=Sum(
                                    Case(
                                        When(plant_machinery_group__machine_type='machine', then='total_working_hrs'),
                                        When(plant_machinery_group__machine_type='vehicle', then='total_km_run'),
                                        default=Value(0),
                                        output_field=FloatField(),
                                    )
                                )
                            )
                            .values('monthly_running')
                        ) * F('plant_machinery_group__r_and_m_norms'),
                        output_field=FloatField(),
                    ),
                    Value(0),
                    output_field=FloatField()
                )
            )
            .filter(*search)
            .order_by(group_by).values(*values_list)
        )

        if all == "true":
            return Response({"results": list(data_list)})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(data_list, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)

        return Response(
            {
                "count": paginator.count,
                "next": page.next_page_number() if page.has_next() else None,
                "previous": page.previous_page_number() if page.has_previous() else None,
                "results": list(page.object_list),
            }
        )
class PlantMachineryAssetRequisitionMainAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        all_pending_by_user = request.query_params.get('all_pending_by_user', None)

        search = custom_filters(request, {}, ['all_pending_by_user'])
        
        if all_pending_by_user:
            try:
                site_map = json.loads(all_pending_by_user)
                search.extend([~Q(asset_requisition__status__icontains='approved'), Q(asset_requisition__status__icontains='checked')])
                search_processed = []
                for site_id, value in site_map.items():
                    search_processed.append(Q(asset_requisition__site_id=site_id) & Q(asset_requisition__current_stage__in=value))
                search.append(reduce(operator.or_, search_processed))
            except Exception as e:
                print("Error parsing all_pending_by_user:", e)
        _list = PlantMachineryAssetRequisitionItem.cmobjects.select_related(
            'organization',
            'asset_requisition',
            'asset_requisition__organization',
            'asset_requisition__site',
            'asset_requisition__store',
            'asset_requisition__project',
            'asset_requisition__financialyear',
            'plant_machinery_group'
        )
        annotations = {}
        approval_applicable_list = []
        already_approved_list = []
        has_permission = UserWiseModulePermissions.cmobjects.filter(
            user_id=request.user.id,
            module_item__unique_id__in=['procurement-pnmar-checker'],
            level_permission=True,
        ).exists()
        if has_permission:
            approval_applicable_list.append(When(Q(asset_requisition__current_stage__in=[0],asset_requisition__status='pending'), then=Value(True)))
            already_approved_list.append(When(Q(asset_requisition__current_stage__in=[0],asset_requisition__status='checked'), then=Value(True)))
        
        # annotations['ref_ref_stage_type']=Case(
        #     When(Q(asset_requisition__ref_stage_type__isnull=False), then=F('asset_requisition__ref_stage_type_id')),
        #     default=Subquery(
        #         MultiStageSetting.cmobjects.filter(
        #             Q(site=OuterRef('asset_requisition__site_id')),
        #             Q(from_name=Value('pnmar'))
        #         ).values('pk')[:1],
        #     ),
        #     output_field=CharField()
        # )
        annotations['ref_ref_stage_type']=F('asset_requisition__ref_stage_type_id')

        annotations['multi_stage_max_stage']=Subquery(
            MultiStageSettingStages.cmobjects.filter(
                Q(multi_stage_setting__is_deleted=False),
                Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
            ).order_by('-stage').values('stage')[:1]
        )

        annotations['current_status']=Case(
            When(asset_requisition__status='pending', then=Value('Pending')),
            When(asset_requisition__status='rejected', then=Value('Rejected')),
            When(asset_requisition__status='cancelled', then=Value('Returned')),
            When(asset_requisition__status='checked',asset_requisition__current_stage=0, then=Value('Checked')),
            When(asset_requisition__status__in=['checked','approved'], then=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(stage=OuterRef('asset_requisition__current_stage')),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).values('stage_name')[:1],
            )),
            default=F('asset_requisition__status'),
            output_field=CharField()
        )

        annotations['approval_applicable']=Case(
            *approval_applicable_list,
            When(Q(Q(asset_requisition__status='checked'),Q(asset_requisition__current_stage__in=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(employee=request.user.id),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).annotate(ref_stage=F('stage')-Value(1)).values('ref_stage'),
            ))), then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )

        annotations['already_approved']=Case(
            *already_approved_list,
            When(Q(Q(asset_requisition__status__in=['checked','approved']),Q(asset_requisition__current_stage__in=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(employee=request.user.id),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).annotate(ref_stage=F('stage')).values('ref_stage'),
            ))), then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )

        stage_data_subqueries = PlantMachineryAssetRequisitionStages.cmobjects.filter(
            asset_requisition=OuterRef(OuterRef('pk')),
            stage=OuterRef('stage')
        ).annotate(
            full_name=Concat(F('created_by__first_name'), Value(' '), F('created_by__last_name'))
        ).order_by('-pk')
        annotations['stage_details']=Subquery(
            MultiStageSettingStages.cmobjects.filter(
                Q(multi_stage_setting__is_deleted=False),
                Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
            ).values('multi_stage_setting').annotate(
                ref_stage_details=GroupConcat(Concat(
                    F('stage'),
                    Value('|'),
                    F('stage_name'),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('full_name')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('created_at')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('status')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('remarks')[:1], output_field=CharField()),
                ), distinct=True)
            ).values('ref_stage_details')
        )
        _list = _list.annotate(**annotations).filter(*search).values(
            # 'id',
            'quantity',
            'availability',
            'project_requirement',
            'type_of_work_or_activity_and_location',
            'required_date',
            'plant_machinery_group__name',
            'asset_requisition__id',
            'asset_requisition__request_code',
            'asset_requisition__version',
            'asset_requisition__latest',
            'asset_requisition__status',
            'asset_requisition__date',
            'asset_requisition__required_duration',
            'asset_requisition__project__project_name',
            'asset_requisition__project__project_code',
            'asset_requisition__current_stage',
            'asset_requisition__site_id',
            'asset_requisition__organization_id',
            **annotations
        ).order_by(*str(order_by).split(",")).distinct()
        print(_list)
        if all == 'true':
            return Response({'results': list(_list)})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': page.object_list,
            },
        })
    
class PlantMachineryAssetRequisitionAPIView(APIView):
    """
    CRUD API for PlantMachineryAssetRequisition
    """
    
    

    def get(self, request):
        """
        Get a list of PlantMachineryAssetRequisition
        """
        check_editor_permissions(request, "pnmar")
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = PlantMachineryAssetRequisition.cmobjects.filter(id=id).first()
            serializer = PlantMachineryAssetRequisitionSerializer(_details)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = PlantMachineryAssetRequisition.cmobjects.select_related(
            'organization', 'project'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryAssetRequisitionSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryAssetRequisitionSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryAssetRequisition
        """
        check_editor_permissions(request, "pnmar")
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryAssetRequisitionSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a PlantMachineryAssetRequisition
        """
        check_editor_permissions(request, "pnmar")
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        requisition_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryAssetRequisition.cmobjects.filter(pk=requisition_id, organization_id=organization_id).exists():
                    details = PlantMachineryAssetRequisition.cmobjects.filter(pk=requisition_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryAssetRequisitionSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if PlantMachineryAssetRequisition.cmobjects.filter(pk=requisition_id, organization_id=organization_id).exists():
                    details = PlantMachineryAssetRequisition.cmobjects.filter(pk=requisition_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'Data': PlantMachineryAssetRequisition.objects.filter(pk=requisition_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

# class PlantMachineryRFQVendorsAPIView(APIView):
#     """
#     CRUD API for PlantMachineryRFQVendors
#     """
#     
#     

#     def get(self, request):
#         id = request.query_params.get('id', None)
#         all = request.query_params.get('all', None)
#         order_by = request.query_params.get('order_by', '-id')

#         if id:
#             details = PlantMachineryRFQVendors.cmobjects.filter(id=id).first()
#             serializer = PlantMachineryRFQVendorsSerializer(details)
#             return Response(serializer.data)

#         search = custom_filters(request, {}, [])
#         _list = PlantMachineryRFQVendors.cmobjects.filter(*search).order_by(*str(order_by).split(","))

#         if all == 'true':
#             serializer = PlantMachineryRFQVendorsSerializer(_list, many=True)
#             return Response({'results': serializer.data})

#         page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
#         paginator = Paginator(_list, page_size)
#         page_number = request.query_params.get('page', 1)
#         page = paginator.get_page(page_number)
#         serializer = PlantMachineryRFQVendorsSerializer(page, many=True)

#         return Response({
#             'count': paginator.count,
#             'next': page.next_page_number() if page.has_next() else None,
#             'previous': page.previous_page_number() if page.has_previous() else None,
#             'results': serializer.data,
#         })                
#     def post(self, request):
#         """
#         Create a new PlantMachineryAssetRequisition
#         """
#         request.data['created_by'] = request.user.id
#         serializer = PlantMachineryRFQVendorsSerializer(data=request.data, context={'request': request})
#         if serializer.is_valid():
#             try:
#                 serializer.save()
#             except Exception as e:
#                 raise APIException({'request_status': 0, 'msg': str(e)})
#             return Response(
#                 {'results': {'Data': serializer.data},
#                  'msg': 'Successfully created',
#                  'status': status.HTTP_201_CREATED,
#                  "request_status": 1})
#         raise APIException({'request_status': 0, 'msg': serializer.errors})

#     def put(self, request):
#         """
#         Edit or delete a PlantMachineryAssetRequisition
#         """
#         method = request.query_params.get('method', None)
#         organization_id = request.query_params.get('organization_id', None)
#         id = request.query_params.get('id', None)

#         with transaction.atomic():
#             if method.lower() == 'edit':
#                 if  PlantMachineryRFQVendors.cmobjects.filter(pk=id, organization_id=organization_id).exists():
#                     details = PlantMachineryRFQVendors.cmobjects.filter(pk=id).first()
#                     request.data['updated_by'] = request.user.id
#                     serializer = PlantMachineryRFQVendorsSerializer(details, data=request.data, partial=True, context={'request': request})

#                     if serializer.is_valid():
#                         try:
#                             serializer.save()
#                         except Exception as e:
#                             raise APIException({'request_status': 0, 'msg': str(e)})
#                         return Response({'results': {'Data': serializer.data},
#                                          'msg': "Successfully updated",
#                                          'status': status.HTTP_202_ACCEPTED,
#                                          "request_status": 1})
#                     raise APIException({'request_status': 0, 'msg': serializer.errors})
#                 else:
#                     raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
#             elif method.lower() == 'delete':
#                 if PlantMachineryRFQVendors.cmobjects.filter(pk=id, organization_id=organization_id).exists():
#                     details = PlantMachineryRFQVendors.cmobjects.filter(pk=id, organization_id=organization_id).first()
#                     details.is_deleted = True
#                     details.updated_by_id = request.user.id
#                     details.save()
#                     return Response({'results': {'Data': PlantMachineryRFQVendors.objects.filter(pk=id, organization_id=organization_id).values()},
#                                      'msg': 'Successfully deleted',
#                                      "request_status": 1})
#                 else:
#                     raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class PlantMachineryRFQVendorsMainAPIView(APIView):
    
    

    def get(self, request):
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')

        search = check_store_site(request)
        search = custom_filters(self.request, search, [])
        data = (PlantMachineryRFQVendors.cmobjects.select_related('organization', \
            'selected_quotation', 'site', 'store', 'project', 'asset_requisition',\
            'financialyear', 'checked_by', 'cancelled_by', 'close_by', 'approved_by', 'rejected_by')\
            .prefetch_related('plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items','plant_machinery_rfq_vendor_plant_machinery_quotation').annotate(
            quot_count = Subquery(
                PlantMachineryQuotation.cmobjects.filter(
                    plant_machinery_rfq_vendor_id=OuterRef('pk'),
                    ).exclude(status__in=['rejected','cancelled']).values('plant_machinery_rfq_vendor').annotate(
                        value=Count('request_code', distinct=True)
                    ).values('value')
            ),
            enq_sent = Subquery(
                PlantMachineryRFQVendorsMailList.cmobjects.filter(
                    plant_machinery_rfq_vendor_id=OuterRef('pk'),
                    email_send__is_sent=True
                    ).values('plant_machinery_rfq_vendor').annotate(
                        value=Count('id')
                    ).values('value')
            ),
            asset_requisition__request_code = Subquery(
                PlantMachineryAssetRequisition.cmobjects.filter(
                    asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_rfq_vendor_items__plant_machinery_rfq_vendor_id=OuterRef('pk'),
                    ).exclude(status__in=['rejected','cancelled']).values('asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_rfq_vendor_items__plant_machinery_rfq_vendor').annotate(
                        value=GroupConcat('request_code', distinct=True)
                    ).values('value')
            ),
            # cst_id = GroupConcat('plant_machinery_rfq_vendor_plant_machinery_cst', distinct=True),
            # cst_is_budgeted = GroupConcat('plant_machinery_rfq_vendor_plant_machinery_cst__is_budgeted', distinct=True),
            # cst_status = GroupConcat('plant_machinery_rfq_vendor_plant_machinery_cst__status', distinct=True),
            
            cst_id = Subquery(
                PlantMachineryCST.cmobjects.filter(
                    plant_machinery_rfq_vendor_id=OuterRef('pk'),
                ).exclude(status__in=['rejected','cancelled']).values('plant_machinery_rfq_vendor').annotate(
                    value=GroupConcat('id', distinct=True)
                ).values('value')
            ),
            cst_is_budgeted = Subquery(
                PlantMachineryCST.cmobjects.filter(
                    plant_machinery_rfq_vendor_id=OuterRef('pk'),
                ).exclude(status__in=['rejected','cancelled']).values('plant_machinery_rfq_vendor').annotate(
                    value=GroupConcat('is_budgeted', distinct=True)
                ).values('value')
            ),
            cst_status = Subquery(
                PlantMachineryCST.cmobjects.filter(
                    plant_machinery_rfq_vendor_id=OuterRef('pk'),
                ).exclude(status__in=['rejected','cancelled']).values('plant_machinery_rfq_vendor').annotate(
                    value=GroupConcat('status', distinct=True)
                ).values('value')
            ),
            cst_details = Subquery(
                PlantMachineryCST.cmobjects.filter(
                    plant_machinery_cst_plant_machinery_cst_item__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef('pk'),
                ).values('plant_machinery_cst_plant_machinery_cst_item__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor').annotate(
                    value=GroupConcat(Concat('id',Value('|'),'version',Value('|'),'status',Value('|'),'current_stage',Value('|'),'is_budgeted',output_field=CharField()), distinct=True)
                ).values('value')
            ),

            ).filter(*search).values(
            'request_code', 'date', 'asset_requisition__request_code', 'id', 'quot_count', 'scope_of_supply', 'project_id','cst_id', 'cst_is_budgeted','cst_status','cst_details', 'is_archived', 'enq_sent'
        ).order_by(*str(order_by).split(",")))

        if all == 'true':
            return Response({'results': data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': page.object_list,
            },
        })
    
class PlantMachineryRFQVendorsAPIView(APIView):
    """
    CRUD API for PlantMachineryRFQVendors model
    """
    
    

    def get(self, request):
        """
        Get a list of all PlantMachineryRFQVendors
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        # vendor_ids = self.request.query_params.get('vendor_ids', None)
        if id:
            _details = PlantMachineryRFQVendors.cmobjects.select_related('organization', \
            'site', 'store', 'project',\
         'financialyear', 'checked_by', 'cancelled_by', 'close_by', 'approved_by', 'rejected_by').filter(id=id).first()
            serializer = PlantMachineryRFQVendorsSerializer(_details)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])

        _list = PlantMachineryRFQVendors.cmobjects.select_related('organization', \
            'site', 'store', 'project',\
         'financialyear', 'checked_by', 'cancelled_by', 'close_by', 'approved_by', 'rejected_by')\
           .filter(*search).order_by('-id')
       
        if all == 'true':
            serializer = PlantMachineryRFQVendorsSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryRFQVendorsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new PlantMachineryRFQVendors
        """
        request.data['updated_by'] = request.user.id
        serializer = PlantMachineryRFQVendorsSerializer(data=request.data, context={'request': request})

        id = request.data.get('id', None)
        vendor = request.data.get('vendor_ids', [])
        temp = []
        try:
            existing_record = PlantMachineryRFQVendorsMailList.cmobjects.filter(plant_machinery_rfq_vendor_id=id).values_list('vendor_id',flat=True)
            if existing_record:
                vendor = list(set(vendor) - set(existing_record))
            print(existing_record)
            print(vendor)
        except Exception as e:
            print(e)
            raise APIException({'request_status': 0, 'msg': f"Enquiry with id: {id} does not exist"})

        if serializer.is_valid():
            try:
                serializer.save()
                process_pnm_rfq_mail(vendor,serializer.data)
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                print(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get(
            'organization_id', None)
        id = request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'delete':
                """
                Delete a RFQVendors
                """
                if PlantMachineryRFQVendors.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = PlantMachineryRFQVendors.cmobjects.filter(
                        pk=id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'site': PlantMachineryRFQVendors.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted ',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})



class PlantMachineryQuotationAPIView(APIView):
    """
    CRUD API for Plant Machinery Quotation model
    """
    
    

    def get_permissions(self):
        if self.request.method == 'POST':
            return [AllowAny()]
        return [IsAuthenticated()]

    def get(self, request):
        """
        Get a list of all Quotation
        """

        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        if id:
            quotation_details = PlantMachineryQuotation.cmobjects.filter(id=id).first()
            serializer = PlantMachineryQuotationSerializer(quotation_details)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])

        quotation_list = PlantMachineryQuotation.cmobjects.select_related('vendor').prefetch_related(
            'plant_machinery_quotation_plant_machinery_quotation_items', 'plant_machinery_quotation_plant_machinery_quotation_tax_details', 'plant_machinery_quotation_plant_machinery_quotation_expense_details',\
            'plant_machinery_quotation_plant_machinery_quotation_attachment', 'plant_machinery_quotation_plant_machinery_quotation_terms_and_conditions'
        ).filter(*search).distinct()

        # print(quotation_list)

        
        if all == 'true':
            serializer = PlantMachineryQuotationSerializer(quotation_list, many=True)

            rfq_vendor_id = request.query_params.get('plant_machinery_rfq_vendor', None)
            rfq_vendor_details = None
            # indent_details = None
            # asset_requisition_details = None
            if rfq_vendor_id:
                rfq_vendor = PlantMachineryRFQVendors.cmobjects.get(pk=rfq_vendor_id)
                if rfq_vendor:
                    try:
                        _s1 = PlantMachineryRFQVendorsSerializer(rfq_vendor)
                        rfq_vendor_details = _s1.data
                    except Exception as e:
                        print('ERROR', e)
                  
            custom_data = {'plant_machinery_rfq_vendor_details': rfq_vendor_details, }

            return Response({'results': serializer.data, 'custom_data': custom_data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(quotation_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryQuotationSerializer(page, many=True)

        print(serializer.data)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Quotation
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryQuotationSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': f'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Quotation
        """
        # current_user = PmsUser.objects.filter(pk=request.user.id).first()
        check_editor_permissions(request, "pnmquotation")
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get(
            'organization_id', None)
        quotation_id = request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Plant Machinery Quotation
                """
                if PlantMachineryQuotation.cmobjects.filter(pk=quotation_id, organization_id=organization_id).exists():
                    quotation = PlantMachineryQuotation.cmobjects.filter(pk=quotation_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryQuotationSerializer(quotation, data=request.data)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully Updated.',
                                'status': status.HTTP_200_OK,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Plant Machinery Quotation
                """
                if PlantMachineryQuotation.cmobjects.filter(pk=quotation_id, organization_id=organization_id).exists():
                    quotation_details = PlantMachineryQuotation.cmobjects.filter(
                        pk=quotation_id, organization_id=organization_id).first()
                    quotation_details.is_deleted = True
                    quotation_details.updated_by_id = request.user.id
                    quotation_details.save()

                    return Response({'results': {
                        'site': PlantMachineryQuotation.objects.filter(pk=quotation_id,
                                                         organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class PlantMachineryCSTMainAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        all_pending_by_user = request.query_params.get('all_pending_by_user', None)

        search = check_store_site(request)
        search = custom_filters(request, search, ['all_pending_by_user'])

        if all_pending_by_user:
            try:
                site_map = json.loads(all_pending_by_user)
                search.extend([~Q(status__icontains='approved'), Q(status__icontains='checked')])
                search_processed = []
                for site_id, value in site_map.items():
                    search_processed.append(Q(site_id=site_id) & Q(current_stage__in=value))
                search.append(reduce(operator.or_, search_processed))
            except Exception as e:
                print("Error parsing all_pending_by_user:", e)

        _list = PlantMachineryCST.cmobjects.select_related('organization','site','store','project','financialyear','previous_version',
            'asset_requisitions','plant_machinery_rfq_vendor','checked_by','cancelled_by','close_by','approved_by','rejected_by').order_by(*order_by.split(',')).annotate(
            created_by_user_full_name=Concat(F('created_by__first_name'), Value(' '), F('created_by__last_name'), output_field=CharField()),
            checked_by_user_full_name=Concat(F('checked_by__first_name'), Value(' '), F('checked_by__last_name'), output_field=CharField()),
            approved_by_user_full_name=Concat(F('approved_by__first_name'), Value(' '), F('approved_by__last_name'), output_field=CharField()),
            rejected_by_user_full_name=Concat(F('rejected_by__first_name'), Value(' '), F('rejected_by__last_name'), output_field=CharField()),
            cancelled_by_user_full_name=Concat(F('cancelled_by__first_name'), Value(' '), F('cancelled_by__last_name'), output_field=CharField()),
            close_by_user_full_name=Concat(F('close_by__first_name'), Value(' '), F('close_by__last_name'), output_field=CharField()),
            # project_code=Subquery(
            #     ProjectData.cmobjects.filter(
            #         project_id=OuterRef('project_id'),
            #         form__form_internal_name='project_id'
            #     ).values('project').annotate(value=GroupConcat('value')).values('value')
            # ),
            project_code=F('project__project_code'),
            # is_pnm_budgeted=Exists(
            #     PlantMachineryCSTItems.cmobjects.filter(
            #         plant_machinery_cst_id=OuterRef('pk'),
            #         plant_machinery_group__in=PlantMachineryMachineBudget.cmobjects.filter(
            #             project_id=OuterRef('plant_machinery_cst__project_id'),
            #             budget_master__is_deleted=False,
            #             budget_master__latest=True
            #         ).values('plant_machinery_group_id')
            #     )
            # ),
            
        )
        annotations = {}
        values_fields = [
            'id', 'organization_id', 'request_code', 'site','site__site_name','store', 'project', 'version',
            'date', 'title', 'scope_of_supply', 'is_budgeted', 'is_repeat_order',
            'status', 'current_stage', 'latest', 'plant_machinery_rfq_vendor',
            'created_by_user_full_name', 'checked_by_user_full_name',
            'approved_by_user_full_name', 'rejected_by_user_full_name',
            'cancelled_by_user_full_name', 'close_by_user_full_name',
            'current_status','project_code','remarks',
            'created_at','checked_by_date','cancelled_by_date','close_by_date','approved_by_date','rejected_by_date',
            'required_duration'
        ]
        approval_applicable_list = []
        already_approved_list = []
        has_permission = UserWiseModulePermissions.cmobjects.filter(
            user_id=request.user.id,
            module_item__unique_id__in=['procurement-pnmcst-checker'],
            level_permission=True,
        ).exists()
        if has_permission:
            approval_applicable_list.append(When(Q(current_stage__in=[0],status='pending'), then=Value(True)))
            already_approved_list.append(When(Q(current_stage__in=[0],status='checked'), then=Value(True)))
        
        # annotations['ref_ref_stage_type']=Case(
        #     When(Q(ref_stage_type__isnull=False), then=F('ref_stage_type_id')),
        #     default=Subquery(
        #         MultiStageSetting.cmobjects.filter(
        #             Q(site=OuterRef('site_id')),
        #             Q(from_name=Value('pnmcst'))
        #         ).values('pk')[:1],
        #     ),
        #     output_field=CharField()
        # )
        annotations['ref_ref_stage_type']=F('ref_stage_type_id')

        annotations['multi_stage_max_stage']=Subquery(
            MultiStageSettingStages.cmobjects.filter(
                Q(multi_stage_setting__is_deleted=False),
                Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
            ).order_by('-stage').values('stage')[:1]
        )

        annotations['current_status']=Case(
            When(status='pending', then=Value('Pending')),
            When(status='rejected', then=Value('Rejected')),
            When(status='cancelled', then=Value('Returned')),
            When(status='checked',current_stage=0, then=Value('Checked')),
            When(status__in=['checked','approved'], then=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(stage=OuterRef('current_stage')),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).values('stage_name')[:1],
            )),
            default=F('status'),
            output_field=CharField()
        )

        annotations['approval_applicable']=Case(
            *approval_applicable_list,
            When(Q(Q(status='checked'),Q(current_stage__in=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(employee=request.user.id),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).annotate(ref_stage=F('stage')-Value(1)).values('ref_stage'),
            ))), then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )

        annotations['already_approved']=Case(
            *already_approved_list,
            When(Q(Q(status__in=['checked','approved']),Q(current_stage__in=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(employee=request.user.id),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).annotate(ref_stage=F('stage')).values('ref_stage'),
            ))), then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )

        stage_data_subqueries = PlantMachineryCSTStages.cmobjects.filter(
            plant_machinery_cst=OuterRef(OuterRef('pk')),
            stage=OuterRef('stage')
        ).annotate(
            full_name=Concat(F('created_by__first_name'), Value(' '), F('created_by__last_name'))
        ).order_by('-pk')
        annotations['stage_details']=Subquery(
            MultiStageSettingStages.cmobjects.filter(
                Q(multi_stage_setting__is_deleted=False),
                Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
            ).values('multi_stage_setting').annotate(
                ref_stage_details=GroupConcat(Concat(
                    F('stage'),
                    Value('|'),
                    F('stage_name'),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('full_name')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('created_at')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('status')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('remarks')[:1], output_field=CharField()),
                ), distinct=True)
            ).values('ref_stage_details')
        )
        vendor_key_list = ['all_vendors','l1_vendors']
        for key in vendor_key_list:
            vendor_search = {
                'plant_machinery_quotation__plant_machinery_rfq_vendor_id': OuterRef('plant_machinery_rfq_vendor_id'),
                'plant_machinery_quotation__is_deleted': False,
                'plant_machinery_quotation__latest': True,
            }
            if key == 'l1_vendors':
                vendor_search['is_selected_by_cst'] = True
            annotations[key] = Subquery(
                PlantMachineryQuotationItems.cmobjects.filter(**vendor_search).values('plant_machinery_quotation__plant_machinery_rfq_vendor').annotate(value=GroupConcat('plant_machinery_quotation__vendor__vendor_name',distinct=True)).values('value')
            )
        annotations['total_item_quantity'] = Coalesce(
            Subquery(
                PlantMachineryCSTItems.cmobjects.filter(
                    plant_machinery_cst_id=OuterRef('pk')
                ).values('plant_machinery_cst_id')
                .annotate(total_qty=Coalesce(Sum('quantity'), Value(0)))
                .values('total_qty'),
                output_field=FloatField()
            ),
            Value(0.0),
            output_field=FloatField()
        )
        total_item_amount_key_list = ['total_item_amount_with_gst','total_item_amount']
        for key in total_item_amount_key_list:
            gst_part = Value(1.0)
            if key == 'total_item_amount_with_gst':
                gst_part += (
                        Coalesce(F('sgst_percentage'), Value(0.0)) +
                        Coalesce(F('cgst_percentage'), Value(0.0)) +
                        Coalesce(F('igst_percentage'), Value(0.0)) +
                        Coalesce(F('utgst_percentage'), Value(0.0))
                    ) / Value(100.0)
            annotations[key] = Coalesce(Sum(Subquery(PlantMachineryQuotationItems.cmobjects.filter(
                plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                plant_machinery_quotation__is_deleted=False,
                plant_machinery_quotation__latest=True,
                is_selected_by_cst=True,
                ).values('plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id').annotate(
                total_item_amount=Coalesce(Sum(Cast(
                    F('rate') * F('quantity_by_cst') *(Value(1.0) - (F('disc_percentage') / Value(100.0))) * gst_part,
                    output_field=FloatField()
                ),output_field=FloatField()),Value(0.0),output_field=FloatField())
                ).values('total_item_amount'),
                output_field=FloatField())),Value(0.0),output_field=FloatField()
            )
        total_expense_amount_key_list = ['total_expense_amount_with_gst','total_expense_amount']
        for key in total_expense_amount_key_list:
            annot = {}
            part_keys = {
                'packing_forwarding_by_cst': ["Packing & Forwarding"],
                'transportaion_charges_by_cst': ["Transportation Charges"],
                'other_charges_by_cst': ["Royalty Expenses", "Other Charges"],
            }
            for part_key,part_value in part_keys.items():
                gst_part = Value(1.0)
                if key == 'total_expense_amount_with_gst':
                    gst_part += Coalesce(Subquery(
                        PlantMachineryQuotationExpenseDetails.cmobjects.filter(
                            plant_machinery_quotation_id=OuterRef('pk'),
                            # plant_machinery_quotation__plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                            expense_head__name__in=part_value,
                        ).annotate(
                            total_tax=(
                                Coalesce(F('sgst_percentage'), Value(0.0)) +
                                Coalesce(F('cgst_percentage'), Value(0.0)) +
                                Coalesce(F('igst_percentage'), Value(0.0)) +
                                Coalesce(F('utgst_percentage'), Value(0.0))
                            )
                        ).values('total_tax')
                    ),Value(0.0)) / Value(100.0)
                
                annot['total_'+part_key] = Coalesce(Sum(Cast(
                    F(part_key) * gst_part,
                    output_field=FloatField()
                ),output_field=FloatField()),Value(0.0),output_field=FloatField())
                
            annotations[key] = Coalesce(Sum(Subquery(
                    PlantMachineryQuotation.cmobjects.filter(
                        plant_machinery_rfq_vendor_id=OuterRef('plant_machinery_rfq_vendor_id'),
                        latest=True,
                        pk__in=Subquery(
                            PlantMachineryQuotationItems.cmobjects.filter(
                                plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_id=OuterRef(OuterRef("plant_machinery_rfq_vendor_id")),
                                plant_machinery_quotation__is_deleted=False,
                                plant_machinery_quotation__latest=True,
                                is_selected_by_cst=True,
                            ).values_list('plant_machinery_quotation_id', flat=True)
                        )
                    ).values('plant_machinery_rfq_vendor_id')
                    .annotate(
                        **annot,
                        total_expense_sum=F('total_packing_forwarding_by_cst') +
                                        F('total_transportaion_charges_by_cst') +
                                        F('total_other_charges_by_cst')
                        # total_expense_sum=F('total_expense_expense_amount')
                    ).values('total_expense_sum'),
                    output_field=FloatField()
                )),Value(0.0),output_field=FloatField()
            )
        annotations['total_amount_with_gst'] = (F('total_item_amount_with_gst')*F('required_duration')) + (F('total_expense_amount_with_gst')*F('total_item_quantity'))
        annotations['total_amount'] = (F('total_item_amount')*F('required_duration')) + (F('total_expense_amount')*F('total_item_quantity'))

        values_fields.extend(annotations.keys())
        _list = _list.annotate(**annotations).filter(*search).values(*values_fields).distinct()
        if all == 'true':
            return Response({'results': list(_list)})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': list(page.object_list),
            },
        })

class PlantMachineryCSTAPIView(APIView):
    """
    CRUD API for Plant Machinery CST (Comparison Statement)
    """
    
    

    def get(self, request):
        """
        Retrieve Plant machinery CST details 
        """
        check_editor_permissions(request, "pnmcst")
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        all_pending_by_user = self.request.query_params.get('all_pending_by_user', None)
       
        ###########    
        if id:
            cst_details = PlantMachineryCST.cmobjects.filter(id=id).first()
            serializer = PlantMachineryCSTSerializer(cst_details)
            return Response(serializer.data)
       
        search = check_store_site(request)
        search = custom_filters(self.request, search, ['all_pending_by_user',])
     
        if all_pending_by_user:
            try:
                site_map = json.loads(all_pending_by_user)
                search.extend([~Q(status__icontains='approved'),Q(status__icontains='checked')])
                search_processed = []
                for site_id,value in site_map.items():
                    search_processed.append(Q(Q(site_id=site_id) & Q(current_stage__in=value)))
                search.append(reduce(operator.or_,search_processed))
            except Exception as e:
                print(e)
                print(all_pending_by_user)
            
        _list = PlantMachineryCST.cmobjects.select_related(
            'organization', 'site', 'store', 'project', 'financialyear',
            'checked_by', 'cancelled_by', 'close_by', 'approved_by', 'rejected_by'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryCSTSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryCSTSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new CST
        """
        check_editor_permissions(request, "pnmcst")
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryCSTSerializer(data=request.data,context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit or delete a CST
        """
        check_editor_permissions(request, "pnmcst")

        # current_user = PmsUser.objects.filter(pk=request.user.id).first()
        # check_editor_permissions(request, "po")
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        cst_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a CST
                """
                if PlantMachineryCST.cmobjects.filter(pk=cst_id, organization_id=organization_id).exists():
                    cst = PlantMachineryCST.cmobjects.filter(pk=cst_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryCSTSerializer(cst, data=request.data,partial=True, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully updated.',
                                'status': status.HTTP_202_ACCEPTED,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})

            elif method.lower() == 'delete':
                """
                Delete a CST
                """
                if PlantMachineryCST.cmobjects.filter(pk=cst_id, organization_id=organization_id).exists():
                    cst_details = PlantMachineryCST.cmobjects.filter(pk=cst_id, organization_id=organization_id).first()
                    cst_details.is_deleted = True
                    cst_details.updated_by = request.user
                    cst_details.save()

                    return Response({'results': {
                        'Data': PlantMachineryCST.objects.filter(pk=cst_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted.',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support.."})


class PlantMachineryWorkOrderMainAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get("all", None)
        order_by = request.query_params.get('order_by', '-id')
        search = check_store_site(request)
        search = custom_filters(request, search, [])

        data = PlantMachineryWorkOrder.cmobjects.select_related(
            "organization", "site", "store", "project", "billing_site", "billing_state",
            "delivery_site", "delivery_state", "job_site", "vendor", "vendor_state",
            "quotation_by", "financialyear", "asset_requisition",
            "plant_machinery_rfq_vendor", "plant_machinery_cst", "plant_machinery_quotation"
        ).prefetch_related(
            "plant_machinery_work_order_plant_machinery_work_order_items",
            "plant_machinery_work_order_plant_machinery_work_order_attachments",
            "plant_machinery_work_order_plant_machinery_work_order_delivery_location",
            "plant_machinery_work_order_plant_machinery_work_order_payment_schedule",
            "plant_machinery_work_order_plant_machinery_work_order_payment_schedule",
            "plant_machinery_work_order_plant_machinery_work_order_terms_and_conditions"
        ).annotate(
            asset_requisition__request_code= Subquery(
                PlantMachineryAssetRequisition.cmobjects.filter(
                    asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_work_order_items__plant_machinery_work_order_id=OuterRef('pk'),
                    ).exclude(status__in=['rejected','cancelled']).values('asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_work_order_items__plant_machinery_work_order').annotate(
                        value=GroupConcat('request_code', distinct=True)
                    ).values('value')
            ),
            asset_requisition__date= Subquery(
                PlantMachineryAssetRequisition.cmobjects.filter(
                    asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_work_order_items__plant_machinery_work_order_id=OuterRef('pk'),
                    ).exclude(status__in=['rejected','cancelled']).values('asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_work_order_items__plant_machinery_work_order').annotate(
                        value=GroupConcat('date', distinct=True)
                    ).values('value')
            ),
            quotation__request_code = Subquery(
                PlantMachineryQuotation.cmobjects.filter(
                    plant_machinery_quotation_plant_machinery_quotation_items__plant_machinery_quotation_item_plant_machinery_work_order_items__plant_machinery_work_order_id=OuterRef('pk'),
                    ).exclude(status__in=['rejected','cancelled']).values('plant_machinery_quotation_plant_machinery_quotation_items__plant_machinery_quotation_item_plant_machinery_work_order_items__plant_machinery_work_order').annotate(
                        value=GroupConcat('request_code', distinct=True)
                    ).values('value')
            ),
            quotation__date = Subquery(
                PlantMachineryQuotation.cmobjects.filter(
                    plant_machinery_quotation_plant_machinery_quotation_items__plant_machinery_quotation_item_plant_machinery_work_order_items__plant_machinery_work_order_id=OuterRef('pk'),
                    ).exclude(status__in=['rejected','cancelled']).values('plant_machinery_quotation_plant_machinery_quotation_items__plant_machinery_quotation_item_plant_machinery_work_order_items__plant_machinery_work_order').annotate(
                        value=GroupConcat('date', distinct=True)
                    ).values('value')
            ),

            wo_doc_list=Subquery(
                PlantMachineryWorkOrderAttachments.cmobjects.filter(
                    plant_machinery_work_order_id=OuterRef("pk")
                ).values("plant_machinery_work_order").annotate(
                    value=GroupConcat(
                        Concat("attachment_name", Value(":"), "attachment", output_field=CharField()),
                        distinct=True
                    )
                ).values("value")
            ),
            latest_version=Subquery(
                PlantMachineryWorkOrder.cmobjects.filter(
                    request_code=OuterRef("request_code")
                ).values("request_code").annotate(value=Max("version")).values("value")
            )
        ).filter(*search).values(
            "id", "wo_doc_list", "billing_site__site_name", "delivery_site__site_name",
            "job_site__site_name", "asset_requisition__request_code", "asset_requisition__date",
            "request_code", "version", "latest_version", "date", "delivery_days",
            "quotation__request_code", "quotation__date", "vendor__vendor_name", "vendor_id",
            "status", "tax_type", "total_item_item_quantity", "total_item_item_amount",
            "total_item_disc_amount", "total_item_sgst_amount", "total_item_igst_amount",
            "total_item_cgst_amount", "total_item_utgst_amount", "total_expense_total_expense_amount",
            "total_tax_total_tax_amount", "total_amount", "scope_of_supply",
        ).order_by(*str(order_by).split(","))

        if all == "true":
            return Response({"results": data})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(data, page_size)
        page_number = request.query_params.get("page", 1)
        page = paginator.get_page(page_number)

        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": {
                "Data": page.object_list,
            },
        })
class PlantMachineryWorkOrderAPIView(APIView):
    """
    CRUD API for Plant Machinery Work Order model
    """
    
    

    def get_permissions(self):
        if self.request.method == 'POST':
            return [AllowAny()]
        return [IsAuthenticated()]

    def get(self, request):
        """
        Get a list of all work order
        """
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        if id:
            _details = PlantMachineryWorkOrder.cmobjects.filter(id=id).first()
            serializer = PlantMachineryWorkOrderSerializer(_details)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])

        _list = PlantMachineryWorkOrder.cmobjects.select_related('vendor').prefetch_related(
            'plant_machinery_work_order_plant_machinery_work_order_items',  'plant_machinery_work_order_plant_machinery_work_order_terms_and_conditions'
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == 'true':
            serializer = PlantMachineryWorkOrderSerializer(_list, many=True)
            # rfq_vendor_id = request.query_params.get('plant_machinery_rfq_vendor', None)
            # rfq_vendor_details = None
            # if rfq_vendor_id:
            #     rfq_vendor = PlantMachineryRFQVendors.cmobjects.get(pk=rfq_vendor_id)
            #     if rfq_vendor:
            #         try:
            #             _s1 = PlantMachineryRFQVendorsSerializer(rfq_vendor)
            #             rfq_vendor_details = _s1.data
            #         except Exception as e:
            #             print('ERROR', e)
                  
            # custom_data = {'plant_machinery_rfq_vendor_details': rfq_vendor_details, }

            return Response({'results': serializer.data,})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryWorkOrderSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new work_order
        """
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryWorkOrderSerializer(data=request.data)
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                print(f"ERROR {e}")
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': f'Successfully created.',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a work_order
        """
        # check_editor_permissions(request, "pnmwo")
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get(
            'organization_id', None)
        id = request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Plant Machinery WorkOrder
                """
                if PlantMachineryWorkOrder.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = PlantMachineryWorkOrder.cmobjects.filter(pk=id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryWorkOrderSerializer(_details, data=request.data)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response(
                            {'results': {
                                'Data': serializer.data,
                            },
                                'msg': 'Successfully Updated.',
                                'status': status.HTTP_200_OK,
                                "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Plant Machinery WorkOrder
                """
                if PlantMachineryWorkOrder.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = PlantMachineryWorkOrder.cmobjects.filter(
                        pk=id, organization_id=organization_id).first()
                    _details.is_deleted = True
                    _details.updated_by_id = request.user.id
                    _details.save()

                    return Response({'results': {
                        'site': PlantMachineryWorkOrder.objects.filter(pk=id,
                                                         organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class PlantMachineryDashboardCountAPIView(APIView):
    
    

    def get(self, request):
        default_type = 'pnmar,pnmcst,ro,pnmhbi,pnmhsda'
        type = self.request.query_params.get('type', default_type)
        type_list = str(type).split(',')
        search = check_store_site(request)
        site_id = search['site__in'] if 'site__in' in search else []
        search = custom_filters(self.request, search, ['type'])
        data_list = {}
        resp = {}
        if 'pnmar' in type_list:
            data_list['pnmar'] = PlantMachineryAssetRequisitionItem.cmobjects.select_related('asset_requisition').annotate(
                    sanctioned_status=F('asset_requisition__status'),
                    current_stage=F('asset_requisition__current_stage'),
                    site=F('asset_requisition__site'),
                    store=F('asset_requisition__store'),
                    project=F('asset_requisition__project'),
                    date=F('asset_requisition__date'),
                    # ref_ref_stage_type=Case(
                    #     When(Q(asset_requisition__ref_stage_type__isnull=False), then=F('asset_requisition__ref_stage_type_id')),
                    #     default=Subquery(
                    #         MultiStageSetting.cmobjects.filter(
                    #             Q(site=OuterRef('asset_requisition__site_id')),
                    #             Q(from_name=Value('pnmar'))
                    #         ).values('pk')[:1],
                    #     ),
                    #     output_field=CharField()
                    # ),
                    ref_ref_stage_type=F('asset_requisition__ref_stage_type_id'),
                    sanctioned_stage = Subquery(
                        MultiStageSettingStages.cmobjects.filter(
                            Q(multi_stage_setting__site=OuterRef('asset_requisition__site_id')),
                            Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type')),
                            Q(stage=OuterRef('current_stage')),
                        ).values('stage_name')[:1],
                    ),
                ).filter(asset_requisition__latest=True,asset_requisition__is_deleted=False)
        
        if 'pnmcst' in type_list or 'ro' in type_list:
            cst_data_list = PlantMachineryCST.cmobjects.annotate(
                sanctioned_status = F('status'),
                # ref_ref_stage_type=Case(
                #     When(Q(ref_stage_type__isnull=False), then=F('ref_stage_type_id')),
                #     default=Subquery(
                #         MultiStageSetting.cmobjects.filter(
                #             Q(site=OuterRef('site_id')),
                #             Q(from_name=Value('pnmcst'))
                #         ).values('pk')[:1],
                #     ),
                #     output_field=CharField()
                # ),
                ref_ref_stage_type=F('ref_stage_type_id'),
                sanctioned_stage = Subquery(
                    MultiStageSettingStages.cmobjects.filter(
                        Q(multi_stage_setting__site=OuterRef('site_id')),
                        Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type')),
                        Q(stage=OuterRef('current_stage')),
                    ).values('stage_name')[:1],
                ),
            )

        if 'pnmcst' in  type_list:
            data_list['pnmcst'] = cst_data_list.filter(is_repeat_order=False,latest=True)
        if 'ro' in  type_list:
            data_list['ro'] = cst_data_list.filter(is_repeat_order=True,latest=True)
        if 'pnmhbi' in  type_list:
            data_list['pnmhbi'] = PlantMachineryHireBillInvoice.cmobjects.annotate(
                sanctioned_status = F('status'),
                # ref_ref_stage_type=Case(
                #     When(Q(ref_stage_type__isnull=False), then=F('ref_stage_type_id')),
                #     default=Subquery(
                #         MultiStageSetting.cmobjects.filter(
                #             Q(site=OuterRef('site_id')),
                #             Q(from_name=Value('pnmhbi'))
                #         ).values('pk')[:1],
                #     ),
                #     output_field=CharField()
                # ),
                ref_ref_stage_type=F('ref_stage_type_id'),
                sanctioned_stage = Subquery(
                    MultiStageSettingStages.cmobjects.filter(
                        Q(multi_stage_setting__site=OuterRef('site_id')),
                        Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type')),
                        Q(stage=OuterRef('current_stage')),
                    ).values('stage_name')[:1],
                ),
            ).filter(latest=True)
        
        if 'pnmhsda' in  type_list:
            data_list['pnmhsda'] = PlantMachineryHSDApproval.cmobjects.annotate(
                sanctioned_status = F('status'),
                # ref_ref_stage_type=Case(
                #     When(Q(ref_stage_type__isnull=False), then=F('ref_stage_type_id')),
                #     default=Subquery(
                #         MultiStageSetting.cmobjects.filter(
                #             Q(site=OuterRef('site_id')),
                #             Q(from_name=Value('pnmhbi'))
                #         ).values('pk')[:1],
                #     ),
                #     output_field=CharField()
                # ),
                ref_ref_stage_type=F('ref_stage_type_id'),
                sanctioned_stage = Subquery(
                    MultiStageSettingStages.cmobjects.filter(
                        Q(multi_stage_setting__site=OuterRef('site_id')),
                        Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type')),
                        Q(stage=OuterRef('current_stage')),
                    ).values('stage_name')[:1],
                ),
            ).filter(latest=True)
        multi_stage_details = {}
        multi_stage_list = {}
        if 'pnmcst' in type_list or 'ro' in type_list:
            multi_stage_list['pnmcst'] = ['pnmcst']
        if 'pnmar' in type_list:
            multi_stage_list['pnmar'] = ['pnmar']
        if 'pnmhbi' in type_list:
            multi_stage_list['pnmhbi'] = ['pnmhbi']
        if 'pnmhsda' in type_list:
            multi_stage_list['pnmhsda'] = ['pnmhsda']
        for multi_stage_key, multi_stage_value in multi_stage_list.items():
            multi_stage_filters = {
                'from_name__in': multi_stage_value,
                'procurement_multi_stage_setting_stages__is_deleted': False,
                'is_archived': False,
            }
            site_id_val = self.request.query_params.get('site', None)
            if site_id_val:
                site_id = [site_id_val]
            organization_id = self.request.query_params.get('organization_id', None)
            if site_id:
                multi_stage_filters['site__in'] = site_id
            if organization_id:
                multi_stage_filters['organization'] = organization_id
            multi_stage_details[multi_stage_key] = MultiStageSetting.cmobjects.filter(**multi_stage_filters).order_by('procurement_multi_stage_setting_stages__stage').values('procurement_multi_stage_setting_stages__stage','procurement_multi_stage_setting_stages__stage_name','procurement_multi_stage_setting_stages__ref_stage_name',)
        for key, value in data_list.items():
            permission = 'pnmcst' if key in ['ro'] else key.replace('-items','')
            flag = 0
            try:
                check_editor_permissions(request, permission)
                flag = 1
            except Exception as e:
                print(e)
            if flag:
                value = value.filter(*search)

                agg_data = {
                    'total': Count('id',),
                    'pending': Count(
                        'id',filter=Q(
                            Q(sanctioned_status__icontains='pending'),
                        ),
                    ),
                    'checked': Count(
                        'id',filter=Q(
                            Q(sanctioned_status__icontains='checked'),
                            ~Q(Q(sanctioned_status__icontains='pending')),
                        ),
                    ),
                    'approved': Count(
                        'id',filter=Q(
                            Q(sanctioned_status__icontains='approved'),
                            ~Q(Q(sanctioned_status__icontains='pending')|Q(sanctioned_status__icontains='checked')),
                        ),
                    ),
                    'rejected': Count(
                        'id',filter=Q(
                            Q(sanctioned_status__icontains='rejected'),
                            ~Q(Q(sanctioned_status__icontains='pending')|Q(sanctioned_status__icontains='checked')|Q(sanctioned_status__icontains='approved')),
                        ),
                    ),
                    'cancelled': Count(
                        'id',filter=Q(
                            Q(sanctioned_status__icontains='cancelled'),
                            ~Q(Q(sanctioned_status__icontains='pending')|Q(sanctioned_status__icontains='checked')|Q(sanctioned_status__icontains='approved')|Q(sanctioned_status__icontains='rejected')),
                        ),
                    ),
                }
                if key in ['pnmcst','ro','pnmar','pnmhbi','pnmhsda']:
                    begin_status = 'pending'
                    ref_multi_stage_details = key
                    if key in ['pnmcst','ro','pnmar','pnmhsda']:
                        if key in ['pnmcst','ro']:
                            ref_multi_stage_details = 'pnmcst'
                        begin_status = 'checked'
                        agg_data['checked'] = Count(
                            'id',filter=Q(
                                Q(sanctioned_status__icontains='checked'),
                                Q(current_stage=0),
                                ~Q(sanctioned_status__icontains='pending'),
                            ),
                        )
                    for multi_stage_detail in multi_stage_details[ref_multi_stage_details]:
                        agg_data['stage_name_'+str(multi_stage_detail['procurement_multi_stage_setting_stages__stage_name'])] = Count(
                            'id',filter=Q(
                                Q(sanctioned_status__in=[begin_status,'approved']),
                                Q(sanctioned_stage=multi_stage_detail['procurement_multi_stage_setting_stages__stage_name']),
                            ),
                        )
                        agg_data['stage_name_details_'+str(multi_stage_detail['procurement_multi_stage_setting_stages__stage_name'])] = GroupConcat(Value(str(multi_stage_detail['procurement_multi_stage_setting_stages__ref_stage_name'])), distinct=True)
                        agg_data['stage_name_serial_'+str(multi_stage_detail['procurement_multi_stage_setting_stages__stage_name'])] = GroupConcat(Value(str(multi_stage_detail['procurement_multi_stage_setting_stages__stage'])), distinct=True)
                    agg_data['pending'] = Count(
                        'id',filter=Q(
                            Q(sanctioned_status__icontains='pending'),
                            Q(current_stage=0),
                        ),
                    )
                resp[key] = value.aggregate(**agg_data)
     
        return Response(resp)


class PlantMachineryDashboardCountSiteWiseAPIView(APIView):
    
    

    def get(self, request):
        _type = self.request.query_params.get('type', 'pnmcst')
        check_editor_permissions(request, _type)
        resp, site_list = {}, []
        search = check_store_site(request)
        if 'site__in' in search:
            site_list = search['site__in']
        search = custom_filters(self.request, search, ['type'])

        TYPE_CONFIG = {
            "pnmcst": {
                "model": PlantMachineryCST,
                "prefix": "",
                "status_field": "status",
                "stage_field": "current_stage",
                "begin_status": "checked",
            },
            "pnmar": {
                "model": PlantMachineryAssetRequisitionItem,
                "prefix": "asset_requisition__",
                "status_field": "asset_requisition__status",
                "stage_field": "asset_requisition__current_stage",
                "begin_status": "checked",
            },
            "pnmhbi": {
                "model": PlantMachineryHireBillInvoice,
                "prefix": "",
                "status_field": "status",
                "stage_field": "current_stage",
                "begin_status": "pending",
            },
            "pnmhsda": {
                "model": PlantMachineryHSDApproval,
                "prefix": "",
                "status_field": "status",
                "stage_field": "current_stage",
                "begin_status": "checked",
            },
        }

        cfg = TYPE_CONFIG[_type]
        if cfg["prefix"] != "":
            for condition in search:
                condition.children = [
                    (f"{cfg['prefix']}{f}" if f != "id" else f, v)
                    for f, v in condition.children
                ]
        approval_applicable_list = []
        already_approved_list = []
        if cfg['begin_status'] == 'checked':
            has_permission = UserWiseModulePermissions.cmobjects.filter(
                user_id=request.user.id,
                module_item__unique_id__in=[f'procurement-{_type}-checker'],
                level_permission=True,
            ).exists()
            if has_permission:
                approval_applicable_list.append(When(Q(ref_current_stage__in=[0],ref_status='pending'), then=Value(True)))
                already_approved_list.append(When(Q(ref_current_stage__in=[0],ref_status='checked'), then=Value(True)))

        for site_id in site_list:
            data_list = cfg["model"].cmobjects.filter(
                *search,
                **{f"{cfg['prefix']}site_id": site_id}
            ).annotate(
                ref_ref_stage_type=F(f'{cfg['prefix']}ref_stage_type_id'),
                ref_status=F(f'{cfg['prefix']}status'),
                ref_current_stage=F(f'{cfg['prefix']}current_stage'),
                approval_applicable=Case(
                    *approval_applicable_list,
                    When(Q(Q(ref_status=cfg["begin_status"]),Q(ref_current_stage__in=Subquery(
                        MultiStageSettingStages.cmobjects.filter(
                            Q(multi_stage_setting__is_deleted=False),
                            Q(employee=request.user.id),
                            Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                        ).annotate(ref_stage=F('stage')-Value(1)).values('ref_stage'),
                    ))), then=Value(True)),
                    default=Value(False),
                    output_field=BooleanField()
                ),
                already_approved=Case(
                    *already_approved_list,
                    When(Q(Q(ref_status__in=[cfg["begin_status"],'approved']),Q(ref_current_stage__in=Subquery(
                        MultiStageSettingStages.cmobjects.filter(
                            Q(multi_stage_setting__is_deleted=False),
                            Q(employee=request.user.id),
                            Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                        ).annotate(ref_stage=F('stage')).values('ref_stage'),
                    ))), then=Value(True)),
                    default=Value(False),
                    output_field=BooleanField()
                ),
            )

            resp[site_id] = {
                'details': SiteMaster.cmobjects.filter(pk=site_id).values(),
                'total': data_list.count(),
                'pending': data_list.filter(approval_applicable=True).count(),
                'approved': data_list.filter(already_approved=True).count(),
            }
        return Response(resp) 
class PlantMachineryRMReportAPIView(APIView):
    """
    R&M Cost report with grouping by plant machinery group.
    """
    
    

    def get(self, request):
        try:
            group_by = request.query_params.get('group_by', 'plant_machinery_group_id')
            date_type = request.query_params.get('date_type', '%Y-%m-%d')
            start_date = request.query_params.get('log_book_date__gte',None)
            end_date = request.query_params.get('log_book_date__lte', None)
            project = request.query_params.get('project', None)
            values = [
                'plant_machinery_machine__plant_machinery_group__name',
                'plant_machinery_machine__plant_machinery_group',
                'plant_machinery_machine__plant_machinery_group__r_and_m_norms',
                'plant_machinery_machine__plant_machinery_group__uom__symbol',
            ]
            if group_by == 'formatted_date':
                values = [
                    'formatted_date',
                ]
            search = {
                'plant_machinery_machine__plant_machinery_group__machine_type__in': 'machine,vehicle',
                'plant_machinery_machine__plant_machinery_group__is_deleted': 'false',
            }    
            search = custom_filters(request,search, ['date_type','group_by',])
           
            repair_filter_list = {}
            repair_group_by_list = []
            if start_date:
                repair_filter_list['date__gte'] = start_date
            if end_date:
                repair_filter_list['date__lte'] = end_date
            if project:
                repair_filter_list['project'] = project    
            if group_by == 'plant_machinery_group_id':
                repair_filter_list['plant_machinery_machine__plant_machinery_group_id'] = OuterRef('plant_machinery_machine__plant_machinery_group_id')
                repair_group_by_list.append('plant_machinery_machine__plant_machinery_group_id')
            else:
                repair_filter_list['repair_formatted_date'] = OuterRef('formatted_date')
                repair_group_by_list.append('repair_formatted_date')                  
            
            aggregated = PlantMachineryLogBook.cmobjects.filter(
                *search,
            ).annotate(
                formatted_date=Func(
                    F('log_book_date'),
                    Value(date_type),
                    function='DATE_FORMAT',
                    output_field=CharField()
                )
            ).values(*values).annotate(
                actual_cost=Coalesce(
                    Subquery(
                        PlantMachineryRepair.cmobjects
                        .annotate(
                            repair_formatted_date=Func(
                                F('date'),
                                Value(date_type),
                                function='DATE_FORMAT',
                                output_field=CharField()
                            )
                        )
                        .filter(**repair_filter_list)
                        .values(*repair_group_by_list,)
                        .annotate(total_value=Coalesce(Sum('total'), Value(0), output_field=FloatField()))
                        .values('total_value')[:1]
                    ),
                    Value(0),
                    output_field=FloatField(),
                ),
                monthly_running=Sum(
                    Case(
                        When(plant_machinery_machine__plant_machinery_group__machine_type='machine', then='total_working_hrs'),
                        When(plant_machinery_machine__plant_machinery_group__machine_type='vehicle', then='total_km_run'),
                        default=Value(0),
                        output_field=FloatField()
                    )
                ),
                budget_cost=Sum(
                    Case(
                        When(plant_machinery_machine__plant_machinery_group__machine_type='machine', then=F('plant_machinery_machine__plant_machinery_group__r_and_m_norms')*F('total_working_hrs')),
                        When(plant_machinery_machine__plant_machinery_group__machine_type='vehicle', then=F('plant_machinery_machine__plant_machinery_group__r_and_m_norms')*F('total_km_run')),
                        default=Value(0),
                        output_field=FloatField()
                    )
                ),
            ).distinct()
            
            return Response({
                'results': {'Data': list(aggregated)},
                'request_status': 1
            })
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})     

class PlantMachineryManpowerDesignationAPIView(APIView):
    """
    PlantMachineryManpowerDesignation.
    """
    
    

    def get(self, request):
        try:
            search = custom_filters(request, {}, [])
            _list = PlantMachineryManpowerDesignation.cmobjects.filter(*search).values_list('name',flat=True)
     
            return Response(list(_list))
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})      
        
class PlantMachineryMajorActivityAPIView(APIView):
    """
    CRUD API for PlantMachineryMajorActivity
    """
    
    

    def get(self, request):
        try:
            all = request.query_params.get('all', None)
            cummulative = request.query_params.get('cummulative', None)
            order_by = request.query_params.get('order_by', '-id')
            achieved_filter = request.query_params.get('achieved_filter', '{}')
            search = {}
            search = custom_filters(request, search, ['cummulative','achieved_filter'])
            _list = PlantMachineryMajorActivity.cmobjects.filter(*search)\
                .annotate(
                    plant_machinery_major_activity__achieved=Coalesce(
                        Subquery(
                            PlantMachineryMajorActivityAchieved.cmobjects.filter(
                                plant_machinery_major_activity=OuterRef('pk'),
                                *process_filters_response(json.loads(achieved_filter)))
                            .values('plant_machinery_major_activity')
                            .annotate(total=Sum('achieved'))
                            .values('total')
                        ),
                        Value(0),
                        output_field=FloatField(),
                    ),
                
                ).values(
                    'id','project_id','project__project_name','project__project_code',
                    'major_activity','uom_id','uom__symbol','budget_master_id','budget_master__name',
                    'project_planning','is_production',
                    'plant_machinery_major_activity__achieved',
                    'plant_machinery_group_id',
                    'plant_machinery_group__name'
                ).order_by(*str(order_by).split(",")).distinct()
            
            if cummulative == 'true':
                _list = _list.aggregate(
                    cumulative_project_planning=Coalesce(Sum('project_planning'), Value(0.0), output_field=FloatField()),
                    cumulative_achieved=Coalesce(Sum('plant_machinery_major_activity__achieved'), Value(0.0), output_field=FloatField())
                )
                
            if all == 'true':
                return Response({
                'results':_list,
                })

            page_size = int(request.query_params.get('page_size',settings.MIN_PAGE_SIZE))
            paginator = Paginator(_list, page_size)
            page_number = request.query_params.get('page', 1)
            page = paginator.get_page(page_number)

            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': page.object_list,

            })
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})   
          
    def post(self, request):
        request.data["created_by"] = request.user.id
        serializer = PlantMachineryMajorActivitySerializer(data=request.data, context={"request": request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({"request_status": 0, "msg": str(e)})

            return Response(
                {"results": {"Data": serializer.data},
                 "msg": "Successfully created.",
                 "status": status.HTTP_201_CREATED,
                 "request_status": 1}
            )
        raise APIException({"request_status": 0, "msg": serializer.errors})

    def put(self, request):
        method = request.query_params.get("method", "").lower()
        id = request.query_params.get("id", None)

        with transaction.atomic():
            details = PlantMachineryMajorActivity.cmobjects.filter(pk=id).first()
            if not details:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})

            if method == "edit":
                request.data["updated_by"] = request.user.id
                serializer = PlantMachineryMajorActivitySerializer(
                    details, data=request.data, partial=True, context={"request": request}
                )
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        raise APIException({"request_status": 0, "msg": str(e)})
                    return Response(
                        {"results": serializer.data,
                         "msg": "Successfully updated.",
                         "status": status.HTTP_202_ACCEPTED,
                         "request_status": 1}
                    )
                raise APIException({"request_status": 0, "msg": serializer.errors})

            elif method == "delete":
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()
                return Response({
                    "results": {"Data": PlantMachineryMajorActivity.objects.filter(pk=id).values()},
                    "msg": "Successfully deleted.",
                    "request_status": 1
                })

            else:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})


class PlantMachineryMajorActivityAchievedAPIView(APIView):
    """
    CRUD API for PlantMachineryMajorActivityAchieved
    """
    
    

    def get(self, request):
        id = request.query_params.get("id", None)
        all = request.query_params.get("all", None)
        order_by = request.query_params.get("order_by", "-id")

        if id:
            details = PlantMachineryMajorActivityAchieved.cmobjects.filter(id=id).first()
            serializer = PlantMachineryMajorActivityAchievedSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryMajorActivityAchieved.cmobjects.select_related(
           "plant_machinery_major_activity"
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == "true":
            serializer = PlantMachineryMajorActivityAchievedSerializer(_list, many=True)
            return Response({"results": serializer.data})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get("page", 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryMajorActivityAchievedSerializer(page, many=True)

        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": serializer.data,
        })

    def post(self, request):
        request.data["created_by"] = request.user.id
        serializer = PlantMachineryMajorActivityAchievedSerializer(data=request.data, context={"request": request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {"results": {"Data": serializer.data},
                 "msg": "Successfully created.",
                 "status": status.HTTP_201_CREATED,
                 "request_status": 1}
            )
        raise APIException({"request_status": 0, "msg": serializer.errors})

    def put(self, request):
        method = request.query_params.get("method", "").lower()
        id = request.query_params.get("id", None)

        with transaction.atomic():
            details = PlantMachineryMajorActivityAchieved.cmobjects.filter(pk=id).first()
            if not details:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})

            if method == "edit":
                request.data["updated_by"] = request.user.id
                serializer = PlantMachineryMajorActivityAchievedSerializer(
                    details, data=request.data, partial=True, context={"request": request}
                )
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})
                    return Response(
                        {"results": serializer.data,
                         "msg": "Successfully updated.",
                         "status": status.HTTP_202_ACCEPTED,
                         "request_status": 1}
                    )
                raise APIException({"request_status": 0, "msg": serializer.errors})

            elif method == "delete":
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()
                return Response({
                    "results": {"Data": PlantMachineryMajorActivityAchieved.objects.filter(pk=id).values()},
                    "msg": "Successfully deleted.",
                    "request_status": 1
                })

            else:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})       
            
class PlantMachineryUtilizationBudgetAPIView(APIView):
    """
    CRUD API for PlantMachineryUtilizationBudget
    """
    
    

    def get(self, request):
        id = request.query_params.get("id", None)
        all = request.query_params.get("all", None)
        order_by = request.query_params.get("order_by", "-id")

        if id:
            details = PlantMachineryUtilizationBudget.cmobjects.filter(id=id).first()
            serializer = PlantMachineryUtilizationBudgetSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryUtilizationBudget.cmobjects.select_related(
            "organization", "project", "plant_machinery_group", "budget_master"
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == "true":
            serializer = PlantMachineryUtilizationBudgetSerializer(_list, many=True)
            return Response({"results": serializer.data})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get("page", 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryUtilizationBudgetSerializer(page, many=True)

        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": serializer.data,
        })

    def post(self, request):
        request.data["created_by"] = request.user.id
        serializer = PlantMachineryUtilizationBudgetSerializer(
            data=request.data, context={"request": request}
        )
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {"results": {"Data": serializer.data},
                 "msg": "Successfully created.",
                 "status": status.HTTP_201_CREATED,
                 "request_status": 1}
            )
        raise APIException({"request_status": 0, "msg": serializer.errors})

    def put(self, request):
        method = request.query_params.get("method", "").lower()
        id = request.query_params.get("id", None)

        with transaction.atomic():
            details = PlantMachineryUtilizationBudget.cmobjects.filter(pk=id).first()
            if not details:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})

            if method == "edit":
                request.data["updated_by"] = request.user.id
                serializer = PlantMachineryUtilizationBudgetSerializer(
                    details, data=request.data, partial=True, context={"request": request}
                )
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})
                    return Response(
                        {"results": serializer.data,
                         "msg": "Successfully updated.",
                         "status": status.HTTP_202_ACCEPTED,
                         "request_status": 1}
                    )
                raise APIException({"request_status": 0, "msg": serializer.errors})

            elif method == "delete":
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()
                return Response({
                    "results": {"Data": PlantMachineryUtilizationBudget.objects.filter(pk=id).values()},
                    "msg": "Successfully deleted.",
                    "request_status": 1
                })

            else:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})
            
class PlantMachineryTaxInvoiceMainAPIView(APIView):
    
    

    def get(self, request):
        try:
            all = request.query_params.get('all', None)
            order_by = request.query_params.get('order_by', '-id')

            search = check_store_site(request)
            search = custom_filters(request, search, [])

            _list = PlantMachineryTaxInvoice.cmobjects.select_related(
                    'organization', 'project', 'site', 'store', 'plant_machinery_machine',
                    'plant_machinery_machine__vendor', 'tax_head',
                ).annotate(
                   
                    # monthly_rent=Coalesce(
                    #     Subquery(
                    #         PlantMachineryMachineRent.cmobjects.filter(
                    #             plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                    #             rent_date__gte=OuterRef('from_date'),
                    #             rent_date__lte=OuterRef('to_date')
                    #         )
                    #         .values('plant_machinery_machine_id')
                    #         .annotate(
                    #             total=Sum(
                    #                 Subquery(
                    #                     PlantMachineryMachineRent.cmobjects.filter(
                    #                         plant_machinery_machine_id=OuterRef(OuterRef('plant_machinery_machine_id')),
                    #                         rent_date=OuterRef('rent_date')
                    #                     )
                    #                     .values('rent_date')
                    #                     .annotate(daily_avg=Avg('rent_amount'))
                    #                     .values('daily_avg')
                    #                 )
                    #             )
                    #         )
                    #         .values('total'),
                    #         output_field=FloatField()
                    #     ),
                    #     Value(0.0),
                    #     output_field=FloatField()
                    # ),
                    log_book__total_fuel_filled=Coalesce(
                        Subquery(
                            PlantMachineryLogBook.cmobjects.filter(
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                log_book_date__gte=OuterRef('from_date'),
                                log_book_date__lte=OuterRef('to_date')
                            ).values('plant_machinery_machine').annotate(
                                total_fuel=Coalesce(Sum('total_fuel_filled'), Value(0.0))
                            ).values('total_fuel'),
                            output_field=FloatField()
                        ),
                        Value(0.0),
                        output_field=FloatField()
                    ),
                    log_book__total_hrs=Coalesce(
                        Subquery(
                            PlantMachineryLogBook.cmobjects.filter(
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                log_book_date__gte=OuterRef('from_date'),
                                log_book_date__lte=OuterRef('to_date')
                            ).annotate(
                                value=Case(
                                    When(plant_machinery_machine__plant_machinery_group__machine_type='machine', then=(F('close_hrs') - F('start_hrs'))),
                                    When(plant_machinery_machine__plant_machinery_group__machine_type='vehicle', then=(F('close_kms') - F('start_kms'))),
                                    default=Value(0),
                                    output_field=FloatField()
                                )
                            ).values('plant_machinery_machine').annotate(
                                total=Coalesce(Sum('value'), Value(0.0))
                            ).values('total'),
                            output_field=FloatField()
                        ),
                        Value(0.0),
                        output_field=FloatField()
                    ),
                    
                    monthly_rent=Coalesce(
                        Subquery(
                            PlantMachineryLogBook.cmobjects.filter(
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                log_book_date__gte=OuterRef('from_date'),
                                log_book_date__lte=OuterRef('to_date')
                            )
                            .values('plant_machinery_machine_id')
                            .annotate(
                                total=Sum(
                                    Subquery(
                                        PlantMachineryMachineRent.cmobjects.filter(
                                            plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                            rent_date__lte=OuterRef('log_book_date'),
                                            rent_to_date__gte=OuterRef('log_book_date'),
                                        )
                                        .values('rent_date')
                                        .annotate(daily_avg=Avg('rent_amount'))
                                        .values('daily_avg')
                                    )
                                )
                            )
                            .values('total'),
                            output_field=FloatField()
                        ),
                        Value(0.0),
                        output_field=FloatField()
                    ),
                    # no_of_days=Coalesce(
                    #     ExpressionWrapper(
                    #         Func(F('to_date'), F('from_date'), function='DATEDIFF') + Value(1),
                    #         output_field=FloatField()
                    #     ),
                    #     Value(0.0),
                    #     output_field=FloatField()
                    # ),
                    no_of_days=Coalesce(
                        ExpressionWrapper(
                            date_diff_handle(F('to_date'), F('from_date')) + Value(1),
                            output_field=FloatField()
                        ),
                        Value(0.0),
                        output_field=FloatField()
                    ),
                    log_book__total_running_days = Coalesce(
                        Subquery(
                            PlantMachineryLogBook.cmobjects.filter(
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                log_book_date__gte=OuterRef('from_date'),
                                log_book_date__lte=OuterRef('to_date'),
                            )
                            .annotate(
                                day_running=Case(
                                    When(in_service='Running', then=Value(1)),
                                    default=Value(0),
                                    output_field=IntegerField(),
                                )
                            )
                            .values('plant_machinery_machine_id')
                            .annotate(
                                total=Sum('day_running')
                            )
                            .values('total'),
                            output_field=IntegerField()
                        ),
                        Value(0),
                        output_field=IntegerField()
                    ),
                    log_book__total_breakdown_days = Coalesce(
                        Subquery(
                            PlantMachineryLogBook.cmobjects.filter(
                                plant_machinery_machine_id=OuterRef('plant_machinery_machine_id'),
                                log_book_date__gte=OuterRef('from_date'),
                                log_book_date__lte=OuterRef('to_date'),
                            )
                            .annotate(
                                day_running=Case(
                                    When(in_service='Breakdown', then=Value(1)),
                                    default=Value(0),
                                    output_field=IntegerField(),
                                )
                            )
                            .values('plant_machinery_machine_id')
                            .annotate(
                                total=Sum('day_running')
                            )
                            .values('total'),
                            output_field=IntegerField()
                        ),
                        Value(0),
                        output_field=IntegerField()
                    ),
                    
                    invoice_amount = Case(
                        When(
                            invoice_type='standard',
                            then=((F('monthly_rent') / F('no_of_days')) * F('log_book__total_running_days'))
                        ),
                        default=((F('monthly_rent') / 300) * F('log_book__total_hrs')),
                        output_field=FloatField()
                    ),
                    gst_percent_sum=(F('sgst_percentage') + F('cgst_percentage') + F('igst_percentage') + F('utgst_percentage')),
                    gst_amount=Coalesce(
                        ExpressionWrapper(
                            F('invoice_amount') * F('gst_percent_sum') / Value(100.0),
                            output_field=FloatField()
                        ),
                        Value(0.0),
                        output_field=FloatField()
                    ),
                    total_payable_amount=Coalesce(
                        ExpressionWrapper(
                            F('invoice_amount') + F('gst_amount'),
                            output_field=FloatField()
                        ),
                        Value(0.0),
                        output_field=FloatField()
                    ),
                    debitable_amount_value=Case(
                        When(
                            plant_machinery_machine__plant_machinery_group__machine_type='vehicle',
                            then=ExpressionWrapper(
                                ((F('log_book__total_hrs') / F('plant_machinery_machine__norms')) - F('actual_hsd_issue')) * F('hsd_rate'),
                                output_field=FloatField()
                            )
                        ),
                        When(
                            plant_machinery_machine__plant_machinery_group__machine_type='machine',
                            then=ExpressionWrapper(
                                ((F('log_book__total_hrs') * F('plant_machinery_machine__norms')) - F('actual_hsd_issue')) * F('hsd_rate'),
                                output_field=FloatField()
                            )
                        ),
                        default=Value(0.0),
                        output_field=FloatField()
                    ),
                    debitable_amount = Case(
                        When(debitable_amount_value__lt=0, then=F('debitable_amount_value')),
                        default=Value(0),
                        output_field=FloatField()
                    ),
                ).filter(*search).values(
                    'id', 'organization_id', 'request_code', 'project_id', 'project__project_name',
                    'site_id','store_id', 'from_date', 'to_date',
                    'plant_machinery_machine_id', 'plant_machinery_machine__equipment_description',
                    'plant_machinery_machine__machine_number',
                    'plant_machinery_machine__vendor_id', 'plant_machinery_machine__vendor__vendor_name', 'plant_machinery_machine__vendor__vendor_code',
                    'invoice_number', 'invoice_date', 'work_order_number', 'work_order_date',
                    'invoice_type','monthly_rent',
                    'tax_head_id','gst_percent_sum','gst_amount','total_payable_amount',
                    'invoice_amount','debitable_amount','debitable_amount_value',
                    'log_book__total_hrs','log_book__total_fuel_filled',
                    'sgst_percentage','cgst_percentage','igst_percentage','utgst_percentage',
                    'sgst_amount','cgst_amount','igst_amount','utgst_amount','log_book__total_running_days','log_book__total_breakdown_days',
                ).distinct().order_by(*order_by.split(','))
            
            if all == 'true':
                return Response({'results': list(_list)})

            page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
            paginator = Paginator(_list, page_size)
            page_number = request.query_params.get('page', 1)
            page = paginator.get_page(page_number)

            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': {'Data': list(page.object_list)},
            })

        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            raise APIException({'request_status': 0, 'msg': error_message})
        

class PlantMachineryTaxInvoiceAPIView(APIView):
    """
    CRUD API for PlantMachineryTaxInvoice
    """
    
    

    def get(self, request):
        check_editor_permissions(request, "pnmti")
        id = request.query_params.get("id", None)
        all = request.query_params.get("all", None)
        order_by = request.query_params.get("order_by", "-id")

        if id:
            details = PlantMachineryTaxInvoice.cmobjects.filter(id=id).first()
            serializer = PlantMachineryTaxInvoiceSerializer(details)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])
        _list = PlantMachineryTaxInvoice.cmobjects.select_related(
            "organization", "project", "site", "store", "plant_machinery_machine", "tax_head"
        ).filter(*search).order_by(*str(order_by).split(",")).distinct()

        if all == "true":
            serializer = PlantMachineryTaxInvoiceSerializer(_list, many=True)
            return Response({"results": serializer.data})

        page_size = int(request.query_params.get("page_size", settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get("page", 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryTaxInvoiceSerializer(page, many=True)

        return Response({
            "count": paginator.count,
            "next": page.next_page_number() if page.has_next() else None,
            "previous": page.previous_page_number() if page.has_previous() else None,
            "results": serializer.data,
        })

    def post(self, request):
        check_editor_permissions(request, "pnmti")
        request.data["created_by"] = request.user.id
        serializer = PlantMachineryTaxInvoiceSerializer(data=request.data, context={"request": request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response({
                "results": {"Data": serializer.data},
                "msg": "Successfully created.",
                "status": status.HTTP_201_CREATED,
                "request_status": 1
            })
        raise APIException({"request_status": 0, "msg": serializer.errors})

    def put(self, request):
        check_editor_permissions(request, "pnmti")
        method = request.query_params.get("method", "").lower()
        id = request.query_params.get("id", None)

        with transaction.atomic():
            details = PlantMachineryTaxInvoice.cmobjects.filter(pk=id).first()
            if not details:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})

            if method == "edit":
                request.data["updated_by"] = request.user.id
                serializer = PlantMachineryTaxInvoiceSerializer(details, data=request.data, partial=True, context={"request": request})
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})
                    return Response({
                        "results": serializer.data,
                        "msg": "Successfully updated.",
                        "status": status.HTTP_202_ACCEPTED,
                        "request_status": 1
                    })
                raise APIException({"request_status": 0, "msg": serializer.errors})

            elif method == "delete":
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()
                return Response({
                    "results": {"Data": PlantMachineryTaxInvoice.objects.filter(pk=id).values()},
                    "msg": "Successfully deleted.",
                    "request_status": 1
                })
            else:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})

class PlantMachineryHireBillInvoiceMainAPIView(APIView):
    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        all_pending_by_user = request.query_params.get('all_pending_by_user', None)

        search = check_store_site(request)
        search = custom_filters(request, search, ['all_pending_by_user'])

        if all_pending_by_user:
            try:
                site_map = json.loads(all_pending_by_user)
                search.extend([~Q(status__icontains='approved'), Q(status__icontains='checked')])
                search_processed = []
                for site_id, value in site_map.items():
                    search_processed.append(Q(site_id=site_id) & Q(current_stage__in=value))
                search.append(reduce(operator.or_, search_processed))
            except Exception as e:
                print("Error parsing all_pending_by_user:", e)

        _list = PlantMachineryHireBillInvoice.cmobjects.select_related(
            'organization','site','store','project',
            'checked_by','cancelled_by','close_by','approved_by','rejected_by'
        ).annotate(
            created_by_user_full_name=Concat(F('created_by__first_name'), Value(' '), F('created_by__last_name'), output_field=CharField()),
            checked_by_user_full_name=Concat(F('checked_by__first_name'), Value(' '), F('checked_by__last_name'), output_field=CharField()),
            approved_by_user_full_name=Concat(F('approved_by__first_name'), Value(' '), F('approved_by__last_name'), output_field=CharField()),
            rejected_by_user_full_name=Concat(F('rejected_by__first_name'), Value(' '), F('rejected_by__last_name'), output_field=CharField()),
            cancelled_by_user_full_name=Concat(F('cancelled_by__first_name'), Value(' '), F('cancelled_by__last_name'), output_field=CharField()),
            close_by_user_full_name=Concat(F('close_by__first_name'), Value(' '), F('close_by__last_name'), output_field=CharField()),
            invoice_amount=Coalesce(
                Subquery(
                    PlantMachineryHireBillInvoiceItem.cmobjects.filter(
                        plant_machinery_hire_bill_invoice_id=OuterRef('pk'),
                    ).values('plant_machinery_hire_bill_invoice').annotate(
                        value=Coalesce(Sum('invoice_amount'), Value(0.0))
                    ).values('value'),
                    output_field=FloatField()
                ),
                Value(0.0),
                output_field=FloatField()
            ),
            total_payable_amount=Coalesce(
                Subquery(
                    PlantMachineryHireBillInvoiceItem.cmobjects.filter(
                        plant_machinery_hire_bill_invoice_id=OuterRef('pk'),
                    ).values('plant_machinery_hire_bill_invoice').annotate(
                        value=Coalesce(Sum('total_payable_amount'), Value(0.0))
                    ).values('value'),
                    output_field=FloatField()
                ),
                Value(0.0),
                output_field=FloatField()
            ),
            debitable_amount=Coalesce(
                Subquery(
                    PlantMachineryHireBillInvoiceItem.cmobjects.filter(
                        plant_machinery_hire_bill_invoice_id=OuterRef('pk'),
                    ).values('plant_machinery_hire_bill_invoice').annotate(
                        value=Coalesce(Sum('debitable_amount'), Value(0.0))
                    ).values('value'),
                    output_field=FloatField()
                ),
                Value(0.0),
                output_field=FloatField()
            ),
            # gst_amount=Coalesce(
            #     Subquery(
            #         PlantMachineryHireBillInvoiceItem.cmobjects.filter(
            #             plant_machinery_hire_bill_invoice_id=OuterRef('pk'),
            #         ).values('plant_machinery_hire_bill_invoice').annotate(
            #             value=Coalesce(Sum(F('sgst_amount')+F('cgst_amount')+F('igst_amount')+F('utgst_amount')), Value(0.0))
            #         ).values('value'),
            #         output_field=FloatField()
            #     ),
            #     Value(0.0),
            #     output_field=FloatField()
            # ),
            gst_amount=Coalesce(
                Subquery(
                    PlantMachineryTaxInvoice.cmobjects.filter(
                        tax_invoice_plant_machinery_hire_bill_invoice_item__plant_machinery_hire_bill_invoice_id=OuterRef('pk')
                    ).values('tax_invoice_plant_machinery_hire_bill_invoice_item__plant_machinery_hire_bill_invoice')
                    .annotate(
                        value=Coalesce(
                            Sum(F('sgst_amount') + F('cgst_amount') + F('igst_amount') + F('utgst_amount')),
                            Value(0.0)
                        )
                    ).values('value'),
                    output_field=FloatField()
                ),
                Value(0.0),
                output_field=FloatField()
            ),
        )
        annotations = {}
        values_fields = [
            'id', 'organization_id', 'request_code','project_id','site_id','store_id','project__project_code',
            'from_date','to_date','status','current_stage','remarks','required_duration',
            'checked_by_date','approved_by_date','rejected_by_date','cancelled_by_date','close_by_date',
            'created_by_user_full_name','checked_by_user_full_name','approved_by_user_full_name',
            'rejected_by_user_full_name','cancelled_by_user_full_name','close_by_user_full_name',
            'invoice_amount','total_payable_amount','debitable_amount','gst_amount','latest','version'
        ]

        # annotations['ref_ref_stage_type']=Case(
        #     When(Q(ref_stage_type__isnull=False), then=F('ref_stage_type_id')),
        #     default=Subquery(
        #         MultiStageSetting.cmobjects.filter(
        #             Q(site=OuterRef('site_id')),
        #             Q(from_name=Value('pnmhbi'))
        #         ).values('pk')[:1],
        #     ),
        #     output_field=CharField()
        # )
        annotations['ref_ref_stage_type']=F('ref_stage_type_id')

        annotations['multi_stage_max_stage']=Subquery(
            MultiStageSettingStages.cmobjects.filter(
                Q(multi_stage_setting__is_deleted=False),
                Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
            ).order_by('-stage').values('stage')[:1]
        )

        annotations['current_status']=Case(
            When(status='rejected', then=Value('Rejected')),
            When(status='cancelled', then=Value('Returned')),
            When(status='pending',current_stage=0, then=Value('Pending')),
            When(status__in=['pending','approved'], then=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(stage=OuterRef('current_stage')),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).values('stage_name')[:1],
            )),
            default=F('status'),
            output_field=CharField()
        )

        already_approved_list = []
        has_permission = UserWiseModulePermissions.cmobjects.filter(
            user_id=request.user.id,
            module_item__unique_id__in=['procurement-pnmhbi-checker'],
            level_permission=True,
        ).exists()
        if has_permission:
            already_approved_list.append(When(Q(current_stage__in=[0],status='pending'), then=Value(True)))

        annotations['approval_applicable']=Case(
            When(Q(Q(status='pending'),Q(current_stage__in=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(employee=request.user.id),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).annotate(ref_stage=F('stage')-Value(1)).values('ref_stage'),
            ))), then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )

        annotations['already_approved']=Case(
            *already_approved_list,
            When(Q(Q(status__in=['pending','approved']),Q(current_stage__in=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(employee=request.user.id),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).annotate(ref_stage=F('stage')).values('ref_stage'),
            ))), then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )

        stage_data_subqueries = PlantMachineryHireBillInvoiceStages.cmobjects.filter(
            plant_machinery_hire_bill_invoice=OuterRef(OuterRef('pk')),
            stage=OuterRef('stage')
        ).annotate(
            full_name=Concat(F('created_by__first_name'), Value(' '), F('created_by__last_name'))
        ).order_by('-pk')
        annotations['stage_details']=Subquery(
            MultiStageSettingStages.cmobjects.filter(
                Q(multi_stage_setting__is_deleted=False),
                Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
            ).values('multi_stage_setting').annotate(
                ref_stage_details=GroupConcat(Concat(
                    F('stage'),
                    Value('|'),
                    F('stage_name'),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('full_name')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('created_at')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('status')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('remarks')[:1], output_field=CharField()),
                ), distinct=True)
            ).values('ref_stage_details')
        )

        values_fields.extend(annotations.keys())
        _list = _list.annotate(**annotations).filter(*search).values(*values_fields).distinct().order_by(*order_by.split(','))

        if all== 'true':
            return Response({
                'results': list(_list),
            })

        page_size = int(request.query_params.get('page_size', 10))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': list(page.object_list),
            },
        })
class PlantMachineryHireBillInvoiceAPIView(APIView):
    """
    CRUD API for Plant Machinery Hire Bill Invoice
    """
    
    

    def get(self, request):
        """
        Retrieve Hire Bill Invoice details
        """
        check_editor_permissions(request, "pnmhbi")

        all = self.request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        all_pending_by_user = self.request.query_params.get('all_pending_by_user', None)
        search = check_store_site(request)
        search = custom_filters(self.request, search, ['all_pending_by_user',])
     
        if all_pending_by_user:
            try:
                site_map = json.loads(all_pending_by_user)
                search.extend([~Q(status__icontains='approved'),Q(status__icontains='checked')])
                search_processed = []
                for site_id,value in site_map.items():
                    search_processed.append(Q(Q(site_id=site_id) & Q(current_stage__in=value)))
                search.append(reduce(operator.or_,search_processed))
            except Exception as e:
                print(e)
                print(all_pending_by_user)
        _list = PlantMachineryHireBillInvoice.cmobjects.select_related(
            'organization', 'project', 'site', 'store',
            'checked_by', 'cancelled_by', 'close_by', 'approved_by', 'rejected_by'
        ).filter(*search, is_deleted=False).order_by(*str(order_by).split(",")).distinct()

        if all== 'true':
            serializer = PlantMachineryHireBillInvoiceSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', 10))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryHireBillInvoiceSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Hire Bill Invoice
        """
        check_editor_permissions(request, "pnmhbi")
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryHireBillInvoiceSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})

            return Response({
                'results': {'Data': serializer.data},
                'msg': 'Successfully created.',
                'status': status.HTTP_201_CREATED,
                'request_status': 1
            })
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        check_editor_permissions(request, "pnmhbi")
        method = request.query_params.get("method", "").lower()
        id = request.query_params.get("id", None)

        with transaction.atomic():
            details = PlantMachineryHireBillInvoice.cmobjects.filter(pk=id).first()
            if not details:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})

            if method == "edit":
                request.data["updated_by"] = request.user.id
                serializer = PlantMachineryHireBillInvoiceSerializer(details, data=request.data, partial=True, context={"request": request})
                if serializer.is_valid():
                    try:
                        serializer.save()
                    except Exception as e:
                        error_message = str(e.args[0]) if e.args else str(e)
                        raise APIException({'request_status': 0, 'msg': error_message})
                    return Response({
                        "results": serializer.data,
                        "msg": "Successfully updated.",
                        "status": status.HTTP_202_ACCEPTED,
                        "request_status": 1
                    })
                raise APIException({"request_status": 0, "msg": serializer.errors})

            elif method == "delete":
                details.is_deleted = True
                details.updated_by_id = request.user.id
                details.save()
                return Response({
                    "results": {"Data": PlantMachineryHireBillInvoice.objects.filter(pk=id).values()},
                    "msg": "Successfully deleted.",
                    "request_status": 1
                })
            else:
                raise APIException({"request_status": 0, "msg": "Something went wrong. If the problem persists, please contact support.."})

# EMAIL TRIGGER
class PlantMachineryPendingCSTDailyTrigger(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        request.user=PmsUser.objects.filter(id=1).first()
        error_msg = []
        try:
            status_lists = {
                'pending': { 'search': { 'status': 'pending', 'current_stage': '0', }, 'users': [], 'cc_users': [], 'count': 0, },
                'stage_0': { 'search': { 'status': 'checked', 'current_stage': '0', }, 'users': [], 'cc_users': [], 'count': 0, },
            }
            details = MultiStageSettingStages.cmobjects.filter(
                multi_stage_setting__from_name='pnmcst',
                multi_stage_setting__is_deleted=False,
                multi_stage_setting__is_archived=False,
            ).annotate(
                user_id=GroupConcat('employee', distinct=True)
            ).values(
                'stage','user_id',
            )
            max_stage = max(details, key=lambda x: x['stage'])['stage'] if details else 0
            status_lists['pending']['users'].extend(list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-pnmcst-checker'],
                level_permission=True,
            ).values_list('user_id',flat=True)))
            cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-pnmcst-tag'],
                level_permission=True,
            ).values_list('user_id',flat=True))
            for detail in details:
                stage = detail['stage']
                # status_lists['stage_'+str(stage)] = { 'search': { 'status': 'checked', 'current_stage': str(stage), }, 'users': [], 'cc_users': (detail['user_id'].split(',') if max_stage-1 == stage else []), 'count': 0, }
                status_lists['stage_'+str(stage)] = { 'search': { 'status': 'checked', 'current_stage': str(stage), }, 'users': [], 'cc_users': [], 'count': 0, }
                status_lists['stage_'+str(stage-1)]['users'] = detail['user_id'].split(',')
            
            if not request.GET._mutable:
                request.GET._mutable = True
            request.GET['all'] = 'true'
            request.GET['latest'] = 'true'
            request.GET['site__isnull'] = 'false'
            request.GET['store__isnull'] = 'false'
            for status_list_key, status_list_value in status_lists.items():
                if status_list_value['users']:
                    ref_link = str(os.getenv('FE_ALL_PNMCST', '#')).format(**status_list_value['search'])
                    for filter_key,filter_value in status_list_value['search'].items():
                        request.GET[filter_key] = filter_value
                    resp = PlantMachineryCSTMainAPIView().get(request)
                    _list = resp.data['results']
                    if _list:
                        status_lists[status_list_key]['count'] = len(_list)
                        status_list_value['cc_users'].extend(cc_users_list)
                        context = {
                            'data': _list,
                            'current_time': datetime.now().strftime('%d-%m-%Y %H:%M:%S'),
                            'ref_link': ref_link
                        }
                        trigger_notifications(action='PLANT-MACHINERY-PENDING-CST-DAILY', user_list=status_list_value['users'], cc_user_list=status_list_value['cc_users'], context=context)
        except Exception as e:
            error_msg.append(str(e))
        return Response({'status_lists': status_lists, 'error_msg': error_msg,})

class PlantMachineryPendingAssetRequisitionDailyTrigger(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        request.user=PmsUser.objects.filter(id=1).first()
        error_msg = []
        try:
            status_lists = {
                'pending': { 'search': { 'asset_requisition__status': 'pending', 'asset_requisition__current_stage': '0', }, 'users': [], 'cc_users': [], 'count': 0, },
                'stage_0': { 'search': { 'asset_requisition__status': 'checked', 'asset_requisition__current_stage': ' 0', }, 'users': [], 'cc_users': [], 'count': 0, },
            }
            details = MultiStageSettingStages.cmobjects.filter(
                multi_stage_setting__from_name='pnmar',
                multi_stage_setting__is_deleted=False,
                multi_stage_setting__is_archived=False,
            ).annotate(
                user_id=GroupConcat('employee', distinct=True)
            ).values(
                'stage','user_id',
            )
            max_stage = max(details, key=lambda x: x['stage'])['stage'] if details else 0
            status_lists['pending']['users'].extend(list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-pnmar-checker'],
                level_permission=True,
            ).values_list('user_id',flat=True)))
            cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-pnmar-tag'],
                level_permission=True,
            ).values_list('user_id',flat=True))
            for detail in details:
                stage = detail['stage']
                status_lists['stage_'+str(stage)] = { 'search': { 'asset_requisition__status': 'checked', 'asset_requisition__current_stage': str(stage), }, 'users': [], 'cc_users': [], 'count': 0, }
                status_lists['stage_'+str(stage-1)]['users'] = detail['user_id'].split(',')
            
            if not request.GET._mutable:
                request.GET._mutable = True

            request.GET['all'] = 'true'
            for status_list_key, status_list_value in status_lists.items():
                print(f"users={status_list_value['users']}")
                if status_list_value['users']:
                    ref_link = str(os.getenv('FE_ALL_PNMAR', '#')).format(**status_list_value['search'])
                    for filter_key,filter_value in status_list_value['search'].items():
                        request.GET[filter_key] = filter_value
                    resp = PlantMachineryAssetRequisitionMainAPIView().get(request)
                    _list = resp.data['results']
                    if _list:
                        status_lists[status_list_key]['count'] = len(_list)
                        status_list_value['cc_users'].extend(cc_users_list)
                        context = {
                            'data': list(_list),
                            'current_time': datetime.now().strftime('%d-%m-%Y %H:%M:%S'),
                            'ref_link': ref_link
                        }
                        trigger_notifications(action='PLANT-MACHINERY-PENDING-AR-DAILY', user_list=status_list_value['users'], cc_user_list=status_list_value['cc_users'], context=context)

        except Exception as e:
            error_msg.append(str(e))
        return Response({'status_lists': status_lists, 'error_msg': error_msg,})


class PlantMachineryPendingCSTDailyTriggerV2(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        error_msg = []
        status_lists = []
        try:
            cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-pnmcst-tag'],
                level_permission=True,
            ).values_list('user_id',flat=True))
            target_user_list = list(MultiStageSettingStages.cmobjects.filter(
                multi_stage_setting__from_name__in=['pnmcst'],
                multi_stage_setting__is_deleted=False,
                multi_stage_setting__is_archived=False,
            ).values_list('employee',flat=True))
            target_user_list.extend(list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-pnmcst-checker'],
                level_permission=True,
            ).values_list('user_id',flat=True)))
            target_user_list = list(set(list(target_user_list)))
            print(target_user_list)
            if not request.GET._mutable:
                request.GET._mutable = True
            request.GET['all'] = 'true'
            request.GET['latest'] = 'true'
            request.GET['site__isnull'] = 'false'
            request.GET['store__isnull'] = 'false'
            request.GET['approval_applicable'] = 'true'
            for target_user in target_user_list:
                if target_user:
                    try:
                        ref_link = str(os.getenv('FE_APPROVAL_PNMCST', '#'))
                        print('USER -> ',target_user)
                        request.user=PmsUser.objects.filter(id=target_user).first()
                        resp = PlantMachineryCSTMainAPIView().get(request)
                        status_lists.append({target_user:len(resp.data['results'])})
                        _list = resp.data['results']
                        if _list:
                            context = {
                                'data': _list,
                                'current_time': datetime.now().strftime('%d-%m-%Y %H:%M:%S'),
                                'ref_link': ref_link
                            }
                            trigger_notifications(action='PLANT-MACHINERY-PENDING-CST-DAILY', user_list=[target_user], cc_user_list=cc_users_list, context=context)
                    except Exception as e:
                        error_msg.append({target_user:str(e)})

        except Exception as e:
            error_msg.append(str(e))
        return Response({'status_lists': status_lists, 'error_msg': error_msg,})


class PlantMachineryPendingAssetRequisitionDailyTriggerV2(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        error_msg = []
        status_lists = []
        try:
            cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-pnmar-tag'],
                level_permission=True,
            ).values_list('user_id',flat=True))
            target_user_list = list(MultiStageSettingStages.cmobjects.filter(
                multi_stage_setting__from_name__in=['pnmar'],
                multi_stage_setting__is_deleted=False,
                multi_stage_setting__is_archived=False,
            ).values_list('employee',flat=True))
            target_user_list.extend(list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['procurement-pnmar-checker'],
                level_permission=True,
            ).values_list('user_id',flat=True)))
            target_user_list = list(set(list(target_user_list)))
            print(target_user_list)
            if not request.GET._mutable:
                request.GET._mutable = True
            request.GET['all'] = 'true'
            request.GET['asset_requisition__latest'] = 'true'
            request.GET['asset_requisition__site__isnull'] = 'false'
            request.GET['asset_requisition__store__isnull'] = 'false'
            request.GET['approval_applicable'] = 'true'
            for target_user in target_user_list:
                if target_user:
                    try:
                        ref_link = str(os.getenv('FE_APPROVAL_PNMAR', '#'))
                        print('USER -> ',target_user)
                        request.user=PmsUser.objects.filter(id=target_user).first()
                        resp = PlantMachineryAssetRequisitionMainAPIView().get(request)
                        status_lists.append({target_user:len(resp.data['results'])})
                        _list = resp.data['results']
                        if _list:
                            context = {
                                'data': _list,
                                'current_time': datetime.now().strftime('%d-%m-%Y %H:%M:%S'),
                                'ref_link': ref_link
                            }
                            trigger_notifications(action='PLANT-MACHINERY-PENDING-AR-DAILY', user_list=[target_user], cc_user_list=cc_users_list, context=context)
                    except Exception as e:
                        error_msg.append({target_user:str(e)})

        except Exception as e:
            error_msg.append(str(e))
        return Response({'status_lists': status_lists, 'error_msg': error_msg,})

class PlantMachineryActivityTrackerAPIView(APIView):
    
    

    def get(self, request):
        search_map = {}
        search = {}
        resp = {}
        field_map = {
            'asset_requisition': [PlantMachineryAssetRequisition,'pnmar',['request_code', 'version', 'latest', 'date'],['-request_code','-version','-latest']],
            'plant_machinery_rfq_vendor': [PlantMachineryRFQVendors,'pnmar',['request_code', 'date', 'is_archived'],['-date']],
            'plant_machinery_quotation': [PlantMachineryQuotation,'pnmar',['request_code', 'version', 'latest', 'date', 'plant_machinery_rfq_vendor_id', 'plant_machinery_quotation_plant_machinery_work_order', 'vendor__vendor_name', 'plant_machinery_quotation_plant_machinery_quotation_items__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor__is_archived'],['-request_code','-version','-latest']],
            'plant_machinery_cst': [PlantMachineryCST,'pnmcst',['request_code', 'version', 'latest', 'is_repeat_order', 'is_budgeted', 'current_stage', 'plant_machinery_rfq_vendor_id', 'date', 'plant_machinery_cst_plant_machinery_cst_item__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor__is_archived'],['-request_code','-version','-latest']],
            'plant_machinery_work_order': [PlantMachineryWorkOrder,'pnmcst',['request_code', 'version', 'latest', 'date', 'plant_machinery_work_order_plant_machinery_work_order_items__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor__is_archived'],['-request_code','-version','-latest']],
        }
        multi_stage_field_map = {
            'asset_requisition': [PlantMachineryAssetRequisitionStages,'asset_requisition','pnmar'],
            'plant_machinery_cst': [PlantMachineryCSTStages,'plant_machinery_cst','pnmcst'],
        }
        for key in field_map.keys():
            search_map[key] = self.request.query_params.get(key, None)
            search[key] = {}
            resp[key] = []
        if search_map['asset_requisition']:
            search['asset_requisition'] = {'id': search_map['asset_requisition']}
            search['plant_machinery_rfq_vendor'] = {'plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items__asset_requisition_item__asset_requisition': search_map['asset_requisition']}
            search['plant_machinery_quotation'] = {'plant_machinery_quotation_plant_machinery_quotation_items__asset_requisition_item__asset_requisition': search_map['asset_requisition']}
            search['plant_machinery_cst'] = {'plant_machinery_cst_plant_machinery_cst_item__asset_requisition_item__asset_requisition': search_map['asset_requisition']}
            search['plant_machinery_work_order'] = {'plant_machinery_work_order_plant_machinery_work_order_items__asset_requisition_item__asset_requisition': search_map['asset_requisition']}
        if search_map['plant_machinery_rfq_vendor']:
            search['asset_requisition'] = {'asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_rfq_vendor_items__plant_machinery_rfq_vendor': search_map['plant_machinery_rfq_vendor']}
            search['plant_machinery_rfq_vendor'] = {'id': search_map['plant_machinery_rfq_vendor']}
            search['plant_machinery_quotation'] = {'plant_machinery_quotation_plant_machinery_quotation_items__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor': search_map['plant_machinery_rfq_vendor']}
            search['plant_machinery_cst'] = {'plant_machinery_cst_plant_machinery_cst_item__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor': search_map['plant_machinery_rfq_vendor']}
            search['plant_machinery_work_order'] = {'plant_machinery_work_order_plant_machinery_work_order_items__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor': search_map['plant_machinery_rfq_vendor']}
        if search_map['plant_machinery_quotation']:
            search['asset_requisition'] = {'asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_quotation_items__plant_machinery_quotation': search_map['plant_machinery_quotation']}
            search['plant_machinery_rfq_vendor'] = {'plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items__plant_machinery_rfq_vendor_item_plant_machinery_quotation_items__plant_machinery_quotation': search_map['plant_machinery_quotation']}
            search['plant_machinery_quotation'] = {'id': search_map['plant_machinery_quotation']}
            search['plant_machinery_cst'] = {'plant_machinery_cst_plant_machinery_cst_item__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_item_plant_machinery_quotation_items__plant_machinery_quotation': search_map['plant_machinery_quotation']}
            search['plant_machinery_work_order'] = {'plant_machinery_work_order_plant_machinery_work_order_items__plant_machinery_quotation_item__plant_machinery_quotation': search_map['plant_machinery_quotation']}
        if search_map['plant_machinery_cst']:
            search['asset_requisition'] = {'asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_cst_item__plant_machinery_cst': search_map['plant_machinery_cst']}
            search['plant_machinery_rfq_vendor'] = {'plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items__plant_machinery_rfq_vendor_item_plant_machinery_cst_item__plant_machinery_cst': search_map['plant_machinery_cst']}
            search['plant_machinery_quotation'] = {'plant_machinery_quotation_plant_machinery_quotation_items__plant_machinery_rfq_vendor_item__plant_machinery_rfq_vendor_item_plant_machinery_cst_item__plant_machinery_cst': search_map['plant_machinery_cst']}
            search['plant_machinery_cst'] = {'id': search_map['plant_machinery_cst']}
            search['plant_machinery_work_order'] = {'plant_machinery_work_order_plant_machinery_work_order_items__plant_machinery_cst_item__plant_machinery_cst': search_map['plant_machinery_cst']}
        if search_map['plant_machinery_work_order']:
            search['asset_requisition'] = {'asset_requisition_plant_machinery_asset_requisition_item__asset_requisition_item_plant_machinery_work_order_items__plant_machinery_work_order': search_map['plant_machinery_work_order']}
            search['plant_machinery_rfq_vendor'] = {'plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items__plant_machinery_rfq_vendor_item_plant_machinery_work_order_items__plant_machinery_work_order': search_map['plant_machinery_work_order']}
            search['plant_machinery_quotation'] = {'plant_machinery_quotation_plant_machinery_quotation_items__plant_machinery_quotation_item_plant_machinery_work_order_items__plant_machinery_work_order': search_map['plant_machinery_work_order']}
            search['plant_machinery_cst'] = {'plant_machinery_cst_plant_machinery_cst_item__plant_machinery_cst_item_plant_machinery_work_order_items__plant_machinery_work_order': search_map['plant_machinery_work_order']}
            search['plant_machinery_work_order'] = {'id': search_map['plant_machinery_work_order']}

        for key,value in field_map.items():
            flag = 0
            try:
                check_editor_permissions(request, value[1])
                flag = 1
            except Exception as e:
                pass
            if flag:
                fields = ['id','created_at','checked_by_date','cancelled_by_date','close_by_date','approved_by_date','rejected_by_date','status']
                fields.extend(value[2])
                annotate_list = {
                    'created_by__user_full_name': Concat('created_by__first_name',Value(' '),'created_by__last_name',output_field=CharField()),
                    'checked_by__user_full_name': Concat('checked_by__first_name',Value(' '),'checked_by__last_name',output_field=CharField()),
                    'cancelled_by__user_full_name': Concat('cancelled_by__first_name',Value(' '),'cancelled_by__last_name',output_field=CharField()),
                    'close_by__user_full_name': Concat('close_by__first_name',Value(' '),'close_by__last_name',output_field=CharField()),
                    'approved_by__user_full_name': Concat('approved_by__first_name',Value(' '),'approved_by__last_name',output_field=CharField()),
                    'rejected_by__user_full_name': Concat('rejected_by__first_name',Value(' '),'rejected_by__last_name',output_field=CharField()),
                }
                if key in ['plant_machinery_cst','asset_requisition']:
                    # annotate_list['ref_ref_stage_type']=Case(
                    #     When(Q(ref_stage_type__isnull=False), then=F('ref_stage_type_id')),
                    #     default=Subquery(
                    #         MultiStageSetting.cmobjects.filter(
                    #             Q(site=OuterRef('site_id')),
                    #             Q(from_name=Value(multi_stage_field_map[key][2]))
                    #         ).values('pk')[:1],
                    #     ),
                    #     output_field=CharField()
                    # )
                    annotate_list['ref_ref_stage_type']=F('ref_stage_type_id')

                    stage_data_subqueries = multi_stage_field_map[key][0].cmobjects.filter(**{
                        multi_stage_field_map[key][1]+'_id': OuterRef(OuterRef('pk')),
                        'stage': OuterRef('stage')
                    }).annotate(
                        full_name=Concat(F('created_by__first_name'), Value(' '), F('created_by__last_name'))
                    ).order_by('-pk')
                    annotate_list['stage_details']=Subquery(
                        MultiStageSettingStages.cmobjects.filter(
                            Q(multi_stage_setting__is_deleted=False),
                            Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                        ).values('multi_stage_setting').annotate(
                            ref_stage_details=GroupConcat(Concat(
                                F('stage'),
                                Value('|'),
                                F('stage_name'),
                                Value('|'),
                                Subquery(stage_data_subqueries.values('full_name')[:1], output_field=CharField()),
                                Value('|'),
                                Subquery(stage_data_subqueries.values('created_at')[:1], output_field=CharField()),
                                Value('|'),
                                Subquery(stage_data_subqueries.values('status')[:1], output_field=CharField()),
                                Value('|'),
                                Subquery(stage_data_subqueries.values('remarks')[:1], output_field=CharField()),
                            ), distinct=True)
                        ).values('ref_stage_details')
                    )
                # if key in ['plant_machinery_rfq_vendor']:
                #     search[key]['is_archived'] = False
                if 'id' in search[key]:
                    temp_record = value[0].cmobjects.filter(**search[key]).first()
                    request_code = getattr(temp_record,'request_code',None)
                    if request_code:
                        search[key]['request_code'] = request_code
                        del(search[key]['id'])
                fields.extend(annotate_list.keys())
                resp[key] = value[0].cmobjects.annotate(**annotate_list).filter(**search[key]).distinct().order_by(*value[3]).values(*fields)
        
        return Response(resp)

class PlantMachineryHSDApprovalMainAPIView(APIView):
    
    

    def get(self, request):
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')
        all_pending_by_user = request.query_params.get('all_pending_by_user', None)

        search = custom_filters(request, {}, ['all_pending_by_user'])
        
        if all_pending_by_user:
            try:
                site_map = json.loads(all_pending_by_user)
                search.extend([~Q(status__icontains='approved'), Q(status__icontains='checked')])
                search_processed = []
                for site_id, value in site_map.items():
                    search_processed.append(Q(site_id=site_id) & Q(current_stage__in=value))
                search.append(reduce(operator.or_, search_processed))
            except Exception as e:
                print("Error parsing all_pending_by_user:", e)
        _list = PlantMachineryHSDApproval.cmobjects.select_related(
            'organization',
            'site',
            'store',
            'project',
            'financialyear',
            'plant_machinery_machine'
        )
        annotations = {}
        approval_applicable_list = []
        already_approved_list = []
        has_permission = UserWiseModulePermissions.cmobjects.filter(
            user_id=request.user.id,
            module_item__unique_id__in=['procurement-pnmhsda-checker'],
            level_permission=True,
        ).exists()
        if has_permission:
            approval_applicable_list.append(When(Q(current_stage__in=[0],status='pending'), then=Value(True)))
            already_approved_list.append(When(Q(current_stage__in=[0],status='checked'), then=Value(True)))
        
        annotations['ref_ref_stage_type']=F('ref_stage_type_id')

        annotations['multi_stage_max_stage']=Subquery(
            MultiStageSettingStages.cmobjects.filter(
                Q(multi_stage_setting__is_deleted=False),
                Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
            ).order_by('-stage').values('stage')[:1]
        )

        annotations['current_status']=Case(
            When(status='pending', then=Value('Pending')),
            When(status='rejected', then=Value('Rejected')),
            When(status='cancelled', then=Value('Returned')),
            When(status='checked',current_stage=0, then=Value('Checked')),
            When(status__in=['checked','approved'], then=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(stage=OuterRef('current_stage')),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).values('stage_name')[:1],
            )),
            default=F('status'),
            output_field=CharField()
        )

        annotations['approval_applicable']=Case(
            *approval_applicable_list,
            When(Q(Q(status='checked'),Q(current_stage__in=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(employee=request.user.id),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).annotate(ref_stage=F('stage')-Value(1)).values('ref_stage'),
            ))), then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )

        annotations['already_approved']=Case(
            *already_approved_list,
            When(Q(Q(status__in=['checked','approved']),Q(current_stage__in=Subquery(
                MultiStageSettingStages.cmobjects.filter(
                    Q(multi_stage_setting__is_deleted=False),
                    Q(employee=request.user.id),
                    Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
                ).annotate(ref_stage=F('stage')).values('ref_stage'),
            ))), then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )

        stage_data_subqueries = PlantMachineryHSDApprovalStages.cmobjects.filter(
            hsd_approval=OuterRef(OuterRef('pk')),
            stage=OuterRef('stage')
        ).annotate(
            full_name=Concat(F('created_by__first_name'), Value(' '), F('created_by__last_name'))
        ).order_by('-pk')
        annotations['stage_details']=Subquery(
            MultiStageSettingStages.cmobjects.filter(
                Q(multi_stage_setting__is_deleted=False),
                Q(multi_stage_setting__pk=OuterRef('ref_ref_stage_type'))
            ).values('multi_stage_setting').annotate(
                ref_stage_details=GroupConcat(Concat(
                    F('stage'),
                    Value('|'),
                    F('stage_name'),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('full_name')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('created_at')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('status')[:1], output_field=CharField()),
                    Value('|'),
                    Subquery(stage_data_subqueries.values('remarks')[:1], output_field=CharField()),
                ), distinct=True)
            ).values('ref_stage_details')
        )

        annotations['total_petrol']=Coalesce(
            Sum(
                Subquery(
                    PlantMachineryHSDApprovalItem.cmobjects.filter(
                        hsd_approval_id=OuterRef('pk'),
                        plant_machinery_machine__machine_info_fuel_type='Petrol',
                    ).annotate(
                        tot_req=F('requirement_per_day')*ExpressionWrapper(
                                date_diff_handle(F('to_date'), F('from_date')),
                                output_field=FloatField()
                            ),
                    ).values('hsd_approval_id')
                    .annotate(total_amount=Sum('tot_req'))
                    .values('total_amount')
                )
            ),
            Value(0.0),
            output_field=FloatField()
        )
        annotations['total_hsd']=Coalesce(
            Sum(
                Subquery(
                    PlantMachineryHSDApprovalItem.cmobjects.filter(
                        hsd_approval_id=OuterRef('pk'),
                        plant_machinery_machine__machine_info_fuel_type='Diesel',
                    ).annotate(
                        tot_req=F('requirement_per_day')*ExpressionWrapper(
                                date_diff_handle(F('to_date'), F('from_date')),
                                output_field=FloatField()
                            ),
                    ).values('hsd_approval_id')
                    .annotate(total_amount=Sum('tot_req'))
                    .values('total_amount')
                )
            ),
            Value(0.0),
            output_field=FloatField()
        )
        annotations['grand_total']=(F('total_petrol')*F('fuel_rate_petrol'))+(F('total_hsd')*F('fuel_rate_hsd'))

        _list = _list.annotate(**annotations).filter(*search).values(
            'id',
            'request_code',
            'version',
            'latest',
            # 'status',
            'date',
            'project__project_name',
            'project__project_code',
            'current_stage',
            'site_id',
            'organization_id',
            **annotations
        ).order_by(*str(order_by).split(",")).distinct()
        print(_list)
        if all == 'true':
            return Response({'results': list(_list)})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': page.object_list,
            },
        })
    
class PlantMachineryHSDApprovalAPIView(APIView):
    
    

    def get(self, request):
        check_editor_permissions(request, "pnmhsda")
        id = request.query_params.get('id', None)
        all = request.query_params.get('all', None)
        order_by = request.query_params.get('order_by', '-id')

        if id:
            _details = PlantMachineryHSDApproval.cmobjects.filter(id=id).first()
            serializer = PlantMachineryHSDApprovalSerializer(_details)
            return Response(serializer.data)

        search = custom_filters(request, {}, [])

        _list = PlantMachineryHSDApproval.cmobjects.select_related(
            'organization', 'project'
        ).filter(*search).order_by(*str(order_by).split(","))

        if all == 'true':
            serializer = PlantMachineryHSDApprovalSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = PlantMachineryHSDApprovalSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        check_editor_permissions(request, "pnmhsda")
        request.data['created_by'] = request.user.id
        serializer = PlantMachineryHSDApprovalSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e)})
            return Response(
                {'results': {'Data': serializer.data},
                 'msg': 'Successfully created',
                 'status': status.HTTP_201_CREATED,
                 "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        check_editor_permissions(request, "pnmhsda")
        method = request.query_params.get('method', None)
        organization_id = request.query_params.get('organization_id', None)
        requisition_id = request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if PlantMachineryHSDApproval.cmobjects.filter(pk=requisition_id, organization_id=organization_id).exists():
                    details = PlantMachineryHSDApproval.cmobjects.filter(pk=requisition_id).first()
                    request.data['updated_by'] = request.user.id
                    serializer = PlantMachineryHSDApprovalSerializer(details, data=request.data, partial=True, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e)})
                        return Response({'results': {'Data': serializer.data},
                                         'msg': "Successfully updated",
                                         'status': status.HTTP_202_ACCEPTED,
                                         "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong"})
            elif method.lower() == 'delete':
                if PlantMachineryHSDApproval.cmobjects.filter(pk=requisition_id, organization_id=organization_id).exists():
                    details = PlantMachineryHSDApproval.cmobjects.filter(pk=requisition_id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()
                    return Response({'results': {'Data': PlantMachineryHSDApproval.objects.filter(pk=requisition_id, organization_id=organization_id).values()},
                                     'msg': 'Successfully deleted',
                                     "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong"})
