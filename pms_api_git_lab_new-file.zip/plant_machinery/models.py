from django.db import models
from custom_management.models import *
from django.core.validators import EmailValidator, RegexValidator

from material_master.models import UnitOfMesurement, Brand,Model , VendorMaterialMaster
from misc.models import TaxHead , ExpenseHead , TermsAndConditionsChild
from administrations.models import Company
from vendor.models import VendorMasterV2
from administrations.models import *
from email_config.models import EmailSend
# from project_and_planning.models import ProjectMaster
# from procurement.models import SiteMaster
class PlantMachineryMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organization_plant_machinery_master',on_delete=models.CASCADE, null=True, blank=True)
    def __str__(self):
        return f'{self.pk}  Deleted:{self.is_deleted}'

    
class PlantMachineryData(BaseAbstractStructure):

    plantmachinery = models.ForeignKey(PlantMachineryMaster, related_name='plant_machinery_master',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='plant_machinery_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True) 
    document = models.FileField(
        upload_to='PlantMachinery/document', null=True, blank=True, help_text='documents')
    by_order = models.IntegerField(default=0)

    class Meta:
        db_table = 'plant_machinery_plantmachinerydata'


class PlantMachineryGroup(BaseAbstractStructure):
    
    MACHINE_TYPE_CHOICES = [
        ('vehicle', 'Vehicle'),
        ('machine', 'Machine'),
        # ('drilling', 'Drilling'),
    ]
    AVERAGE_BASE_CHOICES = [
        ('distance', 'Distance'),
        ('time', 'Time'),
        ('both', 'Both'),
        ('none', 'None'),
    ]
    ASSET_TYPE_CHOICES = [
        ('major', 'Major'),
        ('minor', 'Minor'),
    ]
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_group_organizations_data',on_delete=models.CASCADE)
    projects = models.ManyToManyField('project_and_planning.ProjectMaster', related_name='plant_machinery_plant_machinery_group_projects', null=True, blank=True)
    name = models.CharField(max_length=200,null=True, blank=True)
    parent = models.ForeignKey('self', related_name='plant_machinery_group_parent', on_delete=models.CASCADE, blank=True, null=True)
    average_base = models.CharField(max_length=10, choices=AVERAGE_BASE_CHOICES, default='none')
    standard_km_run_month = models.FloatField(default=0)
    standard_hrs_run_month = models.FloatField(default=0)
    standard_mileage_km_ltr = models.FloatField(default=0)
    standard_mileage_ltr_hr = models.FloatField(default=0)
    remarks = models.TextField(blank=True, null=True)
    use_for = models.CharField(max_length=100,blank=True, null=True)
    display_order_no = models.IntegerField(default=0)
    machine_type = models.CharField(max_length=10, choices=MACHINE_TYPE_CHOICES, default='vehicle')
    is_applicable = models.BooleanField(default=False)
    insurance = models.BooleanField(default=False)
    permit = models.BooleanField(default=False)
    fitness = models.BooleanField(default=False)
    tax = models.BooleanField(default=False)
    puc = models.BooleanField(default=False)
    welfare = models.BooleanField(default=False)
    i_form = models.BooleanField(default=False)
    green_tax = models.BooleanField(default=False)
    unit_per_hour =models.FloatField(default=0)
    working_rate = models.FloatField(default=0)
    designation = models.CharField(max_length=200,blank=True, null=True)
    check_pending_log=models.BooleanField(default=True)
    uom= models.ForeignKey(UnitOfMesurement, related_name='plant_machinery_group_uom',on_delete=models.CASCADE, null=True, blank=True)
    r_and_m_norms = models.FloatField(default=0)
    is_compliance = models.BooleanField(default=False)
    asset_type = models.CharField(max_length=50, choices=ASSET_TYPE_CHOICES, default='major')

    class Meta:
        db_table = "plant_machinery_plant_machinery_group"


class PlantMachinery(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_organization',on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery',on_delete=models.CASCADE, null=True, blank=True)
    equipment_description = models.CharField(max_length=200,null=True, blank=True)
    uom_productivity = models.ForeignKey(UnitOfMesurement, related_name='uom_productivity_plant_machinery',on_delete=models.CASCADE, null=True, blank=True)
    productivity = models.FloatField(default=0)
    capital_cost = models.FloatField(default=0)
    depreciation_norms_per_month = models.FloatField(default=0)
    fixed_hours_per_month = models.FloatField(default=0)
    depreciation_cost = models.FloatField(default=0)
    hsd_norms_uom = models.ForeignKey(UnitOfMesurement, related_name='hsd_norms_uom_plant_machinery',on_delete=models.CASCADE, null=True, blank=True)
    norms = models.FloatField(default=0)
    hsd_rate = models.FloatField(default=0.0)
    hsd_cost = models.FloatField(default=0.0)
    pol_cost = models.FloatField(default=0.0)
    spare_cost = models.FloatField(default=0.0)
    tyre_tube_cost = models.FloatField(default=0.0)
    wear_tear_cost = models.FloatField(default=0.0)
    external_service_cost = models.FloatField(default=0.0)
    miscellaneous_cost = models.FloatField(default=0.0)
    total_rm_cost = models.FloatField(default=0.0)
    mob_demob_exp_cost = models.FloatField(default=0.0)
    prelim_exp_civil_cost = models.FloatField(default=0.0)
    cost_other_than_rm_om = models.FloatField(default=0.0)
    monthly_actual_salary_by_hr = models.FloatField(default=0.0)
    monthly_internal_hire_charges = models.FloatField(default=0.0)
    monthly_external_hire_charges = models.FloatField(default=0.0)
    total_cost_including_fuel = models.FloatField(default=0.0)
    total_production_qty_m3 = models.FloatField(default=0)
    total_production_qty_ton = models.FloatField(default=0)
    productivity_per_hour_m3 = models.FloatField(default=0.0)
    production_per_hour_ton = models.FloatField(default=0.0)
    operating_cost_per_hr = models.FloatField(default=0.0)
    operating_cost_per_km = models.FloatField(default=0.0)
    plant_cost_per_m3_mt = models.FloatField(default=0.0)
    hsd_cost_per_hr_km = models.FloatField(default=0.0)
    rm_cost_per_hr_km = models.FloatField(default=0.0)
    tot_operating_cost_per_hr_km = models.FloatField(default=0.0)
    prod_qty_days = models.FloatField(default=0)
    trips_per_day = models.FloatField(default=0)

    def __str__(self):
        return f"{self.pk} {'deleted' if self.is_deleted else 'not deleted'}"

    class Meta:
        db_table = "plant_machinery_plant_machinery"
class PlantMachineryTruckAccount(BaseAbstractStructure):
    """
    PlantMachineryTruckAccount MasterModel
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_truck_account', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_truck_account_projects', null=True, blank=True, on_delete=models.CASCADE)
   
    name = models.CharField(max_length=200, null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_truck_account"

class PlantMachineryTdsType(BaseAbstractStructure):
    """
    PlantMachineryTdsType Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_tds_type', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_tds_type_projects', null=True, blank=True, on_delete=models.CASCADE)
   
    name = models.CharField(max_length=200, null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_tds_type"  
class PlantMachineryObjectiveIndicationType(BaseAbstractStructure):
    """
    PlantMachineryObjectiveIndicationType Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_objective_indication_type', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_objective_indication_type_project', null=True, blank=True, on_delete=models.CASCADE)
   
    name = models.CharField(max_length=200, null=True, blank=True)
    type = models.CharField(max_length=200, null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_objective_indication_type"              

class PlantMachineryMachine(BaseAbstractStructure):
    """
    PlantMachineryMachine model
    """
    OWNER_TYPE_CHOICES = [
        ('owned', 'Owned'),
        # ('self', 'Self'),
        ('hired', 'Hired'),
    ]
    # FUEL_TYPE_CHOICES = [
    #     ('diesel', 'Diesel'),
    #     ('petrol', 'Petrol'),
    #     ('electric', 'Electric'),
    # ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_machine_projects', null=True, blank=True, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    file_no = models.CharField(max_length=100, blank=True, null=True)
    machine_no_1 = models.CharField(max_length=100, blank=True, null=True)
    machine_number = models.CharField(max_length=200, blank=True, null=True)
    # plant_machinery = models.ForeignKey(PlantMachineryMaster, related_name='plant_machinery_master_plant_machinery_machine', blank=True, null=True, on_delete=models.CASCADE)
    registration_no = models.CharField(max_length=100, blank=True, null=True)
    transport_billing = models.CharField(max_length=100,  blank=True, null=True)
    rfid = models.CharField(max_length=100, blank=True, null=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_machine', blank=True, null=True, on_delete=models.CASCADE)
    machine_no_2 = models.CharField(max_length=100, blank=True, null=True)
    machine_code = models.CharField(max_length=100, blank=True, null=True)
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_machine', blank=True, null=True, on_delete=models.CASCADE)
    active_date = models.DateField(blank=True, null=True)
    gps_track_id = models.IntegerField(blank=True, null=True)
    fastag_no = models.CharField(max_length=100, blank=True, null=True)
    machine_location = models.ForeignKey("procurement.StoreMaster", related_name='store_master_plant_machinery_machine', blank=True, null=True, on_delete=models.CASCADE)
    plant_machinery_objective_indication_type = models.ForeignKey(PlantMachineryObjectiveIndicationType, \
            related_name='plant_machinery_objective_indication_type_plant_machinery_machine', blank=True, null=True, on_delete=models.CASCADE)

    # doc Information
    purchase_vendor = models.CharField(max_length=100, blank=True, null=True)
    date_of_purchase = models.DateField(blank=True, null=True)
    date_of_purchase_active = models.BooleanField(default=False)
    inv_no = models.CharField(max_length=100, blank=True, null=True)
    owner_type = models.CharField(max_length=50, choices=OWNER_TYPE_CHOICES,blank=True, null=True)
    rto_permit = models.CharField(max_length=100, blank=True, null=True)
    rto_from_active = models.BooleanField(default=False)
    rto_from = models.DateField(blank=True, null=True)
    rto_to_active = models.BooleanField(default=False)
    rto_to = models.DateField(blank=True, null=True)
    sld_from_active = models.BooleanField(default=False)
    sld_from = models.DateField(blank=True, null=True)
    sld_to_active = models.BooleanField(default=False)
    sld_to = models.DateField(blank=True, null=True)
    use_date = models.DateField(blank=True, null=True)
    allow_multiple_hire_contract = models.BooleanField(default=False)
    rc_no = models.CharField(max_length=100, blank=True, null=True)
    rc_expiry_date = models.DateField(blank=True, null=True)
    purchase_amount_basic = models.FloatField(default=0)
    depreciation = models.FloatField(default=0)
    rto_amount = models.FloatField(default=0)
    idv =models.FloatField(default=0)
    vrn_date_active = models.BooleanField(default=False)
    vrn_date = models.DateField(blank=True, null=True)
    vrn_no = models.CharField(max_length=100, blank=True, null=True)
    sld_no = models.CharField(max_length=100, blank=True, null=True)
    # machine info
    machine_info_make = models.CharField(max_length=100, blank=True, null=True)
    machine_info_fuel_type = models.CharField(max_length=100, blank=True, null=True)
    machine_info_fuel_item = models.CharField(max_length=100, blank=True, null=True)
    machine_info_chassis_no = models.CharField(max_length=100, blank=True, null=True)
    machine_info_engine_no = models.CharField(max_length=100, blank=True, null=True)
    machine_info_engine_make = models.CharField(max_length=100, blank=True, null=True)
    machine_info_engine_model = models.CharField(max_length=100, blank=True, null=True)
    machine_info_cubic_capacity = models.FloatField(default=0)
    machine_info_cubic_capacity_unit = models.ForeignKey(UnitOfMesurement, related_name='machine_info_cubic_capacity_unit_plant_machinery_machine', on_delete=models.CASCADE,
                              null=True, blank=True)
    machine_info_engine_life_km = models.FloatField(default=0)
    machine_info_engine_life_hr= models.FloatField(default=0)
    machine_info_upto_date_reading_tacho = models.FloatField(default=0)
    machine_info_upto_date_reading_hr= models.FloatField(default=0)
    machine_info_machine_life_year= models.FloatField(default=0)
    machine_info_machine_color = models.CharField(max_length=100, blank=True, null=True)
    machine_info_body_type = models.CharField(max_length=100, blank=True, null=True)
    machine_info_current_rto = models.CharField(max_length=100, blank=True, null=True)
    machine_info_warranty_hr = models.FloatField(default=0)
    machine_info_warranty_day = models.FloatField(default=0)
    machine_info_warranty_km = models.FloatField(default=0)
    machine_info_extended_warranty_hr = models.FloatField(default=0)
    machine_info_extended_warranty_day = models.FloatField(default=0)
    machine_info_extended_warranty_km = models.FloatField(default=0)
    machine_info_remarks = models.TextField(blank=True, null=True)
    machine_info_model = models.CharField(max_length=100, blank=True, null=True)
    machine_info_manufacture_year =  models.CharField(max_length=100, blank=True, null=True)
    machine_info_fuel_capacity = models.FloatField(default=0)
    machine_info_up_to_date_issue = models.FloatField(default=0)
    machine_info_horse_power = models.FloatField(default=0)
    machine_info_capacity = models.FloatField(default=0)
    machine_info_charges = models.FloatField(default=0)
    machine_info_charges_type = models.CharField(max_length=100, blank=True, null=True)
    machine_info_no_of_tyres = models.IntegerField(default=0)
    machine_info_tare_weight = models.FloatField(default=0)
    machine_info_no_of_battery = models.IntegerField(default=0)
    machine_info_tare_weight_unit = models.ForeignKey(UnitOfMesurement, related_name='machine_info_tare_weight_unit_plant_machinery_machine', on_delete=models.CASCADE,
                              null=True, blank=True)
    machine_info_min_allowed_weight_ton= models.FloatField(default=0)
    machine_info_offset_weight_ton = models.FloatField(default=0)
    machine_info_serial_no = models.CharField(max_length=100, blank=True, null=True)
    machine_info_maintain_working_log = models.BooleanField(default=True)
    machine_info_sitting_capacity = models.IntegerField(default=0)
    machine_info_date_of_commissioning = models.DateField(blank=True, null=True)
    machine_info_standard_mileage_ltr_hr = models.FloatField(default=0)
    machine_info_standard_km_run_month= models.FloatField(default=0)
    machine_info_standard_hrs_run_month = models.FloatField(default=0)
    machine_info_standard_norms_ltr_km = models.FloatField(default=0)
    ## plant machinery fields
    equipment_number = models.CharField(max_length=100,null=True, blank=True)
    equipment_description = models.CharField(max_length=200,null=True, blank=True)  # = name
    uom_productivity = models.ForeignKey(UnitOfMesurement, related_name='uom_productivity_plant_machinery_machine',on_delete=models.CASCADE, null=True, blank=True)
    productivity = models.FloatField(default=0)
    capital_cost = models.FloatField(default=0)
    depreciation_norms_per_month = models.FloatField(default=0)
    fixed_hours_per_month = models.FloatField(default=0)
    depreciation_cost = models.FloatField(default=0)
    hsd_norms_uom = models.ForeignKey(UnitOfMesurement, related_name='hsd_norms_uom_plant_machinery_machine',on_delete=models.CASCADE, null=True, blank=True)
    norms = models.FloatField(default=0)
    hsd_rate = models.FloatField(default=0.0)
    hsd_cost = models.FloatField(default=0.0)
    hsd_qty = models.FloatField(default=0)
    pol_cost = models.FloatField(default=0.0)
    spare_cost = models.FloatField(default=0.0)
    tyre_tube_cost = models.FloatField(default=0.0)
    wear_tear_cost = models.FloatField(default=0.0)
    external_service_cost = models.FloatField(default=0.0)
    miscellaneous_cost = models.FloatField(default=0.0)
    total_rm_cost = models.FloatField(default=0.0)
    mob_demob_exp_cost = models.FloatField(default=0.0)
    prelim_exp_civil_cost = models.FloatField(default=0.0)
    cost_other_than_rm_om = models.FloatField(default=0.0)
    monthly_actual_salary_by_hr = models.FloatField(default=0.0)
    monthly_internal_hire_charges = models.FloatField(default=0.0)
    monthly_external_hire_charges = models.FloatField(default=0.0)
    total_cost_including_fuel = models.FloatField(default=0.0)
    total_production_qty_m3 = models.FloatField(default=0)
    total_production_qty_ton = models.FloatField(default=0)
    productivity_per_hour_m3 = models.FloatField(default=0.0)
    production_per_hour_ton = models.FloatField(default=0.0)
    operating_cost_per_hr = models.FloatField(default=0.0)
    operating_cost_per_km = models.FloatField(default=0.0)
    plant_cost_per_m3_mt = models.FloatField(default=0.0)
    hsd_cost_per_hr_km = models.FloatField(default=0.0)
    rm_cost_per_hr_km = models.FloatField(default=0.0)
    tot_operating_cost_per_hr_km = models.FloatField(default=0.0)
    prod_qty_days = models.FloatField(default=0)
    trips_per_day = models.FloatField(default=0)
    ##file upload
    attachment = models.FileField(upload_to='plant_machinery/machine/file_upload/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    ## account create
    truck_account = models.ForeignKey(PlantMachineryTruckAccount, related_name='truck_account_plant_machinery_machine',on_delete=models.CASCADE, null=True, blank=True)
    ##owner
    owner_name=models.CharField(max_length=200,null=True, blank=True)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{6,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    owner_phone_no = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True)
    owner_pan_number=models.CharField(max_length=200,null=True, blank=True)
    owner_address=models.TextField(null=True, blank=True)
    owner_declaration_tds = models.BooleanField(default=False)
    owner_tds_type= models.ForeignKey(PlantMachineryTdsType, related_name='owner_tds_type_plant_machinery_machine',on_delete=models.CASCADE, null=True, blank=True)
    ## seal number
    consumption_tank_starting_seal_number =models.CharField(max_length=200, null=True, blank=True)
    is_fuel_tanker_vehicle = models.BooleanField(default=False)
    distribution_tank_starting_seal_number = models.CharField(max_length=200,null=True, blank=True)
    is_tanker_has_issue_meter_ltr = models.BooleanField(default=False)

    vendor = models.ForeignKey(VendorMasterV2, related_name='vendor_plant_machinery_machine', on_delete=models.CASCADE,null=True, blank=True)
    hsn_code = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return str(self.id) + ' ' + str(self.equipment_description)
    class Meta:
        db_table = "plant_machinery_machine"

class PlantMachineryDpr(BaseAbstractStructure):
    """
    PlantMachineryDpr model
    """
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_dpr_organization', on_delete=models.CASCADE)
    master = models.ForeignKey(PlantMachineryMaster, related_name='plant_machinery_plant_machinery_dpr_master', blank=True, null=True, on_delete=models.CASCADE)
    start_hrs = models.FloatField(blank=True, null=True, default=0.)
    close_hrs = models.FloatField(blank=True, null=True, default=0.)
    bd_hrs = models.FloatField(blank=True, null=True, default=0.)
    extra_working_hrs = models.FloatField(blank=True, null=True, default=0.)
    start_kms = models.FloatField(blank=True, null=True, default=0.)
    close_kms = models.FloatField(blank=True, null=True, default=0.)
    total_fuel_filled = models.FloatField(blank=True, null=True, default=0.)
    total_production_qty_cum = models.FloatField(blank=True, null=True, default=0.)
    total_production_qty_ton = models.FloatField(blank=True, null=True, default=0.)
    gsb_aggregate_trips = models.FloatField(blank=True, null=True, default=0.)
    dbm_bc_trips = models.FloatField(blank=True, null=True, default=0.)
    pqc_dlc_trips = models.FloatField(blank=True, null=True, default=0.)
    soil_bt_cuttingmisc_trips = models.FloatField(blank=True, null=True, default=0.)
    wmm_trips = models.FloatField(blank=True, null=True, default=0.)
    last_entry_date = models.DateField(blank=True, null=True)
    boq = models.CharField(max_length=100, blank=True, null=True)
    from_chainage = models.CharField(max_length=100, blank=True, null=True)
    to_chainage = models.CharField(max_length=100, blank=True, null=True)
    operator_name = models.CharField(max_length=100, blank=True, null=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_dpr"
class PlantMachineryDprMaster(BaseAbstractStructure):
    """
    PlantMachineryDprMaster  model
    """
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_dpr_master_organization', on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='project_master_plant_machinery_dpr_master', blank=True, null=True, on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_dpr_master', blank=True, null=True, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, blank=True, null=True)
    entry_date = models.DateField(blank=True, null=True)
    

    class Meta:
        db_table = "plant_machinery_plant_machinery_dpr_master"
        unique_together=['organization','project','site','entry_date']
class PlantMachineryDprNew(BaseAbstractStructure):
    """
    PlantMachineryDpr New model
    """
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_dpr_new_organization', on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_machine_plant_machinery_dpr_new', blank=True, null=True, on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='project_master_plant_machinery_dpr_new', blank=True, null=True, on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_dpr_new', blank=True, null=True, on_delete=models.CASCADE)
    dpr_master = models.ForeignKey(PlantMachineryDprMaster, related_name='dpr_master_plant_machinery_dpr_new', blank=True, null=True, on_delete=models.CASCADE)
    equipment_number = models.CharField(max_length=100, blank=True, null=True)
    reg_number = models.CharField(max_length=100, blank=True, null=True)
    equipment_description = models.TextField(blank=True, null=True)
    entry_date = models.DateField(blank=True, null=True)
    plan_hrs = models.FloatField(blank=True, null=True, default=0.)
    plan_km = models.FloatField(blank=True, null=True, default=0.)
    start_hrs = models.FloatField(blank=True, null=True, default=0.)
    close_hrs = models.FloatField(blank=True, null=True, default=0.)
    working_hrs = models.FloatField(blank=True, null=True, default=0.)
    total_working_hrs = models.FloatField(blank=True, null=True, default=0)
    bd_hrs = models.FloatField(blank=True, null=True, default=0)
    idle_hrs = models.FloatField(blank=True, null=True, default=0)
    extra_working_hrs = models.FloatField(blank=True, null=True, default=0)
    start_kms = models.FloatField(blank=True, null=True, default=0)
    close_kms = models.FloatField(blank=True, null=True, default=0)
    total_km_run = models.FloatField(blank=True, null=True, default=0)
    total_fuel_filled = models.FloatField(blank=True, null=True, default=0)
    standard_norms = models.FloatField(blank=True, null=True, default=0)
    actual_norms = models.FloatField(blank=True, null=True, default=0)
    difference_norms = models.FloatField(blank=True, null=True, default=0)
    total_production_qty_cum = models.FloatField(blank=True, null=True, default=0)
    total_production_qty_ton = models.FloatField(blank=True, null=True, default=0)
    gsb_aggregate_trips = models.FloatField(blank=True, null=True, default=0)
    dbm_bc_trips = models.FloatField(blank=True, null=True, default=0)
    pqc_dlc_trips = models.FloatField(blank=True, null=True, default=0)
    soil_bt_cuttingmisc_trips = models.FloatField(blank=True, null=True, default=0)
    wmm_trips = models.FloatField(blank=True, null=True, default=0)
    total_trips = models.FloatField(blank=True, null=True, default=0)
    last_entry_date = models.DateField(blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    boq = models.CharField(max_length=100, blank=True, null=True)
    from_location = models.CharField(max_length=100, blank=True, null=True)
    from_chainage = models.CharField(max_length=100, blank=True, null=True)
    to_location = models.CharField(max_length=100, blank=True, null=True)
    to_chainage = models.CharField(max_length=100, blank=True, null=True)
    operator_name = models.CharField(max_length=100, blank=True, null=True)
    total_days = models.IntegerField(blank=True, null=True, default=0)

    class Meta:
        db_table = "plant_machinery_plant_machinery_dpr_new"

class PlantMachineryDocumentUploadMaster(BaseAbstractStructure):
    """
    PlantMachineryDocumentUploadMaster  model
    """

    PURPOSE_CHOICES =  [
        ('license', 'License'),
        ('fitness', 'Fitness'),
        ('national_permit', 'National Permit'),
        ('pollution', 'Pollution'),
        ('calibration_certificate', 'Calibration Certificate'),
        ('rc_documents','RC Documents'),
        ('insurance_certificate','Insurance certificate'),
        ('tax_documents', 'Tax Documents'),
        ('emission_certificate','Emission certificate'),
        ('commissioning_report','Commissioning Report'),
        ('work_order','Work Order'),
    ]
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_document_upload_master_organization', on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_document_upload_master_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_document_upload_master', blank=True, null=True, on_delete=models.CASCADE)
    plant_machinery_machine= models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_machine_plant_machinery_document_upload_master', blank=True, null=True, on_delete=models.CASCADE)
    purpose=models.CharField(max_length=100,choices=PURPOSE_CHOICES, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_document_upload_master"
        
class PlantMachineryDocumentUpload(BaseAbstractStructure):
    """
    Attachments for PlantMachineryDocumentUploadMaster
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_document_upload', 
                                     on_delete=models.CASCADE)
    plant_machinery_document_upload_master = models.ForeignKey(PlantMachineryDocumentUploadMaster, 
                                                               related_name='document_upload_master_plant_machinery_document_upload',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    document_name = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    attachment = models.FileField(upload_to='plant_machinery/documents', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    exp_date = models.DateField(blank=True, null=True)#expiry date
    is_notification_sent = models.BooleanField(default=False)
    class Meta:
        db_table = "plant_machinery_plant_machinery_document_upload"
class PlantMachineryServiceGroup(BaseAbstractStructure):
    """
    PlantMachineryServiceGroup Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_service_group', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_service_group_project', null=True, blank=True, on_delete=models.CASCADE)
   
    name = models.CharField(max_length=200, null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_service_group"

class PlantMachineryServiceItem(BaseAbstractStructure):
    """
    PlantMachineryServiceItem Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_service_item', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_service_item_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                                                               related_name='plant_machinery_machine_plant_machinery_service_item',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_service_group = models.ForeignKey(PlantMachineryServiceGroup, 
                                                               related_name='plant_machinery_serivce_group_plant_machinery_service_item',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    # service_unit = models.ForeignKey(UnitOfMesurement, related_name='service_unit_plant_machinery_service_item', on_delete=models.CASCADE,
    #                           null=True, blank=True)
    service_unit = models.CharField(max_length=200, null=True, blank=True)
    gst_tax = models.ForeignKey(TaxHead, related_name='gst_tax_plant_machinery_service_item', on_delete=models.CASCADE,
                              null=True, blank=True)
    type = models.CharField(max_length=200, null=True, blank=True)
    gst_tax_free = models.BooleanField(default=False)
    is_luxurious_tax = models.BooleanField(default=False)
    quantity=models.IntegerField(default=0)
    class Meta:
        db_table = "plant_machinery_plant_machinery_service_item"
class PlantMachineryServiceSchedule(BaseAbstractStructure):
    """
    PlantMachineryServiceSchedule Categorywise or group wise Model
    """
    REPEAT_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
    ]
    CHARGEABLE_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
    ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_service_schedule', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_service_schedule_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_service_schedule', blank=True, null=True, on_delete=models.CASCADE)

    plant_machinery_service_group = models.ForeignKey(PlantMachineryServiceGroup, 
                                                               related_name='plant_machinery_serivce_group_plant_machinery_service_schedule',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_service_item= models.ForeignKey(PlantMachineryServiceItem, related_name='plant_machinery_serivce_item_plant_machinery_service_schedule', on_delete=models.CASCADE,
                              null=True, blank=True)
    service_unit= models.ForeignKey(UnitOfMesurement, related_name='service_unit_plant_machinery_service_schedule', on_delete=models.CASCADE,
                              null=True, blank=True)
    service_type=  models.CharField(max_length=200, null=True, blank=True)
    repeat=  models.CharField(max_length=200,choices=REPEAT_CHOICES, null=True, blank=True)
    limit_kms_from = models.FloatField(default=0)
    limit_kms_to= models.FloatField(default=0)
    limit_days_from = models.FloatField(default=0)
    limit_days_to= models.FloatField(default=0)
    limit_hrs_from = models.FloatField(default=0)
    limit_hrs_to= models.FloatField(default=0)
    quantity= models.FloatField(default=0)
    chargeable=  models.CharField(max_length=200,choices=REPEAT_CHOICES, null=True, blank=True)
    approx_rate = models.FloatField(default=0)
    approx_amount= models.FloatField(default=0)
    part_number=  models.CharField(max_length=200, null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_service_schedule"
class PlantMachineryServiceScheduleNew(BaseAbstractStructure):
    """
    PlantMachineryServiceSchedule New Model
    """
    SERVICE_TYPE_CHOICES = [
        ('preventive_maintenance', 'Preventive Maintenance'),
        ('schedule_maintenance', 'Schedule Maintenance'),
    ]
    REPAIR_TYPE_CHOICES = [
        ('inside_repair', 'Inside Repair'),
        ('outside_repair', 'Outside Repair'),
    ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_service_schedule_new', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_service_schedule_new_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_service_schedule_new', blank=True, null=True, on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_machine_plant_machinery_service_schedule_new', blank=True, null=True, on_delete=models.CASCADE)

    plant_machinery_service_group = models.ForeignKey(PlantMachineryServiceGroup, 
                                                               related_name='plant_machinery_serivce_group_plant_machinery_service_schedule_new',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, 
            related_name='vendor_plant_machinery_service_schedule_new',
            on_delete=models.CASCADE,null=True, blank=True)
    equipment_model=  models.CharField(max_length=200, null=True, blank=True)
    equipment_make=  models.CharField(max_length=200, null=True, blank=True)
    service_type=  models.CharField(max_length=100,choices=SERVICE_TYPE_CHOICES, null=True, blank=True)
    type_of_repair=  models.CharField(max_length=100,choices=REPAIR_TYPE_CHOICES, null=True, blank=True)
    mechanic_inspector_name=  models.CharField(max_length=200, null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_service_schedule_new"      
class PlantMachineryServiceScheduleNewChild(BaseAbstractStructure):
    """
    PlantMachineryServiceSchedule New Child Model
    """
 
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_service_schedule_new_child', 
                                     on_delete=models.CASCADE)
  
    plant_machinery_service_schedule = models.ForeignKey(PlantMachineryServiceScheduleNew, 
                                                               related_name='plant_machinery_service_schedule_plant_machinery_service_schedule_new_child',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_service_item= models.ForeignKey(PlantMachineryServiceItem, related_name='plant_machinery_serivce_item_plant_machinery_service_schedule_new_child', on_delete=models.CASCADE,
                              null=True, blank=True)
   
    quantity= models.FloatField(default=0)
    unit= models.ForeignKey(UnitOfMesurement, related_name='unit_plant_machinery_service_schedule_new_child', on_delete=models.CASCADE,
                              null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_service_schedule_new_child"              
class PlantMachineryInactiveType(BaseAbstractStructure):
    """
    PlantMachineryInactiveType Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_inactive_type', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_inactive_type_project', null=True, blank=True, on_delete=models.CASCADE)
   
    name = models.CharField(max_length=200, null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_inactive_type"

class PlantMachineryMachineServices(BaseAbstractStructure):
    """
    PlantMachineryMachineServices Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_services', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                                                               related_name='plant_machinery_machine_plant_machinery_machine_services',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_service_group = models.ForeignKey(PlantMachineryServiceGroup, 
                                                               related_name='plant_machinery_serivce_group_plant_machinery_machine_services',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_service_item= models.ForeignKey(PlantMachineryServiceItem, related_name='plant_machinery_serivce_item_plant_machinery_machine_services', on_delete=models.CASCADE,
                              null=True, blank=True)
    
    free_number_of_service_with_machine = models.IntegerField(default=0)
    free_number_of_service_machine_entry_time = models.IntegerField(default=0)

    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_services"        


class PlantMachineryMachineTransfer(BaseAbstractStructure):
    """
    PlantMachineryMachineTransfer Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_transfer', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine =  models.ForeignKey(PlantMachineryMachine, 
                related_name='plant_machinery_machine_plant_machinery_machine_transfer',
                on_delete=models.CASCADE,null=True, blank=True)
    
    transfer_date = models.DateField(null=True, blank=True)
    receiving_date = models.DateField(null=True, blank=True)
    company = models.ForeignKey(Company, 
                related_name='company_plant_machinery_machine_transfer',
                on_delete=models.CASCADE,null=True, blank=True)
    from_contact_person = models.CharField(max_length=200, null=True, blank=True)
    mobile_no = models.CharField(max_length=50, null=True, blank=True)
    self_carrying_vehicle = models.CharField(max_length=200, null=True, blank=True)
    reason = models.TextField(null=True, blank=True)
    print_transfer_certificate = models.BooleanField(default=False)
    attachment = models.FileField(upload_to='plant_machinery/machine/transfer', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    inactive_type =  models.ForeignKey(PlantMachineryInactiveType, 
                related_name='plant_machinery_inactive_type_plant_machinery_machine_transfer',
                on_delete=models.CASCADE,null=True, blank=True)
    transfer_to_site = models.ForeignKey("procurement.SiteMaster", 
                related_name='transfer_to_site_plant_machinery_machine_transfer',
                on_delete=models.CASCADE,null=True, blank=True)
    to_contact_person = models.CharField(max_length=200, null=True, blank=True)
    to_mobile_no = models.CharField(max_length=50, null=True, blank=True)
    other_carrying_vehicle = models.CharField(max_length=200, null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    eway_bill_no = models.CharField(max_length=200, null=True, blank=True)
    transporter_name = models.CharField(max_length=200, null=True, blank=True)
  

    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_transfer"        \
        

class PlantMachineryMachineDriver(BaseAbstractStructure):
    """
    PlantMachineryMachineDriver Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_driver', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                                                               related_name='plant_machinery_machine_plant_machinery_machine_driver',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    
    name =  models.CharField(max_length=200, null=True, blank=True)
    shift =  models.CharField(max_length=200, null=True, blank=True)
    allotment_date = models.DateField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_driver"          

class PlantMachineryMachineRent(BaseAbstractStructure):
    """
    PlantMachineryMachineRent Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_rent', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                                                               related_name='plant_machinery_machine_plant_machinery_machine_rent',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    
    rent_amount = models.FloatField(default=0)
    rent_date = models.DateField(null=True, blank=True)
    rent_to_date = models.DateField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_rent"  
class PlantMachineryMachineDepreciation(BaseAbstractStructure):
    """
    PlantMachineryMachineDepreciation Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_depreciation', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                                                               related_name='plant_machinery_machine_plant_machinery_machine_depreciation',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    amount = models.FloatField(default=0)
    date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_depreciation"
class PlantMachineryMachineServiceSchedule(BaseAbstractStructure):
    """
    PlantMachineryMachineServiceSchedule Model
    """
    REPEAT_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
    ]
    CHARGEABLE_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
    ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_service_schedule', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                                                               related_name='plant_machinery_machine_plant_machinery_machine_service_schedule',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_service_group = models.ForeignKey(PlantMachineryServiceGroup, 
                                                               related_name='plant_machinery_serivce_group_plant_machinery_machine_service_schedule',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_service_item= models.ForeignKey(PlantMachineryServiceItem, related_name='plant_machinery_serivce_item_plant_machinery_machine_service_schedule', on_delete=models.CASCADE,
                              null=True, blank=True)
    service_unit= models.ForeignKey(UnitOfMesurement, related_name='service_unit_plant_machinery_machine_service_schedule', on_delete=models.CASCADE,
                              null=True, blank=True)
    service_type=  models.CharField(max_length=200, null=True, blank=True)
    repeat=  models.CharField(max_length=200,choices=REPEAT_CHOICES, null=True, blank=True)
    limit_kms_from = models.FloatField(default=0)
    limit_kms_to= models.FloatField(default=0)
    limit_days_from = models.FloatField(default=0)
    limit_days_to= models.FloatField(default=0)
    limit_hrs_from = models.FloatField(default=0)
    limit_hrs_to= models.FloatField(default=0)
    quantity= models.FloatField(default=0)
    chargeable=  models.CharField(max_length=200,choices=REPEAT_CHOICES, null=True, blank=True)
    approx_rate = models.FloatField(default=0)
    approx_amount= models.FloatField(default=0)
    part_number=  models.CharField(max_length=200, null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_service_schedule"          


class PlantMachineryMachineMaintenanceItemGroup(BaseAbstractStructure):
    """
    PlantMachineryMachineMaintenanceItemGroup  Model
    """
    COSTING_CHOICES = [
        ('cost', 'Cost'),
        ('quantity', 'Quantity'),
        ('both', 'Both'),
    ]
    ISSUE_FOR_CHOICES = [
        ('consumption', 'Consumption'),
        ('production', 'Production'),
    ]
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_machine_maintenance_item_group_organization', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_machine_maintenance_item_group_project', null=True, blank=True, on_delete=models.CASCADE)

    costing_group=  models.CharField(max_length=200, null=True, blank=True)
    display_order = models.IntegerField(default=0)
    costing=  models.CharField(max_length=200,choices=COSTING_CHOICES, null=True, blank=True)
    issue_for=  models.CharField(max_length=200,choices=ISSUE_FOR_CHOICES, null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_maintenance_item_group"


class PlantMachineryJobSheet(BaseAbstractStructure):
    TYPE = [
        ('Service', 'Service'),
        ('Maintenance', 'Maintenance'),
    ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_job_sheet', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='project_master_plant_machinery_job_sheet', blank=True, null=True, on_delete=models.CASCADE)

    jobsheet_number = models.CharField(max_length=200, blank=True, null=True)
    jobsheet_for = models.CharField(max_length=200, blank=True, null=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_job_sheet',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    vendor = models.ForeignKey(VendorMasterV2, 
            related_name='vendor_plant_machinery_job_sheet',
            on_delete=models.CASCADE,null=True, blank=True)
  
    machine_location = models.ForeignKey("procurement.StoreMaster", related_name='store_master_plant_machinery_job_sheet', blank=True, null=True, on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_job_sheet', blank=True, null=True, on_delete=models.CASCADE)

    driver_operator =models.CharField(max_length=200, blank=True, null=True)
    plant_machinery_service_group = models.ForeignKey(PlantMachineryServiceGroup,  related_name='plant_machinery_serivce_group_plant_machinery_job_sheet', on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_machine_plant_machinery_job_sheet', on_delete=models.CASCADE,null=True, blank=True)
    jobsheet_date = models.DateField(blank=True, null=True)
    jobsheet_time = models.TimeField(blank=True, null=True)
    jobsheet_type = models.CharField(max_length=200, blank=True, null=True)
    jobsheet_service_type = models.CharField(max_length=200,choices=TYPE, default='Service')
    
    # machine_no = models.CharField(max_length=200, blank=True, null=True)
    tacho_reading = models.FloatField(default=0)
    pre_km_reading =  models.FloatField(default=0)
    time_reading =  models.FloatField(default=0)
    pre_time_reading =  models.FloatField(default=0)
    estimated_time_days =models.FloatField(default=0)
    estimated_time_hours = models.FloatField(default=0)
    estimated_time_minutes = models.FloatField(default=0)
    labour_charge = models.FloatField(default=0)
    discount = models.FloatField(default=0)
    other_expenses = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    inspected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_plant_machinery_job_sheet_inspected_by", on_delete=models.CASCADE)
    defect_name_or_remark = models.TextField(blank=True, null=True)
    ##attachement
    attachment = models.FileField(upload_to='plant_machinery/job_sheet/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)    
    class Meta:
        db_table = "plant_machinery_plant_machinery_job_sheet"

class PlantMachineryJobSheetService(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_job_sheet_service', 
                                     on_delete=models.CASCADE)
    plant_machinery_job_sheet = models.ForeignKey(PlantMachineryJobSheet, on_delete=models.CASCADE, related_name='plant_machinery_job_sheet_plant_machinery_job_sheet_service',\
                                                  blank=True, null=True)
    plant_machinery_service_item = models.ForeignKey(PlantMachineryServiceItem, on_delete=models.CASCADE, related_name='plant_machinery_service_item_plant_machinery_job_sheet_service',\
                                                     blank=True, null=True)
    part_item = models.CharField(max_length=200, blank=True, null=True)
    part_item_description = models.CharField(max_length=200, blank=True, null=True)
    quantity = models.IntegerField(default=0)
    unit = models.ForeignKey(UnitOfMesurement, related_name='unit_plant_machinery_job_sheet_service', on_delete=models.CASCADE, null=True, blank=True)
    rate = models.FloatField(default=0)
    value = models.FloatField(default=0)
    mechanic_name = models.CharField(max_length=200, blank=True, null=True)
    comment = models.TextField(null=True, blank=True)    
    class Meta:
        db_table = "plant_machinery_plant_machinery_job_sheet_service"


class PlantMachineryMachineMaintenanceItemServiceGroup(BaseAbstractStructure):
    """
    PlantMachineryMachineMaintenanceItemGroup  Model
    """
    
    item_group_master = models.ForeignKey(PlantMachineryMachineMaintenanceItemGroup, 
                                                               related_name='plant_machinery_machine_maintenance_item_group',
                                                               on_delete=models.CASCADE,null=True, blank=True)
    
    organization = models.ForeignKey(Organization, related_name='plant_machinery_machine_maintenance_item_service_group_organization', 
                                     on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_service_group = models.ForeignKey(PlantMachineryServiceGroup, 
                                                               related_name='plant_machinery_serivce_group',
                                                               on_delete=models.CASCADE,null=True, blank=True)
  
    class Meta:
        db_table = "plant_machinery_machine_maintenance_item_service_group"

class PlantMachineryMeterResetLog(BaseAbstractStructure):
    """
    PlantMachineryMeterResetLog Model
    """
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_meter_reset_log', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_meter_reset_log_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                            related_name='plant_machinery_machine_plant_machinery_meter_reset_log',
                            on_delete=models.CASCADE,null=True, blank=True)
   
    meter_type=  models.CharField(max_length=200, null=True, blank=True)
    meter_number=  models.CharField(max_length=200, null=True, blank=True)
    change_date = models.DateField(null=True, blank=True)
    prev_meter_last_read= models.FloatField(default=0)
    current_meter_read = models.FloatField(default=0)
    reason=  models.TextField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_meter_reset_log" 


class PlantMachineryTyre(BaseAbstractStructure):
    """
    PlantMachineryTyre Model
    """
    POSITION_CHOICES = [
        ("LEFT FRONT", "LEFT FRONT"),
        ("LEFT REAR", "LEFT REAR"),
        ("LEFT REAR IN", "LEFT REAR IN"),
        ("LEFT REAR OUT", "LEFT REAR OUT"),
        ("LEFT CENTER IN", "LEFT CENTER IN"),
        ("LEFT CENTER OUT", "LEFT CENTER OUT"),
        ("LEFT FRONT IN", "LEFT FRONT IN"),
        ("LEFT FRONT OUT", "LEFT FRONT OUT"),
        ("RIGHT REAR", "RIGHT REAR"),
        ("RIGHT REAR IN", "RIGHT REAR IN"),
        ("RIGHT REAR OUT", "RIGHT REAR OUT"),
        ("RIGHT FRONT IN", "RIGHT FRONT IN"),
        ("RIGHT CENTER OUT", "RIGHT CENTER OUT"),
        ("RIGHT CENTER IN", "RIGHT CENTER IN"),
        ("STEPNI", "STEPNI"),
        ("FRONT", "FRONT"),
        ("REAR", "REAR"),
        ("PLAIN", "PLAIN"),
    ]

    TYRE_TYPE_CHOICES = [
        ("RESOLD", "RESOLD"),
        ("NEW", "NEW"),
        ("OLD", "OLD"),
    ]

    TYRE_TYPE1_CHOICES = [
        ("WITH TUBE", "WITH TUBE"),
        ("WITHOUT TUBE", "WITHOUT TUBE"),
    ]

    TYRE_TYPE2_CHOICES = [
        ("RADIAL", "RADIAL"),
        ("NYLON", "NYLON"),
        ("OTHER REMARKS", "OTHER REMARKS"),
    ]

   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_tyre', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_tyre_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_tyre',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                            related_name='plant_machinery_machine_plant_machinery_tyre',
                            on_delete=models.CASCADE,null=True, blank=True)
   
    tyre_serial_number=  models.CharField(max_length=200, null=True, blank=True)
    
    brand = models.ForeignKey(Brand, related_name='brand_master_plant_machinery_tyre', on_delete=models.CASCADE, null=True, blank=True)

    model = models.ForeignKey(Model, related_name='model_plant_machinery_tyre', on_delete=models.CASCADE, null=True, blank=True)
    model_text=  models.CharField(max_length=200, null=True, blank=True)
    make_text=  models.CharField(max_length=200, null=True, blank=True)
    vehicle_km_reading= models.FloatField(default=0)
    vehicle_hrs_reading = models.FloatField(default=0)
    sold_amount = models.FloatField(default=0)
    tyre_number=  models.CharField(max_length=200, null=True, blank=True)
    status=  models.CharField(max_length=200, null=True, blank=True)
    vehicle_number=  models.CharField(max_length=200, null=True, blank=True)
    issue_date = models.DateField(null=True, blank=True)
    sold_date = models.DateField(null=True, blank=True)
    position=  models.CharField(max_length=200, null=True, blank=True)
    ## purchase information
    vendor = models.ForeignKey(VendorMasterV2, 
            related_name='vendor_plant_machinery_tyre',
            on_delete=models.CASCADE,null=True, blank=True)
    purchase_date = models.DateField(null=True, blank=True)
    invoice_number=  models.CharField(max_length=200, null=True, blank=True)
    purchase_amount_cost = models.FloatField(default=0)
    ## tyre information
    size=  models.CharField(max_length=200, null=True, blank=True)
    tread = models.FloatField(default=0)
    ply_rating = models.FloatField(default=0)
    run_at_pur = models.FloatField(default=0)
    number_of_remould = models.IntegerField(default=0)
    tread_depth= models.FloatField(default=0)
    grip= models.FloatField(default=0)
    warranty_days = models.FloatField(default=0)
    warranty_km = models.FloatField(default=0)
    load_capacity= models.FloatField(default=0)
    casing= models.FloatField(default=0)
    ##new added field
    position_new= models.CharField(max_length=200, choices=POSITION_CHOICES, null=True, blank=True)  
    tyre_type = models.CharField(max_length=100, choices=TYRE_TYPE_CHOICES, null=True, blank=True)  
    tyre_type1 = models.CharField(max_length=100, choices=TYRE_TYPE1_CHOICES, null=True, blank=True)  
    tyre_type2 = models.CharField(max_length=100, choices=TYRE_TYPE2_CHOICES, null=True, blank=True)  
    std_psi = models.FloatField(default=0)  
    other_remark = models.TextField(null=True, blank=True) 
    warranty_hrs=models.FloatField(default=0)

    
    class Meta:
        db_table = "plant_machinery_plant_machinery_tyre"                  

class PlantMachineryLogBook(BaseAbstractStructure):
    """
    PlantMachineryLogBook Model
    """
    OWNER_TYPE_CHOICES = [
        ('owned', 'Owned'),
        ('hired', 'Hired'),
    ]
    FUEL_TYPE_CHOICES = [
        ('diesel', 'diesel'),
        ('petrol', 'petrol'),
    ]
    IN_SERVICE_CHOICES = [
        ('Running', 'Running'),
        ('Breakdown', 'Breakdown'),
    ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_log_book', 
                                     on_delete=models.CASCADE)
    log_book_date = models.DateField(blank=True, null=True)
    owner = models.CharField(max_length=100,choices=OWNER_TYPE_CHOICES, blank=True, null=True, default='owned')
    fueltype = models.CharField(max_length=100,choices=FUEL_TYPE_CHOICES, blank=True, null=True, default='diesel')
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_machine_plant_machinery_log_book',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_log_book',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    driver_operator = models.ForeignKey(PlantMachineryMachineDriver, related_name='plant_machinery_machine_driver_plant_machinery_log_book',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    plant_machinery_group_type = models.CharField(max_length=200, null=True, blank=True)
    location = models.ForeignKey("procurement.StoreMaster", related_name='store_master_plant_machinery_log_book', blank=True, null=True, on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_log_book', blank=True, null=True, on_delete=models.CASCADE)
    shift = models.CharField(max_length=100, blank=True, null=True)
    
    remark = models.TextField(null=True, blank=True) 
    number_of_trips = models.IntegerField(default=0)   
    quantity = models.FloatField(default=0)   
    ##attachement
    attachment = models.FileField(upload_to='plant_machinery/log_book/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)   
    request_code = models.CharField(max_length=100, null=True, blank=True)

    ###dprnew fields
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='project_master_plant_machinery_log_book', blank=True, null=True, on_delete=models.CASCADE)
    plan_hrs = models.FloatField(blank=True, null=True, default=0)
    plan_km = models.FloatField(blank=True, null=True, default=0)
    start_hrs = models.FloatField(blank=True, null=True, default=0)
    close_hrs = models.FloatField(blank=True, null=True, default=0)
    working_hrs = models.FloatField(blank=True, null=True, default=0)
    total_working_hrs = models.FloatField(blank=True, null=True, default=0)
    bd_hrs = models.FloatField(blank=True, null=True, default=0)
    idle_hrs = models.FloatField(blank=True, null=True, default=0)
    extra_working_hrs = models.FloatField(blank=True, null=True, default=0)
    start_kms = models.FloatField(blank=True, null=True, default=0)
    close_kms = models.FloatField(blank=True, null=True, default=0)
    total_km_run = models.FloatField(blank=True, null=True, default=0)
    total_fuel_filled = models.FloatField(blank=True, null=True, default=0)
    standard_norms = models.FloatField(blank=True, null=True, default=0)
    actual_norms = models.FloatField(blank=True, null=True, default=0)
    difference_norms = models.FloatField(blank=True, null=True, default=0)
    total_production_qty_cum = models.FloatField(blank=True, null=True, default=0)
    total_production_qty_ton = models.FloatField(blank=True, null=True, default=0)
    gsb_aggregate_trips = models.FloatField(blank=True, null=True, default=0)
    dbm_bc_trips = models.FloatField(blank=True, null=True, default=0)
    pqc_dlc_trips = models.FloatField(blank=True, null=True, default=0)
    soil_bt_cuttingmisc_trips = models.FloatField(blank=True, null=True, default=0)
    wmm_trips = models.FloatField(blank=True, null=True, default=0)
    total_trips = models.FloatField(blank=True, null=True, default=0)
    last_entry_date = models.DateField(blank=True, null=True)
    boq = models.CharField(max_length=100, blank=True, null=True)
    from_location = models.CharField(max_length=100, blank=True, null=True)
    from_chainage = models.CharField(max_length=100, blank=True, null=True)
    to_location = models.CharField(max_length=100, blank=True, null=True)
    to_chainage = models.CharField(max_length=100, blank=True, null=True)
    # operator_name = models.CharField(max_length=100, blank=True, null=True)
    total_days = models.IntegerField(blank=True, null=True, default=0)
    # latest_boq = models.ForeignKey("boq.BOQ", related_name='latest_boq_plant_machinery_log_book',\
    #                                            blank=True, null=True, on_delete=models.CASCADE)
    tag_wbs=models.BooleanField(default=False)
    # wbs = models.ForeignKey("boq.WBSList", related_name='wbs_plant_machinery_log_book',\
    #                                            blank=True, null=True, on_delete=models.CASCADE)
    # chainage = models.ForeignKey("boq.BOQChainage", related_name='chainage_plant_machinery_log_book',\
    #                                            blank=True, null=True, on_delete=models.CASCADE)
    in_service = models.CharField(max_length=100,choices=IN_SERVICE_CHOICES,blank=True, null=True,default='Running')
    hire_bill_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_log_book"
        
class PlantMachineryLogBookWbsChainage(BaseAbstractStructure):
    COST_TYPE_CHOICES = [
        ('indirect', 'Indirect'),
        ('normal', 'Normal'),
    ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_log_book_wbs_chainage', 
                                     on_delete=models.CASCADE)
    plant_machinery_log_book= models.ForeignKey(PlantMachineryLogBook, related_name='plant_machinery_log_book_plant_machinery_log_book_wbs_chainage',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    wbs_chainage= models.ForeignKey("boq.BOQChainageExecutiveSummeryData", related_name='wbs_chainage_plant_machinery_log_book_wbs_chainage',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    cost_type = models.CharField(max_length=100, choices=COST_TYPE_CHOICES, blank=True, null=True)
    wbs=models.ForeignKey("boq.WBSList", related_name='wbs_plant_machinery_log_book_wbs_chainage',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    boq_chainage = models.ForeignKey("boq.BOQChainage", related_name='boq_chainage_plant_machinery_log_book',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    indirect_chainage=models.ForeignKey("boq.WbsIndirectCostPlaning", related_name='indirect_chainage_plant_machinery_log_book_wbs_chainage',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    working_hrs = models.FloatField(default=0)   
    working_kms = models.FloatField(default=0)   
    from_chainage = models.FloatField(default=0)   
    to_chainage = models.FloatField(default=0)   
    class Meta:
        db_table = "plant_machinery_plant_machinery_log_book_wbs_chainage"


class PlantMachineryInsuranceMaster(BaseAbstractStructure):
    """
      PlantMachineryInsuranceMaster Model
    """
   
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_insurance_master_organizations',on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_insurance_master_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_machine_plant_machinery_insurance_master',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    insurance_head_name = models.CharField(max_length=200,null=True, blank=True)
    insurance_head_short_name = models.CharField(max_length=200,null=True, blank=True)
    category_type = models.CharField(max_length=200,null=True, blank=True)
    insurance_date= models.DateField(null=True, blank=True)
    insurance_expiry_date= models.DateField(null=True, blank=True)
    parent = models.ForeignKey('self', related_name='plant_machinery_insurance_master_parent', on_delete=models.CASCADE, blank=True, null=True)
   
    class Meta:
        db_table = "plant_machinery_plant_machinery_insurance_master"        


class PlantMachineryMachineWorking(BaseAbstractStructure):
    """
    PlantMachineryMachineWorking Model
    """
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_working', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_machine_working_project', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_machine_plant_machinery_machine_working',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_machine_working',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    machine_working_date = models.DateField(blank=True, null=True)
    voucher_number = models.CharField(max_length=200, blank=True, null=True)
    manual_slip_number = models.CharField(max_length=200, blank=True, null=True)
    shift = models.CharField(max_length=200, blank=True, null=True)
    machine_type = models.CharField(max_length=200, null=True, blank=True)
    work_type = models.CharField(max_length=200, null=True, blank=True)
    machine_location = models.ForeignKey("procurement.StoreMaster", related_name='store_master_plant_machinery_machine_working', blank=True, null=True, on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_machine_working', blank=True, null=True, on_delete=models.CASCADE)
    techo_opening = models.FloatField(default=0)
    techo_closing = models.FloatField(default=0)
    techo_km_run= models.FloatField(default=0)
    time_opening = models.FloatField(default=0)
    time_closing = models.FloatField(default=0)
    time_run_hrs = models.FloatField(default=0)
    time_run_min = models.FloatField(default=0)
    start_time = models.TimeField(blank=True, null=True)
    end_time = models.TimeField(blank=True, null=True)
    fuel_opening = models.FloatField(default=0)
    fuel_closing = models.FloatField(default=0)
    fuel_issue = models.FloatField(default=0)
    
    cons_hrs = models.FloatField(default=0)
    avg_ltr_hrs =  models.FloatField(default=0)
    full_half_day_status = models.CharField(max_length=200, null=True, blank=True)

    remark = models.TextField(null=True, blank=True) 
    ##attachement
    attachment = models.FileField(upload_to='plant_machinery/machine_working/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)    
    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_working"
class PlantMachineryMachineWorkingMeterReset(BaseAbstractStructure):
    """
    PlantMachineryMachineWorkingMeterReset Model
    """
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_working_meter_reset', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                            related_name='plant_machinery_machine_plant_machinery_machine_working_meter_reset',
                            on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_machine_working= models.ForeignKey(PlantMachineryMachineWorking, 
                            related_name='plant_machinery_machine_working_plant_machinery_machine_working_meter_reset',
                            on_delete=models.CASCADE,null=True, blank=True)
    meter_type=  models.CharField(max_length=200, null=True, blank=True)
    meter_number=  models.CharField(max_length=200, null=True, blank=True)
    prev_meter_last_read= models.FloatField(default=0)
    current_meter_read = models.FloatField(default=0)
    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_working_meter_reset" 

class PlantMachineryMachineWorkingFuelIssue(BaseAbstractStructure):
    """
    PlantMachineryMachineWorkingFuelIssue Model
    """
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_working_fuel_issue', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                            related_name='plant_machinery_machine_plant_machinery_machine_working_fuel_issue',
                            on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_machine_working= models.ForeignKey(PlantMachineryMachineWorking, 
                            related_name='plant_machinery_machine_working_plant_machinery_machine_working_fuel_issue',
                            on_delete=models.CASCADE,null=True, blank=True)
    item_name=  models.CharField(max_length=200, null=True, blank=True)
    issue_number=  models.CharField(max_length=200, null=True, blank=True)
    shift=  models.CharField(max_length=200, null=True, blank=True)
    quantity= models.FloatField(default=0)
    total= models.CharField(max_length=200, null=True, blank=True)
    full_tank=  models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_working_fuel_issue"         

class PlantMachineryMachineWorkingChild(BaseAbstractStructure):
    """
    PlantMachineryMachineWorkingChild (working child table) Model
    """
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_working_child', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                            related_name='plant_machinery_machine_plant_machinery_machine_working_child',
                            on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_machine_working= models.ForeignKey(PlantMachineryMachineWorking, 
                            related_name='plant_machinery_machine_working_plant_machinery_machine_working_child',
                            on_delete=models.CASCADE,null=True, blank=True)
    driver_operator = models.ForeignKey(PlantMachineryMachineDriver, related_name='plant_machinery_machine_driver_plant_machinery_machine_working_child',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    helper = models.CharField(max_length=200, null=True, blank=True)

    location = models.ForeignKey("procurement.StoreMaster", related_name='store_master_plant_machinery_machine_working_child', blank=True, null=True, on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_machine_working_child', blank=True, null=True, on_delete=models.CASCADE)
    trip = models.FloatField(default=0)
    allot_task = models.CharField(max_length=200, null=True, blank=True)
    work_order = models.CharField(max_length=200, null=True, blank=True)
    item_name = models.CharField(max_length=200, null=True, blank=True)

    load_number = models.FloatField(default=0)
    load_length = models.FloatField(default=0)
    load_width = models.FloatField(default=0)
    load_depth = models.FloatField(default=0)
    wise = models.CharField(max_length=200, null=True, blank=True)
    unit = models.ForeignKey(UnitOfMesurement, related_name='unit_plant_machinery_machine_working_child', on_delete=models.CASCADE,
                              null=True, blank=True)
    quantity_trip = models.FloatField(default=0)
    from_time = models.TimeField(blank=True, null=True)
    to_time = models.TimeField(blank=True, null=True)
    total_time = models.CharField(max_length=100, blank=True, null=True)
    time_from_reading = models.FloatField(default=0)
    time_to_reading =  models.FloatField(default=0)
    time_total_reading =  models.FloatField(default=0)
    work_category = models.CharField(max_length=200, null=True, blank=True)
    work_type = models.CharField(max_length=200, null=True, blank=True)
    rate =  models.FloatField(default=0)
    inter_chainage = models.FloatField(default=0)
    chainage_from =  models.FloatField(default=0)
    chainage_to=  models.FloatField(default=0)
    chainage_run =  models.FloatField(default=0)
    total_charge =  models.FloatField(default=0)
    remark = models.TextField(blank=True, null=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_working_child"        



class PlantMachineryMachineWorkingIdleBd(BaseAbstractStructure):
    """
    PlantMachineryMachineWorkingIdleBd  Model
    """
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_working_idle_bd', 
                                     on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, 
                            related_name='plant_machinery_machine_plant_machinery_machine_working_idle_bd',
                            on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_machine_working= models.ForeignKey(PlantMachineryMachineWorking, 
                            related_name='plant_machinery_machine_working_plant_machinery_machine_working_idle_bd',
                            on_delete=models.CASCADE,null=True, blank=True)
    driver_operator = models.ForeignKey(PlantMachineryMachineDriver, related_name='plant_machinery_machine_driver_plant_machinery_machine_working_idle_bd',\
                                               blank=True, null=True, on_delete=models.CASCADE)
    type = models.CharField(max_length=200, null=True, blank=True)
   
    from_time = models.TimeField(blank=True, null=True)
    to_time = models.TimeField(blank=True, null=True)
    hours =  models.FloatField(default=0)
    minutes =  models.FloatField(default=0)
    reason = models.TextField(blank=True, null=True)
    action_taken = models.TextField(blank=True, null=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_machine_working_idle_bd"         
class PlantMachineryManpowerDesignation(BaseAbstractStructure):
    """
    PlantMachineryManpowerDesignation Model
    """
    name = models.CharField(max_length=255, null=False, blank=False)
class PlantMachineryManpower(BaseAbstractStructure):
    """
    PlantMachineryManpower Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_manpower', on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_man_power_project', null=True, blank=True, on_delete=models.CASCADE)
    current_location = models.CharField(max_length=255, null=True, blank=True)
    employee_id = models.CharField(max_length=100, unique=True, null=False, blank=False)
    name_of_employee = models.CharField(max_length=255, null=False, blank=False)
    fathers_name = models.CharField(max_length=255, null=False, blank=False)
    department = models.CharField(max_length=255, null=True, blank=True)
    designation = models.CharField(max_length=255, null=True, blank=True)
    category = models.CharField(max_length=255, null=True, blank=True)
    date_of_joining = models.DateField(null=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    aadhar_no = models.CharField(max_length=30, null=True, blank=True)
    pan_card_no = models.CharField(max_length=30, null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    licence_no = models.CharField(max_length=100, null=True, blank=True)
    licence_issue_date = models.DateField(null=True, blank=True)
    licence_validity = models.DateField(null=True, blank=True)
    mobile_no = models.CharField(max_length=30, null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=50, null=True, blank=True)
    date_of_exit = models.DateField(null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_man_power"           

class PlantMachineryActivityGroup(BaseAbstractStructure):
    """
    PlantMachineryActivityGroup Model
    """
    
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_activity_group',
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_activity_group_project', blank=True, null=True, on_delete=models.CASCADE)

    code = models.CharField(max_length=200, null=True, blank=True)
    remark = models.TextField(null=True, blank=True)

    class Meta:
        # unique_together = ('project', 'code',)
        db_table = "plant_machinery_plant_machinery_activity_group"

class PlantMachineryActivityGroupItems(BaseAbstractStructure):
    """
    PlantMachineryActivityGroupItems
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_activity_group_items',
                                     on_delete=models.CASCADE)
    
    plant_machinery_activity_group = models.ForeignKey(PlantMachineryActivityGroup,related_name='plant_machinery_activity_group_plant_machinery_activity_group_items',\
                                                       on_delete=models.CASCADE, null=True, blank=True)
    

    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_machine_plant_machinery_activity_group_items',
                                on_delete=models.CASCADE,null=True, blank=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_activity_group_items',on_delete=models.CASCADE, null=True, blank=True)

    uom = models.ForeignKey(UnitOfMesurement, related_name='uom_plant_machinery_activity_group_items',on_delete=models.CASCADE, null=True, blank=True)

    code=models.CharField(max_length=200, null=True, blank=True)
    productivity = models.FloatField(default=0.0)
    efficiency_loss_monsoon = models.FloatField(default=0.0)
    efficiency_normal_condn = models.FloatField(default=0.0)
    fuel_efficiency = models.FloatField(default=0.0)
    working_hrs_per_month = models.FloatField(default=0.0)
    fuel_norms = models.FloatField(default=0.0)
    machine_rental = models.FloatField(default=0.0)
  
    class Meta:
        db_table = "plant_machinery_plant_machinery_activity_group_items"
        # unique_together = ('plant_machinery_activity_group', 'plant_machinery_machine')


class PlantMachineryFuelTransaction(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_fuel_transaction',
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_fuel_transaction_projects', null=True, blank=True, on_delete=models.CASCADE)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_plant_machinery_fuel_transaction_plant_machinery_machine', null=True, blank=True, on_delete=models.CASCADE)
    ref_id=models.CharField(max_length=200, null=True, blank=True)
    data = models.JSONField(null=True, blank=True)
  
    class Meta:
        db_table = "plant_machinery_plant_machinery_fuel_transaction"


class PlantMachineryNotifications(BaseAbstractStructure):
    ref_type = models.CharField(max_length=200, null=True, blank=True)
    ref_id = models.CharField(max_length=200, null=True, blank=True)
    data = models.JSONField(null=True, blank=True)
    seen_by = models.ManyToManyField(PmsUser, related_name='plant_machinery_plant_machinery_notifications_seen_by', null=True, blank=True, )
  
    class Meta:
        db_table = "plant_machinery_plant_machinery_notifications"


class PlantMachineryMIS(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_mis_organizations', on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_mis_projects', null=True, blank=True, on_delete=models.CASCADE)
    type = models.CharField(max_length=200, null=True, blank=True)
    months = models.CharField(max_length=200, null=True, blank=True)
    plant_model = models.CharField(max_length=200, null=True, blank=True)
    log_no = models.CharField(max_length=200, null=True, blank=True)
    production_ftm = models.CharField(max_length=200, null=True, blank=True)
    total_cost_norms = models.CharField(max_length=200, null=True, blank=True)
    energy_cost_norms = models.CharField(max_length=200, null=True, blank=True)
    energy_cost_ftm = models.CharField(max_length=200, null=True, blank=True)
    rm_cost_norms = models.CharField(max_length=200, null=True, blank=True)
    rm_cost_ftm = models.CharField(max_length=200, null=True, blank=True)
    om_cost_norms = models.CharField(max_length=200, null=True, blank=True)
    om_cost_ftm = models.CharField(max_length=200, null=True, blank=True)
    dgelectricity_ratio_dg = models.CharField(max_length=200, null=True, blank=True)
    dgelectricity_ratio_elec = models.CharField(max_length=200, null=True, blank=True)
    project_name = models.CharField(max_length=200, null=True, blank=True)
    total_nos = models.CharField(max_length=200, null=True, blank=True)
    total_km_run = models.CharField(max_length=200, null=True, blank=True)
    transported_qty = models.CharField(max_length=200, null=True, blank=True)
    total_cost_ftm = models.CharField(max_length=200, null=True, blank=True)
    saving_loss_n_to_ftm = models.CharField(max_length=200, null=True, blank=True)
    hsd_cost_norms = models.CharField(max_length=200, null=True, blank=True)
    hsd_cost_ftm = models.CharField(max_length=200, null=True, blank=True)
    avg_trip_tipper_day = models.CharField(max_length=200, null=True, blank=True)
    avg_kms_tipper_day = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_mis"


class PlantMachineryHireBill(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_plant_machinery_hire_bill', on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_hire_bill_project', blank=True, null=True, on_delete=models.CASCADE)
    months = models.CharField(max_length=100, blank=True, null=True)
    machinery_vehicle_description = models.CharField(max_length=100, blank=True, null=True)
    equipment_reg_no = models.CharField(max_length=100, blank=True, null=True)
    equipment_log_no = models.CharField(max_length=100, blank=True, null=True)
    wo_no = models.CharField(max_length=100, blank=True, null=True)
    bill_no_invoice_no = models.CharField(max_length=100, blank=True, null=True)
    vendor_code = models.CharField(max_length=100, blank=True, null=True)
    vendor_name = models.CharField(max_length=100, blank=True, null=True)
    bill_date = models.CharField(max_length=100, blank=True, null=True)
    bill_period_from = models.CharField(max_length=100, blank=True, null=True)
    bill_period_to = models.CharField(max_length=100, blank=True, null=True)
    rate = models.CharField(max_length=100, blank=True, null=True)
    working_hrs_km = models.CharField(max_length=100, blank=True, null=True)
    total_hsd = models.CharField(max_length=100, blank=True, null=True)
    working_days = models.CharField(max_length=100, blank=True, null=True)
    idle_days = models.CharField(max_length=100, blank=True, null=True)
    bd_days = models.CharField(max_length=100, blank=True, null=True)
    bill_amount = models.CharField(max_length=100, blank=True, null=True)
    misc = models.CharField(max_length=100, blank=True, null=True)
    tds = models.CharField(max_length=100, blank=True, null=True)
    gst = models.CharField(max_length=100, blank=True, null=True)
    gst_amount = models.CharField(max_length=100, blank=True, null=True)
    bd_deduction = models.CharField(max_length=100, blank=True, null=True)
    diesel_amount_debit = models.CharField(max_length=100, blank=True, null=True)
    total_payable_amtount_rs = models.CharField(max_length=100, blank=True, null=True)
    other_deduction = models.CharField(max_length=100, blank=True, null=True)
    date_on_which = models.CharField(max_length=100, blank=True, null=True)
    bill_sumbited_to_accounts = models.CharField(max_length=100, blank=True, null=True)
    std_avg = models.CharField(max_length=100, blank=True, null=True)
    actual_avg = models.CharField(max_length=100, blank=True, null=True)
    remarks = models.TextField(null=True, blank=True)
    attachment = models.FileField(upload_to='plant_machinery/hire_bill/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_plant_machinery_hire_bill"

class PlantMachineryBattery(BaseAbstractStructure):
    """
    PlantMachineryBattery Model
    """
    # BATTERY_TYPE_CHOICES = [
    #     ("Aluminium-ion battery", "Aluminium-ion battery"),
    #     ("Lead–acid battery", "Lead–acid battery"),
    #     ("Rechargeable lithium–metal battery", "Rechargeable lithium–metal battery"),
    #     ("Magnesium-ion battery", "Magnesium-ion battery"),
    #     ("Nickel–cadmium battery", "Nickel–cadmium battery"),
    #     ("Nickel–zinc battery", "Nickel–zinc battery"),
    #     ("Zinc ion battery", "Zinc ion battery"),
    #     ("Galvanic cell", "Galvanic cell"),
    #     ("Dry cell", "Dry cell"),
    # ]

    organization = models.ForeignKey(
        Organization,
        related_name='organizations_plant_machinery_battery',
        on_delete=models.CASCADE
    )
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_plant_machinery_battery_project',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    plant_machinery_group = models.ForeignKey(
        PlantMachineryGroup,
        related_name='plant_machinery_group_plant_machinery_battery',
        blank=True,
        null=True,
        on_delete=models.CASCADE
    )
    plant_machinery_machine = models.ForeignKey(
        PlantMachineryMachine,
        related_name='plant_machinery_machine_plant_machinery_battery',
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
   
    battery_serial_number = models.CharField(max_length=200, null=True, blank=True)
    
    brand = models.ForeignKey(
        Brand,
        related_name='brand_master_plant_machinery_battery',
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    model = models.ForeignKey(
        Model,
        related_name='model_plant_machinery_battery',
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    equipment_model = models.CharField(max_length=200, null=True, blank=True)
    equipment_text = models.CharField(max_length=200, null=True, blank=True)

    # Vehicle/usage-specific fields
    fitment_km_reading = models.FloatField(default=0)
    fitment_hrs_reading = models.FloatField(default=0)
    sold_amount = models.FloatField(default=0)
    status = models.CharField(max_length=200, null=True, blank=True)
    vehicle_number = models.CharField(max_length=200, null=True, blank=True)
    fitment_date = models.DateField(null=True, blank=True)
    sold_date = models.DateField(null=True, blank=True)

    # Purchase information
    vendor = models.ForeignKey(
        VendorMasterV2,
        related_name='vendor_plant_machinery_battery',
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    purchase_date = models.DateField(null=True, blank=True)
    invoice_number = models.CharField(max_length=200, null=True, blank=True)
    purchase_amount_cost = models.FloatField(default=0)

    # tyre information
    battery_type = models.CharField(max_length=200, null=True, blank=True)
    size = models.FloatField(default=0)  
    tread =models.FloatField(default=0)  
    warranty_km = models.FloatField(default=0)
    warranty_hrs = models.FloatField(default=0)
    other_remark = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_battery"


class PlantMachineryComplianceMaster(BaseAbstractStructure):
    """
    PlantMachineryComplianceMaster Model
    """
    
    organization = models.ForeignKey(
        Organization,
        related_name='organizations_plant_machinery_compliance_master',
        on_delete=models.CASCADE
    )
    
   
    name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_compliance_master"

class PlantMachineryComplianceMasterDetail(BaseAbstractStructure):
    """
    Compliance Detail related to the PlantMachineryComplianceMaster
    """
    organization = models.ForeignKey(
        Organization,
        related_name='organizations_plant_machinery_compliance_master_detail',
        on_delete=models.CASCADE
    )
    
    compliance_master = models.ForeignKey(
        PlantMachineryComplianceMaster,
        related_name='compliance_master_plant_machinery_compliance_master_detail',
        on_delete=models.CASCADE,null=True, blank=True
    )

    name = models.CharField(max_length=300, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_compliance_master_detail"


class PlantMachineryComplianceReport(BaseAbstractStructure):
    """
    Compliance Report Model
    """
 
    organization = models.ForeignKey(
        Organization,
        related_name='organizations_plant_machinery_compliance_report',
        on_delete=models.CASCADE
    )
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_plant_machinery_compliance_report_projects',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    plant_machinery_machine = models.ForeignKey(
        PlantMachineryMachine,
        related_name='plant_machinery_machine_plant_machinery_compliance_report',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    compliance_master = models.ForeignKey(
        PlantMachineryComplianceMaster,
        related_name='compilance_master_plant_machinery_compliance_report',
        on_delete=models.CASCADE,null=True, blank=True
    )
    capacity = models.CharField(max_length=200, null=True, blank=True)
   
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_compliance_report"

class PlantMachineryComplianceReportItem(BaseAbstractStructure):
    """
    PlantMachineryComplianceReportItem Report Model(child table)
    """
    STATUS_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
        ('not_applicable', 'Not Applicable')
    ]

    organization = models.ForeignKey(
        Organization,
        related_name='organizations_plant_machinery_compliance_report_item',
        on_delete=models.CASCADE
    )
 
    compliance_report= models.ForeignKey(
        PlantMachineryComplianceReport,
        related_name='compilance_report_plant_machinery_compliance_report_item',
        on_delete=models.CASCADE,null=True, blank=True
    )
    compliance_master_detail = models.ForeignKey(
        PlantMachineryComplianceMasterDetail,
        related_name='compilance_master_detail_plant_machinery_compliance_report',
        on_delete=models.CASCADE,null=True, blank=True
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        null=True,
        blank=True
    )

    vendor = models.ForeignKey(
        VendorMasterV2,
        related_name='vendor_plant_machinery_compliance_report_item',
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    compliance_date = models.DateField(null=True, blank=True)
    next_schedule_date = models.DateField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    attachment = models.FileField(upload_to='plant_machinery/compliance_reports/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)

   
    
    class Meta:
        db_table = "plant_machinery_plant_machinery_compliance_report_item"        

class PlantMachineryCallibrationReport(BaseAbstractStructure):
    """
    Callibration Model related to the Compliance Report
    """
    STATUS_CHOICES = [
        ('yes', 'Yes'),
        ('no', 'No'),
        ('not_applicable', 'Not Applicable')
    ]
    
    organization = models.ForeignKey(
        Organization,
        related_name='organizations_plant_machinery_callibration',
        on_delete=models.CASCADE
    )
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_plant_machinery_callibration_report_projects',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    plant_machinery_machine = models.ForeignKey(
        PlantMachineryMachine,
        related_name='plant_machinery_machine_plant_machinery_callibration',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    callibration_type = models.CharField(
        max_length=200,
        null=True,
        blank=True
    )
    
    status = models.CharField(
        max_length=100,
        choices=STATUS_CHOICES,
        null=True,
        blank=True
    )
    
    vendor = models.ForeignKey(
        VendorMasterV2,
        related_name='vendor_plant_machinery_callibration',
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    capacity = models.CharField(
        max_length=300,
        null=True,
        blank=True
    )
    frequency = models.FloatField(default=0)
    
    compliance_date = models.DateField(null=True, blank=True)
    next_schedule_date = models.DateField(null=True, blank=True)
    
   
    
    remarks = models.TextField(null=True, blank=True)
    
    attachment = models.FileField(
        upload_to='plant_machinery/callibrations/',
        null=True,
        blank=True
    )
    
    mime_type = models.CharField(
        max_length=200,
        null=True,
        blank=True
    )
    
    file_data = models.TextField(
        null=True,
        blank=True
    )

    class Meta:
        db_table = "plant_machinery_plant_machinery_callibration_report"



class PlantMachineryBudgetMaster(BaseAbstractStructure):
    """
    PlantMachineryBudgetMaster Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_budget_master', 
                                     on_delete=models.CASCADE)
   
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_budget_master_projects',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    name = models.CharField(max_length=255,null=True, blank=True)
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    latest = models.BooleanField(default=True)
    class Meta:
        db_table = "plant_machinery_budget_master"  



class PlantMachineryMachineBudget(BaseAbstractStructure):
    """
    PlantMachineryMachineBudget Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_machine_budget', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_machine_budget_project',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    plant_machinery_machine = models.ForeignKey(
        PlantMachineryMachine,
        related_name='plant_machinery_machine_plant_machinery_machine_budget',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    plant_machinery_group = models.ForeignKey(
        PlantMachineryGroup,
        related_name='plant_machinery_group_plant_machinery_machine_budget',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    budget_master = models.ForeignKey(
        PlantMachineryBudgetMaster,
        related_name='budget_master_plant_machinery_machine_budget',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    amount = models.FloatField(default=0)

    class Meta:
        db_table = "plant_machinery_machine_budget"


class PlantMachineryElectricityBudget(BaseAbstractStructure):
    """
    PlantMachineryElectricityBudget Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_electricity_budget', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_electricity_budget_projects',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    budget_master = models.ForeignKey(
        PlantMachineryBudgetMaster,
        related_name='budget_master_plant_machinery_electricity_budget',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    date=models.DateField(null=True, blank=True)
    amount = models.FloatField(default=0)
    remarks= models.TextField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_electricity_budget"


class PlantMachineryFuelBudget(BaseAbstractStructure):
    """
    PlantMachineryFuelBudget Model
    """
    FUEL_TYPE_CHOICES = [
        ('HSD', 'HSD'),
        ('Petrol', 'Petrol'),
    ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_fuel_budget', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_fuel_budget_project',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    budget_master = models.ForeignKey(
        PlantMachineryBudgetMaster,
        related_name='budget_master_plant_machinery_fuel_budget',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    date=models.DateField(null=True, blank=True)
    amount = models.FloatField(default=0)
    fuel_type=models.CharField(max_length=100,choices=FUEL_TYPE_CHOICES,null=True,blank=True)

    class Meta:
        db_table = "plant_machinery_fuel_budget"                       



class PlantMachineryElectricityEntry(BaseAbstractStructure):
    """
    PlantMachineryElectricityEntry Model
    """
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_electricity_entry', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_electricity_entry_project',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    date=models.DateField(null=True, blank=True)
    amount = models.FloatField(default=0)
    remarks= models.TextField(null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_electricity_entry"          



class PlantMachineryElectricityEntryAttachment(BaseAbstractStructure):
    """
    PlantMachineryElectricityEntryAttachment Model
    """
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_electricity_entry_attachment', 
                                     on_delete=models.CASCADE)
    
    electricity_entry = models.ForeignKey(
       PlantMachineryElectricityEntry,
        related_name='electricity_entry_plant_machinery_electricity_entry_attachment',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    attachment = models.FileField(upload_to='plant_machinery/electricity_entry/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_electricity_entry_attachment"                  



class PlantMachineryHsdIssuedReport(BaseAbstractStructure):
    """
      PlantMachineryHsdIssuedReport Model
    """
   
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_hsd_issued_report_organization',on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_hsd_issued_report_project', null=True, blank=True, on_delete=models.CASCADE)
    approved_quantity = models.FloatField(default=0)
    procured_quantity = models.FloatField(default=0)
    start_date= models.DateField(null=True, blank=True)
    end_date= models.DateField(null=True, blank=True)
    requirement_received_from_site = models.FloatField(default=0)
   
    class Meta:
        db_table = "plant_machinery_plant_machinery_hsd_issued_report"                

class PlantMachineryHsdIssuedReportItem(BaseAbstractStructure):
   
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_hsd_issued_report_item_organizations',on_delete=models.CASCADE)
    plant_machinery_hsd_issued_report = models.ForeignKey(PlantMachineryHsdIssuedReport, related_name='plant_machinery_hsd_issued_report_item_plant_machinery_hsd_issued_report', on_delete=models.CASCADE,null=True, blank=True)
    date= models.DateField(null=True, blank=True)
    datewise_procured_quantity = models.FloatField(default=0)
   
    class Meta:
        db_table = "plant_machinery_plant_machinery_hsd_issued_report_item"


class PlantMachineryRepair(BaseAbstractStructure):
    REPAIR_TYPE = [
        ('Inside', 'Inside'),
        ('Outside', 'Outside'),
    ]
    organization = models.ForeignKey(Organization, related_name='plant_machinery_plant_machinery_repair_organization',on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='plant_machinery_plant_machinery_repair_project', on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, related_name='plant_machinery_plant_machinery_repair_plant_machinery_machine', on_delete=models.CASCADE,null=True, blank=True)
    bill_no = models.CharField(max_length=200, null=True, blank=True)
    repair_type = models.CharField(max_length=100,choices=REPAIR_TYPE,null=True,blank=True,default='Inside')
    date = models.DateField(null=True, blank=True)
    hmr_kmr_cumulative = models.FloatField(default=0)
    spares = models.FloatField(default=0)
    lubricants = models.FloatField(default=0)
    wear_and_tear = models.FloatField(default=0)
    adblue = models.FloatField(default=0)
    labour = models.FloatField(default=0)
    total = models.FloatField(default=0)
    attachment = models.FileField(upload_to='plant_machinery/repair/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_plant_machinery_repair"


class PlantMachineryRepairBudget(BaseAbstractStructure):
    """
    PlantMachineryRepairBudget Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_repair_budget', on_delete=models.CASCADE)
    project = models.ForeignKey(
        "project_and_planning.ProjectMaster",
        related_name='plant_machinery_repair_budget_project',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    
    budget_master = models.ForeignKey(
        PlantMachineryBudgetMaster,
        related_name='budget_master_plant_machinery_repair_budget',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup, related_name='plant_machinery_group_plant_machinery_repair_budget', blank=True, null=True, on_delete=models.CASCADE)
    date=models.DateField(null=True, blank=True)
    amount = models.FloatField(default=0)
    remarks= models.TextField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_repair_budget"


class PlantMachineryAssetRequisition(BaseAbstractStructure):
    """
    Asset Requisition 
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_asset_requisition', on_delete=models.CASCADE)

    project = models.ForeignKey(
        "project_and_planning.ProjectMaster", 
        related_name='project_plant_machinery_asset_requisition', 
        on_delete=models.CASCADE , null=True, blank=True
    )
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_asset_requisition', blank=True, null=True, on_delete=models.CASCADE)
    store = models.ForeignKey("procurement.StoreMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='store_master_plant_machinery_asset_requisition',)
    financialyear = models.ForeignKey("procurement.FinancialYear", related_name='financial_year_plant_machinery_asset_requisition', on_delete=models.CASCADE, blank=True, null=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    previous_version = models.ForeignKey('self', related_name='plant_machinery_asset_requisition_previous_version',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=255, null=True, blank=True)
    version = models.IntegerField(default=1)
    date = models.DateField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    required_duration = models.IntegerField(default=0)
    current_stage = models.IntegerField(default=0)
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    
     # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='plant_machinery_asset_requisition_ref_stage_type', blank=True, null=True, on_delete=models.CASCADE)

    class Meta:
        db_table = "plant_machinery_asset_requisition"

class PlantMachineryAssetRequisitionItem(BaseAbstractStructure):
    """
    PlantMachineryAssetRequisitionItem Model
    """
    # WORK_ACTIVITY_LOCATION_CHOICES = [
    #     ('For staff mobilization', 'For staff mobilization'),
    #     ('Survey work', 'Survey work'),
        
    # ]
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_asset_requisition_item', on_delete=models.CASCADE)
    asset_requisition = models.ForeignKey(
        PlantMachineryAssetRequisition,
        related_name='asset_requisition_plant_machinery_asset_requisition_item',
        on_delete=models.CASCADE, null=True,blank=True,
    )
    
    plant_machinery_group = models.ForeignKey(
        PlantMachineryGroup,
        related_name='plant_machinery_group_plant_machinery_asset_requisition_item',
        blank=True,
        null=True,
        on_delete=models.CASCADE
    )
    quantity = models.IntegerField(default=0)
    availability = models.IntegerField(default=0)
    project_requirement = models.IntegerField(default=0)
    type_of_work_or_activity_and_location = models.CharField(
        max_length=255,  blank=True, null=True)
    remarks = models.TextField(null=True, blank=True)
    required_date=models.DateField(null=True, blank=True)
    is_replacement = models.BooleanField(default=False)
    plant_machinery_machines= models.ManyToManyField(PlantMachineryMachine, related_name="plant_machinery_machines_plant_machinery_asset_requisition_item", null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_asset_requisition_item"

class PlantMachineryAssetRequisitionAttachments(BaseAbstractStructure):
    """
    PlantMachinery Asset Requisition Attachments
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_asset_requisition_attachment', on_delete=models.CASCADE)
    asset_requisition = models.ForeignKey(
        PlantMachineryAssetRequisition,
        related_name='asset_requisition_plant_machinery_asset_requisition_attachment',
        on_delete=models.CASCADE, null=True,blank=True,
    )
    attachment = models.FileField(upload_to='plant_machinery/asset_requisition', null=True, blank=True)
    mime_type = models.CharField(max_length=255, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_asset_requisition_attachments"

class PlantMachineryAssetRequisitionStages(BaseAbstractStructure):
    """
    Stages
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_asset_requisition_stages', on_delete=models.CASCADE)
    asset_requisition = models.ForeignKey(
            PlantMachineryAssetRequisition,
            related_name='asset_requisition_plant_machinery_asset_requisition_stages',
            on_delete=models.CASCADE, null=True,blank=True,
        )    
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_stages_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_stages_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_stages_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_stages_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_asset_requisition_stages_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    is_web = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.asset_requisition} -> {self.stage} {self.status}"

    class Meta:
        db_table = "plant_machinery_asset_requisition_stages"


class PlantMachineryRFQVendors(BaseAbstractStructure):
    """
    PlantMachinery Enquiry
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_rfq_vendor',
                                     on_delete=models.CASCADE)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    vendor = models.ManyToManyField(VendorMasterV2, related_name='vendor_plant_machinery_rfq_vendor', null=True, blank=True)
    site = models.ForeignKey("procurement.SiteMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='site_plant_machinery_rfq_vendor')
    store = models.ForeignKey("procurement.StoreMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='store_plant_machinery_rfq_vendor')
    project = models.ForeignKey("project_and_planning.ProjectMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='project_plant_machinery_rfq_vendor')
    request_code = models.CharField(max_length=100, null=True, blank=True)
    manual_slip_number = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    validity_date = models.DateField(null=True, blank=True)
    enquiry_subject = models.CharField(max_length=255, null=True, blank=True)
    jurisdiction = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    terms_and_condition = models.TextField(null=True, blank=True)
    required_duration = models.IntegerField(default=0)
    asset_requisition = models.ForeignKey(PlantMachineryAssetRequisition, related_name="asset_requisition_plant_machinery_rfq_vendor", on_delete=models.CASCADE, null=True, blank=True)
    asset_requisitions= models.ManyToManyField(PlantMachineryAssetRequisition, related_name="asset_requisitions_plant_machinery_rfq_vendor", null=True, blank=True)## added for multiple AR

    financialyear = models.ForeignKey("procurement.FinancialYear", related_name='financial_year_plant_machinery_rfq_vendor', on_delete=models.CASCADE, blank=True, null=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_rfq_vendor_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_rfq_vendor_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_rfq_vendor_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_rfq_vendor_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_rfq_vendor_rejected_by", on_delete=models.CASCADE)
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    cst_title = models.CharField(max_length=255, null=True, blank=True)
    scope_of_supply = models.TextField(null=True, blank=True)
    is_archived = models.BooleanField(default=False)

    class Meta:
        db_table = "plant_machinery_rfq_vendor"

class PlantMachineryRFQVendorsMailList(BaseAbstractStructure):
    """
    PlantMachinery RFQVendors Mails
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_rfq_vendor_mail',
                                     on_delete=models.CASCADE)
    plant_machinery_rfq_vendor = models.ForeignKey(PlantMachineryRFQVendors, related_name='plant_machiner_rfq_vendors_plant_machinery_rfq_vendor_mail', on_delete=models.CASCADE,
                                    null=True, blank=True)
    vendor = models.ForeignKey(VendorMasterV2, related_name='vendor_plant_machinery_rfq_vendor_mail',
                               on_delete=models.CASCADE, null=True, blank=True)
    email_send = models.ForeignKey(EmailSend, related_name="email_send_plant_machinery_rfq_vendor_mail",
                                   on_delete=models.CASCADE, null=True, blank=True)
    allow_revision = models.BooleanField(default=True)

    class Meta:
        db_table = "plant_machinery_rfq_vendor_mails"

class PlantMachineryRFQVendorsItems(BaseAbstractStructure):
    """
    Plant Machinery RFQVendors Items
    """
    PRIORITIES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_rfq_vendor_items',
                                     on_delete=models.CASCADE)
    plant_machinery_rfq_vendor = models.ForeignKey(PlantMachineryRFQVendors, related_name='plant_machinery_rfq_vendor_plant_machinery_rfq_vendor_items', on_delete=models.CASCADE,
                                    null=True, blank=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup,
                                          related_name='plant_machinery_group_plant_machinery_rfq_vendor_items',
                                          on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.IntegerField(default=0)
    availability = models.IntegerField(default=0)
    project_requirement = models.IntegerField(default=0)
    type_of_work_or_activity_and_location = models.CharField(max_length=255,  blank=True, null=True)
    remarks = models.TextField(null=True, blank=True)
    required_date=models.DateField(null=True, blank=True)
    sanctioned_quantity = models.FloatField(default=0)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    last_purchased_rate = models.FloatField(default=0)
    last_purchased_reference = models.TextField(max_length=500, null=True, blank=True)
    # other model links #
    asset_requisition_item = models.ForeignKey(PlantMachineryAssetRequisitionItem, related_name="asset_requisition_item_plant_machinery_rfq_vendor_items", on_delete=models.CASCADE, null=True, blank=True)
    is_replacement = models.BooleanField(default=False)
    plant_machinery_machines= models.ManyToManyField(PlantMachineryMachine, related_name="plant_machinery_machines_plant_machinery_rfq_vendor_items", null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_rfq_vendor_items"


class PlantMachineryQuotation(BaseAbstractStructure):
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_quotation',
                                     on_delete=models.CASCADE)
    vendor = models.ForeignKey(VendorMasterV2, related_name='vendor_plant_machinery_quotation', on_delete=models.CASCADE,
                               null=True, blank=True)
    vendor_state = models.ForeignKey(State, related_name='vendor_state_plant_machinery_quotation',
                                     on_delete=models.CASCADE, null=True, blank=True)
    gst_number = models.CharField(max_length=200, null=True, blank=True)
    site = models.ForeignKey("procurement.SiteMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='site_plant_machinery_quotation')
    store = models.ForeignKey("procurement.StoreMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='store_plant_machinery_quotation')
    project = models.ForeignKey("project_and_planning.ProjectMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='project_plant_machinery_quotation')
    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="vat")
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    address = models.TextField(max_length=500, null=True, blank=True)
    previous_version = models.ForeignKey('self', related_name='previous_version_plant_machinery_quotation',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    version = models.IntegerField(default=1)
    vendor_quotation_number = models.CharField(max_length=200, null=True, blank=True)
    delivery_days = models.IntegerField(default=0)
    delivery_state = models.ForeignKey(State, related_name='delivery_state_plant_machinery_quotation',
                                       on_delete=models.CASCADE, null=True, blank=True)
    payment_mode = models.CharField(max_length=200, null=True, blank=True)
    payment_days = models.IntegerField(default=0)
    purchase_type = models.CharField(max_length=200, null=True, blank=True)
    revised_quotation = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    payment_terms = models.TextField(max_length=500, null=True, blank=True)
    rate_validity = models.TextField(max_length=500, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    advance_percentage = models.FloatField(default=0)
    advance_amount = models.FloatField(default=0)
    against_c_form = models.BooleanField(default=False)

    total_before_gst_amount = models.FloatField(default=0)
    total_after_gst_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    required_duration = models.FloatField(default=0)
    total_amount_for_required_duration = models.FloatField(default=0)
    warranty = models.TextField(max_length=500, null=True, blank=True)
    inco_term = models.TextField(max_length=500, null=True, blank=True)
    is_repeat_order = models.BooleanField(default=False)
    financialyear = models.ForeignKey("procurement.FinancialYear", related_name='financial_year_plant_machinery_quotation',
                                      on_delete=models.CASCADE, blank=True, null=True)

    ## other model links
    asset_requisition = models.ForeignKey(PlantMachineryAssetRequisition, related_name='asset_requisition_plant_machinery_quotation', on_delete=models.CASCADE, null=True, blank=True)
    asset_requisitions= models.ManyToManyField(PlantMachineryAssetRequisition, related_name="asset_requisitions_plant_machinery_quotation", null=True, blank=True)## added for multiple AR
    
    plant_machinery_rfq_vendor = models.ForeignKey(PlantMachineryRFQVendors, related_name='plant_machinery_rfq_vendor_plant_machinery_quotation', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_quotation_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_quotation_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_quotation_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_quotation_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_quotation_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)

    packing_forwarding_by_cst = models.FloatField(default=0)
    transportaion_charges_by_cst = models.FloatField(default=0)
    other_charges_by_cst = models.FloatField(default=0)

    class Meta:
        db_table = "plant_machinery_quotation"



class PlantMachineryQuotationTermsAndConditions(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='organizations_plant_machinery_quotation_terms_and_conditions',
                                     on_delete=models.CASCADE)
    plant_machinery_quotation = models.ForeignKey(PlantMachineryQuotation, related_name='plant_machinery_quotation_plant_machinery_quotation_terms_and_conditions',
                                  on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(TermsAndConditionsChild, related_name='plant_machinery_quotation_terms_and_conditions_master', on_delete=models.CASCADE, null=True, blank=True)
    key = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    order_id = models.IntegerField(default=0)

    class Meta:
        db_table = "plant_machinery_quotation_terms_and_conditions"

class PlantMachineryQuotationItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_quotation_items',
                                     on_delete=models.CASCADE)
    plant_machinery_quotation = models.ForeignKey(PlantMachineryQuotation, related_name='plant_machinery_quotation_plant_machinery_quotation_items', on_delete=models.CASCADE,
                                  null=True, blank=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup,
                                          related_name='plant_machinery_group_plant_machinery_quotation_items',
                                          on_delete=models.CASCADE, null=True, blank=True)
    size_part_number = models.CharField(max_length=200, null=True, blank=True)
    specification = models.CharField(max_length=200, blank=True, null=True, default="")
    quantity = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='excise_tax_head_plant_machinery_quotation_items',
                                        on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='tax_head_plant_machinery_quotation_items',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    last_purchased_rate = models.FloatField(default=0)
    last_purchased_reference = models.TextField(max_length=500, null=True, blank=True)
    selected_by_cst = models.FloatField(default=0)
    quantity_by_cst = models.FloatField(default=0)
    is_selected_by_cst = models.BooleanField(default=False)
    
    # other model links #

    asset_requisition_item = models.ForeignKey(PlantMachineryAssetRequisitionItem, related_name='asset_requisition_item_plant_machinery_quotation_items', on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_rfq_vendor_item = models.ForeignKey(PlantMachineryRFQVendorsItems, related_name='plant_machinery_rfq_vendor_item_plant_machinery_quotation_items', on_delete=models.CASCADE, null=True, blank=True)
    is_replacement = models.BooleanField(default=False)
    plant_machinery_machines= models.ManyToManyField(PlantMachineryMachine, related_name="plant_machinery_machines_plant_machinery_quotation_items", null=True, blank=True)
    
    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "plant_machinery_quotation_items"

class PlantMachineryQuotationAttachments(BaseAbstractStructure):
    """
    Plant Machinery Quotation Attachments
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_quotation_attachment',
                                     on_delete=models.CASCADE)
    plant_machinery_quotation = models.ForeignKey(PlantMachineryQuotation,
                                  related_name='plant_machinery_quotation_plant_machinery_quotation_attachment',
                                  on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='plant_machinery/plant_machinery_quotation', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_quotation_attachments"

class PlantMachineryQuotationTaxDetails(BaseAbstractStructure):
    """
    Quotation Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_quotation_tax_details',
                                     on_delete=models.CASCADE)
    plant_machinery_quotation = models.ForeignKey(PlantMachineryQuotation,
                                  related_name='plant_machinery_quotation_plant_machinery_quotation_tax_details',
                                  on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='tax_head_plant_machinery_quotation_tax_details', on_delete=models.CASCADE,
                                 null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = PlantMachineryQuotation.cmobjects.filter(pk=self.plant_machinery_quotation.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.plant_machinery_quotation_plant_machinery_quotation_tax_details.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.plant_machinery_quotation_plant_machinery_quotation_tax_details.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value) * float(self.tax_percentage) / 100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount) * float(self.sgst_percentage) / 100
        self.cgst_amount = float(self.tax_amount) * float(self.cgst_percentage) / 100
        self.igst_amount = float(self.tax_amount) * float(self.igst_percentage) / 100
        self.utgst_amount = float(self.tax_amount) * float(self.utgst_percentage) / 100
        self.cess_amount = float(self.tax_amount) * float(self.cess_percentage) / 100
        self.total_tax_amount = float(self.tax_amount) + float(self.sgst_amount) + float(self.cgst_amount) + float(
            self.igst_amount) + float(self.utgst_amount) + float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "plant_machinery_quotation_tax"

class PlantMachineryQuotationExpenseDetails(BaseAbstractStructure):
    """
    Quotation Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_quotation_expense_details',
                                     on_delete=models.CASCADE)
    plant_machinery_quotation = models.ForeignKey(PlantMachineryQuotation, related_name='plant_machinery_quotation_plant_machinery_quotation_expense_details', on_delete=models.CASCADE,
                                  null=True, blank=True)
    expense_on = models.FloatField(default=0)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) 
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) 
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True) 
    expense_head = models.ForeignKey(ExpenseHead, related_name='expense_head_plant_machinery_quotation_expense_details', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='tax_head_plant_machinery_quotation_expense_details', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        # value = 0
        # parent_record = PlantMachineryQuotation.cmobjects.filter(pk=self.plant_machinery_quotation.id).first()
        # if self.expense_on_parent:
        #     value = getattr(parent_record, self.expense_on_parent)
        # elif self.expense_on_self:
        #     temp = parent_record.plant_machinery_quotation_plant_machinery_quotation_expense_details.filter(is_deleted=False, name=self.expense_on_self)
        #     if temp:
        #         value = temp[0].total_expense_amount
        # elif self.expense_on_self_after:
        #     value = parent_record.total_amount
        #     temp = parent_record.plant_machinery_quotation_plant_machinery_quotation_expense_details.filter(is_deleted=False, included=True).order_by('id')
        #     for temp_data in temp:
        #         if temp_data.add:
        #             value += temp_data.total_expense_amount
        #         else:
        #             value -= temp_data.total_expense_amount
        #         if temp_data.name == self.expense_on_self_after:
        #             break
        # else:
        #     value = parent_record.total_amount
        # if self.expense_percentage != 0:
        #     self.expense_amount = float(value)*float(self.expense_percentage)/100
        # else:
        #     if not self.expense_amount:
        #         self.expense_amount = 0
        if self.expense_percentage != 0:
            self.expense_amount = float(self.expense_on)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "plant_machinery_quotation_expense"


class PlantMachineryCST(BaseAbstractStructure):
    """
    Plant machinery Comparison statement (CST)
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_cst', on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster",related_name='site_plant_machinery_cst', on_delete=models.CASCADE, null=True, blank=True)
    store = models.ForeignKey("procurement.StoreMaster",related_name='store_plant_machinery_cst', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='project_plant_machinery_cst', on_delete=models.CASCADE, null=True, blank=True)
    financialyear = models.ForeignKey("procurement.FinancialYear", related_name='financial_year_plant_machinery_cst', on_delete=models.CASCADE, blank=True, null=True)
    request_code = models.CharField(max_length=100, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    time = models.TimeField(null=True, blank=True)
 
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    title = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    checked_remarks = models.TextField(null=True, blank=True)
    approved_remarks = models.TextField(null=True, blank=True)
    rejected_remarks = models.TextField(null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    required_duration = models.IntegerField(default=0)
    is_repeat_order = models.BooleanField(default=False)

    asset_requisition = models.ForeignKey(PlantMachineryAssetRequisition, related_name="asset_requisition_plant_machinery_cst", on_delete=models.CASCADE, null=True, blank=True)
    asset_requisitions= models.ManyToManyField(PlantMachineryAssetRequisition, related_name="asset_requisitions_plant_machinery_cst", null=True, blank=True)## added for multiple AR

    plant_machinery_rfq_vendor = models.ForeignKey(PlantMachineryRFQVendors, related_name='plant_machinery_rfq_vendor_plant_machinery_cst', on_delete=models.CASCADE, null=True, blank=True)
    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_rejected_by", on_delete=models.CASCADE)

    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)
    current_stage = models.IntegerField(default=0)
    is_budgeted = models.BooleanField(default=False)
    previous_version = models.ForeignKey('self', related_name='previous_version_plant_machinery_cst',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    version = models.IntegerField(default=1)
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='plant_machinery_cst_ref_stage_type', blank=True, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.site} Site Requested {self.store} Store"

    class Meta:
        db_table = "plant_machinery_cst"

class PlantMachineryCSTItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_cst_item',
                                     on_delete=models.CASCADE)
    plant_machinery_cst = models.ForeignKey(PlantMachineryCST, related_name='plant_machinery_cst_plant_machinery_cst_item', on_delete=models.CASCADE, null=True, blank=True)

    plant_machinery_group = models.ForeignKey(PlantMachineryGroup,
                                          related_name='plant_machinery_group_plant_machinery_cst_item',
                                          on_delete=models.CASCADE, null=True, blank=True)
    quantity = models.IntegerField(default=0)
    availability = models.IntegerField(default=0)
    project_requirement = models.IntegerField(default=0)
    type_of_work_or_activity_and_location = models.CharField(max_length=255,  blank=True, null=True)
    remarks = models.TextField(null=True, blank=True)
    required_date=models.DateField(null=True, blank=True)
    sanctioned_quantity = models.FloatField(default=0)
    sanctioned_remarks = models.TextField(null=True, blank=True)

    # other model links #
    asset_requisition_item = models.ForeignKey(PlantMachineryAssetRequisitionItem, related_name="asset_requisition_item_plant_machinery_cst_item", on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_rfq_vendor_item = models.ForeignKey(PlantMachineryRFQVendorsItems, related_name="plant_machinery_rfq_vendor_item_plant_machinery_cst_item", on_delete=models.CASCADE, null=True, blank=True)
    is_replacement = models.BooleanField(default=False)
    plant_machinery_machines= models.ManyToManyField(PlantMachineryMachine, related_name="plant_machinery_machines_plant_machinery_cst_item", null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_cst_items"

class PlantMachineryCSTStages(BaseAbstractStructure):
    """
    PlantMachinery CST Stages
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_cst_stages', on_delete=models.CASCADE)
    plant_machinery_cst = models.ForeignKey(PlantMachineryCST, related_name='plant_machinery_cst_plant_machinery_cst_stages', on_delete=models.CASCADE, null=True, blank=True)
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_stages_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_stages_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_stages_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_stages_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_cst_stages_rejected_by", on_delete=models.CASCADE)
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    is_web = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.plant_machinery_cst} -> {self.stage} {self.status}"

    class Meta:
        db_table = "plant_machinery_cst_stages"



class PlantMachineryWorkOrder(BaseAbstractStructure):
    TAX_TYPE = (
        ('gst', 'GST'),
        ('vat', 'VAT'),
    )
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_work_order',
                                     on_delete=models.CASCADE)
    vendor = models.ForeignKey(VendorMasterV2, related_name='vendor_plant_machinery_work_order', on_delete=models.CASCADE,
                               null=True, blank=True)
    vendor_state = models.ForeignKey(State, related_name='vendor_state_plant_machinery_work_order',
                                     on_delete=models.CASCADE, null=True, blank=True)
    gst_number = models.CharField(max_length=200, null=True, blank=True)
    site = models.ForeignKey("procurement.SiteMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='site_plant_machinery_work_order')
    store = models.ForeignKey("procurement.StoreMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='store_plant_machinery_work_order')
    project = models.ForeignKey("project_and_planning.ProjectMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='project_plant_machinery_work_order')
    billing_site = models.ForeignKey("procurement.SiteMaster", related_name='billing_site_plant_machinery_work_order',
                                     on_delete=models.CASCADE, null=True, blank=True)
    billing_state = models.ForeignKey(State, related_name='billing_state_plant_machinery_work_order',
                                      on_delete=models.CASCADE, null=True, blank=True)
    delivery_site = models.ForeignKey("procurement.SiteMaster", related_name='delivery_site_plant_machinery_work_order',
                                      on_delete=models.CASCADE, null=True, blank=True)
    delivery_state = models.ForeignKey(State, related_name='delivery_state_plant_machinery_work_order',
                                       on_delete=models.CASCADE, null=True, blank=True)
    job_site = models.ForeignKey("procurement.SiteMaster", related_name='job_site_plant_machinery_work_order',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_type = models.CharField(max_length=100, choices=TAX_TYPE, blank=True, null=True, default="vat")
    quotation_by = models.ForeignKey(PmsUser, related_name='quotation_by_plant_machinery_work_order',
                                     on_delete=models.CASCADE, null=True, blank=True)
    wo_for = models.CharField(max_length=200, null=True, blank=True)
    valid_date_from = models.DateField(null=True, blank=True)
    valid_date_to = models.DateField(null=True, blank=True)
    quotation_by_text = models.CharField(blank=True, null=True, default='', max_length=100)
    quotation_text = models.CharField(blank=True, null=True, default='', max_length=100)
    quotation_date = models.DateField(blank=True, null=True)
    delivery_address1 = models.TextField(max_length=500, null=True, blank=True)
    delivery_address2 = models.TextField(max_length=500, null=True, blank=True)
    delivery_address3 = models.TextField(max_length=500, null=True, blank=True)
    gst_as_billing_state = models.BooleanField(default=False)
    line_in_bottom = models.TextField(max_length=500, null=True, blank=True)
    delivery_days = models.IntegerField(null=True, blank=True)
    for_alerts_delivery_days = models.IntegerField(null=True, blank=True)
    payment_days = models.IntegerField(null=True, blank=True)
    for_alerts_payment_days = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    address = models.TextField(max_length=500, null=True, blank=True)
    previous_version = models.ForeignKey('self', related_name='previous_version_plant_machinery_work_order',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    version = models.IntegerField(default=1)
    vendor_work_order_number = models.CharField(max_length=200, null=True, blank=True)
    delivery_days = models.IntegerField(default=0)
    delivery_state = models.ForeignKey(State, related_name='delivery_state_plant_machinery_work_order',
                                       on_delete=models.CASCADE, null=True, blank=True)
    payment_mode = models.CharField(max_length=200, null=True, blank=True)
    payment_days = models.IntegerField(default=0)
    purchase_type = models.CharField(max_length=200, null=True, blank=True)
    revised_quotation = models.CharField(max_length=200, null=True, blank=True)
    remarks = models.TextField(max_length=500, null=True, blank=True)
    payment_terms = models.TextField(max_length=500, null=True, blank=True)
    rate_validity = models.TextField(max_length=500, null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    advance_percentage = models.FloatField(default=0)
    advance_amount = models.FloatField(default=0)
    against_c_form = models.BooleanField(default=False)

    total_before_gst_amount = models.FloatField(default=0)
    total_after_gst_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    total_item_item_quantity = models.FloatField(default=0)
    total_item_item_amount = models.FloatField(default=0)
    total_item_disc_amount = models.FloatField(default=0)
    total_item_taxable_amount = models.FloatField(default=0)
    total_item_excise_tax_amount = models.FloatField(default=0)
    total_item_tax_amount = models.FloatField(default=0)
    total_item_sgst_amount = models.FloatField(default=0)
    total_item_cgst_amount = models.FloatField(default=0)
    total_item_igst_amount = models.FloatField(default=0)
    total_item_utgst_amount = models.FloatField(default=0)
    total_item_cess_amount = models.FloatField(default=0)
    total_item_total_amount = models.FloatField(default=0)
    total_tax_tax_amount = models.FloatField(default=0)
    total_tax_sgst_amount = models.FloatField(default=0)
    total_tax_cgst_amount = models.FloatField(default=0)
    total_tax_igst_amount = models.FloatField(default=0)
    total_tax_utgst_amount = models.FloatField(default=0)
    total_tax_cess_amount = models.FloatField(default=0)
    total_tax_total_tax_amount = models.FloatField(default=0)
    total_expense_expense_amount = models.FloatField(default=0)
    total_expense_sgst_amount = models.FloatField(default=0)
    total_expense_cgst_amount = models.FloatField(default=0)
    total_expense_igst_amount = models.FloatField(default=0)
    total_expense_utgst_amount = models.FloatField(default=0)
    total_expense_cess_amount = models.FloatField(default=0)
    total_expense_total_expense_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    required_duration = models.FloatField(default=0)
    total_amount_for_required_duration = models.FloatField(default=0)
    warranty = models.TextField(max_length=500, null=True, blank=True)
    inco_term = models.TextField(max_length=500, null=True, blank=True)
    is_repeat_order = models.BooleanField(default=False)
    financialyear = models.ForeignKey("procurement.FinancialYear", related_name='financial_year_plant_machinery_work_order',
                                      on_delete=models.CASCADE, blank=True, null=True)

    ## other model links
    asset_requisition= models.ForeignKey(PlantMachineryAssetRequisition, related_name="asset_requisition_plant_machinery_work_order",on_delete=models.CASCADE, null=True, blank=True)
    asset_requisitions= models.ManyToManyField(PlantMachineryAssetRequisition, related_name="asset_requisitions_plant_machinery_work_order", null=True, blank=True)## added for multiple AR
    plant_machinery_rfq_vendor = models.ForeignKey(PlantMachineryRFQVendors, related_name='plant_machinery_rfq_vendor_plant_machinery_work_order', on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_cst = models.ForeignKey(PlantMachineryCST, related_name='plant_machinery_cst_plant_machinery_work_order', on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_quotation= models.ForeignKey(PlantMachineryQuotation, related_name='plant_machinery_quotation_plant_machinery_work_order', on_delete=models.CASCADE, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_work_order_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_work_order_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_work_order_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_work_order_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_work_order_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    scope_of_supply = models.TextField(null=True, blank=True)

    packing_forwarding_by_cst = models.FloatField(default=0)
    transportaion_charges_by_cst = models.FloatField(default=0)
    other_charges_by_cst = models.FloatField(default=0)

    class Meta:
        db_table = "plant_machinery_work_order"

class PlantMachineryWorkOrderTermsAndConditions(BaseAbstractStructure):
    organization = models.ForeignKey(Organization,
                                     related_name='organizations_plant_machinery_work_order_terms_and_conditions',
                                     on_delete=models.CASCADE)
    plant_machinery_work_order = models.ForeignKey(PlantMachineryWorkOrder, related_name='plant_machinery_work_order_plant_machinery_work_order_terms_and_conditions',
                                  on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(TermsAndConditionsChild, related_name='plant_machinery_work_order_terms_and_conditions_master', on_delete=models.CASCADE, null=True, blank=True)
    key = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    order_id = models.IntegerField(default=0)

    class Meta:
        db_table = "plant_machinery_work_order_terms_and_conditions"

class PlantMachineryWorkOrderItems(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_work_order_items',
                                     on_delete=models.CASCADE)
    plant_machinery_work_order = models.ForeignKey(PlantMachineryWorkOrder, related_name='plant_machinery_work_order_plant_machinery_work_order_items', on_delete=models.CASCADE,
                                  null=True, blank=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup,
                                          related_name='plant_machinery_group_plant_machinery_work_order_items',
                                          on_delete=models.CASCADE, null=True, blank=True)
    size_part_number = models.CharField(max_length=200, null=True, blank=True)
    specification = models.CharField(max_length=200, blank=True, null=True, default="")
    quantity = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    item_amount = models.FloatField(default=0)
    disc_percentage = models.FloatField(default=0)
    disc_amount = models.FloatField(default=0)
    taxable_amount = models.FloatField(default=0)
    excise_tax_head = models.ForeignKey(TaxHead, related_name='excise_tax_head_plant_machinery_work_order_items',
                                        on_delete=models.CASCADE, null=True, blank=True)
    excise_tax_percentage = models.FloatField(default=0)
    excise_tax_amount = models.FloatField(default=0)
    tax_head = models.ForeignKey(TaxHead, related_name='tax_head_plant_machinery_work_order_items',
                                 on_delete=models.CASCADE, null=True, blank=True)
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_amount = models.FloatField(default=0)
    notes = models.TextField(max_length=500, null=True, blank=True)
    last_purchased_rate = models.FloatField(default=0)
    last_purchased_reference = models.TextField(max_length=500, null=True, blank=True)
    selected_by_cst = models.FloatField(default=0)
    quantity_by_cst = models.FloatField(default=0)
    is_selected_by_cst = models.BooleanField(default=False)
    # other model links #
    asset_requisition_item = models.ForeignKey(PlantMachineryAssetRequisitionItem, related_name='asset_requisition_item_plant_machinery_work_order_items', on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_rfq_vendor_item = models.ForeignKey(PlantMachineryRFQVendorsItems, related_name='plant_machinery_rfq_vendor_item_plant_machinery_work_order_items', on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_cst_item = models.ForeignKey(PlantMachineryCSTItems, related_name='plant_machinery_cst_item_plant_machinery_work_order_items', on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_quotation_item= models.ForeignKey(PlantMachineryQuotationItems, related_name='plant_machinery_quotation_item_plant_machinery_work_order_items', on_delete=models.CASCADE, null=True, blank=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.quantity:
            self.quantity = 0
        if not self.rate:
            self.rate = 0
        if not self.disc_percentage:
            self.disc_percentage = 0
        if not self.excise_tax_percentage:
            self.excise_tax_percentage = 0
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        self.item_amount = float(self.quantity)*float(self.rate)
        if self.disc_percentage != 0:
            self.disc_amount = float(self.item_amount)*float(self.disc_percentage)/100
        else:
            if not self.disc_amount:
                self.disc_amount = 0
        self.taxable_amount = float(self.item_amount)-float(self.disc_amount)
        if self.excise_tax_percentage != 0:
            self.excise_tax_amount = float(self.taxable_amount)*float(self.excise_tax_percentage)/100
        else:
            if not self.excise_tax_amount:
                self.excise_tax_amount = 0
        if self.tax_percentage != 0:
            self.tax_amount = float(self.taxable_amount)*float(self.tax_percentage)/100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.taxable_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.taxable_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.taxable_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.taxable_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.taxable_amount)*float(self.cess_percentage)/100
        self.total_amount = float(self.taxable_amount)+float(self.excise_tax_amount)+float(self.tax_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "plant_machinery_work_order_items"


class PlantMachineryWorkOrderTaxDetails(BaseAbstractStructure):
    """
    Work Order Tax
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_work_order_tax_details',
                                     on_delete=models.CASCADE)
    plant_machinery_work_order = models.ForeignKey(PlantMachineryWorkOrder,
                                  related_name='plant_machinery_work_order_plant_machinery_work_order_tax_details',
                                  on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    tax_on_parent = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_on_self_after = models.CharField(max_length=200, null=True, blank=True)  # field_name
    tax_head = models.ForeignKey(TaxHead, related_name='tax_head_plant_machinery_work_order_tax_details', on_delete=models.CASCADE,
                                 null=True, blank=True)
    tax_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    tax_percentage = models.FloatField(default=0)
    tax_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.tax_percentage:
            self.tax_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = PlantMachineryWorkOrder.cmobjects.filter(pk=self.plant_machinery_work_order.id).first()
        if self.tax_on_parent:
            value = getattr(parent_record, self.tax_on_parent)
        elif self.tax_on_self:
            temp = parent_record.plant_machinery_work_order_plant_machinery_work_order_tax_details.filter(is_deleted=False, name=self.tax_on_self)
            if temp:
                value = temp[0].total_tax_amount
        elif self.tax_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.plant_machinery_work_order_plant_machinery_work_order_tax_details.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_tax_amount
                else:
                    value -= temp_data.total_tax_amount
                if temp_data.name == self.tax_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.tax_percentage != 0:
            self.tax_amount = float(value) * float(self.tax_percentage) / 100
        else:
            if not self.tax_amount:
                self.tax_amount = 0
        self.sgst_amount = float(self.tax_amount) * float(self.sgst_percentage) / 100
        self.cgst_amount = float(self.tax_amount) * float(self.cgst_percentage) / 100
        self.igst_amount = float(self.tax_amount) * float(self.igst_percentage) / 100
        self.utgst_amount = float(self.tax_amount) * float(self.utgst_percentage) / 100
        self.cess_amount = float(self.tax_amount) * float(self.cess_percentage) / 100
        self.total_tax_amount = float(self.tax_amount) + float(self.sgst_amount) + float(self.cgst_amount) + float(
            self.igst_amount) + float(self.utgst_amount) + float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "plant_machinery_work_order_tax_details"

class PlantMachineryWorkOrderExpenseDetails(BaseAbstractStructure):
    """
    Quotation Expense
    """
    CONDITIONS = (
        ('before_gst', 'Before GST'),
        ('after_gst', 'After GST'),
        ('expense', 'After Expense'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_work_order_expense_details',
                                     on_delete=models.CASCADE)
    plant_machinery_work_order = models.ForeignKey(PlantMachineryWorkOrder, related_name='plant_machinery_work_order_plant_machinery_work_order_expense_details', on_delete=models.CASCADE,
                                  null=True, blank=True)
    sac_code = models.CharField(max_length=200, null=True, blank=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    extra = models.CharField(max_length=200, null=True, blank=True)
    choice = models.CharField(max_length=200, null=True, blank=True)
    expense_on_parent = models.CharField(max_length=200, null=True, blank=True) 
    expense_on_self = models.CharField(max_length=200, null=True, blank=True) 
    expense_on_self_after = models.CharField(max_length=200, null=True, blank=True) 
    expense_head = models.ForeignKey(ExpenseHead, related_name='expense_head_plant_machinery_work_order_expense_details', on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead, related_name='tax_head_plant_machinery_work_order_expense_details', on_delete=models.CASCADE, null=True, blank=True)
    expense_condition = models.CharField(max_length=100, choices=CONDITIONS, blank=True, null=True, default="after_gst")
    expense_percentage = models.FloatField(default=0)
    expense_amount = models.FloatField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)
    total_expense_amount = models.FloatField(default=0)
    included = models.BooleanField(default=True)
    add = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.expense_percentage:
            self.expense_percentage = 0
        if not self.sgst_percentage:
            self.sgst_percentage = 0
        if not self.cgst_percentage:
            self.cgst_percentage = 0
        if not self.igst_percentage:
            self.igst_percentage = 0
        if not self.utgst_percentage:
            self.utgst_percentage = 0
        if not self.cess_percentage:
            self.cess_percentage = 0
        value = 0
        parent_record = PlantMachineryWorkOrder.cmobjects.filter(pk=self.plant_machinery_work_order.id).first()
        if self.expense_on_parent:
            value = getattr(parent_record, self.expense_on_parent)
        elif self.expense_on_self:
            temp = parent_record.plant_machinery_work_order_plant_machinery_work_order_expense_details.filter(is_deleted=False, name=self.expense_on_self)
            if temp:
                value = temp[0].total_expense_amount
        elif self.expense_on_self_after:
            value = parent_record.total_amount
            temp = parent_record.plant_machinery_work_order_plant_machinery_work_order_expense_details.filter(is_deleted=False, included=True).order_by('id')
            for temp_data in temp:
                if temp_data.add:
                    value += temp_data.total_expense_amount
                else:
                    value -= temp_data.total_expense_amount
                if temp_data.name == self.expense_on_self_after:
                    break
        else:
            value = parent_record.total_amount
        if self.expense_percentage != 0:
            self.expense_amount = float(value)*float(self.expense_percentage)/100
        else:
            if not self.expense_amount:
                self.expense_amount = 0
        self.sgst_amount = float(self.expense_amount)*float(self.sgst_percentage)/100
        self.cgst_amount = float(self.expense_amount)*float(self.cgst_percentage)/100
        self.igst_amount = float(self.expense_amount)*float(self.igst_percentage)/100
        self.utgst_amount = float(self.expense_amount)*float(self.utgst_percentage)/100
        self.cess_amount = float(self.expense_amount)*float(self.cess_percentage)/100
        self.total_expense_amount = float(self.expense_amount)+float(self.sgst_amount)+float(self.cgst_amount)+float(self.igst_amount)+float(self.utgst_amount)+float(self.cess_amount)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "plant_machinery_work_order_expense_details"


class PlantMachineryWorkOrderPaymentSchedule(BaseAbstractStructure):
    """
    work Order Payment Schedule
    """
    PERCENT_TYPE = (
        ('bg', 'BG'),
        ('lc', 'LC (LETTER OF CREDIT)'),
        ('before_dispatch', 'BEFORE DISPATCH'),
        ('advance', 'ADVANCE'),
        ('after_delivery', 'AFTER DELIVERY'),
        ('after_days', 'AFTER DAYS'),
        ('other', 'OTHER'),
    )
    organization = models.ForeignKey(Organization,
                                     related_name='organizations_plant_machinery_work_order_payment_schedule',
                                     on_delete=models.CASCADE)
    plant_machinery_work_order = models.ForeignKey(PlantMachineryWorkOrder, related_name='plant_machinery_work_order_plant_machinery_work_order_payment_schedule',
                                       on_delete=models.CASCADE, null=True, blank=True)
    percent = models.FloatField(default=0)
    percent_type = models.CharField(max_length=100, choices=PERCENT_TYPE, null=True, blank=True)
    payment_credit_days = models.IntegerField(default=0)
    notify_days = models.IntegerField(default=0)
    description = models.TextField(max_length=500, null=True, blank=True)
    amount = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.percent:
            self.percent = 0
        parent_record = PlantMachineryWorkOrder.cmobjects.filter(pk=self.plant_machinery_work_order.id).first()
        self.amount = float(parent_record.total_amount)*float(self.percent)/100
        super().save(*args, **kwargs)

    class Meta:
        db_table = "plant_machinery_work_order_payment_schedule"

class PlantMachineryWorkOrderDeliveryLocation(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_work_order_delivery_location',
                                     on_delete=models.CASCADE)
    plant_machinery_work_order = models.ForeignKey(PlantMachineryWorkOrder, related_name='plant_machinery_work_order_plant_machinery_work_order_delivery_location',
                                       on_delete=models.CASCADE, null=True, blank=True)
    delivery_location = models.CharField(max_length=200, null=True, blank=True)
    contact_person = models.CharField(max_length=200, null=True, blank=True)
    goods_percentage = models.FloatField(default=0, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_work_order_delivery_location"        

class PlantMachineryWorkOrderAttachments(BaseAbstractStructure):
    """
    Plant Machinery work order Attachments
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_work_order_attachments',
                                     on_delete=models.CASCADE)
    plant_machinery_work_order = models.ForeignKey(PlantMachineryWorkOrder,
                                  related_name='plant_machinery_work_order_plant_machinery_work_order_attachments',
                                  on_delete=models.CASCADE, null=True, blank=True)
    attachment = models.FileField(upload_to='plant_machinery/plant_machinery_work_order', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_work_order_attachments"        
        
class PlantMachineryMajorActivity(BaseAbstractStructure):
    """
    Plant Machinery project planning
    """
    project = models.ForeignKey("project_and_planning.ProjectMaster",related_name="project_plant_machinery_major_activity",on_delete=models.CASCADE,null=True,blank=True)
    budget_master = models.ForeignKey(PlantMachineryBudgetMaster,related_name="budget_master_plant_machinery_major_activity",on_delete=models.CASCADE,null=True,blank=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup,related_name='plant_machinery_group_plant_machinery_major_activity',on_delete=models.CASCADE, null=True, blank=True)
    major_activity = models.CharField(max_length=255, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='uom_plant_machinery_major_activity',on_delete=models.CASCADE, null=True, blank=True)
    project_planning = models.FloatField(default=0)
    is_production = models.BooleanField(default=False)

    class Meta:
        db_table = "plant_machinery_major_activity"


class PlantMachineryMajorActivityAchieved(BaseAbstractStructure):
    """
    Plant Machinery major activities achieved
    """
    plant_machinery_major_activity = models.ForeignKey(PlantMachineryMajorActivity,related_name="plant_machinery_major_activity_achieved",on_delete=models.CASCADE)
    achieved = models.FloatField(default=0)
    date = models.DateField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_major_activity_achieved"        


class PlantMachineryComplianceMasterNew(BaseAbstractStructure):
    """
    PlantMachineryComplianceMasterNew Model
    """
    
    organization = models.ForeignKey(Organization,related_name='organizations_plant_machinery_compliance_master_new',on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster", related_name='project_plant_machinery_compliance_master_new', null=True, blank=True, on_delete=models.CASCADE)
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_plant_machinery_compliance_master_new',
                                 on_delete=models.CASCADE, null=True, blank=True)
    plant_machinery_group = models.ForeignKey(PlantMachineryGroup,related_name='plant_machinery_group_plant_machinery_compliance_master_new',on_delete=models.CASCADE, null=True, blank=True)
    employee_id = models.CharField(max_length=100, unique=True, null=False, blank=False)
    name_of_employee = models.CharField(max_length=255, null=False, blank=False)
    fathers_name = models.CharField(max_length=255, null=False, blank=False)
    designation = models.CharField(max_length=255, null=True, blank=True)
    date_of_joining = models.DateField(null=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    aadhar_no = models.CharField(max_length=255, null=True, blank=True)
    licence_no = models.CharField(max_length=255, null=True, blank=True)
    licence_issue_date = models.DateField(null=True, blank=True)
    licence_validity = models.DateField(null=True, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "plant_machinery_compliance_master_new"        

class PlantMachineryUtilizationBudget(BaseAbstractStructure):
    """
    PlantMachineryUtilizationBudget Model
    """
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_utilization_budget', 
                                     on_delete=models.CASCADE)
    project = models.ForeignKey("project_and_planning.ProjectMaster",related_name='project_plant_machinery_utilization_budget',null=True,blank=True,on_delete=models.CASCADE)
    plant_machinery_group = models.ForeignKey(
        PlantMachineryGroup,
        related_name='plant_machinery_group_plant_machinery_utilization_budget',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    budget_master = models.ForeignKey(
        PlantMachineryBudgetMaster,
        related_name='budget_master_plant_machinery_utilization_budget',
        null=True,
        blank=True,
        on_delete=models.CASCADE
    )
    amount = models.FloatField(default=0)

    class Meta:
        db_table = "plant_machinery_utilization_budget"

class PlantMachineryTaxInvoice(BaseAbstractStructure):
    INVOICE_TYPE = (
        ('standard', 'standard'),
        ('monsoon', 'monsoon'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_tax_invoice', on_delete=models.CASCADE)
    project = models.ForeignKey('project_and_planning.ProjectMaster', on_delete=models.CASCADE, null=True, blank=True, related_name='project_plant_machinery_tax_invoice')
    site = models.ForeignKey('procurement.SiteMaster', on_delete=models.CASCADE, null=True, blank=True, related_name='site_plant_machinery_tax_invoice')
    store = models.ForeignKey('procurement.StoreMaster', on_delete=models.CASCADE, null=True, blank=True, related_name='store_plant_machinery_tax_invoice')
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    plant_machinery_machine = models.ForeignKey(PlantMachineryMachine, on_delete=models.CASCADE, null=True, blank=True, related_name='plant_machinery_machine_plant_machinery_tax_invoice')
    actual_hsd_issue = models.FloatField(default=0)
    hsd_rate = models.FloatField(default=0)
    request_code = models.CharField(max_length=200, null=True, blank=True)
    invoice_number = models.CharField(max_length=200, null=True, blank=True)
    invoice_date = models.DateField(null=True, blank=True)
    work_order_number= models.CharField(max_length=200, null=True, blank=True)
    work_order_date = models.DateField(null=True, blank=True)
    work_order_validity_date = models.DateField(null=True, blank=True)
    invoice_type = models.CharField(max_length=100, choices=INVOICE_TYPE, blank=True, null=True, default="standard")
    
    tax_head = models.ForeignKey(TaxHead, on_delete=models.CASCADE, null=True, blank=True, related_name='tax_head_plant_machinery_tax_invoice')
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    total_tax_amount = models.FloatField(default=0)

    class Meta:
        db_table = "plant_machinery_tax_invoice"        

class PlantMachineryHireBillInvoice(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
   
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name='organization_plant_machinery_hire_bill_invoice')
    project = models.ForeignKey("project_and_planning.ProjectMaster", on_delete=models.CASCADE, related_name='project_plant_machinery_hire_bill_invoice', null=True, blank=True)
    site = models.ForeignKey("procurement.SiteMaster", on_delete=models.CASCADE, related_name='site_plant_machinery_hire_bill_invoice', null=True, blank=True)
    store = models.ForeignKey("procurement.StoreMaster", on_delete=models.CASCADE, related_name='store_plant_machinery_hire_bill_invoice', null=True, blank=True)
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)

    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    latest = models.BooleanField(default=True)
    previous_version = models.ForeignKey('self', related_name='previous_version_plant_machinery_hire_bill_invoice',
                                on_delete=models.CASCADE, null=True, blank=True)
    request_code = models.CharField(max_length=255, null=True, blank=True)
    version = models.IntegerField(default=1)
    date = models.DateField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    required_duration = models.IntegerField(default=0)
    current_stage = models.IntegerField(default=0)
    checked_remarks = models.TextField(null=True, blank=True)
    approved_remarks = models.TextField(null=True, blank=True)
    rejected_remarks = models.TextField(null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    
     # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='plant_machinery_hire_bill_invoice_ref_stage_type_id', blank=True, null=True, on_delete=models.CASCADE)
    class Meta:
        db_table = "plant_machinery_hire_bill_invoice"        

class PlantMachineryHireBillInvoiceItem(BaseAbstractStructure):

    DEBIT_TYPE_CHOICES = (
        ('Food', 'Food'),
        ('HSD', 'HSD'),
        ('Rental', 'Rental'),
        ('Food with HSD', 'Food with HSD'),
        ('Food with Rental', 'Food with Rental'),
        ('HSD with Rental', 'HSD with Rental'),
        ('ALL','ALL'),
        ('NIL', 'NIL'),
    )
    plant_machinery_hire_bill_invoice = models.ForeignKey(PlantMachineryHireBillInvoice, on_delete=models.CASCADE, related_name='plant_machinery_hire_bill_invoice_item',null=True, blank=True,)
    tax_invoice = models.ForeignKey(PlantMachineryTaxInvoice,related_name='tax_invoice_plant_machinery_hire_bill_invoice_item',on_delete=models.CASCADE, null=True, blank=True)
    tax_head = models.ForeignKey(TaxHead,related_name='tax_head_plant_machinery_hire_bill_invoice_item',on_delete=models.CASCADE, null=True, blank=True)
    invoice_amount = models.FloatField(default=0)
    total_payable_amount = models.FloatField(default=0)
    debit_type = models.CharField(max_length=200, choices=DEBIT_TYPE_CHOICES, null=True, blank=True)
    debitable_amount = models.FloatField(default=0)
    rate_per_month = models.FloatField(default=0)
    working_hours_or_km = models.FloatField(default=0)
    total_hsd = models.FloatField(default=0)
    working_days = models.IntegerField(default=0)
    sgst_percentage = models.FloatField(default=0)
    cgst_percentage = models.FloatField(default=0)
    igst_percentage = models.FloatField(default=0)
    utgst_percentage = models.FloatField(default=0)
    cess_percentage = models.FloatField(default=0)
    sgst_amount = models.FloatField(default=0)
    cgst_amount = models.FloatField(default=0)
    igst_amount = models.FloatField(default=0)
    utgst_amount = models.FloatField(default=0)
    cess_amount = models.FloatField(default=0)

    class Meta:
        db_table = "plant_machinery_hire_bill_invoice_item"        

class PlantMachineryHireBillInvoiceAttachments(BaseAbstractStructure):
    """
    Plant Machinery Hire Bill Attachments
    """
    ATTACHMENT_TYPE_CHOICES = (
        ('tax_invoice', 'Tax Invoice'),
        ('debit_note_or_credit_note', 'Debit Note or Credit Note'),
    )

    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_hire_bill_invoice_attachments',on_delete=models.CASCADE)
    plant_machinery_hire_bill_invoice_item = models.ForeignKey(PlantMachineryHireBillInvoiceItem,related_name='plant_machinery_hire_bill_invoice_attachments',on_delete=models.CASCADE,null=True,blank=True)
    type = models.CharField(max_length=50, choices=ATTACHMENT_TYPE_CHOICES, null=True, blank=True)
    attachment = models.FileField(upload_to='plant_machinery/hire_bill_invoice', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_hire_bill_invoice_attachments"


class PlantMachineryHireBillInvoiceStages(BaseAbstractStructure):
    """
    PlantMachinery HireBilltages
    """
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_hire_bill_invoice_stages', on_delete=models.CASCADE
    )
    plant_machinery_hire_bill_invoice= models.ForeignKey(PlantMachineryHireBillInvoice,related_name='plant_machinery_hire_bill_invoice_stages',on_delete=models.CASCADE,null=True,blank=True)
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_stages_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_stages_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_stages_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_stages_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="plant_machinery_hire_bill_invoice_stages_rejected_by", on_delete=models.CASCADE)
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    is_web = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.plant_machinery_hire_bill_invoice} -> Stage {self.stage} [{self.status}]"

    class Meta:
        db_table = "plant_machinery_hire_bill_invoice_stages"


class PlantMachineryHSDApproval(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
   
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_hsd_approval', on_delete=models.CASCADE)

    project = models.ForeignKey(
        "project_and_planning.ProjectMaster", 
        related_name='project_plant_machinery_hsd_approval', 
        on_delete=models.CASCADE , null=True, blank=True
    )
    site = models.ForeignKey("procurement.SiteMaster", related_name='site_master_plant_machinery_hsd_approval', blank=True, null=True, on_delete=models.CASCADE)
    store = models.ForeignKey("procurement.StoreMaster", on_delete=models.CASCADE, null=True, blank=True, related_name='store_master_plant_machinery_hsd_approval',)
    financialyear = models.ForeignKey("procurement.FinancialYear", related_name='financial_year_plant_machinery_hsd_approval', on_delete=models.CASCADE, blank=True, null=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    previous_version = models.ForeignKey('self', related_name='plant_machinery_hsd_approval_previous_version',
                                on_delete=models.CASCADE, null=True, blank=True)
    latest = models.BooleanField(default=True)
    request_code = models.CharField(max_length=255, null=True, blank=True)
    version = models.IntegerField(default=1)
    date = models.DateField(null=True, blank=True)
    fuel_rate_petrol = models.FloatField(default=0.0)
    fuel_rate_hsd = models.FloatField(default=0.0)
    remarks = models.TextField(null=True, blank=True)
    current_stage = models.IntegerField(default=0)
    checked_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    sanctioned_remarks = models.TextField(null=True, blank=True)
    
     # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    ref_stage_type = models.ForeignKey("procurement.MultiStageSetting", related_name='+', blank=True, null=True, on_delete=models.CASCADE)

    class Meta:
        db_table = "plant_machinery_hsd_approval"

class PlantMachineryHSDApprovalItem(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_hsd_approval_item', on_delete=models.CASCADE)
    hsd_approval = models.ForeignKey(
        PlantMachineryHSDApproval,
        related_name='hsd_approval_plant_machinery_hsd_approval_item',
        on_delete=models.CASCADE, null=True,blank=True,
    )
    
    plant_machinery_machine = models.ForeignKey(
        PlantMachineryMachine,
        related_name='plant_machinery_machines_plant_machinery_hsd_approval_item',
        blank=True,
        null=True,
        on_delete=models.CASCADE
    )
    from_date=models.DateField(null=True, blank=True)
    to_date=models.DateField(null=True, blank=True)
    requirement_per_day = models.FloatField(default=0.0)
    remarks = models.TextField(null=True, blank=True)
    
    class Meta:
        db_table = "plant_machinery_hsd_approval_item"

class PlantMachineryHSDApprovalAttachments(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_hsd_approval_attachment', on_delete=models.CASCADE)
    hsd_approval = models.ForeignKey(
        PlantMachineryHSDApproval,
        related_name='hsd_approval_plant_machinery_hsd_approval_attachment',
        on_delete=models.CASCADE, null=True,blank=True,
    )
    attachment = models.FileField(upload_to='plant_machinery/hsd_approval', null=True, blank=True)
    mime_type = models.CharField(max_length=255, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    attachment_name = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        db_table = "plant_machinery_hsd_approval_attachments"

class PlantMachineryHSDApprovalStages(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organizations_plant_machinery_hsd_approval_stages', on_delete=models.CASCADE)
    hsd_approval = models.ForeignKey(
            PlantMachineryHSDApproval,
            related_name='hsd_approval_plant_machinery_hsd_approval_stages',
            on_delete=models.CASCADE, null=True,blank=True,
        )    
    stage = models.IntegerField(default=1)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    remarks = models.TextField(max_length=500, null=True, blank=True)

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="+", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    is_web = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.hsd_approval} -> {self.stage} {self.status}"

    class Meta:
        db_table = "plant_machinery_hsd_approval_stages"

