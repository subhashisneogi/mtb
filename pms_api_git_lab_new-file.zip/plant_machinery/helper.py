from django.db.models import Q
import json
import base64
import os
from urllib.parse import urlencode
from plant_machinery.models import *
from procurement.helper import generate_all_code
from procurement.models import SiteMaster, StoreMaster
from project_and_planning.models import ProjectData , ProjectMaster
import pandas as pd
from django.db import transaction
from email_config.models import *
from administrations.utils import hrms_request,schedule_generic_mail
from procurement.helper import get_vendor_data
def get_plantmachinerygroup_by_name(name):
    return PlantMachineryGroup.cmobjects.filter(name__iexact=name).first()

def get_plantmachinerymachine_by_name(name):
    return PlantMachineryMachine.cmobjects.filter(equipment_description__iexact=name).first()


def get_plantmachineryservicegroup_by_name(name):
    return PlantMachineryServiceGroup.cmobjects.filter(name__iexact=name).first()


def get_plantmachineryserviceitem_by_name(name):
    return PlantMachineryServiceItem.cmobjects.filter(name__iexact=name).first()


def get_plantmachineryactivitygroup_by_code(name):
    return PlantMachineryActivityGroup.cmobjects.filter(code__iexact=name).first()


def get_uom_by_symbol(name):
    return UnitOfMesurement.cmobjects.filter(symbol__iexact=name).first()


def get_site_by_name(name):
    return SiteMaster.cmobjects.filter(site_name__iexact=name).first()


def get_objective_indication_type_by_name(name):
    return PlantMachineryObjectiveIndicationType.cmobjects.filter(name__iexact=name).first()


def get_tax_head_by_name(name):
    return TaxHead.cmobjects.filter(name__icontains=name).first()


def get_store_by_name(name):
    return StoreMaster.cmobjects.filter(store_name__iexact=name).first()

def get_job_sheet_by_code(name):
    return PlantMachineryJobSheet.cmobjects.filter(jobsheet_number__iexact=name).first()


# def get_project_by_name(name):
#     project_details = ProjectData.cmobjects.select_related('form').filter(
#         form__form_type='project_details',
#         form__form_internal_name='project_name',
#         value__iexact=name
#     ).first()
#     return project_details.project if project_details else None
def get_project_by_name(name):
    project_details = ProjectMaster.cmobjects.filter(
        project_name__iexact=name
    ).first()
    return project_details.id if project_details else None


def get_user_by_name(name):
    query = Q()
    query |= Q(**{f'username__icontains': name})
    if len(name.split(' ')) > 1:
        query |= Q(**{f'first_name__icontains': name.split(' ')[0].strip()})
        query |= Q(**{f'last_name__icontains': name.split(' ')[1].strip()})
    else:
        query |= Q(**{f'first_name__icontains': name})
        query |= Q(**{f'last_name__icontains': name})
    return PmsUser.objects.filter(query).first()


def get_vendor_by_name(name):
    vendormasterdata = VendorMasterV2.cmobjects.filter(
        vendor_name__iexact=name
    ).first()
    return vendormasterdata.id if vendormasterdata else None


def update_jobsheet_number():
    '''
    update jobsheet_number if empty
    '''

    plantmachineryjobsheets = PlantMachineryJobSheet.cmobjects.filter(Q(jobsheet_number__isnull=True) or Q(jobsheet_number=""))
    for jobsheet in plantmachineryjobsheets:
        jobsheet.jobsheet_number = generate_all_code(jobsheet,['JS'])
        jobsheet.save()




def handle_nan(value, default=0):
    """ Helper function to handle NaN values for integers and floats. """
    if pd.isna(value):
        return default
    return value
def handle_date(value, default=None):
    if pd.isna(value) or value == "":
        return default
    try:
        return pd.to_datetime(value, errors='coerce').date()
    except Exception as e:
        return default


    