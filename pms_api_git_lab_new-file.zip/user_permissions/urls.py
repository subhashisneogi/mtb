from django.urls import path
from user_permissions import views


urlpatterns = [
    
]