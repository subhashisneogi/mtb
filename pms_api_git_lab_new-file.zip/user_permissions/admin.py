from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from unfold.contrib.filters.admin import AutocompleteSelectMultipleFilter

from .models import *
     

@admin.register(UserPermissions)
class UserPermissionsAdmin(ModelAdmin):
    model = UserPermissions
    search_fields = ['role__role_name','menu__menu_name']
    list_display = ['role','menu','has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission']
    list_editable = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
    list_filter = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
     

@admin.register(UserSubModulePermissions)
class UserSubModulePermissionsAdmin(ModelAdmin):
    model = UserSubModulePermissions
    search_fields = ['role__role_name','sub_menu__sub_menu_name','menu__menu_name']
    list_display = ['role','sub_menu','menu','has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission']
    list_editable = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
    list_filter = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
     

@admin.register(UserWisePermissions)
class UserWisePermissionsAdmin(ModelAdmin):
    model = UserWisePermissions
    search_fields = ['role__role_name','menu__menu_name','user__username']
    list_display = ['user','role','menu','has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission']
    list_editable = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
    list_filter = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
     

@admin.register(UserWiseSubModulePermissions)
class UserWiseSubModulePermissionsAdmin(ModelAdmin):
    model = UserWiseSubModulePermissions
    search_fields = ['role__role_name','sub_menu__sub_menu_name','menu__menu_name','user__username']
    list_display = ['user','role','sub_menu','menu','has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission']
    list_editable = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
    list_filter = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
     

@admin.register(UserModulePermissions)
class UserModulePermissionsAdmin(ModelAdmin):
    model = UserModulePermissions
    search_fields = ['role__role_name','module_item__name']
    list_display = ['role','module_item','level_permission']
    list_editable = ['level_permission',]
    list_filter = ['level_permission',]
     

@admin.register(UserWiseModulePermissions)
class UserWiseModulePermissionsAdmin(ModelAdmin):
    model = UserWiseModulePermissions
    search_fields = ['role__role_name','module_item__name','user__username']
    list_display = ['user','role','module_item','level_permission']
    list_editable = ['level_permission',]
    list_filter = (
        'level_permission',
        ["module_item", AutocompleteSelectMultipleFilter],
        ["user", AutocompleteSelectMultipleFilter],
    )
     

@admin.register(UserSettingsPermissions)
class UserSettingsPermissionsAdmin(ModelAdmin):
    model = UserSettingsPermissions
    search_fields = ['role__role_name','setting_item__name']
    list_display = ['role','setting_item','has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission']
    list_editable = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
    list_filter = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
     

@admin.register(UserWiseSettingPermissions)
class UserWiseSettingPermissionsAdmin(ModelAdmin):
    model = UserWiseSettingPermissions
    search_fields = ['role__role_name','setting_item__name','user__username']
    list_display = ['user','role','setting_item','has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission']
    list_editable = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
    list_filter = ['has_view_permission','has_add_permission','has_edit_permission','has_delete_permission','has_export_permission','level_permission',]
     

@admin.register(UserAdministrativePermissions)
class UserAdministrativePermissionsAdmin(ModelAdmin):
    model = UserAdministrativePermissions
    search_fields = ['role__role_name','admin_item__name']
    list_display = ['role','admin_item','has_import_permission','has_approval_permission','has_approval_submit_permission','has_export_permission','level_permission']
    list_editable = ['has_import_permission','has_approval_permission','has_approval_submit_permission','has_export_permission','level_permission',]
    list_filter = ['has_import_permission','has_approval_permission','has_approval_submit_permission','has_export_permission','level_permission',]
     

@admin.register(UserWiseAdministrativePermissions)
class UserWiseAdministrativePermissionsAdmin(ModelAdmin):
    model = UserWiseAdministrativePermissions
    search_fields = ['role__role_name','admin_item__name','user__username']
    list_display = ['user','role','admin_item','has_import_permission','has_approval_permission','has_approval_submit_permission','has_export_permission','level_permission']
    list_editable = ['has_import_permission','has_approval_permission','has_approval_submit_permission','has_export_permission','level_permission',]
    list_filter = ['has_import_permission','has_approval_permission','has_approval_submit_permission','has_export_permission','level_permission',]


