from django.db import models


from administrations.models import *
# Create your models here.


class UserPermissions(BaseAbstractStructure):
    """
    Master Model For User Permissions
    """
    organization = models.ForeignKey(Organization, related_name='permission_organization',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='permission_roles',on_delete=models.CASCADE, blank=True, null=True)
    menu = models.ForeignKey(MenuMaster, related_name='permission_menu',on_delete=models.CASCADE, blank=True, null=True)
    has_view_permission = models.BooleanField(default=False)
    has_add_permission = models.BooleanField(default=False)
    has_edit_permission = models.BooleanField(default=False)
    has_delete_permission = models.BooleanField(default=False)
    has_export_permission = models.BooleanField(default=False)
    level_permission = models.BooleanField(default=False)


    def __str__(self):
        if self.role:
            return str(self.role.role_name) + " - " + str(self.menu.menu_name)
        else:
            return self.id 

class UserSubModulePermissions(BaseAbstractStructure):
    """
    Master Model For User Sub Module Permissions
    """
    organization = models.ForeignKey(Organization, related_name='sub_permission_organization',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='sub_permission_roles',on_delete=models.CASCADE, blank=True, null=True)
    menu = models.ForeignKey(MenuMaster, related_name='sub_permission_menu',on_delete=models.CASCADE, blank=True, null=True)
    sub_menu = models.ForeignKey(SubMenuMaster, related_name='permission_sub_menu',on_delete=models.CASCADE, blank=True, null=True)
    has_view_permission = models.BooleanField(default=False)
    has_add_permission = models.BooleanField(default=False)
    has_edit_permission = models.BooleanField(default=False)
    has_delete_permission = models.BooleanField(default=False)
    has_export_permission = models.BooleanField(default=False)
    level_permission = models.BooleanField(default=False)


    def __str__(self):
        if self.role:
            return self.role.role_name
        else:
            return self.id


class UserAdministrativePermissions(BaseAbstractStructure):
    """
    Master Model For User Administrative Permissions
    """ 
    organization = models.ForeignKey(Organization, related_name='administrative_organization',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='administrative_roles',on_delete=models.CASCADE, blank=True, null=True)
    admin_item = models.ForeignKey(AdministrativeMaster, related_name='administrative_items',on_delete=models.CASCADE, blank=True, null=True)
    has_import_permission = models.BooleanField(default=False)
    has_approval_permission = models.BooleanField(default=False)
    has_approval_submit_permission = models.BooleanField(default=False)
    has_export_permission = models.BooleanField(default=False)
    level_permission = models.BooleanField(default=False)


    def __str__(self):
        if self.role:
            return self.role.role_name
        else:
            return self.id 
        

class UserSettingsPermissions(BaseAbstractStructure):
    """
    Master Model For User Settings Permissions
    """ 
    organization = models.ForeignKey(Organization, related_name='setting_organization',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='setting_roles',on_delete=models.CASCADE, blank=True, null=True)
    setting_item = models.ForeignKey(SettingsMaster, related_name='setting_items',on_delete=models.CASCADE, blank=True, null=True)
    has_view_permission = models.BooleanField(default=False)
    has_add_permission = models.BooleanField(default=False)
    has_edit_permission = models.BooleanField(default=False)
    has_delete_permission = models.BooleanField(default=False)
    has_export_permission = models.BooleanField(default=False)
    level_permission = models.BooleanField(default=False)


    def __str__(self):
        if self.role:
            return self.role.role_name
        else:
            return self.id 
        

class UserModulePermissions(BaseAbstractStructure):
    """
    Master Model For User Module Permissions
    """ 
    organization = models.ForeignKey(Organization, related_name='module_organization',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='module_roles',on_delete=models.CASCADE, blank=True, null=True)
    module_item = models.ForeignKey(ModulePermissionsMaster, related_name='module_items',on_delete=models.CASCADE, blank=True, null=True)
    level_permission = models.BooleanField(default=False)


    def __str__(self):
        if self.role:
            return self.role.role_name
        else:
            return self.id 
        

################ User Level Permission Module ################################

class UserWisePermissions(BaseAbstractStructure):
    """
    Master Model For User Permissions
    """
    organization = models.ForeignKey(Organization, related_name='permission_organization_userwise',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='permission_roles_userwise',on_delete=models.CASCADE, blank=True, null=True)
    user = models.ForeignKey(PmsUser, related_name='permission_roles_user',on_delete=models.CASCADE, blank=True, null=True)
    menu = models.ForeignKey(MenuMaster, related_name='permission_menu_userwise',on_delete=models.CASCADE, blank=True, null=True)
    has_view_permission = models.BooleanField(default=False)
    has_add_permission = models.BooleanField(default=False)
    has_edit_permission = models.BooleanField(default=False)
    has_delete_permission = models.BooleanField(default=False)
    has_export_permission = models.BooleanField(default=False)
    level_permission = models.BooleanField(default=False)

    class Meta:
        unique_together = ('user', 'menu')

    def __str__(self):
        if self.user and self.menu:
            return self.user.username + '|' + str(self.menu.menu_name)
        elif self.role:
            return self.role.role_name
        else:
            return str(self.id) 

class UserWiseSubModulePermissions(BaseAbstractStructure):
    """
    Master Model For User Sub Module Permissions
    """
    organization = models.ForeignKey(Organization, related_name='sub_permission_organization_userwise',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='sub_permission_roles_userwise',on_delete=models.CASCADE, blank=True, null=True)
    user = models.ForeignKey(PmsUser, related_name='sub_permission_menu_user',on_delete=models.CASCADE, blank=True, null=True)
    menu = models.ForeignKey(MenuMaster, related_name='sub_permission_menu_userwise',on_delete=models.CASCADE, blank=True, null=True)
    sub_menu = models.ForeignKey(SubMenuMaster, related_name='permission_sub_menu_userwise',on_delete=models.CASCADE, blank=True, null=True)
    has_view_permission = models.BooleanField(default=False)
    has_add_permission = models.BooleanField(default=False)
    has_edit_permission = models.BooleanField(default=False)
    has_delete_permission = models.BooleanField(default=False)
    has_export_permission = models.BooleanField(default=False)
    level_permission = models.BooleanField(default=False)

    class Meta:
        unique_together = ('user', 'menu', 'sub_menu')



    def __str__(self):
        if self.user and self.menu and self.sub_menu:
            return str(self.user.username) + '(' +str(self.user.id) + ')' + '|' + str(self.menu.menu_name) + '|' + str(self.sub_menu.sub_menu_name)
        elif self.role:
            return self.role.role_name
        else:
            return str(self.id)


class UserWiseAdministrativePermissions(BaseAbstractStructure):
    """
    Master Model For User Administrative Permissions
    """ 
    organization = models.ForeignKey(Organization, related_name='administrative_organization_userwise',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='administrative_roles_userwise',on_delete=models.CASCADE, blank=True, null=True)
    user = models.ForeignKey(PmsUser, related_name='administrative_roles_user',on_delete=models.CASCADE, blank=True, null=True)
    admin_item = models.ForeignKey(AdministrativeMaster, related_name='administrative_items_userwise',on_delete=models.CASCADE, blank=True, null=True)
    has_import_permission = models.BooleanField(default=False)
    has_approval_permission = models.BooleanField(default=False)
    has_approval_submit_permission = models.BooleanField(default=False)
    has_export_permission = models.BooleanField(default=False)
    level_permission = models.BooleanField(default=False)


    def __str__(self):
        if self.role:
            return self.role.role_name
        else:
            return str(self.id) 
        

class UserWiseSettingPermissions(BaseAbstractStructure):
    """
    Master Model For User Setting Permissions
    """ 
    organization = models.ForeignKey(Organization, related_name='setting_items_organization_userwise',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='setting_items_userwise',on_delete=models.CASCADE, blank=True, null=True)
    user = models.ForeignKey(PmsUser, related_name='setting_items_user',on_delete=models.CASCADE, blank=True, null=True)
    setting_item = models.ForeignKey(SettingsMaster, related_name='setting_items_user',on_delete=models.CASCADE, blank=True, null=True)
    has_view_permission = models.BooleanField(default=False)
    has_add_permission = models.BooleanField(default=False)
    has_edit_permission = models.BooleanField(default=False)
    has_delete_permission = models.BooleanField(default=False)
    has_export_permission = models.BooleanField(default=False)
    level_permission = models.BooleanField(default=False)


    def __str__(self):
        if self.role:
            return self.role.role_name
        else:
            return str(self.id) 
        

class UserWiseModulePermissions(BaseAbstractStructure):
    """
    Master Model For User Module Permissions
    """ 
    organization = models.ForeignKey(Organization, related_name='module_wise_organization',on_delete=models.CASCADE, blank=True, null=True)
    role = models.ForeignKey(Profile, related_name='module_wise_roles',on_delete=models.CASCADE, blank=True, null=True)
    module_item = models.ForeignKey(ModulePermissionsMaster, related_name='module_wise_items',on_delete=models.CASCADE, blank=True, null=True)
    user = models.ForeignKey(PmsUser, related_name='modules_perm_user',on_delete=models.CASCADE, blank=True, null=True)
    level_permission = models.BooleanField(default=False)

    class Meta:
        unique_together = ('user', 'module_item',)


    def __str__(self):
        if self.module_item:
            return str(self.module_item) + '/ ' +self.user.username + ' (' + str(self.user.id) + ')'
        elif self.role:
            return self.role.role_name
        else:
            return self.id 