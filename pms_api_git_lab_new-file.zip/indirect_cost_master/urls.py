from django.urls import path
from indirect_cost_master import views


urlpatterns = [

    path('indirect-cost-category/', views.IndirectCostCategoryAPIView.as_view()),
    path('indirect-cost-master/', views.IndirectCostMasterAPIView.as_view()),

]