from colorama import Back, Style
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException
from datetime import date

from .models import *
from .serializers import *
from procurement.helper import *
# Create your views here.


class IndirectCostCategoryAPIView(APIView):
    """
    CRUD API for IndirectCostCategory model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all IndirectCostCategory
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            indirect_cost_category_details = IndirectCostCategory.cmobjects.filter(id=id).first()
            serializer = IndirectCostCategorySerializer(indirect_cost_category_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        indirect_cost_category_list = IndirectCostCategory.cmobjects.filter(*search).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(indirect_cost_category_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = IndirectCostCategorySerializer(page, many=True)

        if all == 'true':
            serializer = IndirectCostCategorySerializer(indirect_cost_category_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new IndirectCostCategory
        """
        request.data['created_by_id'] = request.user.id
        serializer = IndirectCostCategorySerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a IndirectCostCategory
                """

                if IndirectCostCategory.cmobjects.filter(pk=id,
                                             organization_id=organization_id).exists():

                    indirect_cost_category_details = IndirectCostCategory.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = IndirectCostCategorySerializer(indirect_cost_category_details, data=request.data)
                    if serializer.is_valid():
                        serializer.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a IndirectCostCategory
                """
                if IndirectCostCategory.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    indirect_cost_category_details = IndirectCostCategory.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    if indirect_cost_category_details.is_system_defined:
                        raise APIException({'request_status': 0, 'msg': "System defined Indirect Cost Category cannot be deleted"})
                    else:
                        indirect_cost_category_details.updated_by_id = request.user.id
                        indirect_cost_category_details.is_deleted = True
                        indirect_cost_category_details.save()

                        return Response({'results': {
                            'indirect_cost_category': IndirectCostCategory.objects.filter(pk=id, organization_id=organization_id).values(),
                        },
                            'msg': 'Successfully deleted Indirect Cost Category',
                            "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

class IndirectCostMasterAPIView(APIView):
    """
    CRUD API for IndirectCostMaster model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all IndirectCostMaster
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            indirect_cost_master_details = IndirectCostMaster.cmobjects.filter(id=id).first()
            serializer = IndirectCostMasterSerializer(indirect_cost_master_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        indirect_cost_master_list = IndirectCostMaster.cmobjects.filter(*search).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(indirect_cost_master_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = IndirectCostMasterSerializer(page, many=True)

        if all == 'true':
            serializer = IndirectCostMasterSerializer(indirect_cost_master_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new IndirectCostMaster
        """
        if isinstance(request.data, list):
            with transaction.atomic():
                return_data = []
                for bulk_data in request.data:
                    bulk_data['created_by'] = request.user.id
                    serializer = IndirectCostMasterSerializer(data=bulk_data)
                    if serializer.is_valid():
                        serializer.save()
                        return_data.append(serializer.data)
                    else:
                        raise APIException({'request_status': 0, 'msg': serializer.errors})
                return Response({'results': {'Data': return_data,},
                                'msg': 'Successfully created',
                                'status': status.HTTP_201_CREATED,
                                "request_status": 1})
        else:
            raise APIException({'request_status': 0, 'msg': "Invalid body"})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        if method.lower() == 'edit':
            """
            Update a IndirectCostMaster
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']

                        if IndirectCostMaster.cmobjects.filter(pk=id,
                                                        organization_id=organization_id).exists():

                            indirect_cost_master_details = IndirectCostMaster.cmobjects.filter(pk=id).first()
                            bulk_data['updated_by'] = request.user.id
                            serializer = IndirectCostMasterSerializer(indirect_cost_master_details, data=bulk_data)

                            if serializer.is_valid():
                                serializer.save()
                                return_data.append(serializer.data)
                            else:
                                raise APIException({'request_status': 0, 'msg': serializer.errors})
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'Data': return_data,},
                                    'msg': "Sucessfully updated",
                                    'status': status.HTTP_202_ACCEPTED,
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})
        elif method.lower() == 'delete':
            """
            Delete a IndirectCostMaster
            """
            if isinstance(request.data, list):
                with transaction.atomic():
                    return_data = []
                    for bulk_data in request.data:
                        id = bulk_data['id']
                        if IndirectCostMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                            indirect_cost_master_details = IndirectCostMaster.cmobjects.get(
                                pk=id, organization_id=organization_id)
                            indirect_cost_master_details.updated_by_id = request.user.id
                            indirect_cost_master_details.is_deleted = True
                            indirect_cost_master_details.save()
                            return_data.append(IndirectCostMaster.objects.filter(pk=id, organization_id=organization_id).values())
                        else:
                            raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                    return Response({'results': {'indirect_cost_master': return_data,},
                                    'msg': 'Successfully deleted Indirect Cost Master',
                                    "request_status": 1})
            else:
                raise APIException({'request_status': 0, 'msg': "Invalid body"})