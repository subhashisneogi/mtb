from django.db import models

from administrations.models import *
from material_master.models import *
# Create your models here.

class IndirectCostCategory(BaseAbstractStructure):
    """
    Indirect Cost Component
    """
    organization = models.ForeignKey(Organization, related_name='indirect_cost_category_organization',
                                     on_delete=models.DO_NOTHING)
    name = models.CharField(max_length=255)
    is_system_defined = models.BooleanField(default=False)

    def __str__(self):
        return str(self.name)

    class Meta:
        unique_together = ('organization','name',)
        db_table = "indirect_cost_category"

class IndirectCostMaster(BaseAbstractStructure):
    """
    Indirect Cost Master
    """
    organization = models.ForeignKey(Organization, related_name='indirect_cost_master_organization',
                                     on_delete=models.DO_NOTHING)
    indirect_cost_category = models.ForeignKey(IndirectCostCategory, related_name='indirect_cost_master_indirect_cost_category',
                                     on_delete=models.DO_NOTHING, blank=True, null=True)
    name = models.CharField(max_length=255)
    uom = models.ForeignKey(UnitOfMesurement, related_name='indirect_cost_master_uom',
                            on_delete=models.DO_NOTHING, blank=True, null=True)
    rate = models.FloatField(default=0)

    def __str__(self):
        return str(self.name) + ' ( ' + str(self.indirect_cost_category.name) + ' )'

    class Meta:
        unique_together = ('organization','name','uom','indirect_cost_category',)
        db_table = "indirect_cost_master"
    
