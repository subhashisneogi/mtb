from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline

from .models import *
# Register your models here.

admin.site.register(IndirectCostCategory,ModelAdmin)
admin.site.register(IndirectCostMaster,ModelAdmin)