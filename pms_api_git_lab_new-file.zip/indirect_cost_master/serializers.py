from colorama import Back, Style
from rest_framework import serializers
from .models import *


class IndirectCostCategorySerializer(serializers.ModelSerializer):
    """"
    Indirect Cost Component Serializer
    """

    class Meta:
        model = IndirectCostCategory
        fields = '__all__'

class IndirectCostMasterSerializer(serializers.ModelSerializer):
    """"
    Indirect Cost Master Serializer
    """

    class Meta:
        model = IndirectCostMaster
        fields = '__all__'