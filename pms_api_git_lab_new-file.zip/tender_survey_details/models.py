from django.db import models
from tender.models import *


# Create your models here.
class SurveyDetailsGroup(BaseAbstractStructure):
    """ Survey Deatils Group Model """
    organization = models.ForeignKey(Organization, related_name='organization_survey_group', on_delete=models.CASCADE, null=True, blank=True)
    name =  models.CharField(max_length=100, null=True, blank=True)
    tender_id = models.ForeignKey(TenderMaster, related_name="survey_group_tender_id", on_delete=models.CASCADE, null=True, blank=True)


class SurveyBasicDetails(BaseAbstractStructure):
    """ Survey Basic Details Model  """

    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='basic_details_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    date_of_survey = models.DateField(null=True, blank=True)   
    name_of_work = models.CharField(max_length=100, null=True, blank=True)  
    name_of_client = models.CharField(max_length=100, null=True, blank=True)
    survey_done_by = models.CharField(max_length=100, null=True, blank=True)


class SurveyLocationDetails(BaseAbstractStructure):
    """ Survey Location Details Model  """
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='location_details_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    city_town_area_name = models.DateField(null=True, blank=True)  
    city_town_area_distance = models.DateField(null=True, blank=True)
    district_name = models.CharField(max_length=100, null=True, blank=True)
    district_distance = models.IntegerField(null=True, blank=True)
    state_name = models.CharField(max_length=100, null=True, blank=True)
    state_distance = models.IntegerField(null=True, blank=True)
    nearest_railway_station_name = models.CharField(max_length=100, null=True, blank=True)
    nearest_railway_station_distance = models.IntegerField(null=True, blank=True)


class SurveyNatureOfWork(BaseAbstractStructure):
    """ Survey Nature Of Work Model  """
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='nature_of_work_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    is_bridgework = models.BooleanField(default=False)
    is_roadwork = models.BooleanField(default=False)
    is_railway_earthwork = models.BooleanField(default=False)
    is_canal_lining = models.BooleanField(default=False)
    nos = models.CharField(max_length=200, null=True, blank=True)
    length = models.DecimalField(max_digits=30,decimal_places=20,blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)


class SurveyBridgeWork(BaseAbstractStructure):
    """
    Survey Bridge Work Model
    """
    CATEGORY_CHOICES = [
        ("Yes", "Yes"),
        ("No", "No"),
    ]
    FOUNDATION_CHOICES = [
        ("Open ", "Open "),
        ("Well", "Well"),
        ("Pile", "Pile"),
    ]
    SUPER_STRUCTURE_CHOICES = [
        ("RCC Box ", "RCC Box "),
        ("RCC T-Beam &  Slab", "RCC T-Beam &  Slab"),
        ("RCC Slab", "RCC Slab"),
        ("PSC Girder & Slab  ", "PSC Girder & Slab  "),
        ("PSC Box ", "PSC Box "),
        ("PSC Segmental", "PSC Segmental"),
        ("Composite Steel Structure", "Composite Steel Structure"),
        ("Full Steel Structure", "Full Steel Structure"),
    ]
    APPROACH_CHOICES = [
        ("None ", "None  "),
        ("Bad", "Bad"),
        ("Good", "Good"),
        ("Excellent ", "Excellent "),
    ]

    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='bridge_work_survey_group', on_delete=models.CASCADE, null=True, blank=True)
    bridge_number_or_chaingage_number  = models.CharField(max_length=200,blank=True,null=True)
    length_of_bridge_or_no_of_spans= models.IntegerField( default=0,blank=True, null=True)
    type_of_foundation=models.CharField(choices=FOUNDATION_CHOICES, default="NONE", \
        max_length=200,blank=True,null=True)
    type_of_super_structure=models.CharField(choices=SUPER_STRUCTURE_CHOICES, default="NONE",\
                                             max_length=300,blank=True, null=True)
    location_of_bridge_start_bridge=models.CharField(max_length=200,blank=True,null=True)
    location_of_bridge_end_bridge=models.CharField(max_length=200,blank=True,null=True)
    is_the_bridge_approachable_from_both_sides=models.CharField(choices=CATEGORY_CHOICES, default="NONE", \
        max_length=200,blank=True,null=True)
    remarks_for_above_if_any = models.TextField(blank=True, null=True)
    condition_of_approach_road=models.\
        CharField(choices=APPROACH_CHOICES, default="NONE", \
        max_length=300,blank=True,null=True)
    is_site_approachable_by_trailer=models.\
        CharField(choices=CATEGORY_CHOICES, default="NONE", \
        max_length=300,blank=True,null=True)
    remarks_for_approach_road=models.CharField(max_length=200,blank=True,null=True)
    length_of_Bridge_over_water = models.DecimalField( max_digits=30,decimal_places=20,blank=True, null=True)
    average_height_of_bridge =models.DecimalField( max_digits=30,decimal_places=20,blank=True, null=True)
    maximum_height_of_bridge=models.DecimalField( max_digits=30,decimal_places=20,blank=True, null=True)
    any_remarks = models.TextField(blank=True, null=True)



class SurveyApproachRoadWork(BaseAbstractStructure):
    """
    Survey Approach Road Work Model
    """
    APPROACH_CHOICES = [
        ("None ", "None  "),
        ("Bad", "Bad"),
        ("Good", "Good"),
        ("Excellent ", "Excellent "),

    ]
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='road_work_survey_group', on_delete=models.CASCADE, null=True, blank=True)
    location_of_approach_road_start_of_bridge=models.CharField(max_length=200,blank=True,null=True)
    location_of_approach_road_end_of_bridge=models.CharField(max_length=200,blank=True,null=True)
    length_of_approach_road_start_of_bridge=models.CharField(max_length=200,blank=True,null=True)
    length_of_approach_road_end_of_bridge=models.CharField(max_length=200,blank=True,null=True)
    number_of_minor_bridges_in_approach_start_of_bridge=models.IntegerField( default=0,blank=True, null=True)
    number_of_minor_bridges_in_approach_end_of_bridge=models.IntegerField( default=0,blank=True, null=True)   
    number_of_culverts_in_approach_start_of_bridge=models.IntegerField( default=0,blank=True, null=True)   
    number_of_culverts_in_approach_end_of_bridge=models.IntegerField( default=0,blank=True, null=True)   
    average_height_of_approach_start_of_bridge=models.DecimalField( max_digits=30,decimal_places=20,blank=True, null=True)
    average_height_of_approach_end_of_bridge=models.DecimalField( max_digits=30,decimal_places=20,blank=True, null=True)
    maximum_height_of_approach_start_of_bridge=models.DecimalField( max_digits=30,decimal_places=20,blank=True, null=True)
    maximum_height_of_approach_end_of_bridge=models.DecimalField( max_digits=30,decimal_places=20,blank=True, null=True)
    condition_of_existing_approach_at_start_of_bridge=models.\
        CharField(choices=APPROACH_CHOICES, default="NONE", \
        max_length=300,blank=True,null=True)
    condition_of_existing_approach_at_end_of_bridge=models.\
        CharField(choices=APPROACH_CHOICES, default="NONE", \
        max_length=300,blank=True,null=True)
    any_remarks = models.TextField(blank=True, null=True)


class SurveyMaterialRates(BaseAbstractStructure):
    """
    Survey Material Rates Model
    """
    CATEGORY_CHOICES = [
        ("10 mm Stone Chips", "10 mm Stone Chipsl"),
        ("20 mm Stone Chips", "20 mm Stone Chips"),
        ("40 mm Stone Chips","40 mm Stone Chips"),
        ("Stone Dust","Stone Dust"),
        ("Boulder","Boulder"),
        ("GSB Material","GSB Material"),
        ("Coarse Sand","Coarse Sand"),
        ("Fine Sand","Fine Sand"),
        ("Soil","Soil"),
    ]
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='materials_rates_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    material_type_rates= models.CharField(choices=CATEGORY_CHOICES, default="NONE", max_length=200,blank=True, null=True)
    unit = models.IntegerField(default=0,blank=True, null=True)
    basic =  models.IntegerField(default=0,blank=True, null=True)
    carriage =  models.IntegerField(default=0,blank=True, null=True)
    royality = models.IntegerField(default=0, blank=True, null=True)
    total = models.IntegerField(default=0,blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
  
    def __str__(self):
        return self.survey_group
    

class SurveyHydrologicalData():
    """ Survey Hydrological Data Model  """

    unit_type = [
        ("meter", "meter"),
        ("foot", "foot"),
    ]
    CATEGORY_CHOICES = [
        ("Yes", "Yes"),
        ("No", "No"),
    ]

    WATER_SOURCE_CHOICES = [
        ("Rain", "Rain"),
        ("Dam", "Dam"),
        ("River", "River"),
        ("Sea", "Sea"),
    ]
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='hydrological_data_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    rainy_season_from = models.DateField(null=True, blank=True)
    rainy_season_to = models.DateField(null=True, blank=True)
    water_depth_during_dry_season = models.CharField(max_length=100, blank=True, null=True)
    water_depth_during_dry_season_depth_unit = models.CharField(max_length=100, choices=unit_type, default="meter", blank=True, null=True)
    water_depth_during_rainy_season = models.CharField(max_length=100, blank=True, null=True)
    water_depth_during_rainy_season_depth_unit = models.CharField(max_length=100, choices=unit_type, default="meter", blank=True, null=True)
    water_flow_during_dry_season = models.CharField(max_length=100, blank=True, null=True)
    water_flow_during_dry_season_unit = models.CharField(max_length=100, choices=unit_type, default="meter", blank=True, null=True)
    water_flow_during_rainy_season = models.CharField(max_length=100, blank=True, null=True)
    water_flow_during_rainy_season_unit = models.CharField(max_length=100, choices=unit_type, default="meter", blank=True, null=True)
    water_affected_by_tides = models.CharField(max_length=100, choices=CATEGORY_CHOICES, default="No", blank=True, null=True)
    difference_in_water_level_due_to_tides = models.CharField(max_length=100, choices=unit_type, default="meter", blank=True, null=True)
    source_of_water = models.CharField(max_length=100, choices=WATER_SOURCE_CHOICES, default="meter", blank=True, null=True)
    name_of_dam = models.CharField(max_length=100, blank=True, null=True)
    name_of_river = models.CharField(max_length=100, blank=True, null=True)
    name_of_sea = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.survey_group


class DocumentsToBeCollected(BaseAbstractStructure):
    """ Documents To Be Collected Model  """

    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='documents_to_be_collected_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    is_dpr = models.BooleanField(default=False)
    dpr_remarks = models.TextField(blank=True, null=True)
    is_gad = models.BooleanField(default=False)
    gad_remarks = models.TextField(blank=True, null=True)
    is_l_section = models.BooleanField(default=False)
    l_section_remarks = models.TextField(blank=True, null=True)
    soil_test_report = models.BooleanField(default=False)
    l_section_remarks = models.TextField(blank=True, null=True)
    is_data_from_irrigation_department = models.BooleanField(default=False)
    data_from_irrigation_department_remarks = models.TextField(blank=True, null=True)


class SurveyItem(BaseAbstractStructure):
    """
    Survey Item Model
    """
    CATEGORY_CHOICES = [
        ("Stone Quarry", "Stone Quarry"),
        ("Coarse Sand and Quarry", "Coarse Sand and Quarry"),
        ("Fine Sand and Quarry","Fine Sand and Quarry"),
        ("Moorum Quarry","Moorum Quarry"),
        ("Soil Source","Soil Source"),
        ("GSB Material","GSB Material"),
        ("Coarse Sand","Coarse Sand"),
        ("Fine Sand","Fine Sand"),
        ("Soil","Soil"),
    ]
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='survey_item_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    item_type  = models.CharField(choices=CATEGORY_CHOICES, default="NONE", max_length=200,blank=True,null=True)
    gps_coordinates = models.DecimalField(max_digits=30,decimal_places=20,blank=True, null=True)
    location= models.CharField(max_length=200,blank=True, null=True)
    lead_from_site_km = models.DecimalField(max_digits=30,decimal_places=20,blank=True, null=True)
    any_other_details = models.TextField(blank=True, null=True)
  
    def __str__(self):
        return self.survey_group


class SurveyOtherDetails(BaseAbstractStructure):
    """
        Survey Others Details Model
    """
    CATEGORY_CHOICES = [
        ("Yes", "Yes"),
        ("No", "No"),
    ]
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='other_details_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    above_rates_applicable_for_all_sites  = models.CharField(choices=CATEGORY_CHOICES, default="NONE", \
        max_length=200,blank=True,null=True)
    above_rates_for_following_location= models.CharField(max_length=300,blank=True, null=True)
    offer_slips_received_from_supplier_enclosed=models.CharField(choices=CATEGORY_CHOICES, default="NONE", \
        max_length=200,blank=True,null=True)
    calculation_sheet_for_above_rates_enclosed=models.CharField(max_length=300,blank=True, null=True)
    is_the_availability_for_all_materials_adequate=models.CharField(choices=CATEGORY_CHOICES, default="NONE", \
        max_length=200,blank=True,null=True)
    remarks_for_above_if_any = models.TextField(blank=True, null=True)
    is_the_quality_acceptable_by_the_client = models.\
        CharField(choices=CATEGORY_CHOICES, default="NONE", \
        max_length=200,blank=True,null=True)
    
    
    def __str__(self):
        return self.survey_group


class SurveyOtherDetailsSupplier(BaseAbstractStructure):
    """
    Survey Others Detials Supplier Details Model
    """
    CATEGORY_CHOICES = [
        ("Stone supplier", "Stone supplier"),
        ("Sand Supplier", "Sand Supplier"),
        ("Moorum supplier", "Moorum supplier"),
    ]
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='supplier_other_details_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    other_details= models.ForeignKey(SurveyOtherDetails, related_name='other_details_supplier', on_delete=models.CASCADE, blank=True, null=True)
    suppliers_type= models.CharField(choices=CATEGORY_CHOICES, default="NONE", \
        max_length=200,blank=True,null=True)
    contact_person=models.CharField(max_length=200,blank=True,null=True)
    contact_number=models.CharField(max_length=200,blank=True,null=True)
    email_id=models.EmailField(blank=True,null=True)

    def __str__(self):
        return self.survey_group


class LocalDataToBeCollected(BaseAbstractStructure):
    """ Loacal Data To Be Collected Model  """

    
    SUPPORTIVE_CHOICES = [
        ("Unsupportive", "Unsupportive"),
        ("Indifferent", "Indifferent"),
        ("Supportive", "Supportive"),
    ]
    CATEGORY_CHOISE = [
        ("Yes", "No"),
        ("Yes", "No")
    ]
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='localdata_collected_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    is_meet_the_local_panchayat = models.BooleanField(default=False)
    meet_the_village_pradhan_for_issues = models.CharField(max_length=50, choices=CATEGORY_CHOISE, default="No", blank=True, null=True)
    talk_to_contractors = models.CharField(max_length=50, choices=CATEGORY_CHOISE, default="No", blank=True, null=True)
    how_supportive_are_the_client_engineers_responsible_at_the_site = models.CharField(max_length=150, choices=SUPPORTIVE_CHOICES, blank=True, null=True)
    how_supportive_are_the_local_people = models.CharField(max_length=150, choices=SUPPORTIVE_CHOICES, blank=True, null=True)
    expected_local_and_client_expenses = models.TextField(blank=True, null=True)
    is_taken_photographs_of_how_local_contractors_are_working = models.BooleanField(default=False)


class LocalDataToBeCollectedEngineerDetails(BaseAbstractStructure):
    """ Local Data To be collected Engineer 
        Contact Details Model  
    """
    localdata_collected = models.ForeignKey(LocalDataToBeCollected, related_name='localdata_engineer_details', on_delete=models.CASCADE, null=True, blank=True)
    company = models.CharField(max_length=200, blank=True, null=True)
    name = models.CharField(max_length=200, blank=True, null=True)
    contact = models.CharField(max_length=200, blank=True, null=True)


class CompetitionAnalysis(BaseAbstractStructure):
    """
        Competition Analysis Model 
    """
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='competition_analysis_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    names_of_other_companies_who_have_surveyed_yet_the_site = models.TextField(blank=True, null=True)
    companies_working_nearby = models.TextField(blank=True, null=True)
    companies_who_we_can_expect_to_participate_for_this_work = models.TextField(blank=True, null=True)
    rates_at_which_last_few_works_were_awarded_and_to_whom = models.TextField(blank=True, null=True)


class ContactInformation(BaseAbstractStructure):
    """ Contact Information Model """
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='contact_information_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    designation = models.CharField(max_length=200, blank=True, null=True)
    name = models.CharField(max_length=200, blank=True, null=True)
    contact_number = models.CharField(max_length=30, blank=True, null=True)


class SurveyGpsCoordinates(BaseAbstractStructure):
    """
    Survey GPS Co-ordinates Model
    """
    survey_group = models.ForeignKey(SurveyDetailsGroup, related_name='gps_coordinates_survey_group', on_delete=models.CASCADE, null=True, blank=True )
    start_of_bridge=models.CharField(max_length=200,blank=True,null=True)
    centre_of_bridge=models.CharField(max_length=200,blank=True,null=True)
    end_of_bridge=models.CharField(max_length=200,blank=True,null=True)
    beginning_of_approach_road_at_start_of_bridge_side=models.CharField(max_length=200,blank=True,null=True)
    beginning_of_approach_road_at_end_of_bridge_side=models.CharField(max_length=200,blank=True,null=True)
    any_other_location=models.CharField(max_length=200,blank=True,null=True)


