
# from django.shortcuts import render,get_object_or_404
from django.db import transaction
# from rest_framework import status
# from rest_framework.generics import *
from rest_framework.views import APIView
# from rest_framework.response import Response
from rest_framework.exceptions import APIException
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny

# from .models import *
# from .serializers import *
# Create your views here.

from django.core.paginator import Paginator
# Create your views here.
#from administrations.models import *

from knox.auth import TokenAuthentication

import pandas as pd



class TenderSurveyDetailsAPI(APIView):
    """ Tender Survey Details API View  """

    
    

    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)

            with transaction.atomic():
                pass

                


        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})



class SurveyExcelImportAPI(APIView):
    """ Survey Excel import """

    df = pd.read_excel(r'Path of Excel file\File name.xlsx', sheet_name='your Excel sheet name')
    
    print(df)







