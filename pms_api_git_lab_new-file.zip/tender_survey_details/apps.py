from django.apps import AppConfig


class TenderSurveyDetailsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tender_survey_details'
