from rest_framework import serializers
from .models import *
from administrations.models import *




class TenderSurveySerializer(serializers.ModelSerializer):
    
    class Meta:
        model = SurveyDetailsGroup
        fields = "__all__"
