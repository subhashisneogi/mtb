from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline

from .models import *

# Register your models here.

admin.site.register(SurveyDetailsGroup,ModelAdmin)
admin.site.register(SurveyBasicDetails,ModelAdmin)
admin.site.register(SurveyLocationDetails,ModelAdmin)
admin.site.register(SurveyNatureOfWork,ModelAdmin)
admin.site.register(SurveyBridgeWork,ModelAdmin)
admin.site.register(SurveyApproachRoadWork,ModelAdmin)
admin.site.register(SurveyMaterialRates,ModelAdmin)
admin.site.register(DocumentsToBeCollected,ModelAdmin)
admin.site.register(SurveyItem,ModelAdmin)
admin.site.register(SurveyOtherDetails,ModelAdmin)
admin.site.register(SurveyOtherDetailsSupplier,ModelAdmin)
admin.site.register(LocalDataToBeCollected,ModelAdmin)
admin.site.register(LocalDataToBeCollectedEngineerDetails,ModelAdmin)
admin.site.register(CompetitionAnalysis,ModelAdmin)
admin.site.register(ContactInformation,ModelAdmin)
admin.site.register(SurveyGpsCoordinates,ModelAdmin)
