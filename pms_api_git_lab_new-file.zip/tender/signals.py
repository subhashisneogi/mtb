from django.db.models.signals import post_save, pre_delete, pre_save
from django.db import transaction
from django.dispatch import receiver
from django.db.models import Window
from django.db.models.functions import DenseRank, Rank
from django.db.models import F
from .models import *
from django.db.models import Case, When, Value, IntegerField, F, Window
from rest_framework.exceptions import APIException

@receiver(pre_save, sender=TenderMasterNewSurveyMaster)
def survey_creation_validate(sender, instance, **kwargs):
    if not instance.tender_id:
        return
    qs = TenderMasterNewSurveyMaster.cmobjects.filter(
        organization_id=instance.organization_id,
        tender_id=instance.tender.id
    ).exclude(status__in=['approved', 'rejected'])
    if instance.pk:
        qs = qs.exclude(pk=instance.pk)
    if qs.exists():
        raise APIException({
            'request_status': 0,
            'msg': "Tender survey should not be created, previous checklist must be Approved or Rejected"
        })


@receiver(post_save, sender=TenderMasterNewWinLossAnalysis)
def signal_update_tender_participant_rank(sender, instance, **kwargs):
    with transaction.atomic():
        TenderMasterNewWinLossAnalysis.cmobjects.filter(tender_id=instance.tender.id, bidded_value_in_crore__lte=0).update(rank=None)
        item_list = TenderMasterNewWinLossAnalysis.cmobjects.filter(tender_id=instance.tender.id,
                bidded_value_in_crore__gt=0).annotate(
            rank_value=Window(
                expression=DenseRank(),
                partition_by=[F('tender_id')],
                order_by=F('bidded_value_in_crore').asc()
            ),
        ).values('id', 'rank_value')
        for item in item_list:
            TenderMasterNewWinLossAnalysis.cmobjects.filter(pk=item['id']).update(rank=item['rank_value'])


@receiver(pre_save, sender=TenderMasterNew)
def store_old_values(sender, instance, **kwargs):
    if instance.pk:  
        try:
            old_instance = TenderMasterNew.cmobjects.get(pk=instance.pk)
            instance._old_emd_amount = old_instance.emd_amount
            instance._old_emd_type = old_instance.emd_type
            instance._old_emd_deposition_location = old_instance.emd_deposition_location
            instance._old_emd_overall_remarks = old_instance.emd_overall_remarks
            instance._old_emd_validity_date = old_instance.emd_validity_date
            instance._old_is_emd_applicable = old_instance.is_emd_applicable
        except TenderMasterNew.DoesNotExist:
            instance._old_emd_amount = None
            instance._old_emd_type = None
            instance._old_emd_deposition_location = None
            instance._old_emd_overall_remarks = None
            instance._old_emd_validity_date = None
            instance._old_is_emd_applicable = None

@receiver(post_save, sender=TenderMasterNew)
def check_emd_updates(sender, instance, created, **kwargs):
    from email_config.utils import trigger_emd_update_email
    if not created:
        all_changed = (
            instance.emd_amount != getattr(instance, "_old_emd_amount", None)
            or instance.emd_type != getattr(instance, "_old_emd_type", None)
            or instance.emd_deposition_location != getattr(instance, "_old_emd_deposition_location", None)
            or instance.emd_overall_remarks != getattr(instance, "_old_emd_overall_remarks", None)
            or instance.emd_validity_date != getattr(instance, "_old_emd_validity_date", None)
            or instance.is_emd_applicable != getattr(instance, "_old_is_emd_applicable", None)
        )
        has_required_values = (
            instance.emd_type is not None
            and instance.emd_amount is not None
            and instance.emd_overall_remarks is not None
            and instance.emd_deposition_location is not None
        )
        if all_changed and has_required_values:
            trigger_emd_update_email(instance.id, instance.tender_id)



@receiver(post_save, sender=TenderTrendAnalysisParticipants)
def signal_update_tender_trend_analysis_participant_rank(sender, instance, **kwargs):
    with transaction.atomic():
        project_cost = instance.trend_analysis.tender_value_gst_in_crore or 0
        bidder_value = instance.bidded_value_in_crore or 0
        diff = bidder_value - project_cost
        percentage = 0
        above_below = None
        if project_cost:
            percentage = round((abs(diff) / project_cost) * 100, 2)
        else:
            percentage = 0
        if percentage and percentage > 200:
            percentage = 200  
        # --- Above / Below Logic ---
        if bidder_value == 0:
            above_below = "NA"
            percentage = None
        elif diff > 0:
            above_below = "Above"
        elif diff < 0:
            above_below = "Below"
        else:
            above_below = "Equal"
        TenderTrendAnalysisParticipants.objects.filter(pk=instance.pk).update(
            percentage=percentage,
            above_below=above_below
        )
        # --- Ranking Logic ---
        TenderTrendAnalysisParticipants.cmobjects.filter(
            trend_analysis_id=instance.trend_analysis.id,
            bidded_value_in_crore__lte=0
        ).update(rank=None)
        item_list = TenderTrendAnalysisParticipants.cmobjects.filter(
            trend_analysis_id=instance.trend_analysis.id,
            bidded_value_in_crore__gt=0
        ).annotate(
            rank_value=Window(
                expression=DenseRank(),
                partition_by=[F('trend_analysis_id')],
                order_by=F('bidded_value_in_crore').asc()
            ),
        ).values('id', 'rank_value')
        for item in item_list:
            TenderTrendAnalysisParticipants.cmobjects.filter(
                pk=item['id']
            ).update(rank=item['rank_value'])

