import colorama
from rest_framework import serializers
from django.db.models import F, Sum
from datetime import date
from administrations.utils import get_dependent_values_details
from .helper import get_tender_data_from_tender_master
from .models import *
from datetime import timedelta
from colorama import Fore, Back, Style
from procurement.helper import get_details_from_instance, process_attachments, overlay_text_on_image_file,get_location_name
from administrations.serializers import CompanySerializer, JVMASTERSerializer 
from django.db import transaction
from .helper import *

class CommonFilterListSerializer(serializers.ListSerializer):
    """
    ListSerializer that filters out deleted objects
    """
    def to_representation(self, data):
        if hasattr(data, "filter"):
            data = data.filter(is_deleted=False)
        else:
            data = [item for item in data if not getattr(item, "is_deleted", False)]
        return super().to_representation(data)
class TenderNotificationsSerializer(serializers.ModelSerializer):
    """ TenderNotifications Model Serializer"""
    to = serializers.SerializerMethodField()
    cc = serializers.SerializerMethodField()
    sms_to = serializers.SerializerMethodField()

    def get_to(self,instance):
        if instance.notification_type == 'EMAIL':
            email_lists = list(instance.to.values_list('id', flat=True))
            return email_lists
        else:
            return []
        
    def get_cc(self,instance):
        if instance.notification_type == 'EMAIL':
            email_lists = list(instance.cc.values_list('id', flat=True))
            return email_lists
        else:
            return []
        
    def get_sms_to(self,instance):
        from user_profile.models import UserProfile
        if instance.notification_type == 'SMS':
            user_ids = list(instance.sms_to.values_list('id', flat=True))
            phone_no_list = list(UserProfile.objects.filter(user_id__in=user_ids).values_list('user_id', flat=True))
            return phone_no_list
        else:
            return []

    class Meta:
        model = TenderNotifications
        fields = '__all__'


class TenderEventsSerializer(serializers.ModelSerializer):
    """ TenderEvents Model Serializer"""
    assignees = serializers.SerializerMethodField()
    level_users = serializers.SerializerMethodField()
    notify_assignee = serializers.SerializerMethodField()
    remind_assignee = serializers.SerializerMethodField()

    def get_assignees(self,instance):
        email_lists = list(instance.assignees.values_list('id', flat=True))
        return email_lists
    
    def get_level_users(self,instance):
        users_list = TenderEventsLevel.cmobjects.filter(tender_events_id=instance.id).values()
        return users_list
    
    def get_notify_assignee(self,instance):
        if instance.notify_assignee == True:
            n_assignee = "True"
        else:
            n_assignee = "False"
        return n_assignee
    
    def get_remind_assignee(self,instance):
        if instance.remind_assignee == True:
            r_assignee = "True"
        else:
            r_assignee = "False"
        return r_assignee

    class Meta:
        model = TenderEvents
        fields = '__all__'

class TenderBidderSerializer(serializers.ModelSerializer):
    """  Tender Bidder model Serializer """

    class Meta:
        model = TenderBidder
        fields = '__all__'

def represents_int(s):
    try: 
        int(s)
    except ValueError:
        return False
    else:
        return True

class TenderMasterSerializer(serializers.ModelSerializer):
    """  Tender Master model Serializer """

    tender_data = serializers.SerializerMethodField()
    form_editable = serializers.SerializerMethodField()
    tender_status = serializers.SerializerMethodField()
    tender_age = serializers.SerializerMethodField()
    resend_user_name = serializers.SerializerMethodField()
    status_map = serializers.SerializerMethodField()
    survey_assigned_members = serializers.SerializerMethodField()
    survey_status = serializers.SerializerMethodField()
    elapsed_days = serializers.SerializerMethodField()
    is_survey_complete_button_show = serializers.SerializerMethodField()

    chainages = serializers.SerializerMethodField()


    def get_is_survey_complete_button_show(self,instance):
        from user_permissions.models import UserWiseModulePermissions

        user_id = self.context.get("user_id", None)

        user_ids = list(UserWiseModulePermissions.cmobjects.filter(level_permission=True, \
                                                                    module_item__unique_id__in=['pre-tender-approver', \
                                                                        'pre-tender-recommender']).values_list('user_id', flat=True))

        if instance.is_survey_complete == True:
            return False
        elif user_id in user_ids and instance.is_physical_survey_complete == True and \
            instance.is_material_survey_complete == True and instance.is_taxation_survey_complete == True and \
                instance.is_liason_survey_complete == True:
            return True
        else:
            return False
        

    def get_survey_assigned_members(self,instance):
        tender_data_form = TenderData.cmobjects.filter(form__form_internal_name='select_members',\
                                                       tender_id=instance.id).first()
        
        material_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_material',\
                                                       tender_id=instance.id).first()
        
        taxation_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_taxation',\
                                                       tender_id=instance.id).first()
        
        liason_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_liason',\
                                                       tender_id=instance.id).first()
        

        if tender_data_form:
            import ast
            form_ids = ast.literal_eval(tender_data_form.value)
            dependent_form = list(FormDependentChoices.cmobjects.filter(option_id__in=form_ids, \
                                                                        form__form_internal_name='select_members').values_list('name', flat=True))
            members = ','.join(dependent_form) 
        else:
            members = ""

        if material_rate_data:
            import ast
            material_form_ids = ast.literal_eval(material_rate_data.value)
            material_dependent_form = list(FormDependentChoices.cmobjects.filter(option_id__in=material_form_ids, \
                                                                        form__form_internal_name='select_members_material').values_list('name', flat=True))
            material_members = ','.join(material_dependent_form) 
        else:
            material_members = ""

        if taxation_rate_data:
            import ast
            taxation_form_ids = ast.literal_eval(taxation_rate_data.value)
            taxation_dependent_form = list(FormDependentChoices.cmobjects.filter(option_id__in=taxation_form_ids, \
                                                                        form__form_internal_name='select_members_taxation').values_list('name', flat=True))
            taxation_members = ','.join(taxation_dependent_form) 
        else:
            taxation_members = ""

        if liason_rate_data:
            import ast
            liason_form_ids = ast.literal_eval(liason_rate_data.value)
            liason_dependent_form = list(FormDependentChoices.cmobjects.filter(option_id__in=liason_form_ids, \
                                                                        form__form_internal_name='select_members_liason').values_list('name', flat=True))
            liason_members = ','.join(liason_dependent_form) 
        else:
            liason_members = ""

        result = [
            {
                'physical_feasibility_members' : members,
                'material_members' : material_members,
                'taxation_members' : taxation_members,
                'liason_members' : liason_members
            }
        ]

        return result
    
    def get_survey_status(self,instance):
        survey_status = ""
        if instance.is_survey_complete == True:
            survey_status = "completed"
        elif instance.is_survey_started == True and instance.is_survey_complete == False:
            survey_status = "in_progress"
        elif instance.is_survey_active == True and instance.is_survey_started == False and instance.is_survey_complete == False:
            survey_status = "due"
        return survey_status


    def get_resend_user_name(self,instance):
        if instance.resend_user_id:
            user_details = PmsUser.objects.filter(id=instance.resend_user_id).first()

            name = str(user_details.first_name) + " " + str(user_details.last_name) if user_details else ""
            return name
        else:
            return ""


    def get_tender_age(self,instance):
        date1 = instance.created_at.date()
        date = datetime.now().date()

        no_of_days = int((date-date1).days) + 1 
        return str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
    

    def get_elapsed_days(self,instance):
        current_date = datetime.now().date()

        dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='agreement_signed', \
                                                               option='Yes').values_list('id', flat=True))
        
        agreement_signed = TenderData.cmobjects.filter(form__form_internal_name='agreement_signed', \
                                                      value__in=dropdown_ids, \
                                                        tender_id=instance.id).first()
        
        tender_due_details = TenderData.cmobjects.filter(tender_id=instance.id, \
                                                         form__form_internal_name="tender_due_date").first()
        
        tender_due_date = tender_due_details.value if tender_due_details else None

        tender_target_final_submission_date = datetime.strptime(tender_due_date, "%Y-%m-%d").date() if tender_due_date else None


        if agreement_signed and instance.is_l1_complete:
            target_date = current_date
        elif instance.is_l1 == True:
            target_date = current_date
        elif instance.is_not_l1 == True:
            target_date = current_date
        elif instance.is_submission_complete == True:
            target_date = current_date
        elif instance.is_reject == True:
            target_date = tender_target_final_submission_date
        elif instance.is_approved == True:
            target_date = tender_target_final_submission_date
        elif instance.is_sent_for_final_approval == True:
            target_date = instance.created_at.date() + timedelta(days=15)
        elif instance.is_survey_complete == True:
            target_date = instance.created_at.date() + timedelta(days=14)
        elif instance.is_survey_started == True:
            target_date = instance.created_at.date() + timedelta(days=13)
        elif instance.is_assignment_complete == True:
            target_date = instance.created_at.date() + timedelta(days=8)
        elif instance.is_vga_reject == True:
            target_date = instance.created_at.date() + timedelta(days=6)
        elif instance.is_vga_approved == True:
            target_date = instance.created_at.date() + timedelta(days=6)
        elif instance.is_sent_for_approval == True:
            target_date = instance.created_at.date() + timedelta(days=3)
        elif instance.is_recommended == True:
            target_date = instance.created_at.date() + timedelta(days=3)
        elif instance.is_sent_for_recommendation == True:
            target_date = instance.created_at.date() + timedelta(days=2)
        else:
            target_date = instance.created_at.date() + timedelta(days=1)


        no_of_days = int((target_date-current_date).days) if target_date else 0

        if no_of_days < 0:
            elapsed_days = abs(no_of_days)
        else: 
            elapsed_days = 0

        return str(elapsed_days) + " Days" if int(elapsed_days) > 1 else str(elapsed_days) + " Day"


    def get_tender_status(self,instance):
        dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='agreement_signed', \
                                                               option='Yes').values_list('id', flat=True))
        
        agreement_signed = TenderData.cmobjects.filter(form__form_internal_name='agreement_signed', \
                                                      value__in=dropdown_ids, \
                                                        tender_id=instance.id).first()
        not_dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='agreement_signed', \
                                                               option='No').values_list('id', flat=True))
        
        not_agreement_signed = TenderData.cmobjects.filter(form__form_internal_name='agreement_signed', \
                                                      value__in=not_dropdown_ids, \
                                                        tender_id=instance.id).first()
        if instance.is_l1_complete == True:
            status = 'Agreement Signed'
        elif instance.is_not_l1_complete == True:
            status = 'Agreement Not Signed'
        elif instance.is_l1 == True:
            status = 'Selected As L1'
        elif instance.is_not_l1 == True:
            status = 'Not Selected As L1'
        elif instance.is_submission_complete == True:
            status = 'Tender Submitted'
        elif instance.is_reject == True:
            status = 'Rejected'
        elif instance.is_approved == True:
            status = 'Approved'
        elif instance.is_sent_for_final_approval == True:
            status = 'Tender is Send For Approval'
        elif instance.is_survey_complete == True:
            status = 'Survey Completed'
        elif instance.is_survey_started == True:
            status = 'Survey Started and In Progress'
        elif instance.is_assignment_complete == True:
            status = 'Members Assigned For Survey'
        elif instance.is_vga_reject == True:
            status = 'VGA Rejected'
        elif instance.is_vga_approved == True:
            status = 'VGA Done'
        elif instance.is_sent_for_approval == True:
            status = 'Recommended and Waiting For Approval'
        elif instance.is_recommended == True:
            status = 'Recommended By Recommender/Tender Head'
        elif instance.is_sent_for_recommendation == True:
            status = 'Proposed and Sent For Recommendation'
        elif instance.is_eligibility_complete_for_proposer == True:
            status = 'Proposed and Not Sent For Recommendation'
        else:
            status = 'Identified'
        return status
    

    def get_status_map(self,instance):
        result = []
        identified_dict = {}
        identified_dict['status'] = 'Identified'
        identified_dict['status_check'] = True
        identified_dict['date'] = instance.created_at.date()
        identified_dict['target_date'] = instance.created_at.date()
        identified_dict['is_elapsed'] = False
        identified_dict['elapsed_days'] = "0 Day"
        result.append(identified_dict)

        proposal_dict = {}
        proposal_dict['status'] = 'Proposed and Sent For Recommendation'
        if instance.is_sent_for_recommendation == True:
            proposal_dict['status_check'] = True
            proposal_dict['date'] = instance.tender_proposal_date
            proposal_dict['target_date'] = instance.created_at.date() + timedelta(days=1)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((proposal_dict['target_date']-proposal_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            proposal_dict['is_elapsed'] = True if elapsed_days < 0 else False
            proposal_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        else:
            proposal_dict['status_check'] = False
            proposal_dict['date'] = ""
            proposal_dict['target_date'] = instance.created_at.date() + timedelta(days=1)
            proposal_dict['is_elapsed'] = False
            proposal_dict['elapsed_days'] = "0 Day"
        result.append(proposal_dict)

        recommendation_dict = {}
        recommendation_dict['status'] = 'Recommended By Recommender/Tender Head'
        if instance.is_recommended == True:
            recommendation_dict['status_check'] = True
            recommendation_dict['date'] = instance.tender_recommendation_date
            recommendation_dict['target_date'] = instance.created_at.date() + timedelta(days=2)
            
            # Elapsed Days Calculation Based On Status
            elapsed_days = int((recommendation_dict['target_date']-recommendation_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            recommendation_dict['is_elapsed'] = True if elapsed_days < 0 else False
            recommendation_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        else:
            recommendation_dict['status_check'] = False
            recommendation_dict['date'] = ""
            recommendation_dict['target_date'] = instance.created_at.date() + timedelta(days=2)
            recommendation_dict['is_elapsed'] = False
            recommendation_dict['elapsed_days'] = "0 Day"
        result.append(recommendation_dict)


        wf_approval_dict = {}
        wf_approval_dict['status'] = 'Recommended and Waiting For Approval'
        if instance.is_sent_for_approval == True:
            wf_approval_dict['status_check'] = True
            wf_approval_dict['date'] = instance.tender_sent_for_vga_approval_date
            wf_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=3)
            
            # Elapsed Days Calculation Based On Status
            elapsed_days = int((wf_approval_dict['target_date']-wf_approval_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            wf_approval_dict['is_elapsed'] = True if elapsed_days < 0 else False
            wf_approval_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        else:
            wf_approval_dict['status_check'] = False
            wf_approval_dict['date'] = ""
            wf_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=3)
            wf_approval_dict['is_elapsed'] = False
            wf_approval_dict['elapsed_days'] = "0 Day"
        result.append(wf_approval_dict)

        

        if instance.is_vga_approved == True:
            vga_approval_dict = {}
            vga_approval_dict['status'] = 'VGA Done'
            vga_approval_dict['status_check'] = True
            vga_approval_dict['date'] = instance.tender_vga_approval_date
            vga_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=3)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((vga_approval_dict['target_date']-vga_approval_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            vga_approval_dict['is_elapsed'] = True if elapsed_days < 0 else False
            vga_approval_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        elif instance.is_vga_reject == True:
            vga_approval_dict = {}
            vga_approval_dict['status'] = 'VGA Rejected'
            vga_approval_dict['status_check'] = True
            vga_approval_dict['date'] = instance.tender_vga_rejected_date
            vga_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=3)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((vga_approval_dict['target_date']-vga_approval_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            vga_approval_dict['is_elapsed'] = True if elapsed_days < 0 else False
            vga_approval_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        else:
            vga_approval_dict = {}
            vga_approval_dict['status'] = 'VGA Done / VGA Rejected'
            vga_approval_dict['status_check'] = False
            vga_approval_dict['date'] = ""
            vga_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=3)
            vga_approval_dict['is_elapsed'] = False
            vga_approval_dict['elapsed_days'] = "0 Day"
        
        result.append(vga_approval_dict)

        survey_members_approval_dict = {}
        survey_members_approval_dict['status'] = 'Members Assigned For Survey'
        if instance.is_assignment_complete == True:
            survey_members_approval_dict['status_check'] = True
            survey_members_approval_dict['date'] = instance.survey_members_assigned_date
            survey_members_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=6)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((survey_members_approval_dict['target_date']-survey_members_approval_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            survey_members_approval_dict['is_elapsed'] = True if elapsed_days < 0 else False
            survey_members_approval_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        else:
            survey_members_approval_dict['status_check'] = False
            survey_members_approval_dict['date'] = ""
            survey_members_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=6)
            survey_members_approval_dict['is_elapsed'] = False
            survey_members_approval_dict['elapsed_days'] = "0 Day"

        result.append(survey_members_approval_dict)

        survey_started_dict = {}
        survey_started_dict['status'] = 'Survey Started and In Progress'
        if instance.is_survey_started == True:
            survey_started_dict['status_check'] = True
            survey_started_dict['date'] = instance.survey_started_date
            survey_started_dict['target_date'] = instance.created_at.date() + timedelta(days=8)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((survey_started_dict['target_date']-survey_started_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            survey_started_dict['is_elapsed'] = True if elapsed_days < 0 else False
            survey_started_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        else:
            survey_started_dict['status_check'] = False
            survey_started_dict['date'] = ""
            survey_started_dict['target_date'] = instance.created_at.date() + timedelta(days=8)
            survey_started_dict['is_elapsed'] = False
            survey_started_dict['elapsed_days'] = "0 Day"

        result.append(survey_started_dict)


        survey_completed_dict = {}
        survey_completed_dict['status'] = 'Survey Completed'
        if instance.is_survey_complete == True:
            survey_completed_dict['status_check'] = True
            survey_completed_dict['date'] = instance.survey_completed_date
            survey_completed_dict['target_date'] = instance.created_at.date() + timedelta(days=13)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((survey_completed_dict['target_date']-survey_completed_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            survey_completed_dict['is_elapsed'] = True if elapsed_days < 0 else False
            survey_completed_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        else:
            survey_completed_dict['status_check'] = False
            survey_completed_dict['date'] = ""
            survey_completed_dict['target_date'] = instance.created_at.date() + timedelta(days=13)
            survey_completed_dict['is_elapsed'] = False
            survey_completed_dict['elapsed_days'] = "0 Day"

        result.append(survey_completed_dict)

        final_approval_dict = {}
        final_approval_dict['status'] = 'Send For Final Approval'
        if instance.is_sent_for_final_approval == True:
            final_approval_dict['status_check'] = True
            final_approval_dict['date'] = instance.tender_final_approval_send_date
            final_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=14)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((final_approval_dict['target_date']-final_approval_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            final_approval_dict['is_elapsed'] = True if elapsed_days < 0 else False
            final_approval_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
        else:
            final_approval_dict['status_check'] = False
            final_approval_dict['date'] = ""
            final_approval_dict['target_date'] = instance.created_at.date() + timedelta(days=14)
            final_approval_dict['is_elapsed'] = False
            final_approval_dict['elapsed_days'] = "0 Day"

        result.append(final_approval_dict)


        if instance.is_approved == True:
            approval_dict = {}
            approval_dict['status'] = 'Approved'
            approval_dict['status_check'] = True
            approval_dict['date'] = instance.tender_approval_date
            approval_dict['target_date'] = instance.created_at.date() + timedelta(days=15)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((approval_dict['target_date']-approval_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            approval_dict['is_elapsed'] = True if elapsed_days < 0 else False
            approval_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
            result.append(approval_dict)
        elif instance.is_reject == True:
            rejected_dict = {}
            rejected_dict['status'] = 'Rejected'
            rejected_dict['status_check'] = True
            rejected_dict['date'] = instance.tender_rejected_date
            rejected_dict['target_date'] = instance.created_at.date() + timedelta(days=15)

            # Elapsed Days Calculation Based On Status
            elapsed_days = int((rejected_dict['target_date']-rejected_dict['date']).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            rejected_dict['is_elapsed'] = True if elapsed_days < 0 else False
            rejected_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
            result.append(rejected_dict)
        else:
            approval_rejected_dict = {}
            approval_rejected_dict['status'] = 'Approved / Rejected'
            approval_rejected_dict['status_check'] = False
            approval_rejected_dict['date'] = ""
            approval_rejected_dict['target_date'] = instance.created_at.date() + timedelta(days=15)
            approval_rejected_dict['is_elapsed'] = False
            approval_rejected_dict['elapsed_days'] = "0 Day"
            result.append(approval_rejected_dict)


        submission_dict = {}
        data_details = TenderData.cmobjects.filter(tender_id=instance.id, form__form_internal_name="submission_date").first()
        tender_due_details = TenderData.cmobjects.filter(tender_id=instance.id, form__form_internal_name="tender_due_date").first()
        submission_dict['status'] = 'Submitted'
        if instance.is_submission_complete == True:
            submission_dict['status_check'] = True
            submission_dict['date'] = data_details.value if data_details else ""
            submission_dict['target_date'] = tender_due_details.value if tender_due_details else ""

            # Elapsed Days Calculation Based On Status
            submission_date = datetime.strptime(submission_dict['date'], "%Y-%m-%d").date()
            target_date = datetime.strptime(submission_dict['target_date'], "%Y-%m-%d").date()

            elapsed_days = int((target_date-submission_date).days)
            no_of_days = abs(elapsed_days) if elapsed_days < 0 else 0
            submission_dict['is_elapsed'] = True if elapsed_days < 0 else False
            submission_dict['elapsed_days'] = str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
            result.append(submission_dict)

        else:
            submission_dict['status_check'] = False
            submission_dict['date'] = ""
            submission_dict['target_date'] = tender_due_details.value if tender_due_details else ""
            submission_dict['is_elapsed'] = False
            submission_dict['elapsed_days'] = "0 Day"
        result.append(submission_dict)


        if instance.is_l1 == True:
            l1_dict = {}
            l1_dict['status'] = 'Selected As L1'
            l1_dict['status_check'] = True
            l1_dict['date'] = instance.l1_selection_date
            l1_dict['target_date'] = ""
            l1_dict['is_elapsed'] = False
            l1_dict['elapsed_days'] = "0 Day"
            result.append(l1_dict)
        elif instance.is_not_l1 == True:
            no_l1_dict = {}
            no_l1_dict['status'] = 'Not Selected As L1'
            no_l1_dict['status_check'] = True
            no_l1_dict['date'] = instance.l1_not_selection_date
            no_l1_dict['target_date'] = ""
            no_l1_dict['is_elapsed'] = False
            no_l1_dict['elapsed_days'] = "0 Day"
            result.append(no_l1_dict)
        else:
            l1_or_not_dict = {}
            l1_or_not_dict['status'] = 'Selection Status Pending'
            l1_or_not_dict['status_check'] = False
            l1_or_not_dict['date'] = ""
            l1_or_not_dict['target_date'] = ""
            l1_or_not_dict['is_elapsed'] = False
            l1_or_not_dict['elapsed_days'] = "0 Day"
            result.append(l1_or_not_dict)

        
        agreement_dict = {}

        dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='agreement_signed', \
                                                               option='Yes').values_list('id', flat=True))
        
        agreement_signed = TenderData.cmobjects.filter(form__form_internal_name='agreement_signed', \
                                                      value__in=dropdown_ids, \
                                                        tender_id=instance.id).first()
        if agreement_signed and instance.is_l1_complete == True:
            agreement_dict['status'] = 'Agreement Signed'
            agreement_dict['status_check'] = True
            agreement_dict['date'] = instance.agreement_signing_date
            agreement_dict['target_date'] = ""
            agreement_dict['is_elapsed'] = False
            agreement_dict['elapsed_days'] = "0 Day"
        elif instance.is_not_l1 == True and instance.is_not_l1_complete == True:
            agreement_dict['status'] = 'RCA Provided'
            agreement_dict['status_check'] = True
            agreement_dict['date'] = instance.agreement_signing_date
            agreement_dict['target_date'] = ""
            agreement_dict['is_elapsed'] = False
            agreement_dict['elapsed_days'] = "0 Day"
        else:
            agreement_dict['status'] = 'Agreement Status Pending'
            agreement_dict['status_check'] = False
            agreement_dict['date'] = ""
            agreement_dict['target_date'] = ""
            agreement_dict['is_elapsed'] = False
            agreement_dict['elapsed_days'] = "0 Day"

        result.append(agreement_dict)

        return result


    def get_form_editable(self,instance):
        form_menu_type = self.context.get("form_menu_type", None)
        dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='agreement_signed', \
                                                               option='Yes').values_list('id', flat=True))
        
        agreement_signed = TenderData.cmobjects.filter(form__form_internal_name='agreement_signed', \
                                                      value__in=dropdown_ids, \
                                                        tender_id=instance.id).first()
        
        if agreement_signed and instance.is_l1_complete == True:
            form_editable = False
        elif instance.is_approved == True and form_menu_type in ["tender_pre_feasibility_assignments", "tender_top_sheet",\
                                                                        "tender_executive_summary", "tender_eligibility", "tender_compliances"]:
            form_editable = False
        elif instance.is_sent_for_approval == True and form_menu_type in ["tender_eligibility", "tender_compliances",\
                                                                        "tender_executive_summary"]:
            form_editable = False
        else:
            form_editable = True
        # form_editable = True  # TODO : make comment after testing
        return form_editable

    def get_tender_data(self,instance):
        form_menu_type = self.context.get("form_menu_type", None)
        form_group_id = self.context.get("form_group_id", None)
        list_type = self.context.get("list_type", None)
        user_id = self.context.get("user_id", None)
        organization_id=self.context.get("organization_id", None)

        user_details = PmsUser.objects.filter(id=user_id, is_active=True).first()

        master_list = list(FormMenuMaster.objects.filter(is_display=True, menu_id=3).values_list('form_type_name', flat=True))

        group_list_ids = list(FormGroupMastr.cmobjects.filter(form_type__in=master_list).values_list('id', flat=True))

        if list_type:
            if form_menu_type and form_group_id:

                form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id,organization_id=organization_id, \
                                                is_export=True).order_by('form_group_id','sort_orders')
            elif form_menu_type:

                group_ids = list(FormGroupMastr.cmobjects.filter(form_type=form_menu_type).values_list('id', flat=True))
                form_datas = FormMaster.cmobjects.filter(form_group_id__in=group_ids, organization_id=organization_id, \
                                                is_export=True).order_by('form_group_id','sort_orders')
            
            elif form_group_id:

                form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id,organization_id=organization_id, \
                                                is_export=True).order_by('form_group_id','sort_orders')

            else:

                form_datas = FormMaster.cmobjects.filter(organization_id=organization_id, \
                                                    is_export=True, form_group_id__in=group_list_ids).exclude(\
                                                        form_type='tender_survey_details').order_by('form_group_id','sort_orders')
        else:
            if form_menu_type and form_group_id:

                form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id,\
                                                         organization_id=organization_id).order_by('form_group_id','sort_orders')
            elif form_menu_type:

                group_ids = list(FormGroupMastr.cmobjects.filter(form_type=form_menu_type).values_list('id', flat=True))
                form_datas = FormMaster.cmobjects.filter(form_group_id__in=group_ids, \
                                                         organization_id=organization_id).order_by('form_group_id',\
                                                                                                                   'sort_orders')
            
            elif form_group_id:

                form_datas = FormMaster.cmobjects.filter(form_group_id=form_group_id,\
                                                         organization_id=organization_id).order_by('form_group_id',\
                                                                                                                   'sort_orders')

            else:

                form_datas = FormMaster.cmobjects.filter(organization_id=organization_id, form_group_id__in=group_list_ids).exclude(\
                                                        form_type='tender_survey_details').order_by('form_group_id','sort_orders')
                

        tender_datas = []
        for item in form_datas:
            if item.form_group.is_multiple == False:
                tender_data_details = TenderData.cmobjects.select_related('form').filter(form_id=item.id, \
                                                                                        tender_id=instance.id).first()
                tender_dict = dict()
                tender_dict['id'] = tender_data_details.id if tender_data_details else ""
                tender_dict['form_label'] = item.form_label
                tender_dict['inpute_type'] = tender_data_details.form.form_input_type if tender_data_details and tender_data_details.form else None # TODO: testing pending
                if tender_data_details:
                    if tender_data_details.value and represents_int(tender_data_details.value):
                        final_value = FormDropdownChoices.cmobjects.filter(id=int(tender_data_details.value)).first()
                        dependent_value = FormDependentChoices.cmobjects.filter(id=int(tender_data_details.value)).first()
                        if final_value and tender_data_details.form.form_input_type == 'dropdown':
                            tender_dict['value'] = final_value.option 
                            tender_dict['value_id'] = final_value.id 

                        elif final_value and tender_data_details.form.form_input_type == 'radio':
                            tender_dict['value'] = final_value.option 
                            tender_dict['value_id'] = final_value.id 

                        elif tender_data_details.form.form_input_type == 'condition' and \
                                tender_data_details.form.condition_input_type == 'dropdown':
                            tender_dict['value'] = int(tender_data_details.value) 
                            tender_dict['value_id'] = ""

                        # TODO: REMOVE AFTER TESTING
                        # elif dependent_value and \
                        #     tender_data_details.form.form_input_type == 'reference' and item.form_internal_name != 'employer':
                        #     tender_dict['value'] = dependent_value.name
                        #     tender_dict['value_id'] = dependent_value.option_id

                        elif tender_data_details.form.form_input_type == 'reference':
                            form_master = tender_data_details.form
                            fdc_obj = FormDependentChoices.cmobjects.filter(form=form_master).first()

                            organization_id = organization_id
                            obj = get_dependent_values_details(fdc_obj.query_name,
                                                         organization_id,
                                                         tender_data_details.value)

                            tender_dict['value'] = obj.get("display_name", "")
                            tender_dict['value_id'] = tender_data_details.value

                        else:
                            if represents_int(tender_data_details.value) and not tender_data_details.form.form_input_type == 'dependency':
                                tender_dict['value'] = format(int(tender_data_details.value), '.2f')
                            elif tender_data_details.value == 'true':
                                tender_dict['value'] = "Yes"
                            elif tender_data_details.value == 'false':
                                tender_dict['value'] = "No"
                            else:
                                tender_dict['value'] = tender_data_details.value
                            tender_dict['value_id'] = ""
                    else:
                        final_value = FormDropdownChoices.objects.filter(option=tender_data_details.value).first()
                        try:
                            if represents_int(tender_data_details.value) and not tender_data_details.form.form_input_type == 'dependency':
                                tender_dict['value'] = format(int(tender_data_details.value), '.2f')
                            elif tender_data_details.value == 'true':
                                tender_dict['value'] = "Yes"
                            elif tender_data_details.value == 'false':
                                tender_dict['value'] = "No"
                            else:
                                tender_dict['value'] = tender_data_details.value
                        except Exception as ex:
                            tender_dict['value'] = ""
                        if tender_data_details.form.form_input_type not in ['textarea','text','checkbox','date','number','phone','boolean','file','formulla','condition']:
                            tender_dict['value_id'] = final_value.id if final_value else ""
                        else:
                            tender_dict['value_id'] = ""
                else:
                    tender_dict['value'] = ""
                    tender_dict['value_id'] = ""

                tender_value = TenderData.cmobjects.filter(tender_id=instance.id, form__form_internal_name='tender_project_cost__eligibility').first()
                if item.form_internal_name == 'thresold':
                    tender_dict['value'] = tender_value.value if tender_value else ""
                    tender_dict['value_id'] = ""

                if item.form_internal_name == 'tender_value_compliance':
                    tender_dict['value'] = tender_value.value if tender_value else ""
                    tender_dict['value_id'] = ""

                if item.form_internal_name == 'defect_liability_period':
                    tender_dict['value'] = int(float(tender_data_details.value if tender_data_details.value else "0")) if tender_data_details else ''
                    tender_dict['value_id'] = ""

                if item.form_input_type == 'boolean':
                    if not tender_data_details:
                        tender_dict['value'] = "NA"
                        tender_dict['value_id'] = ""
                    elif tender_data_details.value == 'false':
                        tender_dict['value'] = "No"
                        tender_dict['value_id'] = ""
                    else:
                        tender_dict['value'] = "Yes"
                        tender_dict['value_id'] = ""

                if item.form_internal_name == 'schedule_durations':
                    tender_dict['value'] = int(float(tender_data_details.value if tender_data_details.value else '0')) if tender_data_details else ""
                    tender_dict['value_id'] = ""

                # TODO: REMOVE AFTER TESTING
                '''
                if item.form_internal_name == 'employer':
                    try:
                        employee_details = FormDependentChoices.objects.filter(id=int(float(tender_data_details.value))).first() if tender_value else None
                        tender_dict['value'] = employee_details.name if employee_details else "" 
                        tender_dict['value_id'] = int(float(tender_data_details.value)) if tender_data_details else ""
                    except Exception as ex:
                        tender_dict['value'] = tender_data_details.value if tender_data_details else ""
                        tender_dict['value_id'] = "" 
                '''

                '''        
                if item.form_internal_name == 'state_tender':

                    if tender_data_details:
                        print("tender_data_details", tender_data_details)
                        state_ids = list(FormDependentChoices.cmobjects.filter(id=int(tender_data_details.value)).values_list('option_id', flat=True))
                        state_name_list = []

                        for obj in state_ids:
                            state_details = State.objects.filter(state_id=int(obj)).first()
                            state_name_list.append(state_details.name)

                        state_string = ','.join(state_name_list)

                        tender_dict['value'] = state_string 
                        tender_dict['value_id'] = int(tender_data_details.value)
                    else:
                        tender_dict['value'] = "" 
                        tender_dict['value_id'] = ""
                '''

                tender_dict['document'] = tender_data_details.document.url if tender_data_details and tender_data_details.document else ""
                tender_dict['internal_name'] = item.form_internal_name
                tender_dict['form_group_id'] = item.form_group_id
                tender_dict['by_order'] = tender_data_details.by_order if tender_data_details else ""
                tender_dict['is_multiple'] = False
                tender_dict['form_id'] = item.id
                tender_datas.append(tender_dict)
            else:
                if item.form_group.name == 'JV Details':
                    by_order_ids = list(TenderData.cmobjects.select_related('form').filter(tender_id=instance.id,\
                                                                                           form__form_internal_name='jv_share__details').values_list('by_order', flat=True))
                    tender_data_details = TenderData.cmobjects.select_related('form').filter(form_id=item.id, \
                                                                                        tender_id=instance.id, by_order__in=by_order_ids).order_by('by_order')
                else:
                    tender_data_details = TenderData.cmobjects.select_related('form').filter(form_id=item.id, \
                                                                                        tender_id=instance.id).order_by('by_order')

                for obj in tender_data_details:
                    tender_dict = dict()
                    tender_dict['id'] = obj.id if obj else ""
                    tender_dict['form_label'] = item.form_label
                    tender_dict['inpute_type'] = obj.form.form_input_type if obj and obj.form else None # TODO: testing pending
                    if obj:
                        if obj.value and represents_int(obj.value):
                            final_value = FormDropdownChoices.cmobjects.filter(id=int(obj.value)).first()
                            dependent_value = FormDependentChoices.cmobjects.filter(id=int(obj.value)).first()
                            if final_value and obj.form.form_input_type == 'dropdown':
                                tender_dict['value'] = final_value.option 
                                tender_dict['value_id'] = final_value.id 
                            
                            elif final_value and obj.form.form_input_type == 'radio':
                                tender_dict['value'] = final_value.option 
                                tender_dict['value_id'] = final_value.id 

                            elif obj.form.form_input_type == 'condition' and \
                                    obj.form.condition_input_type == 'dropdown':
                                tender_dict['value'] = int(obj.value) 
                                tender_dict['value_id'] = ""

                            elif dependent_value and \
                                obj.form.form_input_type == 'reference' \
                                    and item.form_internal_name != 'employer' \
                                    and item.form_internal_name != 'uom':
                                tender_dict['value'] = dependent_value.name 
                                tender_dict['value_id'] = dependent_value.option_id

                            else:
                                if represents_int(obj.value) and not obj.form.form_input_type == 'dependency':
                                    # tender_dict['value'] = format(int(obj.value), '.2f')
                                    tender_dict['value'] = obj.value
                                elif obj.value == 'true':
                                    tender_dict['value'] = "Yes"
                                elif obj.value == 'false':
                                    tender_dict['value'] = "No"
                                else:
                                    tender_dict['value'] = obj.value
                                tender_dict['value_id'] = ""
                        else:
                            final_value = FormDropdownChoices.objects.filter(option=obj.value).first()
                            try:
                                if represents_int(obj.value) and not obj.form.form_input_type == 'dependency':
                                    tender_dict['value'] = format(int(obj.value), '.2f')
                                elif obj.value == 'true':
                                    tender_dict['value'] = "Yes"
                                elif obj.value == 'false':
                                    tender_dict['value'] = "No"
                                else:
                                    tender_dict['value'] = obj.value
                            except Exception as ex:
                                tender_dict['value'] = ""
                            tender_dict['value_id'] = final_value.id if final_value else ""
                    else:
                        tender_dict['value'] = ""
                        tender_dict['value_id'] = ""

                    tender_value = TenderData.cmobjects.filter(tender_id=instance.id, form__form_internal_name='tender_project_cost__eligibility').first()
                    if item.form_internal_name == 'thresold':
                        tender_dict['value'] = tender_value.value if tender_value else ""
                        tender_dict['value_id'] = ""

                    if item.form_internal_name == 'tender_value_compliance':
                        tender_dict['value'] = tender_value.value if tender_value else ""
                        tender_dict['value_id'] = ""

                    if item.form_internal_name == 'defect_liability_period':
                        tender_dict['value'] = int(float(obj.value)) if obj else ""
                        tender_dict['value_id'] = ""

                    if item.form_input_type == 'boolean':
                        if not obj:
                            tender_dict['value'] = "NA"
                            tender_dict['value_id'] = ""
                        elif obj.value == 'false':
                            tender_dict['value'] = "No"
                            tender_dict['value_id'] = ""
                        else:
                            tender_dict['value'] = "Yes"
                            tender_dict['value_id'] = ""

                    if item.form_internal_name == 'schedule_durations':
                        tender_dict['value'] = int(float(obj.value)) if obj else ""
                        tender_dict['value_id'] = ""

                    if item.form_internal_name == 'employer':
                        try:
                            employee_details = FormDependentChoices.objects.filter(id=int(float(obj.value))).first() if tender_value else None
                            tender_dict['value'] = employee_details.name if employee_details else "" 
                            tender_dict['value_id'] = int(float(obj.value)) 
                        except Exception as ex:
                            tender_dict['value'] = obj.value 
                            tender_dict['value_id'] = "" 

                    tender_dict['document'] = obj.document.url if obj and obj.document else ""
                    tender_dict['internal_name'] = item.form_internal_name
                    tender_dict['form_group_id'] = item.form_group_id
                    tender_dict['by_order'] = obj.by_order if obj else ""
                    tender_dict['is_multiple'] = True
                    tender_dict['form_id'] = item.id
                    tender_datas.append(tender_dict)
        return tender_datas

    def get_chainages(self, instance):
        _details = []
        if instance:
            _details = TenderChainage.cmobjects.filter(tender=instance).values('tender', 'start', 'end', 'chainage_value')
        return _details

    class Meta:
        model = TenderMaster
        fields = '__all__'



class TenderMasterSerializer2(serializers.ModelSerializer):
    """Serializer for TenderMaster model 2"""
    tender_name = serializers.SerializerMethodField()
    tender_code = serializers.SerializerMethodField()

    def get_tender_name(self, instance):
        data = get_tender_data_from_tender_master(instance.pk, 'proposed_tender')
        # print('data', colorama.Back.GREEN, data, colorama.Style.RESET_ALL)
        tender_name = data['proposed_tender'] if 'proposed_tender' in data else None
        return tender_name
    
    def get_tender_code(self, instance):
        data = get_tender_data_from_tender_master(instance.pk, 'tender_id')
        # print('data', colorama.Back.GREEN, data, colorama.Style.RESET_ALL)
        tender_code = data['tender_id'] if 'tender_id' in data else None
        return tender_code

    class Meta:
        model = TenderMaster
        fields = ('id', 'organization', 'tender_name', 'tender_code')


class TenderSurveySerializer(serializers.ModelSerializer):
    """
    Tender Survey Serializer
    """
    survey_objects = serializers.SerializerMethodField()


    def get_survey_objects(self,instance):
        tender_id = instance.id

        result_list = []

        form_group_list = FormGroupMastr.objects.filter(form_type='tender_survey_details').order_by('sort_orders')

        for item in form_group_list:
            tender_data_details = TenderData.cmobjects.select_related('form').filter(form__form_group_id=item.id, \
                                                                                     tender_id=tender_id).values('form_id', \
                                                                                                                 'form__form_label').distinct() 
            tender_dict = dict()
            tender_dict['group_name'] = item.name
            tender_dict['id'] = item.id 
            tender_dict['is_multiple'] = item.is_multiple 
            tender_list = []

            if item.is_multiple:
                for obj in tender_data_details:
                    obj_dict = dict()

                    obj_dict['form_label'] = obj.get('form__form_label', None)
                    data_list = []
                    data_file_list = []
                    data_details = TenderData.cmobjects.select_related('form').filter(form_id=obj.get('form_id', None))
                    for imv in data_details:
                        if imv:
                            if imv.value and represents_int(imv.value):
                                final_value = FormDropdownChoices.cmobjects.filter(id=int(imv.value)).first()
                                dependent_value = FormDependentChoices.cmobjects.filter(id=int(imv.value)).first()
                                if final_value:
                                    value = final_value.option 
                                elif dependent_value:
                                    value = dependent_value.name
                                else:
                                    value = imv.value 
                            else:
                                value = imv.value 
                        else:
                            value = ""
                        document = imv.document.url if imv and imv.document else ""

                        data_list.append(value)
                        data_file_list.append(document)

                    obj_dict['value'] = data_list
                    obj_dict['document'] = data_file_list

                    tender_list.append(obj_dict)
            else:
                for obj in tender_data_details:
                    obj_dict = dict()

                    obj_dict['form_label'] = obj.get('form__form_label', None)
                    data_details = TenderData.cmobjects.select_related('form').filter(form_id=obj.get('form_id', None), \
                                                                                     tender_id=tender_id).first()
                    if data_details:
                        if data_details.value and represents_int(data_details.value):
                            final_value = FormDropdownChoices.cmobjects.filter(id=int(data_details.value)).first()
                            dependent_value = FormDependentChoices.cmobjects.filter(id=int(data_details.value)).first()
                            if final_value:
                                obj_dict['value'] = final_value.option 
                            elif dependent_value:
                                obj_dict['value'] = dependent_value.name
                            else:
                                obj_dict['value'] = data_details.value 
                        else:
                            obj_dict['value'] = data_details.value 
                    else:
                        obj_dict['value'] = ""
                    obj_dict['document'] = data_details.document.url if data_details and data_details.document else ""

                    tender_list.append(obj_dict)

            tender_dict['tender_datas'] = tender_list

            result_list.append(tender_dict)
        
        return result_list
    
    class Meta:
        model = TenderMaster
        fields = '__all__'
            

class TenderDataSerializer(serializers.ModelSerializer):

    class Meta:
        model = TenderData
        fields = '__all__'


class TenderSerializer(serializers.ModelSerializer):
    """ Add Tender model serizalizer"""
    class Meta:
        model = Tender
        fields = '__all__'


class TenderDocumentSerializer(serializers.ModelSerializer):
    """ Add Tender model serizalizer"""
    class Meta:
        model = TenderDocument
        fields = '__all__'      


class TenderWBSKeyScopesSerializer(serializers.ModelSerializer):
    """"
    Tender WBS KeyScopes Serializer
    """
    tender_value = serializers.SerializerMethodField()
    uom_name= serializers.SerializerMethodField()
    second_key_scopes = serializers.SerializerMethodField()

    def get_second_key_scopes(self,instance):
        key_list = TenderWBSSecondKeyScopes.cmobjects.filter(keyscope_id=instance.id).order_by("by_order").values("id","name","unit",\
                                                                                                       "uom__symbol","uom_id")
        return key_list


    def get_tender_value(self, obj):
        tender_id = self.context.get("tender_id", None)
        ex_details = ExecutiveSummeryData.objects.filter(tender_id=tender_id, wbs_id=obj.id,\
                                                         form__form_internal_name='qty').first()
        if ex_details:
            return float(ex_details.value)
        return 0
    
    def get_uom_name(self, obj):
        uom_details = UnitOfMesurement.cmobjects.filter(id=obj.uom_id).first()
        if uom_details:
            return uom_details.symbol
        else:
            return ""
        
    class Meta:
        model = TenderWBSKeyScopes
        fields = '__all__'


class TenderWBSSecondKeyScopesSerializer(serializers.ModelSerializer):
    """"
    Tender WBS Second KeyScopes Serializer
    """
    uom_name= serializers.SerializerMethodField()
    
    def get_uom_name(self, obj):
        uom_details = UnitOfMesurement.cmobjects.filter(id=obj.uom_id).first()
        if uom_details:
            return uom_details.symbol
        else:
            return ""
        
    class Meta:
        model = TenderWBSSecondKeyScopes
        fields = '__all__'


class TenderWBSSerializer(serializers.ModelSerializer):
    """"
    Tender WBS Serializer
    """
    # key_scopes = serializers.SerializerMethodField()
    # key_scopes = TenderWBSKeyScopesSerializer(many=True, source="tender_wbs_key_scope")
    uom_name = serializers.SerializerMethodField()
    tender_value = serializers.SerializerMethodField()
    wbs_attribute = serializers.SerializerMethodField()

    # def get_key_scopes(self,instance):
    #     key_list = TenderWBSKeyScopes.cmobjects.filter(wbs_id=instance.id).order_by("by_order").annotate(uom_name=F('uom__symbol')).values("id","keyscope","unit",\
    #                                                                                                    "uom_name","uom_id")
    #     for item_data in key_list:
    #         item_data['second_key_scopes'] = TenderWBSSecondKeyScopes.cmobjects.filter(keyscope_id=item_data['id']).order_by("by_order").annotate(uom_name=F('uom__symbol')).values("id","name","unit",\
    #                                                                                                    "uom_name","uom_id")
    #     return key_list

    def get_tender_value(self, instance):
        key_list = ExecutiveSummeryData.cmobjects.filter(wbs=instance, form__form_group=99, form__form_internal_name='type_of_road').values_list('value', flat=True)
        return key_list

    def get_uom_name(self, instance):
        if instance.uom:
            return instance.uom.symbol
        else:
            return ""

    def get_wbs_attribute(self, instance):
        _list = WbsAttribute.cmobjects.filter(pk=instance.id).values()
        if _list:
            return _list
        return [{'risk_type': None, 'color_code': '#0d6efd'}] # default values

    class Meta:
        model = TenderWBS
        fields = '__all__'


class WbsAttributeSerializer(serializers.ModelSerializer):
    """
    WbsAttribute Serializer
    """

    class Meta:
        model = WbsAttribute
        fields = '__all__'


class TopSheetSaleDataSerializer(serializers.ModelSerializer):
    """"
    TopSheet Sale Data Serializer
    """

    class Meta:
        model = TopSheetSaleData
        fields = '__all__'


class TopSheetExpenditureDataSerializer(serializers.ModelSerializer):
    """"
    TopSheet Expenditure Data Serializer
    """

    class Meta:
        model = TopSheetExpenditureData
        fields = '__all__'
        
class ExecutiveSummeryDataSerializer(serializers.ModelSerializer):
    wbs = serializers.SerializerMethodField()
    # wbskey = serializers.SerializerMethodField()
    wbs_id = serializers.SerializerMethodField()
    wbs_parent_id = serializers.SerializerMethodField()
    # wbs_key_id = serializers.SerializerMethodField()
    # wbs_second_key = serializers.SerializerMethodField()
    # wbs_second_key_id = serializers.SerializerMethodField()

    class Meta:
        model = ExecutiveSummeryData
        fields = '__all__'

    def get_wbs_parent_id(self, obj):
        if obj.wbs:
            if obj.wbs.parent_id:
                return obj.wbs.parent_id.id
        return None

    def get_wbs_second_key(self, obj):
        if obj.wbssecondkey:
            return obj.wbssecondkey.name
        return None

    def get_wbs_second_key_id(self, obj):
        if obj.wbssecondkey:
            return obj.wbssecondkey_id
        return None

    def get_wbs(self, obj):
        if obj.wbs:
            return obj.wbs.wbs_name
        return None

    def get_wbskey(self, obj):
        if obj.wbskey:
            return obj.wbskey.keyscope
        return None
    
    def get_wbs_id(self, obj):
        if obj.wbs:
            return obj.wbs_id
        return None

    def get_wbs_key_id(self, obj):
        if obj.wbskey:
            return obj.wbs_id
        return None
    

# class TenderCompliancesDataSerializer(serializers.ModelSerializer):
#     value = serializers.SerializerMethodField()

#     def get_value(self, obj):
#         if obj.form.form_internal_name == 'days_left_from_today':
#             derivative_date_details = TenderCompliancesData.cmobjects.filter(form__form_internal_name='dates',\
#                                                                              form__form_type='tender_executive_summary', \
#                                                                                 compliances_id=obj.compliances_id).first()
#             if derivative_date_details:
#                 date_provided_str = derivative_date_details.value
#                 date_provided = datetime.strptime(date_provided_str, "%Y-%m-%d").date()
#                 date = datetime.now().date()

#                 no_of_days = int((date-date_provided).days) + 1 
#                 return str(no_of_days) + " Days" if int(no_of_days) > 1 else str(no_of_days) + " Day"
#             else:
#                 return ""
#         return obj.value
    

class TenderComplianceDerivativesSerializer(serializers.ModelSerializer):
    compliance_obj = serializers.SerializerMethodField()

    class Meta:
        model = TenderComplianceDerivatives
        fields = '__all__'

    def get_compliance_obj(self, obj):
        if obj.id:
            details = TenderCompliancesData.objects.filter(compliances_id=obj.id).values()
            return details
        return []

class RiskdetailsSerializer(serializers.ModelSerializer):
    risk_details_obj = serializers.SerializerMethodField()

    class Meta:
        model = Riskdetails
        fields = '__all__'

    def get_risk_details_obj(self, obj):
        if obj.id:
            details = RiskdetailsData.objects.filter(risk_details_id=obj.id).values()
            return details
        return []

class OpportunitydetailsSerializer(serializers.ModelSerializer):
    opportunity_details_obj = serializers.SerializerMethodField()

    class Meta:
        model = Opportunitydetails
        fields = '__all__'

    def get_opportunity_details_obj(self, obj):
        if obj.id:
            details = OpportunitydetailsData.objects.filter(opportunity_details_id=obj.id).values()
            return details
        return []




class TenderActivityLogSerializer(serializers.ModelSerializer):

    name = serializers.SerializerMethodField()

    class Meta:
        model = TenderActivityLog
        fields = '__all__'

    def get_name(self, obj):
        if obj.user:
            details = str(obj.user.first_name) + " " + str(obj.user.last_name)
            return details
        return ''





class TenderExecutiveCommiteeSerializer(serializers.ModelSerializer):
    tender_users = serializers.SerializerMethodField()
    is_approval_user = serializers.SerializerMethodField()

    class Meta:
        model = TenderExecutiveCommitee
        fields = '__all__'

    def get_tender_users(self, obj):
        if obj.id:
            details = TenderCommiteeMembers.cmobjects.filter(ex_commitee=obj.id).values('users', 'users__username', \
                                                                                        'users__first_name', \
                                                                                            'users__last_name', \
                                                                                                'users_id', 'level', 'commitee_level')
            return details
        return []
    
    def get_is_approval_user(self, obj):
        user_id = self.context.get("user_id", None)
        if obj.id:
            from django.db.models import Q
            action_user_ids = list(TenderCommiteeMembers.cmobjects.filter(\
                ex_commitee=obj.id).exclude(Q(is_approved=True) | \
                                            Q(is_reject=True) | Q(is_vga_approved=True) |\
                                                Q(is_vga_reject=True)).values_list('users_id', \
                                                                           flat=True))
            
            if user_id in action_user_ids:
                is_present = True
            else:
                is_present = False
            return is_present
        return False
    

class TenderExecutiveCommiteeFinalApprovalSerializer(serializers.ModelSerializer):
    tender_users = serializers.SerializerMethodField()
    is_approval_user = serializers.SerializerMethodField()

    class Meta:
        model = TenderExecutiveCommitee
        fields = '__all__'

    def get_tender_users(self, obj):
        if obj.id:
            details = TenderCommiteeMembers.cmobjects.filter(ex_commitee=obj.id).values('users', 'users__username', \
                                                                                        'users__first_name', \
                                                                                            'users__last_name', \
                                                                                                'users_id', 'level', 'commitee_level')
            return details
        return []
    
    def get_is_approval_user(self, obj):
        user_id = self.context.get("user_id", None)
        if obj.id:
            from django.db.models import Q
            action_user_ids = list(TenderCommiteeMembers.cmobjects.filter(\
                ex_commitee=obj.id).exclude(Q(is_approved=True) | \
                                            Q(is_reject=True)).values_list('users_id', \
                                                                           flat=True))
            
            if user_id in action_user_ids:
                is_present = True
            else:
                is_present = False
            return is_present
        return False
    


class TenderExecutiveCommiteeMembersSerializer(serializers.ModelSerializer):
    tender_id = serializers.SerializerMethodField()
    status = serializers.SerializerMethodField()

    class Meta:
        model = TenderCommiteeMembers
        fields = '__all__'

    def get_tender_id(self, obj):
        if obj.ex_commitee_id:
            ex_details = TenderExecutiveCommitee.objects.filter(id=obj.ex_commitee_id).first()
            return ex_details.tender_id
        return ""
    
    def get_status(self, obj):
        if obj.is_vga_approved == True:
            status = "VGA Done"
        elif obj.is_vga_reject == True:
            status = "VGA Rejected"
        else:
            status = "Waiting For Approval"
        return status
    

class TenderExecutiveCommiteeMembersFinalApprovalSerializer(serializers.ModelSerializer):
    """ Tender Executive Summary For Final Approval (**************** Made New As needed change in the remarks row)"""

    tender_id = serializers.SerializerMethodField()
    status = serializers.SerializerMethodField()
    remarks = serializers.SerializerMethodField()

    class Meta:
        model = TenderCommiteeMembers
        fields = '__all__'

    def get_tender_id(self, obj):
        if obj.ex_commitee_id:
            ex_details = TenderExecutiveCommitee.objects.filter(id=obj.ex_commitee_id).first()
            return ex_details.tender_id
        return ""
    
    def get_status(self, obj):
        if obj.is_approved == True:
            status = "Approved"
        elif obj.is_reject == True:
            status = "Rejected"
        else:
            status = "Waiting For Approval"
        return status
    
    def get_remarks(self, obj):
        if obj.is_approved == True:
            remarks = obj.approval_remarks
        elif obj.is_reject == True:
            remarks = obj.rejection_remarks
        else:
            remarks = ""
        return remarks


class TenderChainageSerializer(serializers.ModelSerializer):
    """
        TenderChainage Serializer
    """
    class Meta:
        model = TenderChainage
        fields = '__all__'


class ChainageExecutiveSummeryDataSerializer(serializers.ModelSerializer):
    """
        ChainageExecutiveSummeryData Serializer
    """
    class Meta:
        model = ChainageExecutiveSummeryData
        fields = '__all__'

class TenderWBSProjectSerializer(serializers.ModelSerializer):
    """"
    Tender WBS Project Serializer
    """
   
    uom_name = serializers.SerializerMethodField()
    wbs = TenderWBSSerializer()



    def get_uom_name(self, instance):
        if instance.uom:
            return instance.uom.symbol
        else:
            return ""

    

    class Meta:
        model = TenderWBSProject
        fields = '__all__'

class TopSheetMapSerializer(serializers.ModelSerializer):
    """"
    Top Sheet Map Serializer(model in tender app)
    """

    class Meta:
        model = TopSheetMap
        fields = '__all__'


class TopSheetMapSerializer2(serializers.ModelSerializer):
    """
    Top Sheet Map Serializer(model in tender app)
    """

    # total_child_percentage = serializers.SerializerMethodField()
    executive_summery_data_sum = serializers.SerializerMethodField()

    # def get_total_child_percentage(self, instance):
    #     total = TopSheetMap.cmobjects.filter(parent=instance).aggregate(Sum("percentage", default=0))["percentage__sum"]
    #     return total

    def get_executive_summery_data_sum(self, instance):
        _details = 0.
        if instance.tender and instance.wbs.all():
            wbs_ids = [i.pk for i in instance.wbs.all()]
            try:
                _details = ExecutiveSummeryData.cmobjects.filter(
                    tender=instance.tender,
                    wbs__in=wbs_ids,
                    form__form_internal_name='sale_amount'
                ).aggregate(Sum("value", default=0))["value__sum"]
            except Exception as e:
                print('ERROR', e)
        return _details


    class Meta:
        model = TopSheetMap
        fields = '__all__'


class TenderSectorSerializer(serializers.ModelSerializer):
    users_details = serializers.SerializerMethodField()
    class Meta:
        model = TenderSector
        fields = '__all__'
    def get_users_details(self, instance):
        return list(instance.users.values('id', 'username', 'email', 'first_name', 'last_name'))

    def create(self, validated_data):
        request = self.context.get('request')
        if not request or not request.user:
            raise serializers.ValidationError(
                {"detail": "Request context and authenticated user are required."}
            )
        users = validated_data.pop('users', [])
        validated_data['created_by'] = request.user
        
        with transaction.atomic():
            sector = TenderSector.objects.create(**validated_data)
            sector.users.set(users)
            sector.save()    
        return sector

    def update(self, instance, validated_data):
        request = self.context.get('request')
        if not request or not request.user:
            raise serializers.ValidationError(
                {"detail": "Request context and authenticated user are required."}
            )
        users = validated_data.pop('users', None)
        with transaction.atomic():
            for field in instance._meta.fields:
                field_name = field.name
                if field_name in validated_data:
                    setattr(instance, field_name, validated_data[field_name])
            if users:
                instance.users.clear()
                instance.users.set(users)
            instance.save()
        return instance


class TenderSubSectorSerializer(serializers.ModelSerializer):
    sector_details = serializers.SerializerMethodField()
    def get_sector_details(self, instance):
        _details = None
        if instance.sector:
            _details = TenderSector.cmobjects.filter(pk=instance.sector.id).values()
        return _details
    class Meta:
        model = TenderSubSector
        fields = '__all__'


class TenderDepartmentMasterSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = TenderDepartmentMaster
        fields = '__all__'

class TenderChecklistMasterSerializer(serializers.ModelSerializer):
    tender_department_details = serializers.SerializerMethodField()
    class Meta:
        model = TenderChecklistMaster
        fields = '__all__'

    def get_tender_department_details(self, instance):
        return get_details_from_instance(instance.tender_department, type="dict")


class TenderMasterNewPartyDetailsSerializer(serializers.ModelSerializer):
    company = serializers.PrimaryKeyRelatedField(
        queryset=Company.objects.all(),
        required=False,
        allow_null=True
    )
    jvmaster = serializers.PrimaryKeyRelatedField(
        queryset=JVMASTER.objects.all(),
        required=False,
        allow_null=True
    )
    # For displaying nested data on GET
    company_details = CompanySerializer(source='company', read_only=True)
    jvmaster_details = JVMASTERSerializer(source='jvmaster', read_only=True)

    class Meta:
        model = TenderMasterNewPartyDetails
        fields = '__all__'


class TenderMasterNewWinLossAnalysisSerializer(serializers.ModelSerializer):    

    def update(self, instance, validated_data):
        user = self.context['request'].user
        validated_data['updated_by'] = user
        return super().update(instance, validated_data)
    
    class Meta:
        model = TenderMasterNewWinLossAnalysis
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']


class TenderMasterNewSerializer(serializers.ModelSerializer):
    sector_details = serializers.SerializerMethodField()
    employer_details = serializers.SerializerMethodField()
    state_details = serializers.SerializerMethodField()
    party_list = TenderMasterNewPartyDetailsSerializer(many=True, required=False)
    party_details = TenderMasterNewPartyDetailsSerializer(
        source='tender_party_details',
        many=True,
        read_only=True
    )
    win_loss_analysis = serializers.SerializerMethodField()
    admin_liasoning_assignees = serializers.SerializerMethodField()
    physical_feasibility_assignees = serializers.SerializerMethodField()
    material_rate_assignees = serializers.SerializerMethodField()
    statutory_taxation_assignees = serializers.SerializerMethodField()

    class Meta:
        model = TenderMasterNew
        fields = '__all__'

    def get_win_loss_analysis(self, obj):
        try:
            win_loss_data = obj.tender_win_loss.all().filter(is_deleted=False)
            return TenderMasterNewWinLossAnalysisSerializer(win_loss_data, many=True).data
        except Exception as e:
            print("Error fetching win_loss_analysis:", str(e))
            return []

    def get_admin_liasoning_assignees(self, instance):

        return list(instance.admin_and_liasoning.values('id', 'username', 'email', 'first_name', 'last_name'))

    def get_physical_feasibility_assignees(self, instance):
        return list(instance.physical_fesibility.values('id', 'username', 'email', 'first_name', 'last_name'))

    def get_material_rate_assignees(self, instance):
        return list(instance.material_rate.values('id', 'username', 'email', 'first_name', 'last_name'))

    def get_statutory_taxation_assignees(self, instance):
        return list(instance.statutory_and_taxation.values('id', 'username', 'email', 'first_name', 'last_name'))

    def get_employer_details(self, instance):
        return get_details_from_instance(instance.tender_organization, type="dict")

    def get_state_details(self, instance):
        return get_details_from_instance(instance.state, type="dict")

    def get_sector_details(self, instance):
        return get_details_from_instance(instance.sector, type="dict")

    def create(self, validated_data):
        request = self.context.get('request')
        if not request:
            raise serializers.ValidationError("Request context is required.")
        party_list_data = validated_data.pop('party_list', [])
        
        admin_liasoning = validated_data.pop('admin_and_liasoning', [])
        physical_feasibility = validated_data.pop('physical_fesibility', [])
        material_rate = validated_data.pop('material_rate', [])
        statutory_taxation = validated_data.pop('statutory_and_taxation', [])

        user = request.user
        validated_data['created_by'] = user

        with transaction.atomic():
            tender = TenderMasterNew.objects.create(**validated_data)
            if admin_liasoning:
                tender.admin_and_liasoning.add(*admin_liasoning)
            if physical_feasibility:
                tender.physical_fesibility.add(*physical_feasibility)
            if material_rate:
                tender.material_rate.add(*material_rate)
            if statutory_taxation:
                tender.statutory_and_taxation.add(*statutory_taxation)

            for party_data in party_list_data:
                TenderMasterNewPartyDetails.objects.create(tender=tender, **party_data)

        return tender


    def update(self, instance, validated_data):
        request = self.context.get('request')
        if not request:
            raise serializers.ValidationError("Request context is required.")

        party_list_data = validated_data.pop('party_list', [])
        
        admin_liasoning = validated_data.pop('admin_and_liasoning', None)
        physical_feasibility = validated_data.pop('physical_fesibility', None)
        material_rate = validated_data.pop('material_rate', None)
        statutory_taxation = validated_data.pop('statutory_and_taxation', None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if admin_liasoning is not None:
            instance.admin_and_liasoning.set(admin_liasoning)
        if physical_feasibility is not None:
            instance.physical_fesibility.set(physical_feasibility)
        if material_rate is not None:
            instance.material_rate.set(material_rate)
        if statutory_taxation is not None:
            instance.statutory_and_taxation.set(statutory_taxation)

        if party_list_data:
            incoming_party_ids = [item.get('id') for item in party_list_data if item.get('id')]
            TenderMasterNewPartyDetails.cmobjects.filter(tender=instance).exclude(id__in=incoming_party_ids).delete()

        for party_data in party_list_data:
            party_id = party_data.get('id')
            if party_id:
                party_instance = TenderMasterNewPartyDetails.cmobjects.get(id=party_id, tender=instance)
                for key, val in party_data.items():
                    setattr(party_instance, key, val)
                party_instance.save()
            else:
                TenderMasterNewPartyDetails.objects.create(tender=instance, **party_data)

        return instance
    

class TenderMasterNewQualificationDocumentsSerializer(serializers.ModelSerializer):
    tender_department_details = serializers.SerializerMethodField()
    checklist_details = serializers.SerializerMethodField()

    def get_tender_department_details(self, instance):
        return get_details_from_instance(instance.tender_department, type="dict")
    
    def get_checklist_details(self, instance):
        return get_details_from_instance(instance.checklist, type="dict")

    def create(self, validated_data):
        request = self.context.get('request')
        if not request:
            raise serializers.ValidationError("Request context is required.")
        
        payload = request.data 
        created_instances = []
        for item in payload:
            organization_id = item.get('organization_id')
            tender_id = item.get('tender_id')
            file_data = item.get('file_data', '')
            mime_type = item.get('mime_type', '')
            file_name = item.get('file_name', '')
            doc_type = item.get('doc_type', )
            is_email = item.get('is_email')
            mail_to = item.get('mail_to')
            mail_cc = item.get('mail_cc')

            attachment_content = process_attachments({'mime_type': mime_type,'file_data': file_data})
            tender_document = TenderMasterNewQualificationDocuments.objects.create(
                organization_id=organization_id,
                tender_id=tender_id,
                file_name=file_name,
                attachment_name = file_name,
                attachment=attachment_content,
                created_by=request.user,
                doc_type = doc_type,
                is_email = is_email,
                mail_to = mail_to,
                mail_cc = mail_cc
            )
            created_instances.append(tender_document)

        return created_instances 

    def update(self, instance, validated_data):
        request = self.context.get('request')
        if not request:
            raise serializers.ValidationError("Request context is required.")

        instance.organization_id = validated_data.get('organization_id', instance.organization_id)
        instance.tender_id = validated_data.get('tender_id', instance.tender_id)
        instance.file_name = validated_data.get('file_name', instance.file_name)
        instance.attachment_name = validated_data.get('file_name', instance.attachment_name)
        
        file_data = request.data.get('fileData')
        mime_type = request.data.get('mime_type')

        if file_data:
            requested_attachment_data = {
                'mime_type': mime_type or instance.mime_type,
                'fileData': file_data,
            }
            attachment = process_attachments(requested_attachment_data)
            if attachment:
                instance.attachment = attachment 

        instance.updated_by = request.user
        instance.save()
        return instance
    class Meta:
        model = TenderMasterNewQualificationDocuments
        fields = '__all__'



class TenderEmpanelmentTrackerTypeMasterSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderEmpanelmentTrackerTypeMaster
        fields = '__all__'

class TenderEmpanelmentTrackerSerializer(serializers.ModelSerializer):
    type_details = serializers.SerializerMethodField()
    class Meta:
        model = TenderEmpanelmentTracker
        fields = '__all__'

    def get_type_details(self, instance):
        return get_details_from_instance(instance.type, type="dict")
    
class TenderEmpanelmentTrackerDocumentSerializer(serializers.ModelSerializer):
    """ Serializer for Tender Empanelment Tracker Document model """

    empanelment_tracker_details = serializers.SerializerMethodField()

    def get_empanelment_tracker_details(self, instance):
        return get_details_from_instance(instance.empanelment_tracker, type="dict")

    class Meta:
        model = TenderEmpanelmentTrackerDocument
        fields = '__all__'

    @transaction.atomic
    def create(self, validated_data):
        filedata = validated_data.pop('file_data', None)
        mime_type = validated_data.pop('mime_type', '')
        file_name = validated_data.pop('file_name', '')
        try:
            if not filedata:
                raise serializers.ValidationError({
                    "file_data": "This field is required to process the attachment."
                })
            attachment_content = process_attachments({
                'mime_type': mime_type,
                'file_data': filedata
            })
            # attachment_content.name = file_name

            instance = TenderEmpanelmentTrackerDocument.objects.create(
                attachment=attachment_content,
                file_name=file_name,
                **validated_data
            )
            return instance
        except serializers.ValidationError:
            raise
        except Exception as e:
            print(f"Unexpected exception: {e}")
            raise serializers.ValidationError(f"Failed to create record: {str(e)}")

    @transaction.atomic
    def update(self, instance, validated_data):
        file_data = validated_data.pop('file_data', None)
        mime_type = validated_data.pop('mime_type', '')
        file_name = validated_data.pop('file_name', '')
        try:
            if file_data:
                attachment_content = process_attachments({'mime_type': mime_type, 'file_data': file_data})
                attachment_content.name = file_name
                instance.attachment = attachment_content

            for attr, value in validated_data.items():
                setattr(instance, attr, value)
                
            instance.save()
            return instance

        except Exception as e:
            raise serializers.ValidationError(f"Failed to update Tender Empanelment Tracker Document: {str(e)}")

class TenderMasterNewCencelRequestLogSerializer(serializers.ModelSerializer):
    tender_details = serializers.SerializerMethodField()
    class Meta:
        model = TenderMasterNewApprovalRequestLog
        fields = '__all__'  
    def get_tender_details(self, instance):
        """
        Return selected details from the related TenderMasterNew object.
        """
        tender = instance.tender
        if tender:
            return {
                "id": tender.id,
                "tender_id": tender.tender_id or "",
                "name": tender.name or "",
            }
        return None


## TENDER SURVEY
class TenderMasterNewSurveyMasterSerializer(serializers.ModelSerializer):
    tender_details = serializers.SerializerMethodField()
    tender_sector_name = serializers.SerializerMethodField()
    tender_state_name = serializers.SerializerMethodField()
    tender_department_name = serializers.SerializerMethodField()
    tender_organization_name = serializers.SerializerMethodField()
    survey_child_tables = serializers.SerializerMethodField()
    users_details = serializers.SerializerMethodField()
    def get_users_details(self, instance):
        details = []
        for user in instance.users.all():
            details.append({
                "first_name": user.first_name,
                "last_name": user.last_name,
                "email": user.email,
            })
        return details
    def get_survey_child_tables(self, instance):
        all_models = instance._meta.related_objects
        child_status = {}
        for model in all_models:
            accessor_name = model.get_accessor_name()
            related_obj = getattr(instance, accessor_name, None)
            if model.one_to_one:
                has_data = related_obj is not None
            else:
                has_data = related_obj.exists()
            child_status[accessor_name] = has_data
        return child_status
    def get_tender_sector_name(self, instance):
        return instance.tender.sector.name if instance.tender.sector else ''
    def get_tender_state_name(self, instance):
        return instance.tender.state.name if instance.tender.state else ''
    def get_tender_department_name(self, instance):
        return instance.tender.department_name if instance.tender.department_name else ''
    def get_tender_organization_name(self, instance):
        return instance.tender.tender_organization.employee_name if instance.tender.tender_organization else ''
    def get_tender_details(self, instance):
        return get_details_from_instance(instance.tender)
    class Meta:
        model = TenderMasterNewSurveyMaster
        fields = '__all__'

class TenderMasterNewSurveyMasterAttachmentsSerializer(serializers.ModelSerializer):
    """
    TenderMaster New Survey Master Attachments Serializer 
    """
    id = serializers.IntegerField(required=False)
    location_name = serializers.SerializerMethodField()
    def get_location_name(self, instance):
        location_name = None
        if instance.latitude and instance.longitude:
            location_name = get_location_name(instance.latitude, instance.longitude)
        return location_name
    class Meta:
        model = TenderMasterNewSurveyMasterSiteDetailsAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterSiteDetailsSerializer(serializers.ModelSerializer):
    survey_details = serializers.SerializerMethodField()
    attachments = TenderMasterNewSurveyMasterAttachmentsSerializer(many=True, required=False, source="survey_site_details_attachment")
    def get_survey_details(self, instance):
        return get_details_from_instance(instance.survey)
    @transaction.atomic
    def create(self, validated_data):
        requested_attachment = validated_data.pop('survey_site_details_attachment', [])
        site_details = TenderMasterNewSurveyMasterSiteDetails.objects.create(**validated_data)
        current_user = site_details.created_by if site_details.created_by else None
        for requested_attachment_data in requested_attachment:
            try:
                TenderMasterNewSurveyMasterSiteDetailsAttachments.objects.create(
                    site_details=site_details,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type=requested_attachment_data.get('mime_type', None), 
                    attachment_name=requested_attachment_data.get('attachment_name', None),
                    latitude=requested_attachment_data.get('latitude', None),
                    longitude=requested_attachment_data.get('longitude', None),
                    created_by=current_user,
                    remarks=requested_attachment_data.get('remarks', None),
                )
            except Exception as e:
                print(f"exception: {e}")
        site_details.save()
        return site_details
    
    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])

        current_user = instance.updated_by if instance.updated_by else None
        attachments_data = validated_data.get('survey_site_details_attachment', [])
        existing_attachments = instance.survey_site_details_attachment.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = TenderMasterNewSurveyMasterSiteDetailsAttachments.objects.create(
                        site_details=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type=attachment_data.get('mime_type', None), 
                        attachment_name=attachment_data.get('attachment_name', None),
                        latitude=attachment_data.get('latitude', None),
                        longitude=attachment_data.get('longitude', None), 
                        remarks=attachment_data.get('remarks', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'mime_type', attachment_data.get('mime_type', None))
                setattr(existing_attachment, 'latitude', attachment_data.get('latitude', None))
                setattr(existing_attachment, 'longitude', attachment_data.get('longitude', None))
                setattr(existing_attachment, 'remarks', attachment_data.get('remarks', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data
        return representation
    class Meta:
        model = TenderMasterNewSurveyMasterSiteDetails
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
        
class TenderMasterNewSurveyMasterFacilitySiteAttachmentsSerializer(serializers.ModelSerializer):
    """
    Tender Master NewSurvey Master Facility Site Attachments Attachments Serializer 
    """
    id = serializers.IntegerField(required=False)
    location_name = serializers.SerializerMethodField()
    def get_location_name(self, instance):
        location_name = None
        if instance.latitude and instance.longitude:
            location_name = get_location_name(instance.latitude, instance.longitude)
        return location_name
    class Meta:
        model = TenderMasterNewSurveyMasterFacilitySiteAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterFacilitySiteSerializer(serializers.ModelSerializer):
    attachments = TenderMasterNewSurveyMasterFacilitySiteAttachmentsSerializer(many=True, required=False, source="survey_facility_site_attachments")
    @transaction.atomic
    def create(self, validated_data):
        requested_attachment = validated_data.pop('survey_facility_site_attachments', [])
        facility_site = TenderMasterNewSurveyMasterFacilitySite.objects.create(**validated_data)
        current_user = facility_site.created_by if facility_site.created_by else None
        for requested_attachment_data in requested_attachment:
            try:
                TenderMasterNewSurveyMasterFacilitySiteAttachments.objects.create(
                    facility_site=facility_site,
                    attachment=process_attachments(requested_attachment_data),
                    file_data="",
                    mime_type=requested_attachment_data.get('mime_type', None), 
                    attachment_name=requested_attachment_data.get('attachment_name', None),
                    latitude=requested_attachment_data.get('latitude', None),
                    longitude=requested_attachment_data.get('longitude', None),
                    created_by=current_user,
                    remarks=requested_attachment_data.get('remarks', None),
                )
            except Exception as e:
                print(f"exception: {e}")
        facility_site.save()
        return facility_site
    
    @transaction.atomic
    def update(self, instance, validated_data):
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])

        current_user = instance.updated_by if instance.updated_by else None
        attachments_data = validated_data.get('survey_facility_site_attachments', [])
        existing_attachments = instance.survey_facility_site_attachments.filter(is_deleted=False)

        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            temp_attach_data = process_attachments(attachment_data)
            existing_attachment = next((attachment for attachment in existing_attachments if attachment.id == attachment_id), None)
            if not existing_attachment:
                try:
                    existing_attachment = TenderMasterNewSurveyMasterFacilitySiteAttachments.objects.create(
						facility_site=instance,
                        attachment=temp_attach_data,
                        file_data="",
                        mime_type=attachment_data.get('mime_type', None), 
                        attachment_name=attachment_data.get('attachment_name', None),
                        latitude=attachment_data.get('latitude', None),
                        longitude=attachment_data.get('longitude', None),
                        remarks=attachment_data.get('remarks', None),
                        created_by=current_user
                    )
                except Exception as e:
                    print(f"exception: {e}")
            else:
                if temp_attach_data:
                    setattr(existing_attachment, 'attachment', temp_attach_data)
                setattr(existing_attachment, 'attachment_name', attachment_data.get('attachment_name', None))
                setattr(existing_attachment, 'mime_type', attachment_data.get('mime_type', None))
                setattr(existing_attachment, 'latitude', attachment_data.get('latitude', None))
                setattr(existing_attachment, 'longitude', attachment_data.get('longitude', None))
                setattr(existing_attachment, 'remarks', attachment_data.get('remarks', None))
                setattr(existing_attachment, 'updated_by', current_user)
                existing_attachment.save()
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        attachment_data = representation.pop('attachments', [])
        representation['attachments'] = attachment_data
        return representation
    class Meta:
        model = TenderMasterNewSurveyMasterFacilitySite
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterClimateAtSiteSiteSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterClimateAtSite
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterHydrologicalMarineConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterHydrologicalMarineCondition
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterTopographySerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterTopography
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterGeologicalDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterGeologicalData
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
class TenderMasterNewSurveyMasterLocalIssuesSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterLocalIssues
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

# class TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsSerializer(serializers.ModelSerializer):
#     """
#     Serializer for Construction Materials Attachments
#     """
#     id = serializers.IntegerField(required=False)

#     class Meta:
#         model = TenderMasterNewSurveyMasterConstructionMaterialsAttachments
#         fields = '__all__'
#         read_only_fields = ['id']
#         list_serializer_class = CommonFilterListSerializer
        
class TenderMasterNewSurveyMasterConstructionMaterialsSupplierDetailsSerializer(serializers.ModelSerializer):
    """
    Serializer for Construction Materials Supplier Details
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = TenderMasterNewSurveyMasterConstructionMaterialsSupplierDetails
        fields = '__all__'
        read_only_fields = ['id', 'construction_materials']
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsSerializer(serializers.ModelSerializer):
    """ Serializer for Construction Materials Attachments """
    id = serializers.IntegerField(required=False, allow_null=True)
    class Meta:
        model = TenderMasterNewSurveyMasterConstructionMaterialsAttachments
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

    @transaction.atomic
    def create(self, validated_data):
        """
        If payload has 'id' -> update existing record
        Else -> create new record
        """
        current_user = self.context['request'].user.id if self.context['request'].user else None
        attachment_id = validated_data.get("id", None)
        if attachment_id:
            try:
                instance = TenderMasterNewSurveyMasterConstructionMaterialsAttachments.objects.get(pk=attachment_id)
                # Update fields
                instance.survey_id = validated_data.get("survey", instance.survey_id)
                if process_attachments(validated_data):
                    instance.attachment = process_attachments(validated_data)
                instance.file_data = validated_data.get("file_data", instance.file_data)
                instance.mime_type = validated_data.get("mime_type", instance.mime_type)
                instance.attachment_name = validated_data.get("attachment_name", instance.attachment_name)
                instance.remarks = validated_data.get("remarks", instance.remarks)
                instance.updated_by_id = current_user
                instance.save()
                return instance
            except TenderMasterNewSurveyMasterConstructionMaterialsAttachments.DoesNotExist:
                raise serializers.ValidationError(f"Attachment with id {attachment_id} not found")

        obj = TenderMasterNewSurveyMasterConstructionMaterialsAttachments.objects.create(
            survey=validated_data.get("survey"),
            attachment=process_attachments(validated_data),
            file_data=validated_data.get("file_data", ""),
            mime_type=validated_data.get("mime_type", ""),
            attachment_name=validated_data.get("attachment_name", ""),
            remarks=validated_data.get("remarks", ""),
            created_by_id=current_user,
        )
        return obj

class TenderMasterNewSurveyMasterConstructionMaterialsSerializer(serializers.ModelSerializer):
    """
    Serializer for Construction Materials with nested supplier details and attachments
    """
    supplier_details = TenderMasterNewSurveyMasterConstructionMaterialsSupplierDetailsSerializer(many=True, required=False, source="survey_construction_materials_supplier_details")
    # attachments = TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsSerializer(
    #     many=True, required=False, source="survey_construction_materials_attachments"
    # )
    @transaction.atomic
    def create(self, validated_data):
        supplier_details_data = validated_data.pop('survey_construction_materials_supplier_details', [])
        # attachments_data = validated_data.pop('survey_construction_materials_attachments', [])

        construction_materials = TenderMasterNewSurveyMasterConstructionMaterials.objects.create(**validated_data)
        current_user = construction_materials.created_by if construction_materials.created_by else None

        # for attachment in attachments_data:
        #     try:
        #         TenderMasterNewSurveyMasterConstructionMaterialsAttachments.objects.create(
        #             construction_materials=construction_materials,
        #             attachment=process_attachments(attachment),
        #             file_data="",
        #             mime_type=attachment.get('mime_type'),
        #             attachment_name=attachment.get('attachment_name'),
        #             remarks=attachment.get('remarks'),
        #             created_by=current_user,
        #         )
        #     except Exception as e:
        #         print(f"Attachment creation exception: {e}")

        # Create supplier details
        for supplier in supplier_details_data:
            TenderMasterNewSurveyMasterConstructionMaterialsSupplierDetails.objects.create(
                construction_materials=construction_materials,
                created_by=current_user,
                **supplier
            )
        return construction_materials

    @transaction.atomic
    def update(self, instance, validated_data):
        # Update base fields
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])

        current_user = instance.updated_by if instance.updated_by else None

        # Handle attachments
        # attachments_data = validated_data.get('survey_construction_materials_attachments', [])
        # existing_attachments = instance.survey_construction_materials_attachments.filter(is_deleted=False)
        
        # for attachment in attachments_data:
        #     attachment_id = attachment.get('id')
        #     temp_attach_data = process_attachments(attachment)
        #     existing_attachment = next((a for a in existing_attachments if a.id == attachment_id), None)

        #     if not existing_attachment:
        #         try:
        #             TenderMasterNewSurveyMasterConstructionMaterialsAttachments.objects.create(
        #                 construction_materials=instance,
        #                 attachment=temp_attach_data,
        #                 file_data="",
        #                 mime_type=attachment.get('mime_type'),
        #                 attachment_name=attachment.get('attachment_name'),
        #                 remarks=attachment.get('remarks'),
        #                 created_by=current_user
        #             )
        #         except Exception as e:
        #             print(f"Attachment update exception: {e}")
        #     else:
        #         if temp_attach_data:
        #             existing_attachment.attachment = temp_attach_data
        #         existing_attachment.attachment_name = attachment.get('attachment_name')
        #         existing_attachment.mime_type = attachment.get('mime_type')
        #         existing_attachment.remarks = attachment.get('remarks')
        #         existing_attachment.updated_by = current_user
        #         existing_attachment.save()

        # Handle supplier details
        supplier_details_data = validated_data.get('survey_construction_materials_supplier_details', [])
        existing_suppliers = instance.survey_construction_materials_supplier_details.filter(is_deleted=False)

        for item_data in supplier_details_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_suppliers if item.id == item_id), None)
            print(existing_item)
            if not existing_item:
                existing_item = TenderMasterNewSurveyMasterConstructionMaterialsSupplierDetails.objects.create(construction_materials=instance, created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        # Mark deleted suppliers
        for existing_supplier in existing_suppliers:
            if existing_supplier.id not in [s.get('id') for s in supplier_details_data]:
                existing_supplier.is_deleted = True
                existing_supplier.updated_by = current_user
                existing_supplier.save()
        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        # representation['attachments'] = representation.pop('attachments', [])
        supplier_details_data = representation.pop('supplier_details', [])
        representation['supplier_details'] = supplier_details_data
        return representation
    class Meta:
        model = TenderMasterNewSurveyMasterConstructionMaterials
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterSubContractorSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterSubContractor
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class SurveyEmployeeCategoriesMasterSerializer(serializers.ModelSerializer):
    class Meta:
        model = SurveyEmployeeCategoriesMaster
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class SurveyEmployeeCategoriesMasterAreaSerializer(serializers.ModelSerializer):

    class Meta:
        model = SurveyEmployeeCategoriesMasterArea
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
        

class TenderMasterNewSurveyMasterLabourEmployeeCategoriesSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    employee_category_details = serializers.SerializerMethodField()
    def get_employee_category_details(self, instance):
        return get_details_from_instance(instance.employee_category)
    class Meta:
        model = TenderMasterNewSurveyMasterLabourEmployeeCategories
        fields = '__all__'
        read_only_fields = ['id']

class TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    category_details = serializers.SerializerMethodField()
    def get_category_details(self, instance):
        return get_details_from_instance(instance.category)
    class Meta:
        model = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer
        
class TenderMasterNewSurveyMasterLabourAttachmentSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)  
    class Meta:
        model = TenderMasterNewSurveyMasterLabourAttachment
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class TenderMasterNewSurveyMasterLabourSerializer(serializers.ModelSerializer):
    man_power_items = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateSerializer(many=True,required=False,
                                source='survey_labour_man_power' )
    attachments = TenderMasterNewSurveyMasterLabourAttachmentSerializer(
        many=True,
        required=False,
        source='survey_labour_attachment'
    )
    class Meta:
        model = TenderMasterNewSurveyMasterLabour
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
    @transaction.atomic
    def create(self, validated_data):
        man_power_items_data = validated_data.pop('survey_labour_man_power', [])
        attachments_data = validated_data.pop('survey_labour_attachment', [])
        survey_labour = TenderMasterNewSurveyMasterLabour.objects.create(**validated_data)
        current_user = survey_labour.created_by if survey_labour.created_by else None
        for item_data in man_power_items_data:
            TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.objects.create(
                **item_data,
                labour=survey_labour,
                created_by=current_user,
            )
        for attachment_data in attachments_data:
            processed_attachment = process_attachments(attachment_data)
            attachment_data.pop('mime_type', None)
            attachment_data.pop('file_data', None)
            TenderMasterNewSurveyMasterLabourAttachment.objects.create(
                **attachment_data,
                labour=survey_labour,
                attachment=processed_attachment if processed_attachment else None,
                created_by=current_user,
            )
        return survey_labour
    
    @transaction.atomic
    def update(self, instance, validated_data):
        stages_data = validated_data.pop('survey_labour_man_power', [])
        attachments_data = validated_data.pop('survey_labour_attachment', [])
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])

        current_user = instance.updated_by if instance.updated_by else None
        existing_stages = instance.survey_labour_man_power.filter(is_deleted=False)
        existing_attachments = instance.survey_labour_attachment.filter(is_deleted=False)
        for item_data in stages_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_stages if item.id == item_id), None)

            if not existing_item:
                existing_item = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.objects.create(labour=instance, 
                                                                                                               created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_stages:
            if existing_item.id not in [item_data.get('id') for item_data in stages_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()


        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            processed_attachment = process_attachments(attachment_data)
            existing_attachment = next((item for item in existing_attachments if item.id == attachment_id), None)
            if existing_attachment:
                for attr, value in attachment_data.items():
                    setattr(existing_attachment, attr, value)
                if processed_attachment:
                    existing_attachment.attachment = processed_attachment
                    existing_attachment.file_data=""
                    existing_attachment.mime_type=""
                existing_attachment.updated_by = current_user
                existing_attachment.save()
            else:
                attachment_data.pop('mime_type', None)
                attachment_data.pop('file_data', None)
                TenderMasterNewSurveyMasterLabourAttachment.objects.create(
                    **attachment_data,
                    labour=instance,
                    attachment=processed_attachment if processed_attachment else None,
                    created_by=current_user,
                )

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['man_power_items'] = representation.pop('man_power_items', [])
        representation['attachments'] = representation.pop('attachments', [])
        return representation

class TenderMasterNewSurveyMasterFuelSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterFuel
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterAccommodationSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterAccommodation
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterTemporarySetupSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterTemporarySetup
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterTaxesDutiesSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterTaxesDuties
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
class TenderMasterNewSurveyMasterSubcontractorsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterSubcontractors
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
class TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterAccessCrossingsRouteDetails
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
class TenderMasterNewSurveyMasterWasteManagementSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterWasteManagement
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
class TenderMasterNewSurveyMasterMiscSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterMisc
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
class TenderMasterNewSurveyMasterReferenceSimilarProjectsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterReferenceSimilarProjects
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
class TenderMasterNewSurveyMasterExistingUtilitiesSerializer(serializers.ModelSerializer):
    class Meta:
        model = TenderMasterNewSurveyMasterExistingUtilities
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer

class TenderMasterNewSurveyMasterAllSerializer(serializers.ModelSerializer):
    tender_details = serializers.SerializerMethodField()
    tender_sector_name = serializers.SerializerMethodField()
    tender_state_name = serializers.SerializerMethodField()
    tender_department_name = serializers.SerializerMethodField()
    tender_organization_name = serializers.SerializerMethodField()
    
    site_details = TenderMasterNewSurveyMasterSiteDetailsSerializer(source="survey_site_details")
    facility_details = TenderMasterNewSurveyMasterFacilitySiteSerializer(source="survey_facility_site")
    climate_site_details = TenderMasterNewSurveyMasterClimateAtSiteSiteSerializer(source="survey_climate_site")
    hydrological_marine_details = TenderMasterNewSurveyMasterHydrologicalMarineConditionSerializer(source="survey_hydrology_marine_condition")
    topography_details = TenderMasterNewSurveyMasterTopographySerializer(source="survey_topography")
    geological_data_details = TenderMasterNewSurveyMasterGeologicalDataSerializer(source="survey_geological_data")
    local_issue_details = TenderMasterNewSurveyMasterLocalIssuesSerializer(source="survey_local_issues")
    material_details = TenderMasterNewSurveyMasterConstructionMaterialsSerializer(source="survey_construction_materials", many=True)
    sub_contractor_details = TenderMasterNewSurveyMasterSubContractorSerializer(source="survey_sub_contractor")
    labour_details = TenderMasterNewSurveyMasterLabourSerializer(source="survey_labour")
    fuel_details = TenderMasterNewSurveyMasterFuelSerializer(source="survey_fuel")
    accommodation_details = TenderMasterNewSurveyMasterAccommodationSerializer(source="survey_accommodation")
    temporary_setup_details = TenderMasterNewSurveyMasterTemporarySetupSerializer(source="survey_temporary_setup")
    taxes_duties_details = TenderMasterNewSurveyMasterTaxesDutiesSerializer(source="survey_taxes_duties")
    subcontractors_details = TenderMasterNewSurveyMasterSubcontractorsSerializer(source="survey_subcontractors")
    access_crossings_route_details = TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsSerializer(source="survey_access_crossings_route_details")
    waste_management_details = TenderMasterNewSurveyMasterWasteManagementSerializer(source="survey_waste_management")
    misc_details = TenderMasterNewSurveyMasterMiscSerializer(source="survey_waste_misc")
    reference_similar_projects_details = TenderMasterNewSurveyMasterReferenceSimilarProjectsSerializer(source="survey_reference_similar_projects")
    existing_utilities_details = TenderMasterNewSurveyMasterExistingUtilitiesSerializer(source="survey_existing_utilities")
    users_details = serializers.SerializerMethodField()
    approved_by_details = serializers.SerializerMethodField()
    rejected_by_details = serializers.SerializerMethodField()
    def get_approved_by_details(self, instance):
        details = None
        if instance.approved_by:
            details = []
            details.append({
                "first_name": instance.approved_by.first_name,
                "last_name": instance.approved_by.last_name,
                "email": instance.approved_by.email,
            })
        return details
    def get_users_details(self, instance):
        details = []
        for user in instance.users.all():
            details.append({
                "first_name": user.first_name,
                "last_name": user.last_name,
                "email": user.email,
            })
        return details

    def get_rejected_by_details(self, instance):
        details = None
        if instance.rejected_by:
            details = []
            details.append({
                "first_name": instance.rejected_by.first_name,
                "last_name": instance.rejected_by.last_name,
                "email": instance.rejected_by.email,
            })
        return details

    def get_tender_sector_name(self, instance):
        return instance.tender.sector.name if instance.tender and instance.tender.sector else ''

    def get_tender_state_name(self, instance):
        return instance.tender.state.name if instance.tender and instance.tender.state else ''

    def get_tender_department_name(self, instance):
        return instance.tender.department_name if instance.tender and instance.tender.department_name else ''

    def get_tender_organization_name(self, instance):
        return instance.tender.tender_organization.employee_name if instance.tender and instance.tender.tender_organization else ''

    def get_tender_details(self, instance):
        return get_details_from_instance(instance.tender) if instance.tender else {}

    class Meta:
        model = TenderMasterNewSurveyMaster
        fields = '__all__'

class TenderTrendAnalysisParticipantsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = TenderTrendAnalysisParticipants
        fields = '__all__'
        read_only_fields = ['id','trend_analysis']
        list_serializer_class = CommonFilterListSerializer

class TenderTrendAnalysisAttachmentsSerializer(serializers.ModelSerializer):
    """
    Trend Analysis Master Attachments Serializer 
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = TenderTrendAnalysisAttachments
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class TenderTrendAnalysisSerializer(serializers.ModelSerializer):
    participants_items = TenderTrendAnalysisParticipantsSerializer(many=True,required=False,
                                source='tender_trend_analysis_participants_trend_analysis' )
    attachments = TenderTrendAnalysisAttachmentsSerializer(
        many=True,
        required=False,
        source='tender_trend_analysis_attachment'
    )
    class Meta:
        model = TenderTrendAnalysis
        fields = '__all__'
        list_serializer_class = CommonFilterListSerializer
    @transaction.atomic
    def create(self, validated_data):
        participants_items_data = validated_data.pop('tender_trend_analysis_participants_trend_analysis', [])
        attachments_data = validated_data.pop('tender_trend_analysis_attachment', [])
        trend_analysis = TenderTrendAnalysis.objects.create(**validated_data)
        current_user = trend_analysis.created_by if trend_analysis.created_by else None
        for item_data in participants_items_data:
            TenderTrendAnalysisParticipants.objects.create(
                **item_data,
                trend_analysis=trend_analysis,
                created_by=current_user,
            )
        for attachment_data in attachments_data:
            processed_attachment = process_attachments(attachment_data)
            attachment_data.pop('mime_type', None)
            attachment_data.pop('file_data', None)
            TenderTrendAnalysisAttachments.objects.create(
                **attachment_data,
                trend_analysis=trend_analysis,
                attachment=processed_attachment if processed_attachment else None,
                created_by=current_user,
            )
        return trend_analysis
    
    @transaction.atomic
    def update(self, instance, validated_data):
        stages_data = validated_data.pop('tender_trend_analysis_participants_trend_analysis', [])
        attachments_data = validated_data.pop('tender_trend_analysis_attachment', [])
        for field in instance._meta.fields:
            field_name = field.name
            if field_name in validated_data:
                setattr(instance, field_name, validated_data[field_name])

        current_user = instance.updated_by if instance.updated_by else None
        existing_stages = instance.tender_trend_analysis_participants_trend_analysis.filter(is_deleted=False)
        existing_attachments = instance.tender_trend_analysis_attachment.filter(is_deleted=False)
        for item_data in stages_data:
            item_id = item_data.get('id')
            existing_item = next((item for item in existing_stages if item.id == item_id), None)

            if not existing_item:
                existing_item = TenderTrendAnalysisParticipants.objects.create(trend_analysis=instance, 
                                created_by=current_user, **item_data)
            else:
                for field in existing_item._meta.fields:
                    field_name = field.name
                    if field_name in item_data:
                        setattr(existing_item, field_name, item_data[field_name])
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()

        for existing_item in existing_stages:
            if existing_item.id not in [item_data.get('id') for item_data in stages_data]:
                setattr(existing_item, 'is_deleted', True)
                setattr(existing_item, 'updated_by', current_user)
                existing_item.save()


        for attachment_data in attachments_data:
            attachment_id = attachment_data.get('id')
            processed_attachment = process_attachments(attachment_data)
            existing_attachment = next((item for item in existing_attachments if item.id == attachment_id), None)
            if existing_attachment:
                for attr, value in attachment_data.items():
                    setattr(existing_attachment, attr, value)
                if processed_attachment:
                    existing_attachment.attachment = processed_attachment
                    existing_attachment.file_data=""
                    existing_attachment.mime_type=""
                existing_attachment.updated_by = current_user
                existing_attachment.save()
            else:
                attachment_data.pop('mime_type', None)
                attachment_data.pop('file_data', None)
                TenderTrendAnalysisAttachments.objects.create(
                    **attachment_data,
                    trend_analysis=instance,
                    attachment=processed_attachment if processed_attachment else None,
                    created_by=current_user,
                )

        instance.save()
        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['participants_items'] = representation.pop('participants_items', [])
        representation['attachments'] = representation.pop('attachments', [])
        return representation