import ast
import json
import logging
import threading
import copy

import pandas as pd
import numpy as np
from openpyxl import load_workbook
from functools import reduce
# from django.shortcuts import render
from rest_framework.views import APIView
from time import gmtime, strftime, localtime
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException
# from datetime import date
from datetime import datetime, timedelta, date
from django.db.models import Prefetch

from django.db.models import IntegerField, Q, Sum, Value, Count, CharField, Exists, BooleanField
from django.db.models.functions import Cast, Coalesce
from django.db.models.expressions import Subquery, OuterRef, Case, When
from procurement.helper import GroupConcat
from boq.helper import planning_tender_link
from django.db.models import fields
from administrations.utils import schedule_generic_mail , trigger_notifications
from user_permissions.models import UserWiseModulePermissions
from django.db import transaction, IntegrityError
from django.db.models import F, Value
from django.db.models.functions import Trim, Replace
from django.db.models.functions import Concat
# from .models import *
from .serializers import *
from .helper import *
import re
from custom_management.models import *

from colorama import Fore, Back, Style
from procurement.helper import custom_filters, process_filters_response, rcv_process_attachments
from django.db.models.functions import Lower
from django.utils import timezone
from email_config.utils import *
from django.db.models import F, ExpressionWrapper, DurationField, IntegerField
from django.db.models.functions import Now, TruncDate

# Create your views here.

class TenderMasterWorkFlowAPIView(APIView):
    
    

    def get(self, request, *args, **kwargs):
        organization_id = self.request.query_params.get('organization_id')
        tenders = TenderWorkFlow.cmobjects.filter(organization_id=organization_id)
        role_dict = {}

        # Create a dictionary of roles, with the role id as the key and the role object as the value
        for role in tenders:
            role_dict[role.id] = role

        # Create a dictionary of child roles, with the parent role id as the key and a list of child role ids as the value
        child_roles_dict = {}
        for role in tenders:
            parent_id = role.parent_id
            if parent_id in child_roles_dict:
                child_roles_dict[parent_id].append(role.id)
            else:
                child_roles_dict[parent_id] = [role.id]

        # Create the tree structure
        tree = []
        for role in tenders:
            if role.parent_id == 0:
                node = self.get_node(role, role_dict, child_roles_dict)
                tree.append(node)

        return Response(tree)

    def get_node(self, role, role_dict, child_roles_dict):
        notifications_list = TenderNotifications.cmobjects.filter(tender_id=role.id).values('id', 'notification_type', \
                                                                                            'trigger_type', 'date')
        event_list = TenderEvents.cmobjects.filter(tender_id=role.id).values('id', 'event_name', \
                                                                                'start_hour', 'end_hour',\
                                                                                    'status','priority')
        node = {
            "id": role.id,
            "step_name": role.step_name,
            "reverse_id": role.reverse_id,
            "action_type": role.action_type,
            'notifications_list' : notifications_list,
            "event_list" : event_list,
            "children": []
        }

        if role.id in child_roles_dict:
            child_ids = child_roles_dict[role.id]
            for child_id in child_ids:
                child = role_dict[child_id]
                #if not child.is_deleted: # Check if the child role is not deleted
                child_node = self.get_node(child, role_dict, child_roles_dict)
                node["children"].append(child_node)

        return node
    

class TenderNotificationsAPIView(APIView):
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender notifications
        """
        id = self.request.query_params.get('id', None)
        if id:
            noti_list = TenderNotifications.cmobjects.filter(id = id).first()
            serializer = TenderNotificationsSerializer(noti_list)
            return Response(serializer.data)

        organization_id = self.request.query_params.get('organization_id', None)
        noti_list = TenderNotifications.cmobjects.filter(organization_id = organization_id).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(noti_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        serializer = TenderNotificationsSerializer(page, many=True)
        # serializer = CompanySerializer(company_list, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)
            title = request.data.get('title', None)
            tender_id = request.data.get('tender_id', None)
            email_template_id = request.data.get('email_template_id', None)
            sms_template_id = request.data.get('sms_template_id', None)
            notification_type = request.data.get('notification_type', None)
            trigger_type = request.data.get('trigger_type', None)
            date = request.data.get('date', None)
            to = request.data.get('to', [])
            cc = request.data.get('cc', [])
            sms_to = request.data.get('sms_to', [])


            with transaction.atomic(): 
                
                created = TenderNotifications.objects.create(organization_id=organization_id, tender_id = tender_id, title=title, email_template_id=email_template_id, \
                                                    sms_template_id=sms_template_id, notification_type=notification_type, trigger_type=trigger_type,\
                                                        date=date, created_by=request.user)
                created.save()

                if to:
                    to_user_list = PmsUser.objects.filter(id__in=to)
                    for to_item in to_user_list:
                        created.to.add(to_item)
                        created.save()

                if cc:
                    cc_user_list = PmsUser.objects.filter(id__in=cc)
                    for cc_item in cc_user_list:
                        created.cc.add(cc_item)
                        created.save()

                if sms_to:
                    sms_to_user_list = PmsUser.objects.filter(id__in=sms_to)
                    for sms_to_item in sms_to_user_list:
                        created.sms_to.add(sms_to_item)
                        created.save()

                

                serializer = TenderNotificationsSerializer(created)

                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Notification Added SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)


        with transaction.atomic():
            if method.lower() == 'edit':

                tender_id = request.data.get('tender_id', None)
                title = request.data.get('title', None)
                email_template_id = request.data.get('email_template_id', None)
                sms_template_id = request.data.get('sms_template_id', None)
                notification_type = request.data.get('notification_type', None)
                trigger_type = request.data.get('trigger_type', None)
                date = request.data.get('date', None)
                to = request.data.get('to', [])
                cc = request.data.get('cc', [])
                sms_to = request.data.get('sms_to', [])

                noti_details = TenderNotifications.cmobjects.filter(pk=id).first()
                
                if not noti_details:
                    return Response({'results': [],
                                    'msg': "Selected Tender Notifications Does'nt exists!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                
                noti_details.tender_id = tender_id
                noti_details.email_template_id = email_template_id
                noti_details.sms_template_id = sms_template_id
                noti_details.title = title
                noti_details.notification_type = notification_type
                noti_details.trigger_type = trigger_type
                noti_details.date = date
                noti_details.updated_by = request.user
                noti_details.save()

                
                if noti_details.to:
                    #to_user_list_delete = PmsUser.objects.filter(id__in=noti_details.to)
                    for to_item in noti_details.to.all():
                        noti_details.to.remove(to_item)
                        noti_details.save()

                if noti_details.cc:
                    #cc_user_list_delete = PmsUser.objects.filter(id__in=noti_details.cc)
                    for cc_item in noti_details.cc.all():
                        noti_details.to.remove(cc_item)
                        noti_details.save()

                if noti_details.sms_to:
                    #sms_to_user_list_delete = PmsUser.objects.filter(id__in=noti_details.sms_to)
                    for sms_to_item in noti_details.sms_to.all():
                        noti_details.to.remove(sms_to_item)
                        noti_details.save()
                
                if to:
                    to_user_list = PmsUser.objects.filter(id__in=to)
                    for to_item in to_user_list:
                        noti_details.to.add(to_item)
                        noti_details.save()

                if cc:
                    cc_user_list = PmsUser.objects.filter(id__in=cc)
                    for cc_item in cc_user_list:
                        noti_details.cc.add(cc_item)
                        noti_details.save()

                if sms_to:
                    sms_to_user_list = PmsUser.objects.filter(id__in=sms_to)
                    for sms_to_item in sms_to_user_list:
                        noti_details.sms_to.add(sms_to_item)
                        noti_details.save()

                form_details = TenderNotifications.cmobjects.filter(id=id).first()

                serializer = TenderNotificationsSerializer(form_details)

                return Response({'results':{
                                        'Data':serializer.data,
                                        },
                                        'msg': 'Notifications Updated SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
            
            elif method.lower() == 'delete':
                """
                Delete a Organisation role
                """
                if TenderNotifications.cmobjects.filter(id=id, organization_id=organization_id).exists():
                    form_details = TenderNotifications.cmobjects.filter(id=id, organization=organization_id).first()
                    form_details.is_deleted = True
                    form_details.save()
                    
                    return Response({'results':{
                                        'form_details':TenderNotifications.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Selected Tender Notifications Deleted Successfully',
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Selected Tender Notifications Does'nt exists!",
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
                



class TenderEventsAPIView(APIView):
    
    


    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender notifications
        """
        id = self.request.query_params.get('id', None)
        if id:
            event_details = TenderEvents.cmobjects.filter(id = id).first()
            serializer = TenderEventsSerializer(event_details)
            return Response(serializer.data)

        organization_id = self.request.query_params.get('organization_id', None)
        event_list = TenderEvents.cmobjects.filter(organization_id = organization_id).order_by('-id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(event_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        serializer = TenderEventsSerializer(page, many=True)
        # serializer = CompanySerializer(company_list, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)
            tender_id = request.data.get('tender_id', None)
            event_type = request.data.get('event_type', None)
            event_name = request.data.get('event_name', None)
            event_descriptions = request.data.get('event_descriptions', None)
            event_trigger_type = request.data.get('event_trigger_type', None)
            start_hour = request.data.get('start_hour', None)
            end_hour = request.data.get('end_hour', None)
            status_event = request.data.get('status', None)
            assignees = request.data.get('assignees', [])
            priority = request.data.get('priority', None)
            notify_assignee = request.data.get('notify_assignee', None)
            remind_assignee = request.data.get('remind_assignee', None)
            send_reminder_in_hours = request.data.get('send_reminder_in_hours', None)
            #### For CONFIRMATION Event Type #############
            #confirmed_by = request.data.get('confirmed_by_id', True)
            level_user = request.data.get('level_user', [])

            #### For Email and SMS ########################
            cc_to = request.data.get('cc_to', [])
            event_notification_type = request.data.get('event_notification_type', None)
            email_template_id = request.data.get('email_template_id', None)
            sms_template_id = request.data.get('sms_template_id', None)


            if notify_assignee and notify_assignee == 'True':
                n_assignee = True
            else:
                n_assignee = False

            if remind_assignee and remind_assignee == 'True':
                r_assignee = True
            else:
                r_assignee = False


            with transaction.atomic(): 

                if TenderEvents.cmobjects.filter(event_name=event_name.strip(),          # validate existing tender name
                            organization_id=organization_id, tender_id=tender_id).exists():
                    raise APIException({'request_status': 0, 'msg': "Tender event with same name already exist for the selected tender"})
                
                created = TenderEvents.objects.create(organization_id=organization_id, tender_id = tender_id, event_type=event_type, event_name=event_name, \
                                                    event_descriptions=event_descriptions, start_hour=start_hour, end_hour=end_hour,\
                                                        status=status_event, priority=priority, notify_assignee=n_assignee, \
                                                            remind_assignee=r_assignee, created_by=request.user, event_trigger_type=event_trigger_type,\
                                                                confirmed_by=request.user, event_notification_type=event_notification_type, email_template_id=email_template_id,\
                                                                    sms_template_id=sms_template_id, send_reminder_in_hours=send_reminder_in_hours)
                created.save()

                if assignees:
                    assignees_user_list = PmsUser.objects.filter(id__in=assignees)
                    for to_item in assignees_user_list:
                        created.assignees.add(to_item)
                        created.save()

                if cc_to:
                    cc_to_user_list = PmsUser.objects.filter(id__in=cc_to)
                    for item in cc_to_user_list:
                        created.cc_to.add(item)
                        created.save()

                if level_user:
                    for obj in level_user:
                        user_id = obj.get('level_user_id', None)
                        level_count = obj.get('level_count', None)
                        obj_created = TenderEventsLevel.objects.create(organization_id=organization_id, tender_events=created,\
                                                                       level_user_id=user_id, level_count=level_count, created_by=request.user)
                        obj_created.save()

                serializer = TenderEventsSerializer(created)

                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Tender Event Added SuccessFully For the Selected Tender',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        
    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)


        with transaction.atomic():
            if method.lower() == 'edit':

                tender_id = request.data.get('tender_id', None)
                event_type = request.data.get('event_type', None)
                event_name = request.data.get('event_name', None)
                event_descriptions = request.data.get('event_descriptions', None)
                event_trigger_type = request.data.get('event_trigger_type', None)
                start_hour = request.data.get('start_hour', None)
                end_hour = request.data.get('end_hour', None)
                status_event = request.data.get('status', None)
                assignees = request.data.get('assignees', [])
                priority = request.data.get('priority', None)
                notify_assignee = request.data.get('notify_assignee', None)
                remind_assignee = request.data.get('remind_assignee', None)
                send_reminder_in_hours = request.data.get('send_reminder_in_hours', None)
                #### For CONFIRMATION Event Type #############
                #confirmed_by = request.data.get('confirmed_by_id', True)
                level_user = request.data.get('level_user', [])

                #### For Email and SMS ########################
                cc_to = request.data.get('cc_to', [])
                event_notification_type = request.data.get('event_notification_type', None)
                email_template_id = request.data.get('email_template_id', None)
                sms_template_id = request.data.get('sms_template_id', None)

                event_details = TenderEvents.cmobjects.filter(pk=id).first()


                if notify_assignee and notify_assignee == 'True':
                    n_assignee = True
                else:
                    n_assignee = False

                if remind_assignee and remind_assignee == 'True':
                    r_assignee = True
                else:
                    r_assignee = False
                
                if not event_details:
                    return Response({'results': [],
                                    'msg': "Selected Tender Event Does'nt exists!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                
                if TenderEvents.cmobjects.filter(event_name=event_name.strip(),          # validate existing tender name
                            organization_id=organization_id, tender_id=tender_id).exclude(\
                                event_name=event_details.event_name.strip()).exists():
                    raise APIException({'request_status': 0, 'msg': "Tender event with same name already exist for the selected tender"})
                
                event_details.tender_id = tender_id
                event_details.event_type = event_type
                event_details.event_name = event_name
                event_details.event_descriptions = event_descriptions
                event_details.start_hour = start_hour
                event_details.end_hour = end_hour
                event_details.status = status_event
                event_details.priority = priority
                event_details.notify_assignee = n_assignee
                event_details.remind_assignee = r_assignee
                event_details.send_reminder_in_hours = send_reminder_in_hours
                event_details.event_trigger_type = event_trigger_type
                event_details.event_notification_type = event_notification_type
                event_details.email_template_id = email_template_id
                event_details.sms_template_id = sms_template_id
                event_details.updated_by = request.user
                event_details.save()

                TenderEventsLevel.objects.filter(tender_events_id=event_details.id).delete()
                
                if event_details.assignees:
                    #to_user_list_delete = PmsUser.objects.filter(id__in=noti_details.to)
                    for to_item in event_details.assignees.all():
                        event_details.assignees.remove(to_item)
                        event_details.save()
                
                if assignees:
                    to_user_list = PmsUser.objects.filter(id__in=assignees)
                    for to_item in to_user_list:
                        event_details.assignees.add(to_item)
                        event_details.save()

                if event_details.cc_to:
                    #to_user_list_delete = PmsUser.objects.filter(id__in=noti_details.to)
                    for item in event_details.cc_to.all():
                        event_details.cc_to.remove(item)
                        event_details.save()

                if cc_to:
                    cc_to_user_list = PmsUser.objects.filter(id__in=cc_to)
                    for item in cc_to_user_list:
                        event_details.cc_to.add(item)
                        event_details.save()

                if level_user:
                    for obj in level_user:
                        user_id = obj.get('level_user_id', None)
                        level_count = obj.get('level_count', None)
                        obj_created = TenderEventsLevel.objects.create(organization_id=organization_id, tender_events=event_details,\
                                                                       level_user_id=user_id, level_count=level_count, \
                                                                        created_by=request.user, updated_by=request.user)
                        obj_created.save()


                event = TenderEvents.cmobjects.filter(id=id).first()

                serializer = TenderEventsSerializer(event)

                return Response({'results':{
                                        'Data':serializer.data,
                                        },
                                        'msg': 'Event Updated SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
            
            elif method.lower() == 'delete':
                """
                Delete a Organisation Tender Event
                """
                if TenderEvents.cmobjects.filter(id=id, organization_id=organization_id).exists():
                    form_details = TenderEvents.cmobjects.filter(id=id, organization=organization_id).first()
                    form_details.is_deleted = True
                    form_details.save()
                    
                    return Response({'results':{
                                        'form_details':TenderEvents.objects.filter(pk=id,organization=organization_id).values(),
                                        },
                                        'msg': 'Selected Tender Event Deleted Successfully',
                                        "request_status": 1})
                else:
                    return Response({'results': [],
                                    'msg': "Selected Tender Event Does'nt exists!",
                                    'status': status.HTTP_404_NOT_FOUND,
                                    "request_status": 0})
                


class TenderBidderAPIView(APIView):
    """ Tender BIdder API View """
    
    
    
    def post(self, request, format=None):
        try:
            organization_id = request.data.get('organization', None)
            tender_id = request.data.get('tender', None)
            form_id = request.data.get('form', None)
            value_character = request.data.get('value_character', None)
            value_interger = request.data.get('value_interger', None)
            document = request.data.get('document', None)



            with transaction.atomic(): 
                
                created = TenderBidder.objects.create(organization_id=organization_id, tender_id = tender_id, \
                                                      form_id=form_id, value_character=value_character, \
                                                        value_interger=value_interger,  document=document, created_by=request.user)
                created.save()

                serializer = TenderBidderSerializer(created)

                return Response({'results':{
                                        'Data':serializer.data ,
                                        },
                                        'msg': 'Tender Bidder Added SuccessFully For the Selected Tender',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


    def put(self, request, *args, **kwargs):
        """
            Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':

                tender_id = request.data.get('tender_id', None)
                organization_id = request.data.get('organization_id', None)
                form_id = request.data.get('form_id', None)
                value_character = request.data.get('value_character', None)
                value_interger = request.data.get('value_interger', None)
                document = request.data.get('document', None)

                bidder_details = TenderBidder.cmobjects.filter(pk=id).first()

                if not bidder_details:
                    return Response({'results': [],
                                    'msg': "Selected Tender Bidder Does'nt exists!",
                                    "request_status": 0}, status=status.HTTP_400_BAD_REQUEST)
                
                bidder_details.tender_id = tender_id
                bidder_details.organization_id = organization_id
                bidder_details.form_id = form_id
                bidder_details.value_character = value_character
                bidder_details.value_interger = value_interger
                bidder_details.document = document

                bidder_details.save()

                tender_bidder = TenderBidder.cmobjects.filter(id=id).first()

                serializer = TenderBidderSerializer(tender_bidder)

                return Response({'results':{
                                        'Data':serializer.data,
                                        },
                                        'msg': 'Tender Bidder Updated SuccessFully',
                                        'status':status.HTTP_200_OK,
                                        "request_status": 0})
            

 


class TenderSurveyDetailsAPI(APIView):
    """ Tender Master API View """

    
    

    def get(self, request, *args, **kwargs):
        """
        Get Survey Details Noted From Serializer Data
        """
        id = self.request.query_params.get('id', None)

        tender_list = TenderMaster.cmobjects.filter(id = id).first()
        serializer = TenderSurveySerializer(tender_list)

        return Response(serializer.data)


class TenderMasterAPI(APIView):
    """ Tender Master API View """

    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender notifications
        """
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        form_menu_type = self.request.query_params.get('form_menu_type', None)
        form_group_id = self.request.query_params.get('form_group_id', None)

        tender_type = self.request.query_params.get('tender_type', None)

        list_type = self.request.query_params.get('list', None)

        is_paginated = self.request.query_params.get('is_paginated', 0)
        
        tender_status = self.request.query_params.get('tender_status', 0)

        jv_id = self.request.query_params.get('jv_id', 0)

        employee_id = self.request.query_params.get('employee_id', 0)

        survey = self.request.query_params.get('survey', None)

        survey_status = self.request.query_params.get('survey_status', None)

        order_by = self.request.query_params.get('order_by', None)
        is_archived = self.request.query_params.get('is_archived', 'false')
        status = self.request.query_params.get('status', None)

        tender_title = "Tender List"

        if id:
            tender_list = TenderMaster.cmobjects.filter(id = id).first()
            if form_menu_type and form_group_id:
                serializer = TenderMasterSerializer(tender_list, context = {"organization_id": organization_id,\
                                                                            "form_menu_type" : form_menu_type, \
                                                                                "form_group_id" : form_group_id,\
                                                                                    "list_type" : list_type,\
                                                                                        "user_id" : request.user.id})
            elif form_menu_type:
                serializer = TenderMasterSerializer(tender_list, context = {"organization_id": organization_id,\
                                                                            "form_menu_type" : form_menu_type,\
                                                                                    "list_type" : list_type,\
                                                                                        "user_id" : request.user.id})
            elif form_group_id:
                serializer = TenderMasterSerializer(tender_list, context = {"organization_id": organization_id,\
                                                                            "form_group_id" : form_group_id,\
                                                                                    "list_type" : list_type,\
                                                                                        "user_id" : request.user.id})
            else:
                serializer = TenderMasterSerializer(tender_list, context = {"organization_id": organization_id,\
                                                                                    "list_type" : list_type})
            detail_serializer = TenderMasterSerializer(tender_list, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True,\
                                                                                        "user_id" : request.user.id})

            return Response({
                'results': serializer.data,
                # 'Data':detail_serializer.data,
            })
        

        
        if tender_type == 'all':
            tender_list = TenderMaster.cmobjects.filter(organization_id = organization_id).order_by('-id')
            tender_title = "Tender List"

        elif tender_type == 'not_applicable':

            not_applicable_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='participations_mode', \
                                                               option__in=['Standalone','JV']).values_list('id', flat=True))
        
            not_applicable_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='participations_mode', \
                                                        value__in=not_applicable_ids).values_list('tender_id', flat=True))

            tender_list = TenderMaster.cmobjects.filter(\
                organization_id=organization_id).exclude(\
                    id__in=not_applicable_tender_ids).order_by('-id')
            
            tender_title = "Identified Tender List"
            

        elif tender_type == 'single':

            drop_ids = list(FormDropdownChoices.objects.filter(option="Standalone").values_list('id', flat=True))
            tender_ids = list(TenderData.objects.annotate(values_int=Cast('value', IntegerField())).filter(\
                form__form_internal_name="participations_mode", values_int__in=drop_ids).values_list('tender_id', flat=True))
            
            tender_list = TenderMaster.cmobjects.filter(organization_id = organization_id, \
                                                        id__in=tender_ids).order_by('-id')
            
            tender_title = "Stand Alone Tender List"
            
        elif tender_type == 'participated_single':

            drop_ids = list(FormDropdownChoices.objects.filter(option="Standalone").values_list('id', flat=True))
            tender_ids = list(TenderData.objects.annotate(values_int=Cast('value', IntegerField())).filter(\
                form__form_internal_name="participations_mode", values_int__in=drop_ids).values_list('tender_id', flat=True))
            
            tender_list = TenderMaster.cmobjects.filter(Q(organization_id = organization_id), \
                                                        Q(id__in=tender_ids), Q(is_sent_for_approval=True) |\
                                                            Q(is_approved=True)).exclude(is_reject=True).order_by('-id')
            
            tender_title = "Stand Alone Participated Tender List"
            
        elif tender_type == 'technical_single':

            drop_ids = list(FormDropdownChoices.objects.filter(option="Standalone").values_list('id', flat=True))
            participated_tender_ids = list(TenderData.objects.annotate(values_int=Cast('value', IntegerField())).filter(\
                form__form_internal_name="participations_mode", values_int__in=drop_ids).values_list('tender_id', flat=True))
            



            dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='technically_opened_tender_final', \
                                                               option='Yes').values_list('id', flat=True))
        
            technical_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='technically_opened_tender_final', \
                                                      value__in=dropdown_ids).values_list('tender_id', flat=True))
            
            from tender_eligibility.views import common_list
            
            common_technical_ids = common_list(participated_tender_ids,technical_tender_ids)
            
            tender_list = TenderMaster.cmobjects.filter(id__in=common_technical_ids).exclude(is_reject=True).order_by('-id')

            tender_title = "Stand Alone Technically Opened Tender List"

        elif tender_type == 'financial_single':

            drop_ids = list(FormDropdownChoices.objects.filter(option="Standalone").values_list('id', flat=True))
            participated_tender_ids = list(TenderData.objects.annotate(values_int=Cast('value', IntegerField())).filter(\
                form__form_internal_name="participations_mode", values_int__in=drop_ids).values_list('tender_id', flat=True))

            dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='financially_opened_tender_final', \
                                                               option='Yes').values_list('id', flat=True))
        
            financial_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='financially_opened_tender_final', \
                                                      value__in=dropdown_ids).values_list('tender_id', flat=True))
            
            from tender_eligibility.views import common_list
            
            common_financial_ids = common_list(participated_tender_ids,financial_tender_ids)
            
            tender_list = TenderMaster.cmobjects.filter(id__in=common_financial_ids).exclude(is_reject=True).order_by('-id')

            tender_title = "Stand Alone Financially Opened Tender List"

        elif tender_type == 'l1_single':

            drop_ids = list(FormDropdownChoices.cmobjects.filter(option="Standalone").values_list('id', flat=True))

            tender_data2 = TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
                                                            form__form_internal_name="participations_mode", \
                                                                tender__organization_id=organization_id, \
                                                                    values_int__in=drop_ids)
       
            tender_ids = list(tender_data2.values_list('tender_id', flat=True))

            all_tender_l1_ids = list(TenderData.cmobjects.filter(form__form_internal_name="selected_as_l1", \
                                                            value='true').values_list('tender_id', flat=True))
            from tender_eligibility.views import common_list
            
            common_standalone_j1_ids = common_list(tender_ids, all_tender_l1_ids)
            
            tender_list = TenderMaster.cmobjects.filter(id__in=common_standalone_j1_ids).exclude(is_reject=True).order_by('-id')

            tender_title = "Stand Alone L1 Tender List"

        

        elif int(jv_id) == 0 and tender_type == 'jv':

            option_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='party_name').values_list('option_id', flat=True))
        
            # jv_tender_ids = list(TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
            #                                         form__form_internal_name='party_name', \
            #                                           values_int__in=option_ids).values_list('tender_id', flat=True))
            
            jv_tender_ids = []

            tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='party_name')

            for item in tender_data_list:
                try:
                    res = ast.literal_eval(item.value)
                except Exception as ex:
                    res = []
                for obj in res:
                    if obj in option_ids:
                        jv_tender_ids.append(item.tender_id)
            
            tender_list = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                    id__in=jv_tender_ids).order_by('-id')
            
            tender_title = "Joint Venture Tender List"

        

        elif int(jv_id) > 0 and tender_type == 'jv':

            jv_master_details = JVMASTER.objects.filter(id=int(jv_id)).first()

            option_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='party_name', \
                                                               option_id=jv_id).values_list('option_id', flat=True))
        
            # jv_tender_ids = list(TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
            #                                         form__form_internal_name='party_name', \
            #                                           values_int__in=option_ids).values_list('tender_id', flat=True))
            
            jv_tender_ids = []

            tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='party_name')

            for item in tender_data_list:
                try:
                    res = ast.literal_eval(item.value)
                except Exception as ex:
                    res = []
                for obj in res:
                    if obj in option_ids:
                        jv_tender_ids.append(item.tender_id)
            
            tender_list = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                    id__in=jv_tender_ids).order_by('-id')
            
            tender_title = "Joint Venture Tender List For " + str(jv_master_details.party_name)
            
        elif jv_id and tender_type == 'participated_jv':

            jv_master_details = JVMASTER.objects.filter(id=int(jv_id)).first()

            jv_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='party_name', \
                                                               option_id=jv_id).values_list('option_id', flat=True))
        
            # jv_tender_ids = list(TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
            #                                         form__form_internal_name='party_name', \
            #                                           values_int__in=jv_ids).values_list('tender_id', flat=True))
            
            jv_tender_ids = []

            tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='party_name')

            for item in tender_data_list:
                try:
                    res = ast.literal_eval(item.value)
                except Exception as ex:
                    res = []
                for obj in res:
                    if obj in jv_ids:
                        jv_tender_ids.append(item.tender_id)

            tender_list = TenderMaster.cmobjects.filter(Q(organization_id = organization_id), \
                                                        Q(id__in=jv_tender_ids), Q(is_sent_for_approval=True) |\
                                                            Q(is_approved=True)).exclude(is_reject=True)
            
            tender_title = "Joint Venture Participated Tender List For " + str(jv_master_details.party_name)

        elif jv_id and tender_type == 'technical_open_jv':

            jv_master_details = JVMASTER.objects.filter(id=int(jv_id)).first()

            jv_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='party_name', \
                                                               option_id=jv_id).values_list('option_id', flat=True))
        
            # jv_tender_ids = list(TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
            #                                         form__form_internal_name='party_name', \
            #                                           values_int__in=jv_ids).values_list('tender_id', flat=True))
            
            jv_tender_ids = []

            tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='party_name')

            for item in tender_data_list:
                try:
                    res = ast.literal_eval(item.value)
                except Exception as ex:
                    res = []
                for obj in res:
                    if obj in jv_ids:
                        jv_tender_ids.append(item.tender_id)
            
            tender_list_participated_id = list(TenderMaster.cmobjects.filter(Q(organization_id = organization_id), \
                                                        Q(id__in=jv_tender_ids), Q(is_sent_for_approval=True) |\
                                                            Q(is_approved=True)).exclude(is_reject=True).values_list('id', flat=True))
            
            dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='technically_opened_tender_final', \
                                                                option='Yes').values_list('id', flat=True))
            
            technical_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='technically_opened_tender_final', \
                                                        value__in=dropdown_ids).values_list('tender_id', flat=True))
            
            from tender_eligibility.views import common_list

            common_technical_ids = common_list(tender_list_participated_id,technical_tender_ids)

            tender_list = TenderMaster.cmobjects.filter(id__in=common_technical_ids).exclude(is_reject=True)
            
            tender_title = "Joint Venture Technically Opened Tender List For " + str(jv_master_details.party_name)

        elif jv_id and tender_type == 'financial_open_jv':

            jv_master_details = JVMASTER.objects.filter(id=int(jv_id)).first()

            jv_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='party_name', \
                                                               option_id=jv_id).values_list('option_id', flat=True))
        
            # jv_tender_ids = list(TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
            #                                         form__form_internal_name='party_name', \
            #                                           values_int__in=jv_ids).values_list('tender_id', flat=True))
            
            jv_tender_ids = []

            tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='party_name')

            for item in tender_data_list:
                try:
                    res = ast.literal_eval(item.value)
                except Exception as ex:
                    res = []
                for obj in res:
                    if obj in jv_ids:
                        jv_tender_ids.append(item.tender_id)
            
            tender_list_participated_id = list(TenderMaster.cmobjects.filter(Q(organization_id = organization_id), \
                                                        Q(id__in=jv_tender_ids), Q(is_sent_for_approval=True) |\
                                                            Q(is_approved=True)).exclude(is_reject=True).values_list('id', flat=True))
            
            dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='financially_opened_tender_final', \
                                                                option='Yes').values_list('id', flat=True))
            
            financial_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='financially_opened_tender_final', \
                                                        value__in=dropdown_ids).values_list('tender_id', flat=True))
            
            from tender_eligibility.views import common_list

            common_financial_ids = common_list(tender_list_participated_id,financial_tender_ids)

            tender_list = TenderMaster.cmobjects.filter(id__in=common_financial_ids).exclude(is_reject=True)
            
            tender_title = "Joint Venture Financially Opened Tender List For " + str(jv_master_details.party_name)


        elif jv_id and tender_type == 'l1_jv':

            jv_master_details = JVMASTER.objects.filter(id=int(jv_id)).first()

            jv_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='party_name', \
                                                               option_id=jv_id).values_list('option_id', flat=True))
        
            # jv_tender_ids = list(TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
            #                                         form__form_internal_name='party_name', \
            #                                           values_int__in=jv_ids).values_list('tender_id', flat=True))
            
            jv_tender_ids = []

            tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='party_name')

            for item in tender_data_list:
                try:
                    res = ast.literal_eval(item.value)
                except Exception as ex:
                    res = []
                for obj in res:
                    if obj in jv_ids:
                        jv_tender_ids.append(item.tender_id)
            
            all_tender_l1_ids = list(TenderData.cmobjects.filter(form__form_internal_name="selected_as_l1", \
                                                            value='true').values_list('tender_id', flat=True))
            
            from tender_eligibility.views import common_list

            common_l1_ids = common_list(jv_tender_ids,all_tender_l1_ids)

            tender_list = TenderMaster.cmobjects.filter(id__in=common_l1_ids).exclude(is_reject=True)
            
            tender_title = "Joint Venture L1 Selected Tender List For " + str(jv_master_details.party_name)


        elif employee_id:
            
            employee_details = EMPLOYEEMASTER.cmobjects.filter(id=int(employee_id)).first()

            employee_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='employer', \
                                                               option_id=employee_id).values_list('id', flat=True))
            
            employee_tender_ids = list(TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
                                                    form__form_internal_name='employer', \
                                                      values_int__in=employee_ids).values_list('tender_id', flat=True))
            
            tender_list = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                    id__in=employee_tender_ids).order_by('-id')

            tender_title = "Tender List For " + str(employee_details.employee_name)
            
        else:
            tender_list = TenderMaster.cmobjects.filter(organization_id = organization_id).order_by('-id')
            tender_title = "Tender List"

        if tender_status == 'selected_as_l1':
            tender_list = tender_list.filter(Q(is_l1=True) | Q(is_l1_complete = True)).order_by('-id')
        elif tender_status == 'not_selected_as_l1':
            tender_list = tender_list.filter(Q(is_not_l1=True) | Q(is_not_l1_complete = True)).order_by('-id')
        elif tender_status == 'tender_submitted':
            tender_list = tender_list.filter(is_submission_complete=True, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'approved':
            tender_list = tender_list.filter(is_approved=True, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'rejected':
            tender_list = tender_list.filter(is_reject=True, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'tender_is_send_for_approval':
            tender_list = tender_list.filter(is_sent_for_final_approval=True, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'survey_completed':
            tender_list = tender_list.filter(is_survey_complete=True, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'survey_started_and_in_progress':
            tender_list = tender_list.filter(is_survey_started=True, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'members_assigned_for_survey':
            tender_list = tender_list.filter(is_assignment_complete=True, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'vga_done':
            tender_list = tender_list.filter(is_vga_approved=True, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'vga_rejected':
            tender_list = tender_list.filter(is_vga_reject=True, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'recommended_and_waiting_for_approval':
            tender_list = tender_list.filter(is_sent_for_approval=True, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'recommended':
            tender_list = tender_list.filter(is_recommended=True, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'proposed_but_not_recommended':
            tender_list = tender_list.filter(is_sent_for_recommendation=True, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'proposed':
            tender_list = tender_list.filter(is_eligibility_complete_for_proposer=True, is_sent_for_recommendation=False, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        elif tender_status == 'identified':
            tender_list = tender_list.filter(is_eligibility_complete_for_proposer=False, is_sent_for_recommendation=False, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False).order_by('-id')
        else:
            tender_list = tender_list
        
        if status:
            tender_list = tender_list.filter(status=status).order_by('-id')


        if survey:
            user_id = request.user.id

            tender_ids = []

            dependent_form_id = FormDependentChoices.cmobjects.filter(option_id=user_id, \
                                                                      form__form_internal_name='select_members').first()
            
            
            tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='select_members')

            for item in tender_data_list:
                form_ids = ast.literal_eval(item.value)
                if dependent_form_id and dependent_form_id.id in form_ids:
                    tender_ids.append(item.tender_id)

            # For Material rate Users
            material_rate_form_id = FormDependentChoices.cmobjects.filter(option_id=user_id, \
                                                                        form__form_internal_name='select_members_material').first()
            
            material_rate_tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='select_members_material')

            for mat in material_rate_tender_data_list:
                form_ids = ast.literal_eval(mat.value)
                if material_rate_form_id and material_rate_form_id.id in form_ids:
                    tender_ids.append(mat.tender_id)

            
            # For Statutory and Taxation Users
            taxation_form_id = FormDependentChoices.cmobjects.filter(option_id=user_id, \
                                                                        form__form_internal_name='select_members_taxation').first()
            
            taxation_tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='select_members_taxation')

            for tax in taxation_tender_data_list:
                form_ids = ast.literal_eval(tax.value)
                if taxation_form_id and taxation_form_id.id in form_ids:
                    tender_ids.append(tax.tender_id)


            # For Admin and Liasoning Users
            admin_form_id = FormDependentChoices.cmobjects.filter(option_id=user_id, \
                                                                        form__form_internal_name='select_members_liason').first()
            
            admin_tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='select_members_liason')

            for admin in admin_tender_data_list:
                form_ids = ast.literal_eval(admin.value)
                if admin_form_id and admin_form_id.id in form_ids:
                    tender_ids.append(admin.tender_id)

            if survey_status:
                if survey_status == "due":
                    tender_list = TenderMaster.cmobjects.filter(organization_id = organization_id,\
                                                                id__in=tender_ids, is_survey_active=True,\
                                                                    is_survey_started=False, \
                                                                        is_survey_complete=False).order_by('-id')
                elif survey_status == "in_progress":
                    tender_list = TenderMaster.cmobjects.filter(organization_id = organization_id,\
                                                                id__in=tender_ids, is_survey_started=True, \
                                                                    is_survey_complete=False).order_by('-id')
                elif survey_status == "completed":
                    tender_list = TenderMaster.cmobjects.filter(organization_id = organization_id,\
                                                                id__in=tender_ids, is_survey_complete=True).order_by('-id')
                else:
                    tender_list = TenderMaster.cmobjects.filter(organization_id = organization_id,\
                                                                id__in=tender_ids).order_by('-id')
            else:
                tender_list = TenderMaster.cmobjects.filter(organization_id = organization_id,\
                                                                id__in=tender_ids).order_by('-id')
                
        else:
            tender_list = tender_list

        search = self.request.query_params.get('search', None)

        existing_keys = ['organization_id','id','form_menu_type','form_group_id','tender_type','list','is_paginated',\
                             'tender_status','jv_id','employee_id','survey','survey_status','search','page_size','page','order_by','status']


        search_tender_ids = []

        if search == 'true':
            # search_tender_ids.clear()
            for key,value in request.query_params.items():
                if not key in existing_keys:
                    form_details = FormMaster.cmobjects.filter(id=int(key)).first()

                    if form_details.form_input_type == 'dropdown':
                        tender_ids = list(TenderData.cmobjects.filter(form_id=int(key), \
                                                                value=int(value)).values_list('tender_id', flat=True))
                    elif form_details.form_input_type == 'reference':
                        tender_ids = list(TenderData.cmobjects.filter(form_id=int(key), \
                                                                value=int(value)).values_list('tender_id', flat=True))
                    else:
                        tender_ids = list(TenderData.cmobjects.filter(form_id=int(key), \
                                                                value__icontains=value).values_list('tender_id', flat=True))

                    search_tender_ids.append(tender_ids)

            filtered_ids = list(reduce(lambda a, b: set(a) & set(b), search_tender_ids))

            tender_list = tender_list.filter(id__in=filtered_ids)
        else:
            tender_list = tender_list
        
        is_archived_filter = False
        if is_archived == 'true':
            is_archived_filter = True
        tender_list = tender_list.filter(is_archived=is_archived_filter)

        if order_by:
            temp_list = {}
            for tender_list_data in tender_list:
                temp_list[int(tender_list_data.id)] = 0.0
                try:
                    sort_value = TenderData.cmobjects.filter(tender=int(tender_list_data.id), form__form_internal_name=order_by).first()
                    if sort_value:
                        temp_list[int(tender_list_data.id)] = float(sort_value.value)
                except Exception as e:
                    print(e)
            sorted_list = dict(sorted(temp_list.items(), key=lambda item: item[1], reverse=True))

            tender_list = dict([(obj.id, obj) for obj in tender_list])
            sorted_objects = [tender_list[id] for id in sorted_list.keys()]
        else:
            sorted_objects = tender_list
            

        if int(is_paginated) == 0:
            page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
            paginator = Paginator(sorted_objects, page_size)
            page_number = self.request.query_params.get('page', 1)
            page = paginator.get_page(page_number)
            
            serializer = TenderMasterSerializer(page, many=True, context = {"organization_id": organization_id,\
                                                                                        "list_type" : list_type,\
                                                                                        "user_id" : request.user.id})
            
            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': serializer.data,
                # 'Data':serializer.data,
                'tender_title' : tender_title
            })
        else:
            serializer = TenderMasterSerializer(sorted_objects, many=True, context = {"organization_id": organization_id,\
                                                                                        "list_type" : list_type,\
                                                                                        "user_id" : request.user.id})
            
            return Response({
                'results': serializer.data,
                # 'Data':serializer.data,
                'tender_title' : tender_title
            })
            

        

    def post(self, request, format=None):
        from user_permissions.models import UserWiseModulePermissions
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            form_type = self.request.query_params.get('form_type', None)


            user_permissions_module_ids = list(UserWiseModulePermissions.objects.filter(user=request.user, \
                                                                                    level_permission=True).values_list('module_item_id', flat=True))

            frm_group_list = list(FormGroupMastr.cmobjects.filter(organization_id = organization_id, \
                                                              permissible_user_types__in=user_permissions_module_ids).values_list('form_type', flat=True))

            with transaction.atomic():
                tendermaster_create = TenderMaster.objects.create(organization_id=organization_id, created_by=request.user)
                tendermaster_create.save()

                from administrations.utils import create_tender_opportunity_default_datas, create_tender_compliance_derivatives_default_datas

                create_tender_opportunity_default_datas(tendermaster_create.id)
                create_tender_compliance_derivatives_default_datas(tendermaster_create.id)

                for key, value in request.data.items():
                    form_details = FormMaster.objects.filter(id=key).first()

                    if form_details.form_input_type == 'file':
                        created = TenderData.objects.create(tender=tendermaster_create, form_id=key, \
                                                            document=value, created_by=request.user)
                    else:
                        created = TenderData.objects.create(tender=tendermaster_create, form_id=key, value=value, \
                                                            created_by=request.user)
                    
                    created.save()

            serializer = TenderMasterSerializer(tendermaster_create, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True,\
                                                                                        "user_id" : request.user.id})

            form_type_list = list(FormMenuMaster.cmobjects.filter(\
                is_display=True, \
                    form_type_name__in=frm_group_list).order_by('sort_order').values_list('form_type_name', flat=True).distinct())

            next_form_type = 'last'

            for num, value in enumerate(form_type_list, start=0):
                if form_type == value:
                    next_form_type = form_type_list[num + 1]


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'next' : next_form_type,
                                    'msg': 'Added Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


    def put(self, request, *args, **kwargs):
        from user_permissions.models import UserWiseModulePermissions
        mismatch_records = []
        organization_id = self.request.query_params.get('organization_id', None)
        tender_id = self.request.query_params.get('tender_id', None)
        form_type = self.request.query_params.get('form_type', None)

        on_submission_open = self.request.query_params.get('on_submission_open', None)

        project_id = ""

        # tender_data = request.data.get('tender_data', None)

        if tender_id != 'null':
            tender_l1_check = TenderData.cmobjects.filter(\
                    form__form_internal_name="selected_as_l1", tender_id=tender_id).first()
            
            dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='agreement_signed', \
                                                               option='Yes').values_list('id', flat=True))
        
            agreement_signed = TenderData.cmobjects.filter(form__form_internal_name='agreement_signed', \
                                                      value__in=dropdown_ids, tender_id=tender_id).first()
            
            print("******************agreement_signed: ", agreement_signed)
        else:
            tender_l1_check = None
            agreement_signed = None

        user_permissions_module_ids = list(UserWiseModulePermissions.objects.filter(user=request.user, \
                                                                                level_permission=True).values_list('module_item_id', flat=True))

        frm_group_qs = FormGroupMastr.cmobjects.filter(organization_id = organization_id, \
                                                            permissible_user_types__in=user_permissions_module_ids).order_by('form_type').values('form_type').distinct()

        frm_group_list = [item['form_type'] for item in frm_group_qs]

        user_permission_list = list(UserWiseModulePermissions.objects.filter(user=request.user, \
                                                                                        level_permission=True).values_list('module_item__unique_id', flat=True))

        with transaction.atomic():

            time_now = strftime("%d %b %Y %I:%M %p", localtime())

            if tender_id != 'null':
                tender_details = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                                id=tender_id).first()
                
                end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)

                if "pre-tender-proposer" in user_permission_list:
                    if form_type == 'tender_compliances':
                        log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                    activity="Tender Compliances Updated by Proposer Name " + \
                                                    str(end_user_name) + " at " + str(time_now), user=request.user)
                
                        log_details.save()
                    else:
                        log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                    activity="Tender Updated by Proposer Name " + \
                                                        str(end_user_name) + " at " + str(time_now), user=request.user)
                    
                        log_details.save()

                elif "pre-tender-identifier" in user_permission_list:
                    log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                    activity="Tender Updated by " + \
                                                    str(end_user_name) + " at " + str(time_now), user=request.user)
                
                    log_details.save()


            
            else:
                tender_details = TenderMaster.objects.create(organization_id=organization_id, created_by=request.user)
                tender_details.save()
                from administrations.utils import create_tender_opportunity_default_datas, create_tender_compliance_derivatives_default_datas
                
                create_tender_opportunity_default_datas(tender_details.id)
                create_tender_compliance_derivatives_default_datas(tender_details.id)


                end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)

                log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                    activity="Tender Identified by " + \
                                                    str(end_user_name) + " at " + str(time_now), user=request.user)
                
                log_details.save()

            if on_submission_open in ["tender_compliances", "percentage_share_analytics"]:
                if "pre-tender-identifier" in user_permission_list and "pre-tender-proposer" in user_permission_list:

                    tender_details.is_eligibility_complete = True
                    tender_details.is_eligibility_complete_for_proposer = True
                    tender_details.is_percentage_share_active = True
                    tender_details.is_percentage_share_complete = True
                    tender_details.is_compliance_active = True

                elif "pre-tender-identifier" in user_permission_list:

                    tender_details.is_eligibility_complete = True

                elif "pre-tender-proposer" in user_permission_list:

                    tender_details.is_eligibility_complete = True
                    tender_details.is_eligibility_complete_for_proposer = True
                    tender_details.is_percentage_share_active = True
                    tender_details.is_percentage_share_complete = True
                    tender_details.is_compliance_active = True

                else:
                    tender_details.is_eligibility_complete = True
                    tender_details.is_eligibility_complete_for_proposer = True
                    tender_details.is_percentage_share_active = True
                    tender_details.is_percentage_share_complete = True
                    tender_details.is_compliance_active = True

            elif on_submission_open == "tender_executive_summary":
                tender_details.is_executive_summary_active = True
                tender_details.is_compliance_complete = True

            elif on_submission_open == "tender_executive_commitee":
                tender_details.is_approval_active = True
                tender_details.is_executive_summary_complete = True

            elif on_submission_open == "tender_survey_details":
                tender_details.is_assignment_complete = True
                tender_details.survey_members_assigned_date = date.today()
                tender_details.is_survey_active = True

            elif on_submission_open == "tender_open_status":
                tender_details.is_submission_complete = True
                tender_details.is_technical_open_active = True

            elif on_submission_open == "tender_evaluation_status":
                tender_details.is_evaluation_active = True
                tender_details.is_technical_open_complete = True

            elif on_submission_open == "tender_lmpi_group":
                tender_details.is_lmpi_active = True
                tender_details.is_evaluation_complete = True

            
            
            if tender_l1_check and tender_l1_check.value == 'true' \
                and on_submission_open == 'tender_l1_selection':

                # raise Exception("-- debug --1 ")
                tender_details.is_lmpi_active = True
                tender_details.is_evaluation_complete = True
                tender_details.is_lmpi_complete = True
                tender_details.is_l1 = True
                tender_details.is_not_l1 = False
                tender_details.l1_selection_date = date.today()                    
                
                log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                    activity="Tender Selected as L1 at " + str(time_now), user=request.user)
                
                log_details.save()

            elif tender_l1_check and tender_l1_check.value == 'false' \
                and on_submission_open == 'tender_l1_selection':

                # raise Exception("-- debug --2 ")
                tender_details.is_lmpi_complete = True
                tender_details.is_not_l1 = True
                tender_details.is_l1 = False
                tender_details.l1_not_selection_date = date.today()

                log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                    activity="Tender Not Selected as L1 at " + str(time_now), user=request.user)
                
                log_details.save()

            if agreement_signed:
                if form_type == 'tender_l1_selection':
                    tender_details.is_l1_complete = True
                    tender_details.is_not_l1_complete = False
                    tender_details.agreement_signing_date = date.today()

                    log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                        activity="Tender Agreement Signed at " + str(time_now), user=request.user)
                    
                    log_details.save()

            else:
                if form_type == 'tender_l1_not_selected':
                    tender_details.is_l1_complete = False
                    tender_details.is_not_l1_complete = True
                    tender_details.rca_date = date.today()

                    log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                        activity="Tender RCA Done at " + str(time_now), user=request.user)
                    
                    log_details.save()

            tender_details.save()


            l1_value = ""

            participation_value = ""

            # print(Back.GREEN)
            # for key, value in request.data.items():
            #     print(key, ":", value)
            # print(Style.RESET_ALL)

            for key, value in request.data.items():
                # print(key, ":", value)
                formatted_key = str(key).split("_")
                form_id = formatted_key[0]
                sort_count = formatted_key[1]
                form_details = FormMaster.objects.select_related('form_group').filter(id=int(form_id)).first()

                if form_details.form_internal_name == "selected_as_l1":
                    l1_value = value

                if form_details.form_internal_name == "participations_mode":
                    participation_value = value

                if form_details.form_group.is_multiple:
                    if form_details.form_input_type == 'file':
                        created = TenderData.cmobjects.update_or_create(tender=tender_details, form_id=form_id, by_order=sort_count, \
                                                                    defaults = {"document" :  value, \
                                                                                "created_by" : request.user})
                    else:
                        if form_details.form_internal_name == 'change_date_final':
                            created = TenderData.cmobjects.update_or_create(tender=tender_details, form_id=form_id, by_order=sort_count, \
                                                                    defaults = {"value" : value, \
                                                                                    "created_by" : request.user})
                            change_form_details = FormMaster.cmobjects.filter(form_internal_name="tender_date_changed_by_final").first()

                            exclude_ids = list(TenderData.cmobjects.filter(tender=tender_details, \
                                                                           form=change_form_details).values_list('id', flat=True))
                            
                            created_by = TenderData.cmobjects.exclude(id__in=exclude_ids).update_or_create(tender=tender_details, form=change_form_details, by_order=sort_count, \
                                                                    defaults = {"value" : str(request.user.first_name) + " " + str(request.user.last_name), \
                                                                                    "created_by" : request.user})

                            
                        else:
                            change_form_details = FormMaster.cmobjects.filter(form_internal_name="tender_date_changed_by_final").first()

                            exclude_ids = list(TenderData.cmobjects.filter(tender=tender_details, \
                                                                           form=change_form_details).values_list('id', flat=True))



                            # TODO: debug done. Multiple Objects Returned
                            filtered_tender_data = TenderData.cmobjects.filter(
                                ~Q(id__in=exclude_ids),
                                tender=tender_details,
                                form_id=form_id,
                                by_order=sort_count,
                            )
                            if filtered_tender_data.count() > 1:
                                filtered_tender_data.delete()
                                created, tender_data_object = TenderData.cmobjects.filter(
                                    ~Q(id__in=exclude_ids)).update_or_create(
                                    tender=tender_details,
                                    form_id=form_id,
                                    by_order=sort_count,
                                    defaults={"value": value,"created_by": request.user}
                                )

                            else:
                                created, tender_data_object = TenderData.cmobjects.filter(~Q(id__in=exclude_ids)).update_or_create(
                                    tender=tender_details,
                                    form_id=form_id,
                                    by_order=sort_count,
                                    defaults = {"value" : value,"created_by" : request.user}
                                )
                else:
                    if form_details.form_input_type == 'file':
                        created, tender_data_object  = TenderData.cmobjects.update_or_create(tender=tender_details, form_id=form_id, \
                                                                    defaults = {'document' : value, 'created_by' : request.user})
                    else:
                        created, tender_data_object  = TenderData.cmobjects.update_or_create(tender=tender_details, form_id=form_id, \
                                                                    defaults = {'value' : value, 'created_by' : request.user})

        serializer = TenderMasterSerializer(tender_details, context = {"organization_id": organization_id,\
                                                                                "list_type" : True,\
                                                                                        "user_id" : request.user.id})
        

        tender_data_details = TenderData.objects.filter(tender=tender_details, \
                                                                form__form_internal_name='tender_id').first()

        if form_type == 'tender_pre_feasibility_assignments' and tender_id:
            log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                            activity="Survey Members Assigned by " + \
                                            str(end_user_name) + " at " + str(time_now), user=request.user)
        
            log_details.save()

            choise_ids = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name="select_members").first()

            dependent_ids = ast.literal_eval(choise_ids.value)

            user_ids = list(FormDependentChoices.cmobjects.filter(\
                id__in=dependent_ids).values_list('option_id', flat=True))
            
            emails = list(PmsUser.objects.filter(id__in=user_ids).values_list('email', flat=True))

            for obj in user_ids:
                user_details = PmsUser.objects.filter(id=obj).first()
                log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                            activity="Tender with Tender ID " + str(tender_data_details.value) + " Survey Assigned to you by " + \
                                            str(end_user_name) + " at " + str(time_now), user=user_details)
        
                log_details.save()

            subject = "Tender With Tender ID " + str(tender_data_details.value) + " Survey Assigned to you"

            notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " Survey Assigned to you by " + str(end_user_name) + " at " + str(time_now)
            trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

            # schedule_generic_mail(subject=subject, to_mail_list=emails, context={'notification_text ': notification_text})

        form_type_list = list(FormMenuMaster.cmobjects.filter(is_display=True,\
                form_type_name__in=frm_group_list, menu__form_type_name='tender').order_by('sort_order').values_list('form_type_name', flat=True).distinct())

        next_form_type = ''

        try:
            for num, value in enumerate(form_type_list, start=0):
                if form_type == value:
                    next_form_type = form_type_list[num + 1]
        except Exception as ex:
            next_form_type = "last"


        # if form_type == 'tender_eligibility' and participation_value == 'JV':
        #     next_form_type = "percentage_share_analytics"

        if next_form_type == 'tender_executive_commitee' and tender_details.is_sent_for_approval == False:
            next_form_type = "last"

        
        if form_type == 'tender_evaluation_status' and l1_value == 'true':
            # next_form_type = "tender_l1_selection"
            next_form_type = "tender_lmpi_group"

        if form_type == 'tender_evaluation_status' and l1_value == 'false':
            next_form_type = "tender_l1_not_selected"

        if agreement_signed and form_type == 'tender_l1_selection':
            next_form_type = "project_details"
            from project_and_planning.models import ProjectMaster
            project_details = ProjectMaster.cmobjects.filter(organization_id=organization_id, \
                                                             tender_id=tender_id).first()
            if project_details:
                project_id = project_details.id
            else:
                with transaction.atomic():
                    project_create = ProjectMaster.objects.create(organization_id=organization_id, \
                                                                tender_id=tender_id)
                    project_create.save()

                    project_id = project_create.id

                    from administrations.utils import executive_summary_create_for_project, risk_create_for_project

                    executive_summary_create_for_project(tender_details.id, project_id)
                    risk_create_for_project(tender_details.id, project_id)
                    # mismatch_records = planning_tender_link(request, project_id, tender_details.id, organization_id)

        elif not agreement_signed and form_type == 'tender_l1_selection':
            next_form_type = "last"
        

        return Response({'results':{
                                'Data':serializer.data,
                                },
                                'planning_tender': mismatch_records if mismatch_records else None,
                                'next' : next_form_type,
                                'l1_value' : l1_value,
                                "project_id" : project_id,
                                'msg': 'Updated Successfully',
                                'status':status.HTTP_200_OK,    
                                "request_status": 0})
          
    
class TenderMasterOptimizeAPI(APIView):
    """
        CRUD API for communication model
    """
    
    

    def get(self, request):
        """
		Get a list of all TenderMaster
		"""
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')

        tender_name__isnull = self.request.query_params.get('tender_name__isnull', False)

        if id:
            queryset = TenderMaster.cmobjects.filter(id=id).first()
            serializer = TenderMasterSerializer2(queryset)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, ['hideLoader', 'tender_name__isnull'])
        queryset = (TenderMaster.cmobjects.
                    select_related('organization').
                    prefetch_related('tenderbidder_tender_id').
                    filter(*search))
        if all == 'true':
            serializer = TenderMasterSerializer2(queryset, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = TenderMasterSerializer2(page, many=True,)
        results = serializer.data

        if not tender_name__isnull:
            results = list(filter(lambda x: str(x['tender_name']).strip(), results))

        _reverse = True if str(order_by).startswith('-') else False
        results.sort(key=lambda x: x[str(order_by).replace('-', '')], reverse=_reverse)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': results,
        })


class TenderMasterRejectAPI(APIView):
    """ Tender Master form File input API View """

    
    

    def put(self, request, *args, **kwargs):
        try:
            tender_id = self.request.query_params.get('tender_id', None)

            tender_details = TenderMaster.cmobjects.filter(
                                id=tender_id).first()
            
            tender_details.is_reject = True
            tender_details.save()

            serializer = TenderDataSerializer(tender_details)

            return Response({'results':{
                                    'Data': serializer.data,
                                    },
                                    'msg': 'Selected Tender Rejected',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class TenderWBSAPI(APIView):
    """
    Tender WBS API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender wbs
        """
        search = {}
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        non_zero_val_in_qty = self.request.query_params.get('non_zero_val_in_qty', None)
        if id:
            wbs_details = TenderWBS.cmobjects.filter(id = id).first()
            serializer = TenderWBSSerializer(wbs_details)
            return Response(serializer.data)

        tender_id = self.request.query_params.get('tender_id', None)
        remove_vendor = self.request.query_params.get('remove_vendor', None)
        only_vendor = self.request.query_params.get('only_vendor', None)
        is_master = self.request.query_params.get('is_master', None)
        is_parent_null = self.request.query_params.get('is_parent_null', None)

        if is_master:
            is_master = bool(int(is_master))
            wbs_list = TenderWBS.cmobjects.filter(is_default=is_master, is_deleted=False).order_by('after_this','id','by_order')
        else:
            wbs_list = TenderWBS.cmobjects.filter(Q(tender_id=tender_id) | Q(is_default=True)).order_by('after_this','id','by_order')

        if remove_vendor == 'true':
            search['exclude__slug'] = 'specilized-vendors'

        if only_vendor:
            search['slug'] = 'specilized-vendors'

        if is_parent_null:
            search['parent_id__isnull'] = True
        
        search = custom_filters(self.request, search, ['tender_id','remove_vendor','only_vendor','is_master','is_parent_null','non_zero_val_in_qty'])

        wbs_list = wbs_list.filter(*search)
        if not is_parent_null:
            return_list = []
            parent_list = list(set(list(wbs_list.values_list('id', flat=True))))
            return_list = get_all_child(parent_list,return_list)
            wbs_list = TenderWBS.cmobjects.filter(id__in=return_list).order_by('after_this','id','by_order')

        if all == 'true':
            if non_zero_val_in_qty and tender_id:
                ids = list(wbs_list.values_list('id', flat=True))
                include_ids = ExecutiveSummeryData.cmobjects.filter(
                        tender__id=tender_id,
                        wbs__id__in=ids,
                        form__form_internal_name='sale_amount',  # 'qty'
                        value__isnull=False
                ).values_list('wbs__id', flat=True).distinct()
                if include_ids:
                    wbs_list = wbs_list.filter(pk__in=include_ids).distinct()

            serializer = TenderWBSSerializer(wbs_list, many=True)
            return Response({'results': (serializer.data)})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderWBSSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request, format=None):
        try:
            with transaction.atomic():
                all_data = None
                return_data = []
                if not isinstance(self.request.data, list):
                    all_data = [self.request.data]
                else:
                    all_data = self.request.data
                for data in all_data:
                    tender_id = data.get('tender_id', None)
                    wbs_name = data.get('wbs_name', None)
                    key_scopes = data.get('key_scopes', [])
                    category = data.get('category', None)
                    parent_id = data.get('parent_id', None)
                    uom_id = data.get('uom_id', None)
                    short_name = data.get('short_name', None)
                    by_order = data.get('by_order', 1)
                    boq_code = data.get('boq_code', None)
                    boq_no = data.get('boq_no', None)
                    after_this = data.get('after_this', None)

                    is_master = self.request.query_params.get('is_master', None)

                    if is_master:
                        is_master = bool(int(is_master))
                        wbs_create = TenderWBS.objects.create(tender_id=tender_id, parent_id_id=parent_id, category=category, wbs_name=wbs_name, is_default=is_master, uom_id=uom_id,short_name=short_name,by_order=by_order,boq_code=boq_code,boq_no=boq_no,after_this_id=after_this)
                        wbs_create.save()
                    else:
                        wbs_create = TenderWBS.objects.create(tender_id=tender_id, parent_id_id=parent_id, category=category, wbs_name=wbs_name, is_default=False, uom_id=uom_id,short_name=short_name,by_order=by_order,boq_code=boq_code,boq_no=boq_no,after_this_id=after_this)
                        wbs_create.save()

                    for item in key_scopes:
                        keyscope = item.get('keyscope', None)
                        uom = item.get('uom', None)
                        unit = item.get('unit', None)
                        by_order = item.get('by_order', 1)
                        
                        created = TenderWBSKeyScopes.objects.create(wbs_id=wbs_create.id, keyscope=keyscope, \
                                                                    uom_id=uom, by_order=by_order)
                        
                        created.save()

                        second_key_scopes = item.get('second_key_scopes', [])
                        for second_item in second_key_scopes:
                            name = second_item.get('keyscope', None)
                            uom = second_item.get('uom', None)
                            unit = second_item.get('unit', None)
                            by_order = second_item.get('by_order', 1)
                            
                            second_created = TenderWBSSecondKeyScopes.objects.create(keyscope_id=created.id, name=name, \
                                                                        uom_id=uom, by_order=by_order)
                            
                            second_created.save()

                    serializer = TenderWBSSerializer(wbs_create)
                    return_data.append(serializer.data)


            return Response({'results':{
                                    'Data':return_data,
                                    },
                                    'msg': 'Added Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        
    def put(self, request, *args, **kwargs):
        try:
            method = self.request.query_params.get('method', None)
            wbs_id = self.request.query_params.get('wbs_id', None)

            if method.lower() == 'edit':
                with transaction.atomic():
                    all_data = None
                    return_data = []
                    if not isinstance(self.request.data, list):
                        all_data = [self.request.data]
                    else:
                        all_data = self.request.data
                    for data in all_data:
                        tender_id = data.get('tender_id', None)
                        wbs_name = data.get('wbs_name', None)
                        key_scopes = data.get('key_scopes', [])
                        category = data.get('category', None)
                        parent_id = data.get('parent_id', None)
                        uom_id = data.get('uom_id', None)
                        short_name = data.get('short_name', None)
                        by_order = data.get('by_order', 1)
                        boq_code = data.get('boq_code', None)
                        boq_no = data.get('boq_no', None)
                        wbs_id = data.get('wbs_id', None)
                        after_this = data.get('after_this', None)

                        is_master = self.request.query_params.get('is_master', None)

                        if is_master:
                            is_master = bool(int(is_master))
                            _obj, _wbs_create = TenderWBS.objects.update_or_create(id=wbs_id,
                                                                                defaults={"category": category, "wbs_name": wbs_name, "tender_id": tender_id, "is_default": is_master, "parent_id_id": parent_id, "uom_id": uom_id,"short_name":short_name,"by_order":by_order,"boq_code":boq_code,"boq_no":boq_no,"after_this_id":after_this}
                                                                                )
                        else:
                            _obj, _wbs_create = TenderWBS.objects.update_or_create(id=wbs_id, \
                                                                                defaults={"category": category, "wbs_name": wbs_name, \
                                                                                            "tender_id": tender_id, "parent_id_id": parent_id, "uom_id": uom_id,"short_name":short_name,"by_order":by_order,"boq_code":boq_code,"boq_no":boq_no,"after_this_id":after_this})

                        key_scopes_list = []

                        for item in key_scopes:
                            id = item.get('id', None)
                            keyscope = item.get('keyscope', None)
                            uom = item.get('uom', None)
                            by_order = item.get('by_order', 1)
                            unit = item.get('unit', None)
                            
                            if id != "":
                                created = TenderWBSKeyScopes.objects.update_or_create(wbs_id=wbs_id, id=id, \
                                                                                    defaults={'keyscope' : keyscope, 'unit' : unit, \
                                                                                                'by_order' : by_order, 'uom_id' : uom})
                            else:
                                created = TenderWBSKeyScopes.objects.create(wbs_id=wbs_id, keyscope=keyscope,\
                                                                            uom_id=uom, by_order=by_order, unit=unit)
                                created.save()
                            

                            key_scopes_list.append(keyscope)
                            
                            second_key_scopes = item.get('second_key_scopes', [])
                            second_key_scopes_list = []
                            for second_item in second_key_scopes:
                                second_id = second_item.get('id', None)
                                second_keyscope = second_item.get('keyscope', None)
                                uom = second_item.get('uom', None)
                                by_order = second_item.get('by_order', 1)
                                unit = second_item.get('unit', None)
                                if second_id != "":
                                    second_created = TenderWBSSecondKeyScopes.objects.update_or_create(keyscope_id=id, id=second_id, \
                                                                                        defaults={'name' : second_keyscope, 'unit' : unit, \
                                                                                                    'by_order' : by_order, 'uom_id' : uom})
                                else:
                                    second_created = TenderWBSSecondKeyScopes.objects.create(keyscope_id=id, name=second_keyscope,\
                                                                                uom_id=uom, by_order=by_order, unit=unit)
                                    second_created.save()
                                second_key_scopes_list.append(second_keyscope)

                            second_wbs_deleted_list = TenderWBSSecondKeyScopes.cmobjects.filter(keyscope_id=id).exclude(name__in=second_key_scopes_list)
                            for obj in second_wbs_deleted_list:
                                obj.is_deleted = True
                                obj.save()

                        wbs_deleted_list = TenderWBSKeyScopes.cmobjects.filter(wbs_id=wbs_id).exclude(keyscope__in=key_scopes_list)
                        for obj in wbs_deleted_list:
                            obj.is_deleted = True
                            obj.save()

            elif method.lower() == 'delete':
                wbs_details = TenderWBS.cmobjects.filter(id=wbs_id).first()
                wbs_details.is_deleted = True
                wbs_details.save()

            wbs_details = TenderWBS.cmobjects.filter(id=wbs_id).first()

            serializer = TenderWBSSerializer(wbs_details)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Updated Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class WbsAttributeAPI(APIView):
    """
        CRUD API for WbsAttribute model (  one to one with TenderWBS )
    """
    
    

    def get(self, request):
        """
        Get a list of all WbsAttribute
        """
        wbs = self.request.query_params.get('wbs', None)
        all = self.request.query_params.get('all', None)
        if wbs:
            accounts_head_details = WbsAttribute.cmobjects.filter(pk=wbs).first()
            serializer = WbsAttributeSerializer(accounts_head_details)
            return Response(serializer.data)

        search = {}
        for filters in self.request.query_params:
            if not filters in ['id', 'all', 'page_size', 'page'] and self.request.query_params.get(filters, None):
                search[filters] = self.request.query_params.get(filters, None)

        _list = WbsAttribute.cmobjects.filter(**search).order_by('-pk')
        if all == 'true':
            serializer = WbsAttributeSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = WbsAttributeSerializer(page, many=True)

        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new WbsAttribute
        """
        request.data['created_by_id'] = request.user.id
        serializer = WbsAttributeSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a WbsAttribute
        """
        method = self.request.query_params.get('method', None)

        wbs = self.request.query_params.get('wbs', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a AccountsHead
                """
                if WbsAttribute.cmobjects.filter(pk=wbs).exists():
                    _details = WbsAttribute.cmobjects.filter(pk=wbs).first()

                    request.data['updated_by_id'] = request.user.id
                    serializer = WbsAttributeSerializer(_details, data=request.data)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a WbsAttribute
                """
                if WbsAttribute.cmobjects.filter(pk=wbs).exists():
                    accounts_head_details = WbsAttribute.cmobjects.get(pk=wbs)
                    accounts_head_details.is_deleted = True
                    accounts_head_details.save()

                    return Response({'results': {
                        'wbs_attribute': WbsAttribute.objects.filter(pk=wbs).values(),
                    },
                        'msg': 'Successfully deleted WbsAttribute',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})

        raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support...."})


class TenderWBSKeyScopesAPI(APIView):
    """
    Tender WBS API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender wbs
        """
        id = self.request.query_params.get('id', None)
        if id:
            wbs_details = TenderWBSKeyScopes.cmobjects.filter(id = id).first()
            serializer = TenderWBSKeyScopesSerializer(wbs_details)
            return Response(serializer.data)

        tender_id = self.request.query_params.get('tender_id', None)
        wbs_id_list = list(TenderWBS.cmobjects.filter(Q(tender_id = tender_id) | \
                                                      Q(is_default = True)).values_list('id', flat=True))

        key_scope_list = TenderWBSKeyScopes.cmobjects.filter(wbs_id__in=wbs_id_list).order_by('by_order')
        
        serializer = TenderWBSKeyScopesSerializer(key_scope_list, many=True, context = {"tender_id": tender_id})
        # serializer = CompanySerializer(company_list, many=True)
        return Response({
            'count': key_scope_list.count(),
            'results': serializer.data,
        }) 

class TenderWBSSecondKeyScopesAPI(APIView):
    """
    Tender WBS API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender wbs
        """
        id = self.request.query_params.get('id', None)
        if id:
            wbs_details = TenderWBSSecondKeyScopes.cmobjects.filter(id = id).first()
            serializer = TenderWBSSecondKeyScopesSerializer(wbs_details)
            return Response(serializer.data)

        tender_id = self.request.query_params.get('tender_id', None)
        wbs_id_list = list(TenderWBS.cmobjects.filter(Q(tender_id = tender_id) | \
                                                      Q(is_default = True)).values_list('id', flat=True))

        key_scope_list = TenderWBSSecondKeyScopes.cmobjects.filter(keyscope_id__wbs_id__in=wbs_id_list).order_by('by_order')
        
        serializer = TenderWBSSecondKeyScopesSerializer(key_scope_list, many=True, context = {"tender_id": tender_id})
        # serializer = CompanySerializer(company_list, many=True)
        return Response({
            'count': key_scope_list.count(),
            'results': serializer.data,
        })
        
class ExecutiveSummeryDataAPIView(APIView):
    
    

    
    def get(self, request, format=None):
        organization_id = request.query_params.get('organization_id', None)
        queryset = ExecutiveSummeryData.objects.all()
        if organization_id:
            search = {}
            search['tender__organization_id'] = organization_id
            search = custom_filters(self.request, search, ['organization_id'])
            queryset = queryset.filter(*search)
            serializer = ExecutiveSummeryDataSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response({'error': "please enter a valid organization_id"}, status=status.HTTP_404_NOT_FOUND)
            
        
    def put(self, request, *args, **kwargs):
        try:
            # Extract the relevant data from the request
            tender_id = request.data.get('tender_id')
            wbs_id = request.data.get('wbs_id')
            # wbskey_id = request.data.get('wbskey_id')
            # wbssecondkey_id = request.data.get('wbssecondkey_id',None)
            form_id = request.data.get('form_id')
            value = request.data.get('value')

            # Get or create the related objects
            
            tender = TenderMaster.objects.get(id=tender_id)
            wbs = TenderWBS.objects.get(id=wbs_id)
            # wbskey = TenderWBSKeyScopes.objects.get(id=wbskey_id)
            # wbssecondkey = None
            # if not wbssecondkey_id is None:
            #     wbssecondkey = TenderWBSSecondKeyScopes.objects.get(id=wbssecondkey_id)

            # Check if the ExecutiveSummeryData instance already exists
            instance, created = ExecutiveSummeryData.objects.get_or_create(tender=tender, wbs=wbs, \
                                                                           form_id=form_id)

            # Update the value field
            instance.value = value
            instance.save()

            # Serialize the updated instance
            serializer = ExecutiveSummeryDataSerializer(instance)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except (TenderMaster.DoesNotExist, TenderWBS.DoesNotExist) as e:
            return Response({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        



class TenderComplianceDerivativesAPIView(APIView):
    
    

    
    def get(self, request, format=None):
        tender_id = request.query_params.get('tender_id')
        if tender_id:
            queryset = TenderComplianceDerivatives.cmobjects.filter(tender_id=tender_id).order_by('id')
            serializer = TenderComplianceDerivativesSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response({'error': "Tender Not Found"}, status=status.HTTP_404_NOT_FOUND)
            
        
    def put(self, request, *args, **kwargs):
        try:
            # Extract the relevant data from the request
            tender_id = request.data.get('tender_id')
            form_id = request.data.get('form_id')
            value = request.data.get('value')
            table_id = request.data.get('table_id')

            compliance_id = request.data.get('compliance_id', None)


            if compliance_id:
                derivative_id = int(compliance_id)
                derivative_details = TenderComplianceDerivatives.objects.filter(id=derivative_id).first()
            else:
                derivative_details = TenderComplianceDerivatives.objects.create(tender_id=tender_id)
                derivative_details.save()
                derivative_id = derivative_details.id            

            # Check if the ExecutiveSummeryData instance already exists
            instance, created = TenderCompliancesData.objects.get_or_create(compliances_id=derivative_id,\
                                                                                  form_id=form_id)

            # Update the value field
            instance.value = value
            instance.table_id = table_id
            instance.save()

            form_details = FormMaster.cmobjects.filter(id=form_id).first()

            if form_details.form_internal_name == 'dates' and form_details.form_type == 'tender_executive_summary':
                days_left_form = FormMaster.cmobjects.filter(form_internal_name="days_left_from_today",\
                                                             form_type='tender_executive_summary').first()
                
                left_instance, left_created = TenderCompliancesData.objects.get_or_create(compliances_id=derivative_id,\
                                                                                  form=days_left_form)
                
                derivative_date_details = TenderCompliancesData.cmobjects.filter(form__form_internal_name='dates',\
                                                                             form__form_type='tender_executive_summary', \
                                                                                compliances_id=derivative_id).first()
                if derivative_date_details:
                    date_provided_str = derivative_date_details.value
                    date_provided = datetime.strptime(date_provided_str, "%Y-%m-%d").date()
                    date = datetime.now().date()

                    no_of_days = int((date_provided - date).days) + 1 if date < date_provided else 0
                    final_no_of_days =  no_of_days
                else:
                    final_no_of_days = ""

                left_instance.value = final_no_of_days
                left_instance.table_id = table_id
                left_instance.save()
                

            # Serialize the updated instance
            serializer = TenderComplianceDerivativesSerializer(derivative_details)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)
        
class RiskDetilsAPIView(APIView):
    
    

    
    def get(self, request, format=None):
        tender_id = request.query_params.get('tender_id')
        if tender_id:
            queryset = Riskdetails.cmobjects.filter(tender_id=tender_id).order_by('id')
            serializer = RiskdetailsSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response({'error': "Tender Not Found"}, status=status.HTTP_404_NOT_FOUND)
            
        
    def put(self, request, *args, **kwargs):
        try:
            # Extract the relevant data from the request
            tender_id = request.data.get('tender_id')
            form_id = request.data.get('form_id')
            value = request.data.get('value')
            table_id = request.data.get('table_id')

            risk_details_id = request.data.get('risk_details_id', None)


            if risk_details_id:
                risk_details_id = int(risk_details_id)
                risk_details = Riskdetails.objects.filter(id=risk_details_id).first()
            else:
                risk_details = Riskdetails.objects.create(tender_id=tender_id)
                risk_details.save()
                risk_details_id = risk_details.id            

            instance, created = RiskdetailsData.objects.get_or_create(risk_details_id=risk_details_id,\
                                                                                  form_id=form_id)
            # Update the value field
            instance.value = value
            instance.table_id = table_id
            instance.save()
            # Serialize the updated instance
            serializer = RiskdetailsSerializer(risk_details)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)
        
class OpportunityDetailsAPIView(APIView):
    
    

    
    def get(self, request, format=None):
        tender_id = request.query_params.get('tender_id')
        if tender_id:
            queryset = Opportunitydetails.cmobjects.filter(tender_id=tender_id).order_by('id')
            serializer = OpportunitydetailsSerializer(queryset, many=True)
            return Response(serializer.data)
        else:
            return Response({'error': "Tender Not Found"}, status=status.HTTP_404_NOT_FOUND)
            
        
    def put(self, request, *args, **kwargs):
        try:
            # Extract the relevant data from the request
            tender_id = request.data.get('tender_id')
            form_id = request.data.get('form_id')
            value = request.data.get('value')
            table_id = request.data.get('table_id')

            opportunity_details_id = request.data.get('opportunity_details_id', None)


            if opportunity_details_id:
                opportunity_details_id = int(opportunity_details_id)
                opportunity_details = Opportunitydetails.objects.filter(id=opportunity_details_id).first()
            else:
                opportunity_details = Opportunitydetails.objects.create(tender_id=tender_id)
                opportunity_details.save()
                opportunity_details_id = opportunity_details.id            

            instance, created = OpportunitydetailsData.objects.get_or_create(opportunity_details_id=opportunity_details_id,\
                                                                                  form_id=form_id)
            # Update the value field
            instance.value = value
            instance.table_id = table_id
            instance.save()
            # Serialize the updated instance
            serializer = OpportunitydetailsSerializer(opportunity_details)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)
        


class TenderMasterRecommendationAPI(APIView):
    """ Tender Master API View """

    
    

    def put(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            tender_id = self.request.query_params.get('tender_id', None)
            is_recommended = self.request.query_params.get('is_recommended', False)


            with transaction.atomic():
                time_now = strftime("%d %b %Y %I:%M %p", localtime())
                tender_details = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                                id=tender_id).first()
                tender_details.is_sent_for_recommendation = True if is_recommended == 'true' else False
                tender_details.tender_proposal_date = date.today()
                tender_details.save()

                end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)

                log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                     activity="Tender Is Sent for Recommendation By " + \
                                                        str(end_user_name) + " at " + str(time_now), user=request.user)
                    
                log_details.save()

                tender_data_details = TenderData.objects.filter(tender=tender_details, \
                                                                form__form_internal_name='tender_id').first()
                
                noti_create = NotificationMaster.objects.create(organization_id=organization_id,\
                                                                notification="Tender With Tender ID " + str(tender_data_details.value) + " Is Sent for Recommendation By " + \
                                                        str(end_user_name) + " at " + str(time_now), is_universal=True)
                
                noti_create.save()

                user_emails = list(UserWiseModulePermissions.objects.filter(\
                    level_permission=True).values_list('user__username', flat=True).distinct())
                user_ids = list(UserWiseModulePermissions.objects.filter(\
                    level_permission=True).values_list('user_id', flat=True).distinct())
                
                subject = "Tender With Tender ID " + str(tender_data_details.value) + " Is Sent for Recommendation"

                notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " Is Sent for Recommendation By " + \
                                                        str(end_user_name) + " at " + str(time_now)

                trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

            serializer = TenderMasterSerializer(tender_details, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True,\
                                                                                        "user_id" : request.user.id})

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Tender Send For Recommendation',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})



class TenderMasterReverseProposalAPI(APIView):
    """ Tender Master API View """

    
    

    def put(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            tender_id = self.request.query_params.get('tender_id', None)
            is_reverse_for_proposal = self.request.query_params.get('is_reverse_for_proposal', False)


            with transaction.atomic():
                time_now = strftime("%d %b %Y %I:%M %p", localtime())
                tender_details = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                                id=tender_id).first()
                tender_details.is_sent_for_recommendation = False if is_reverse_for_proposal == 'true' else True
                tender_details.save()

                end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)

                log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                     activity="Tender Is Reversed for Proposal By " + \
                                                        str(end_user_name) + " at " + str(time_now), user=request.user)
                    
                log_details.save()

                tender_data_details = TenderData.objects.filter(tender=tender_details, \
                                                                form__form_internal_name='tender_id').first()
                
                noti_create = NotificationMaster.objects.create(organization_id=organization_id,\
                                                                notification="Tender With Tender ID " + str(tender_data_details.value) + " Is Reversed for Proposal By " + \
                                                        str(end_user_name) + " at " + str(time_now), is_universal=True)
                
                noti_create.save()

                user_emails = list(UserWiseModulePermissions.objects.filter(\
                    level_permission=True).values_list('user__username', flat=True).distinct())
                user_ids = list(UserWiseModulePermissions.objects.filter(\
                    level_permission=True).values_list('user_id', flat=True).distinct())
                
                subject = "Tender With Tender ID " + str(tender_data_details.value) + " Is Reversed for Proposal"

                notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " Is Reversed for Proposal By " + \
                                                        str(end_user_name) + " at " + str(time_now)

                trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

            serializer = TenderMasterSerializer(tender_details, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True,\
                                                                                        "user_id" : request.user.id})

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Tender Is Reversed for Proposal',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class TenderMasterApprovalAPI(APIView):
    """ Tender Master API View """

    
    

    def put(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            tender_id = self.request.query_params.get('tender_id', None)
            is_sent_for_approval = self.request.query_params.get('is_sent_for_approval', False)


            with transaction.atomic():
                time_now = strftime("%d %b %Y %I:%M %p", localtime())
                tender_details = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                                id=tender_id).first()
                tender_details.is_recommended = True if is_sent_for_approval == 'true' else False
                tender_details.is_approval_active = True
                tender_details.is_executive_summary_complete = True
                tender_details.is_executive_summary_active = True
                tender_details.is_compliance_complete = True
                tender_details.is_eligibility_complete = True
                tender_details.is_eligibility_complete_for_proposer = True
                tender_details.is_compliance_active = True
                tender_details.tender_recommendation_date = date.today()
                tender_details.save()

                end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)

                log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                     activity="Tender Is Recommended By " + \
                                                        str(end_user_name) + " at " + str(time_now), user=request.user)
                    
                log_details.save()


                tender_data_details = TenderData.objects.filter(tender=tender_details, \
                                                                form__form_internal_name='tender_id').first()
                
                noti_create = NotificationMaster.objects.create(organization_id=organization_id,\
                                                                notification="Tender With Tender ID " + str(tender_data_details.value) + " Is Recommended By " + \
                                                        str(end_user_name) + " at " + str(time_now), is_universal=True)
                
                noti_create.save()

                user_emails = list(UserWiseModulePermissions.objects.filter(\
                    level_permission=True).values_list('user__username', flat=True).distinct())
                
                subject = "Tender With Tender ID " + str(tender_data_details.value) + " Is Recommended"

                notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " Is Recommended By " + \
                                                        str(end_user_name) + " at " + str(time_now)

                user_ids = list(UserWiseModulePermissions.objects.filter(\
                    level_permission=True).values_list('user_id', flat=True).distinct()) 
                trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

            serializer = TenderMasterSerializer(tender_details, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True,\
                                                                                        "user_id" : request.user.id})

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Tender Send For Approval',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class TenderMasterReverseRecommendationAPI(APIView):
    """ Tender Master API View """

    
    

    def put(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            tender_id = self.request.query_params.get('tender_id', None)
            is_reverse_for_recommendation = self.request.query_params.get('is_reverse_for_recommendation', False)


            user_id = request.data.get('user_id', None)
            remarks = request.data.get('remarks', None)


            with transaction.atomic():
                time_now = strftime("%d %b %Y %I:%M %p", localtime())
                tender_details = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                                id=tender_id).first()
                tender_details.is_recommended = False if is_reverse_for_recommendation == 'true' else True
                tender_details.is_sent_for_approval = False if is_reverse_for_recommendation == 'true' else True
                tender_details.is_approval_active = False
                tender_details.is_resend_for_recommendations = True
                tender_details.resend_for_recommendation_remarks = remarks
                tender_details.resend_user_id = user_id
                tender_details.save()

                end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)

                log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                     activity="Tender Is Reversed For Recommendation By " + \
                                                        str(end_user_name) + " at " + str(time_now), user=request.user)
                    
                log_details.save()


                tender_data_details = TenderData.objects.filter(tender=tender_details, \
                                                                form__form_internal_name='tender_id').first()
                
                noti_create = NotificationMaster.objects.create(organization_id=organization_id,\
                                                                notification="Tender With Tender ID " + str(tender_data_details.value) + " Is Reversed For Recommendation By " + \
                                                        str(end_user_name) + " at " + str(time_now), is_universal=True)
                
                noti_create.save()

                user_emails = list(UserWiseModulePermissions.objects.filter(\
                    level_permission=True).values_list('user__username', flat=True).distinct())
                
                subject = "Tender With Tender ID " + str(tender_data_details.value) + " Is Reversed For Recommendation"

                notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " Is Reversed For Recommendation By " + \
                                                        str(end_user_name) + " at " + str(time_now)

                user_ids = list(UserWiseModulePermissions.objects.filter(\
                    level_permission=True).values_list('user_id', flat=True).distinct()) 
                trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})
 
                # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

            serializer = TenderMasterSerializer(tender_details, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True,\
                                                                                        "user_id" : request.user.id})

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Tender Is Reversed For Recommendation',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        


class TenderMasterExSummaryReccomendationAPI(APIView):
    """ Tender Master API View """

    
    

    def put(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            tender_id = self.request.query_params.get('tender_id', None)
            ex_summary_recommend_requested = self.request.query_params.get('ex_summary_recommend_requested', False)


            with transaction.atomic():
                summary_file = request.FILES.get('summary_file', None)
                tender_details = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                                id=tender_id).first()
                tender_details.ex_summary_recommend_requested = True if ex_summary_recommend_requested == 'true' else False
                tender_details.summary_file = summary_file
                tender_details.save()

            serializer = TenderMasterSerializer(tender_details, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True,\
                                                                                        "user_id" : request.user.id})

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Selected Tender Executive Summary Send For Reccomendations',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class TenderMasterExSummaryApprovalAPI(APIView):
    """ Tender Master API View """

    
    

    def put(self, request, *args, **kwargs):
        try:
            organization_id = self.request.query_params.get('organization_id', None)
            tender_id = self.request.query_params.get('tender_id', None)
            ex_summary_approval_requested = self.request.query_params.get('ex_summary_approval_requested', False)


            with transaction.atomic():
                summary_file = request.FILES.get('summary_file', None)
                tender_details = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                                id=tender_id).first()
                tender_details.ex_summary_approval_requested = True if ex_summary_approval_requested == 'true' else False
                tender_details.summary_file = summary_file
                tender_details.save()

            serializer = TenderMasterSerializer(tender_details, context = {"organization_id": organization_id,\
                                                                                    "list_type" : True,\
                                                                                        "user_id" : request.user.id})

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Selected Tender Executive Summary Send For Approval',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        





class TenderActivityLogAPIView(APIView):
    """
    CRUD API for TenderActivityLog model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all TenderActivityLog
        """
        activity_type = self.request.query_params.get('activity_type', None)

        tender_id = self.request.query_params.get(
                'tender_id', None)

        if activity_type and activity_type.lower() == 'list':
            id = self.request.query_params.get('id', None)
            if id:
                user_type = TenderActivityLog.cmobjects.filter(id=id).first()
                serializer = TenderActivityLogSerializer(user_type)
                return Response(serializer.data)
            
            employeement_type = TenderActivityLog.cmobjects.filter(
                tender_id=tender_id).order_by('id')

            page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
            paginator = Paginator(employeement_type, page_size)
            page_number = self.request.query_params.get('page', 1)
            page = paginator.get_page(page_number)
            serializer = TenderActivityLogSerializer(page, many=True)

            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': serializer.data,
            })
        
        elif activity_type and activity_type.lower() == 'milestone':
            from django.db.models import Value as V
            from django.db.models.functions import Concat
            from administrations.utils import date_range_list

            tender_details = TenderMaster.cmobjects.filter(id=tender_id).first()

            tender_created_date = tender_details.created_at.date()
            current_date = date.today()

            data_details = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                       form__form_internal_name="submission_date").first()

            if data_details:
                submission_date = datetime.strptime(data_details.value, "%Y-%m-%d").date()
                date_list = date_range_list(tender_created_date, submission_date)
            else:
                date_list = date_range_list(tender_created_date, current_date)

            tender_activity_dates = list(TenderActivityLog.cmobjects.filter(\
                tender_id=tender_id).values_list('date', flat=True).distinct())

            activity_log = []

            for item in date_list:
                activity_dict = {}
                activity_dict['date'] = item
                day_count = (item - tender_created_date)
                activity_dict['day'] = "Day " + str(day_count.days + 1)

                if TenderActivityLog.cmobjects.filter(tender_id=tender_id,\
                                                    date=item).exists():
                    activity_dict['activity_data'] = TenderActivityLog.cmobjects.filter(tender_id=tender_id,\
                                                        date=item).annotate(\
                                                            full_name=Concat('user__first_name', \
                                                                V(' '), 'user__last_name')).values('date',\
                                                                    'activity', 'full_name')
                    activity_dict['no_activity'] = False
                else:
                    activity_dict['activity_data'] = "No Activity Captured On This Day"
                    activity_dict['no_activity'] = True
                
                activity_log.append(activity_dict)

            return Response({
                'results': activity_log,
            })

    


class TenderExecutiveCommiteeAPIView(APIView):
    """
    CRUD API for TenderExecutiveCommitee model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all TenderExecutiveCommitee
        """
        user_id = request.user.id

        id = self.request.query_params.get('id', None)
        if id:
            user_type = TenderExecutiveCommitee.cmobjects.filter(id=id).first()
            serializer = TenderExecutiveCommiteeSerializer(user_type, context={"user_id" : user_id})
            return Response(serializer.data)

        tender_id = self.request.query_params.get(
            'tender_id', None)
        
        employeement_type = TenderExecutiveCommitee.cmobjects.filter(
            tender_id=tender_id).order_by('id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(employeement_type, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderExecutiveCommiteeSerializer(page, many=True, context={"user_id" : user_id})


        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def put(self, request, *args, **kwargs):
        try:
            tender_id = self.request.query_params.get('tender_id', None)

            tender_details = TenderMaster.objects.filter(id=tender_id).first()

            with transaction.atomic():
                group_id = request.data.get('group_id', None)
                user_ids = request.data.get('user_ids', [])
                tender_ex_details = TenderExecutiveCommitee.cmobjects.filter(tender_id=tender_id).first()
                
                if not tender_ex_details:
                    tender_ex_details = TenderExecutiveCommitee.objects.create(tender_id=tender_id, groups_id=group_id)
                    tender_ex_details.save()
                else:
                    tender_ex_details.groups_id = group_id
                    tender_ex_details.save()

                if TenderCommiteeMembers.objects.filter(ex_commitee=tender_ex_details).exists():
                    TenderCommiteeMembers.objects.filter(ex_commitee=tender_ex_details).delete()

                user_emails = []

                for item in user_ids:
                    created = TenderCommiteeMembers.objects.create(ex_commitee=tender_ex_details, \
                                                                    users_id=item.get('user_id', None),\
                                                                        level = item.get('level', None),\
                                                                            commitee_level = item.get('commitee_level', None))
                    created.save()

                    us_details = PmsUser.objects.filter(id=item.get('user_id', None)).first()
                    user_emails.append(us_details.username)

                    time_now = strftime("%d %b %Y %I:%M %p", localtime())

                    tender_data_details = TenderData.objects.filter(tender_id=tender_details, \
                                                                form__form_internal_name='tender_id').first()
                
                    noti_create = NotificationMaster.objects.create(organization_id=tender_details.organization_id,\
                                                                    notification="Tender With Tender ID " + str(tender_data_details.value) \
                                                                        + " Is Sent for VGA Approval To you at " + str(time_now), notified_users=us_details)
                    
                    noti_create.save()

                TenderMaster.objects.filter(id=tender_id).update(is_sent_for_approval=True, \
                                                                 tender_sent_for_vga_approval_date=date.today())

                subject = "Tender With Tender ID " + str(tender_data_details.value) + " is Recommended and Sent for VGA Approval"

                notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " is Recommended and Sent for VGA Approval to you at " + str(time_now)

                
                trigger_notifications(subject=subject, user_list=user_emails,context={'notification_text ': notification_text})
 
                # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})


            serializer = TenderExecutiveCommiteeSerializer(tender_ex_details, context={"user_id" : request.user.id})

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Tender Executive Commitee Created',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class TenderExecutiveCommiteeMembersVGAActionAPIView(APIView):
    """
    CRUD API for TenderExecutiveCommitee model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all TenderExecutiveCommitee
        """
        ex_commitee_id = self.request.query_params.get(
            'ex_commitee_id', None)
        
        members_list = TenderCommiteeMembers.cmobjects.filter(
            ex_commitee_id=ex_commitee_id).order_by('id')

        serializer = TenderExecutiveCommiteeMembersSerializer(members_list, many=True)


        return Response({
            'results': serializer.data,
        })
    
    def put(self, request, *args, **kwargs):
        try:
            ex_commitee_id = self.request.query_params.get('ex_commitee_id', None)
            action_status = self.request.query_params.get('action_status', None)

            ex_details = TenderExecutiveCommitee.objects.filter(id=ex_commitee_id).first()
            tender_details = TenderMaster.objects.filter(id=ex_details.tender_id).first()

            tender_data_details = TenderData.objects.filter(tender=tender_details, \
                                                                    form__form_internal_name='tender_id').first()
            
            end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)

            time_now = strftime("%d %b %Y %I:%M %p", localtime())

            with transaction.atomic():
                if action_status == 'approved':
                    user_id = request.data.get('user_id', None)
                    remarks = request.data.get('remarks', None)

                    commitee_member_details = TenderCommiteeMembers.objects.filter(ex_commitee_id=ex_commitee_id,\
                                                                                   users_id=user_id).first()
                    commitee_member_details.is_vga_approved = True
                    commitee_member_details.is_vga_reject = False
                    commitee_member_details.remarks = remarks
                    commitee_member_details.save()


                    log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                        activity="VGA Approved By " + \
                                                            str(end_user_name) + " at " + str(time_now), user=request.user)
                        
                    log_details.save()
                    
                    noti_create = NotificationMaster.objects.create(organization_id=tender_details.organization_id,\
                                                                    notification="Tender With Tender ID " + str(tender_data_details.value) + " VGA Approved By " + \
                                                            str(end_user_name) + " at " + str(time_now), is_universal=True)
                    
                    noti_create.save()


                    tender_details.is_vga_approved = True
                    tender_details.is_assignment_active = True
                    tender_details.is_resend_for_recommendations = False
                    tender_details.tender_vga_approval_date = date.today()
                    tender_details.save()

                    user_emails = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user__username', flat=True).distinct())
                   
                    subject = "Tender With Tender ID " + str(tender_data_details.value) + " VGA Approved"

                    notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " VGA Approved By " + str(end_user_name) + " at " + str(time_now) + "\n" + "Remarks : " + str(remarks)
                    user_ids = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user_id', flat=True).distinct())
                    
                    trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                    # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

                
                elif action_status == 'reject':
                    user_id = request.data.get('user_id', None)
                    remarks = request.data.get('remarks', None)

                    commitee_member_details = TenderCommiteeMembers.objects.filter(ex_commitee_id=ex_commitee_id,\
                                                                                   users_id=user_id).first()
                    commitee_member_details.is_vga_approved = False
                    commitee_member_details.is_vga_reject = True
                    commitee_member_details.remarks = remarks
                    tender_details.tender_vga_rejected_date = date.today()
                    commitee_member_details.save()


                    log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                        activity="VGA Rejected By " + \
                                                            str(end_user_name) + " at " + str(time_now), user=request.user)
                        
                    log_details.save()
                    
                    noti_create = NotificationMaster.objects.create(organization_id=tender_details.organization_id,\
                                                                    notification="Tender With Tender ID " + str(tender_data_details.value) + " VGA Rejected By " + \
                                                            str(end_user_name) + " at " + str(time_now), is_universal=True)
                    
                    noti_create.save()


                    tender_details.is_vga_reject = True
                    tender_details.save()

                    user_emails = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user__username', flat=True).distinct())
                    
                    subject = "Tender With Tender ID " + str(tender_data_details.value) + " VGA Rejected"

                    notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " VGA Rejected By " + \
                                                            str(end_user_name) + " at " + str(time_now) + "\n" + "Remarks : " + str(remarks)

                    user_ids = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user_id', flat=True).distinct())
                    
                    trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                    # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})



                # total_commitee_members = TenderCommiteeMembers.objects.filter(ex_commitee_id=ex_commitee_id).count()
                # approval_commitee_members = TenderCommiteeMembers.objects.filter(ex_commitee_id=ex_commitee_id,\
                #                                                                  is_vga_approved=True).count()
                
                # if int(total_commitee_members) == int(approval_commitee_members):

                #     tender_details.is_vga_approved = True
                #     tender_details.save()

                #     from administrations.utils import send_notification_mail
                #     from user_permissions.models import UserWiseModulePermissions

                #     user_emails = list(UserWiseModulePermissions.objects.filter(\
                #         level_permission=True).values_list('user__username', flat=True).distinct())
                    
                #     subject = "Tender With Tender ID " + str(tender_data_details.value) + " VGA Approved"

                #     notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " VGA Approved"

                #     schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

                    
            serializer = TenderExecutiveCommiteeMembersSerializer(commitee_member_details)

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Status Updated',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        


class TenderExecutiveCommiteeMembersResendActionAPIView(APIView):
    """
    Resend API for Executive Commitee Formation
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            ex_commitee_id = self.request.query_params.get('ex_commitee_id', None)

            tender_ex_details = TenderExecutiveCommitee.cmobjects.filter(id=ex_commitee_id).first()

            tender_details = TenderMaster.cmobjects.filter(id=tender_ex_details.tender_id).first()

            if tender_details.is_approved == True:
                return Response({'msg': 'Selected Tender is already Approved',
                                    'status':status.HTTP_500_INTERNAL_SERVER_ERROR,    
                                    "request_status": 1})
            
            if tender_details.is_reject == True:
                return Response({'msg': 'Selected Tender is already Rejected',
                                    'status':status.HTTP_500_INTERNAL_SERVER_ERROR,    
                                    "request_status": 1})
            
            if tender_details.is_vga_approved == True:
                return Response({'msg': 'Selected Tender VGA already Done',
                                    'status':status.HTTP_500_INTERNAL_SERVER_ERROR,    
                                    "request_status": 1})
            
            if tender_details.is_vga_reject == True:
                return Response({'msg': 'Selected Tender VGA already Rejected',
                                    'status':status.HTTP_500_INTERNAL_SERVER_ERROR,    
                                    "request_status": 1})

            with transaction.atomic():

                if TenderCommiteeMembers.objects.filter(ex_commitee=tender_ex_details).exists():
                    TenderCommiteeMembers.objects.filter(ex_commitee=tender_ex_details).delete()

                
                tender_ex_details.is_deleted = True
                tender_ex_details.save()


                tender_details.is_sent_for_approval = False
                tender_details.is_approved = False
                tender_details.is_reject = False
                tender_details.is_vga_approved = False
                tender_details.is_vga_reject = False
                tender_details.save()
                    

            return Response({'msg': 'Executive Commitee Formation Resend Request Send',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        


class TopSheetSaleDataAPI(APIView):
    """
    TopSheet Sale Data API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender wbs
        """
        id = self.request.query_params.get('id', None)
        if id:
            wbs_details = TopSheetSaleData.cmobjects.filter(id = id).first()
            serializer = TopSheetSaleDataSerializer(wbs_details)
            return Response(serializer.data)

        tender_id = self.request.query_params.get('tender_id', None)
        wbs_list = TopSheetSaleData.cmobjects.filter(tender_id = tender_id).order_by('id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        serializer = TopSheetSaleDataSerializer(page, many=True)
        # serializer = CompanySerializer(company_list, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def put(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                tender_id = self.request.data.get('tender_id', None)
                wbskey_id = self.request.data.get('wbskey_id', None)
                form_id = self.request.data.get('form_id', None)
                value = self.request.data.get('value', None)

                instance = TopSheetSaleData.objects.update_or_create(tender_id=tender_id, wbskey_id=wbskey_id,\
                                                                                form_id=form_id, defaults={"value" : value})

                sale_data = TopSheetSaleData.objects.filter(tender_id=tender_id, wbskey_id=wbskey_id, form_id=form_id).first()

                serializer = TopSheetSaleDataSerializer(sale_data)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Updated Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class TopSheetExpenditureDataAPI(APIView):
    """
    TopSheet Sale Data API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender wbs
        """
        id = self.request.query_params.get('id', None)
        if id:
            wbs_details = TopSheetExpenditureData.cmobjects.filter(id = id).first()
            serializer = TopSheetExpenditureDataSerializer(wbs_details)
            return Response(serializer.data)

        tender_id = self.request.query_params.get('tender_id', None)
        wbs_list = TopSheetExpenditureData.cmobjects.filter(tender_id = tender_id).order_by('id')

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(wbs_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        serializer = TopSheetExpenditureDataSerializer(page, many=True)
        # serializer = CompanySerializer(company_list, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def put(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                tender_id = self.request.data.get('tender_id', None)
                wbskey_id = self.request.data.get('wbskey_id', None)
                form_id = self.request.data.get('form_id', None)
                value = self.request.data.get('value', None)

                instance = TopSheetExpenditureData.objects.update_or_create(tender_id=tender_id, wbskey_id=wbskey_id,\
                                                                                form_id=form_id, defaults={"value" : value})
                
                expenditure_data = TopSheetExpenditureData.objects.filter(tender_id=tender_id, wbskey_id=wbskey_id, form_id=form_id).first()

                serializer = TopSheetExpenditureDataSerializer(expenditure_data)


            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Updated Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        

class TopSheetSaleNExpenditureDataAPI(APIView):
    """
    TopSheet Sale Data API View
    """
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender wbs
        """
        tender_id = self.request.query_params.get('tender_id', None)

        sale_total = TopSheetSaleData.objects.filter(form__form_internal_name="sale_value", \
                                                     tender_id=tender_id).annotate(values_int=Cast('value', \
                                                        IntegerField())).aggregate(
                                                            the_sum=Coalesce(Sum('values_int'), Value(0)))['the_sum']
        
        expenditure_total = TopSheetExpenditureData.objects.filter(form__form_internal_name="expenditure_value", \
                                                     tender_id=tender_id).annotate(values_int=Cast('value', \
                                                        IntegerField())).aggregate(
                                                            the_sum=Coalesce(Sum('values_int'), Value(0)))['the_sum']


        return Response({
            "sale_total" : sale_total,
            "expenditure_total" : expenditure_total
        })
    


class TopSheetFinalSubmissionDataAPI(APIView):
    """
    TopSheet Final Approval Action VIew
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                remarks = self.request.data.get('remarks', None)
                tender_id = self.request.data.get('tender_id', None)

                tender_details = TenderMaster.objects.filter(id=tender_id).first()

                tender_details.is_top_sheet_complete = True
                tender_details.is_final_approval_active = True
                tender_details.is_sent_for_final_approval = True
                tender_details.top_sheet_remarks = remarks
                tender_details.tender_final_approval_send_date = date.today()
                tender_details.save()


            return Response({'msg': 'Tender Top Sheet Submitted Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
    



############################################ Tender Approval Procedure Stats Here #########################

class TenderExecutiveCommiteeFinalApprovalAPIView(APIView):
    """
    CRUD API for TenderExecutiveCommitee model(**** For Final Approval)
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all TenderExecutiveCommitee
        """
        user_id = request.user.id

        id = self.request.query_params.get('id', None)
        if id:
            user_type = TenderExecutiveCommitee.cmobjects.filter(id=id).first()
            serializer = TenderExecutiveCommiteeFinalApprovalSerializer(user_type, context={"user_id" : user_id})
            return Response(serializer.data)

        tender_id = self.request.query_params.get(
            'tender_id', None)
        
        employeement_type = TenderExecutiveCommitee.cmobjects.filter(
            tender_id=tender_id).order_by('id')

        serializer = TenderExecutiveCommiteeFinalApprovalSerializer(employeement_type, many=True, context={"user_id" : user_id})


        return Response({
            'results': serializer.data,
        })
    
    def put(self, request, *args, **kwargs):
        try:
            tender_id = self.request.query_params.get('tender_id', None)

            tender_details = TenderMaster.objects.filter(id=tender_id).first()

            with transaction.atomic():
                group_id = request.data.get('group_id', None)
                user_ids = request.data.get('user_ids', [])
                tender_ex_details = TenderExecutiveCommitee.cmobjects.filter(tender_id=tender_id).first()
                
                if not tender_ex_details:
                    tender_ex_details = TenderExecutiveCommitee.objects.create(tender_id=tender_id, groups_id=group_id)
                    tender_ex_details.save()
                else:
                    tender_ex_details.groups_id = group_id
                    tender_ex_details.save()

                user_emails = []

                for item in user_ids:

                    TenderCommiteeMembers.objects.update_or_create(ex_commitee=tender_ex_details, users_id=item.get('user_id', None),\
                                                                            defaults={"level" : item.get('level', None), \
                                                                             "commitee_level" : item.get('commitee_level', None)})

                    us_details = PmsUser.objects.filter(id=item.get('user_id', None)).first()
                    user_emails.append(us_details.username)

                    time_now = strftime("%d %b %Y %I:%M %p", localtime())

                    tender_data_details = TenderData.objects.filter(tender_id=tender_details, \
                                                                form__form_internal_name='tender_id').first()
                
                    noti_create = NotificationMaster.objects.create(organization_id=tender_details.organization_id,\
                                                                    notification="Tender With Tender ID " + str(tender_data_details.value) \
                                                                        + " Is Sent for Final Approval To you at " + str(time_now), notified_users=us_details)
                    
                    noti_create.save()

                TenderMaster.objects.filter(id=tender_id).update(is_sent_for_final_approval=True, \
                                                                 tender_final_approval_send_date=date.today())
                
                subject = "Tender With Tender ID " + str(tender_data_details.value) + " is Sent for Final Approval"

                notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " is Sent for Final Approval to you at " + str(time_now)
                
                trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

                

            serializer = TenderExecutiveCommiteeFinalApprovalSerializer(tender_ex_details, context={"user_id" : request.user.id})

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Tender Executive Commitee Created For Tender Final Approval',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        



class TenderExecutiveCommiteeMembersFinalApprovalAPIView(APIView):
    """
    CRUD API for TenderExecutiveCommitee model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all TenderExecutiveCommitee
        """
        ex_commitee_id = self.request.query_params.get(
            'ex_commitee_id', None)
        
        members_list = TenderCommiteeMembers.cmobjects.filter(
            ex_commitee_id=ex_commitee_id).order_by('id')

        serializer = TenderExecutiveCommiteeMembersFinalApprovalSerializer(members_list, many=True)


        return Response({
            'results': serializer.data,
        })
    
    def put(self, request, *args, **kwargs):
        try:
            ex_commitee_id = self.request.query_params.get('ex_commitee_id', None)
            action_status = self.request.query_params.get('action_status', None)

            ex_details = TenderExecutiveCommitee.objects.filter(id=ex_commitee_id).first()
            tender_details = TenderMaster.objects.filter(id=ex_details.tender_id).first()

            tender_data_details = TenderData.objects.filter(tender=tender_details, \
                                                                    form__form_internal_name='tender_id').first()
            
            end_user_name = str(request.user.first_name) + " " + str(request.user.last_name)

            time_now = strftime("%d %b %Y %I:%M %p", localtime())

            with transaction.atomic():
                if action_status == 'approved':
                    user_id = request.data.get('user_id', None)
                    remarks = request.data.get('remarks', None)

                    commitee_member_details = TenderCommiteeMembers.objects.filter(ex_commitee_id=ex_commitee_id,\
                                                                                   users_id=user_id).first()
                    commitee_member_details.is_approved = True
                    commitee_member_details.is_reject = False
                    commitee_member_details.approval_remarks = remarks
                    commitee_member_details.save()


                    log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                        activity="Tender Approved By " + \
                                                            str(end_user_name) + " at " + str(time_now), user=request.user)
                        
                    log_details.save()
                    
                    noti_create = NotificationMaster.objects.create(organization_id=tender_details.organization_id,\
                                                                    notification="Tender With Tender ID " + str(tender_data_details.value) + " Approved By " + \
                                                            str(end_user_name) + " at " + str(time_now), is_universal=True)
                    
                    noti_create.save()

                    user_emails = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user__username', flat=True).distinct())
                    
                    subject = "Tender With Tender ID " + str(tender_data_details.value) + " Approved By " + str(end_user_name)

                    notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " Approved By " + str(end_user_name) + " at " + str(time_now) + "\n" + "Remarks : " + str(remarks)

                    user_ids = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user_id', flat=True).distinct())
                    
                    trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                    # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

                
                elif action_status == 'reject':
                    user_id = request.data.get('user_id', None)
                    remarks = request.data.get('remarks', None)

                    commitee_member_details = TenderCommiteeMembers.objects.filter(ex_commitee_id=ex_commitee_id,\
                                                                                   users_id=user_id).first()
                    commitee_member_details.is_approved = False
                    commitee_member_details.is_reject = True
                    commitee_member_details.rejection_remarks = remarks
                    commitee_member_details.save()


                    log_details = TenderActivityLog.objects.create(tender=tender_details, \
                                                        activity="Tender Rejected By " + \
                                                            str(end_user_name) + " at " + str(time_now), user=request.user)
                        
                    log_details.save()
                    
                    noti_create = NotificationMaster.objects.create(organization_id=tender_details.organization_id,\
                                                                    notification="Tender With Tender ID " + str(tender_data_details.value) + " Rejected By " + \
                                                            str(end_user_name) + " at " + str(time_now), is_universal=True)
                    
                    noti_create.save()


                    tender_details.is_reject = True
                    tender_details.tender_rejected_date = date.today()
                    tender_details.save()

                    user_emails = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user__username', flat=True).distinct())
                    
                    subject = "Tender With Tender ID " + str(tender_data_details.value) + " Rejected"

                    notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " Rejected By " + \
                                                            str(end_user_name) + " at " + str(time_now) + "\n" + "Remarks : " + str(remarks)

                    user_ids = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user_id', flat=True).distinct())
                    
                    trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                    # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})




                total_commitee_members = TenderCommiteeMembers.objects.filter(ex_commitee_id=ex_commitee_id).count()
                approval_commitee_members = TenderCommiteeMembers.objects.filter(ex_commitee_id=ex_commitee_id,\
                                                                                 is_approved=True).count()
                
                if int(total_commitee_members) == int(approval_commitee_members):

                    tender_details.is_approved = True
                    tender_details.tender_approval_date = date.today()
                    tender_details.is_submission_active = True
                    tender_details.save()

                    user_emails = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user__username', flat=True).distinct())
                    
                    subject = "Tender With Tender ID " + str(tender_data_details.value) + " Is Approved"

                    notification_text = "Tender With Tender ID " + str(tender_data_details.value) + " Is Approved"

                    user_ids = list(UserWiseModulePermissions.objects.filter(\
                        level_permission=True).values_list('user_id', flat=True).distinct())
                    
                    trigger_notifications(subject=subject, user_list=user_ids,context={'notification_text ': notification_text})

                    # schedule_generic_mail(subject=subject, to_mail_list=user_emails, context={'notification_text ': notification_text})

                    
            serializer = TenderExecutiveCommiteeMembersFinalApprovalSerializer(commitee_member_details)

            return Response({'results':{
                                    'Data':serializer.data,
                                    },
                                    'msg': 'Status Updated',
                                    'status':status.HTTP_200_OK,    
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        



############################# Survey Action APIs ##############################


class TopSheetStartSurveyDataAPI(APIView):
    """
    TopSheet Final Approval Action VIew
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                tender_id = self.request.data.get('tender_id', None)

                tender_details = TenderMaster.objects.filter(id=tender_id).first()

                tender_details.is_survey_started = True
                tender_details.survey_started_date = date.today()
                tender_details.save()


            return Response({'msg': 'Tender Survey Started Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class FormGroupActiveStatusCheckForSurveyAPI(APIView):
    """
    Tender Survey Form Group Active Check(*** Specifically for Mobile App, Note: This API shoul be called only once for each group and each tender)
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                tender_id = self.request.data.get('tender_id', None)
                form_group_id = self.request.data.get('form_group_id', None)

                survey_form_status = TenderSurveyFormGroupCompletion.objects.update_or_create(tender_id=tender_id, form_group_id=form_group_id,\
                                                                                              defaults={"is_completed" : True, "completion_date" : date.today(),\
                                                                                                        "completed_by" : request.user})
                


            return Response({'msg': 'Updated Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
        


class TenderCurrentSurveyAPIView(APIView):
    """
    API to fetch the tender id for user selected for survey completions
    """
    
    

    def get(self, request, format=None):
        """
        API to fetch the tender id for user selected for survey completions
        """
        user_id = request.user.id
        organization_id = self.request.query_params.get('organization_id', None)

        tender_ids = []

        # For Physical Fesibility Users
        dependent_form_id = FormDependentChoices.cmobjects.filter(option_id=user_id, \
                                                                      form__form_internal_name='select_members').first()
        
        
        tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='select_members')

        for item in tender_data_list:
            form_ids = ast.literal_eval(item.value)
            if dependent_form_id and dependent_form_id.id in form_ids:
                tender_ids.append(item.tender_id)

        # For Material rate Users
        material_rate_form_id = FormDependentChoices.cmobjects.filter(option_id=user_id, \
                                                                      form__form_internal_name='select_members_material').first()
        
        material_rate_tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='select_members_material')

        for mat in material_rate_tender_data_list:
            form_ids = ast.literal_eval(mat.value)
            if material_rate_form_id and material_rate_form_id.id in form_ids:
                tender_ids.append(mat.tender_id)

        # For Statutory and Taxation Users
        taxation_form_id = FormDependentChoices.cmobjects.filter(option_id=user_id, \
                                                                      form__form_internal_name='select_members_taxation').first()
        
        taxation_tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='select_members_taxation')

        for tax in taxation_tender_data_list:
            form_ids = ast.literal_eval(tax.value)
            if taxation_form_id and taxation_form_id.id in form_ids:
                tender_ids.append(tax.tender_id)


        # For Admin and Liasoning Users
        admin_form_id = FormDependentChoices.cmobjects.filter(option_id=user_id, \
                                                                      form__form_internal_name='select_members_liason').first()
        
        admin_tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='select_members_liason')

        for admin in admin_tender_data_list:
            form_ids = ast.literal_eval(admin.value)
            if admin_form_id and admin_form_id.id in form_ids:
                tender_ids.append(admin.tender_id)

        ongoing_tender_details = TenderMaster.cmobjects.filter(organization_id = organization_id,\
                                                                id__in=tender_ids, is_survey_started=True, \
                                                                    is_survey_complete=False).first()
        
        if ongoing_tender_details:
            tender_id = ongoing_tender_details.id
            msg = "Please Fill The Required Details"
            status_code = status.HTTP_200_OK
            request_status = 0
        else:
            tender_id = ""
            msg = "No Ongoing Tender Assigned To You!"
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            request_status = 1


        return Response({
            'tender_id': tender_id,
            'msg' : msg,
            'status': status_code,
            "request_status": request_status
        })



class TenderSurveyCompletionUserAssignedWiseAPI(APIView):
    """
    Tender Survey Final Completion Assigned Role WIse API VIew
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                import ast
                tender_id = self.request.data.get('tender_id', None)
                tender_details = TenderMaster.objects.filter(id=tender_id).first()
                user_id = request.user.id
                tender_data_form = TenderData.cmobjects.filter(form__form_internal_name='select_members',\
                                                       tender_id=tender_id).first()
                material_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_material',\
                                                            tender_id=tender_id).first()
                taxation_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_taxation',\
                                                            tender_id=tender_id).first()
                liason_rate_data = TenderData.cmobjects.filter(form__form_internal_name='select_members_liason',\
                                                            tender_id=tender_id).first()
                if tender_data_form:
                    form_ids = ast.literal_eval(tender_data_form.value)
                    physical_user_ids = list(FormDependentChoices.cmobjects.filter(option_id__in=form_ids, \
                                                                        form__form_internal_name='select_members').values_list('option_id', flat=True))
                else:
                    physical_user_ids = []

                if material_rate_data:
                    material_form_ids = ast.literal_eval(material_rate_data.value)
                    material_user_ids = list(FormDependentChoices.cmobjects.filter(option_id__in=material_form_ids, \
                                                                        form__form_internal_name='select_members_material').values_list('option_id', flat=True))
                else:
                    material_user_ids = []

                if taxation_rate_data:
                    taxation_form_ids = ast.literal_eval(taxation_rate_data.value)
                    taxation_user_ids = list(FormDependentChoices.cmobjects.filter(option_id__in=taxation_form_ids, \
                                                                        form__form_internal_name='select_members_taxation').values_list('option_id', flat=True))
                else:
                    taxation_user_ids = []

                if liason_rate_data:
                    liason_form_ids = ast.literal_eval(liason_rate_data.value)
                    liason_user_ids = list(FormDependentChoices.cmobjects.filter(option_id__in=liason_form_ids, \
                                                                        form__form_internal_name='select_members_liason').values_list('option_id', flat=True))
                else:
                    liason_user_ids = []

                if user_id in physical_user_ids:
                    tender_details.is_physical_survey_complete = True
                    tender_details.physical_survey_completion_date = date.today()
                    tender_details.save()

                if user_id in material_user_ids:
                    tender_details.is_material_survey_complete = True
                    tender_details.material_survey_completion_date = date.today()
                    tender_details.save()

                if user_id in taxation_user_ids:
                    tender_details.is_taxation_survey_complete = True
                    tender_details.taxation_survey_completion_date = date.today()
                    tender_details.save()

                if user_id in liason_user_ids:
                    tender_details.is_liason_survey_complete = True
                    tender_details.liason_survey_completion_date = date.today()
                    tender_details.save()

                # TODO testing required:
                # if request.user.is_superuser:
                #     tender_details.is_physical_survey_complete = True
                #     tender_details.physical_survey_completion_date = date.today()
                #
                #     tender_details.is_material_survey_complete = True
                #     tender_details.material_survey_completion_date = date.today()
                #
                #     tender_details.is_taxation_survey_complete = True
                #     tender_details.taxation_survey_completion_date = date.today()
                #
                #     tender_details.is_liason_survey_complete = True
                #     tender_details.liason_survey_completion_date = date.today()
                #     tender_details.save()




            return Response({'msg': 'Tender Survey Completed Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})




class TenderSurveyFinalCompletionAPI(APIView):
    """
    Tender Survey Final Completion API VIew
    """
    
    

    def put(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                tender_id = self.request.data.get('tender_id', None)

                tender_details = TenderMaster.objects.filter(id=tender_id).first()

                tender_details.is_survey_complete = True
                tender_details.is_top_sheet_active = True
                tender_details.survey_completed_date = date.today()
                tender_details.save()


            return Response({'msg': 'Tender Survey Completed Successfully',
                                    'status':status.HTTP_200_OK,
                                    "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class TenderChainageAPI(APIView):
    """
        CRUD API for model TenderChainage
    """
    
    

    def get(self, request):
        """
            Get a list TenderChainage
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = TenderChainage.cmobjects.filter(id=id).first()
            serializer = TenderChainageSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, [])

        _list = TenderChainage.cmobjects.filter(*search).order_by(str(order_by))
        if all == 'true':
            serializer = TenderChainageSerializer(_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderChainageSerializer(page, many=True)

        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new TenderChainage
        """
        request.data['created_by_id'] = request.user.id
        serializer = TenderChainageSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit TenderChainage
        """
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update
                """
                if TenderChainage.cmobjects.filter(pk=id).exists():
                    _details = TenderChainage.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = TenderChainageSerializer(_details, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete
                """
                if TenderChainage.cmobjects.filter(pk=id,).exists():
                    _details = TenderChainage.cmobjects.get(pk=id,)
                    _details.is_deleted = True
                    _details.save()

                    return Response({'results': {
                        'data': TenderChainage.objects.filter(pk=id,).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class UATDataFixAPI(APIView):
    
    

    def put(self, request, *args, **kwargs):
        try:
            resp_done = []
            resp_error = []
            with transaction.atomic():
                details = TenderWBSKeyScopes.cmobjects.all()
                for data in details:
                    if data.wbs:
                        temp = {
                            "pk": data.id,
                            "tender_id": data.wbs.tender.id if data.wbs.tender else None,
                            "category": data.wbs.category,
                            "parent_id": data.wbs.id,
                            "wbs_name": data.keyscope,
                            "uom_id": data.uom.id if data.uom else None,
                            "is_default": False,
                        }
                        if TenderWBS.cmobjects.filter(pk=temp["pk"]).exists():
                            resp_error.append(temp["pk"])
                        else:
                            resp_done.append(temp["pk"])
                            TenderWBS.cmobjects.create(**temp)
            return Response({'resp_error': resp_error,'resp_done': resp_done})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

class ExecutiveSummeryDataNewAPIView(APIView):
    
    

    def get(self, request, format=None):
        organization_id = request.query_params.get('organization_id', None)
        wbs__parent_id = request.query_params.get('wbs__parent_id', None)
        return_list = []
        return_list = get_all_child([wbs__parent_id],return_list)
        search = custom_filters(self.request, {}, ['organization_id','wbs__parent_id'])
        queryset = ExecutiveSummeryData.cmobjects.select_related(
            'tender','wbs','form'
        ).filter(
            wbs_id__in=return_list,tender__organization_id=organization_id,*search
        ).values(
            'id','wbs__wbs_name','wbs','wbs__parent_id_id','value','tender','form'
        )
        return Response(queryset)
       

class ChainageExecutiveSummeryDataAPIView(APIView):
    
    

    def get(self, request, format=None):
        organization_id = request.query_params.get('organization_id', None)
        search = custom_filters(self.request, {}, ['organization_id'])
        queryset = ChainageExecutiveSummeryData.cmobjects.filter(
            tender__organization_id=organization_id,*search
        )
        return_list = []
        parent_list = list(set(list(queryset.values_list('wbs_id', flat=True))))
        return_list = get_all_child(parent_list,return_list)
        queryset = ChainageExecutiveSummeryData.cmobjects.select_related(
            'tender','wbs','form'
        ).filter(wbs_id__in=return_list).values(
            'id','wbs__wbs_name','wbs','wbs__parent_id_id','value','tender','form','type'
        )
        return Response(queryset)
            
        
    def put(self, request, *args, **kwargs):
        try:
            tender_id = request.data.get('tender_id')
            wbs_id = request.data.get('wbs_id')
            form_id = request.data.get('form_id')
            value = request.data.get('value')
            type = request.data.get('type')

            tender = TenderMaster.objects.get(id=tender_id)
            wbs = TenderWBS.objects.get(id=wbs_id)
            instance, created = ChainageExecutiveSummeryData.objects.get_or_create(tender=tender, wbs=wbs, form_id=form_id, type=type)

            instance.value = value
            instance.save()

            serializer = ChainageExecutiveSummeryDataSerializer(instance)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except (TenderMaster.DoesNotExist, TenderWBS.DoesNotExist) as e:
            return Response({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class TenderWBSProjectAPI(APIView):
    
    

    def get(self, request, *args, **kwargs):
        """
        Get a list of all tender WBS projects
        """
        # Get query parameters
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            # Retrieve and serialize a single project by ID
            project_details = TenderWBSProject.objects.filter(id=id).first()
            serializer = TenderWBSProjectSerializer(project_details)
            return Response(serializer.data)

        tender_id = self.request.query_params.get('tender_id', None)
        wbs_id = self.request.query_params.get('wbs_id', None)
        category = self.request.query_params.get('category', None)
        is_master = self.request.query_params.get('is_master', None)
        is_parent_null = self.request.query_params.get('is_parent_null', None)
        remove_vendor = self.request.query_params.get('remove_vendor', None)
        only_vendor = self.request.query_params.get('only_vendor', None)
     
        search = custom_filters(self.request, {}, ['tender_id','remove_vendor','only_vendor','is_master','is_parent_null','remove_vendor','only_vendor'])

        search = custom_filters(self.request, {}, ['tender_id', 'wbs_id', 'category', 'is_master', 'is_parent_null'])

        if is_master:
            is_master = bool(int(is_master))
            project_list = TenderWBSProject.objects.filter(is_default=is_master, *search).order_by('by_order')
        else:
            project_list = TenderWBSProject.objects.filter(tender_id=tender_id, wbs_id=wbs_id, category=category, *search).order_by('by_order')

        if not is_parent_null:
            return_list = []
            parent_list = list(set(list(project_list.values_list('id', flat=True))))
            return_list = get_all_child(parent_list, return_list)
            project_list = TenderWBSProject.objects.filter(id__in=return_list).order_by('parent_id', 'by_order')

        if all == 'true':
            serializer = TenderWBSProjectSerializer(project_list, many=True)
            return Response(serializer.data)

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(project_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = TenderWBSProjectSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new tender WBS project
        """
        try:
            tender_id = self.request.data.get('tender_id', None)
            organization_id = self.request.data.get('organization_id', None)
            wbs_id = self.request.data.get('wbs_id', None)
            category = self.request.data.get('category', None)
            parent_id = self.request.data.get('parent_id', None)
            project_name = self.request.data.get('project_name', None)
            uom_id = self.request.data.get('uom_id', None)
            is_default = self.request.data.get('is_default', False)
            slug = self.request.data.get('slug', None)
            by_order = self.request.data.get('by_order', 1)
            boq_code = self.request.data.get('boq_code', None)
            boq_no = self.request.data.get('boq_no', None)
            is_master = self.request.query_params.get('is_master', None)
            if is_master:
                    is_master = bool(int(is_master))
                    project_create = TenderWBSProject.objects.create(
                    tender_id=tender_id,organization_id=organization_id,
                    wbs_id=wbs_id,
                    category=category,
                    parent_id=parent_id,
                    project_name=project_name,
                    uom_id=uom_id,
                    is_default=is_master,
                    slug=slug,
                    by_order=by_order,
                    boq_code=boq_code,
                    boq_no=boq_no
                )
            else:
                project_create = TenderWBSProject.objects.create(
                tender_id=tender_id,organization_id=organization_id,
                wbs_id=wbs_id,
                category=category,
                parent_id=parent_id,
                project_name=project_name,
                uom_id=uom_id,
                is_default=False,
                slug=slug,
                by_order=by_order,
                boq_code=boq_code,
                boq_no=boq_no
            )
          
            serializer = TenderWBSProjectSerializer(project_create)

            return Response({
                'data': serializer.data,
                'msg': 'Added Successfully',
                'status': status.HTTP_200_OK,
                "request_status": 0
            })

        except Exception as e:
            return Response({
                'request_status': 0,
                'msg': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, *args, **kwargs):
        try:
            method = self.request.query_params.get('method', None)
            project_id = self.request.query_params.get('project_id', None)

            if method.lower() == 'edit':
                with transaction.atomic():
                    tender_id = self.request.data.get('tender_id', None)
                    organization_id = self.request.data.get('organization_id', None)
                    wbs_id = self.request.data.get('wbs_id', None)
                    project_name = self.request.data.get('project_name', None)
                    category = self.request.data.get('category', None)
                    parent_id = self.request.data.get('parent_id', None)
                    uom_id = self.request.data.get('uom_id', None)
                    is_default = self.request.data.get('is_default', None)
                    slug = self.request.data.get('slug', None)
                    by_order = self.request.data.get('by_order', 1)
                    boq_code = self.request.data.get('boq_code', None)
                    boq_no = self.request.data.get('boq_no', None)
                    is_master = self.request.query_params.get('is_master', None)

                    if is_master:
                        is_master = bool(int(is_master))
                        project_obj, created = TenderWBSProject.objects.update_or_create(id=project_id,
                                                                                     defaults={"category": category,
                                                                                               "project_name": project_name,
                                                                                               "tender_id": tender_id,
                                                                                               'organization_id':organization_id,
                                                                                               "wbs_id": wbs_id,
                                                                                               "is_default": is_master,
                                                                                               "parent_id": parent_id,
                                                                                               "uom_id": uom_id,
                                                                                               "slug": slug,
                                                                                               "by_order": by_order,
                                                                                               "boq_code": boq_code,
                                                                                               "boq_no": boq_no})
                    else:
                         project_obj, created = TenderWBSProject.objects.update_or_create(id=project_id,
                                                                                     defaults={"category": category,
                                                                                               "project_name": project_name,
                                                                                               "tender_id": tender_id,
                                                                                               'organization_id':organization_id,
                                                                                               "wbs_id": wbs_id,
                                                                                               "is_default": is_default,
                                                                                               "parent_id": parent_id,
                                                                                               "uom_id": uom_id,
                                                                                               "slug": slug,
                                                                                               "by_order": by_order,
                                                                                               "boq_code": boq_code,
                                                                                               "boq_no": boq_no})   
            elif method.lower() == 'delete':
                project_details = TenderWBSProject.objects.filter(id=project_id).first()
                project_details.is_deleted = True
                project_details.save()

            project_details = TenderWBSProject.objects.filter(id=project_id).first()

            serializer = TenderWBSProjectSerializer(project_details)

            return Response({'results': {
                'Data': serializer.data,
            },
                'msg': 'Updated Successfully',
                'status': status.HTTP_200_OK,
                "request_status": 0})
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})    
        


class TopSheetMapAPIView(APIView):
    """Top Sheet Map CRUD API View"""
    def get(self, request):
        id = self.request.query_params.get('id', None)
        # organization_id = self.request.query_params.get('organization_id', None)
        all = self.request.query_params.get('all', None)

        if id:
            top_sheet_map = TopSheetMap.cmobjects.filter(id=id,).first()
            serializer = TopSheetMapSerializer(top_sheet_map)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])

        top_sheet_map_list = TopSheetMap.cmobjects.select_related('tender', 'parent')\
                                                .prefetch_related('wbs')\
                                                .filter(*search)\
                                                .order_by('-id')
        if all == 'true':
            serializer = TopSheetMapSerializer(top_sheet_map_list,many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(top_sheet_map_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = TopSheetMapSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    @transaction.atomic()
    def post(self, request):
        serializer = TopSheetMapSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            try:
                instance = serializer.save()
                instance.created_by = request.user
                instance.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    @transaction.atomic()
    def put(self, request, *args, **kwargs):
        id = self.request.query_params.get('id', None)
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)

        if method.lower() == 'edit':
            with transaction.atomic():
                if TopSheetMap.cmobjects.filter(pk=id, tender__organization_id=organization_id).exists():
                    top_sheet_map = TopSheetMap.objects.filter(pk=id).first()
                    serializer = TopSheetMapSerializer(top_sheet_map, data=request.data)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support.."})
        elif method.lower() == 'delete':
            with transaction.atomic():
                if TopSheetMap.cmobjects.filter(pk=id, tender__organization_id=organization_id).exists():
                    top_sheet_map = TopSheetMap.cmobjects.get(pk=id, tender__organization_id=organization_id)
                    top_sheet_map.is_deleted = True
                    top_sheet_map.save()

                    return Response({'results': {
                        'data': TopSheetMap.objects.filter(pk=id, tender__organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support.."})


class TopSheetMapReportAPIView(APIView):
    """Top Sheet Map CRUD API View"""

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)

        if id:
            top_sheet_map = TopSheetMap.cmobjects.filter(id=id, ).first()
            serializer = TopSheetMapSerializer2(top_sheet_map)
            return Response(serializer.data)

        search = custom_filters(self.request, {}, [])

        top_sheet_map_list = TopSheetMap.cmobjects.select_related('tender', 'parent') \
            .prefetch_related('wbs') \
            .filter(*search) \
            .order_by('-id')
        if all == 'true':
            serializer = TopSheetMapSerializer2(top_sheet_map_list, many=True)
            return Response({'results': serializer.data})

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(top_sheet_map_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = TopSheetMapSerializer2(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })




class TenderSectorAPIView(APIView):
    
    

    def get(self, request):
        all_param = request.query_params.get('all', None)
        organization_id = request.query_params.get('organization_id', None)
        full_name_query = request.query_params.get('users__full_name__icontains', None)

        # Start with base queryset
        queryset = TenderSector.cmobjects.all()

        # Filter by organization
        if organization_id:
            queryset = queryset.filter(organization_id=organization_id)

        # Handle full name search
        if full_name_query:
            # Annotate full name and filter
            queryset = queryset.annotate(
                user_full_name=Concat(
                    'users__first_name',
                    Value(' '),
                    'users__last_name',
                    output_field=models.CharField()
                )
            ).filter(user_full_name__icontains=full_name_query)
        else:
            # Apply other custom filters (skip full_name)
            search = custom_filters(self.request, {}, ['users__full_name__icontains'])
            if search:
                queryset = queryset.filter(*search)

        # Ensure unique TenderSector objects (critical after M2M join)
        queryset = queryset.distinct()

        # Final ordering
        queryset = queryset.order_by('-id')

        # Return all?
        if all_param == 'true':
            serializer = TenderSectorSerializer(queryset, many=True)
            return Response({'results': serializer.data})

        # Paginate
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = request.query_params.get('page', 1)
        page = paginator.get_page(page_number)

        serializer = TenderSectorSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    

    def post(self, request):
        request.data['created_by_id'] = request.user.id
        serializer = TenderSectorSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderSector.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderSector.cmobjects.filter(pk=id).first()

                    serializer = TenderSectorSerializer(details, data=request.data,
                                                          context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if TenderSector.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderSector.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()

                    return Response({'results': {
                        'details': TenderSector.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class TenderSubSectorAPIView(APIView):
    
    

    def get(self, request):
        all = self.request.query_params.get('all', None)
        search = custom_filters(self.request, {}, [])
        list_data = TenderSubSector.cmobjects.filter(*search).order_by('-id')

        if all == 'true':
            serializer = TenderSubSectorSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderSubSectorSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by_id'] = request.user.id
        serializer = TenderSubSectorSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderSubSector.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderSubSector.cmobjects.filter(pk=id).first()

                    serializer = TenderSubSectorSerializer(details, data=request.data,
                                                          context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                if TenderSubSector.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderSubSector.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()

                    return Response({'results': {
                        'details': TenderSubSector.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class TenderDashboardAPIView(APIView):
    
    

    def get(self, request):
        list_data = TenderMaster.cmobjects.filter().annotate(
            final_position=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='final_position'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            tender_project_cost__eligibility=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_project_cost__eligibility'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            tender_id=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_id'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            proposed_tender=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='proposed_tender'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            tender_name=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_name'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            submission_final_amount=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='submission_final_amount'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            submission__=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='submission__'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            tender_due_date=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_due_date'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            tender_domain=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_domain'
                ).values('tender').annotate(value=GroupConcat(
                    Subquery(
                    FormDropdownChoices.cmobjects.filter(
                        id=OuterRef('value'),
                    ).values('id').annotate(value=GroupConcat('option', distinct=True)).values('option')
                ))).values('value')
            ),
            tender_sector=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_sector'
                ).values('tender').annotate(value=GroupConcat(
                    Subquery(
                    TenderSector.cmobjects.filter(
                        id=OuterRef('value'),
                    ).values('id').annotate(value=GroupConcat('name', distinct=True)).values('name')
                ))).values('value')
            ),
            tender_sub_sector=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_sub_sector'
                ).values('tender').annotate(value=GroupConcat(
                    Subquery(
                    TenderSubSector.cmobjects.filter(
                        id=OuterRef('value'),
                    ).values('id').annotate(value=GroupConcat('name', distinct=True)).values('name')
                ))).values('value')
            ),
            state_tender=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='state_tender'
                ).values('tender').annotate(value=GroupConcat(
                    Subquery(
                    State.objects.filter(
                        state_id=OuterRef('value'),
                    ).values('state_id').annotate(value=GroupConcat('name', distinct=True)).values('name')
                ))).values('value')
            ),
            participations_mode=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='participations_mode'
                ).values('tender').annotate(value=GroupConcat(
                    Subquery(
                    FormDropdownChoices.cmobjects.filter(
                        id=OuterRef('value'),
                        form__form_internal_name='participations_mode'
                    ).values('form').annotate(value=GroupConcat('option', distinct=True)).values('option')
                ))).values('value')
            ),
            selected_as_l1=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='selected_as_l1'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            agreement_signed=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='agreement_signed'
                ).values('tender').annotate(value=GroupConcat(
                    Subquery(
                    FormDropdownChoices.cmobjects.filter(
                        id=OuterRef('value'),
                        form__form_internal_name='agreement_signed'
                    ).values('form').annotate(value=GroupConcat('option', distinct=True)).values('option')
                ))).values('value')
            ),
            ref_status=Case(
                When(Q(is_l1=True) | Q(is_l1_complete = True), then=Value(14)),
                When(Q(is_not_l1=True) | Q(is_not_l1_complete = True), then=Value(13)),
                When(is_submission_complete=True, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(12)),
                When(is_reject=True, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(11)),
                When(is_approved=True, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(10)),
                When(is_sent_for_final_approval=True, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(9)),
                When(is_survey_complete=True, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(8)),
                When(is_survey_started=True, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(7)),
                When(is_assignment_complete=True, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(6)),
                When(is_vga_reject=True, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(5)),
                When(is_vga_approved=True, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(4)),
                When(is_sent_for_approval=True, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(3)),
                When(is_recommended=True, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(2)),
                When(is_sent_for_recommendation=True, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(1)),
                When(is_eligibility_complete_for_proposer=True, is_sent_for_recommendation=False, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(0.5)),
                When(is_eligibility_complete_for_proposer=False, is_sent_for_recommendation=False, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(0)),
                default=Value(-1),
                output_field=fields.FloatField(),
            ),
        ).values()
        # all_status_list = {
        #     # "-1": ["", ""],
        #     "0": ["Identified", "identified"],
        #     "1": ["Proposed", "proposed"],
        #     "2": ["Recommended", "recommended"],
        #     # "3": ["Recommended and Waiting For Approval", ""],
        #     # "4": ["VGA Done", ""],
        #     # "5": ["VGA Rejected", ""],
        #     # "6": ["Members Assigned For Survey", ""],
        #     # "7": ["Survey Started and In Progress", ""],
        #     "8": ["Survey Completed", "survey_completed"],
        #     # "9": ["Tender is Send For Approval", ""],
        #     "10": ["Approved", "approved"],
        #     # "11": ["Rejected", ""],
        #     # "12": ["Tender Submitted", ""],
        #     "13": ["Not-Awarded", "not_selected_as_l1"],
        #     "14": ["Awarded", "selected_as_l1"],
        #     "15": ["Agreement Not Signed", "agreement_not_signed"],
        #     "16": ["Agreement Signed", "agreement_signed"],
        # }
        all_status_list = {
            # "-1": ["", ""],
            "0": ["Identified", "identified"],
            "0.5": ["Proposed but not sent for recommendation", "proposed_but_not_recommended"],
            "1": ["Proposed", "proposed"],
            "2": ["Recommended", "recommended"],
            "3": ["Recommended and Waiting For Approval", "recommended_and_waiting_for_approval"],
            "4": ["VGA Done", "vga_done"],
            "5": ["VGA Rejected", "vga_rejected"],
            "6": ["Members Assigned For Survey", "members_assigned_for_survey"],
            "7": ["Survey Started and In Progress", "survey_started_and_in_progress"],
            "8": ["Survey Completed", "survey_completed"],
            "9": ["Tender is Send For Approval", "tender_is_send_for_approval"],
            "10": ["Approved", "approved"],
            "11": ["Rejected", "rejected"],
            "12": ["Tender Submitted", "tender_submitted"],
            "13": ["Not-Awarded", "not_selected_as_l1"],
            "14": ["Awarded", "selected_as_l1"],
        }
        # resp = {
        #     'all_status_list': all_status_list,
        #     'total_tender_count': list_data.filter().count(),
        #     'total_standalone_count': list_data.filter(is_deleted=False,participations_mode='Standalone').count(),
        #     'total_jv_count': list_data.filter(is_deleted=False,participations_mode='JV').count(),
        #     'total_active_count': list_data.filter(is_deleted=False,status=int(12)).count(),
        #     'total_upcoming_count': list_data.filter(is_deleted=False,status=int(1)).count(),
        #     'total_l1_count': list_data.filter(is_deleted=False,selected_as_l1="true").count(),
        #     'total_tender_value_by_status': {status : list_data.filter(is_deleted=False,status=int(status)).values('ref_status').order_by('ref_status').annotate(tender_project_cost__eligibility=Sum('tender_project_cost__eligibility')).values_list('tender_project_cost__eligibility',flat=True) for status in all_status_list.keys()},
        #     'total_tender_value_by_status_inclusive': {status : list_data.filter(is_deleted=False,status__gte=int(status)).values('ref_status').order_by('ref_status').annotate(tender_project_cost__eligibility=Sum('tender_project_cost__eligibility')).values_list('tender_project_cost__eligibility',flat=True) for status in all_status_list.keys()},
        #     'total_tender_count_by_status': {status : list_data.filter(is_deleted=False,status=int(status)).values('ref_status').order_by('ref_status').annotate(tender_project_cost__eligibility=Count('tender_project_cost__eligibility')).values_list('tender_project_cost__eligibility',flat=True) for status in all_status_list.keys()},
        #     'total_tender_count_by_status_inclusive': {status : list_data.filter(is_deleted=False,status__gte=int(status)).values('ref_status').order_by('ref_status').annotate(tender_project_cost__eligibility=Count('tender_project_cost__eligibility')).values_list('tender_project_cost__eligibility',flat=True) for status in all_status_list.keys()},
        #     'recent_activity_tracker': list_data.filter(is_deleted=False,status__in=all_status_list.keys()).order_by('-created_at')[:10],
        #     'top_tender_value_by_status': {status : list_data.filter(is_deleted=False,status=int(status)).order_by('-tender_project_cost__eligibility')[:5] for status in all_status_list.keys()},
        #     'top_tender_value_by_status_inclusive': {status : list_data.filter(is_deleted=False,status__gte=int(status)).order_by('-tender_project_cost__eligibility')[:5] for status in all_status_list.keys()},
        # }
        list_data = pd.DataFrame(list_data)
        list_data = list_data.fillna(np.nan).replace([np.nan], [None])
        recent_activity_tracker = list_data.where(list_data['ref_status'].apply(str).isin(all_status_list.keys())).sort_values(by='created_at', ascending=False, na_position='last').head(10)
        recent_activity_tracker = recent_activity_tracker.fillna(np.nan).replace([np.nan], [None])
        total_tender_value_by_status = {}
        total_tender_value_by_status_inclusive = {}
        total_tender_count_by_status = {}
        total_tender_count_by_status_inclusive = {}
        top_tender_value_by_status = {}
        top_tender_value_by_status_inclusive = {}
        for status in all_status_list.keys():
            top_tender_value_by_status_temp = list_data.where(list_data['ref_status']==float(status)).sort_values(by='tender_project_cost__eligibility', ascending=False, na_position='last').dropna(how='all').head(5)
            top_tender_value_by_status_inclusive_temp = list_data.where(list_data['ref_status']>=float(status)).sort_values(by='tender_project_cost__eligibility', ascending=False, na_position='last').dropna(how='all').head(5)
            top_tender_value_by_status_temp = top_tender_value_by_status_temp.fillna(np.nan).replace([np.nan], [None])
            top_tender_value_by_status_inclusive_temp = top_tender_value_by_status_inclusive_temp.fillna(np.nan).replace([np.nan], [None])
            total_tender_value_by_status[status] = [pd.to_numeric(list_data.where(list_data['ref_status']==float(status))['tender_project_cost__eligibility'], errors='coerce').sum()]
            total_tender_value_by_status_inclusive[status] = [pd.to_numeric(list_data.where(list_data['ref_status']>=float(status))['tender_project_cost__eligibility'], errors='coerce').sum()]
            total_tender_count_by_status[status] = [list_data.where(list_data['ref_status']==float(status))[list_data.columns[0]].count()]
            total_tender_count_by_status_inclusive[status] = [list_data.where(list_data['ref_status']>=float(status))[list_data.columns[0]].count()]
            top_tender_value_by_status[status] = top_tender_value_by_status_temp.to_dict('records')
            top_tender_value_by_status_inclusive[status] = top_tender_value_by_status_inclusive_temp.to_dict('records')
        resp = {
            'all_status_list': all_status_list,
            'total_tender_count': list_data[list_data.columns[0]].count(),
            'total_standalone_count': list_data.where(list_data['participations_mode']=='Standalone')[list_data.columns[0]].count(),
            'total_jv_count': list_data.where(list_data['participations_mode']=='JV')[list_data.columns[0]].count(),
            'total_active_count': total_tender_count_by_status['12'][0],
            'total_upcoming_count': total_tender_count_by_status['1'][0],
            'total_l1_count': total_tender_count_by_status['14'][0],
            'total_tender_value_by_status': total_tender_value_by_status,
            'total_tender_value_by_status_inclusive': total_tender_value_by_status_inclusive,
            'total_tender_count_by_status': total_tender_count_by_status,
            'total_tender_count_by_status_inclusive': total_tender_count_by_status_inclusive,
            'recent_activity_tracker': recent_activity_tracker.to_dict('records'),
            'top_tender_value_by_status': top_tender_value_by_status,
            'top_tender_value_by_status_inclusive': top_tender_value_by_status_inclusive,
        }
        resp['win_rate'] = float((float(total_tender_count_by_status['14'][0])/float(float(total_tender_count_by_status['14'][0])+float(total_tender_count_by_status['13'][0])+float(total_tender_count_by_status['12'][0])))*100)

        return Response({
            'results': resp,
        })


class TenderReportAPIView(APIView):
    
    

    def get(self, request):
        try:
            list_data = TenderMaster.cmobjects.prefetch_related('tenderbidder_tender_id','tender_data_form_masters').annotate(
                final_position=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='final_position'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                submission_date=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='submission_date'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                party_name_percentage_share=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='party_name_percentage_share'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                place=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='place'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                bg_required_on=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='bg_required_on'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                bg_value_pre_feasibility=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='bg_value_pre_feasibility'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                employer=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='employer'
                    ).values('tender').annotate(value=GroupConcat(
                        Subquery(
                        EMPLOYEEMASTER.cmobjects.filter(
                            id=OuterRef('value'),
                        ).values('id').annotate(value=GroupConcat('employee_name', distinct=True)).values('employee_name')
                    ))).values('value')
                ),
                tender_identification_remarks=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_identification_remarks'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                tender_project_cost__eligibility=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_project_cost__eligibility'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                tender_id=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_id'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                proposed_tender=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='proposed_tender'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                tender_name=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_name'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                submission_final_amount=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='submission_final_amount'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                submission__=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='submission__'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                tender_due_date=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_due_date'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                tender_domain=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_domain'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                tender_sector_id=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_sector'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                tender_sector=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_sector'
                    ).values('tender').annotate(value=GroupConcat(
                        Subquery(
                        TenderSector.cmobjects.filter(
                            id=OuterRef('value'),
                        ).values('id').annotate(value=GroupConcat('name', distinct=True)).values('name')
                    ))).values('value')
                ),
                tender_sub_sector=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='tender_sub_sector'
                    ).values('tender').annotate(value=GroupConcat(
                        Subquery(
                        TenderSubSector.cmobjects.filter(
                            id=OuterRef('value'),
                        ).values('id').annotate(value=GroupConcat('name', distinct=True)).values('name')
                    ))).values('value')
                ),
                state_tender=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='state_tender'
                    ).values('tender').annotate(value=GroupConcat(
                        Subquery(
                        State.objects.filter(
                            state_id=OuterRef('value'),
                        ).values('state_id').annotate(value=GroupConcat('name', distinct=True)).values('name')
                    ))).values('value')
                ),
                participations_mode=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='participations_mode'
                    ).values('tender').annotate(value=GroupConcat(
                        Subquery(
                        FormDropdownChoices.cmobjects.filter(
                            id=OuterRef('value'),
                            form__form_internal_name='participations_mode'
                        ).values('form').annotate(value=GroupConcat('option', distinct=True)).values('option')
                    ))).values('value')
                ),
                selected_as_l1=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='selected_as_l1'
                    ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
                ),
                agreement_signed=Subquery(
                    TenderData.cmobjects.filter(
                        tender_id=OuterRef('pk'),
                        form__form_internal_name='agreement_signed'
                    ).values('tender').annotate(value=GroupConcat(
                        Subquery(
                        FormDropdownChoices.cmobjects.filter(
                            id=OuterRef('value'),
                            form__form_internal_name='agreement_signed'
                        ).values('form').annotate(value=GroupConcat('option', distinct=True)).values('option')
                    ))).values('value')
                ),
                ref_status=Case(
                    When(Q(is_l1=True) | Q(is_l1_complete = True), then=Value(14)),
                    When(Q(is_not_l1=True) | Q(is_not_l1_complete = True), then=Value(13)),
                    When(is_submission_complete=True, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(12)),
                    When(is_reject=True, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(11)),
                    When(is_approved=True, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(10)),
                    When(is_sent_for_final_approval=True, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(9)),
                    When(is_survey_complete=True, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(8)),
                    When(is_survey_started=True, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(7)),
                    When(is_assignment_complete=True, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(6)),
                    When(is_vga_reject=True, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(5)),
                    When(is_vga_approved=True, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(4)),
                    When(is_sent_for_approval=True, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(3)),
                    When(is_recommended=True, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(2)),
                    When(is_sent_for_recommendation=True, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(1)),
                    When(is_eligibility_complete_for_proposer=True, is_sent_for_recommendation=False, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(0.5)),
                    When(is_eligibility_complete_for_proposer=False, is_sent_for_recommendation=False, is_recommended=False, is_sent_for_approval=False, is_vga_approved=False, is_vga_reject=False, is_assignment_complete=False, is_survey_started=False, is_survey_complete=False, is_sent_for_final_approval=False, is_reject=False, is_approved=False, is_submission_complete=False, is_l1=False, is_l1_complete=False, is_not_l1=False, is_not_l1_complete=False, then=Value(0)),
                    default=Value(-1),
                    output_field=fields.FloatField(),
                ),
            )
            resp = {}
            for filter_name, filter_value in request.query_params.items():
                resp[filter_name] = list_data.filter(*process_filters_response(json.loads(filter_value))).values()
            return Response({
                'results': resp,
            })
        except Exception as e:
            print(f"ERROR {e}")
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class TenderWBSImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                file = request.data['file']
                path = 'media/excel/' + file.name
                if not os.path.exists('media/excel'):
                    os.makedirs('media/excel')
                with open(path, 'wb+') as destination:
                    for chunk in file.chunks():
                        destination.write(chunk)
                tender_id = self.request.query_params.get('tender_id', None)

                workbook = load_workbook(path, data_only = True)
                sheet = workbook.worksheets[0]

                sheet_xlsx = pd.read_excel(path)
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                
                def process_str(x):
                    return str(x).lower().strip().replace(' ', '')
                
                executive_data_form = FormMaster.cmobjects.filter(form_type='tender_executive_summary',form_internal_name='qty').values_list('id',flat=True)
                uom_list = pd.DataFrame(UnitOfMesurement.cmobjects.values('id','formal_name','symbol'))
                uom_list = uom_list.fillna(np.nan).replace([np.nan], [None])
                uom_list = uom_list.applymap(lambda x: process_str(x))
                uom_list = uom_list.replace([np.nan], [None])

                sheet_xlsx['lower_boq_no'] = sheet_xlsx['BOQ NO.'].apply(lambda x: process_str(x))
                sheet_xlsx['lower_wbs'] = sheet_xlsx['PARTICULARS'].apply(lambda x: process_str(x))
                sheet_xlsx['lower_uom'] = sheet_xlsx['UNIT'].apply(lambda x: process_str(x))
                sheet_xlsx['id'] = None
                sheet_xlsx['form_id'] = None
                def check_uom(row):
                    result = None
                    if 'symbol' in uom_list and row['lower_uom']:
                        temp = list(uom_list.loc[(uom_list['symbol'].values == row['lower_uom'])]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                sheet_xlsx['uom_id'] = sheet_xlsx.apply(lambda row: check_uom(row), axis=1)
                levels = {0:None,1:None,2:None,3:None,}
                for index, row in sheet_xlsx.iterrows():
                    isnull = False
                    data = {
                        'tender_id': tender_id,
                        'category': 'others',
                        'parent_id_id': None,
                        'wbs_name': None,
                        'uom_id': row['uom_id'],
                        'boq_no': None,
                    }
                    if row['lower_boq_no'].startswith('billno'):
                        isnull = True
                        data['wbs_name'] = row['BOQ NO.']
                    else:
                        data['boq_no'] = row['BOQ NO.']
                        data['wbs_name'] = row['PARTICULARS']
                    level = 0
                    if not isnull:
                        if str(row['BOQ NO.']).strip().replace('.', '').replace(' ', '').isupper():
                            level = 1
                        if str(row['BOQ NO.']).strip().replace('.', '').replace(' ', '').isnumeric():
                            level = 2
                        if str(row['BOQ NO.']).strip().replace('.', '').replace(' ', '').islower():
                            level = 3
                        if not row['BOQ NO.']:
                            if sheet[index+2][1].font.b:
                                level = 1
                            else:
                                level = 2
                    if level == 0:
                        levels[1] = None
                        levels[2] = None
                        levels[3] = None
                    if level == 1:
                        data['parent_id_id'] = levels[0]
                        levels[2] = None
                        levels[3] = None
                    if level == 2:
                        data['parent_id_id'] = levels[1] if levels[1] else levels[0]
                        levels[3] = None
                    if level == 3:
                        data['parent_id_id'] = levels[2] if levels[2] else (levels[1] if levels[1] else levels[0])
                    result = TenderWBS.objects.create(**data)
                    sheet_xlsx.at[index, 'id'] = result.id
                    # print(str(row['BOQ NO.']).strip().replace('.', '').replace(' ', ''),' -> ',row['PARTICULARS'],' -> ',' -> ',level)
                    levels[level] = result.id
                    if isnull:
                        form_data = {
                            'tender_id': tender_id,
                            'wbs_id': result.id,
                            'name': 'LOT-1',
                        }
                        form_result = TenderChainage.objects.create(**form_data)
                        sheet_xlsx.at[index, 'form_id'] = form_result.id
                sheet_xlsx['form_id'] = sheet_xlsx['form_id'].ffill(axis=0)
                executive_chainage_data_add = []
                executive_data_add = []
                for index, row in sheet_xlsx.iterrows():
                    if row['BOQ\nQTY']:
                        executive_chainage_data = {
                            'tender_id': tender_id,
                            'wbs_id': row['id'],
                            'form_id': row['form_id'],
                            'type': None,
                            'value': row['BOQ\nQTY'],
                        }
                        executive_data = {
                            'tender_id': tender_id,
                            'wbs_id': row['id'],
                            'form_id': executive_data_form[0],
                            'value': row['BOQ\nQTY'],
                        }
                        executive_chainage_data_add.append(ChainageExecutiveSummeryData(**executive_chainage_data))
                        executive_data_add.append(ExecutiveSummeryData(**executive_data))
                ChainageExecutiveSummeryData.objects.bulk_create(executive_chainage_data_add, batch_size=1000, ignore_conflicts=False)
                ExecutiveSummeryData.objects.bulk_create(executive_data_add, batch_size=1000, ignore_conflicts=False)
                # print(sheet_xlsx)
                # print(levels)
                return Response({
                    'results': len(sheet_xlsx),
                })
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class ExecutiveSummeryWBSImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'wbs_add': 0, 'wbs_edit': 0, 'executive_add_edit': 0}
                organization_id = self.request.query_params.get('organization_id', None)
                tender_id = self.request.query_params.get('tender_id', None)
                wbs_list_id = self.request.query_params.get('wbs_list_id', None)
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                if organization_id is None or tender_id is None:
                    raise APIException({'request_status': 0, 'msg': "Organization ID or Tender ID not provided"})
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")
                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) <= 0:
                    raise APIException({'request_status': 0, 'msg': 'Empty file'})
                
                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x

                executive_data_form_list = FormMaster.cmobjects.filter(form_type='tender_executive_summary',form_internal_name__in=[
                    'qty','rate_incl__indirect_cost','sale_amount','labour','material','machinery','overheads'
                ]).values('id','form_internal_name')
                wbs_list = pd.DataFrame(TenderWBS.cmobjects.filter(tender_id=tender_id).values('id','wbs_name','parent_id'))
                chainage_list = pd.DataFrame(TenderChainage.cmobjects.filter(tender_id=tender_id,wbs_id=wbs_list_id).values('id','name'))
                chainage_code_list = pd.DataFrame(ChainageExecutiveSummeryData.cmobjects.filter(tender_id=tender_id,type='C').values('wbs','form','value','wbs__parent_id'))
                uom_list = pd.DataFrame(UnitOfMesurement.cmobjects.filter(organization_id=organization_id).values('id','formal_name','symbol'))
                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                    # sheet_xlsx[column] = sheet_xlsx[column].ffill(axis=0)
                chainage_count = len(sheet_xlsx.columns[pd.Series(sheet_xlsx.columns).str.startswith(field_map['chainage'])])
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                wbs_list = wbs_list.fillna(np.nan).replace([np.nan], [None])
                chainage_list = chainage_list.fillna(np.nan).replace([np.nan], [None])
                uom_list = uom_list.fillna(np.nan).replace([np.nan], [None])
                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                wbs_list = wbs_list.applymap(lambda x: process_str(x))
                chainage_list = chainage_list.applymap(lambda x: process_str(x))
                uom_list = uom_list.applymap(lambda x: process_str(x))
                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                wbs_list = wbs_list.replace([np.nan], [None])
                chainage_list = chainage_list.replace([np.nan], [None])
                uom_list = uom_list.replace([np.nan], [None])
                def convert_pattern(code,parent=False):
                    # print(code)
                    try:
                        code_arr = process_str(code).split("-")
                        code_arr[int(code_arr.index("cp"))+1] = r'\d{2}'
                        if parent:
                            code_arr.pop()
                        code = '-'.join(code_arr)
                    except Exception as e:
                        print(e)
                    # print(code)
                    return code
                def check_wbs_list(row):
                    result = None
                    if 'value' in chainage_code_list and row[field_map['chainage_wbs_code']]:
                        temp = list(chainage_code_list.loc[chainage_code_list['value'].str.contains(r'^'+convert_pattern(row[field_map['chainage_wbs_code']], False)+'$')]['wbs'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_parent_wbs_list(row):
                    result = None
                    if 'value' in chainage_code_list and row[field_map['chainage_wbs_code']]:
                        temp = list(chainage_code_list.loc[chainage_code_list['value'].str.contains(r'^'+convert_pattern(row[field_map['chainage_wbs_code']], True)+'$')]['wbs'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_uom(row):
                    result = None
                    if 'symbol' in uom_list and row[field_map['uom']]:
                        temp = list(uom_list.loc[(uom_list['symbol'].values == process_str(row[field_map['uom']]))]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_chainage(row,index):
                    result = None
                    column_name = field_map['chainage']
                    if not index == 0:
                        column_name += '.'+str(index)
                    if 'name' in chainage_list and row[column_name]:
                        temp = list(chainage_list.loc[(chainage_list['name'].values == process_str(row[column_name]))]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                sheet_xlsx['id'] = sheet_xlsx.apply(lambda row: check_wbs_list(row), axis=1)
                sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row: check_parent_wbs_list(row), axis=1)
                sheet_xlsx['uom_id'] = sheet_xlsx.apply(lambda row: check_uom(row), axis=1)
                for index in range(0,chainage_count):
                    sheet_xlsx['chainage_id_'+str(index)] = sheet_xlsx.apply(lambda row: check_chainage(row,index), axis=1)
                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                for index, row in sheet_xlsx.iterrows():
                    if sheet_xlsx.at[index, field_map['wbs']] and sheet_xlsx.at[index, field_map['chainage']] and sheet_xlsx.at[index, 'chainage_id_0'] and sheet_xlsx.at[index, field_map['chainage_wbs_code']]:
                        data = {
                            'tender_id': tender_id,
                            'parent_id_id': sheet_xlsx.at[index, 'parent_id'] if sheet_xlsx.at[index, 'parent_id'] else wbs_list_id,
                            'uom_id': sheet_xlsx.at[index, 'uom_id'],
                            'boq_code': row[field_map['boq_code']],
                            'boq_no': row[field_map['boq_no']],
                            'wbs_name': row[field_map['wbs']],
                        }
                        if sheet_xlsx.at[index, 'id']:
                            TenderWBS.objects.filter(pk=sheet_xlsx.at[index, 'id']).update(updated_by_id=request.user.id, **data)
                            count_data['wbs_edit'] += 1
                        else:
                            instance = TenderWBS.objects.create(created_by_id=request.user.id, **data)
                            sheet_xlsx['id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['chainage_wbs_code']] and row1[field_map['chainage_wbs_code']] and (convert_pattern(row[field_map['chainage_wbs_code']], False) == convert_pattern(row1[field_map['chainage_wbs_code']], False)) else None) if (not row1['id']) else row1['id'], axis=1)
                            sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['chainage_wbs_code']] and row1[field_map['chainage_wbs_code']] and (convert_pattern(row[field_map['chainage_wbs_code']], False) == convert_pattern(row1[field_map['chainage_wbs_code']], True)) else None) if (not row1['parent_id']) else row1['parent_id'], axis=1)
                            sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                            count_data['wbs_add'] += 1
                        for executive_data_form in executive_data_form_list:
                            executive_data = {
                                'tender_id': tender_id,
                                'wbs_id': sheet_xlsx.at[index, 'id'],
                                'form_id': executive_data_form['id'],
                                'updated_by_id': request.user.id,
                            }
                            executive_data_value = copy.copy(executive_data)
                            executive_data_value['value'] = row[field_map[executive_data_form['form_internal_name']]]
                            ExecutiveSummeryData.objects.update_or_create(**executive_data_value,defaults=executive_data)
                        for index1 in range(0,chainage_count):
                            chainage_wbs_code_column_name = field_map['chainage_wbs_code']
                            chainage_quantity_column_name = field_map['chainage_quantity']
                            if not index1 == 0:
                                chainage_wbs_code_column_name += '.'+str(index1)
                                chainage_quantity_column_name += '.'+str(index1)
                            chainage_data = {
                                'tender_id': tender_id,
                                'wbs_id': sheet_xlsx.at[index, 'id'],
                                'form_id': sheet_xlsx.at[index, 'chainage_id_'+str(index1)],
                                'updated_by_id': request.user.id,
                            }
                            chainage_data['type'] = 'C'
                            chainage_data_value = copy.copy(chainage_data)
                            chainage_data_value['value'] = row[chainage_wbs_code_column_name]
                            # print('-'*120)
                            # print(chainage_data)
                            # print('='*120)
                            # print(chainage_data_value)
                            # print('-'*120)
                            ChainageExecutiveSummeryData.objects.update_or_create(**chainage_data_value,defaults=chainage_data)
                            chainage_data['type'] = None
                            chainage_data_value = copy.copy(chainage_data)
                            chainage_data_value['value'] = row[chainage_quantity_column_name]
                            # print('-'*120)
                            # print(chainage_data)
                            # print('='*120)
                            # print(chainage_data_value)
                            # print('-'*120)
                            ChainageExecutiveSummeryData.objects.update_or_create(**chainage_data_value,defaults=chainage_data)
                            count_data['executive_add_edit'] += 2
                        # print(data)
                        # print('#'*120)

                # print(sheet_xlsx)
                return Response(
                    {'results': {
                        'Data': count_data,
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})



# TENDER IMPORT API VIEW
class TenderImportAPI(APIView):
    
    

    def post(self, request, *args, **kwargs):

        def process_str(x):
            if isinstance(x, str):
                x = x.lower().strip().replace(' ', '')
            return x
        
        try:
            with transaction.atomic():
                count_data = {
                    'items_created': 0,
                    'items_updated': 0,
                    'errors': 0,
                    'sheets_processed': []
                }

                organization_id = request.query_params.get('organization_id')
                if not organization_id:
                    raise APIException({'request_status': 0, 'msg': "Organization ID is required"})

                file_name = request.data.get('file_name')
                field_map = request.data.get('field_map')

                if not file_name or not field_map:
                    raise APIException({'request_status': 0, 'msg': "Missing file_name or field_map in request"})

                file_path = os.path.join('media', 'excel', file_name)
                if not os.path.exists(file_path):
                    raise APIException({'request_status': 0, 'msg': f"File '{file_name}' not found on server"})

                try:
                    all_sheets = pd.read_excel(file_path, sheet_name=None)
                except Exception as e:
                    raise APIException({'request_status': 0, 'msg': f"Error reading Excel: {str(e)}"})

                def normalize(val):
                    return str(val).strip().lower().replace(" ", "_") if isinstance(val, str) else val

                normalized_field_map = {key: normalize(val) for key, val in field_map.items()}

                form_qs = FormMaster.cmobjects.filter(
                    organization_id=organization_id,
                    form_internal_name__in=normalized_field_map.keys()
                )
                form_map = {f.form_internal_name: f for f in form_qs}

                # type_of_contract
                dropdown_choices_map = {}
                DROPDOWN_FIELDS = ['type_of_contract', ]

                for field in DROPDOWN_FIELDS:
                    form = form_map.get(field)
                    if not form:
                        continue

                    drop_down_choices = FormDropdownChoices.objects.annotate(
                        clean_name=Trim(Replace(F('option'), Value(' '), Value('')))  
                    ).filter(
                        form__form_internal_name = field
                    ).values('clean_name', 'id')  

                    dropdown_choices_map[field] = {
                        choice['clean_name'].lower(): choice['id']
                        for choice in drop_down_choices
                    }

                # Reference Field
                dependent_choices_map = {}
                DEPENDENT_FIELDS = ['employer', 'state_tender', 'tender_sector']

                for field in DEPENDENT_FIELDS:
                    form = form_map.get(field)
                    if not form:
                        continue
         
                    choices = FormDependentChoices.objects.annotate(
                        clean_name=Trim(Replace(F('name'), Value(' '), Value('')))
                    ).filter(
                        form__form_internal_name = field
                    ).values('clean_name', 'option_id')

                    dependent_choices_map[field] = {
                        choice['clean_name'].lower(): choice['option_id']
                        for choice in choices
                    }


                for sheet_name, sheet_df in all_sheets.items():
                    if sheet_df.empty:
                        continue

                    sheet_df.columns = [normalize(col) for col in sheet_df.columns]

                    for index, row in sheet_df.iterrows():
                   
                        processed_values = {}
                        for col in sheet_df.columns:
                            val = row[col]
                            processed_val = process_str(val)
                            processed_values[col] = processed_val

                
                        tender_id_col = normalized_field_map.get('tender_id')
                        if not tender_id_col:
                            count_data['errors'] += 1
                            continue

                        tender_id = processed_values.get(tender_id_col)
                        if pd.isna(tender_id) or str(tender_id).strip() == '':
                            count_data['errors'] += 1
                            continue

                        tender_sector_col = normalized_field_map.get('tender_sector')
                        tender_sector_val = processed_values.get(tender_sector_col) if tender_sector_col else None
                        sector_details = None
                        if tender_sector_val:
                            sector_details = TenderSector.objects.annotate(
                                clean_name=Trim(Replace(F('name'), Value(' '), Value('')))
                            ).filter(
                                clean_name__iexact=str(tender_sector_val).strip(),
                                organization_id=organization_id
                            ).first()

                            if not sector_details:
                                count_data['errors'] += 1
                                continue
                        
                        form_tender_id = form_map.get('tender_id')
                        existing_tender_data = TenderData.cmobjects.filter(
                            form=form_tender_id,
                            value=str(tender_id)
                        ).first()

                        if existing_tender_data:
                            tender_master = existing_tender_data.tender
                        else:
                            tender_master = TenderMaster.objects.create(
                                organization_id=organization_id,
                                created_by=request.user
                            )

                        for internal_name, excel_col in normalized_field_map.items():
                            form = form_map.get(internal_name)
                            if not form:
                                continue

                            id_fields = ['tender_sector', 'employer', 'type_of_contract', 'state_tender']
                            if internal_name in id_fields:
                                value = processed_values.get(excel_col)
                            else:
                                value = row.get(excel_col)

                            if pd.isna(value):
                                value = None

                            # Handle dependent fields
                            if internal_name in DEPENDENT_FIELDS:
                                if not value:
                                    count_data['errors'] += 1
                                    continue

                                choice_map = dependent_choices_map.get(internal_name, {})
                                clean_key = value.lower()

                                if clean_key in choice_map:
                                    value = choice_map[clean_key]
                                else:
                                    count_data['errors'] += 1
                                    value = ""

                            # DROPDOWN FIELDS
                            if internal_name in DROPDOWN_FIELDS:
                                if not value:
                                    count_data['errors'] += 1
                                    continue
                                choice_map = dropdown_choices_map.get(internal_name, {})
                                clean_key = value.lower()

                                if clean_key in choice_map:
                                    value = choice_map[clean_key]
                                else:
                                    count_data['errors'] += 1
                                    value = ""


                            if form.form_input_type == 'number' and value is not None:
                                try:
                                    value = float(value)
                                except ValueError:
                                    count_data['errors'] += 1
                                    continue
                            elif form.form_input_type == 'text' and value is not None:
                                value = str(value)

                            if sector_details:
                                tender_data, created = TenderData.cmobjects.update_or_create(
                                    tender=tender_master,
                                    form=form,
                                    defaults={
                                        'value': value if value is not None else None,
                                        'by_order': form.sort_orders,
                                        'created_by': request.user,
                                    }
                                )

                                if created:
                                    count_data['items_created'] += 1
                                else:
                                    count_data['items_updated'] += 1

                        count_data['sheets_processed'].append(sheet_name)

                return Response({
                    'request_status': 1,
                    'msg': 'Tender data imported from all sheets successfully',
                    'data': count_data
                })

        except Exception as e:
            print(f"Import error: {e}")
            raise APIException({'request_status': 0, 'msg': str(e)})







class TenderSummeryAPIView(APIView):
    
    

    def get(self, request):
        search = custom_filters(self.request, {}, [])
        resp = {'data': {}}
        resp['state_tender_list'] = State.objects.filter(country_name__is_default=True).values_list('name',flat=True)
        resp['tender_sector_list'] = TenderSector.cmobjects.values_list('name',flat=True)
        list_data = TenderMaster.cmobjects.filter(*search).annotate(
            tender_project_cost__eligibility=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_project_cost__eligibility'
                ).values('tender').annotate(value=GroupConcat('value', distinct=True)).values('value')
            ),
            tender_sector=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='tender_sector'
                ).values('tender').annotate(value=GroupConcat(
                    Subquery(
                    TenderSector.cmobjects.filter(
                        id=OuterRef('value'),
                    ).values('id').annotate(value=GroupConcat('name', distinct=True)).values('name')
                ))).values('value')
            ),
            state_tender=Subquery(
                TenderData.cmobjects.filter(
                    tender_id=OuterRef('pk'),
                    form__form_internal_name='state_tender'
                ).values('tender').annotate(value=GroupConcat(
                    Subquery(
                    State.objects.filter(
                        state_id=OuterRef('value'),
                    ).values('state_id').annotate(value=GroupConcat('name', distinct=True)).values('name')
                ))).values('value')
            ),
        ).values('tender_project_cost__eligibility','tender_sector','state_tender')
        grouped = {}
        if list_data:
            list_data = pd.DataFrame(list_data)
            list_data = list_data.fillna(np.nan).replace([np.nan], [None])
            list_data['tender_project_cost__eligibility'] = pd.to_numeric(list_data['tender_project_cost__eligibility'], errors='coerce')
            grouped = list_data.groupby(['state_tender', 'tender_sector']).agg(
                value=('tender_project_cost__eligibility', 'sum'),
                count=('tender_project_cost__eligibility', 'count')
            ).to_dict('index')
        resp['data'] = {
            state: {
                sector: grouped.get((state, sector), {'value': 0, 'count': 0})
                for sector in resp['tender_sector_list']
            }
            for state in resp['state_tender_list']
        }

        return Response({
            'results': resp,
        })




class TenderApprovalAPIView(APIView):
    
    

    def put(self, request):
        count = 0
        error_msg = []
        with transaction.atomic():
            status_list = [c[0] for c in TenderMaster.status.field.choices]
            bulk_datas = request.data
            if not isinstance(request.data, list):
                bulk_datas = [request.data]
            for idx, bulk_data in enumerate(bulk_datas):
                try:
                    target_status = bulk_data['status']
                    index = status_list.index(target_status)
                    applicable_status = status_list[index-1]
                    search = {
                        'id': bulk_data['id'],
                    }
                    if not target_status == 'rejected':
                        search['status'] = applicable_status
                    data = {
                        'status': target_status,
                        target_status+'_by_id': request.user.id,
                        target_status+'_by_date': datetime.now(),
                        target_status+'_remarks': bulk_data['remarks'] if 'remarks' in bulk_data else '',
                    }
                    indicator = TenderMaster.cmobjects.filter(**search).exclude(status='rejected').update(**data)
                    if indicator == 0:
                        error_msg.append(f"{idx}: not updated")
                    count += indicator
                except Exception as e:
                    error_msg.append(f"{idx}: {str(e)}")
        return Response({
            'results': count,
            'error': error_msg,
        })


# Tender New Views
class TenderDepartmentMasterAPIView(APIView):
    
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        
        if id:
            list_data = TenderDepartmentMaster.cmobjects.filter(id=id).first()
            serializer = TenderDepartmentMasterSerializer(list_data)
            return Response(serializer.data)
        
        list_data = TenderDepartmentMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderDepartmentMasterSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderDepartmentMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderDepartmentMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        details = TenderDepartmentMaster.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderDepartmentMaster.cmobjects.filter(pk=id).first()
                    serializer = TenderDepartmentMasterSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderDepartmentMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class TenderChecklistMasterAPIView(APIView):
    
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        
        if id:
            list_data = TenderChecklistMaster.cmobjects.filter(id=id).first()
            serializer = TenderChecklistMasterSerializer(list_data)
            return Response(serializer.data)
        
        list_data = TenderChecklistMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderChecklistMasterSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderChecklistMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderChecklistMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        details = TenderChecklistMaster.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderChecklistMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderChecklistMaster.cmobjects.filter(pk=id).first()
                    serializer = TenderChecklistMasterSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderChecklistMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderChecklistMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderChecklistMaster.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class TenderMasterNewDashboardAPIView(APIView):
    def get(self, request, format=None):
        today = timezone.now().date()
        search = custom_filters(request, {}, [])
        base_queryset = TenderMasterNew.cmobjects.filter(is_archived=False).distinct()
        filtered_queryset = base_queryset.filter(*search) if search else base_queryset
        aggregates = filtered_queryset.aggregate(
            standalone_tenders=Count('id', filter=Q(tender_type='standalone')&Q(is_reject_request=False)),
            jv_tenders=Count('id', filter=Q(tender_type='jv')&Q(is_reject_request=False)),
            live=Count('id', filter=Q(status='live')&Q(is_reject_request=False)),
            qualifying=Count('id', filter=Q(status='qualifying')&Q(is_reject_request=False)),
            emd_deposition=Count('id', filter=Q(status='emd_deposition')&Q(is_reject_request=False)),
            short_list=Count('id', filter=Q(status='short_list')&Q(is_reject_request=False)),
            proposed=Count('id', filter=Q(status='proposed')&Q(is_reject_request=False)),
            recommended=Count('id', filter=Q(status='recommended')&Q(is_reject_request=False)),
            documentation=Count('id', filter=Q(status='documentation')&Q(is_reject_request=False)),
            approved=Count('id', filter=Q(status='approved')&Q(is_reject_request=False)),
            bid_submitted = Count('id', filter=Q(status='bid_submitted')&Q(is_reject_request=False)),
            win = Count('id', filter=Q(status='win')&Q(is_reject_request=False)),
            loss = Count('id', filter=Q(status='loss')&Q(is_reject_request=False)),
            rejected=Count('id', filter=Q(status='rejected')),
            canceled=Count('id', filter=Q(status='canceled')),
            active_tenders=Count('id', filter=Q(bid_submission_date__lt=today)&Q(is_reject_request=False)),
            reject_request = Count('id', filter=Q(is_reject_request=True)),
            # canceled_request = Count('id', filter=Q(is_canceled_request=True)),
            technical_disqualified=Count('id', filter=Q(status='technical_disqualified')&Q(is_reject_request=False)),
            mis_on_going = Count('id', filter=Q(status='approved')&Q(is_reject_request=False)),
            mis_submitted = Count('id', filter=Q(status__in=['bid_submitted','win','loss','technical_disqualified','canceled'])&Q(is_reject_request=False)),
            mis_awaiting_results = Count('id', filter=Q(status="bid_submitted")&Q(financial_bid_open_date__isnull=True)&Q(technical_bid_open_date__isnull=False)&Q(is_reject_request=False)),
        )
        tender_data = {
            "standalone_type_tenders": aggregates['standalone_tenders'],
            "jv_type_tenders": aggregates['jv_tenders'],
            "live_tenders": aggregates['live'],
            "short_list_tenders": aggregates['short_list'],
            "qualifying_tenders": aggregates['qualifying'],
            "proposed_tenders": aggregates['proposed'],
            "recommended_tenders": aggregates['recommended'],
            "documentation_tenders": aggregates['documentation'],
            "approved_tenders": aggregates['approved'],
            "emd_deposition_tenders" : aggregates['emd_deposition'],
            "bid_submitted_tenders": aggregates['bid_submitted'],
            "win_tenders": aggregates['win'],
            "loss_tenders": aggregates['loss'],
            "rejected_tenders": aggregates['rejected'],
            "active_tenders": aggregates['active_tenders'],
            "total_tenders": filtered_queryset.count(),
            "archived_tenders" : TenderMasterNew.cmobjects.filter(is_archived=True, *search).count(),
            "reject_request" : aggregates['reject_request'],
            # "canceled_request" : aggregates['canceled_request'],
            "canceled" : aggregates['canceled'],
            "technical_disqualified" : aggregates['technical_disqualified'],
            "mis_on_going" : aggregates['mis_on_going'],
            "mis_submitted" : aggregates['mis_submitted'],
            "mis_awaiting_results" : aggregates['mis_awaiting_results'],
            "pending_emds_tenders": TenderMasterNew.cmobjects.filter(
                status__in=['win', 'loss', 'canceled', 'rejected'],
                is_emd_deposition=True, financial_bid_open_date__isnull=False).count(),
        }
        return Response(tender_data, status=200)


class TenderMasterNewAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        
        if id:
            list_data = TenderMasterNew.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSerializer(list_data)
            return Response(serializer.data)
        
        list_data = TenderMasterNew.cmobjects.filter(*search).order_by(*str(order_by).split(",")).distinct()
        if all == 'true':
            serializer = TenderMasterNewSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNew.cmobjects.filter(pk=id).first()

        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNew.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderMasterNew.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSerializer(details, data=request.data,
                                                          context={'request': request})
                    is_checklist_notify = self.request.data.get('is_checklist_notify')
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNew.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderMasterNew.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNew.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class TenderChecklistDocUpdateNotifyAPIView(APIView):
    
    

    def put(self, request, *args, **kwargs):
        tender_id = request.query_params.get('id', None)
        organization_id = request.query_params.get('organization_id', None)
        if not tender_id:
            raise APIException({
                'request_status': 0,
                'msg': 'Tender ID is required in query parameters.'
            })
        if not organization_id:
            raise APIException({
                'request_status': 0,
                'msg': 'Organization ID is required in query parameters.'
            })

        tender = TenderMasterNew.cmobjects.filter(
            id=tender_id,
            organization_id=organization_id,
            is_checklist_notify=False
        ).first()
        if not tender:
            raise APIException({
                'request_status': 0,
                'msg': 'Tender not found, belongs to a different organization, or already notified.'
            })
        is_checklist_notify = request.data.get('is_checklist_notify', False)
        if is_checklist_notify:
            tender.is_checklist_notify = True
            tender.checklist_notify_by = request.user
            tender.checklist_notify_date = timezone.now()
            tender.save()
            # Trigger email notification
            send_tender_is_notify_department_email(tender_id)
            # send_tender_checklist_doc_update_email(tender_id)
        serializer = TenderMasterNewSerializer(tender)
        return Response({
            'results': {
                'Data': serializer.data
            },
            'msg': 'Successfully updated',
            'status': status.HTTP_200_OK,
            'request_status': 1
        }, status=status.HTTP_200_OK)

class TenderWinLossAnalysisAPIView(APIView):
    
    
    def get(self, request):
        all = self.request.query_params.get('all', None)
        id = self.request.query_params.get('id', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        
        if id:
            list_data = TenderMasterNewWinLossAnalysis.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewWinLossAnalysisSerializer(list_data)
            return Response(serializer.data)

        list_data = TenderMasterNewWinLossAnalysis.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewWinLossAnalysisSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
    
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewWinLossAnalysisSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request):
        tender_id = request.query_params.get("tender_id")
        organization_id = request.query_params.get("organization_id")
        if not tender_id:
            raise APIException({
                "request_status": 0,
                "msg": "Missing 'tender_id' in query parameters"
            })
        try:
            tender = TenderMasterNew.cmobjects.get(pk=tender_id)
        except TenderMasterNew.DoesNotExist:
            raise APIException({
                "request_status": 0,
                "msg": f"Tender with ID {tender_id} does not exist"
            })
        item_list = request.data.get("item_list", [])
        if not isinstance(item_list, list):
            raise APIException({
                "request_status": 0,
                "msg": "'item_list' must be an array"
            })
        created_items = []
        errors = []
        try:
            with transaction.atomic():
                for idx, item in enumerate(item_list):
                    item["created_by"] = request.user.id
                    item["tender"] = tender_id
                    item["organization"] = organization_id
                    
                    serializer = TenderMasterNewWinLossAnalysisSerializer(
                        data=item,
                        context={'request': request}
                    )
                    if serializer.is_valid():
                        serializer.save()
                        created_items.append(serializer.data)
                    else:
                        errors.append({idx: serializer.errors})
                if errors:
                    raise APIException({
                        "request_status": 0,
                        "msg": "Some items failed validation",
                        "errors": errors
                    })
                
        except APIException:
            raise  
        except Exception as e:
            raise APIException({
                "request_status": 0,
                "msg": f"An unexpected error occurred: {str(e)}"
            })
        return Response({
            "request_status": 1,
            "msg": "Successfully created items",
            "results": {
                "created_count": len(created_items),
                "created_items": created_items
            }
        }, status=status.HTTP_201_CREATED)

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        tender_id = self.request.query_params.get('tender_id', None)
        id_param = self.request.query_params.get('id', None)  

        if not tender_id:
            raise APIException({'request_status': 0, 'msg': "tender_id is required"})

        if not TenderMasterNew.cmobjects.filter(pk=tender_id, organization_id=organization_id).exists():
            raise APIException({'request_status': 0, 'msg': "Tender not found for this organization"})

        if not method:
            raise APIException({'request_status': 0, 'msg': "method parameter is required"})

        method = method.lower()
        if method == 'edit':
            with transaction.atomic():
                item_list = request.data.get('item_list', [])
                if not isinstance(item_list, list):
                    raise APIException({
                        "request_status": 0,
                        "msg": "'item_list' must be an array"
                    })
                existing_records = TenderMasterNewWinLossAnalysis.cmobjects.filter(
                    tender_id=tender_id,
                    organization_id=organization_id
                )
                existing_records_dict = {record.id: record for record in existing_records}
                updated_ids = set()
                user = request.user
                for item in item_list:
                    item_id = item.get('id', None)
                    if item_id and item_id in existing_records_dict:
                        record = existing_records_dict[item_id]
                        record.partcipant_name = item.get('partcipant_name', record.partcipant_name)
                        record.bidded_value_in_crore = item.get('bidded_value_in_crore', record.bidded_value_in_crore)
                        record.percentage = item.get('percentage', record.percentage)
                        record.above_below = item.get('above_below', record.above_below)
                        record.rank = item.get('rank', record.rank)
                        record.is_my_biider_rank = item.get('is_my_biider_rank', record.is_my_biider_rank)
                        record.updated_by = user
                        record.save()
                        updated_ids.add(item_id)
                    else:
                        TenderMasterNewWinLossAnalysis.cmobjects.create(
                            organization_id=organization_id,
                            tender_id=tender_id,
                            partcipant_name=item.get('partcipant_name'),
                            bidded_value_in_crore=item.get('bidded_value_in_crore'),
                            percentage=item.get('percentage'),
                            above_below=item.get('above_below'),
                            rank=item.get('rank'),
                            is_my_biider_rank=item.get('is_my_biider_rank', False),
                            created_by=user,
                            updated_by=user
                        )
                ids_to_delete = set(existing_records_dict.keys()) - updated_ids
                if ids_to_delete:
                    TenderMasterNewWinLossAnalysis.cmobjects.filter(id__in=ids_to_delete).update(is_deleted=True)
                return Response({
                    'results': {
                        'Data': item_list,
                    },
                    'msg': "Successfully updated win/loss analysis",
                    'status': status.HTTP_202_ACCEPTED,
                    "request_status": 1
                })
        elif method == 'delete':
            if not id_param:
                raise APIException({'request_status': 0, 'msg': "id is required for delete method"})
            try:
                record = TenderMasterNewWinLossAnalysis.cmobjects.get(
                    pk=id_param,
                    organization_id=organization_id,
                    tender_id=tender_id  
                )
                record.is_deleted = True
                record.save()
                return Response({
                    'results': {
                        'details': TenderMasterNewWinLossAnalysis.cmobjects.filter(
                            pk=id_param, organization_id=organization_id
                        ).values().first(), 
                    },
                    'msg': 'Successfully deleted',
                    'request_status': 1
                })
            except TenderMasterNewWinLossAnalysis.DoesNotExist:
                raise APIException({'request_status': 0, 'msg': "Record not found"})
        else:
            raise APIException({'request_status': 0, 'msg': "Only 'edit' or 'delete' methods are supported"})
                

# TENDER MASTER NEW IMPORT
class TenderMasterNewImportAPI(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {
                    'items_created': 0,
                    'items_updated': 0,
                    'errors': 0,
                    'sheets_processed': [],
                    'sector_data_count': {}
                }
                errors = []

                organization_id = request.query_params.get('organization_id')
                if not organization_id:
                    raise APIException({'request_status': 0, 'msg': "Organization ID is required"})

                file_name = request.data.get('file_name')
                field_map = request.data.get('field_map')

                if not file_name or not field_map:
                    raise APIException({'request_status': 0, 'msg': "Missing file_name or field_map"})

                file_path = os.path.join('media', 'excel', file_name)
                if not os.path.exists(file_path):
                    raise APIException({'request_status': 0, 'msg': f"File '{file_name}' not found on server"})

                try:
                    excel_file = pd.ExcelFile(file_path)
                    all_sheets = {}
                    for sheet_name in excel_file.sheet_names:
                        sheet_df = pd.read_excel(excel_file, sheet_name=sheet_name)
                        sheet_df = sheet_df.fillna("").applymap(lambda x: x.strip() if isinstance(x, str) else x)
                        sheet_df = sheet_df.fillna(np.nan).replace([np.nan], [None])
                        all_sheets[sheet_name] = sheet_df
                except Exception as e:
                    raise APIException({'request_status': 0, 'msg': f"Error reading and cleaning Excel: {str(e)}"})

                sector_list = pd.DataFrame(TenderSector.cmobjects.filter(organization_id=organization_id).values('id', 'name'))
                employer_list = pd.DataFrame(EMPLOYEEMASTER.cmobjects.filter(organization_id=organization_id).values('id', 'employee_name'))
                state_list = pd.DataFrame(State.objects.all().values('state_id', 'name'))
                live_tender_list = pd.DataFrame(TenderMasterNew.cmobjects.exclude(status="live",is_archived=False).values('id', 'tender_id'))

                def process_str(x):
                    if isinstance(x, str):
                        # x = x.lower().strip().replace(' ', '')
                        x = x.strip()
                    return x
                
                def handle_date(value, default=None):
                    if pd.isna(value) or value is None:
                        return default
                    
                    if isinstance(value, (pd.Timestamp, pd._libs.tslibs.timestamps.Timestamp, pd._libs.tslibs.nattype.NaTType)):
                        if pd.isna(value):
                            return default
                        return value.date()
                    
                    if isinstance(value, str):
                        first_date_str = value.split('&')[0].strip()
                    else:
                        first_date_str = str(value).split('&')[0].strip()
                    try:
                        dt = pd.to_datetime(first_date_str, errors='coerce')
                        if pd.isna(dt):
                            return default
                        return dt.date()
                    except Exception:
                        return default

                def process_numeric(value, default=0.0):
                    if pd.isna(value) or value == "":
                        return default
                    try:
                        return float(value)
                    except (ValueError, TypeError):
                        return default

                def check_sector(name):
                    name_clean = str(name).strip().lower()
                    match = sector_list[sector_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None

                def check_employer(name):
                    name_clean = str(name).strip().lower()
                    match = employer_list[employer_list['employee_name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None

                def check_state(name):
                    name_clean = str(name).strip().lower()
                    match = state_list[state_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['state_id'] if not match.empty else None

                def check_tender_id(name):
                    name_clean = str(name).strip().lower()
                    if live_tender_list.empty:
                        return None
                    match = live_tender_list[live_tender_list['tender_id'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None
                
                for sheet_name, sheet_df in all_sheets.items():
                    if sheet_df.empty:
                        continue

                    sheet_df.columns = [str(col).strip() for col in sheet_df.columns]
                    count_data['sheets_processed'].append(sheet_name)

                    for index, row in sheet_df.iterrows():
                        row_data = {col: row[col] for col in sheet_df.columns}

                        tender_id_column = field_map.get('tender_id')
                        if not tender_id_column:
                            errors.append(f"Tender ID column Not Found for {sheet_name}")
                            count_data['errors'] += 1
                            continue

                        tender_id_raw = str(row_data.get(tender_id_column))
                        if not tender_id_raw:
                            errors.append(f"Tender ID {tender_id_raw}: Not Found for {sheet_name}")
                            count_data['errors'] += 1
                            continue
                        
                        tender_id = tender_id_raw.strip()

                        employer_column = field_map.get('employer')
                        state_column = field_map.get('state_tender')
                        sector_column = field_map.get('tender_sector')

                        employer_val = str(row_data.get(employer_column, "").strip().lower())
                        employer_name = str(row_data.get(employer_column, "").strip())
                        state_val = str(row_data.get(state_column, "").strip().lower())
                        sector_val = str(row_data.get(sector_column, "").strip().lower())
                        tender_id_val = str(tender_id_raw.strip().lower())

                        employer_id = check_employer(employer_val)
                        state_id = check_state(state_val)
                        sector_id = check_sector(sector_val)
                        live_tender_id = check_tender_id(tender_id_val)
                        
                        if live_tender_id:
                            errors.append(f"Tender ID {tender_id} already exists and status not as live or archived.")
                            count_data['errors'] += 1
                            continue

                        if not sector_id:
                            errors.append(f"Tender ID - {tender_id_raw}, Tender Sector '{sector_val}' not found for {sheet_name}.")
                            count_data['errors'] += 1
                            continue

                        if not state_id:
                            errors.append(f"Tender ID - {tender_id_raw}, State '{state_val}' not found for {sheet_name}.")
                            count_data['errors'] += 1
                            continue

                        employer_id = check_employer(employer_val)
                        if not employer_id:
                            emp_obj  = EMPLOYEEMASTER.objects.create(
                                organization_id = organization_id, 
                                employee_name=employer_name,
                                created_by_id=request.user.id,
                            )
                            employer_id = emp_obj.pk
                         
                        defaults = {
                            'organization_id': organization_id,
                            'sector_id': sector_id,
                            'state_id': state_id,
                            'tender_organization_id': employer_id,
                            'tender_id': tender_id,
                            'created_by': request.user,

                            "proposed_tender": str(row_data.get(field_map.get('proposed_tender', ''), '')),
                            "project_cost": process_numeric(row_data.get(field_map.get('tender_project_cost_eligibility'))),
                            "work_type": str(row_data.get(field_map.get('type_of_contract', ''), '')),
                            "qualification_criteria": str(row_data.get(field_map.get('qualification_criteria', ''), '')),
                            "bid_submission_date": handle_date(row_data.get(field_map.get('bid_submission_date'))),
                            "schedule_durations": str(row_data.get(field_map.get('schedule_durations', ''), '')),
                            "emd_amount": process_numeric(row_data.get(field_map.get('bg_value_pre_feasibility'))),
                            "department_name": str(row_data.get(field_map.get('department_name', ''), '')),
                            "contact_person": str(row_data.get(field_map.get('contact_person', ''), '')),
                            "contact_number": str(row_data.get(field_map.get('contact_no', ''), '')),
                            "publish_date": handle_date(row_data.get(field_map.get('tender_publish_date'))),
                            "pre_bid_meeting_date": handle_date(row_data.get(field_map.get('pre_bid_meeting_date'))),
                            "pre_bid_meeting_date_2": handle_date(row_data.get(field_map.get('pre_bid_meeting_date_2'))),
                            "sinpl_tracking_date": handle_date(row_data.get(field_map.get('sinpl_tracking_date'))),
                            "website_link": str(row_data.get(field_map.get('website_link', ''), '')),
                            "analysis": str(row_data.get(field_map.get('analysis', ''), '')),
                            "tender_identification_remarks": str(row_data.get(field_map.get('tender_identification_remarks', ''), '')),
                            "status_of_participation": str(row_data.get(field_map.get('status_of_participation', ''), '')),
                            
                        }
                        existing = TenderMasterNew.cmobjects.annotate(
                            lower_tender_id=Lower('tender_id')
                        ).filter(
                            lower_tender_id=tender_id_val,
                            organization_id=organization_id,
                            is_archived= False,
                        ).first()
                        if existing:
                            for key, value in defaults.items():
                                setattr(existing, key, value)
                            existing.save()
                            count_data['items_updated'] += 1
                        else:
                            TenderMasterNew.objects.create(**defaults)
                            count_data['items_created'] += 1
                            if sector_id:
                                sector_key = sector_id
                                if sector_key not in count_data['sector_data_count']:
                                    count_data['sector_data_count'][sector_key] = {
                                        'sector_id': sector_id,
                                        'sector_val': str(sector_val).title(),
                                        'count': 0
                                    }
                                count_data['sector_data_count'][sector_key]['count'] += 1


                final_sector_summary = list(count_data['sector_data_count'].values())
                count_data['sector_data_count'] = final_sector_summary

                created_count = count_data['items_created']
                if created_count > 0: 
                    send_tender_excel_import_email(created_count, sector_list=final_sector_summary)
     
                return Response({
                    'request_status': 1,
                    'msg': 'Tender data imported successfully.',
                    'data': count_data,
                    'errors': errors,
                })
                            
        except Exception as e:
            print(f"Import error: {e}")
            raise APIException({'request_status': 0, 'msg': str(e)})


# tender summary
class TenderMasterNewSummeryAPIView(APIView):
    
    
    def get(self, request):
        search = custom_filters(self.request, {}, [])
        resp = {
            'data': {},
            'state_tender_list': list(State.objects.filter(country_name__is_default=True).values_list('name', flat=True)),
            'tender_sector_list': list(TenderSector.cmobjects.values_list('name', flat=True))
        }
        queryset = TenderMasterNew.cmobjects.filter(*search).annotate(
            sector_name=Subquery(
                TenderSector.cmobjects.filter(id=OuterRef('sector_id')).values('name')[:1]
            ),
            state_name=Subquery(
                State.objects.filter(state_id=OuterRef('state_id')).values('name')[:1]
            )
        ).values('sector_name', 'state_name', 'project_cost')
        if not queryset.exists():
            return Response({'results': resp})
        df = pd.DataFrame(queryset)
        df['project_cost'] = pd.to_numeric(df['project_cost'], errors='coerce')
        df.fillna({'sector_name': 'Others', 'state_name': 'Unknown'}, inplace=True)
        grouped_df = df.groupby(['state_name', 'sector_name']).agg(
            value=('project_cost', 'sum'),
            count=('project_cost', 'size')
        ).reset_index()
        result_data = {}
        for _, row in grouped_df.iterrows():
            state = row['state_name']
            sector = row['sector_name']
            val = float(row['value'])
            cnt = int(row['count'])
            if state not in result_data:
                result_data[state] = {}
            result_data[state][sector] = {
                "value": round(val, 2),
                "count": cnt
            }
        final_grouped_data = {
            state: {
                sector: result_data.get(state, {}).get(sector, {"value": 0.0, "count": 0})
                for sector in resp['tender_sector_list']
            }
            for state in resp['state_tender_list']
        }
        resp['data'] = final_grouped_data
        return Response({
            'results': resp,
        })
    
def tender_validate_fields(tender_id, target_status):
    """ Validates that all necessary fields are filled before recommending or approving a tender. """
    status_field_map = {
        "recommended": {
            'tender_organization': 'Organization Name',
            'proposed_tender': "Work Description",
            'state': 'State / UT',
            'project_cost': 'Tender Value',
            'emd_amount': 'EMD Amount',
            'performance_security': 'Performance Security',
            'schedule_durations': 'Schedule Durations',
            'bid_submission_date': 'Bid Submission Date',
            'price_escalation': 'Price Escalation Applicable',
            'tender_type' : "Participations Mode",
        },
        "documentation": {
            'bank_guarantee_ref_page_no': 'Bank Guarantee Ref Page No',
            'finance_department_timeline': 'Finance Dept Timeline',
            'secretarial_department_timeline': 'Secretarial Dept Timeline',
            'ca_certificate_ref_page_no': 'CA Certificate Ref Page No',
            'accounts_department_timeline': 'Accounts Dept Timeline',
            'tender_department_timeline': 'Tender Dept Timeline',
            'poa_for_signing_of_tender_ref_page_no': 'POA for Signing Tender Ref Page No',
            'poa_of_lead_member_ref_page_no': 'POA of Lead Member Ref Page No',
            'finance_remarks': 'Finance Remarks',
            'secretarial_remarks': 'Secretarial Remarks',
            'accounts_remarks': 'Accounts Remarks'
        },
        "emd_deposition": {
            'emd_amount': 'EMD Amount',
            'emd_type': 'EMD Type',
            'emd_deposition_location': 'EMD Deposition Location',
            'emd_overall_remarks' : "EMD Overall Remarks",
        },
        "win" : {
            "financial_bid_open_date" : "Financial Bid Open Date"
        },
        "loss" : {
            "financial_bid_open_date" : "Financial Bid Open Date"
        }
    }
    required_tender_fields = status_field_map.get(target_status, {})
    tender_instance = TenderMasterNew.cmobjects.filter(id=tender_id).first()
    if not tender_instance:
        raise APIException({
            'request_status': 0,
            'msg': f"Tender with ID {tender_id} does not exist."
        })
    if str(tender_instance.tender_type) == "jv":
        required_tender_fields.update({'tender_jv_name': 'Tender JV Name'})
    missing_fields = []
    for field, label in required_tender_fields.items():
        value = getattr(tender_instance, field, None)
        if isinstance(value, models.Model):
            if not value.pk:
                missing_fields.append(label)
        elif value in [None, '', 0]:
            missing_fields.append(label)

    if target_status == "emd_deposition":
        emd_doc_instance = TenderMasterNewQualificationDocuments.cmobjects.filter(
            tender=tender_instance, doc_type="emd_deposition_document"
        ).first()
        if not emd_doc_instance:
            missing_fields.append("EMD Deposition Document")

    party_details_instance = TenderMasterNewPartyDetails.cmobjects.filter(tender=tender_instance).first()
    if not party_details_instance and str(tender_instance.tender_type) == "jv":
        raise APIException({
            "request_status": 0,
            "msg": f"The required fields for Tender #ID - {tender_instance.tender_id} are missing: Party Name",
        })
    if not party_details_instance and str(tender_instance.tender_type) == "standalone":
        raise APIException({
            "request_status": 0,
            "msg": f"The required fields for Tender #ID - {tender_instance.tender_id} are missing: Company Name",
        })
    required_party_fields = {}
    if str(tender_instance.tender_type) == "jv" and party_details_instance.company is None:
        required_party_fields = {
            'jvmaster': 'JV Name',
            'jv_share_percent': 'JV Share',
        }
    elif str(tender_instance.tender_type) == "standalone" and party_details_instance.jvmaster is None:
        required_party_fields = {
            'company': 'Company Name',
        }
    for field, label in required_party_fields.items():
        value = getattr(party_details_instance, field, None)
        if isinstance(value, models.Model):
            if not value.pk:
                missing_fields.append(label)
        elif value in [None, '', 0]:
            missing_fields.append(label)
    if missing_fields:
        raise APIException({
            "request_status": 0,
            "msg": f"The required fields for Tender #ID - {tender_instance.tender_id} are missing: {', '.join(missing_fields)}"
        })
    return True

class TenderMasterNewApprovalAPIView(APIView):
    def put(self, request):
        count = 0   
        error_details = []
        with transaction.atomic():
            status_list = [c[0] for c in TenderMasterNew.status.field.choices]
            bulk_datas = request.data if isinstance(request.data, list) else [request.data]
            for idx, bulk_data in enumerate(bulk_datas):
                try:
                    target_status = bulk_data.get('status')
                    tender_id = bulk_data.get('id')
                    if not target_status or not tender_id:
                        raise APIException({
                            'request_status': 0,
                            'msg': "Missing 'status' or 'id' in the request data."
                        })
                    if target_status == "rejected":
                        tender_approved_status = TenderMasterNew.cmobjects.filter(id=tender_id, status="approved").first()
                    if target_status == "reject_request":
                        organization_id = bulk_data.get('organization_id')
                        file_name = (bulk_data.get('file_name') or '').strip()
                        mime_type = (bulk_data.get('mime_type') or '').strip()
                        file_data = bulk_data.get('file_data', '')
                        doc_type = (bulk_data.get('doc_type') or '').strip()
                        
                        tender_status_obj = TenderMasterNew.cmobjects.filter(id=tender_id).values("status").first()
                        applicable_status = tender_status_obj["status"] if tender_status_obj else None
                        updated = TenderMasterNew.cmobjects.filter(id=tender_id).update(
                            is_reject_request=True,
                            reject_request_by=request.user,
                            reject_request_remarks =  bulk_data['remarks'] if 'remarks' in bulk_data else '',
                            reject_request_date= datetime.now(),
                        )
                        if file_data and mime_type:
                            attachment_content = process_attachments({'mime_type': mime_type, 'file_data': file_data})
                            TenderMasterNewQualificationDocuments.objects.create(
                                    organization_id=organization_id,
                                    tender_id=tender_id,
                                    doc_type=doc_type,
                                    file_name=file_name,
                                    attachment=attachment_content,
                                    created_by=request.user
                                )
                        #email trigger
                        send_tender_reject_request_email(tender_id)
                    elif target_status == "reject_request_deny":
                        tender_status_obj = TenderMasterNew.cmobjects.filter(id=tender_id).values("status").first()
                        applicable_status = tender_status_obj["status"] if tender_status_obj else None
                        TenderMasterNew.cmobjects.filter(id=tender_id).update(
                            is_reject_request=False
                        )
                    else:
                        index = status_list.index(target_status)
                        applicable_status = status_list[index - 1]

                        if target_status in ["recommended", "documentation", "emd_deposition", "win", "loss"]:
                            tender_validate_fields(tender_id, target_status)

                        search = {'id': tender_id}
                        if target_status not in ['rejected', 'loss', 'canceled', 'technical_disqualified', 'approved']:
                            search['status'] = applicable_status

                        update_data = {
                            'status': target_status,
                            target_status+'_by_id': request.user.id,
                            target_status+'_by_date': datetime.now(),
                            target_status+'_remarks': bulk_data['remarks'] if 'remarks' in bulk_data else '',
                        }
                        indicator = TenderMasterNew.cmobjects.filter(**search).exclude(status='rejected').update(**update_data)
                        if indicator == 0:
                            error_details.append(f"Tender ID - {tender_id}: Not updated - Invalid status transition or record not found")
                            
                        count += indicator
                        if target_status == "proposed" and indicator:
                            send_tender_proposed_approval_email(tender_id)
                        if target_status == "recommended" and indicator:
                            send_tender_recommended_approval_email(tender_id)
                        if target_status == "documentation" and indicator:
                            send_tender_documentation_approval_email(tender_id)
                        if target_status == "approved" and indicator:
                            send_tender_director_approval_checklist_attached(tender_id)
                        if target_status == "rejected" and indicator:
                            TenderMasterNew.cmobjects.filter(id=tender_id).update(
                                is_reject_request=False
                            )
                            if tender_approved_status:
                                send_tender_rejected_trigger_email(tender_id)

                    TenderMasterNewApprovalRequestLog.objects.create(tender_id=tender_id, 
                                        user=request.user, status=target_status, previous_status=applicable_status, 
                                        remarks=bulk_data['remarks'])
                except ValueError:
                    error_details.append(f"{idx}: Invalid or unknown status value provided.")
                except APIException as e:
                    error_msg = e.detail.get('msg') if isinstance(e.detail, dict) else str(e.detail)
                    error_details.append({
                        'index': idx,
                        'error': error_msg
                    })
                except Exception as e:
                    error_details.append(f"{idx}: {str(e)}")
        if error_details:
            raise APIException({
                'request_status': 0,
                'msg': [err['error'] if isinstance(err, dict) else err for err in error_details],
            })
        return Response({
            "request_status": 1,
            'msg': 'Successfully updated.',
            'results': count
        }, status=200)

class TenderApprovalAPIView(APIView):
    def put(self, request):
        count = 0
        error_msg = []
        with transaction.atomic():
            status_list = [c[0] for c in TenderMaster.status.field.choices]
            bulk_datas = request.data
            if not isinstance(request.data, list):
                bulk_datas = [request.data]
            for idx, bulk_data in enumerate(bulk_datas):
                try:
                    target_status = bulk_data['status']
                    index = status_list.index(target_status)
                    applicable_status = status_list[index-1]
                    search = {
                        'id': bulk_data['id'],
                    }
                    if not target_status == 'rejected':
                        search['status'] = applicable_status
                    data = {
                        'status': target_status,
                        target_status+'_by_id': request.user.id,
                        target_status+'_by_date': datetime.now(),
                        target_status+'_remarks': bulk_data['remarks'] if 'remarks' in bulk_data else '',
                    }
                    indicator = TenderMaster.cmobjects.filter(**search).exclude(status='rejected').update(**data)
                    if indicator == 0:
                        error_msg.append(f"{idx}: not updated")
                    count += indicator
                except Exception as e:
                    error_msg.append(f"{idx}: {str(e)}")
        return Response({
            'results': count,
            'error': error_msg,
        })

class TenderMasterNewQualificationDocumentsAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])

        if id:
            list_data = TenderMasterNewQualificationDocuments.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewQualificationDocumentsSerializer(list_data)
            return Response(serializer.data)

        list_data = TenderMasterNewQualificationDocuments.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        
        if all == 'true':
            serializer = TenderMasterNewQualificationDocumentsSerializer(list_data, many=True)
            return Response({'results': serializer.data})
            
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewQualificationDocumentsSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
    def post(self, request, *args, **kwargs):
        if not isinstance(request.data, list):
            raise APIException({'request_status': 0, 'msg': "Expected a list of documents."})
        bulk_datas = request.data
        created_data = []
        errors = []
        for idx, item in enumerate(bulk_datas):
            try:
                organization_id = item.get('organization_id')
                checklist_id = item.get('checklist_id')
                tender_department_id = item.get('tender_department_id')
                tender_id = item.get('tender_id')
                file_name = (item.get('file_name') or '').strip()
                mime_type = (item.get('mime_type') or '').strip()
                file_data = item.get('file_data', '')
                rcv_mime_type = (item.get('rcv_mime_type') or '').strip()
                rcv_file_data = item.get('rcv_file_data', '')
                doc_type = (item.get('doc_type') or '').strip()
                is_email = item.get('is_email', '')
                mail_to = (item.get('mail_to') or '').strip()
                mail_cc = (item.get('mail_cc') or '').strip()
                doc_id = item.get('id')
                reference_page_no = (item.get('reference_page_no'))
                document_print_on = (item.get('document_print_on') or '')
                is_sign_shyam_infra = (item.get('is_sign_shyam_infra'))
                is_sign_ca = (item.get('is_sign_ca'))
                is_sign_bank = (item.get('is_sign_bank'))
                is_applicable = (item.get('is_applicable'))
                is_sign_jv_partner = (item.get('is_sign_jv_partner'))
                is_received_copy = (item.get('is_received_copy'))
                is_default_file = (item.get('is_default_file'))
                raw_file_name = (item.get('raw_file_name') or '').strip()
                
                try:
                    instance = TenderMasterNewQualificationDocuments.cmobjects.filter(id=doc_id).first()
                except TenderMasterNewQualificationDocuments.DoesNotExist:
                    raise APIException({'request_status': 0, 'msg': f"Document with id {doc_id} does not exist."})
                
                if not organization_id:
                    raise APIException({'request_status': 0, 'msg': "organization_id is required."}) 
                if not tender_id:
                    raise APIException({'request_status': 0, 'msg': "tender_id is required."}) 
                
                if file_data:
                    attachment_content = process_attachments({'mime_type': mime_type, 'file_data': file_data, 'raw_file_name' : raw_file_name})
                else:
                    attachment_content = None

                if rcv_file_data:
                    rcv_attachment_content = rcv_process_attachments({'rcv_mime_type': rcv_mime_type, 'rcv_file_data': rcv_file_data})
                else:
                    rcv_attachment_content = None

                if instance:
                    if not file_data:
                        attachment_content = instance.attachment
                    if not rcv_file_data:
                        rcv_attachment_content = instance.rcv_attachment
                    instance.organization_id = organization_id
                    instance.tender_id = tender_id
                    instance.file_name = file_name
                    instance.attachment = attachment_content
                    instance.rcv_attachment = rcv_attachment_content
                    instance.updated_by = request.user
                    instance.doc_type = doc_type
                    instance.is_email = is_email
                    instance.mail_to = mail_to
                    instance.mail_cc = mail_cc
                    instance.checklist_id = checklist_id
                    instance.tender_department_id = tender_department_id
                    instance.reference_page_no = reference_page_no
                    instance.document_print_on = document_print_on
                    instance.is_sign_shyam_infra = is_sign_shyam_infra
                    instance.is_sign_ca = is_sign_ca
                    instance.is_sign_bank = is_sign_bank
                    instance.is_applicable = is_applicable
                    instance.is_sign_jv_partner = is_sign_jv_partner
                    instance.is_received_copy = is_received_copy
                    instance.updated_by = request.user
                    instance.is_default_file = is_default_file
                    instance.save()
                else:
                    instance = TenderMasterNewQualificationDocuments.objects.create(
                        organization_id=organization_id,
                        checklist_id = checklist_id,
                        tender_department_id = tender_department_id,
                        tender_id=tender_id,
                        file_name=file_name,
                        attachment=attachment_content,
                        rcv_attachment = rcv_attachment_content,
                        created_by=request.user,
                        doc_type=doc_type,
                        is_email=is_email,
                        mail_to=mail_to,
                        mail_cc=mail_cc,
                        reference_page_no = reference_page_no,
                        document_print_on = document_print_on,
                        is_sign_shyam_infra = is_sign_shyam_infra,
                        is_sign_ca = is_sign_ca,
                        is_sign_bank = is_sign_bank,
                        is_sign_jv_partner = is_sign_jv_partner,
                        is_received_copy = is_received_copy,
                        is_applicable = is_applicable,
                        is_default_file = is_default_file
                    )
            except Exception as e:
                errors.append({idx: str(e)})
        if errors:
            raise APIException({'request_status': 0, "msg": "Some documents failed to upload.",})
        return Response({
            "request_status": 1,
            "msg": "All documents uploaded successfully.",
        }, status=status.HTTP_201_CREATED)

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewQualificationDocuments.cmobjects.filter(pk=id).first()
        
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewQualificationDocuments.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderMasterNewQualificationDocuments.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewQualificationDocumentsSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewQualificationDocuments.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderMasterNewQualificationDocuments.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewQualificationDocuments.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
# TENDER SURVEY
class TenderMasterNewWinLossAnalysisImportAPI(APIView):
    
    
    def post(self, request, *args, **kwargs):
        try:
            count_data = {
                'items_created': 0,
                'items_updated': 0,
                'errors': 0,
                'sheets_processed': []
            }
            errors = []
            organization_id = request.query_params.get('organization_id')
            tender_id = request.query_params.get('tender_id')

            if not organization_id:
                raise APIException({'request_status': 0, 'msg': 'Organization ID is required.'})
            if not tender_id:
                raise APIException({'request_status': 0, 'msg': 'Tender ID is required.'})

            file_name = request.data.get('file_name')
            field_map = request.data.get('field_map')

            if not file_name or not field_map:
                raise APIException({'request_status': 0, 'msg': 'File name or field map missing.'})

            file_path = os.path.join('media', 'excel', file_name)
            if not os.path.exists(file_path):
                raise APIException({'request_status': 0, 'msg': 'File not found.'})

            tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values('project_cost').first()
            if not tender_details:
                raise APIException({'request_status': 0, 'msg': 'Tender details not found.'})
            project_cost = tender_details['project_cost']

            try:
                excel_file = pd.ExcelFile(file_path)
                all_sheets = {}
                for sheet_name in excel_file.sheet_names:
                    sheet_df = pd.read_excel(excel_file, sheet_name=sheet_name)
                    sheet_df = sheet_df.fillna("").applymap(lambda x: x.strip() if isinstance(x, str) else x)
                    sheet_df = sheet_df.replace(['', ' ', np.nan], None)
                    all_sheets[sheet_name] = sheet_df
            except Exception as e:
                raise APIException({'request_status': 0, 'msg': f'Error reading Excel file: {str(e)}'})
                
            def validate_numeric(value, field_name, row_index):
                raw_val = str(value).strip()
                if raw_val == "" or "," in raw_val:
                    errors.append(f"Row {row_index}: {field_name} contains invalid format '{raw_val}'")
                    count_data['errors'] += 1
                    return None
                if re.search(r'[eE]', raw_val):
                    errors.append(f"Row {row_index}: {field_name} contains invalid scientific notation '{raw_val}'")
                    count_data['errors'] += 1
                    return None
                if not re.match(r'^\d+(\.\d+)?$', raw_val):
                    errors.append(f"Row {row_index}: {field_name} must be a valid number (got '{raw_val}')")
                    count_data['errors'] += 1
                    return None
                try:
                    return float(raw_val)
                except ValueError:
                    errors.append(f"Row {row_index}: {field_name} must be numeric (got '{raw_val}')")
                    count_data['errors'] += 1
                    return None
                
            def validate_participant_name(value, row_index, sheet_name):
                if value is None:
                    errors.append(f"Row {row_index} in {sheet_name}: participant name is missing.")
                    count_data['errors'] += 1
                    return None
                name = str(value).strip()
                if name == "":
                    errors.append(f"Row {row_index} in {sheet_name}: participant name is empty.")
                    count_data['errors'] += 1
                    return None
                if name.startswith("."):
                    errors.append(f"Row {row_index} in {sheet_name}: participant name '{name}' starts with a dot.")
                    count_data['errors'] += 1
                    return None
                if name.endswith(".."):
                    errors.append(f"Row {row_index} in {sheet_name}: participant name '{name}' ends with a dot.")
                    count_data['errors'] += 1
                    return None
                if ".." in name:
                    errors.append(f"Row {row_index} in {sheet_name}: participant name '{name}' contains consecutive dots.")
                    count_data['errors'] += 1
                    return None
                return name

            for sheet_name, sheet_df in all_sheets.items():
                if sheet_df.empty:
                    errors.append(f"sheet: {sheet_name} is blank.")
                    count_data['errors'] += 1   
                    continue
                sheet_df.columns = [str(col).strip() for col in sheet_df.columns]
                count_data['sheets_processed'].append(sheet_name)

                for index, row in sheet_df.iterrows():
                    try:
                        row_data = {str(col): row[col] for col in sheet_df.columns}
                        row_index = index + 2

                        partcipant_name_key = field_map.get('partcipant_name')
                        if not partcipant_name_key:
                            errors.append(f"Missing participant name Column at sheet: {sheet_name}")
                            count_data['errors'] += 1
                            continue

                        mandatory_fields = ['bidded_value_in_crore', 'partcipant_name']
                        missing_fields = []
                        for field in mandatory_fields:
                            field_name = field_map.get(field)
                            value = row_data.get(field_name)
                            if not field_name or pd.isna(value) or str(value).strip() == "":
                                missing_fields.append(field)
                        if missing_fields:
                            errors.append(f"Row {row_index}: Missing mandatory fields {', '.join(missing_fields)}")
                            count_data['errors'] += 1
                            continue

                        partcipant_name = validate_participant_name(
                                                    str(row_data.get(partcipant_name_key, '')).strip(),
                                                    row_index,
                                                    sheet_name
                                                )
                        if partcipant_name is None:
                            continue

                        bidder_value = validate_numeric(row_data.get(field_map['bidded_value_in_crore']),
                                                        'bidded_value_in_crore', row_index)
                        if bidder_value is None:
                            errors.append(f"Row {row_index}: must be valid bidded_value_in_crore")
                            count_data['errors'] += 1
                            continue
 
                        diff = bidder_value - project_cost
                        percentage = round((abs(diff) / project_cost) * 100, 2) if project_cost else 0
                        if percentage > 200:
                            errors.append(f"Row {row_index}: percentage can not accepting more than 200%.")
                            count_data['errors'] += 1
                            continue

                        if bidder_value == 0:
                            direction = "NA"
                            percentage = None
                        elif diff > 0:
                            direction = "Above"
                        elif diff < 0:
                            direction = "Below"
                        else:
                            direction = "Equal"
                            
                        defaults = {
                            'organization_id': organization_id,
                            'tender_id': tender_id,
                            'updated_by': request.user,
                            'partcipant_name': partcipant_name,
                            'bidded_value_in_crore': bidder_value,
                            'percentage': percentage,
                            'above_below': direction,
                        }
                        obj, created = TenderMasterNewWinLossAnalysis.cmobjects.update_or_create(
                            tender_id=tender_id,
                            organization_id=organization_id,
                            partcipant_name=str(row_data.get(field_map.get('partcipant_name', ''), '')),
                            defaults=defaults,
                        )
                        if created:
                            count_data['items_created'] += 1
                        else:
                            count_data['items_updated'] += 1
                    except Exception as ex:
                        errors.append(f"Error processing row {row_index} in {sheet_name}: {str(ex)}")
                        count_data['errors'] += 1
            return Response({
                'request_status': 1,
                'msg': 'Tender Win Loss data imported successfully.',
                'data': count_data,
                'errors': errors
            })
        except Exception as e:
            raise APIException({
                'request_status': 0,
                'msg': e
            })
        
class TenderMasterNewWinLossAnalysisImportAPI222(APIView):
    
    
    def post(self, request, *args, **kwargs):
        count_data = {
            'items_created': 0,
            'items_updated': 0,
            'errors': 0,
            'sheets_processed': []
        }
        errors = []
        organization_id = request.query_params.get('organization_id')
        tender_id = request.query_params.get('tender_id')
        if not organization_id:
            raise APIException({'request_status': 0, 'msg': 'Organization ID is required.'})
        if not tender_id:
            raise APIException({'request_status': 0, 'msg': 'Tender ID is required.'})

        file_name = request.data.get('file_name')
        field_map = request.data.get('field_map')
        if not file_name or not field_map:
            raise APIException({'request_status': 0, 'msg': 'File name or field map missing.'})
        file_path = os.path.join('media', 'excel', file_name)
        if not os.path.exists(file_path):
            raise APIException({'request_status': 0, 'msg': 'File not found.'})

        tender_details = TenderMasterNew.cmobjects.filter(id=tender_id).values('project_cost').first()
        if not tender_details:
            raise APIException({'request_status': 0, 'msg': 'Tender details not found.'})
        project_cost = tender_details['project_cost']

        try:
            excel_file = pd.ExcelFile(file_path)
            all_sheets = {
                sheet_name: pd.read_excel(excel_file, sheet_name=sheet_name)
                .fillna("")
                .applymap(lambda x: x.strip() if isinstance(x, str) else x)
                .replace(['', ' ', np.nan], None)
                for sheet_name in excel_file.sheet_names
            }
        except Exception as e:
            raise APIException({'request_status': 0, 'msg': f'Error reading Excel file: {str(e)}'})

        def validate_numeric(value, field_name, row_index):
            raw_val = str(value).strip()
            if raw_val == "" or "," in raw_val:
                errors.append(f"Row {row_index}: {field_name} contains invalid format '{raw_val}'")
                count_data['errors'] += 1
                return None
            if re.search(r'[eE]', raw_val):
                errors.append(f"Row {row_index}: {field_name} contains invalid scientific notation '{raw_val}'")
                count_data['errors'] += 1
                return None
            if not re.match(r'^\d+(\.\d+)?$', raw_val):
                errors.append(f"Row {row_index}: {field_name} must be a valid number (got '{raw_val}')")
                count_data['errors'] += 1
                return None
            try:
                return float(raw_val)
            except ValueError:
                errors.append(f"Row {row_index}: {field_name} must be numeric (got '{raw_val}')")
                count_data['errors'] += 1
                return None

        participants = []
        for sheet_name, sheet_df in all_sheets.items():
            if sheet_df.empty:
                continue
            sheet_df.columns = [str(col).strip() for col in sheet_df.columns]
            count_data['sheets_processed'].append(sheet_name)

            for index, row in sheet_df.iterrows():
                row_data = {str(col): row[col] for col in sheet_df.columns}
                row_index = index + 2 

                mandatory_fields = ['bidded_value_in_crore', 'partcipant_name']
                missing_fields = []
                for field in mandatory_fields:
                    field_name = field_map.get(field)
                    value = row_data.get(field_name)
                    if not field_name or pd.isna(value) or str(value).strip() == "":
                        missing_fields.append(field)
                if missing_fields:
                    errors.append(f"Row {row_index}: Missing mandatory fields {', '.join(missing_fields)}")
                    count_data['errors'] += 1
                    continue

                bidder_value = validate_numeric(row_data.get(field_map['bidded_value_in_crore']),
                                                'bidded_value_in_crore', row_index)
                if bidder_value is None:
                    continue

                diff = bidder_value - project_cost
                percentage = round((abs(diff) / project_cost) * 100, 2) if project_cost else 0
                direction = 'Above' if diff > 0 else 'Below' if diff < 0 else 'Equal'

                participants.append({
                    'organization_id': organization_id,
                    'tender_id': tender_id,
                    'partcipant_name': str(row_data.get(field_map.get('partcipant_name', ''), '')),
                    'bidded_value_in_crore': bidder_value,
                    'percentage': percentage,
                    'above_below': direction,
                    'updated_by': request.user,
                    'is_import' : True,
                })
            for idx, p in enumerate(sorted(participants, key=lambda x: x['bidded_value_in_crore']), start=1):
                p['rank'] = idx
                try:
                    with transaction.atomic():
                        existing = TenderMasterNewWinLossAnalysis.cmobjects.annotate(
                            lower_partcipant_name=Lower('partcipant_name')
                        ).filter(
                            lower_partcipant_name__exact=p['partcipant_name'].lower(),
                            organization_id=organization_id,
                            tender_id=tender_id
                        ).first()
                        if existing:
                            for key, value in p.items():
                                setattr(existing, key, value)
                            existing.save()
                            count_data['items_updated'] += 1
                        else:
                            p['created_by'] = request.user
                            TenderMasterNewWinLossAnalysis.objects.create(**p)
                            count_data['items_created'] += 1

                except IntegrityError as ie:
                    errors.append(f"Integrity error for participant {p['partcipant_name']}: {str(ie)}")
                    count_data['errors'] += 1
                except Exception as ex:
                    errors.append(f"Error saving participant {p['partcipant_name']}: {str(ex)}")
                    count_data['errors'] += 1

        return Response({
            'request_status': 1,
            'msg': 'Tender Win Loss data imported successfully.',
            'data': count_data,
            'errors': errors
        })

class TenderMasterNewAutoArchivedAPIView(APIView):
    """
    API View to automatically archive tenders whose bid submission date has passed.
    This view is intended to be called by a cron job at regular intervals.
    """
    authentication_classes = []
    permission_classes = []

    def get(self, request, *args, **kwargs):
        try:
            today_date = datetime.now().date()
            updated_count = TenderMasterNew.cmobjects.filter(
                status="live",
                bid_submission_date__lt=today_date
            ).update(is_archived=True)
            response_data = {
                "today_date": today_date,
                'request_status': 1,
                'archived_count': updated_count,
            }
            return Response(response_data)
        except Exception as e:
            error_msg = f"Error in Tender auto-archiving: {str(e)}"
            raise APIException({
                'request_status': 0,
                'msg': error_msg
            })
        

# Auto Reminder Email
def tender_proposer_reminder_email():
    """
        Reminder Email for Proposer, if no action taken, every 24 Hours
    """
    tender_list = TenderMasterNew.cmobjects.filter(status="live", is_archived=False).values(
        'id', 'tender_id', 'name', 'created_at'
    )
    for tender in tender_list:
        tender_id = tender['tender_id']
        tender_name = tender['name']
        created_at = tender['created_at']
        created_at_date = created_at.strftime('%d-%m-%Y %H:%M:%S') if created_at else ""
        send_tender_proposer_reminder_email(id, tender_id, tender_name, created_at_date)
    
    return True


def tender_recommender_reminder_email():
    """
        Reminder Email for Recommender, if no action taken, every 24 Hours
    """
    tender_list = TenderMasterNew.cmobjects.filter(status="proposed", is_archived=False).values(
        'id', 'tender_id', 'name', 'proposed_by_date'
    )
    for tender in tender_list:
        id = tender['id']
        tender_id = tender['tender_id']
        tender_name = tender['name']
        proposed_by_date = tender['proposed_by_date']
        proposed_by_date = proposed_by_date.strftime('%d-%m-%Y %H:%M:%S') if proposed_by_date else ""
        send_tender_recommender_reminder_email(id, tender_id, tender_name, proposed_by_date)
    
    return True  
    

def tender_documentation_reminder_email():
    """
        Reminder Email for Documentation, if no action taken, every 24 Hours
    """
    tender_list = TenderMasterNew.cmobjects.filter(status="recommended", is_archived=False).values(
        'id', 'tender_id', 'name', 'proposed_by_date'
    )
    for tender in tender_list:
        id = tender['id']
        tender_id = tender['tender_id']
        tender_name = tender['name']
        recommended_by_date = tender['recommended_by_date']
        recommended_by_date = recommended_by_date.strftime('%d-%m-%Y %H:%M:%S') if recommended_by_date else ""
        send_tender_documentation_reminder_email(id, tender_id, tender_name, recommended_by_date)
    
    return True  


def tender_approval_reminder_email():
    """
        Reminder Email for Approval, if no action taken, every 24 Hours
    """
    tender_list = TenderMasterNew.cmobjects.filter(status="documentation", is_archived=False).values(
        'id', 'tender_id', 'name', 'proposed_by_date'
    )
    for tender in tender_list:
        id = tender['id']
        tender_id = tender['tender_id']
        tender_name = tender['name']
        documentation_by_date = tender['documentation_by_date']
        documentation_by_date = documentation_by_date.strftime('%d-%m-%Y %H:%M:%S') if documentation_by_date else ""
        send_tender_approval_reminder_email(id, tender_id, tender_name, documentation_by_date)
    
    return True  


def tender_checklist_reminder_email():
    """
        Reminder Email for CHECK LIST, if no action taken, every 24 Hours
    """
    tender_list = TenderMasterNew.cmobjects.filter(status="documentation", is_archived=False).values(
        'id', 'tender_id', 'name', 'proposed_by_date'
    )
    for tender in tender_list:
        id = tender['id']
        tender_id = tender['tender_id']
        tender_name = tender['name']
        documentation_by_date = tender['documentation_by_date']
        documentation_by_date = documentation_by_date.strftime('%d-%m-%Y %H:%M:%S') if documentation_by_date else ""
        send_tender_approval_reminder_email(id, tender_id, tender_name, documentation_by_date)
    
    return True  



#Tender Empanelment Tracker Views
class TenderEmpanelmentTrackerAPIView(APIView):
    
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        
        if id:
            list_data = TenderEmpanelmentTracker.cmobjects.filter(id=id).first()
            serializer = TenderEmpanelmentTrackerSerializer(list_data)
            return Response(serializer.data)
        
        list_data = TenderEmpanelmentTracker.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderEmpanelmentTrackerSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderEmpanelmentTrackerSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderEmpanelmentTrackerSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        details = TenderEmpanelmentTracker.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderEmpanelmentTracker.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderEmpanelmentTracker.cmobjects.filter(pk=id).first()
                    serializer = TenderEmpanelmentTrackerSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderEmpanelmentTracker.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderEmpanelmentTracker.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderEmpanelmentTracker.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class TenderEmpanelmentTrackerDocumentAPIView(APIView):
    """
        CRUD API for Tender Empanelment Tracker Document model
    """
    
    

    def get(self, request):
        """
        Get a list of all Tender Empanelment Tracker Document
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            queryset = TenderEmpanelmentTrackerDocument.cmobjects.filter(id=id).first()
            serializer = TenderEmpanelmentTrackerDocumentSerializer(queryset)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])
       
        queryset = TenderEmpanelmentTrackerDocument.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderEmpanelmentTrackerDocumentSerializer(queryset, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderEmpanelmentTrackerDocumentSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create one or more records
        """
        data = request.data if isinstance(request.data, list) else [request.data]
        created_objects = []
        errors = []

        for item in data:
            item['created_by'] = request.user.id
            serializer = TenderEmpanelmentTrackerDocumentSerializer(data=item, context={'request': request})
            if serializer.is_valid():
                try:
                    instance = serializer.save()
                    created_objects.append(TenderEmpanelmentTrackerDocumentSerializer(instance).data)
                except Exception as e:
                    errors.append({'data': item, 'error': str(e)})
            else:
                errors.append({'data': item, 'error': serializer.errors})

        if errors:
            return Response({
                'request_status': 0,
                'msg': 'Some records failed to create',
                'errors': errors,
                'created': created_objects
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'results': {'Data': created_objects},
            'msg': 'Successfully created',
            'status': status.HTTP_201_CREATED,
            'request_status': 1
        }, status=status.HTTP_201_CREATED)

    def put(self, request):
        """
        Edit a Tender Empanelment Tracker Document
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a TenderEmpanelmentTrackerDocument
                """
                if TenderEmpanelmentTrackerDocument.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderEmpanelmentTrackerDocument.cmobjects.filter(pk=id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = TenderEmpanelmentTrackerDocumentSerializer(details, data=request.data,partial=True,)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                """
                Delete a Tender Empanelment Tracker Document
                """
                if TenderEmpanelmentTrackerDocument.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderEmpanelmentTrackerDocument.cmobjects.filter(
                        pk=id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': TenderEmpanelmentTrackerDocument.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Tender Empanelment Tracker Document',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                

class TenderMasterNewMainAPIView(APIView):
    def get(self, request):
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        data = (TenderMasterNew.cmobjects.select_related(
            'sector', 'tender_organization', 'state').filter(*search).values(
                'id','project_cost','state__name', 'proposed_tender', 'project_cost', 'qualification_criteria',
                'bid_submission_date', 'emd_amount', 'department_name', 'contact_person', 'contact_number',
                'publish_date', 'pre_bid_meeting_date', 'pre_bid_meeting_date_2', 'sinpl_tracking_date', 'is_reject_request',
                'reject_request_date', 'reject_request_remarks', 'rejected_remarks',
                'created_at', 'tender_id', 'website_link', 'status', 'tender_jv_name', 'tender_organization__employee_name',
                'sector__name', 'work_type', 'schedule_durations', 'is_checklist_notify', 'is_archived', 'is_archived_date', 'archived_remarks',
                'emd_amount', 'emd_type', 'emd_deposition_location', 'emd_validity_date', 'emd_checked_by_account', 'financial_bid_open_date',
                'is_emd_deposition', 'emd_deposition_remarks', 'is_emd_received_by_account', 'is_emd_applicable', 'emd_overall_remarks','gst_type',
            ).order_by(*str(order_by).split(","))).distinct()
        if all == 'true':
            return Response({'results': data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': {
                'Data': page.object_list,
            },
        })
    
# SEND TENDER AUTO REMINDER EMAILS
class TenderAutoReminderEmailTriggerAPIView(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        """
            Reminder Email for Proposer, if no action taken, every 24 Hours
        """
        current_date = datetime.now().strftime('%d-%m-%Y')
        status_list = {
            'qualifying': {
                'subject': 'Reminder Tender Pending from Shortlist',	
                'status_text' : 'Shortlist',
                'to_users_email': "tender-pending-for-shortlist-mail-to",
                'cc_users_email': "tender-pending-for-shortlist-mail-cc"
            },
            'short_list': {
                'subject': 'Reminder Tender Pending from Proposer',
                'status_text' : 'Proposal',
                'to_users_email': "tender-pending-for-proposer-mail-to",
                'cc_users_email': "tender-pending-for-proposer-mail-cc"
            },
            'proposed': {
                'subject': 'Reminder Tender Pending from Recommender',
                'status_text' : 'Recommendation',
                'to_users_email' : "tender-pending-for-recommender-mail-to",
                'cc_users_email' : "tender-pending-for-recommender-mail-cc"
            },
            'recommended': {
                'subject': 'Reminder Tender Pending from Documentation',
                'status_text' : 'Documentations',
                'to_users_email' : "tender-pending-for-documentation-mail-to",
                'cc_users_email' : "tender-pending-for-documentation-mail-cc"
            },
            'documentation': {
                'subject': 'Reminder Tender Pending from Approver',
                'status_text' : 'Approval',
                'to_users_email' : "tender-pending-for-approver-mail-to",
                'cc_users_email' : "tender-pending-for-approver-mail-cc"
            },
        }
        _list = TenderMasterNew.cmobjects.filter(is_archived=False, is_reject_request=False)
        for status_key,status_value in status_list.items():
            status_count = _list.filter(status=status_key).count()
            context = {}
            if _list.exists():
                to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                    module_item__unique_id__in=[status_value['to_users_email']],
                    level_permission=True,
                ).values_list('user_id',flat=True))
                cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                    module_item__unique_id__in=[status_value['cc_users_email']],
                    level_permission=True,
                ).values_list('user_id',flat=True))
                status_key_url = str(os.getenv('FF_TENDER_LIST_STATUS_URL',''))
                if to_users_list and status_count > 0:
                    context = {
                        "date": current_date,
                        "tot_count": status_count,
                        "status_text" : status_value['status_text'],
                        "status_key" : status_key,
                        "status_key_url" : status_key_url,
                    }
                    trigger_notifications(
                        action='TENDER-AUTO-REMINDER',
                        subject=status_value['subject'],
                        user_list=to_users_list,
                        cc_user_list=cc_users_list,
                        context=context
                    )
        return Response(context)
    
class TenderMasterNewArchivedAPIView(APIView):
    def put(self, request, *args, **kwargs):
        organization_id = request.query_params.get('organization_id')
        if not organization_id:
            raise APIException({
                'request_status': 0,
                'msg': "Organization ID is required in query parameters."
            })
        bulk_data = request.data
        if not isinstance(bulk_data, list):
            raise APIException({
                'request_status': 0,
                'msg': "Invalid body: expected a list of items."
            })
        results = []
        errors = []
        try:
            with transaction.atomic():
                for idx, item in enumerate(bulk_data):
                    id = item.get('id')
                    is_archived = item.get('is_archived')
                    archived_remarks = item.get('archived_remarks')

                    if id is None or is_archived is None:
                        errors.append(f"Index {idx + 1}: Each item must include id and is_archived.")
                        continue
                    try:
                        tender = TenderMasterNew.cmobjects.filter(id=id, organization_id=organization_id).first()
                        if not tender:
                            errors.append(f"ID - {id} not found.")
                            continue
                        tender_id = tender.tender_id
                        update_data = TenderMasterNew.cmobjects.filter(id=id, organization_id=organization_id).update(
                            is_archived=is_archived,
                            is_archived_by=request.user,
                            is_archived_date=timezone.now(),
                            archived_remarks=archived_remarks,
                        ) 
                        if is_archived == True and update_data:
                            results.append(f"Tender ID - {tender_id} archived successfully.")
                        elif is_archived == False and update_data:
                            results.append(f"Tender ID - {tender_id} restore successfully.")
                    except Exception as e:
                        tender_id = getattr(tender, 'tender_id', 'Unknown')
                        errors.append(f"Tender ID - {tender_id}, {str(e)}.")
        except Exception as e:
            raise APIException({
                'request_status': 0,
                'msg': f"Database error during processing: {str(e)}",
                'errors': [str(e)],
                'results': []
            })
        if len(results) == 0:
            raise APIException({
                'request_status': 0,
                'msg': "Failed to archive tenders.",
                'errors': errors or ["No valid tenders provided for archiving."],
                'results': []
            })
        msg = "All tenders archived successfully." if not errors else "Partial success: some items were archived, others failed."
        return Response({
            'request_status': 1,
            'msg': msg,
            'results_count': len(results),
            'results': results,
            'errors': errors
        }, status=status.HTTP_200_OK)


class TenderMasterNewApprovalRequestLogAPIView(APIView):
    
    

    def get(self, request):
        """
        Get a list of all Tender Master New Cencel Request Log
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            queryset = TenderMasterNewApprovalRequestLog.cmobjects.filter(id=id).first()
            serializer = TenderEmpanelmentTrackerDocumentSerializer(queryset)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])
       
        queryset = TenderMasterNewApprovalRequestLog.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewCencelRequestLogSerializer(queryset, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(queryset, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewCencelRequestLogSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    
class TenderMasterNewApprovalRequestLogCreateAPIView(APIView):
    
    

    def post(self, request):
        """
        Tender Master New Cancel/Reject Request Log API View
        """
        data = request.data if isinstance(request.data, list) else [request.data]
        created_objects = []
        errors = []

        for item in data:
            item['created_by'] = request.user.id
            serializer = TenderMasterNewCencelRequestLogSerializer(
                data=item, context={'request': request}
            )
            if serializer.is_valid():
                try:
                    instance = serializer.save()
                    created_objects.append(
                        TenderMasterNewCencelRequestLogSerializer(instance).data
                    )
                    print("status ####", instance.status)
                    if item.get('status') == 'rejected_request':
                        TenderMasterNew.objects.filter(pk=instance.tender.pk).update(
                            is_reject_request=True,
                            reject_request_by=request.user,
                            reject_request_date=datetime.now()
                        )
                    elif item.get('status') == 'canceled_request':
                        print("TEBDDER ##", instance.tender)
                        TenderMasterNew.objects.filter(pk=instance.tender.pk).update(
                            is_canceled_request=True,
                            canceled_request_by=request.user,
                            canceled_request_date=datetime.now()
                        )
                except Exception as e:
                    errors.append({'data': item, 'error': str(e)})
            else:
                errors.append({'data': item, 'error': serializer.errors})
        if errors:
            return Response({
                'request_status': 0,
                'msg': 'Some records failed to create',
                'errors': errors,
                'created': created_objects
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'results': {'Data': created_objects},
            'msg': 'Successfully created',
            'status': status.HTTP_201_CREATED,
            'request_status': 1
        }, status=status.HTTP_201_CREATED)
    
    def put(self, request):
        """
        Edit a Tender Master New Cencel Request Log
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a TenderEmpanelmentTrackerDocument
                """
                if TenderMasterNewApprovalRequestLog.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderMasterNewApprovalRequestLog.cmobjects.filter(pk=id).first()
                    if details:
                        request.data['updated_by'] = request.user.id
                    serializer = TenderMasterNewCencelRequestLogSerializer(details, data=request.data,partial=True,)

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                """
                Delete a Tender Empanelment Tracker Document
                """
                if TenderMasterNewApprovalRequestLog.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderMasterNewApprovalRequestLog.cmobjects.filter(
                        pk=id, organization_id=organization_id).first()
                    details.is_deleted = True
                    details.updated_by_id = request.user.id
                    details.save()

                    return Response({'results': {
                        'Data': TenderMasterNewApprovalRequestLog.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderEmpanelmentTrackerTypeMasterAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        
        if id:
            list_data = TenderEmpanelmentTrackerTypeMaster.cmobjects.filter(id=id).first()
            serializer = TenderEmpanelmentTrackerTypeMasterSerializer(list_data)
            return Response(serializer.data)
        
        list_data = TenderEmpanelmentTrackerTypeMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderEmpanelmentTrackerTypeMasterSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderEmpanelmentTrackerTypeMasterSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderEmpanelmentTrackerTypeMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        details = TenderEmpanelmentTrackerTypeMaster.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderEmpanelmentTrackerTypeMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderEmpanelmentTrackerTypeMaster.cmobjects.filter(pk=id).first()
                    serializer = TenderEmpanelmentTrackerTypeMasterSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderEmpanelmentTrackerTypeMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderEmpanelmentTrackerTypeMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderEmpanelmentTrackerTypeMaster.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

#Survey
class TenderMasterNewSurveyMasterAllAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = {}
        has_permission = UserWiseModulePermissions.objects.filter(
            user=request.user,
            module_item__unique_id__in=['tender-site-survey-manager'],
            level_permission=True,
            is_deleted=False
        ).exists()
        if not has_permission:
            search = {'users__in__or__created_by': f"{request.user.id}__or__{request.user.id}"}
        search = custom_filters(self.request, search, [])
        if id:
            list_data = TenderMasterNewSurveyMaster.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterAllSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMaster.cmobjects.filter(*search).order_by(*str(order_by).split(",")).distinct()
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterAllSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterAllSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

class TenderMasterNewSurveyMasterAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = {}
        has_permission = UserWiseModulePermissions.objects.filter(
            user=request.user,
            module_item__unique_id__in=['tender-site-survey-manager'],
            level_permission=True,
            is_deleted=False
        ).exists()
        if not has_permission:
            search = {'users__in__or__created_by': f"{request.user.id}__or__{request.user.id}"}
        search = custom_filters(self.request, search, [])
        if id:
            list_data = TenderMasterNewSurveyMaster.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMaster.cmobjects.filter(*search).order_by(*str(order_by).split(",")).distinct()
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterSerializer(data=request.data, context={'request': request})
        users = self.request.data.get('users', [])
        if serializer.is_valid():
            try:
                obj = serializer.save()
                if users:
                    send_tender_site_survey_checklist_assigned_email(users, serializer.data)
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        request.data['updated_by'] = request.user.id
        details = TenderMasterNewSurveyMaster.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderMasterNewSurveyMaster.cmobjects.filter(pk=id).first()
                    existing_users = list(details.users.values_list('id', flat=True))
                    serializer = TenderMasterNewSurveyMasterSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            obj = serializer.save()
                            new_users = request.data.get('users', [])
                            added_users = list(set(new_users)-set(existing_users))
                            if added_users:
                                send_tender_site_survey_checklist_assigned_email(added_users, serializer.data)
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = TenderMasterNewSurveyMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMaster.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterSiteDetailsAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterSiteDetails.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterSiteDetailsSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterSiteDetails.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterSiteDetailsSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterSiteDetailsSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterSiteDetailsSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterSiteDetails.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterSiteDetails.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterSiteDetails.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterSiteDetailsSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterSiteDetails.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterSiteDetails.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterSiteDetails.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterFacilitySiteAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterFacilitySite.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterFacilitySiteSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterFacilitySite.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterFacilitySiteSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterFacilitySiteSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterFacilitySiteSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterFacilitySite.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterFacilitySite.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterFacilitySite.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterFacilitySiteSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        # try:
                        serializer.save()
                        # except Exception as e:
                        #     error_message = str(e.args[0]) if e.args else str(e)
                        #     raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterFacilitySite.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterFacilitySite.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterFacilitySite.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterClimateAtSiteAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterClimateAtSite.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterClimateAtSiteSiteSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterClimateAtSite.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterClimateAtSiteSiteSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterClimateAtSiteSiteSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterClimateAtSiteSiteSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterClimateAtSite.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterClimateAtSite.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterClimateAtSite.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterClimateAtSiteSiteSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterClimateAtSite.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterClimateAtSite.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterClimateAtSite.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderMasterNewSurveyMasterHydrologicalMarineConditionAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterHydrologicalMarineCondition.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterHydrologicalMarineConditionSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterHydrologicalMarineCondition.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterHydrologicalMarineConditionSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterHydrologicalMarineConditionSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterHydrologicalMarineConditionSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterHydrologicalMarineCondition.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterHydrologicalMarineCondition.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterHydrologicalMarineCondition.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterHydrologicalMarineConditionSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterHydrologicalMarineCondition.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterHydrologicalMarineCondition.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterHydrologicalMarineCondition.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderMasterNewSurveyMasterTopographyAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterTopography.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterTopographySerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterTopography.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterTopographySerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterTopographySerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterTopographySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterTopography.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterTopography.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterTopography.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterTopographySerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterTopography.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterTopography.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterTopography.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterGeologicalDataAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterGeologicalData.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterGeologicalDataSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterGeologicalData.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterGeologicalDataSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterGeologicalDataSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterGeologicalDataSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterGeologicalData.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterGeologicalData.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterGeologicalData.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterGeologicalDataSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterGeologicalData.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterGeologicalData.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterGeologicalData.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderMasterNewSurveyMasterLocalIssuesAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterLocalIssues.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterLocalIssuesSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterLocalIssues.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterLocalIssuesSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterLocalIssuesSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterLocalIssuesSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterLocalIssues.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterLocalIssues.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterLocalIssues.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterLocalIssuesSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterLocalIssues.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterLocalIssues.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterLocalIssues.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterConstructionMaterialsAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterConstructionMaterialsSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterConstructionMaterialsSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterConstructionMaterialsSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        """
        Bulk Create & Update
        """
        request_data = request.data if isinstance(request.data, list) else [request.data]
        results = {"success": [], "errors": []}
        with transaction.atomic():
            # try:
                payload_ids = [data.get("id") for data in request_data if "id" in data]

                survey_id = request_data[0].get("survey")
                existing_items = TenderMasterNewSurveyMasterConstructionMaterials.objects.filter(survey=survey_id)
                existing_ids = list(existing_items.values_list("id", flat=True))

                ids_to_delete = set(existing_ids) - set(payload_ids)
                if ids_to_delete:
                    TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(id__in=ids_to_delete).update(
                        is_deleted=True,   
                        updated_by=request.user.id
                    )
                for data in request_data:
                    serializer = None
                    if 'id' in data:
                        instance = TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(pk=data['id']).first()
                        data['updated_by'] = request.user.id
                        serializer = TenderMasterNewSurveyMasterConstructionMaterialsSerializer(instance, data=data, partial=True, context={'request': request})
                    else:
                        data['created_by'] = request.user.id
                        serializer = TenderMasterNewSurveyMasterConstructionMaterialsSerializer(data=data, context={'request': request})
                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": data,
                            "error": serializer.errors,
                            "msg": "Validation failed"
                        })
            # except Exception as e:
            #     results["errors"].append({
            #         "error": str(e),
            #         "msg": "Something went wrong. If the problem persists, please contact support."
            #     })
        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        })  
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterConstructionMaterialsSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterConstructionMaterials.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderMasterNewSurveyMasterSubContractorAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterSubContractor.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterSubContractorSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterSubContractor.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterSubContractorSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterSubContractorSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterSubContractorSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            # try:
            serializer.save()
            # except Exception as e:
            #     error_message = str(e.args[0]) if e.args else str(e)
            #     raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterSubContractor.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterSubContractor.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterSubContractor.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterSubContractorSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterSubContractor.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterSubContractor.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterSubContractor.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class SurveyEmployeeCategoriesMasterAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = SurveyEmployeeCategoriesMaster.cmobjects.filter(id=id).first()
            serializer = SurveyEmployeeCategoriesMasterSerializer(list_data)
            return Response(serializer.data)
        list_data = SurveyEmployeeCategoriesMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = SurveyEmployeeCategoriesMasterSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = SurveyEmployeeCategoriesMasterSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request_data = request.data if isinstance(request.data, list) else [request.data]
        results = {"success": [], "errors": []}
        with transaction.atomic():
            try:
                for data in request_data:
                    serializer = None
                    if 'id' in data:
                        instance = SurveyEmployeeCategoriesMaster.cmobjects.filter(pk=data['id']).first()
                        data['updated_by'] = request.user.id
                        serializer = SurveyEmployeeCategoriesMasterSerializer(instance, data=data, partial=True, context={'request': request})
                    else:
                        data['created_by'] = request.user.id
                        serializer = SurveyEmployeeCategoriesMasterSerializer(data=data, context={'request': request})

                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": data,
                            "error": serializer.errors,
                            "msg": "Validation failed"
                        })

            except Exception as e:
                results["errors"].append({
                    "error": str(e),
                    "msg": "Something went wrong. If the problem persists, please contact support."
                })

        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        }) 


    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = SurveyEmployeeCategoriesMaster.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if SurveyEmployeeCategoriesMaster.cmobjects.filter(pk=id).exists():
                    details = SurveyEmployeeCategoriesMaster.cmobjects.filter(pk=id).first()
                    serializer = SurveyEmployeeCategoriesMasterSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if SurveyEmployeeCategoriesMaster.cmobjects.filter(pk=id).exists():
                    details = SurveyEmployeeCategoriesMaster.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': SurveyEmployeeCategoriesMaster.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class SurveyEmployeeCategoriesMasterAreaAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = SurveyEmployeeCategoriesMasterArea.cmobjects.filter(id=id).first()
            serializer = SurveyEmployeeCategoriesMasterAreaSerializer(list_data)
            return Response(serializer.data)
        list_data = SurveyEmployeeCategoriesMasterArea.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = SurveyEmployeeCategoriesMasterAreaSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = SurveyEmployeeCategoriesMasterAreaSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request_data = request.data if isinstance(request.data, list) else [request.data]
        results = {"success": [], "errors": []}
        with transaction.atomic():
            try:
                for data in request_data:
                    serializer = None
                    if 'id' in data:
                        instance = SurveyEmployeeCategoriesMasterArea.cmobjects.filter(pk=data['id']).first()
                        data['updated_by'] = request.user.id
                        serializer = SurveyEmployeeCategoriesMasterAreaSerializer(instance, data=data, partial=True, context={'request': request})
                    else:
                        data['created_by'] = request.user.id
                        serializer = SurveyEmployeeCategoriesMasterAreaSerializer(data=data, context={'request': request})

                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": data,
                            "error": serializer.errors,
                            "msg": "Validation failed"
                        })
            except Exception as e:
                results["errors"].append({
                    "error": str(e),
                    "msg": "Something went wrong. If the problem persists, please contact support."
                })

    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = SurveyEmployeeCategoriesMasterArea.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if SurveyEmployeeCategoriesMasterArea.cmobjects.filter(pk=id).exists():
                    details = SurveyEmployeeCategoriesMasterArea.cmobjects.filter(pk=id).first()
                    serializer = SurveyEmployeeCategoriesMasterAreaSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if SurveyEmployeeCategoriesMasterArea.cmobjects.filter(pk=id).exists():
                    details = SurveyEmployeeCategoriesMasterArea.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': SurveyEmployeeCategoriesMasterArea.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class TenderMasterNewSurveyMasterLabourAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterLabour.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterLabourSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterLabour.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterLabourSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterLabourSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterLabourSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterLabour.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterLabour.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterLabour.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterLabourSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterLabour.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterLabour.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterLabour.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        """
        Bulk Create & Update
        """
        request_data = request.data if isinstance(request.data, list) else [request.data]
        results = {"success": [], "errors": []}
        with transaction.atomic():
            try:
                for data in request_data:
                    serializer = None
                    if 'id' in data:
                        instance = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.filter(pk=data['id']).first()
                        data['updated_by'] = request.user.id
                        serializer = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateSerializer(instance, data=data, partial=True, context={'request': request})
                    else:
                        data['created_by'] = request.user.id
                        serializer = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateSerializer(data=data, context={'request': request})

                    if serializer.is_valid():
                        serializer.save()
                        results["success"].append({
                            "data": serializer.data,
                            "msg": "Successfully created"
                        })
                    else:
                        results["errors"].append({
                            "data": data,
                            "error": serializer.errors,
                            "msg": "Validation failed"
                        })

            except Exception as e:
                results["errors"].append({
                    "error": str(e),
                    "msg": "Something went wrong. If the problem persists, please contact support."
                })

        return Response({
            'results': results,
            'status': status.HTTP_201_CREATED,
            "request_status": 1
        }) 
    

    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderMasterNewSurveyMasterFuelAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterFuel.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterFuelSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterFuel.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterFuelSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterFuelSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterFuelSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    
    
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterFuel.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterFuel.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterFuel.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterFuelSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterFuel.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterFuel.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterFuel.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderMasterNewSurveyMasterAccommodationAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterAccommodation.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterAccommodationSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterAccommodation.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterAccommodationSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterAccommodationSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterAccommodationSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    
    
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterAccommodation.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterAccommodation.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterAccommodation.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterAccommodationSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterAccommodation.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterAccommodation.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterAccommodation.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderMasterNewSurveyMasterTemporarySetupAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterTemporarySetup.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterTemporarySetupSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterTemporarySetup.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterTemporarySetupSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterTemporarySetupSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterTemporarySetupSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    
    
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterTemporarySetup.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterTemporarySetup.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterTemporarySetup.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterTemporarySetupSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterTemporarySetup.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterTemporarySetup.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterTemporarySetup.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderMasterNewSurveyMasterTaxesDutiesAPIView(APIView):
    
    
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterTaxesDuties.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterTaxesDutiesSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterTaxesDuties.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterTaxesDutiesSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterTaxesDutiesSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterTaxesDutiesSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    
    
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterTaxesDuties.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterTaxesDuties.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterTaxesDuties.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterTaxesDutiesSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterTaxesDuties.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterTaxesDuties.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterTaxesDuties.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterSubcontractorsAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterSubcontractors.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterSubcontractorsSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterSubcontractors.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterSubcontractorsSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterSubcontractorsSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterSubcontractorsSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterSubcontractors.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterSubcontractors.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterSubcontractors.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterSubcontractorsSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterSubcontractors.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterSubcontractors.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterSubcontractors.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterAccessCrossingsRouteDetails.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterAccessCrossingsRouteDetails.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterAccessCrossingsRouteDetails.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterAccessCrossingsRouteDetails.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterAccessCrossingsRouteDetails.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterAccessCrossingsRouteDetails.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterAccessCrossingsRouteDetails.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterAccessCrossingsRouteDetails.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterWasteManagementAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterWasteManagement.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterWasteManagementSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterWasteManagement.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterWasteManagementSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterWasteManagementSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterWasteManagementSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterWasteManagement.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterWasteManagement.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterWasteManagement.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterWasteManagementSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterWasteManagement.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterWasteManagement.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterWasteManagement.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterMiscAPIView(APIView):
    
    

    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterMisc.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterMiscSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterMisc.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterMiscSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterMiscSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterMiscSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterMisc.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterMisc.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterMisc.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterMiscSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterMisc.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterMisc.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterMisc.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterReferenceSimilarProjectsAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterReferenceSimilarProjects.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterReferenceSimilarProjectsSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterReferenceSimilarProjects.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterReferenceSimilarProjectsSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterReferenceSimilarProjectsSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterReferenceSimilarProjectsSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterReferenceSimilarProjects.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterReferenceSimilarProjects.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterReferenceSimilarProjects.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterReferenceSimilarProjectsSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterReferenceSimilarProjects.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterReferenceSimilarProjects.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterReferenceSimilarProjects.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterExistingUtilitiesAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterExistingUtilities.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterExistingUtilitiesSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterExistingUtilities.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterExistingUtilitiesSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterExistingUtilitiesSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderMasterNewSurveyMasterExistingUtilitiesSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderMasterNewSurveyMasterExistingUtilities.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterExistingUtilities.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterExistingUtilities.cmobjects.filter(pk=id).first()
                    serializer = TenderMasterNewSurveyMasterExistingUtilitiesSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterExistingUtilities.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterExistingUtilities.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterExistingUtilities.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class TenderMasterNewSurveyMasterApprovalAPIView(APIView):
    """Site Survey Status API View"""
    VALID_TRANSITIONS = {
        "draft": ["in_progress", "draft"],
        "submit": ["in_progress", "draft"],
        "approved": ["submit"],
        "rejected": ["submit"],
    }
    def put(self, request):
        count = 0
        error_details = []
        with transaction.atomic():
            status_list = [c[0] for c in TenderMasterNewSurveyMaster.status.field.choices]
            bulk_datas = request.data if isinstance(request.data, list) else [request.data]
            for idx, bulk_data in enumerate(bulk_datas):
                try:
                    target_status = bulk_data.get('status')
                    survey_id = bulk_data.get('id')

                    if not target_status or not survey_id:
                        raise APIException("Missing 'status' or 'id' in the request data.")
                    if target_status not in status_list:
                        raise ValueError("Invalid or unknown status value provided.")
                    index = status_list.index(target_status)
                    applicable_status = status_list[index - 1] if index > 0 else None

                    search = {'id': survey_id}
                    if target_status == 'draft':
                        search['status__in'] = ['in_progress', 'draft']
                    elif target_status == 'submit':
                        search['status__in'] = ['in_progress', 'draft']
                    elif target_status in ['approved', 'rejected']:
                        search['status__in'] = ['submit',]

                    current_status = TenderMasterNewSurveyMaster.cmobjects.filter(
                        id=survey_id
                    ).values_list("status", flat=True).first()
                    if not current_status:
                        raise APIException(f"Survey ID {survey_id} not found.")

                    if current_status in target_status and target_status not in ['draft']:
                        raise APIException({'request_status': 0, 'msg': f'This Site Survey has already been {current_status}.'})
                        continue

                    allowed_previous = self.VALID_TRANSITIONS.get(target_status, [])
                    if current_status not in allowed_previous:
                        error_details.append({
                            "error": f"This Site Survey has already been {current_status} and cannot be {target_status}."
                        })
                        continue

                    update_data = {
                        'status': target_status,
                        f"{target_status}_by_id": request.user.id,
                        f"{target_status}_by_date": datetime.now(),
                        f"{target_status}_remarks": bulk_data['remarks'] if 'remarks' in bulk_data else '',
                    }
                    # check permissison
                    if target_status in ['approved', 'rejected']:
                        permission_map = ['approver', ]
                        permission_items = [f'tender-survey-{perm}' for perm in permission_map]
                        has_permission = UserWiseModulePermissions.cmobjects.filter(
                            user=request.user,
                            module_item__unique_id__in=permission_items,
                            level_permission=True,
                        ).exists()
                        if not has_permission:
                            raise APIException({'request_status': 0,'msg': "User does not have permission for this action"})
                    elif target_status in ['draft', 'submit']:
                        has_permission = TenderMasterNewSurveyMaster.cmobjects.filter(users__in=[self.request.user], id=survey_id).exists()
                        if not has_permission:
                            raise APIException({'request_status': 0,'msg': "Permission denied. You are not authorized user to perform this action"})
                    
                    indicator = TenderMasterNewSurveyMaster.cmobjects.filter(**search).exclude(status='rejected').update(**update_data)
                    if indicator == 0:
                        error_details.append({
                            'index': idx,
                            'error': f"Survey ID {survey_id}: Not updated"
                        })
                    else:
                        count += indicator
                        if target_status == "submit":
                            send_tender_site_survey_submission_email(survey_id, request.user)
                    TenderMasterNewSurveyMasterApprovalRequestLog.objects.create(
                        survey_id=survey_id,
                        user=request.user,
                        status=target_status,
                        previous_status=applicable_status,
                        remarks=bulk_data.get('remarks', '')
                    )
                except ValueError as e:
                    error_details.append({'index': idx, 'error': str(e)})
                except APIException as e:
                    error_msg = e.detail.get('msg') if isinstance(e.detail, dict) else str(e.detail)
                    error_details.append({'index': idx, 'error': error_msg})
                except Exception as e:
                    error_details.append({'index': idx, 'error': str(e)})

            if error_details:
                raise APIException({
                    'request_status': 0,
                    'msg': [err['error'] for err in error_details],
                })
            return Response({
                "request_status": 1,
                'msg': 'Successfully updated.',
                'results': count
            }, status=200)
class TenderMonitoringPendingEMDEmailTriggerAPIView(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        """
        Monitoring of pending EMDs, if no action taken, every 31 days after Financial Bid Open Date
        """
        current_date = datetime.now().date()
        pending_since_date = current_date - timedelta(days=31)
        print("pending_since_date ############", pending_since_date)
        rank_subquery = TenderMasterNewWinLossAnalysis.cmobjects.filter(
            tender=OuterRef('pk')).values('rank')[:1]
        tender_data = TenderMasterNew.cmobjects.annotate(
            rank_value=Subquery(rank_subquery, output_field=IntegerField())
            ).filter(status__in=['win', 'loss', 'canceled', 'rejected'], financial_bid_open_date__lte=pending_since_date,
            is_emd_deposition=True, is_emd_received_by_account=False).values(
            'id','tender_id','financial_bid_open_date','emd_amount','emd_type','emd_deposition_location','emd_validity_date',
            'emd_checked_by_account', 'tender_organization__employee_name', 'proposed_tender', 'bg_value', 'emd_amount', 'rank_value')

        to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['tender-pending-emds-to'],
                level_permission=True,
            ).values_list('user_id', flat=True))
        cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
                module_item__unique_id__in=['tender-pending-emds-cc'],
                level_permission=True,
            ).values_list('user_id', flat=True))
        context = {}
        if tender_data:
            subject = "List of pending EMDs with details for follow-up"
            context = {
                "date": current_date.strftime('%d-%m-%Y'),
                "data": list(tender_data),
            }
            trigger_notifications(
                action='TENDER-AUTO-PENDING-EMDS',
                subject=subject,
                user_list=to_users_list,
                cc_user_list=cc_users_list,
                context=context
            )
        return Response(context)

class TenderSiteSurveySubmitPendingReminderEmailTriggerAPIView(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        """
        Trigger reminder email 7 days before Tender Due Date
        if Site Survey status is  'draft and in_progress'.
        """
        current_date = datetime.now().date()
        survey_pending_exists = TenderMasterNewSurveyMaster.cmobjects.filter(
            tender=OuterRef('pk'),
            status__in=['in_progress', 'draft']   
        )
        days_offset = int(os.getenv('TENDER_SURVEY_SUBMIT_DAYS', '7'))
        _list = TenderMasterNew.cmobjects.annotate(
            has_pending_survey=Exists(survey_pending_exists)
        ).filter(
            has_pending_survey=True,due_date__gte=current_date, due_date = current_date + timedelta(days=days_offset),      
            is_archived=False,
            is_reject_request=False,
            due_date__isnull=False
        ).values('id', 'tender_id', 'due_date')
        
        to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['tender-site-survey-pending-reminder-to'],
            level_permission=True,
        ).values_list('user_id', flat=True))
        cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['tender-site-survey-pending-reminder-cc'],
            level_permission=True,
        ).values_list('user_id', flat=True))
        result = []
        if _list:
            for item in _list:
                survey_users = list(
                    TenderMasterNewSurveyMaster.cmobjects.filter(
                        tender_id=item['id'],
                        status__in=['in_progress', 'draft']
                    ).values_list('users__id', flat=True)
                )
                final_to_users = list(set(to_users_list + survey_users))
                subject = f"Reminder for Submission of the Site Survey Checklist_{item['tender_id']}"
                context = {
                    "date": current_date.strftime('%d-%m-%Y'),
                    "tender_pk" : item['id'],
                    "tender_id": item['tender_id'],
                    "due_date": item['due_date'].strftime('%d-%m-%Y'),
                    "ref_url": f"{str(os.getenv('FE_TENDER_SURVEY_URL', '#'))}{item['id']}",
                    "reminder_date" : current_date + timedelta(days=7),
                }
                result.append(context)
                trigger_notifications(
                    action='TENDER-SITE-SURVEY-PENDING-REMINDER',
                    subject=subject,
                    user_list=final_to_users,
                    cc_user_list=cc_users_list,
                    context=context
                )
        return Response(result)
    

class TenderCostEstimationPendingReminderEmailAPIView(APIView):
    """A reminder email for the Cost Estimation should be triggered 7 days before the Tender  Due Date."""
    permission_classes = (AllowAny,)
    def get(self, request):
        current_date = datetime.now().date()
        reminder_date = current_date - timedelta(days=7)
        cost_document_exists = TenderMasterNewQualificationDocuments.cmobjects.filter(
            tender=OuterRef('pk'),
            doc_type="cost_document"
        )
        _list = TenderMasterNew.cmobjects.annotate(
            has_cost_document=Exists(cost_document_exists)
        ).filter(
            has_cost_document=False, due_date__gte=current_date, due_date = current_date + timedelta(days=7), is_archived=False, is_reject_request=False, due_date__isnull=False
        ).values('id', 'tender_id', 'due_date')
        to_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['tender-cost-estimation-form-pending-reminder-to'],
            level_permission=True,
        ).values_list('user_id', flat=True))
        cc_users_list = list(UserWiseModulePermissions.cmobjects.filter(
            module_item__unique_id__in=['tender-cost-estimation-form-pending-reminder-cc'],
            level_permission=True,
        ).values_list('user_id', flat=True))
        result = []
        if _list:
            for item in _list:
                subject = f"Reminder for Submission of Cost Estimation for {item['tender_id']}"
                context = {
                    "date": current_date.strftime('%d-%m-%Y'),
                    "tender_id": item['tender_id'],
                    "due_date": item['due_date'].strftime('%d-%m-%Y'),
                    "ref_url": f"{str(os.getenv('FE_TENDER_COST_FORM_URL', '#'))}{item['id']}",
                    "reminder_date" : reminder_date,
                }
                result.append(context)
                trigger_notifications(
                    action='TENDER-COST-ESTIMATION-FORM-PENDING-REMINDER',
                    subject=subject,
                    user_list=to_users_list,
                    cc_user_list=cc_users_list,
                    context=context
                )
        return Response(result)


class TenderMasterNewAutoBlockedCostEstimationAPIView(APIView):
    """
    API View to automatically The Cost Estimation tab should provide only the upload option, and the 
    uploaded documents must remain frozen 5 days before the Tender Due date. No modifications should be 
    allowed unless explicitly approved by GP Sir.
    """
    permission_classes = (AllowAny,)
    def get(self, request, *args, **kwargs):
        try:
            current_date = datetime.now().date()
            cutoff_date = current_date + timedelta(days=5)
            # queryset = TenderMasterNew.cmobjects.filter(
            #     due_date__isnull=False,
            #     due_date__lte=current_date + timedelta(days=5),
            #     is_archived=False,
            #     is_reject_request=False,
            # ).update(is_estimation_form_locked=True)
            queryset = TenderMasterNew.cmobjects.filter(
                due_date__isnull=False,
                is_archived=False,
                is_reject_request=False,
            ).update(
                is_estimation_form_locked=Case(
                    When(due_date__lte=cutoff_date, then=Value(True)),
                    default=Value(False),
                    output_field=BooleanField()
                )
            )
            response_data = {
                "today_date": current_date,
                "request_status": 1,
                "updated Data": queryset,
            }
            return Response(response_data)
        except Exception as e:
            error_msg = f"Error in Tender auto Cost Estimation Locked: {str(e)}"
            raise APIException({
                "request_status": 0,
                "msg": error_msg
            })

class TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderMasterNewSurveyMasterConstructionMaterialsAttachments.cmobjects.filter(id=id).first()
            serializer = TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderMasterNewSurveyMasterConstructionMaterialsAttachments.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        if not isinstance(request.data, list):
            return
        serializer = TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsSerializer(data=request.data, many=True, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    
    def put(self, request):
        method = self.request.query_params.get('method', None)
        survey_id = self.request.query_params.get('survey', None)
        details = TenderMasterNewSurveyMasterConstructionMaterialsAttachments.cmobjects.filter(survey_id=survey_id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderMasterNewSurveyMasterConstructionMaterialsAttachments.cmobjects.filter(survey_id=survey_id).exists():
                    details = TenderMasterNewSurveyMasterConstructionMaterialsAttachments.cmobjects.filter(survey_id=survey_id).first()
                    serializer = TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsSerializer(details, data=request.data,
                                                          context={'request': request}, many=True)
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderMasterNewSurveyMasterConstructionMaterialsAttachments.cmobjects.filter(pk=id).exists():
                    details = TenderMasterNewSurveyMasterConstructionMaterialsAttachments.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderMasterNewSurveyMasterConstructionMaterialsAttachments.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
class TenderTrendAnalysisAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = custom_filters(self.request, {}, [])
        if id:
            list_data = TenderTrendAnalysis.cmobjects.filter(id=id).first()
            serializer = TenderTrendAnalysisSerializer(list_data)
            return Response(serializer.data)
        list_data = TenderTrendAnalysis.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = TenderTrendAnalysisSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = TenderTrendAnalysisSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = TenderTrendAnalysisSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        details = TenderTrendAnalysis.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if TenderTrendAnalysis.cmobjects.filter(pk=id).exists():
                    details = TenderTrendAnalysis.cmobjects.filter(pk=id).first()
                    serializer = TenderTrendAnalysisSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if TenderTrendAnalysis.cmobjects.filter(pk=id).exists():
                    details = TenderTrendAnalysis.cmobjects.get(pk=id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': TenderTrendAnalysis.cmobjects.filter(pk=id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
