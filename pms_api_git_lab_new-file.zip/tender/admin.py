from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from .models import *
from django.contrib.admin import DateFieldListFilter

class TenderEventsLevelAdmin(StackedInline):
    """
	    TenderEventsLevel Admin
	"""

    model = TenderEventsLevel
    fk_name = 'tender_events'


class TenderWBSKeyScopesAdmin(StackedInline):
    """
     TenderWBSKeyScopes Inline Admin
     """
    model = TenderWBSKeyScopes
    fk_name = 'wbs'
    list_display = [field.name for field in TenderWBSKeyScopes._meta.get_fields()]


@admin.register(TenderWBS)
class TenderWBSAdmin(ModelAdmin):
    list_display = ['id', 'wbs_name', 'category', 'parent_id', 'is_deleted']
    search_fields = ('wbs_name',)
    # inlines = (TenderWBSKeyScopesAdmin,) 
admin.site.register(TenderWBSProject,ModelAdmin)

admin.site.register(WbsAttribute,ModelAdmin)  # one 2 one with TenderWBS

@admin.register(TenderWorkFlow)
class TenderWorkFlowTable(ModelAdmin):
    list_display = ['id', 'step_name', 'parent_id', 'reverse_id', 'action_type']
    search_fields = ('step_name', 'parent_id', 'action_type')


@admin.register(TenderEvents)
class TenderEvents(ModelAdmin):
    list_display = ['id', 'event_name', 'start_hour', 'end_hour', 'status', 'priority', 'notify_assignee',
                    'remind_assignee']
    search_fields = ('event_name', 'event_descriptions')
    inlines = (TenderEventsLevelAdmin,)


admin.site.register(TenderNotifications,ModelAdmin)


@admin.register(Tender)
class Tender(ModelAdmin):
    list_display = ['id', 'form', 'value_character', 'value_integer']
    search_fields = ('form', 'value_character', 'value_integer')


@admin.register(TenderDocument)
class TenderDocument(ModelAdmin):
    list_display = ['id', 'form', 'tender', 'name_of_document', 'document']
    search_fields = ('name_of_document',)


@admin.register(TenderMaster)
class TenderMasterAdmin(ModelAdmin):
    list_display = ('id', 'status', 'last_approved_by', 'last_approved_by_date', 'is_deleted')
    list_filter = ['status', 'is_deleted']

    def last_approved_by(self, obj):
        return getattr(obj, obj.status+'_by',None)
    def last_approved_by_date(self, obj):
        return getattr(obj, obj.status+'_by_date',None)


class TenderDataAdmin(ModelAdmin):
    list_display = ('id', 'get_form_master_id', 'tender', 'value')
    search_fields = ('id', 'form__form_internal_name__icontains')

    def get_form_master_id(self, obj):
        return obj.form.form_internal_name if obj.form else ''

    get_form_master_id.short_description = 'Form Master IT name'


admin.site.register(TenderData, TenderDataAdmin)


@admin.register(ExecutiveSummeryData)
class ExecutiveSummeryDataAdmin(ModelAdmin):
    list_display = ['id', 'tender', 'wbs', 'form', 'value']


@admin.register(ChainageExecutiveSummeryData)
class ChainageExecutiveSummeryDataAdmin(ModelAdmin):
    list_display = ['id', 'tender', 'wbs', 'form', 'value']


@admin.register(TenderChainage)
class TenderChainageAdmin(ModelAdmin):
    search_fields = ('tender__id', 'name')
    list_display = ['id', 'tender', 'name', 'start', 'end']


@admin.register(TenderWBSKeyScopes)
class TenderWBSKeyScopesAdmin(ModelAdmin):
    list_display = ['id', 'keyscope']


@admin.register(TenderWBSSecondKeyScopes)
class TenderWBSSecondKeyScopesAdmin(ModelAdmin):
    list_display = ['id', 'name']


@admin.register(TopSheetMap)
class TopSheetMapAdmin(ModelAdmin):
    search_fields = ('tender__id', 'title')
    list_display = ['id', 'code', 'title', 'parent', 'percentage', 'tender']


class TenderCompliancesDataAdmin(StackedInline):
    """
	TenderCompliancesData Admin
	"""
    model = TenderCompliancesData
    fk_name = 'compliances'


class TenderComplianceDerivativesAdmin(ModelAdmin):
    inlines = (TenderCompliancesDataAdmin,)


class RiskdetailsDataAdmin(StackedInline):
    """
	RiskdetailsData Admin
	"""
    model = RiskdetailsData
    fk_name = 'risk_details'


class RiskdetailsAdmin(ModelAdmin):
    inlines = (RiskdetailsDataAdmin,)


class OpportunitydetailsDataAdmin(StackedInline):
    """
	Opportunitydetails Admin
	"""
    model = OpportunitydetailsData
    fk_name = 'opportunity_details'


class OpportunitydetailsAdmin(ModelAdmin):
    inlines = (OpportunitydetailsDataAdmin,)


class TenderSubSectorAdmin(StackedInline):
    model = TenderSubSector
@admin.register(TenderSector)
class TenderSectorAdmin(ModelAdmin):
    search_fields = ('domain', 'name')
    list_display = ['id', 'domain', 'name', 'is_deleted']
    inlines = (TenderSubSectorAdmin,)


admin.site.register(TenderActivityLog,ModelAdmin)
admin.site.register(TenderExecutiveCommitee,ModelAdmin)
admin.site.register(TenderCommiteeMembers,ModelAdmin)
admin.site.register(TopSheetSaleData,ModelAdmin)
admin.site.register(TopSheetExpenditureData,ModelAdmin)
admin.site.register(TenderSurveyFormGroupCompletion,ModelAdmin)

admin.site.register(TenderComplianceDerivatives, TenderComplianceDerivativesAdmin)

admin.site.register(Riskdetails, RiskdetailsAdmin)

admin.site.register(Opportunitydetails, OpportunitydetailsAdmin)





@admin.register(TenderMasterNew)
class TenderMasterNewAdmin(ModelAdmin):
    """
    TenderMasterNew Admin
    """
    model = TenderMasterNew
    search_fields = ('name', 'code', 'tender_id')
    list_display = [
        'id', 'sector', 'name', 'project_cost', 'due_date', 'is_estimation_form_locked', 'code', 'tender_id',
        'bid_submission_date', 'status', 'is_archived', 'created_at', 'approved_by_date', 'is_reject_request'
    ]
    list_filter = (
        ('approved_by_date', DateFieldListFilter),
        'status',
        'is_archived',
        ('created_at', DateFieldListFilter),
    )
    date_hierarchy = 'created_at'

class TenderMasterNewPartyDetailsAdmin(ModelAdmin):
    list_display = ['id', 'tender', 'company', 'jvmaster', 'is_lead', 'is_deleted']

admin.site.register(TenderMasterNewPartyDetails, TenderMasterNewPartyDetailsAdmin)
class TenderMasterNewQualificationDocumentsAdmin(ModelAdmin):
    list_display = ['id', 'tender', 'doc_type', 'attachment_name', 'file_name', 'attachment']
    search_fields = ('file_name', 'doc_type',)
    list_filter = (
        'tender',
        'doc_type',
        ('created_at', DateFieldListFilter),
    )
admin.site.register(TenderMasterNewQualificationDocuments, TenderMasterNewQualificationDocumentsAdmin)

#survey
class TenderMasterNewSurveyMasterAdmin(ModelAdmin):
    list_display = ['id', 'tender', 'status', 'is_deleted']

admin.site.register(TenderMasterNewSurveyMaster,TenderMasterNewSurveyMasterAdmin)
class TenderMasterNewSurveyMasterSiteDetailsAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterSiteDetails, TenderMasterNewSurveyMasterSiteDetailsAdmin)
class TenderMasterNewSurveyMasterSiteDetailsAttachmentsAdmin(ModelAdmin):
    list_display = ['id', 'site_details', 'attachment_name' ,'attachment','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterSiteDetailsAttachments, TenderMasterNewSurveyMasterSiteDetailsAttachmentsAdmin)
class TenderMasterNewSurveyMasterFacilitySiteAdmin(ModelAdmin):
    list_display = ['id', 'survey','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterFacilitySite, TenderMasterNewSurveyMasterFacilitySiteAdmin)
class TenderMasterNewSurveyMasterFacilitySiteAttachmentsAdmin(ModelAdmin):
    list_display = ['id','facility_site','attachment_name','attachment','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterFacilitySiteAttachments, TenderMasterNewSurveyMasterFacilitySiteAttachmentsAdmin)
class TenderMasterNewSurveyMasterClimateAtSiteAdmin(ModelAdmin):
    list_display = ['id', 'survey','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterClimateAtSite, TenderMasterNewSurveyMasterClimateAtSiteAdmin)
class TenderMasterNewSurveyMasterHydrologicalMarineConditionAdmin(ModelAdmin):
    list_display = ['id', 'survey','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterHydrologicalMarineCondition, TenderMasterNewSurveyMasterHydrologicalMarineConditionAdmin)
class TenderMasterNewSurveyMasterTopographyAdmin(ModelAdmin):
    list_display = ['id', 'survey','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterTopography, TenderMasterNewSurveyMasterTopographyAdmin)
class TenderMasterNewSurveyMasterGeologicalDataAdmin(ModelAdmin):
    list_display = ['id', 'survey','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterGeologicalData, TenderMasterNewSurveyMasterGeologicalDataAdmin)
class TenderMasterNewSurveyMasterLocalIssuesAdmin(ModelAdmin):
    list_display = ['id', 'survey','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterLocalIssues, TenderMasterNewSurveyMasterLocalIssuesAdmin)
class TenderMasterNewSurveyMasterConstructionMaterialsAdmin(ModelAdmin):
    list_display = ['id', 'survey','is_deleted']
admin.site.register(TenderMasterNewSurveyMasterConstructionMaterials, TenderMasterNewSurveyMasterConstructionMaterialsAdmin)

class TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'attachment_name', 'attachment', 'remarks',]
admin.site.register(TenderMasterNewSurveyMasterConstructionMaterialsAttachments, TenderMasterNewSurveyMasterConstructionMaterialsAttachmentsAdmin)

class TenderMasterNewSurveyMasterSubContractorAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterSubContractor, TenderMasterNewSurveyMasterSubContractorAdmin)

class SurveyEmployeeCategoriesMasterAdmin(ModelAdmin):
    list_display = ['id', 'name', 'is_deleted']
admin.site.register(SurveyEmployeeCategoriesMaster, SurveyEmployeeCategoriesMasterAdmin)

class SurveyEmployeeCategoriesMasterAreaAdmin(ModelAdmin):
    list_display = ['id', 'name', 'is_deleted']
admin.site.register(SurveyEmployeeCategoriesMasterArea, SurveyEmployeeCategoriesMasterAreaAdmin)

class TenderMasterNewSurveyMasterLabourAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterLabour, TenderMasterNewSurveyMasterLabourAdmin)

class TenderMasterNewSurveyMasterLabourEmployeeCategoriesAdmin(ModelAdmin):
    list_display = ['id', 'survey_labour', 'employee_category', 'remarks', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterLabourEmployeeCategories, TenderMasterNewSurveyMasterLabourEmployeeCategoriesAdmin)

class TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateAdmin(ModelAdmin):
    list_display = ['id', 'category', 'area', 'total_minimum_wages_per_day_rate', 'total_minimum_wages_per_month_rate', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate, TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRateAdmin)

class TenderMasterNewSurveyMasterFuelAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterFuel, TenderMasterNewSurveyMasterFuelAdmin)

class TenderMasterNewSurveyMasterAccommodationAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterAccommodation, TenderMasterNewSurveyMasterAccommodationAdmin)

class TenderMasterNewSurveyMasterTemporarySetupAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterTemporarySetup, TenderMasterNewSurveyMasterTemporarySetupAdmin)

class TenderMasterNewSurveyMasterTaxesDutiesAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterTaxesDuties, TenderMasterNewSurveyMasterTaxesDutiesAdmin)

class TenderMasterNewSurveyMasterSubcontractorsAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterSubcontractors, TenderMasterNewSurveyMasterSubcontractorsAdmin)

class TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterAccessCrossingsRouteDetails, TenderMasterNewSurveyMasterAccessCrossingsRouteDetailsAdmin)

class TenderMasterNewSurveyMasterWasteManagementAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterWasteManagement, TenderMasterNewSurveyMasterWasteManagementAdmin)

class TenderMasterNewSurveyMasterMiscAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterMisc, TenderMasterNewSurveyMasterMiscAdmin)

class TenderMasterNewSurveyMasterReferenceSimilarProjectsAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterReferenceSimilarProjects, TenderMasterNewSurveyMasterReferenceSimilarProjectsAdmin)

class TenderMasterNewSurveyMasterExistingUtilitiesAdmin(ModelAdmin):
    list_display = ['id', 'survey', 'is_deleted']
admin.site.register(TenderMasterNewSurveyMasterExistingUtilities, TenderMasterNewSurveyMasterExistingUtilitiesAdmin)


class TenderMasterNewWinLossAnalysisAdmin(ModelAdmin):
    list_display = ['id', 'tender', 'partcipant_name', 'bidded_value_in_crore', 'percentage', 'above_below', 'rank', 'is_deleted']
    search_fields = ('tender__tender_id', 'partcipant_name',)
    list_filter = (
        'tender',
        ('created_at', DateFieldListFilter),
    )
admin.site.register(TenderMasterNewWinLossAnalysis, TenderMasterNewWinLossAnalysisAdmin)

class TenderDepartmentMasterAdmin(ModelAdmin):
    list_display = ['id', 'name', 'created_at']
admin.site.register(TenderDepartmentMaster, TenderDepartmentMasterAdmin)

class TenderChecklistMasterAdmin(ModelAdmin):
    list_display =['id', 'created_at', 'tender_department', 'name', 'is_sign_shyam_infra', 'is_sign_ca', 'is_sign_bank']

admin.site.register(TenderChecklistMaster, TenderChecklistMasterAdmin)

admin.site.register(TenderEmpanelmentTrackerTypeMaster,ModelAdmin)
class TenderEmpanelmentTrackerAdmin(ModelAdmin):
    list_display = ['id', 'type', 'organization_name', 'login_user_id', 'created_at', 'created_by']
admin.site.register(TenderEmpanelmentTracker, TenderEmpanelmentTrackerAdmin)
#end survey

class TenderEmpanelmentTrackerDocumentAdmin(ModelAdmin):
    list_display = ['id', 'doc_type', 'empanelment_tracker', 'attachment_name', 'file_name', 'attachment', 'created_at', 'created_by']
admin.site.register(TenderEmpanelmentTrackerDocument, TenderEmpanelmentTrackerDocumentAdmin)


class TenderMasterNewApprovalRequestLogLogAdmin(ModelAdmin):
    list_display = ['id', 'tender', 'user', 'created_at']
admin.site.register(TenderMasterNewApprovalRequestLog, TenderMasterNewApprovalRequestLogLogAdmin)

class TenderTrendAnalysisAdmin(ModelAdmin):
    list_display = ['id', 'sector', 'tender_id', 'work_description', 'tender_value_gst_in_crore', 'awarded_value_in_crore', 'state', 'bid_submission_date', 'financial_bid_opening_date']
admin.site.register(TenderTrendAnalysis, TenderTrendAnalysisAdmin)
class TenderTrendAnalysisAttachmentsAdmin(ModelAdmin):
    list_display = ['id', 'trend_analysis', 'attachment_name', 'attachment', 'remarks','is_deleted']
admin.site.register(TenderTrendAnalysisAttachments, TenderTrendAnalysisAttachmentsAdmin)
class TenderTrendAnalysisParticipantsAdmin(ModelAdmin):
    list_display = ['id', 'trend_analysis', 'partcipant_name', 'bidded_value_in_crore', 'percentage','rank','remarks','is_deleted']
admin.site.register(TenderTrendAnalysisParticipants, TenderTrendAnalysisParticipantsAdmin)