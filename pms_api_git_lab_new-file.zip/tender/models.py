from django.db import models

from administrations.models import *
from email_config.models import *
# Create your models here.
from custom_management.models import *
from material_master.models import UnitOfMesurement, VendorMaterialMaster

class TenderWorkFlow(BaseAbstractStructure):
    """
    Tender WorkFlow Master Model
    """
    organization = models.ForeignKey(Organization, related_name='organization_tender',on_delete=models.CASCADE, null=True, blank=True)
    step_name = models.CharField(max_length=200)
    parent_id = models.IntegerField(default=0)
    reverse_id = models.IntegerField(default=0)
    action_type = models.CharField(max_length=200, blank=True, null=True)
    descriptions = models.TextField(blank=True, null=True)

    def __str__(self) -> str:
        return str(self.step_name)
    

class TenderNotifications(BaseAbstractStructure):
    """
    Tender Notifications Model
    """
    NOTIFICATIONS_TYPE = [
        ("SMS", "SMS"),
        ("EMAIL", "EMAIL"),
    ]
    TRIGGER_TYPE = [
        ("IMMEDIATELY", "IMMEDIATELY"),
        ("SET DATE", "SET DATE")
    ]
    organization = models.ForeignKey(Organization, related_name='organization_tender_noti',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderWorkFlow, related_name='tender_workflows',on_delete=models.CASCADE, null=True, blank=True)
    email_template = models.ForeignKey(EmailTemplates, related_name='tender_emails',on_delete=models.CASCADE, null=True, blank=True)
    sms_template = models.ForeignKey(SmsTemplate, related_name='tender_sms',on_delete=models.CASCADE, null=True, blank=True)

    title = models.CharField(max_length=200, blank=True, null=True)

    notification_type = models.CharField(choices=NOTIFICATIONS_TYPE, default="EMAIL", max_length=20)
    trigger_type = models.CharField(choices=TRIGGER_TYPE, default="IMMEDIATELY", max_length=20)
    date = models.DateTimeField(blank=True, null=True)

    ####### For Emails ########################
    to = models.ManyToManyField(PmsUser, related_name="email_tos", blank=True)
    cc = models.ManyToManyField(PmsUser, related_name="email_ccs", blank=True)

    ####### For Sms ########################
    sms_to = models.ManyToManyField(PmsUser, related_name="sms_tos", blank=True)

    def __str__(self):
        if self.email_template:
            return f"{str(self.tender.step_name)}  ~ {str(self.email_template.template_name)} ~ {self.notification_type} ~ {self.trigger_type}"
        else:
            return f"{str(self.tender.step_name)}  ~ {str(self.sms_template.sms_template_name)} ~ {self.notification_type} ~ {self.trigger_type}"
        

class TenderEvents(BaseAbstractStructure):
    """
    Tender Events Model
    """
    E_TYPE = [
        ("CONFIRMATION", "CONFIRMATION"),
        ("USER EVENT", "USER EVENT"),
    ]
    NOTIFICATIONS_TYPE = [
        ("SMS", "SMS"),
        ("EMAIL", "EMAIL"),
    ]
    TRIGGER_TYPE = [
        ("IMMEDIATELY", "IMMEDIATELY"),
        ("SET DATE", "SET DATE")
    ]
    organization = models.ForeignKey(Organization, related_name='organization_tender_events',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderWorkFlow, related_name='tender_events',on_delete=models.CASCADE, null=True, blank=True)

    event_type = models.CharField(choices=E_TYPE, default="CONFIRMATION", max_length=200)
    event_name = models.CharField(max_length=255)
    event_descriptions = models.TextField(blank=True, null=True)
    event_trigger_type = models.CharField(choices=TRIGGER_TYPE, default="IMMEDIATELY", max_length=20)

    confirmed_by = models.ForeignKey(PmsUser, related_name='event_confirmed_by',on_delete=models.DO_NOTHING, blank=True, null=True) # Only for "Confirmational" Events

    start_hour = models.IntegerField(default=1)
    end_hour = models.IntegerField(default=1)

    assignees = models.ManyToManyField(PmsUser, related_name="event_assignees", blank=True)
    cc_to = models.ManyToManyField(PmsUser, related_name="cc_tos", blank=True)

    status = models.CharField(max_length=200, blank=True, null=True)
    priority = models.CharField(max_length=200, blank=True, null=True)

    notify_assignee = models.BooleanField(default=True)
    remind_assignee = models.BooleanField(default=True)

    send_reminder_in_hours = models.IntegerField(default=1)

    event_notification_type = models.CharField(choices=NOTIFICATIONS_TYPE, default="EMAIL", max_length=20)
    email_template = models.ForeignKey(EmailTemplates, related_name='tender_emails_events',on_delete=models.CASCADE, null=True, blank=True)
    sms_template = models.ForeignKey(SmsTemplate, related_name='tender_sms_events',on_delete=models.CASCADE, null=True, blank=True)


    def __str__(self):
        return str(self.event_name)



class TenderEventsLevel(BaseAbstractStructure):
    """
    Tender Events Level Model
    """
    organization = models.ForeignKey(Organization, related_name='organization_tender_level',on_delete=models.CASCADE, null=True, blank=True)
    tender_events = models.ForeignKey(TenderEvents, related_name='tender_events',on_delete=models.CASCADE, null=True, blank=True)
    level_user = models.ForeignKey(PmsUser, related_name='tender_level_user',on_delete=models.CASCADE, blank=True, null=True)
    level_count = models.IntegerField(default=0)


class Tender(BaseAbstractStructure):
    """
    Add New Tender  Model
    """
    organization = models.ForeignKey(Organization, related_name='organization_tender_add',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='tender_form_masters',on_delete=models.CASCADE, blank=True, null=True)

    value_character=models.CharField(max_length=200, blank=True, null=True) 
    value_integer=models.IntegerField(blank=True,null=True)
    document= models.FileField(
        upload_to='tender/document', null=True, blank=True, help_text='documents')
  


class TenderDocument(BaseAbstractStructure):
    """
    Add Documents to New Tender Model
    """
    organization = models.ForeignKey(Organization, related_name='organization_tender_add_document',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='tender_document_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    tender=models.ForeignKey(Tender, related_name='tender_document_id',on_delete=models.CASCADE, blank=True, null=True)
    name_of_document= models.CharField(max_length=200, blank=True, null=True)

    document= models.FileField(
        upload_to='tender/document', null=True, blank=True, help_text='documents')

    
class TenderBidder(BaseAbstractStructure):
    """
        Tender Bidder Model 
    """
    organization = models.ForeignKey(Organization, related_name='organization_tender_bidder',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(Tender, related_name='tenderbidder_tender_id',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='tender_bidder_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value_character=models.CharField(max_length=200, blank=True, null=True) 
    value_interger=models.IntegerField(blank=True,null=True)
    document= models.FileField(
        upload_to='tender/document', null=True, blank=True, help_text='documents')
    
    
class TenderMaster(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('identified', 'Identified'),
        ('proposed', 'Proposed'),
        ('sent_for_recommendation', 'Sent For Recommendation'),
        ('recommended', 'Recommended'),
        ('sent_for_approval', 'Sent For Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organization_tender_master',on_delete=models.CASCADE, null=True, blank=True)
    ########### Approval Users track when they re send for recommendations

    resend_for_recommendation_remarks = models.TextField(blank=True, null=True)
    resend_user_id = models.IntegerField(blank=True, null=True)
    is_resend_for_recommendations = models.BooleanField(default=False)

    ########### For Form Submission Next Step Activeness
    is_percentage_share_active = models.BooleanField(default=False)
    is_compliance_active = models.BooleanField(default=False)
    is_executive_summary_active = models.BooleanField(default=False)
    is_approval_active = models.BooleanField(default=False)
    is_assignment_active = models.BooleanField(default=False)
    is_survey_active = models.BooleanField(default=False)
    is_top_sheet_active = models.BooleanField(default=False)
    is_final_approval_active = models.BooleanField(default=False)
    is_submission_active = models.BooleanField(default=False)
    is_technical_open_active = models.BooleanField(default=False)
    is_evaluation_active = models.BooleanField(default=False)
    is_lmpi_active = models.BooleanField(default=False)
    is_l1 = models.BooleanField(default=False)
    is_not_l1 = models.BooleanField(default=False)
    ########### For Form Completion ##################
    is_percentage_share_complete = models.BooleanField(default=False)
    is_eligibility_complete = models.BooleanField(default=False)
    is_eligibility_complete_for_proposer = models.BooleanField(default=False)
    is_compliance_complete = models.BooleanField(default=False)
    is_executive_summary_complete = models.BooleanField(default=False)
    is_assignment_complete = models.BooleanField(default=False)
    is_survey_complete = models.BooleanField(default=False)
    is_top_sheet_complete = models.BooleanField(default=False)
    is_submission_complete = models.BooleanField(default=False)
    is_technical_open_complete = models.BooleanField(default=False)
    is_evaluation_complete = models.BooleanField(default=False)
    is_lmpi_complete = models.BooleanField(default=False)
    is_l1_complete = models.BooleanField(default=False)
    is_not_l1_complete = models.BooleanField(default=False)
    ###################################################

    ###################### Survey Status Completion Role Wise ###################
    is_physical_survey_complete = models.BooleanField(default=False)
    is_material_survey_complete = models.BooleanField(default=False)
    is_taxation_survey_complete = models.BooleanField(default=False)
    is_liason_survey_complete = models.BooleanField(default=False)

    physical_survey_completion_date = models.DateField(blank=True, null=True)
    material_survey_completion_date = models.DateField(blank=True, null=True)
    taxation_survey_completion_date = models.DateField(blank=True, null=True)
    liason_survey_completion_date = models.DateField(blank=True, null=True)
    ###############################################################################
    
    is_recommended = models.BooleanField(default=False)
    is_sent_for_recommendation = models.BooleanField(default=False)

    is_vga_approved = models.BooleanField(default=False)
    is_vga_reject = models.BooleanField(default=False)
    is_sent_for_approval = models.BooleanField(default=False)

    is_survey_started = models.BooleanField(default=False) # For SUrvey In Progress Status

    is_sent_for_final_approval = models.BooleanField(default=False)
    is_approved = models.BooleanField(default=False)
    is_reject = models.BooleanField(default=False)

    ex_summary_recommend_requested = models.BooleanField(default=False)
    ex_summary_approval_requested = models.BooleanField(default=False)

    summary_file = models.FileField(
        upload_to="tender_summary_file", blank=True, null=True)
    
    top_sheet_remarks = models.TextField(blank=True, null=True)
    
    tender_proposal_date = models.DateField(blank=True, null=True)
    tender_recommendation_date = models.DateField(blank=True, null=True)
    tender_sent_for_vga_approval_date = models.DateField(blank=True, null=True)
    tender_final_approval_send_date = models.DateField(blank=True, null=True)
    survey_members_assigned_date = models.DateField(blank=True, null=True)
    survey_started_date = models.DateField(blank=True, null=True)
    survey_completed_date = models.DateField(blank=True, null=True)
    l1_selection_date = models.DateField(blank=True, null=True)
    l1_not_selection_date = models.DateField(blank=True, null=True)
    agreement_signing_date = models.DateField(blank=True, null=True)
    rca_date = models.DateField(blank=True, null=True)

    tender_vga_approval_date = models.DateField(blank=True, null=True)
    tender_vga_rejected_date = models.DateField(blank=True, null=True)

    tender_approval_date = models.DateField(blank=True, null=True)
    tender_rejected_date = models.DateField(blank=True, null=True)
    is_archived = models.BooleanField(default=False)

    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="identified")
    # for APPROVED STATUS user
    proposed_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_proposed_by", on_delete=models.CASCADE)
    sent_for_recommendation_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_sent_for_recommendation_by", on_delete=models.CASCADE)
    recommended_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_recommended_by", on_delete=models.CASCADE)
    sent_for_approval_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_sent_for_approval_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_rejected_by", on_delete=models.CASCADE)

    proposed_remarks = models.TextField(max_length=500, null=True, blank=True)
    sent_for_recommendation_remarks = models.TextField(max_length=500, null=True, blank=True)
    recommended_remarks = models.TextField(max_length=500, null=True, blank=True)
    sent_for_approval_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)

    proposed_by_date = models.DateTimeField(blank=True, null=True, )
    sent_for_recommendation_by_date = models.DateTimeField(blank=True, null=True, )
    recommended_by_date = models.DateTimeField(blank=True, null=True, )
    sent_for_approval_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )


class TenderData(BaseAbstractStructure):

    tender = models.ForeignKey(TenderMaster, related_name='tenderbidder_tender_id',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='tender_data_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.TextField(blank=True, null=True) 
    document= models.FileField(
        upload_to='tender/document', null=True, blank=True, help_text='documents')
    by_order = models.IntegerField(default=0)

    def __str__(self):
        return str(self.form.form_internal_name)+" -> "+str(self.value)


class TenderWBS(BaseAbstractStructure):
    """
    Tender WBS Master Model
    """
    CATEGORY = (
        ('highway', 'Highway'),
        ('structure', 'Structure'),
        ('volumetric', 'Volumetric'),
        ('others', 'Others'),
    )
    tender = models.ForeignKey(TenderMaster, related_name='tender_wbs',on_delete=models.CASCADE, null=True, blank=True)
    category = models.CharField(max_length=100, choices=CATEGORY, default='highway')
    # parent_id = models.IntegerField(null=True, blank=True)
    parent_id = models.ForeignKey('self', related_name="tender_wbs_parent_id", on_delete=models.CASCADE, null=True, blank=True)
    wbs_name = models.TextField(null=True, blank=True)
    short_name = models.CharField(max_length=255,null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name="tender_wbs_unit_of_mesurement", on_delete=models.DO_NOTHING, null=True, blank=True)
    is_default = models.BooleanField(default=False)
    slug = models.TextField(null=True, blank=True)
    by_order = models.IntegerField(default=1)
    after_this = models.ForeignKey('self', related_name="tender_wbs_after_this", on_delete=models.CASCADE, null=True, blank=True)
    boq_code = models.CharField(max_length=255,null=True, blank=True)
    boq_no = models.CharField(max_length=255,null=True, blank=True)

    def __str__(self):
        return str(self.wbs_name) + " (" + str(self.category) + ") " + str(self.parent_id)

class TenderChainage(BaseAbstractStructure):
    tender = models.ForeignKey(TenderMaster, related_name='tender_chainage', on_delete=models.CASCADE,)
    wbs = models.ForeignKey(TenderWBS, related_name='tender_chainage_wbs',on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    start = models.FloatField(blank=True, null=True, default=0.)
    end = models.FloatField(blank=True, null=True, default=0.)
    chainage_value = models.FloatField(blank=True, null=True, default=0.)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.start:
            self.start = 0.
        if not self.end:
            self.end = 0.
        self.chainage_value = float(self.end)-float(self.start)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "tender_chainage"


class WbsAttribute(BaseAbstractStructure):
    wbs = models.OneToOneField(
        TenderWBS,
        on_delete=models.CASCADE,
        primary_key=True,
    )
    risk_type = models.CharField(max_length=30, choices=(('FINANCIAL', 'FINANCIAL'), ('NORMAL', 'NORMAL'),), default='NORMAL' )
    color_code = models.CharField(max_length=50, blank=True, null=True, default='#0d6efd')

    def __str__(self):
        return "TenderWBS = %s " % self.wbs.wbs_name



class TenderWBSKeyScopes(BaseAbstractStructure):
    """
    Tender WBS KeyScopes Model
    """
    wbs = models.ForeignKey(TenderWBS, related_name='tender_wbs_key_scope',on_delete=models.CASCADE)
    keyscope = models.CharField(max_length=255, default='')
    uom = models.ForeignKey(UnitOfMesurement, related_name="unit_of_mesurement", on_delete=models.DO_NOTHING)
    unit = models.CharField(max_length=255, default='')
    by_order = models.IntegerField(default=0)

    def __str__(self):
        return str(self.wbs.wbs_name) + " KeyScope " + str(self.keyscope) + " Unit " + str(self.unit)
    

class TenderWBSSecondKeyScopes(BaseAbstractStructure):
    """
    Tender WBS Second KeyScopes Model
    """
    keyscope = models.ForeignKey(TenderWBSKeyScopes, related_name='tender_wbs_second_key_scope',on_delete=models.CASCADE)
    name = models.CharField(max_length=255, default='')
    uom = models.ForeignKey(UnitOfMesurement, related_name="tender_wbs_second_key_scope_uom", on_delete=models.DO_NOTHING)
    unit = models.CharField(max_length=255, default='')
    by_order = models.IntegerField(default=0)

    def __str__(self):
        return str(self.keyscope.keyscope) + " KeyScope " + str(self.name) + " Unit " + str(self.unit)
    


class ExecutiveSummeryData(BaseAbstractStructure):
    tender = models.ForeignKey(TenderMaster, related_name='ex_tender_id',on_delete=models.DO_NOTHING, null=True, blank=True)
    wbs = models.ForeignKey(TenderWBS, related_name='ex_wbs_id',on_delete=models.CASCADE, null=True, blank=True)
    # wbskey = models.ForeignKey(TenderWBSKeyScopes,related_name='ex_wbskey_id',on_delete=models.CASCADE, null=True, blank=True)
    # wbssecondkey = models.ForeignKey(TenderWBSSecondKeyScopes,related_name='ex_wbssecondkey_id',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='ex_data_form_masters',on_delete=models.DO_NOTHING, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)


class ChainageExecutiveSummeryData(BaseAbstractStructure):
    tender = models.ForeignKey(TenderMaster, related_name='tender_chainage_executivesummery_tender',on_delete=models.CASCADE, null=True, blank=True)
    wbs = models.ForeignKey(TenderWBS, related_name='tender_chainage_executivesummery_wbs',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(TenderChainage, related_name='tender_chainage_executivesummery_form',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)
    type = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = "tender_chainage_executivesummery"


class TenderComplianceDerivatives(BaseAbstractStructure):
    """
    Tender Compliance Derivatives Model
    """
    tender = models.ForeignKey(TenderMaster, related_name='compliance_tender_id',on_delete=models.CASCADE, null=True, blank=True)
     

class TenderCompliancesData(BaseAbstractStructure):
    """
    Tender Compliances Data
    """
    compliances = models.ForeignKey(TenderComplianceDerivatives, related_name='tender_compliances',on_delete=models.CASCADE, blank=True, null=True)
    form = models.ForeignKey(FormMaster, related_name='compliance_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)
    table_id = models.CharField(max_length=200, blank=True, null=True)
    

class Riskdetails(BaseAbstractStructure):
    """
    Risk Details Model
    """
    tender = models.ForeignKey(TenderMaster, related_name='risk_details_tender_id',on_delete=models.CASCADE, null=True, blank=True)
     

class RiskdetailsData(BaseAbstractStructure):
    """
    Risk Details Data
    """
    risk_details = models.ForeignKey(Riskdetails, related_name='risk_details',on_delete=models.CASCADE, blank=True, null=True)
    form = models.ForeignKey(FormMaster, related_name='risk_details_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.TextField(blank=True, null=True, max_length=500)
    table_id = models.CharField(max_length=200, blank=True, null=True)
    
class Opportunitydetails(BaseAbstractStructure):
    """
    Risk Details Model
    """
    tender = models.ForeignKey(TenderMaster, related_name='opportunity_details_tender_id',on_delete=models.CASCADE, null=True, blank=True)
     

class OpportunitydetailsData(BaseAbstractStructure):
    """
    Risk Details Data
    """
    opportunity_details = models.ForeignKey(Opportunitydetails, related_name='opportunity_details',on_delete=models.CASCADE, blank=True, null=True)
    form = models.ForeignKey(FormMaster, related_name='opportunity_details_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)
    table_id = models.CharField(max_length=200, blank=True, null=True)



class TenderActivityLog(BaseAbstractStructure):
    """
    Tender Activity Log
    """
    tender = models.ForeignKey(TenderMaster, related_name='tender_activity',on_delete=models.CASCADE, null=True, blank=True)
    date = models.DateField(auto_now_add=True)
    activity = models.TextField(blank=True, null=True)
    user = models.ForeignKey(PmsUser, related_name='tender_activity_user',on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return str(self.activity)
    


class TenderExecutiveCommitee(BaseAbstractStructure):
    """
    Tender Executive Commitee
    """
    from user_profile.models import Group
    tender = models.ForeignKey(TenderMaster, related_name='tender_commitee',on_delete=models.CASCADE, null=True, blank=True)
    groups = models.ForeignKey(Group, related_name='tender_group',on_delete=models.CASCADE, null=True, blank=True)


class TenderCommiteeMembers(BaseAbstractStructure):
    """
    Tender Commitee Members
    """
    ex_commitee = models.ForeignKey(TenderExecutiveCommitee, related_name='ex_tender',on_delete=models.CASCADE, null=True, blank=True)
    users = models.ForeignKey(PmsUser, related_name='tender_group_users',on_delete=models.CASCADE, null=True, blank=True)
    level = models.CharField(max_length=200, blank=True, null=True)
    commitee_level = models.IntegerField(default=0)

    is_vga_approved = models.BooleanField(default=False)
    is_vga_reject = models.BooleanField(default=False)

    is_approved = models.BooleanField(default=False)
    is_reject = models.BooleanField(default=False)
    remarks = models.TextField(blank=True, null=True)
    approval_remarks = models.TextField(blank=True, null=True)
    rejection_remarks = models.TextField(blank=True, null=True)


class TopSheetMap(BaseAbstractStructure):
    tender = models.ForeignKey(TenderMaster, related_name='top_sheet_map_tender',on_delete=models.CASCADE, null=True, blank=True)
    parent = models.ForeignKey('self', related_name='top_sheet_map_parent',on_delete=models.CASCADE, blank=True, null=True)
    code = models.CharField(max_length=200, blank=True, null=True)
    title = models.TextField(blank=True, null=True, max_length=500)
    percentage = models.FloatField(default=0)
    sale_amt = models.FloatField(default=0.)
    wbs = models.ManyToManyField(TenderWBS, related_name='top_sheet_map_wbs', null=True, blank=True)


class TopSheetSaleData(BaseAbstractStructure):
    tender = models.ForeignKey(TenderMaster, related_name='top_sales_tender_id',on_delete=models.CASCADE, null=True, blank=True)
    wbskey = models.ForeignKey(TenderWBS,related_name='top_sales_wbskey_id',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='top_sales_data_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)


class TopSheetExpenditureData(BaseAbstractStructure):
    tender = models.ForeignKey(TenderMaster, related_name='top_exp_tender_id',on_delete=models.CASCADE, null=True, blank=True)
    wbskey = models.ForeignKey(TenderWBS,related_name='top_exp_wbskey_id',on_delete=models.CASCADE, null=True, blank=True)
    form = models.ForeignKey(FormMaster, related_name='top_exp_data_form_masters',on_delete=models.CASCADE, blank=True, null=True)
    value = models.CharField(max_length=200, blank=True, null=True)


class TenderSurveyFormGroupCompletion(BaseAbstractStructure):
    """
    Model To Track Completion Status of Tender Survey Group Wise
    """
    tender = models.ForeignKey(TenderMaster, related_name='completion_tender',on_delete=models.CASCADE, null=True, blank=True)
    form_group = models.ForeignKey(FormGroupMastr, related_name='completion_form_group',on_delete=models.CASCADE, blank=True, null=True)
    is_completed = models.BooleanField(default=False)
    completion_date = models.DateField(blank=True, null=True)
    completed_by = models.ForeignKey(PmsUser, related_name='completed_user',on_delete=models.DO_NOTHING, blank=True, null=True)

class TenderWBSProject(BaseAbstractStructure):
    """
    Tender WBS Project Model
    """
    CATEGORY = (
        ('general', 'General'),
        ('volumetric', 'Volumetric'),
    )
    organization = models.ForeignKey(Organization, related_name='organization_tender_wbs_project',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderMaster, related_name='ex_tender_project_id',on_delete=models.DO_NOTHING, null=True, blank=True)
    wbs = models.ForeignKey(TenderWBS, related_name='ex_wbs_project_id',on_delete=models.CASCADE, null=True, blank=True)
    category = models.CharField(max_length=100, choices=CATEGORY, default='general')
    parent_id = models.ForeignKey('self', related_name="tender_wbs_project_parent_id", on_delete=models.CASCADE, null=True, blank=True)
    project_name = models.TextField(null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name="tender_wbs_project_unit_of_mesurement", on_delete=models.DO_NOTHING, null=True, blank=True)
    is_default = models.BooleanField(default=False)
    slug = models.TextField(null=True, blank=True)
    by_order = models.IntegerField(default=1)
    boq_code = models.CharField(max_length=255,null=True, blank=True)
    boq_no = models.CharField(max_length=255,null=True, blank=True)

    def __str__(self):
        return str(self.project_name) + " (" + str(self.category) + ") " + str(self.parent_id)


class TenderSector(BaseAbstractStructure):
    """
    Tender Sector Model
    """
    DOMAIN = (
        ('State', 'State'),
        ('Central', 'Central'),
    )
    organization = models.ForeignKey(Organization, related_name='tender_sector_organization',on_delete=models.CASCADE, null=True, blank=True)
    domain = models.CharField(max_length=100, choices=DOMAIN, default='State')
    name = models.CharField(max_length=255,null=True, blank=True)
    users = models.ManyToManyField("administrations.PmsUser", null=True, blank=True)

    class Meta:
        db_table = "tender_sector"


class TenderSubSector(BaseAbstractStructure):
    """
    Tender Sub-Sector Model
    """
    organization = models.ForeignKey(Organization, related_name='tender_sub_sector_organization',on_delete=models.CASCADE, null=True, blank=True)
    sector = models.ForeignKey(TenderSector, related_name='tender_sub_sector_sector',on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=255,null=True, blank=True)

    class Meta:
        db_table = "tender_sub_sector"


######## Tender Models NEW ###########


class TenderDepartmentMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organization_tender_department_master',on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "tender_department_master"

class TenderChecklistMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organization_tender_checklist_master',on_delete=models.CASCADE, null=True, blank=True)
    tender_department = models.ForeignKey(TenderDepartmentMaster, related_name="tender_department", on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=255, null=True, blank=True)
    is_sign_shyam_infra = models.BooleanField(default=False, null=True, blank=True)
    is_sign_ca = models.BooleanField(default=False, null=True, blank=True)
    is_sign_bank = models.BooleanField(default=False, null=True, blank=True)
    is_sign_jv_partner = models.BooleanField(default=False)
    
    class Meta:
        db_table = "tender_checklist_master"

class TenderMasterNew(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('live', 'Live'),
        ('qualifying', 'Qualifying'),
        ('short_list', 'Short List'),
        ('proposed', 'Proposed'),
        ('recommended', 'Recommended'),
        ('documentation', 'Documentation'),
        ('approved', 'Approved'),
        ('emd_deposition', 'Emd Deposition'), 
        ('bid_submitted', 'Bid Submitted'),
        ('win', 'Win'),
        ('loss', 'Loss'),
        ('technical_disqualified', 'Technical Disqualified'),
        ('canceled', 'Canceled'), 
        ('rejected', 'Rejected'),
    )
    gst_type = (
        ('Inclusive', 'Inclusive'),
        ('Exclusive', 'Exclusive'),
    )
    mode_type = (
        ('Online', 'Online'),
        ('Offline', 'Offline'),
    )
    ELIGIBILITY_CHOICES = (
        ('yes', 'Yes'),
        ('no', 'No'),
    )
    TENDER_TYPE_CHOICES = (
        ('standalone', 'Standalone'),
        ('jv', 'JV'),
    )
    PRICE_ESCALATION_CHOISES = (
        ('yes', 'Yes'),
        ('no', 'No'),
    ) 
    organization = models.ForeignKey(Organization, related_name='organization_tender_master_new',on_delete=models.CASCADE, null=True, blank=True)
    sector = models.ForeignKey(TenderSector, related_name='tender_sector_tender_master', on_delete=models.CASCADE, null=True, blank=True)
    tender_organization = models.ForeignKey(EMPLOYEEMASTER, related_name="tender_organization_id", on_delete=models.CASCADE, null=True, blank=True)
    # work_description = models.TextField(null=True, blank=True)
    project_cost = models.FloatField(default=0)
    state = models.ForeignKey(State, related_name='state_tender_master', on_delete=models.CASCADE, null=True, blank=True)
    work_type = models.CharField(max_length=250, null=True, blank=True)
    qualification_criteria = models.TextField( null=True, blank=True)
    bid_submission_date = models.DateField(null=True, blank=True)
    schedule_durations = models.CharField(max_length=250, null=True, blank=True)
    emd_amount = models.FloatField(default=0)
    emd_type = models.CharField(max_length=250, null=True, blank=True)
    emd_deposition_location = models.CharField(max_length=250, null=True, blank=True)
    emd_validity_date =  models.DateField(null=True, blank=True)
    emd_checked_by_account = models.BooleanField(default=False)
    is_emd_deposition = models.BooleanField(default=False)
    is_emd_applicable = models.BooleanField(default=False)
    is_emd_received_by_account = models.BooleanField(default=False)
    emd_overall_remarks = models.TextField(null=True, blank=True)
    department_name = models.CharField(max_length=250, null=True, blank=True)
    contact_person = models.CharField(max_length=250, null=True, blank=True)
    contact_number = models.TextField( null=True, blank=True)
    publish_date = models.DateField(null=True, blank=True)
    pre_bid_meeting_date = models.DateField(null=True, blank=True)
    pre_bid_meeting_date_2 = models.DateField(null=True, blank=True)
    sinpl_tracking_date = models.DateField(null=True, blank=True)
    name = models.CharField(max_length=250, null=True, blank=True)
    code = models.CharField(max_length=250, null=True, blank=True)
    tender_id = models.CharField(max_length=250, unique=True, null=True, blank=True) 
    place = models.CharField(max_length=250, null=True, blank=True)   
    due_date = models.DateField(null=True, blank=True)
    gst_type = models.CharField(max_length=100, choices=gst_type,  null=True, blank=True)
    defect_liability_period = models.CharField(max_length=250, null=True, blank=True)
    tender_identification_remarks = models.CharField(max_length=250, null=True, blank=True)
    tender_source = models.CharField(max_length=250, null=True, blank=True)
    website_link = models.TextField(null=True, blank=True)
    mode = models.CharField(max_length=100, choices=mode_type,  null=True, blank=True)
    proposed_tender = models.TextField(null=True, blank=True)
    analysis = models.TextField(null=True, blank=True)
    status_of_participation = models.CharField(max_length=250, null=True, blank=True)
    bg_value_pre_feasibility = models.CharField(max_length=250, null=True, blank=True)
    is_archived = models.BooleanField(default=False)
    is_archived_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_is_archived_by", on_delete=models.CASCADE)
    is_archived_date = models.DateTimeField(blank=True, null=True, )
    archived_remarks = models.TextField(null=True, blank=True)
    is_reject_request = models.BooleanField(default=False)
    reject_request_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_reject_request_by", on_delete=models.CASCADE)
    reject_request_date = models.DateTimeField(blank=True, null=True, )
    reject_request_remarks = models.TextField(null=True, blank=True)
    is_canceled_request = models.BooleanField(default=False)
    canceled_request_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_canceled_request_by", on_delete=models.CASCADE)
    canceled_request_date = models.DateTimeField(blank=True, null=True, )
    canceled_request_remarks = models.TextField(null=True, blank=True)
    threshold_required = models.FloatField(default=0)
    avg_turn_over_last_5yrs = models.FloatField(default=0)
    whether_eligible_with_special_eligibility = models.CharField(max_length=3,choices=ELIGIBILITY_CHOICES,null=True,blank=True)
    whether_category_year_wise_fluctuation_incorporated = models.BooleanField(default=False)
    category_wise_updation_factor_applicable = models.CharField(max_length=3,choices=ELIGIBILITY_CHOICES,null=True,blank=True)
    year_wise_updation_factor_applicable = models.CharField(max_length=3, choices=ELIGIBILITY_CHOICES, null=True, blank=True)
    similar_work_definition = models.TextField(null=True,blank=True)
    tender_type = models.CharField(max_length=150, choices=TENDER_TYPE_CHOICES,  null=True, blank=True)
    # Qualification Criteria Amount Fields
    tender_qualification_technical_criteria_amount = models.FloatField(default=0)
    tender_qualification_financial_criteria_amount = models.FloatField(default=0)
    tender_qualification_bid_capacity_criteria_amount = models.FloatField(default=0)
    tender_qualification_others_criteria_amount = models.FloatField(default=0)
    sinpl_qualification_technical_criteria_amount = models.FloatField(default=0)
    sinpl_qualification_financial_criteria_amount = models.FloatField(default=0)
    sinpl_qualification_bid_capacity_criteria_amount = models.FloatField(default=0)
    sinpl_qualification_others_criteria_amount = models.FloatField(default=0)
    jv_partner_qualification_technical_criteria_amount = models.FloatField(default=0)
    jv_partner_qualification_financial_criteria_amount = models.FloatField(default=0)
    jv_partner_qualification_bid_capacity_criteria_amount = models.FloatField(default=0)
    jv_partner_qualification_others_criteria_amount = models.FloatField(default=0)
    bank_guarantee_ref_page_no = models.CharField(max_length=250, null=True, blank=True)
    board_resolution_ref_page_no = models.CharField(max_length=250, null=True, blank=True)
    ca_certificate_ref_page_no = models.CharField(max_length=250, null=True, blank=True)
    poa_for_signing_of_tender_ref_page_no = models.CharField(max_length=250, null=True, blank=True)
    poa_of_lead_member_ref_page_no = models.CharField(max_length=250, null=True, blank=True)
    finance_department_timeline = models.DateField(null=True, blank=True)
    secretarial_department_timeline = models.DateField(null=True, blank=True)
    accounts_department_timeline = models.DateField(null=True, blank=True)
    tender_department_timeline = models.DateField(null=True, blank=True)
    performance_security = models.CharField(max_length=250, null=True, blank=True)
    # Remarks Fields
    finance_remarks = models.TextField(null=True, blank=True)
    secretarial_remarks = models.TextField(null=True, blank=True)
    accounts_remarks = models.TextField(null=True, blank=True)
    tender_remarks = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="live")
    tender_jv_name = models.CharField(max_length=250, null=True, blank=True)
    tender_jv_name_remarks = models.TextField(null=True, blank=True)
    # pre submission
    tender_fee_cost = models.FloatField(default=0)
    tender_fee_requisition = models.BooleanField(default=False)
    bid_bg_percent = models.FloatField(default=0)
    bg_value = models.FloatField(default=0)
    bid_bg_requisition = models.BooleanField(default=False)
    tender_fee_mode = models.CharField(max_length=250, null=True, blank=True)
    bg_required_on_date = models.DateField(null=True, blank=True)
    bid_bg_extension = models.BooleanField(default=False)
    bid_bg_expiry_date = models.DateField(null=True, blank=True)
    extension_upto = models.BooleanField(default=False)
    extension_upto_date = models.DateField(null=True, blank=True)
    poa_check = models.BooleanField(default=False)
    poa_for_lead_jv = models.BooleanField(default=False)
    br = models.BooleanField(default=False)
    mou = models.BooleanField(default=False)
    jv_agreement = models.BooleanField(default=False)
    legal_consent_or_capacity = models.BooleanField(default=False)
    local_content_ca_certificate = models.BooleanField(default=False)
    site_feasibility_by_date = models.DateField(null=True, blank=True)
    site_feasibility_instruction_given = models.BooleanField(default=False)
    technical_bid_open_date = models.DateField(null=True, blank=True)
    financial_bid_open_date = models.DateField(null=True, blank=True)
    authority = models.CharField(max_length=155, null=True, blank=True)
    # for APPROVED STATUS user
    short_list_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_short_list_by", on_delete=models.CASCADE)
    qualifying_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_qualifying_by", on_delete=models.CASCADE)
    proposed_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_proposed_by", on_delete=models.CASCADE)
    recommended_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_recommended_by", on_delete=models.CASCADE)
    documentation_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_documentation_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_approved_by", on_delete=models.CASCADE)
    on_going_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_on_going_by", on_delete=models.CASCADE)
    emd_deposition_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_emd_deposition_by", on_delete=models.CASCADE)
    bid_submitted_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_bid_submitted_by", on_delete=models.CASCADE)
    win_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_win_by", on_delete=models.CASCADE)
    loss_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_loss_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_rejected_by", on_delete=models.CASCADE)
    canceled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_canceled_by", on_delete=models.CASCADE)
    technical_disqualified_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_technical_disqualified_by", on_delete=models.CASCADE)
    short_list_remarks = models.TextField(max_length=500, null=True, blank=True)
    qualifying_remarks = models.TextField(max_length=500, null=True, blank=True)
    proposed_remarks = models.TextField(max_length=500, null=True, blank=True)
    recommended_remarks = models.TextField(max_length=500, null=True, blank=True)
    documentation_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    canceled_remarks = models.TextField(max_length=500, null=True, blank=True)
    technical_disqualified_remarks = models.TextField(max_length=500, null=True, blank=True)
    on_going_remarks = models.TextField(max_length=500, null=True, blank=True)
    emd_deposition_remarks = models.TextField(max_length=500, null=True, blank=True)
    bid_submitted_remarks = models.TextField(max_length=500, null=True, blank=True)
    win_remarks = models.TextField(max_length=500, null=True, blank=True)
    loss_remarks = models.TextField(max_length=500, null=True, blank=True)
    short_list_by_date = models.DateTimeField(blank=True, null=True, )
    qualifying_by_date = models.DateTimeField(blank=True, null=True, )
    proposed_by_date = models.DateTimeField(blank=True, null=True, )
    recommended_by_date = models.DateTimeField(blank=True, null=True, )
    documentation_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    canceled_by_date = models.DateTimeField(blank=True, null=True, )
    on_going_by_date = models.DateTimeField(blank=True, null=True, )
    emd_deposition_by_date = models.DateTimeField(blank=True, null=True,)
    bid_submitted_by_date = models.DateTimeField(blank=True, null=True, )
    win_by_date = models.DateTimeField(blank=True, null=True, )
    loss_by_date = models.DateTimeField(blank=True, null=True, )
    technical_disqualified_by_date = models.DateTimeField(blank=True, null=True, )
    tender_team_hod_desc = models.TextField(null=True, blank=True)
    vp_finance_peer_review_desc = models.TextField(null=True, blank=True)
    tender_hod_desc = models.TextField(null=True, blank=True)
    peer_review_commite_desc = models.TextField(null=True, blank=True)
    peer_review_commite_desc_2 = models.TextField(null=True, blank=True)
    net_worth = models.FloatField(null=True, blank=True)
    value_of_similar_works = models.FloatField(null=True, blank=True)
    maximum_span_length_of_bridge_avail = models.FloatField(null=True, blank=True)
    bid_capacity_required = models.FloatField(null=True, blank=True)
    price_escalation = models.CharField(max_length=150, null=True, blank=True)
    price_variation_clause = models.CharField(max_length=190, null=True, blank=True)
    is_reverse_option_applicable = models.CharField(max_length=10, null=True, blank=True)
    # survey assign
    admin_and_liasoning = models.ManyToManyField(PmsUser, related_name="admin_and_liasoning", blank=True)
    physical_fesibility = models.ManyToManyField(PmsUser, related_name="physical_fesibility", blank=True)
    material_rate = models.ManyToManyField(PmsUser, related_name="material_rate", blank=True)
    statutory_and_taxation = models.ManyToManyField(PmsUser, related_name="statutory_and_taxation", blank=True)
    is_checklist_notify = models.BooleanField(default=False)
    checklist_notify_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_checklist_notify_by", on_delete=models.CASCADE)
    checklist_notify_date = models.DateTimeField(blank=True, null=True, )
    is_estimation_form_locked =  models.BooleanField(default=False)
    class Meta:
        db_table = "tender_master_new"

class TenderMasterNewApprovalRequestLog(BaseAbstractStructure):
    """ Tender Approval requesr Log """
    APPROVE_STATUS = (
        ('live', 'Live'),
        ('short_list', 'Short List'),
        ('proposed', 'Proposed'),
        ('recommended', 'Recommended'),
        ('documentation', 'Documentation'),
        ('approved', 'Approved'),
        ('bid_submitted', 'Bid Submitted'),
        ('win', 'Win'),
        ('loss', 'Loss'),
        ('technical_disqualified', 'Technical Disqualified'),
        ('rejected', 'Rejected'),
        ('canceled', 'Canceled'),
        ('reject_request', 'Reject Request'),
        ('reject_request_deny', 'Reject Request Deny'),
    )
    organization = models.ForeignKey(Organization, related_name='organization_tender_cancel_log',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderMasterNew, related_name='tender_cancel_log', on_delete=models.CASCADE, null=True, blank=True) 
    user = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_approval_request_log_user", on_delete=models.CASCADE)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True)
    previous_status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_approval_request_log"


class TenderMasterNewPartyDetails(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organization_tender_party_details',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderMasterNew, related_name='tender_party_details', on_delete=models.CASCADE, null=True, blank=True)
    company = models.ForeignKey(Company, blank=True, null=True, related_name="tender_master_new_company_deatils", on_delete=models.CASCADE)
    jvmaster = models.ForeignKey(JVMASTER, blank=True, null=True, related_name="tender_master_new_jv_master_details", on_delete=models.CASCADE)
    is_lead = models.BooleanField(default=False)
    available_threshold = models.FloatField(blank=True, null=True)
    value_of_similar_works = models.FloatField(blank=True, null=True)
    maximum_span_length_of_bridge_avail = models.FloatField(blank=True, null=True)
    average_annual_turn_over = models.FloatField(blank=True, null=True)
    net_worth = models.FloatField(blank=True, null=True)
    is_bid_capacity = models.BooleanField(default=False)
    bid_capacity = models.FloatField(blank=True, null=True)
    jv_share_percent = models.FloatField(blank=True, null=True)
    
    class Meta:
        db_table = "tender_master_new_party_details"

class TenderMasterNewWinLossAnalysis(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organization_tender_win_loss',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderMasterNew, related_name='tender_win_loss', on_delete=models.CASCADE, null=True, blank=True)
    partcipant_name = models.CharField(max_length=250, null=True, blank=True)
    bidded_value_in_crore = models.FloatField(null=True, blank=True)
    percentage = models.FloatField(null=True, blank=True)
    above_below = models.CharField(max_length=250, null=True, blank=True)
    rank = models.IntegerField(null=True, blank=True)
    is_my_biider_rank = models.BooleanField(default=False)
    is_import = models.BooleanField(default=False)
    
    class Meta:
        db_table = "tender_master_new_win_loss_analysis"


class TenderMasterNewQualificationDocuments(BaseAbstractStructure):
    DOC_TYPE_CHOICES = (
        ('tender_document', 'Tender Document'),
        ('qualification_document', 'Qualification Document'),
        ('survey_document', 'Survey Document'),
        ('ca_document', 'CA Document'),
        ('checklist_document', 'Checklist Document'),
        ('evaluation_document', 'Evaluation Document'),
        ('cost_document', 'Cost Document'),
        ('reject_document', 'Reject Document'),
        ('emd_deposition_document', 'Emd Deposition Document'),
    )
    organization = models.ForeignKey(Organization, related_name='organization_tender_qualification_documents',on_delete=models.CASCADE, null=True, blank=True)
    tender = models.ForeignKey(TenderMasterNew, related_name='tender_qualification_documents', on_delete=models.CASCADE, null=True, blank=True)
    tender_department = models.ForeignKey(TenderDepartmentMaster, related_name="tender_department_qualification", on_delete=models.CASCADE, null=True, blank=True)
    checklist = models.ForeignKey(TenderChecklistMaster, related_name="tender_checklist", on_delete=models.CASCADE, null=True, blank=True)
    file_name=models.CharField(max_length=200, null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(
        upload_to='tender/qualification/document', null=True, blank=True)
    rcv_attachment = models.FileField(
        upload_to='tender/qualification/document/checklist/received', null=True, blank=True)
    doc_type = models.CharField(max_length=50,choices=DOC_TYPE_CHOICES, default='qualification_document',
        blank=True, null=True
    )
    is_email = models.BooleanField(default=False, blank=True, null=True)
    mail_to = models.TextField(null=True, blank=True)
    mail_cc = models.TextField(null=True, blank=True)
    reference_page_no = models.CharField(max_length=200, null=True, blank=True)
    document_print_on = models.CharField(max_length=200, null=True, blank=True)
    is_sign_shyam_infra = models.BooleanField(default=False, null=True, blank=True)
    is_sign_ca = models.BooleanField(default=False, null=True, blank=True)
    is_sign_bank = models.BooleanField(default=False, null=True, blank=True)
    is_applicable = models.BooleanField(default=False, null=True, blank=True)
    is_sign_jv_partner = models.BooleanField(default=False, null=True, blank=True)
    is_received_copy = models.BooleanField(default=False, null=True, blank=True)
    is_default_file = models.BooleanField(default=False, null=True, blank=True)
    
    class Meta:
        db_table = "tender_master_new_qualification_documents"

#site survey
class TenderMasterNewSurveyMaster(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('in_progress', 'In-Progress'),
        ('draft', 'Draft'),
        ('submit', 'Submit'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ) 
    organization = models.ForeignKey(Organization,related_name='organization_tender_survey',on_delete=models.CASCADE,null=True,blank=TenderSubSector)
    tender = models.ForeignKey(TenderMasterNew,related_name='tender_master_new_survey', on_delete=models.CASCADE,null=True,blank=True)
    date = models.DateField(null=True, blank=True)
    visited_by = models.CharField(max_length=250, null=True, blank=True)
    project_details_remarks = models.TextField(null=True, blank=True)
    client_remarks = models.TextField(null=True, blank=True)
    project_cost_remarks = models.TextField(null=True, blank=True)
    nature_of_contract_remarks = models.TextField(null=True, blank=True)
    completion_period_remarks = models.TextField(null=True, blank=True)
    gst_type_remarks = models.TextField(null=True, blank=True)
    dpr_licensor = models.TextField(null=True, blank=True)
    dpr_licensor_remarks = models.TextField(null=True, blank=True)
    location = models.TextField(null=True, blank=True)
    location_remarks = models.TextField(null=True, blank=True)
    brief_desc_of_scope = models.TextField(null=True, blank=True)
    brief_desc_of_scope_remarks = models.TextField(null=True, blank=True)
    employer_representatives = models.TextField(null=True, blank=True)
    employer_representatives_remarks = models.TextField(null=True, blank=True) 
    consultant_representatives = models.TextField(null=True, blank=True)
    consultant_representatives_remarks = models.TextField(null=True, blank=True)
    users = models.ManyToManyField("administrations.PmsUser", null=True, blank=True)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="in_progress")
    draft_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_survey_master_draft_by", on_delete=models.CASCADE)
    submit_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_survey_master_submit_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_survey_master_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_survey_master_rejected_by", on_delete=models.CASCADE)
    draft_by_date = models.DateTimeField(blank=True, null=True, )
    submit_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )
    draft_remarks = models.TextField(max_length=500, null=True, blank=True)
    submit_remarks = models.TextField(max_length=500, null=True, blank=True)
    approved_remarks = models.TextField(max_length=500, null=True, blank=True)
    rejected_remarks = models.TextField(max_length=500, null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master"

class TenderMasterNewSurveyMasterApprovalRequestLog(BaseAbstractStructure):
    """ Tender Suyvey Master Approval requesr Log """
    APPROVE_STATUS = (
        ('in_progress', 'In-Progress'),
        ('save_draft', 'Save Draft'),
        ('submit', 'Submit'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='organization_survey_status_request_log',on_delete=models.CASCADE, null=True, blank=True)
    survey = models.ForeignKey(TenderMasterNewSurveyMaster, related_name='survey_status_request_log', on_delete=models.CASCADE, null=True, blank=True) 
    user = models.ForeignKey(PmsUser, blank=True, null=True, related_name="tender_master_new_survey_master_approval_request_log_user", on_delete=models.CASCADE)
    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True)
    previous_status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_approval_request_log"

class TenderMasterNewSurveyMasterSiteDetails(BaseAbstractStructure):
    ELIGIBILITY_CHOICES = (
        ('yes', 'Yes'),
        ('no', 'No'), 
    )
    survey = models.OneToOneField(TenderMasterNewSurveyMaster, related_name='survey_site_details', on_delete=models.CASCADE)
    sd_name_distance_city_town = models.TextField(blank=True, null=True)
    sd_name_distance_city_town_remarks = models.TextField(blank=True, null=True)
    sd_name_distance_railhead = models.TextField(blank=True, null=True)
    sd_name_distance_railhead_remarks = models.TextField(blank=True, null=True)
    sd_name_distance_airport = models.TextField(blank=True, null=True)
    sd_name_distance_airport_remarks = models.TextField(blank=True, null=True)
    sd_name_distance_port = models.TextField(blank=True, null=True)
    sd_name_distance_port_remarks = models.TextField(blank=True, null=True)
    sd_access_to_site = models.TextField(blank=True, null=True)
    sd_access_to_site_remarks = models.TextField(blank=True, null=True)
    sd_between_highway_site = models.TextField(blank=True, null=True)
    sd_between_highway_site_remarks = models.TextField(blank=True, null=True)
    sd_permissible_height_fob = models.TextField(blank=True, null=True)
    sd_permissible_height_fob_remarks = models.TextField(blank=True, null=True)
    sd_motorway_bridge_load_deatils = models.TextField(blank=True, null=True)
    sd_motorway_bridge_load_deatils_remarks = models.TextField(blank=True, null=True)
    sd_railway_crossing_height = models.TextField(blank=True, null=True)
    sd_railway_crossing_height_remarks = models.TextField(blank=True, null=True)
    sd_access_road_width_min_max = models.TextField(blank=True, null=True)
    sd_access_road_width_min_max_remarks = models.TextField(blank=True, null=True)
    sd_village_city_town_population_type = models.TextField(blank=True, null=True)
    sd_village_city_town_population_type_remarks = models.TextField(blank=True, null=True)
    sd_inland_waterways = models.TextField(blank=True, null=True)
    sd_inland_waterways_remarks = models.TextField(blank=True, null=True)
    sd_is_toll_fees_payable = models.CharField(max_length=25,  null=True, blank=True)
    sd_is_toll_fees_payable_remarks = models.TextField(blank=True, null=True)
    sd_is_special_permit_required = models.CharField(max_length=25,  null=True, blank=True)
    sd_is_special_permit_required_remarks = models.TextField(blank=True, null=True)
    sd_land_acquisition_status = models.TextField(blank=True, null=True)
    sd_land_acquisition_status_remarks = models.TextField(blank=True, null=True)
    sd_environmental_approval_status = models.TextField(blank=True, null=True)
    sd_environmental_approval_status_remarks = models.TextField(blank=True, null=True)
    sd_overall_terrain = models.TextField(blank=True, null=True)
    sd_overall_terrain_remarks = models.TextField(blank=True, null=True)
    sd_encroachments_row_issues = models.TextField(blank=True, null=True)
    sd_encroachments_row_issues_remarks = models.TextField(blank=True, null=True)
    sd_attachment_remarks = models.TextField(blank=True, null=True)
    class Meta:
        db_table = "tender_master_new_survey_master_site_details"

class TenderMasterNewSurveyMasterSiteDetailsAttachments(BaseAbstractStructure):
    site_details = models.ForeignKey(TenderMasterNewSurveyMasterSiteDetails,related_name='survey_site_details_attachment', on_delete=models.CASCADE, null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(upload_to='tender/site_survey/site_details', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    latitude = models.CharField(max_length=250, null=True, blank=True)
    longitude = models.CharField(max_length=250, null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_site_details_attachments"

class TenderMasterNewSurveyMasterFacilitySite(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster, related_name='survey_facility_site', on_delete=models.CASCADE)
    fs_cp_is_power_supply = models.CharField(max_length=150, null=True, blank=True)
    fs_cp_is_power_supply_remarks = models.TextField(null=True, blank=True)
    fs_cp_distance_of_supply_line = models.TextField(null=True, blank=True)
    fs_cp_distance_of_supply_line_remarks = models.TextField(null=True, blank=True)
    fs_cp_reliability_of_the_same = models.TextField(null=True, blank=True)
    fs_cp_reliability_of_the_same_remarks = models.TextField(null=True, blank=True)
    fs_cp_supply_cost = models.FloatField(default=0)
    fs_cp_supply_cost_remarks = models.TextField(null=True, blank=True)
    fs_cw_is_construction_water = models.CharField(max_length=150, null=True, blank=True)
    fs_cw_is_construction_water_remarks = models.TextField(null=True, blank=True)
    fs_cw_distance_of_supply_line = models.TextField(null=True, blank=True)
    fs_cw_distance_of_supply_line_remarks = models.TextField(null=True, blank=True)
    fs_cw_reliability_of_the_same = models.TextField(null=True, blank=True)
    fs_cw_reliability_of_the_same_remarks = models.TextField(null=True, blank=True)
    fs_cw_supply_cost = models.FloatField(default=0)
    fs_cw_supply_cost_remarks = models.TextField(null=True, blank=True)
    fs_dw_is_drinking_water = models.CharField(max_length=150, null=True, blank=True)
    fs_dw_is_drinking_water_remarks = models.TextField(null=True, blank=True)
    fs_dw_supply_cost = models.FloatField(default=0)
    fs_dw_supply_cost_remarks = models.TextField(null=True, blank=True)
    fs_cwo_is_construction_workmen = models.CharField(max_length=150, null=True, blank=True)
    fs_cwo_is_construction_workmen_remarks = models.TextField(null=True, blank=True)
    fs_cwo_is_experienced_similar_nature_of_work = models.CharField(max_length=25, null=True, blank=True)
    fs_cwo_is_experienced_similar_nature_of_work_remarks = models.TextField(null=True, blank=True)
    fs_cwo_is_land_setup_labour_camp = models.CharField(max_length=150, null=True, blank=True)
    fs_cwo_is_land_setup_labour_camp_remarks = models.TextField(null=True, blank=True)
    fs_ce_can_get_plant_equipment = models.TextField(null=True, blank=True)
    fs_ce_can_get_plant_equipment_remarks = models.TextField(null=True, blank=True)
    fs_ce_nearest_place_rental_availability_equipment = models.TextField(null=True, blank=True)
    fs_ce_nearest_place_rental_availability_equipment_remarks = models.TextField(null=True, blank=True)
    fs_ce_availability_of_the_same = models.TextField(null=True, blank=True)
    fs_ce_availability_of_the_same_remarks = models.TextField(null=True, blank=True)
    fs_mf_is_available_near_site = models.CharField(max_length=150, null=True, blank=True)
    fs_mf_is_available_near_site_remarks = models.TextField(null=True, blank=True)
    fs_mf_distance_from_site = models.TextField(null=True, blank=True)
    fs_mf_distance_from_site_remarks = models.TextField(null=True, blank=True)
    fs_cf_is_available = models.CharField(max_length=150, null=True, blank=True)
    fs_cf_is_available_remarks = models.TextField(null=True, blank=True)
    fs_cf_cost_of_installation = models.FloatField(default=0)
    fs_cf_cost_of_installation_remarks = models.TextField(null=True, blank=True)
    fs_bf_is_available = models.CharField(max_length=150, null=True, blank=True)
    fs_bf_is_available_remarks = models.TextField(null=True, blank=True)
    fs_bf_distance_from_site = models.TextField(null=True, blank=True)
    fs_bf_distance_from_site_remarks = models.TextField(null=True, blank=True)
    fs_sec_is_site_secure = models.CharField(max_length=150, null=True, blank=True)
    fs_sec_is_site_secure_remarks = models.TextField(null=True, blank=True)
    fs_sec_is_fencing_or_boundary_wall_exist = models.CharField(max_length=25, null=True, blank=True)
    fs_sec_is_fencing_or_boundary_wall_exist_remarks = models.TextField(null=True, blank=True)
    fs_sec_is_fencing_required = models.CharField(max_length=150, null=True, blank=True)
    fs_sec_is_fencing_required_remarks = models.TextField(null=True, blank=True)
    fs_sec_is_security_personnel_required = models.CharField(max_length=150, null=True, blank=True)
    fs_sec_is_security_personnel_required_remarks = models.TextField(null=True, blank=True)
    fs_sec_barricading_required = models.TextField(null=True, blank=True)
    fs_sec_barricading_required_remarks = models.TextField(null=True, blank=True)
    fs_sec_type_of_barricading = models.TextField(null=True, blank=True)
    fs_sec_type_of_barricading_remarks = models.TextField(null=True, blank=True)
    fs_sec_entry_same_for_manpower_and_transport = models.TextField(null=True, blank=True)
    fs_sec_entry_same_for_manpower_and_transport_remarks = models.TextField(null=True, blank=True)
    fs_sec_type_of_arrangement_for_green_field_entry = models.TextField(null=True, blank=True)
    fs_sec_type_of_arrangement_for_green_field_entry_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_facility_site"
class TenderMasterNewSurveyMasterFacilitySiteAttachments(BaseAbstractStructure):
    facility_site = models.ForeignKey(TenderMasterNewSurveyMasterFacilitySite,related_name='survey_facility_site_attachments', on_delete=models.CASCADE, null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(upload_to='tender/site_survey/facility_site', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    latitude = models.CharField(max_length=250, null=True, blank=True)
    longitude = models.CharField(max_length=250, null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_facility_site_attachments"
class TenderMasterNewSurveyMasterClimateAtSite(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_climate_site',on_delete=models.CASCADE)
    cs_normal_rainy_seasons = models.TextField(blank=True, null=True)
    cs_normal_rainy_seasons_remarks = models.TextField(blank=True, null=True)
    cs_can_we_work_during_rainy_seasons = models.CharField(max_length=150, blank=True, null=True)
    cs_can_we_work_during_rainy_seasons_remarks = models.TextField(blank=True, null=True)
    cs_intensity_of_rains = models.TextField(blank=True, null=True)
    cs_intensity_of_rains_remarks = models.TextField(blank=True, null=True)
    cs_normal_temperature = models.TextField(blank=True, null=True)
    cs_normal_temperature_remarks = models.TextField(blank=True, null=True)
    cs_is_cyclones_typhoons_duststorms = models.CharField(max_length=150, blank=True, null=True)
    cs_is_cyclones_typhoons_duststorms_remarks = models.TextField(blank=True, null=True)
    cs_cyclones_typhoons_duststorms_occurrences = models.TextField(blank=True, null=True)
    cs_cyclones_typhoons_duststorms_occurrences_remarks = models.TextField(blank=True, null=True)
    cs_site_is_earthquake_flood = models.TextField(blank=True, null=True)
    cs_site_is_earthquake_flood_remarks = models.TextField(blank=True, null=True)
    cs_earthquake_flood_occurrences = models.TextField(blank=True, null=True)
    cs_earthquake_flood_occurrences_remarks = models.TextField(blank=True, null=True)
    class Meta:
        db_table = "tender_master_new_survey_master_climate_at_site"

class TenderMasterNewSurveyMasterHydrologicalMarineCondition(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster, related_name='survey_hydrology_marine_condition',on_delete=models.CASCADE)
    hmc_existing_ground_water_table = models.TextField(null=True, blank=True)
    hmc_existing_ground_water_table_remarks = models.TextField(null=True, blank=True)
    hmc_depth_of_underground_water_monsoons = models.TextField(null=True, blank=True)
    hmc_depth_of_underground_water_monsoons_remarks = models.TextField(null=True, blank=True)
    hmc_wave_height = models.TextField(null=True, blank=True)
    hmc_wave_height_remarks = models.TextField(null=True, blank=True)
    hmc_wind_speed_direction = models.TextField(null=True, blank=True)
    hmc_wind_speed_direction_remarks = models.TextField(null=True, blank=True)
    hmc_tide_tables = models.TextField(null=True, blank=True)
    hmc_tide_tables_remarks = models.TextField(null=True, blank=True)
    hmc_eddies_or_currents = models.TextField(null=True, blank=True)
    hmc_eddies_or_currents_remarks = models.TextField(null=True, blank=True)
    hmc_marine_traffic_interference = models.TextField(null=True, blank=True)
    hmc_marine_traffic_interference_remarks = models.TextField(null=True, blank=True)
    hmc_bathometric_survey_data = models.TextField(null=True, blank=True)
    hmc_bathometric_survey_data_remarks = models.TextField(null=True, blank=True)
    hmc_draft_available = models.TextField(null=True, blank=True)
    hmc_draft_available_remarks = models.TextField(null=True, blank=True)
    hmc_maritime_board_approvals_restrictions = models.TextField(null=True, blank=True)
    hmc_maritime_board_approvals_restrictions_remarks = models.TextField(null=True, blank=True)
    hmc_port_restrictions_approvals = models.TextField(null=True, blank=True)
    hmc_port_restrictions_approvals_remarks = models.TextField(null=True, blank=True)
    hmc_stretch_under_environmentally_sensitive_zone = models.TextField(null=True, blank=True)
    hmc_stretch_under_environmentally_sensitive_zone_remarks = models.TextField(null=True, blank=True)
    hmc_subsea_utilities = models.TextField(null=True, blank=True)
    hmc_subsea_utilities_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_hydrology_marine_condition"

class TenderMasterNewSurveyMasterTopography(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster, related_name='survey_topography', on_delete=models.CASCADE)
    t_flat_undulated = models.TextField(null=True, blank=True)
    t_flat_undulated_remarks = models.TextField(null=True, blank=True)
    t_clean_vegetation_jungle = models.TextField(null=True, blank=True)
    t_clean_vegetation_jungle_remarks = models.TextField(null=True, blank=True)
    t_natural_slope = models.TextField(null=True, blank=True)
    t_natural_slope_remarks = models.TextField(null=True, blank=True)
    t_current_situation_waterlogged_dry = models.TextField(null=True, blank=True)
    t_current_situation_waterlogged_dry_remarks = models.TextField(null=True, blank=True)
    t_any_chance_of_water_logging_during_rains = models.CharField(max_length=150, null=True, blank=True)
    t_any_chance_of_water_logging_during_rains_remarks = models.TextField(null=True, blank=True)
    t_no_of_locations_with_water_logging = models.TextField(null=True, blank=True)
    t_no_of_locations_with_water_logging_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_topography"

class TenderMasterNewSurveyMasterGeologicalData(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster, related_name='survey_geological_data', on_delete=models.CASCADE)
    gd_have_any_boring_been_taken = models.CharField(max_length=150, null=True, blank=True)
    gd_have_any_boring_been_taken_remarks = models.TextField(null=True, blank=True)
    gd_if_yes_give_details = models.TextField(null=True, blank=True)
    gd_if_yes_give_details_remarks = models.TextField(null=True, blank=True)
    gd_are_there_any_borrow_pit = models.CharField(max_length=150, null=True, blank=True)
    gd_are_there_any_borrow_pit_remarks = models.TextField(null=True, blank=True)
    gd_is_soil_characteristic_various_layers = models.CharField(max_length=150, null=True, blank=True)
    gd_is_soil_characteristic_various_layers_remarks = models.TextField(null=True, blank=True)
    gd_any_chance_of_encounter_with_rock = models.CharField(max_length=150, null=True, blank=True)
    gd_any_chance_of_encounter_with_rock_remarks = models.TextField(null=True, blank=True)
    gd_if_yes_blasting_required = models.CharField(max_length=150, null=True, blank=True)
    gd_if_yes_blasting_required_remarks = models.TextField(null=True, blank=True)
    gd_sub_surface_water_level_dry_wet = models.TextField(null=True, blank=True)
    gd_sub_surface_water_level_dry_wet_remarks = models.TextField(null=True, blank=True)
    gd_type_of_dewatering_prevalent = models.TextField(null=True, blank=True)
    gd_type_of_dewatering_prevalent_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_geological_data"

class TenderMasterNewSurveyMasterLocalIssues(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster, related_name='survey_local_issues', on_delete=models.CASCADE)
    li_local_population_support_to_the_project = models.CharField(max_length=150, null=True, blank=True)
    li_local_population_support_to_the_project_remarks = models.TextField(null=True, blank=True)
    li_local_political_support = models.CharField(max_length=150, null=True, blank=True)
    li_local_political_support_remarks = models.TextField(null=True, blank=True)
    li_demand_expectations_of_local_people = models.TextField(null=True, blank=True)
    li_demand_expectations_of_local_people_remarks = models.TextField(null=True, blank=True)
    li_local_protest_history = models.CharField(max_length=150, null=True, blank=True)
    li_local_protest_history_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_local_issues"
class TenderMasterNewSurveyMasterConstructionMaterials(BaseAbstractStructure):
    survey = models.ForeignKey(TenderMasterNewSurveyMaster,related_name='survey_construction_materials', on_delete=models.CASCADE)
    material = models.TextField(null=True, blank=True)
    material_remarks = models.TextField(null=True, blank=True)
    cm_distance_of_nearest_source = models.TextField(null=True, blank=True)
    cm_distance_of_nearest_source_remarks = models.TextField(null=True, blank=True)
    cm_availability_capacity_to_supply = models.TextField(null=True, blank=True)
    cm_availability_capacity_to_supply_remarks = models.TextField(null=True, blank=True)
    cm_mode_of_transport = models.TextField(null=True, blank=True)
    cm_approximate_transportation_cost = models.TextField(null=True, blank=True)
    cm_approximate_transportation_cost_remarks = models.TextField(null=True, blank=True)
    cm_mode_of_transport_remarks = models.TextField(null=True, blank=True)
    cm_taxes_and_duties = models.TextField(null=True, blank=True)
    cm_taxes_and_duties_remarks = models.TextField(null=True, blank=True)
    cm_prices_at_source = models.TextField(null=True, blank=True)
    cm_prices_at_source_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_construction_materials"

class TenderMasterNewSurveyMasterConstructionMaterialsSupplierDetails(BaseAbstractStructure):
    construction_materials = models.ForeignKey(TenderMasterNewSurveyMasterConstructionMaterials, related_name='survey_construction_materials_supplier_details', on_delete=models.CASCADE)
    supplier_name = models.CharField(max_length=255, null=True, blank=True)
    source_distance = models.CharField(max_length=250, null=True, blank=True)
    unit_rate = models.CharField(max_length=250, null=True, blank=True)
    royalty = models.CharField(max_length=255, null=True, blank=True)
    transportation = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "survey_master_construction_materials_supplier_details"

class TenderMasterNewSurveyMasterConstructionMaterialsAttachments(BaseAbstractStructure):
    survey = models.ForeignKey(TenderMasterNewSurveyMaster,related_name='survey_materials_attachments', on_delete=models.CASCADE, null=True, blank=True)
    construction_materials = models.ForeignKey(TenderMasterNewSurveyMasterConstructionMaterials,related_name='survey_construction_materials_attachments', on_delete=models.CASCADE, null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(upload_to='tender/site_survey/construction_materials', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "survey_master_construction_materials_attachments"

#SUB-CONTRACTOR
class TenderMasterNewSurveyMasterSubContractor(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_sub_contractor',on_delete=models.CASCADE)
    sc_can_we_get_sub_contractor = models.TextField(null=True, blank=True)
    sc_can_we_get_sub_contractor_remarks = models.TextField(null=True, blank=True)
    sc_give_details_of_the_same = models.TextField(null=True, blank=True)
    sc_give_details_of_the_same_remarks = models.TextField(null=True, blank=True)
    sc_cost_of_similar_subcontractors_in_the_recent_past = models.TextField(null=True, blank=True)
    sc_cost_of_similar_subcontractors_in_the_recent_past_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_sub_contractor"
        
# LABOUR
class SurveyEmployeeCategoriesMaster(BaseAbstractStructure):
    name = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "survey_employee_categories_master"

class SurveyEmployeeCategoriesMasterArea(BaseAbstractStructure):
    name = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "survey_employee_categories_master_area"

class TenderMasterNewSurveyMasterLabour(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_labour',on_delete=models.CASCADE)
    l_local_wages_prevailing_market_area = models.TextField(null=True, blank=True)
    l_local_wages_prevailing_market_area_remarks = models.TextField(null=True, blank=True)
    l_carpenter_barbender = models.TextField(null=True, blank=True)
    l_carpenter_barbender_remarks = models.TextField(null=True, blank=True)
    l_khalasi = models.TextField(null=True, blank=True)
    l_khalasi_remarks = models.TextField(null=True, blank=True)
    l_electrician_mechanic = models.TextField(null=True, blank=True)
    l_electrician_mechanic_remarks = models.TextField(null=True, blank=True)
    l_un_skilled = models.TextField(null=True, blank=True)
    l_un_skilled_remarks = models.TextField(null=True, blank=True)
    l_report_on_labour_union_activity_and_possible_increase = models.TextField(null=True, blank=True)
    l_report_on_labour_union_activity_and_possible_increase_remarks = models.TextField(null=True, blank=True)
    l_availability_of_various_category_of_labour = models.TextField(null=True, blank=True)
    l_availability_of_various_category_of_labour_remarks = models.TextField(null=True, blank=True)
    l_labour_permit_clearances_for_overseas_projects = models.TextField(null=True, blank=True)
    l_labour_permit_clearances_for_overseas_projects_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_labour"

class TenderMasterNewSurveyMasterLabourEmployeeCategories(BaseAbstractStructure):
    survey_labour = models.ForeignKey(TenderMasterNewSurveyMasterLabour, related_name='labour_employees_categoriers',on_delete=models.CASCADE, null=True, blank=True)
    employee_category = models.ForeignKey(SurveyEmployeeCategoriesMaster, related_name='employees_categoriers_master',on_delete=models.CASCADE, null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_labour_employee_categories"

class TenderMasterNewSurveyMasterLabourAttachment(BaseAbstractStructure):
    labour = models.ForeignKey(TenderMasterNewSurveyMasterLabour,related_name='survey_labour_attachment', on_delete=models.CASCADE, null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(upload_to='tender/site_survey/labour', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_survey_labour_attachment"


class TenderMasterNewSurveyMasterLabourEmployeeCategoriesManPowerRate(BaseAbstractStructure):
    labour = models.ForeignKey(TenderMasterNewSurveyMasterLabour, related_name='survey_labour_man_power',on_delete=models.CASCADE, null=True, blank=True)
    category = models.ForeignKey(SurveyEmployeeCategoriesMaster, related_name='survey_employee_category', on_delete=models.CASCADE)
    area = models.TextField(null=True, blank=True)
    basic_minimum_wages_per_day_rate = models.FloatField(default=0)
    vda_rate = models.FloatField(default=0)
    total_minimum_wages_per_day_rate = models.FloatField(default=0)
    total_minimum_wages_per_month_rate = models.FloatField(default=0)
    class Meta:
        db_table = "tender_master_new_survey_master_labour_man_power_rate"

# FUEL
class TenderMasterNewSurveyMasterFuel(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_fuel',on_delete=models.CASCADE)
    fuel_what_is_the_nearest_source = models.TextField(null=True, blank=True)
    fuel_what_is_the_nearest_source_remarks = models.TextField(null=True, blank=True)
    fuel_cost_of_diesel = models.TextField(null=True, blank=True)
    fuel_cost_of_diesel_remarks = models.TextField(null=True, blank=True)
    fuel_cost_of_petrol = models.TextField(null=True, blank=True)
    fuel_cost_of_petrol_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_fuel"
        
# ACCOMMODATION
class TenderMasterNewSurveyMasterAccommodation(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_accommodation',on_delete=models.CASCADE)
    acco_what_is_the_nearest_place = models.TextField(null=True, blank=True)
    acco_what_is_the_nearest_place_remarks = models.TextField(null=True, blank=True)
    acco_distance_from_site = models.TextField(null=True, blank=True)
    acco_distance_from_site_remarks = models.TextField(null=True, blank=True)
    acco_is_existing_facility_available =  models.CharField(max_length=150, null=True, blank=True)
    acco_is_existing_facility_available_remarks = models.TextField(null=True, blank=True)
    acco_if_so_give_details = models.TextField(null=True, blank=True)
    acco_if_so_give_details_remarks = models.TextField(null=True, blank=True)
    acco_cost_of_accommodation_for_staff = models.TextField(null=True, blank=True)
    acco_cost_of_accommodation_for_staff_remarks = models.TextField(null=True, blank=True)
    acco_where_we_can_accommodate_our_operators_laborers = models.TextField(null=True, blank=True)
    acco_where_we_can_accommodate_our_operators_laborers_remarks = models.TextField(null=True, blank=True)
    acco_rental_of_temporary_office_guest = models.TextField(null=True, blank=True)
    acco_rental_of_temporary_office_guest_remarks = models.TextField(null=True, blank=True)
    acco_nearest_family_accommodation_rentals =  models.CharField(max_length=150, null=True, blank=True)
    acco_nearest_family_accommodation_rentals_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_accommodation"
#TEMPORARY SET UP
class TenderMasterNewSurveyMasterTemporarySetup(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_temporary_setup',on_delete=models.CASCADE)
    temp_where_we_can_set_up_our_office = models.TextField(null=True, blank=True)
    temp_where_we_can_set_up_our_office_remarks = models.TextField(null=True, blank=True)
    temp_is_it_free_or_we_have_to_take_on_lease_or_rental = models.TextField(null=True, blank=True)
    temp_is_it_free_or_we_have_to_take_on_lease_or_rental_remarks = models.TextField(null=True, blank=True)
    temp_if_so_what_is_the_cost_of_lease_rental = models.TextField(null=True, blank=True)
    temp_if_so_what_is_the_cost_of_lease_rental_remarks = models.TextField(null=True, blank=True)
    temp_porta_cabin_availability_or_import = models.TextField(null=True, blank=True)
    temp_porta_cabin_availability_or_import_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_temporary_setup"
#TAXES & DUTIES
class TenderMasterNewSurveyMasterTaxesDuties(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_taxes_duties',on_delete=models.CASCADE)
    ta_custom_duty_on_construction_equipment = models.TextField(null=True, blank=True)
    ta_custom_duty_on_construction_equipment_remarks = models.TextField(null=True, blank=True)
    ta_custom_duty_on_construction_materials = models.TextField(null=True, blank=True)
    ta_custom_duty_on_construction_materials_remarks = models.TextField(null=True, blank=True)
    ta_excise_duty = models.TextField(null=True, blank=True)
    ta_excise_duty_remarks = models.TextField(null=True, blank=True)
    ta_sales_tax = models.TextField(null=True, blank=True)
    ta_sales_tax_remarks = models.TextField(null=True, blank=True)
    ta_value_added_tax = models.TextField(null=True, blank=True)
    ta_value_added_tax_remarks = models.TextField(null=True, blank=True)
    ta_entry_tax = models.TextField(null=True, blank=True)
    ta_entry_tax_remarks = models.TextField(null=True, blank=True)
    ta_works_contract_tax = models.TextField(null=True, blank=True)
    ta_works_contract_tax_remarks = models.TextField(null=True, blank=True)
    ta_turnover_tax = models.TextField(null=True, blank=True)
    ta_turnover_tax_remarks = models.TextField(null=True, blank=True)
    ta_professional_tax = models.TextField(null=True, blank=True)
    ta_professional_tax_remarks = models.TextField(null=True, blank=True)
    ta_any_other_tax = models.TextField(null=True, blank=True)
    ta_any_other_tax_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_taxes_duties"
# SUBCONTRACTORS
class TenderMasterNewSurveyMasterSubcontractors(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_subcontractors',on_delete=models.CASCADE)
    subc_flyash_supplier = models.TextField(null=True, blank=True)
    subc_flyash_supplier_remarks = models.TextField(null=True, blank=True)
    subc_earthwork_roadwork_contractor = models.TextField(null=True, blank=True)
    subc_earthwork_roadwork_contractor_remarks = models.TextField(null=True, blank=True)
    subc_rmc_supplier = models.TextField(null=True, blank=True)
    subc_rmc_supplier_remarks = models.TextField(null=True, blank=True)
    subc_name_of_the_rmc_establishment_around_location = models.TextField(null=True, blank=True)
    subc_name_of_the_rmc_establishment_around_location_remarks = models.TextField(null=True, blank=True)
    subc_capacity_of_plants = models.TextField(null=True, blank=True)
    subc_capacity_of_plants_remarks = models.TextField(null=True, blank=True)
    subc_distance_of_rmc_plants_to_site = models.TextField(null=True, blank=True)
    subc_distance_of_rmc_plants_to_site_remarks = models.TextField(null=True, blank=True)
    subc_sourcing_of_materials_by_rmc_vendors = models.TextField(null=True, blank=True)
    subc_sourcing_of_materials_by_rmc_vendors_remarks = models.TextField(null=True, blank=True)
    subc_rate_per_cum = models.TextField(null=True, blank=True)
    subc_rate_per_cum_remarks = models.TextField(null=True, blank=True)
    subc_work_load_of_each_plants = models.TextField(null=True, blank=True)
    subc_work_load_of_each_plants_remarks = models.TextField(null=True, blank=True)
    subc_other_conditions_delivery = models.TextField(null=True, blank=True)
    subc_other_conditions_delivery_remarks = models.TextField(null=True, blank=True)
    subc_piling_contractors = models.TextField(null=True, blank=True)
    subc_piling_contractors_remarks = models.TextField(null=True, blank=True)
    subc_prw = models.TextField(null=True, blank=True)
    subc_prw_remarks = models.TextField(null=True, blank=True)
    subc_reinforcement_cutting_bending_fixing = models.TextField(null=True, blank=True)
    subc_reinforcement_cutting_bending_fixing_remarks = models.TextField(null=True, blank=True)
    subc_placing_of_concrete = models.TextField(null=True, blank=True)
    subc_placing_of_concrete_remarks = models.TextField(null=True, blank=True)
    subc_structural_steel_fabrication_works = models.TextField(null=True, blank=True)
    subc_structural_steel_fabrication_works_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_subcontractors"
#Access, Crossings & Route details
class TenderMasterNewSurveyMasterAccessCrossingsRouteDetails(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_access_crossings_route_details',on_delete=models.CASCADE)
    acr_is_ease_of_material_movement = models.CharField(max_length=500, null=True, blank=True)
    acr_is_ease_of_material_movement_remarks = models.TextField(null=True, blank=True)
    acr_is_ease_of_equipment_movement = models.CharField(max_length=500, null=True, blank=True)
    acr_is_ease_of_equipment_movement_remarks = models.TextField(null=True, blank=True)
    acr_is_ease_of_men_movement = models.CharField(max_length=500, null=True, blank=True)
    acr_is_ease_of_men_movement_remarks = models.TextField(null=True, blank=True)
    acr_is_create_access_costs = models.CharField(max_length=500, null=True, blank=True)
    acr_is_create_access_costs_remarks = models.TextField(null=True, blank=True)
    acr_is_tree_or_crop_compensation = models.CharField(max_length=500, null=True, blank=True)
    acr_is_tree_or_crop_compensation_remarks = models.TextField(null=True, blank=True)
    acr_is_access_road = models.CharField(max_length=500, null=True, blank=True)
    acr_is_access_road_remarks = models.TextField(null=True, blank=True)
    acr_no_of_existing_access_roads_available_for_access = models.TextField(null=True, blank=True)
    acr_no_of_existing_access_roads_available_for_access_remarks = models.TextField(null=True, blank=True)
    acr_is_any_load_carrying_limitations_access_roads = models.CharField(max_length=500, null=True, blank=True)
    acr_is_any_load_carrying_limitations_access_roads_remarks = models.TextField(null=True, blank=True)
    acr_is_any_bridges_to_be_built_or_strengthened = models.CharField(max_length=500, null=True, blank=True)
    acr_is_any_bridges_to_be_built_or_strengthened_remarks = models.TextField(null=True, blank=True)
    acr_types_of_soils_encountered_along_the_route = models.TextField(null=True, blank=True)
    acr_types_of_soils_encountered_along_the_route_remarks = models.TextField(null=True, blank=True)
    acr_is_requirements_of_tree_cutting_route = models.CharField(max_length=500, null=True, blank=True)
    acr_is_requirements_of_tree_cutting_route_remarks = models.TextField(null=True, blank=True)
    acr_is_extent_of_government_owned_or_privately = models.CharField(max_length=500, null=True, blank=True)
    acr_is_extent_of_government_owned_or_privately_remarks = models.TextField(null=True, blank=True)
    acr_is_facilities_of_hospitals_po_courier = models.CharField(max_length=500, null=True, blank=True)
    acr_is_facilities_of_hospitals_po_courier_remarks = models.TextField(null=True, blank=True)
    acr_proposed_areas_for_main_stores = models.TextField(null=True, blank=True)
    acr_proposed_areas_for_main_stores_remarks = models.TextField(null=True, blank=True)
    acr_lead_lengths_of_various_tower_locations_road = models.TextField(null=True, blank=True)
    acr_lead_lengths_of_various_tower_locations_road_remarks = models.TextField(null=True, blank=True)
    acr_is_no_of_forest_areas_to_be_crossed = models.CharField(max_length=500, null=True, blank=True)
    acr_is_no_of_forest_areas_to_be_crossed_remarks = models.TextField(null=True, blank=True)
    acr_did_client_apply_for_forest_clearance = models.CharField(max_length=500, null=True, blank=True)
    acr_did_client_apply_for_forest_clearance_remarks = models.TextField(null=True, blank=True)
    acr_is_no_of_river_canal_crossings = models.CharField(max_length=500, null=True, blank=True)
    acr_is_no_of_river_canal_crossings_remarks = models.TextField(null=True, blank=True)
    acr_is_crossings_on_hv_power_lines = models.CharField(max_length=500, null=True, blank=True)
    acr_is_crossings_on_hv_power_lines_remarks = models.TextField(null=True, blank=True)
    acr_is_no_of_crossings_over_major_roads = models.CharField(max_length=500, null=True, blank=True)
    acr_is_no_of_crossings_over_major_roads_remarks = models.TextField(null=True, blank=True)
    acr_is_no_of_railway_crossings = models.CharField(max_length=500, null=True, blank=True)
    acr_is_no_of_railway_crossings_remarks = models.TextField(null=True, blank=True)
    acr_any_buildings_or_structures_to_be_crossed = models.TextField(null=True, blank=True)
    acr_any_buildings_or_structures_to_be_crossed_remarks = models.TextField(null=True, blank=True)
    acr_is_any_blasting_required_areas = models.CharField(max_length=500, null=True, blank=True)
    acr_is_any_blasting_required_areas_remarks = models.TextField(null=True, blank=True)
    acr_permissions_approvals_and_restrictions_on_blasting = models.TextField(null=True, blank=True)
    acr_permissions_approvals_and_restrictions_on_blasting_remarks = models.TextField(null=True, blank=True)
    acr_is_any_head_loading_envisaged = models.CharField(max_length=500, null=True, blank=True)
    acr_is_any_head_loading_envisaged_remarks = models.TextField(null=True, blank=True)
    acr_no_of_pile_locations_envisaged = models.TextField(null=True, blank=True)
    acr_no_of_pile_locations_envisaged_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_access_crossings_route_details"
#WasteManagement
class TenderMasterNewSurveyMasterWasteManagement(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_waste_management',on_delete=models.CASCADE)
    wm_location_for_disposal_of_debris = models.TextField(null=True, blank=True)
    wm_location_for_disposal_of_debris_remarks = models.TextField(null=True, blank=True)
    wm_location_for_disposal_of_hydrotest_water = models.TextField(null=True, blank=True)
    wm_location_for_disposal_of_hydrotest_water_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_waste_management"
#Misc
class TenderMasterNewSurveyMasterMisc(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_waste_misc',on_delete=models.CASCADE)
    misc_any_local_mafia_naxals_threat = models.TextField(null=True, blank=True)
    misc_any_local_mafia_naxals_threat_remarks = models.TextField(null=True, blank=True)
    misc_any_pain_points_observed_which_if_addressed = models.TextField(null=True, blank=True)
    misc_any_pain_points_observed_which_if_addressed_remarks = models.TextField(null=True, blank=True)
    misc_intelligence_on_any_competitors_facilities_nearby = models.TextField(null=True, blank=True)
    misc_intelligence_on_any_competitors_facilities_nearby_remarks = models.TextField(null=True, blank=True)
    misc_cost_material_labour_vehicle_power_other_costs = models.TextField(null=True, blank=True)
    misc_cost_material_labour_vehicle_power_other_costs_remarks = models.TextField(null=True, blank=True)
    misc_any_obstruction_site_conditions = models.TextField(null=True, blank=True)
    misc_any_obstruction_site_conditions_remarks = models.TextField(null=True, blank=True)
    misc_insurance_charges_for_personnels = models.TextField(null=True, blank=True)
    misc_insurance_charges_for_personnels_remarks = models.TextField(null=True, blank=True)
    misc_price_indices_to_be_followed_for_overseas_projects = models.TextField(null=True, blank=True)
    misc_price_indices_to_be_followed_for_overseas_projects_remarks = models.TextField(null=True, blank=True)
    misc_prospective_bidders = models.TextField(null=True, blank=True)
    misc_prospective_bidders_remarks = models.TextField(null=True, blank=True)
    misc_general_political_scenario = models.TextField(null=True, blank=True)
    misc_general_political_scenario_remarks = models.TextField(null=True, blank=True)
    misc_place_of_recognized_testing_laboratories = models.TextField(null=True, blank=True)
    misc_place_of_recognized_testing_laboratories_remarks = models.TextField(null=True, blank=True)
    misc_availability_of_cars_trucks = models.TextField(null=True, blank=True)
    misc_availability_of_cars_trucks_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_misc"
#Reference/SimilarProjects
class TenderMasterNewSurveyMasterReferenceSimilarProjects(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_reference_similar_projects', on_delete=models.CASCADE)
    ref_similar_projects_near_to_the_proposed_project = models.TextField(null=True, blank=True)
    ref_similar_projects_near_to_the_proposed_project_remarks = models.TextField(null=True, blank=True)
    ref_nearest_project = models.TextField(null=True, blank=True)
    ref_nearest_project_remarks = models.TextField(null=True, blank=True)
    ref_related_information_from_the_ongoing_project = models.TextField(null=True, blank=True)
    ref_related_information_from_the_ongoing_project_remarks = models.TextField(null=True, blank=True)
    ref_learnings_from_the_existing_project = models.TextField(null=True, blank=True)
    ref_learnings_from_the_existing_project_remarks = models.TextField(null=True, blank=True)
    ref_challenges_faced_by_the_existing_ongoing_projects = models.TextField(null=True, blank=True)
    ref_challenges_faced_by_the_existing_ongoing_projects_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_reference_similar_projects"
#ExistingUtilities
class TenderMasterNewSurveyMasterExistingUtilities(BaseAbstractStructure):
    survey = models.OneToOneField(TenderMasterNewSurveyMaster,related_name='survey_existing_utilities', on_delete=models.CASCADE)
    exu_phe_pipelines_manholes = models.TextField(null=True, blank=True)
    exu_phe_pipelines_manholes_remarks = models.TextField(null=True, blank=True)
    exu_water_supply_pipe_line = models.TextField(null=True, blank=True)
    exu_water_supply_pipe_line_remarks = models.TextField(null=True, blank=True)
    exu_sewage_pipeline = models.TextField(null=True, blank=True)
    exu_sewage_pipeline_remarks = models.TextField(null=True, blank=True)
    exu_electrical_utilities = models.TextField(null=True, blank=True)
    exu_electrical_utilities_remarks = models.TextField(null=True, blank=True)
    exu_ht_line = models.TextField(null=True, blank=True)
    exu_ht_line_remarks = models.TextField(null=True, blank=True)
    exu_lt_line = models.TextField(null=True, blank=True)
    exu_lt_line_remarks = models.TextField(null=True, blank=True)
    exu_transformers_other_electrical_infrastructure = models.TextField(null=True, blank=True)
    exu_transformers_other_electrical_infrastructure_remarks = models.TextField(null=True, blank=True)
    exu_o_g_utilities = models.TextField(null=True, blank=True)
    exu_o_g_utilities_remarks = models.TextField(null=True, blank=True)
    exu_gas_pipeline = models.TextField(null=True, blank=True)
    exu_gas_pipeline_remarks = models.TextField(null=True, blank=True)
    exu_oil_pipeline = models.TextField(null=True, blank=True)
    exu_oil_pipeline_remarks = models.TextField(null=True, blank=True)
    exu_any_other_utilities = models.TextField(null=True, blank=True)
    exu_any_other_utilities_remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_master_new_survey_master_existing_utilities"
        
## END SURVEY
#Tender Empanelment Tracker
class TenderEmpanelmentTrackerTypeMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organization_tender_empanelment_type', on_delete=models.CASCADE)
    name = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "tender_empanelment_tracker_type_master"

    def __str__(self):
        return str(self.name)

class TenderEmpanelmentTracker(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='organization_tender_empanelment', on_delete=models.CASCADE)
    type = models.ForeignKey(TenderEmpanelmentTrackerTypeMaster, on_delete=models.CASCADE, related_name="empanelment_type_master", null=True, blank=True)
    organization_name = models.CharField(max_length=255, null=True, blank=True)
    contact_person = models.CharField(max_length=255,null=True, blank=True)
    contact_number = models.CharField(max_length=50, null=True, blank=True)
    url = models.TextField(null=True,blank=True)
    documents_preparation_status = models.CharField(max_length=50, null=True,blank=True)
    category_applied = models.CharField(max_length=255,null=True,blank=True)
    group_applied = models.CharField(max_length=255,null=True,blank=True)
    monetary_limit_amount = models.FloatField(null=True,blank=True)
    dsc_used_for_enlistment	 = models.CharField(max_length=255, null=True, blank=True)
    login_user_id = models.CharField(max_length=100, null=True, blank=True)
    password = models.CharField(max_length=100,null=True,blank=True)
    submission_application_date = models.DateField(null=True, blank=True)
    submission_status = models.CharField(max_length=50, null=True, blank=True)
    present_status = models.TextField(null=True,blank=True)
    valid_upto_date = models.DateField(null=True,blank=True)
    remarks = models.TextField(null=True,blank=True)
    is_certificate_received = models.BooleanField(default=False)

    class Meta:
        db_table = "tender_empanelment_tracker"

class TenderEmpanelmentTrackerDocument(BaseAbstractStructure):
    DOC_TYPE = (
        ('general_document', 'General Document'),
        ('certificate_document', 'Certificate Document')
    )
    organization = models.ForeignKey(Organization, related_name='tender_empanelment_tracker_organization', on_delete=models.CASCADE)
    empanelment_tracker = models.ForeignKey(TenderEmpanelmentTracker, related_name='tender_empanelment_tracker', on_delete=models.CASCADE,
        blank=True,
        null=True
    )
    doc_type = models.CharField(choices=DOC_TYPE, default="EMAIL", max_length=20)
    file_name=models.CharField(max_length=200, null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(
        upload_to='tender/empanelment_tracker/document/', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)

    class Meta:
        db_table = "tender_empanelment_tracker_document"

class TenderTrendAnalysis(BaseAbstractStructure):
    """ Tender Trend Analysis Models """
    organization = models.ForeignKey(Organization, related_name='tender_trend_analysis_organization',on_delete=models.CASCADE)
    sector = models.ForeignKey(TenderSector, related_name='tender_trend_analysis_sector',on_delete=models.CASCADE, null=True, blank=True)
    tender_id = models.CharField(max_length=250,blank=True, null=True)
    work_description = models.TextField(null=True, blank=True)
    tender_value_gst_in_crore = models.FloatField(default=0)
    awarded_value_in_crore = models.FloatField(default=0)
    state = models.ForeignKey(State, related_name="tender_trend_analysis_state", on_delete=models.CASCADE, null=True, blank=True)
    bid_submission_date = models.DateField(blank=True, null=True)
    financial_bid_opening_date = models.DateField(blank=True, null=True)
    time_of_works = models.CharField(max_length=250,blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    class Meta:
        db_table = "tender_trend_analysis"

class TenderTrendAnalysisAttachments(BaseAbstractStructure):
    trend_analysis = models.ForeignKey(TenderTrendAnalysis,related_name='tender_trend_analysis_attachment', on_delete=models.CASCADE, null=True, blank=True)
    attachment_name = models.CharField(max_length=200, null=True, blank=True)
    attachment = models.FileField(upload_to='tender/site_survey/site_details', null=True, blank=True)
    mime_type = models.CharField(max_length=200, null=True, blank=True)
    file_data = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    class Meta:
        db_table = "tender_trend_analysis_attachments"

class TenderTrendAnalysisParticipants(BaseAbstractStructure):
    trend_analysis = models.ForeignKey(TenderTrendAnalysis,related_name='tender_trend_analysis_participants_trend_analysis',on_delete=models.CASCADE)
    partcipant_name = models.CharField(max_length=250, null=True, blank=True)
    bidded_value_in_crore = models.FloatField(null=True, blank=True)
    percentage = models.FloatField(null=True, blank=True)
    above_below = models.CharField(max_length=250, null=True, blank=True)
    rank = models.IntegerField(null=True, blank=True)
    remarks = models.TextField(blank=True, null=True)
    is_import = models.BooleanField(default=False)
    class Meta:
        db_table = "tender_trend_analysis_participants"

