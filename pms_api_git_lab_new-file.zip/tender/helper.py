
import os
import io, textwrap
import tempfile
from .models import *

def build_tree(items):
    tree = {}
    children = {item['id']: [] for item in items}
    
    # Recursive function to build the tree
    def add_children(node):
        if node['id'] in children:
            node['children'] = children[node['id']]
            for child in node['children']:
                add_children(child)
    
    # Build the children dictionary
    for item in items:
        if item['parent_id'] is not None:
            if not item['parent_id'] in children:
                tree[item['id']] = item
                add_children(item)
            else:
                children[item['parent_id']].append(item)
    
    # Initialize the tree with root nodes
    for item in items:
        if item['parent_id'] is None:
            tree[item['id']] = item
            add_children(item)
    
    return tree

def get_all_child(parent_list,return_list):
    if len(parent_list) == 0:
        return return_list
    else:
        return_list.extend(parent_list)
        parent_list = list(set(list(TenderWBS.cmobjects.filter(parent_id__in=parent_list).values_list('id', flat=True))))
    return get_all_child(parent_list,return_list)


def str2bool(v):
  return v.lower() in ("yes", "true", "t", "1")


def get_tender_data_from_tender_master(_id: int, form__form_internal_name=''):
    _tender = TenderMaster.cmobjects.filter(pk=_id).first()
    try:
        if _tender:
            _tender = TenderMaster.cmobjects.filter(pk=_tender.id).first()
            if form__form_internal_name:
                _data = TenderData.cmobjects.filter(
                    form__form_internal_name=form__form_internal_name,
                    tender=_tender
                ).select_related('form').values('form__form_internal_name', 'value')
            else:
                _data = TenderData.cmobjects.filter(
                    tender=_tender
                ).select_related('form').values('form__form_internal_name', 'value')
            _data_dict = {item['form__form_internal_name']: item['value'] for item in _data}
            # print('_data_dict', _data_dict)
            return _data_dict
        else:
            return {}
    except Exception as e:
        print('ERROR', e)
    return {}


# def get_font(font_size=15):
#     font_paths = [
#         # Windows
#         r"C:\Windows\Fonts\arialbd.ttf",
#         r"C:\Windows\Fonts\Arial Bold.ttf",
#         # Linux (DejaVu is widely available)
#         "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
#         "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
#         # macOS
#         "/System/Library/Fonts/Supplemental/Arial Bold.ttf"
#     ]
#     for path in font_paths:
#         if os.path.exists(path):
#             try:
#                 return ImageFont.truetype(path, font_size)
#             except OSError:
#                 continue
#     bundled_path = os.path.join(os.path.dirname(__file__), "fonts", "DejaVuSans-Bold.ttf")
#     if os.path.exists(bundled_path):
#         return ImageFont.truetype(bundled_path, font_size)
#     return ImageFont.load_default()

# def get_location_name(latitude, longitude):
#     try:
#         geolocator = Nominatim(user_agent="facility_site_app")
#         location = geolocator.reverse(f"{latitude}, {longitude}", language="en")
#         return location.address if location else ""
#     except Exception as e:
#         print(f"Error fetching location name: {e}")
#         return ""

# def overlay_text_on_image_file(content_file, text):
#     content_file.seek(0)
#     image = Image.open(io.BytesIO(content_file.read()))
#     draw = ImageDraw.Draw(image)
#     font_size = max(15, image.width // 40)
#     font = get_font(font_size)
#     # Measure text size
#     text_bbox = draw.textbbox((0, 0), text, font=font)
#     text_width = text_bbox[2] - text_bbox[0]
#     text_height = text_bbox[3] - text_bbox[1]
#     # Position: bottom-left with margin
#     x = 10   # left margin
#     y = image.height - text_height - 20   # bottom margin
#     # Draw background rectangle (highlight)
#     padding = 10
#     rect_x0 = x - padding
#     rect_y0 = y - padding
#     rect_x1 = x + text_width + padding
#     rect_y1 = y + text_height + padding
#     draw.rectangle([rect_x0, rect_y0, rect_x1, rect_y1], fill=(0, 0, 0, 128))  
#     draw.text((x, y), text, fill=(255, 0, 0), font=font)
#     output = io.BytesIO()
#     image.save(output, format="JPEG")
#     output.seek(0)
#     return ContentFile(output.read(), name=content_file.name)





