from django.urls import path
from . import views

urlpatterns = [
    path('accounts-project-data/', views.ProjectChainageBreakupAPIView.as_view()),
    path('account-project-cost-master/', views.AccountProjectCostMasterAPIView.as_view()),  # niu
    # path('accounts-project-budget/', views.AccountProjectBudgetAPIView.as_view()), # old
    path('accounts-budget-breakdown/', views.BudgetBreakdownAPIView.as_view()),
    path('accounts-budget-breakdown-replicate/', views.BudgetBreakdownReplicateAPIView.as_view()),

    path('accounts-budget-breakdown-bulk/', views.BudgetBreakdownBulkAPIView.as_view()),
    path('update-ordering/', views.updateOrderingAPIView.as_view()),

    # accounts activity v2
    path('accounts-project-budget-v2/', views.AccountProjectBudgetV2APIView.as_view()),  # v2
    # path('accounts-project-budget-v2-replicate/', views.AccountProjectBudgetV2ReplicateAPIView.as_view()),
    path('accounts-project-budget-add-child/', views.AccountProjectBudgetAddChildAPIView.as_view()),

    path('account-chainage-master/', views.AccountChainageMasterAPIView.as_view()),
    path('account-chainage-master-bulk/', views.AccountChainageMasterBulkAPIView.as_view()),
    path('account-activity-master/', views.AccountActivityMasterAPIView.as_view()),
    path('account-activity-master-bulk/', views.AccountActivityMasterBulkAPIView.as_view()),
    path('account-activity-master-bulk2/', views.AccountActivityMasterBulk2APIView.as_view()),
    path('account-sub-activity-master/', views.AccountSubActivityMasterAPIView.as_view()),
    path('account-sub-activity-master-bulk/', views.AccountSubActivityMasterBulkAPIView.as_view()),
    path('account-sub-activity-master-bulk2/', views.AccountSubActivityMasterBulk2APIView.as_view()),

    path('accounts-project-budget-v2-pyramid/', views.AccountProjectBudgetV2PyramidAPIView.as_view()),  
    # material apis
    path('account-material-project-group/', views.AccountMaterialProjectGroupAPIView.as_view()),
    path('accounts-material-budget/', views.AccountMaterialProjectAPIView.as_view()),
    path('accounts-material-budget-add-child/', views.AccountMaterialProjectAddChildAPIView.as_view()),

    path('account-material-budget-breakdown/', views.MaterialBudgetBreakdownAPIView.as_view()),
    path('account-material-consumption-breakdown/', views.MaterialConsumptionBreakdownAPIView.as_view()),
    path('account-material-budget-breakdown-bulk/', views.MaterialBudgetBreakdownBulkAPIView.as_view()),
    path('update-ordering-material/', views.updateOrderingMaterialAPIView.as_view()),
    path('accounts-import/', views.AccountsImportAPIView.as_view()),
    path('accounts-import2/', views.AccountsImport2APIView.as_view()),
    path('accounts-material-import/', views.AccountsMaterialImportAPIView.as_view()),

    # AccountPRW
    path('account-prw-category/', views.AccountPRWCategoryAPIView.as_view()),
    path('account-prw/', views.AccountPRWAPIView.as_view()),
    path('account-prw-rates/', views.AccountPRWRatesAPIView.as_view()),
    path('account-prw-category-summary/', views.AccountPRWCategorySummaryAPIView.as_view()),
    path('account-prw-category-summary2/', views.AccountPRWCategorySummary2APIView.as_view()),
    path('account-prw-rates-bulk/', views.AccountPRWRatesBulkAPIView.as_view()),

    path('account-indirect-cost-dpr/', views.AccountIndirectCostDPRAPI.as_view()),
    path('budget-consumption-report/', views.BudgetConsumptionReport.as_view())

]