from datetime import datetime
from colorama import Back, Style
from django.db.models import Subquery, OuterRef, Case, When, F, Max, IntegerField, FloatField, ExpressionWrapper, Func, Value, CharField
from django.db.models.expressions import RawSQL
from django.db.models.functions import Round
from procurement.helper import GroupConcat
from accounts.models import *
from project_and_planning.models import ProjectData
from pprint import pprint
from rest_framework.exceptions import APIException

def convert_date(date_str: str, input_format="%d-%m-%Y", output_format="%Y-%m-%d"):
    try:
        parsed_date = datetime.strptime(date_str, input_format)
        formatted_date = parsed_date.strftime(output_format)
        return formatted_date
    except ValueError:
        return "Invalid date format. Please provide a valid date."


def add_child_details(i_children, depth: int) -> list:
    # print('depth', depth)
    response = []
    arr_children = i_children.split(',') if i_children else []
    if arr_children:
        for _id in arr_children:
            _qs = (AccountProjectBudget.cmobjects.
                  filter(pk=_id).
                  select_related('project', 'sub_activity_master').
                  annotate(
                    project_name=Subquery(
                        ProjectData.cmobjects.filter(
                            project_id=OuterRef('project'),
                            form__form_internal_name='project_name'
                        ).values('project').annotate(value=GroupConcat('value')).values('value')
                    ),
                    project_code=Subquery(
                        ProjectData.cmobjects.filter(
                            project_id=OuterRef('project'),
                            form__form_internal_name='project_id'
                        ).values('project').annotate(value=GroupConcat('value')).values('value')
                    ),
                    # variance_per=Case(
                    #     When(
                    #         budgeted_amount=0,
                    #         then=0
                    #     ),
                    #     When(
                    #         consumption_amount=0,
                    #         then=0
                    #     ),
                    #     default=(
                    #         Round(
                    #             (F('consumption_amount')) * 100.0 / F('budgeted_amount'),
                    #             precision=2
                    #         )
                    #     ), output_field=FloatField()),
                    # has_grand_parents=F('parent__parent_id'),
                    children=Subquery(
                        AccountProjectBudget.cmobjects.filter(
                            parent=OuterRef('pk'),
                        ).values('parent').annotate(ids=GroupConcat('id')).values('ids')
                    ),
                    max_version=Subquery(
                        AccountProjectBudget.cmobjects.filter(
                            project=OuterRef('project'),
                            chainage_no=OuterRef('chainage_no'),
                        ).values('project', 'chainage_no').annotate(max_v=Max('version')).values('max_v')
                    ),
                    custom_order=Case(
                        When(parent__isnull=False, then=F('parent')),
                        default=0,
                        output_field=IntegerField()
                    ),
                    formatted_entry_date=ExpressionWrapper(
                        Func(F('entry_date'), Value('%d-%m-%Y'), function='DATE_FORMAT'), output_field=CharField())
                ))

            result = _qs.values()[0]
            result2 = result.copy()
            # print(type(result2))
            # print(result2['entry_date'].strftime('%d-%m-%Y'), type(result2['entry_date']))
            # result2['entry_date'] = convert_date(result2['entry_date'].strftime('%Y-%m-%d'))

            # update results
            for _i in result.items():
                if _i[0] == 'children' and depth > 0:
                    if _i[1]:
                        result2['children_details'] = add_child_details(_i[1], depth-1)  # recursive call ✨
                        result2['entry_date'] = result2['entry_date'].strftime('%d-%m-%Y')
            response.append(result2)
    return response


def get_budget_breakdown_details(instance: AccountProjectBudget):
    """
    BudgetBreakdown Details
    """
    _details = []
    if instance:
        if instance:
            _details = (BudgetBreakdown.cmobjects.filter(master=instance).order_by('entry_date').
                        values('id',
                               'organization',
                               'master',
                               'project',
                               'qty',
                               'rate',
                               'amount',
                               'entry_date',
                               'is_deleted'))
            for i in _details:
                i['entry_date'] = i['entry_date'].strftime('%d-%m-%Y')
    return _details


def get_consumption_breakdown_details(instance: AccountProjectBudget):
    """
    BudgetBreakdown Details
    """
    _details = []
    if instance:
        _details = (AccountConsumptionBreakdown.cmobjects.filter(master=instance).order_by('entry_date').
                    values('id',
                           'organization',
                           'master',
                           'project',
                           'qty',
                           'rate',
                           'amount',
                           'entry_date',
                           'is_deleted'))
        for i in _details:
            i['entry_date'] = i['entry_date'].strftime('%d-%m-%Y')

    return _details


def get_sub_activity_master_details(instance):
    _details = []
    if instance and instance.sub_activity_master_id:
        _details = AccountSubActivityMaster.cmobjects.filter(pk=instance.sub_activity_master_id).values('id', 'organization', 'name', 'activity', 'parent', 'ordering', 'is_deleted')

    return _details


def get_activity_master_details(instance):
    _details = []
    if instance and instance.sub_activity_master and instance.sub_activity_master.activity:
        _details = AccountActivityMaster.cmobjects.filter(pk=instance.sub_activity_master.activity.id).values(
            'id',
            'organization',
            'name',
            'chainage',
            'ordering',
            'is_deleted'
        )
    return _details


def get_chainage_details(instance):
    _details = []
    if instance and instance.sub_activity_master and instance.sub_activity_master.activity and instance.sub_activity_master.activity.chainage:
        _details = AccountChainageMaster.cmobjects.filter(pk=instance.sub_activity_master.activity.chainage.id).values(
            'id',
            'name',
            'project',
            'organization',
            'ordering',
            'is_deleted'
        )
    return _details


def get_max_budget_entry_date(instance: AccountProjectBudget):
    """
    max budget entry_date
    """
    entry_date = BudgetBreakdown.cmobjects.filter(master=instance, master__is_deleted=False).aggregate(Max('entry_date'))['entry_date__max']
    return entry_date.strftime('%d-%m-%Y') if entry_date else instance.entry_date.strftime('%d-%m-%Y')


def get_max_budget_entry_date_project(instance: AccountProjectBudget):
    """
    max budget entry_date per project basis
    """
    budget_breakdown = instance.account_budget_breakdown.filter(is_deleted=False)
    max_date_l = []
    for i in budget_breakdown:
        max_date_l.append(i.entry_date)
    max_date_l = list(set(max_date_l))
    max_date = max(max_date_l) if max_date_l else None
    return max_date.strftime('%d-%m-%Y') if max_date else (instance.entry_date.strftime('%d-%m-%Y') if instance.entry_date else None)


def get_level_master_details(_id: int):
    _details = []
    if _id:
        _details = AccountProjectCostMaster.cmobjects.filter(pk=_id).values(
            'id', 'name', 'level'
        )
    return _details


def add_activity_master(_id, entry_date=None):
    if entry_date:
        _details = []
        chainage = AccountChainageMaster.cmobjects.filter(pk=_id).first()
        _details = AccountActivityMaster.cmobjects.filter(chainage=chainage).values()
        for i in _details:
            # print(i, type(i))
            i.update({'sub_activity_master': add_sub_activity_master(i['id'], entry_date)})
        return _details

    ############## print('chainage id:', _id)
    _details = []
    chainage = AccountChainageMaster.cmobjects.filter(pk=_id).first()
    _details = AccountActivityMaster.cmobjects.filter(chainage=chainage).values()
    for i in _details:
        # print(i, type(i))
        i.update({'sub_activity_master': add_sub_activity_master(i['id'])})
    return _details


def add_sub_activity_master(_id, entry_date=None):
    _details = []
    parent_list = []
    # print('activity id:', _id)
    activity = AccountActivityMaster.cmobjects.filter(pk=_id).first()
    _details = AccountSubActivityMaster.cmobjects.filter(activity=activity).values()

    def get_account_project_budget(_sub_act_id: int):
        if entry_date:
            _details = []
            _details = AccountProjectBudget.cmobjects.filter(sub_activity_master__id=_sub_act_id, entry_date=entry_date).values()
            for i in _details:
                # print(AccountProjectBudget.cmobjects.filter(sub_activity_master__id=_sub_act_id).query)
                # print(Back.BLUE)
                # pprint(i)
                i.update({'entry_date': i['entry_date'].strftime('%d-%m-%Y')})
                instance = AccountProjectBudget.cmobjects.filter(pk=i['id']).first()
                i.update({'budget_breakdown': get_budget_breakdown_details(instance)})
                i.update({'consumption_breakdown': get_consumption_breakdown_details(instance)})
                # print(Style.RESET_ALL)
            return _details

        ############################ if not entry_date
        if not entry_date:
            # print('_sub_act_id', _sub_act_id)
            # AccountProjectBudget
            _details = []
            _details = AccountProjectBudget.cmobjects.filter(sub_activity_master__id=_sub_act_id).values()
            for i in _details:
                # print(AccountProjectBudget.cmobjects.filter(sub_activity_master__id=_sub_act_id).query)
                # print(Back.BLUE)
                # pprint(i)
                i.update({'entry_date': i['entry_date'].strftime('%d-%m-%Y')})
                instance = AccountProjectBudget.cmobjects.filter(pk=i['id']).first()
                i.update({'budget_breakdown': get_budget_breakdown_details(instance)})
                i.update({'consumption_breakdown': get_consumption_breakdown_details(instance)})
                # print(Style.RESET_ALL)
            return _details

    def children_details_rec(_id, depth):
        # print(_id)
        # print(parent_list)
        __details = []
        if not _id in parent_list:
            parent_list.append(_id)
            _instance = AccountSubActivityMaster.cmobjects.filter(pk=_id).first()
            __details = AccountSubActivityMaster.cmobjects.filter(parent=_instance).values()
            if __details and depth > 0:
                for _i in __details:
                    _i.update({'children_details': children_details_rec(_i['id'], depth - 1)})
                    _i.update({'activity_items': get_account_project_budget(_i['id'])})
        return __details

    result = []
    for i in _details:
        # print(i['id'])
        # print(parent_list)
        if not i['id'] in parent_list:
            # print(Back.LIGHTMAGENTA_EX)
            # pprint(i)
            i.update({'children_details': children_details_rec(i['id'], 2)})
            i.update({'activity_items': get_account_project_budget(i['id'])})
            # print(Style.RESET_ALL)
            result.append(i)
        # print(parent_list)
    # print(parent_list)
    return result


def get_max_version_account_project_budget(project_id):
    raw_sql = RawSQL(
        "SELECT MAX(version)  FROM account_project_budget where project_id=%s", [project_id,])
    max_version = (AccountProjectBudget.
                   cmobjects.
                   filter(project=project_id, ).
                   annotate(custom_annotation=raw_sql).values('custom_annotation')).first()

    if max_version:
        print('max_version', max_version)
        return int(max_version['custom_annotation'])
    return 1


def check_if_sub_activity_child_exists(instance: AccountSubActivityMaster):
    obj = AccountSubActivityMaster.cmobjects.filter(parent=instance)
    if len(obj) > 0:
        return True
    obj2 = AccountProjectBudget.cmobjects.filter(sub_activity_master=instance)
    if len(obj2) > 0:
        return True
    return False


def check_code(instance):
    try:
        if instance.code and not instance.code.strip().replace(' ', '') == '':
            fields_map = [
                [AccountChainageMaster,'project_id',[]],
                [AccountActivityMaster,'chainage__project_id',['chainage__is_deleted']],
                [AccountSubActivityMaster,'activity__chainage__project_id',['activity__is_deleted','activity__chainage__is_deleted']],
                [AccountProjectBudget,'project_id',['sub_activity_master__is_deleted','sub_activity_master__activity__is_deleted','sub_activity_master__activity__chainage__is_deleted']],
            ]
            sender = instance._meta.model
            project_id = instance.activity.chainage.project_id if sender == AccountSubActivityMaster else (instance.chainage.project_id if sender == AccountActivityMaster else instance.project_id)
            records = []
            for value in fields_map:
                if value[0] == sender:
                    search = {
                        'code__iexact': instance.code,
                        value[1]: project_id,
                    }
                    for key in value[2]:
                        search[key] = False
                    details = value[0].cmobjects.filter(**search)
                    if value[0] == sender and instance.id:
                        details = details.exclude(pk=instance.id)
                    records.extend(details.values_list('id',flat=True))
                    # print('~'*120)
                    # print(value[0])
                    # print(details.values_list('id',flat=True))
                    # print('~'*120)
            if len(records) > 0:
                raise APIException({'request_status': 1, 'msg': 'Duplicate Code: '+str(instance.code)})
    except Exception as e:
        error_message = str(e.args[0]) if e.args else str(e)
        raise APIException({'request_status': 0, 'msg': error_message})


