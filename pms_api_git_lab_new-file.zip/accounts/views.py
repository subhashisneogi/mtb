import sys
import os
from datetime import datetime
import pandas as pd
import numpy as np
from openpyxl import load_workbook
# from django.db import connection, transaction
from django.db import connections

import colorama
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import CharField, FloatField, Count, IntegerField, Max, Func, F, Value, CharField, Q, Sum
from django.db.models.expressions import F, Case, When, Value, Subquery, OuterRef, ExpressionWrapper, RawSQL
from django.db.models.functions import Round, Coalesce
from django.http import HttpResponse
from procurement.helper import GroupConcat
from knox.auth import TokenAuthentication
from rest_framework import status
from rest_framework.exceptions import APIException
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.helper import *
from accounts.models import *
from accounts.serializers import *
from administrations.utils import timer_wrapper
from procurement.helper import custom_filters, get_model_details
from project_and_planning.models import *


class ProjectChainageBreakupAPIView(APIView):
    
    

    def get(self, request):
        """
        Get a list
        """

        order_by = self.request.query_params.get('order', '-id')
        id = self.request.query_params.get('id', None)
        search = custom_filters(self.request, {}, ['project', 'order', 'hideLoader'])

        _qs = (ProjectMaster.cmobjects
        .filter(pk=id, *search)
        .select_related('project_head', 'planning_head', 'tender')
        .prefetch_related('projects', 'project_chainage_breakup')
        .order_by(*str(order_by).split(","))
        .annotate(
            project_name=Subquery(
                ProjectData.cmobjects.filter(
                    project_id=OuterRef('pk'),
                    form__form_internal_name='project_name'
                ).values('project').annotate(value=GroupConcat('value')).values('value')
            ),
            project_code=Subquery(
                ProjectData.cmobjects.filter(
                    project_id=OuterRef('pk'),
                    form__form_internal_name='project_id'
                ).values('project').annotate(value=GroupConcat('value')).values('value')
            ),

            chainage_details_kms=Case(
                When(project_chainage_breakup__value__lte=0, then=Value(0)),
                When(project_chainage_breakup__value__gt=0, then=F('project_chainage_breakup__value') * 0.01),
                default=Value(0.5),
                output_field=FloatField(),
            ),
            project_start_in_kms=Subquery(
                ProjectData.cmobjects.filter(
                    project_id=OuterRef('pk'),
                    form__form_internal_name='project_start__in_kms_planning'
                ).values('project').annotate(value=GroupConcat('value')).values('value')
            ),
            project_end_in_kms=Subquery(
                ProjectData.cmobjects.filter(
                    project_id=OuterRef('pk'),
                    form__form_internal_name='length_of_the_project__in_kms_planning'
                ).values('project').annotate(value=GroupConcat('value')).values('value')
            ),
        ))

        result = _qs.values()

        return Response({
            'success': True,
            "result": result,
        },
            status=status.HTTP_200_OK
        )


class AccountProjectCostMasterAPIView(APIView):
    """
        AccountProjectCostMaster APIView
    """
    
    

    def get(self, request):
        """
            AccountProjectBudget APIView
        """
        # check_editor_permissions(request, "account-project-budget")
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountProjectCostMaster.cmobjects.filter(id=id).first()
            serializer = AccountProjectCostMasterSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = AccountProjectCostMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountProjectCostMasterSerializer(page, many=True)

        if all == 'true':
            serializer = AccountProjectCostMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountProjectCostMaster
        """
        request.data['created_by_id'] = request.user.id
        serializer = AccountProjectCostMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountProjectCostMaster
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update
                """
                if AccountProjectCostMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountProjectCostMaster.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountProjectCostMasterSerializer(_details, data=request.data,
                                                                    context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Rack Setting
                """
                if AccountProjectCostMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountProjectCostMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    _details.is_deleted = True
                    _details.save()

                    return Response({'results': {
                        'data': AccountProjectCostMaster.objects.filter(pk=id,
                                                                        organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountProjectBudgetAPIView(APIView):
    """
        CRUD API for model: AccountProjectBudget
    """
    
    

    def get(self, request):
        """
            Get a list AccountProjectBudget
        """
        # check_editor_permissions(request, "account-project-budget")
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        flat = self.request.query_params.get('flat', None)
        order_by = self.request.query_params.get('order_by', '-id')
        order_by_child = self.request.query_params.get('order_by_child', 'ordering_child')
        latest_version = self.request.query_params.get('latest_version', None)
        level = self.request.query_params.get('level', 0)
        # if id:
        #     _details = AccountProjectBudget.cmobjects.filter(id=id).first()
        #     serializer = AccountProjectBudgetSerializer(_details)
        #     return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['flat', 'order_by_child', 'latest_version', 'level', 'hideLoader'])

        _list = AccountProjectBudget.cmobjects.filter(*search).order_by(str(order_by),
                                                                                            str(order_by_child),
                                                                                            str('id'))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountProjectBudgetSerializer(page, many=True)

        if all == 'true':
            serializer = AccountProjectBudgetSerializer(_list, many=True)
            return Response({'results': serializer.data})

        if flat:
            _qs = (AccountProjectBudget.cmobjects.
                   filter(*search).
                   select_related('project', ).
                   # prefetch_related('',).
                   annotate(
                project_name=Subquery(
                    ProjectData.cmobjects.filter(
                        project_id=OuterRef('project'),
                        form__form_internal_name='project_name'
                    ).values('project').annotate(value=GroupConcat('value')).values('value')
                ),
                project_code=Subquery(
                    ProjectData.cmobjects.filter(
                        project_id=OuterRef('project'),
                        form__form_internal_name='project_id'
                    ).values('project').annotate(value=GroupConcat('value')).values('value')
                ),
                # variance_per=Case(
                #     When(
                #         budgeted_amount=0,
                #         then=0
                #     ),
                #     When(
                #         consumption_amount=0,
                #         then=0
                #     ),
                #     default=(
                #         Round(
                #             (F('consumption_amount')) * 100.0 / F('budgeted_amount'),
                #             precision=2
                #         )
                #     ), output_field=FloatField()),
                # has_grand_parents=F('parent__parent_id'),
                children=Subquery(
                    AccountProjectBudget.cmobjects.filter(
                        parent=OuterRef('pk'),
                    ).values('parent').annotate(ids=GroupConcat('id')).values('ids')
                ),
                max_version=Subquery(
                    AccountProjectBudget.cmobjects.filter(
                        project=OuterRef('project'),
                        chainage_no=OuterRef('chainage_no'),
                    ).values('project', 'chainage_no').annotate(max_v=Max('version')).values('max_v')
                ),

                custom_order=Case(
                    When(parent__isnull=False, then=F('parent')),
                    default=0,
                    output_field=IntegerField()
                ),

            ).order_by(str(order_by), str(order_by_child), str('-custom_order')))

            if latest_version:
                _qs_version = (
                    AccountProjectBudget.cmobjects.filter(*search).aggregate(Max('version')))
                # print('version', list(_qs_version.values())[0])
                version = list(_qs_version.values())[0]
                _qs = _qs.filter(version=version)

            if level:
                _qs = _qs.filter(tab_count=level)

            results = _qs.values()

            # update results
            for i in results:
                i['children_details'] = add_child_details(i['children'], depth=10)
                instance = AccountProjectBudget.cmobjects.filter(pk=i['id']).first()
                i['budget_breakdown_details'] = get_budget_breakdown_details(instance)
                i['consumption_breakdown_details'] = get_consumption_breakdown_details(instance)



            return Response({
                'success': True,
                "result": results,
            },
                status=status.HTTP_200_OK
            )

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountProjectBudget
        """
        # check_editor_permissions(request, "account-project-budget")
        request.data['created_by_id'] = request.user.id

        # ✅ update (ordering_child + 1) if not 0
        parent = request.data.get('parent', None)
        if parent and AccountProjectBudget.cmobjects.filter(parent=parent).exists():
            obj = AccountProjectBudget.cmobjects.filter(parent=parent).last()
            ordering_child = int(obj.ordering_child) + 1
            request.data['ordering_child'] = ordering_child

        qry1 = (AccountProjectBudget.cmobjects.
               filter(project=request.data['project'], ).
               values('entry_date').
               annotate(data_count=Count('entry_date')).
               order_by('entry_date'))

        # raw SQL expression
        raw_sql = RawSQL(
            "SELECT MAX(entry_date)  FROM account_project_budget where project_id=%s", [request.data['project'],])
        max_date_qry = (AccountProjectBudget.
                        cmobjects.
                        filter(project=request.data['project'], ).
                        annotate(custom_annotation=raw_sql).values('custom_annotation')).first()

        if (max_date_qry and (datetime.strptime(request.data['entry_date'], "%Y-%m-%d").date() >= max_date_qry['custom_annotation'])):
            request.data['version'] = int(qry1.count()) + 1
        else:
            request.data['version'] = int(qry1.count())

        serializer = AccountProjectBudgetSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountProjectBudget
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountProjectBudget
                """
                if AccountProjectBudget.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountProjectBudget.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountProjectBudgetSerializer(_details, data=request.data,
                                                                context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountProjectBudget
                """
                if AccountProjectBudget.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountProjectBudget.cmobjects.get(pk=id, organization_id=organization_id)
                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()  # add soft delete after testing

                    return Response({'results': {
                        'data': AccountProjectBudget.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


# v2
class AccountProjectBudgetV2APIView(APIView):
    """
        CRUD API for model: AccountProjectBudget
    """
    
    

    @timer_wrapper(route_name='AccountProjectBudgetV2APIView  GET')
    def get(self, request):
        """
            Get a list AccountProjectBudget v2
        """
        # check_editor_permissions(request, "account-project-budget")
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        flat = self.request.query_params.get('flat', None)
        order_by = self.request.query_params.get('order_by', 'id')
        latest_version = self.request.query_params.get('latest_version', None)
        level = self.request.query_params.get('level', 0)

        search = {}
        search = custom_filters(self.request, search, ['flat', 'order_by_child', 'latest_version', 'level', 'hideLoader'])

        _list = AccountProjectBudget.cmobjects.filter(project__is_deleted=False, *search).order_by(str('tab_count'), str(order_by))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountProjectBudgetSerializer(page, many=True)

        if all == 'true':
            serializer = AccountProjectBudgetSerializer(_list, many=True)
            return Response({'results': serializer.data})

        if flat:
            _qs = (AccountProjectBudget.cmobjects.
                   filter(project__is_deleted=False, *search).
                   select_related('project', 'sub_activity_master')
            .order_by(*str(order_by).split(",")))

            if latest_version:
                _qs_version = (
                    AccountProjectBudget.cmobjects.filter(*search).aggregate(Max('version')))
                version = list(_qs_version.values())[0] if _qs_version else 1
                _qs = _qs.filter(version=version)

            if level:
                _qs = _qs.filter(tab_count=level)

            results = _qs.values()

            search1 = {}
            project = self.request.query_params.get('project', None)
            if project:
                search1['project_id'] = project

            budget_breakdown_details = pd.DataFrame(BudgetBreakdown.cmobjects.filter(**search1).order_by('entry_date').
                        values('id',
                               'organization',
                               'master',
                               'project',
                               'qty',
                               'rate',
                               'amount',
                               'entry_date',
                               'is_zero_budget',
                               'is_deleted'))

            consumption_breakdown_details = pd.DataFrame(AccountConsumptionBreakdown.cmobjects.filter(**search1).order_by('entry_date').
                    values('id',
                           'organization',
                           'master',
                           'project',
                           'qty',
                           'rate',
                           'amount',
                           'entry_date',
                           'is_deleted'))
            budget_breakdown_details = budget_breakdown_details.fillna(np.nan).replace([np.nan], [None])
            consumption_breakdown_details = consumption_breakdown_details.fillna(np.nan).replace([np.nan], [None])
            
            if 'entry_date' in budget_breakdown_details:
                budget_breakdown_details['entry_date'] = pd.to_datetime(budget_breakdown_details.entry_date)
                budget_breakdown_details['entry_date'] = budget_breakdown_details['entry_date'].dt.strftime('%d-%m-%Y')
            if 'entry_date' in consumption_breakdown_details:
                consumption_breakdown_details['entry_date'] = pd.to_datetime(consumption_breakdown_details.entry_date)
                consumption_breakdown_details['entry_date'] = consumption_breakdown_details['entry_date'].dt.strftime('%d-%m-%Y')
                        
            for i in results:
                i['entry_date'] = i['entry_date'].strftime('%d-%m-%Y')
                i['budget_breakdown'] = budget_breakdown_details[budget_breakdown_details['master'].values == i['id']].to_dict('records') if 'master' in budget_breakdown_details else []
                i['consumption_breakdown'] = consumption_breakdown_details[consumption_breakdown_details['master'].values == i['id']].to_dict('records') if 'master' in consumption_breakdown_details else []

            budget_entry_date_project_list = None
            zero_budget_entry_date_project_list = None
            if 'is_zero_budget' in budget_breakdown_details and 'entry_date' in budget_breakdown_details:
                budget_entry_date_project_list = sorted(budget_breakdown_details[budget_breakdown_details['is_zero_budget'].values == False]['entry_date'].unique())
                zero_budget_entry_date_project_list = sorted(budget_breakdown_details[budget_breakdown_details['is_zero_budget'].values == True]['entry_date'].unique())
            return Response({
                'success': True,
                "result": results,
                'budget_entry_date_project_list': budget_entry_date_project_list,
                'zero_budget_entry_date_project_list': zero_budget_entry_date_project_list,
            },
                status=status.HTTP_200_OK
            )

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountProjectBudget v2
        """
        # check_editor_permissions(request, "account-project-budget")
        request.data['created_by_id'] = request.user.id

        raw_sql = RawSQL(
            "SELECT MAX(version)  FROM account_project_budget where project_id=%s", [request.data['project'],])
        max_version = (AccountProjectBudget.
                        cmobjects.
                        filter(project=request.data['project'], ).
                        annotate(custom_annotation=raw_sql).values('custom_annotation')).first()

        if max_version:
            print('max_version', max_version)
        else:
            pass



        serializer = AccountProjectBudgetSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountProjectBudget v2
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountProjectBudget
                """
                if AccountProjectBudget.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountProjectBudget.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountProjectBudgetSerializer(_details, data=request.data,
                                                                context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountProjectBudget
                """
                if AccountProjectBudget.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountProjectBudget.cmobjects.get(pk=id, organization_id=organization_id)
                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()  # add soft delete after testing

                    return Response({'results': {
                        'data': AccountProjectBudget.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountProjectBudgetV2ReplicateAPIView(APIView):
    """
        CRUD API for model: AccountChainageMaster
    """
    
    

    def post(self, request):
        """
        Create a new AccountChainageMaster
        """


        new_entry_date = self.request.query_params.get('new_entry_date', None)
        project = self.request.query_params.get('project', None)
        created_by = request.user
        res = []

        new_entry_date = convert_date(new_entry_date)
        raw_sql_max_date_qry = RawSQL(
            "SELECT MAX(entry_date)  FROM account_project_budget where project_id=%s", [project,])
        max_date_qry = (AccountProjectBudget.
                        cmobjects.
                        filter(project=project, ).
                        annotate(custom_annotation=raw_sql_max_date_qry).values('custom_annotation')).first()
        entry_date = max_date_qry['custom_annotation']

        max_version = get_max_version_account_project_budget(project)
        print(entry_date, new_entry_date, max_version)

        account_project_budget = None
        if datetime.strptime(new_entry_date, "%Y-%m-%d").date() > entry_date:
            print('new_entry_date > entry_date')
            # get all `AccountProjectBudget` with child table's data on `entry_date` and `project`
            account_project_budget = AccountProjectBudget.cmobjects.filter(project=project, entry_date=entry_date).exclude(entry_date=new_entry_date)

        def replicate_data(_obj, _new_entry_date):
            print('_new_entry_date', _new_entry_date)
            _res = []
            for item in _obj.values():
                # print('item: ', item)
                old_instance_obj = AccountProjectBudget.cmobjects.filter(pk=item['id']).first()
                _entry_date = datetime.strptime(_new_entry_date, "%Y-%m-%d").date()
                [item.pop(k, None) for k in ('entry_date', 'created_by', 'version', 'id',)]
                instance = AccountProjectBudget.objects.create(
                    created_by=created_by,
                    entry_date=_entry_date,
                    version=int(max_version + 1),
                    **item
                )

                instance.save()
                # save new BudgetBreakdown and AccountConsumptionBreakdown
                print('old_instance_obj', old_instance_obj)
                _budget_breakdown_last_item = BudgetBreakdown.cmobjects.filter(master=old_instance_obj).last()
                _budget_breakdown = BudgetBreakdown.cmobjects.create(
                    organization=instance.organization,
                    master=instance,
                    project=instance.project,
                    entry_date=_entry_date,

                    qty=_budget_breakdown_last_item.qty if _budget_breakdown_last_item else 0,
                    rate=_budget_breakdown_last_item.rate if _budget_breakdown_last_item else 0,
                    amount=_budget_breakdown_last_item.amount if _budget_breakdown_last_item else 0
                )

                _consumption_breakdown_last_item = AccountConsumptionBreakdown.cmobjects.filter(master=old_instance_obj).last()
                _consumption_breakdown = AccountConsumptionBreakdown.cmobjects.create(
                    organization=instance.organization,
                    master=instance,
                    project=instance.project,
                    entry_date=_entry_date,

                    qty=_consumption_breakdown_last_item.qty if _consumption_breakdown_last_item else 0,
                    rate=_consumption_breakdown_last_item.rate if _consumption_breakdown_last_item else 0,
                    amount=_consumption_breakdown_last_item.amount if _consumption_breakdown_last_item else 0
                )
                _res.append(instance.pk)
            return _res

        try:
            with transaction.atomic():
                # atomic true
                # replicate all data `AccountProjectBudget` data on `new_entry_date` and `project`
                res = replicate_data(account_project_budget, new_entry_date) if account_project_budget else None

        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})


class AccountProjectBudgetAddChildAPIView(APIView):
    """
        AccountProjectBudget create child
    """
    
    

    def post(self, request):
        """
        AccountProjectBudget create child
        """

        project = self.request.query_params.get('project', None)
        created_by = request.user
        res = []
        res2 = []

        def create_child_if_not_exists(_project):
            print('@create_child_if_not_exists ')
            project_obj = ProjectMaster.cmobjects.filter(pk=_project).first()
            # get AccountProjectBudget  under project
            account_project_budget = AccountProjectBudget.cmobjects.filter(project=project_obj)
            for master in account_project_budget:
                print('master ', master)
                # check if child exists a). BudgetBreakdown b). AccountConsumptionBreakdown
                # a)
                if BudgetBreakdown.cmobjects.filter(master=master).exists():
                    print('child :BudgetBreakdown exists')
                else:
                    print(Back.BLUE, 'child :BudgetBreakdown NOT exists', Style.RESET_ALL)
                    # insert a blank child with same `entry_date` under this project
                    budget_breakdown = BudgetBreakdown.objects.create(
                        master=master,
                        created_by=created_by,
                        entry_date=master.entry_date,
                        organization=master.organization,
                        project=master.project,
                        qty=0.,
                        rate=0.,
                        amount=0.
                    )
                    budget_breakdown.save()
                    print('created budget_breakdown ', budget_breakdown)
                    res.append(budget_breakdown.id)
                # b)
                if AccountConsumptionBreakdown.cmobjects.filter(master=master).exists():
                    print('child :AccountConsumptionBreakdown exists')
                else:
                    print(Back.CYAN, 'child :AccountConsumptionBreakdown NOT exists', Style.RESET_ALL)
                    # insert a blank child with same `entry_date` under this project
                    account_consumption_breakdown = AccountConsumptionBreakdown.objects.create(
                        master=master,
                        created_by=created_by,
                        entry_date=master.entry_date,
                        organization=master.organization,
                        project=master.project,
                        qty=0.,
                        rate=0.,
                        amount=0.
                    )
                    account_consumption_breakdown.save()
                    print('created account_consumption_breakdown ', account_consumption_breakdown)
                    res2.append(account_consumption_breakdown.id)

        try:
            with transaction.atomic():
                create_child_if_not_exists(project)

        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': {'response': res, 'response2': res2},
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})

    def put(self, request):
        '''
        using raw query
        '''

        project = self.request.query_params.get('project', None)
        created_by = request.user.id
        res = []
        res2 = []

        def insert_data_using_raw_sql_1(data, project, created_by):
            """
            table: account_consumption_breakdown
            """

            query = f"""
                INSERT INTO account_consumption_breakdown 
                (master_id, organization_id, project_id, entry_date, is_deleted, created_at, updated_at, qty, rate, amount, created_by_id)
                SELECT
                    b.id,
                    b.organization_id,
                    b.project_id,
                    b.entry_date,
                    b.is_deleted,
                    b.created_at,
                    b.updated_at,
                    '0' AS qty,
                    '0' AS rate,
                    '0' AS amount,
                    '{created_by}' AS created_by_id
                FROM account_project_budget b
                LEFT JOIN account_consumption_breakdown a ON b.id = a.master_id
                WHERE a.id IS NULL
                AND b.project_id = {project}
            """

            print("1-->", query)

            cursor = connections['default'].cursor()
            try:
                cursor.execute(query, data)
                print('done')
            except Exception as e:
                print('ERROR', str(e))

        def insert_data_using_raw_sql_2(data, project, created_by):
            """
            table: account_budget_breakdown
            """

            query = f"""
                INSERT INTO account_budget_breakdown 
                (master_id, organization_id, project_id, entry_date, is_deleted, created_at, updated_at, qty, rate, amount, created_by_id, is_zero_budget)
                SELECT
                    b.id,
                    b.organization_id,
                    b.project_id,
                    b.entry_date,
                    b.is_deleted,
                    b.created_at,
                    b.updated_at,
                    '0' AS qty,
                    '0' AS rate,
                    '0' AS amount,
                    '{created_by}' AS created_by_id,
                    '0' AS is_zero_budget
                FROM account_project_budget b
                LEFT JOIN account_budget_breakdown a ON b.id = a.master_id
                WHERE a.id IS NULL
                AND b.project_id = {project}
            """

            print("2-->", query)

            cursor = connections['default'].cursor()
            try:
                cursor.execute(query, data)
                print(Back.CYAN, 'done', Style.RESET_ALL)
            except Exception as e:
                print('ERROR', str(e))

        try:
            insert_data_using_raw_sql_1(None, project, created_by)
            insert_data_using_raw_sql_2(None, project, created_by)
        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': {'response': res, 'response2': res2},
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})


class AccountChainageMasterAPIView(APIView):
    """
        CRUD API for model: AccountChainageMaster
    """
    
    

    def get(self, request):
        """
            Get a list AccountChainageMaster
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountChainageMaster.cmobjects.filter(id=id).first()
            serializer = AccountChainageMasterSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = AccountChainageMaster.cmobjects.filter(project__is_deleted=False, *search).order_by(*str(order_by).split(","))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountChainageMasterSerializer(page, many=True)

        if all == 'true':
            serializer = AccountChainageMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountChainageMaster
        """

        request.data['created_by_id'] = request.user.id

        serializer = AccountChainageMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountChainageMaster
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountChainageMaster
                """
                if AccountChainageMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountChainageMaster.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountChainageMasterSerializer(_details, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountChainageMaster
                """
                if AccountChainageMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountChainageMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    # if AccountActivityMaster.cmobjects.filter(chainage=_details).exists():
                    #     raise APIException({'request_status': 1, 'msg': "Please delete all children first!"})
                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()

                    return Response({'results': {
                        'data': AccountChainageMaster.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountChainageMasterBulkAPIView(APIView):
    """
        CRUD API for model: AccountChainageMaster bulk
    """
    
    

    def post(self, request):
        """
        Create a new AccountChainageMaster bulk
        """

        res = []
        try:
            with transaction.atomic():
                if request.data:
                    for i in request.data:
                        project = ProjectMaster.cmobjects.filter(pk=i['project']).first()
                        ordering = i['ordering']
                        name = i['name']
                        _ = AccountChainageMaster.cmobjects.create(project=project, ordering=ordering,
                                                                     name=name)
                        res.append(_.id)
        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})


class AccountActivityMasterAPIView(APIView):
    """
        CRUD API for model: AccountChainageMaster
    """
    
    

    def get(self, request):
        """
            Get a list AccountActivityMaster
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountActivityMaster.cmobjects.filter(id=id).first()
            serializer = AccountActivityMasterSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = AccountActivityMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountActivityMasterSerializer(page, many=True)

        if all == 'true':
            serializer = AccountActivityMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountActivityMaster
        """

        request.data['created_by_id'] = request.user.id

        serializer = AccountActivityMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountActivityMaster
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountActivityMaster
                """
                if AccountActivityMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountActivityMaster.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountActivityMasterSerializer(_details, data=request.data,
                                                                 context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountActivityMaster
                """
                if AccountActivityMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountActivityMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    # if AccountSubActivityMaster.cmobjects.filter(activity=_details).exists():
                    #     raise APIException({'request_status': 1, 'msg': "Please delete all child sub-activity first!"})
                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()

                    return Response({'results': {
                        'data': AccountActivityMaster.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountActivityMasterBulkAPIView(APIView):
    """
        CRUD API for model: AccountChainageMaster bulk
    """
    
    

    def post(self, request):
        """
        Create a new AccountActivityMaster bulk
        """

        res = []
        try:
            with transaction.atomic():
                if request.data:
                    for i in request.data:
                        chainage = AccountChainageMaster.cmobjects.filter(pk=i['chainage']).first()
                        ordering = i['ordering']
                        name = i['name']
                        _ = AccountActivityMaster.cmobjects.create(chainage=chainage, ordering=ordering,
                                                                   name=name)
                        res.append(_.id)
        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})

class AccountActivityMasterBulk2APIView(APIView):
    """
        CRUD API for model: AccountActivityMaster bulk
    """
    
    

    def post(self, request):
        """
        Create a new AccountActivityMaster bulk
        """

        res = []
        try:
            with transaction.atomic():
                if request.data:

                    chainage_ids = request.data.get('chainage_ids', [])
                    organization = request.data.get('organization', None)
                    name = request.data.get('name', None)
                    code = request.data.get('code', None)
                    ordering = request.data.get('ordering', 0)

                    orde = ordering
                    for chainage_id in chainage_ids:
                        chainage = AccountChainageMaster.cmobjects.filter(pk=chainage_id).first()
                        org = Organization.objects.filter(pk=organization).first()
                        _ = AccountActivityMaster.cmobjects.create(chainage=chainage, ordering=orde,
                                                                   name=name, organization=org, code=code)
                        orde += 1
                        res.append(_.id)


        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})



class AccountSubActivityMasterAPIView(APIView):
    """
        CRUD API for model: AccountSubActivityMaster
    """
    
    

    def get(self, request):
        """
            Get a list AccountSubActivityMaster
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountSubActivityMaster.cmobjects.filter(id=id).first()
            serializer = AccountSubActivityMasterSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = AccountSubActivityMaster.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountSubActivityMasterSerializer(page, many=True)

        if all == 'true':
            serializer = AccountSubActivityMasterSerializer(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountSubActivityMaster
        """

        request.data['created_by_id'] = request.user.id

        serializer = AccountSubActivityMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountSubActivityMaster
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountSubActivityMaster
                """
                if AccountSubActivityMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountSubActivityMaster.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountSubActivityMasterSerializer(_details, data=request.data,
                                                                 context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountSubActivityMaster
                """
                if AccountSubActivityMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountSubActivityMaster.cmobjects.get(pk=id, organization_id=organization_id)

                    v = check_if_sub_activity_child_exists(_details)
                    if (v):
                        pass
                        # raise APIException({'request_status': 0, 'msg': 'Please delete all child sub-activity first!'})

                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()

                    return Response({'results': {
                        'data': AccountSubActivityMaster.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})



class AccountSubActivityMasterBulkAPIView(APIView):
    """
        CRUD API for model: AccountSubActivityMaster bulk
    """
    
    

    def post(self, request):
        """
        Create a new AccountSubActivityMaster bulk
        """

        res = []
        try:
            with transaction.atomic():
                if request.data:
                    for i in request.data:
                        activity = AccountActivityMaster.cmobjects.filter(pk=i['activity']).first()
                        ordering = i['ordering']
                        name = i['name']
                        _ = AccountSubActivityMaster.cmobjects.create(activity=activity, ordering=ordering,
                                                                   name=name)
                        res.append(_.id)
        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})


class AccountSubActivityMasterBulk2APIView(APIView):
    """
        CRUD API for model: AccountSubActivityMaster bulk 2
    """
    
    

    def post(self, request):
        """
        Create a new AccountSubActivityMaster bulk 2
        """

        res = []
        try:
            with transaction.atomic():
                if request.data:

                    activity_ids = request.data.get('activity_ids', [])
                    organization = request.data.get('organization', None)
                    name = request.data.get('name', None)
                    parent = request.data.get('parent', None)
                    ordering = request.data.get('ordering', None)
                    code = request.data.get('code', None)

                    parent_sub_activity_ids = request.data.get('parent_sub_activity_ids', [])

                    orde = ordering
                    if not parent_sub_activity_ids:
                        for activity_id in activity_ids:
                            activity = AccountActivityMaster.cmobjects.filter(pk=activity_id).first()
                            parent_sub_activity = AccountSubActivityMaster.cmobjects.filter(pk=parent).first()
                            org = Organization.objects.filter(pk=organization).first()
                            _ = AccountSubActivityMaster.cmobjects.create(activity=activity, ordering=orde, name=name,
                                                                          organization=org, parent=parent_sub_activity,
                                                                          code=code)
                            orde += 1
                            res.append(_.id)
                    if parent_sub_activity_ids:
                        for parent in parent_sub_activity_ids:
                            for activity_id in activity_ids:
                                activity = AccountActivityMaster.cmobjects.filter(pk=activity_id).first()
                                parent_sub_activity = AccountSubActivityMaster.cmobjects.filter(pk=parent).first()
                                org = Organization.objects.filter(pk=organization).first()
                                _ = AccountSubActivityMaster.cmobjects.create(activity=activity, ordering=orde, name=name,
                                                                              organization=org, parent=parent_sub_activity, code=code)
                            orde += 1
                            res.append(_.id)


        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})


class AccountProjectBudgetV2PyramidAPIView(APIView):
    """
        API for model: AccountProjectBudgetV2PyramidAPIView
    """
    
    

    # @timer_wrapper(route_name='AccountProjectBudgetV2PyramidAPIView  GET')
    def get(self, request):
        """
        Get a list
        """

        chainage_order = self.request.query_params.get('chainage_order', '-id')
        activity_order = self.request.query_params.get('activity_order', '-id')
        project_budget_order = self.request.query_params.get('project_budget_order', '-id')
        budget_breakdown_order = self.request.query_params.get('budget_breakdown_order', '-id')
        consumption_breakdown_order = self.request.query_params.get('consumption_breakdown_order', '-id')
        project = self.request.query_params.get('project_id', None)
        search = custom_filters(self.request, {}, ['chainage_order','activity_order','project_budget_order','budget_breakdown_order','consumption_breakdown_order', 'hideLoader'])

        project_list = pd.DataFrame(ProjectMaster.cmobjects.filter(pk=project).annotate(
                            project_name=Subquery(
                                ProjectData.cmobjects.filter(
                                    project_id=OuterRef('pk'),
                                    form__form_internal_name='project_name'
                                ).values('project').annotate(value=GroupConcat('value')).values('value')
                            ),
                            project_code=Subquery(
                                ProjectData.cmobjects.filter(
                                    project_id=OuterRef('pk'),
                                    form__form_internal_name='project_id'
                                ).values('project').annotate(value=GroupConcat('value')).values('value')
                            ),
                            ).values())
        chainage_list = pd.DataFrame(AccountChainageMaster.cmobjects.filter(*search).order_by(str(chainage_order)).values())
        activity_list = pd.DataFrame(AccountActivityMaster.cmobjects.filter(chainage__project=project).order_by(str(activity_order)).values())
        sub_activity_list = pd.DataFrame(AccountSubActivityMaster.cmobjects.filter(activity__chainage__project=project).order_by('parent_id','ordering').values())
        # project_budget_list = pd.DataFrame(AccountProjectBudget.cmobjects.filter(*search).order_by(str(project_budget_order)).values())
        budget_breakdown_list = pd.DataFrame(BudgetBreakdown.cmobjects.filter(*search).order_by(str(budget_breakdown_order)).
                                             values('id',
                                                'organization',
                                                'master',
                                                'project',
                                                'qty',
                                                'rate',
                                                'amount',
                                                'entry_date',
                                                'is_zero_budget',
                                                'is_deleted'))
        consumption_breakdown_list = pd.DataFrame(AccountConsumptionBreakdown.cmobjects.filter(*search).order_by(str(consumption_breakdown_order)).
                                                  values('id',
                                                    'organization',
                                                    'master',
                                                    'project',
                                                    'qty',
                                                    'rate',
                                                    'amount',
                                                    'entry_date',
                                                    'is_deleted'))
        latest_date = None
        if 'entry_date' in budget_breakdown_list:
            latest_date = budget_breakdown_list['entry_date'].max()
        # if 'is_zero_budget' in budget_breakdown_list:
        #     try:
        #         latest_date = budget_breakdown_list[budget_breakdown_list['is_zero_budget'].values == False]['entry_date'].max()
        #         # print(f"Latest date: {latest_date}")
        #     except Exception as e:
        #         print('ERROR ---> ', str(e))
        # else:
        #     latest_date = budget_breakdown_list['entry_date'].max()
        #     # print(f"(else) Latest date: {latest_date}")
        if latest_date:
            latest_date = latest_date.strftime('%d-%m-%Y')
        project_budget_list = pd.DataFrame(AccountProjectBudget.cmobjects.filter(*search).order_by(str(project_budget_order)).values())
        if 'entry_date' in budget_breakdown_list:
            budget_breakdown_list['entry_date'] = pd.to_datetime(budget_breakdown_list.entry_date)
            budget_breakdown_list['entry_date'] = budget_breakdown_list['entry_date'].dt.strftime('%d-%m-%Y')
        if 'entry_date' in consumption_breakdown_list:
            consumption_breakdown_list['entry_date'] = pd.to_datetime(consumption_breakdown_list.entry_date)
            consumption_breakdown_list['entry_date'] = consumption_breakdown_list['entry_date'].dt.strftime('%d-%m-%Y')

        project_list = project_list.fillna(np.nan).replace([np.nan], [None])
        chainage_list = chainage_list.fillna(np.nan).replace([np.nan], [None])
        activity_list = activity_list.fillna(np.nan).replace([np.nan], [None])
        sub_activity_list = sub_activity_list.fillna(np.nan).replace([np.nan], [None])
        project_budget_list = project_budget_list.fillna(np.nan).replace([np.nan], [None])
        project_budget_list['total_budget_breakdown_qty'] = 0
        project_budget_list['total_consumption_breakdown_qty'] = 0
        project_budget_list['total_budget_breakdown'] = 0
        project_budget_list['total_consumption_breakdown'] = 0
        project_budget_list['remaining_qty'] = 0
        project_budget_list['remaining_amount'] = 0
        project_budget_list['budget_breakdown'] = project_budget_list.apply(lambda row: budget_breakdown_list[budget_breakdown_list['master'].values == row['id']].to_dict('records') if 'master' in budget_breakdown_list else [], axis=1)
        project_budget_list['consumption_breakdown'] = project_budget_list.apply(lambda row: consumption_breakdown_list[consumption_breakdown_list['master'].values == row['id']].to_dict('records') if 'master' in consumption_breakdown_list else [], axis=1)
        project_budget_list = project_budget_list.fillna(np.nan).replace([np.nan], [None])
        for index, row in project_budget_list.iterrows():
            for temp in row['budget_breakdown']:
                if latest_date and temp['entry_date'] == latest_date:
                    project_budget_list.at[index, 'total_budget_breakdown_qty'] = float(temp['qty'])
                    project_budget_list.at[index, 'total_budget_breakdown'] = float(temp['amount'])
            for temp in row['consumption_breakdown']:
                project_budget_list.at[index, 'total_consumption_breakdown_qty'] = float(temp['qty'])
                project_budget_list.at[index, 'total_consumption_breakdown'] = float(temp['amount'])
            project_budget_list.at[index, 'remaining_qty'] = float(project_budget_list.at[index, 'total_budget_breakdown_qty'])-float(project_budget_list.at[index, 'total_consumption_breakdown_qty'])
            project_budget_list.at[index, 'remaining_amount'] = float(project_budget_list.at[index, 'total_budget_breakdown'])-float(project_budget_list.at[index, 'total_consumption_breakdown'])
        sub_activity_list['activity_items'] = sub_activity_list.apply(lambda row: project_budget_list[project_budget_list['sub_activity_master_id'].values == row['id']].to_dict('records') if 'sub_activity_master_id' in project_budget_list else [], axis=1)

        def rec(query, parent):
            parent['children_details'] = []
            for item in query:
                if item['parent_id'] == parent['id']:
                    parent['children_details'].append(item)
                    rec(query, item)

        root = {'id': None}
        rec(sub_activity_list.to_dict('records'), root)

        parent_data_pd = pd.DataFrame(root['children_details'])
        parent_data_pd = parent_data_pd.fillna(np.nan).replace([np.nan], [None])
        activity_list['sub_activity_master'] = activity_list.apply(lambda row: parent_data_pd[parent_data_pd['activity_id'].values == row['id']].to_dict('records') if 'activity_id' in parent_data_pd else [], axis=1)
        chainage_list['activity_master'] = chainage_list.apply(lambda row: activity_list[activity_list['chainage_id'].values == row['id']].to_dict('records') if 'chainage_id' in activity_list else [], axis=1)
        project_list['results'] = project_list.apply(lambda row: chainage_list[chainage_list['project_id'].values == row['id']].to_dict('records') if 'project_id' in chainage_list else [], axis=1)
        
        return Response({
            'success': True,
            'dates': pd.unique(budget_breakdown_list['entry_date']) if 'entry_date' in budget_breakdown_list else [],
            "projects": project_list.to_dict('records'),
        },
            status=status.HTTP_200_OK
        )

class BudgetBreakdownAPIView(APIView):
    """
        CRUD API for model: BudgetBreakdown
    """
    
    

    def get(self, request):
        """
            Get a list BudgetBreakdown
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = BudgetBreakdown.cmobjects.filter(id=id).first()
            serializer = BudgetBreakdownSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search,['hideLoader'])

        _list = BudgetBreakdown.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BudgetBreakdownSerializer(page, many=True)

        if all == 'true':
            serializer = BudgetBreakdownSerializer(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new BudgetBreakdown
        """

        request.data['created_by_id'] = request.user.id

        serializer = BudgetBreakdownSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit BudgetBreakdown
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update BudgetBreakdown
                """
                if BudgetBreakdown.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = BudgetBreakdown.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    # is_zero_budget = request.data.get('is_zero_budget')
                    # if is_zero_budget:
                    #     raise APIException({'request_status': 0, 'msg': 'zero_budget can not be edited!'})

                    serializer = BudgetBreakdownSerializer(_details, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                        'msg': "Successfully updated",
                        'status': status.HTTP_202_ACCEPTED,
                        "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete BudgetBreakdown
                """
                if BudgetBreakdown.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = BudgetBreakdown.cmobjects.get(pk=id, organization_id=organization_id)
                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()

                    return Response({'results': {
                        'data': BudgetBreakdown.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class BudgetBreakdownReplicateAPIView(APIView):
    """
        BudgetBreakdown Replicate
    """
    
    

    def post(self, request):
        # try:
            new_entry_date = self.request.query_params.get('new_entry_date', None)
            project = self.request.query_params.get('project', None)
            organization_id = self.request.query_params.get('organization_id', None)
            created_by_id = request.user.id
            new_entry_date = convert_date(new_entry_date)
            res1 = res2 = 0
            with transaction.atomic():
                to_create_list = []
                dupes = []
                main_data_obj = pd.DataFrame(BudgetBreakdown.cmobjects.filter(project_id=project).values().order_by('-entry_date'))
                all_master_obj = list(AccountProjectBudget.cmobjects.filter(project_id=project).values_list('id',flat=True))
                all_dates = list(BudgetBreakdown.cmobjects.filter(project_id=project).values_list('entry_date',flat=True))
                all_dates.append(datetime.strptime(new_entry_date, "%Y-%m-%d").date())
                for check_entry_date in list(set(all_dates)):
                    # print('check_entry_date',check_entry_date)
                    all_data_obj = main_data_obj.loc[(main_data_obj['entry_date'] == check_entry_date)]
                    master_budget = all_data_obj['master_id'] if 'master_id' in all_data_obj else []
                    to_create = list(set(all_master_obj) - set(master_budget))
                    for master_id in to_create:
                        last_qty_rate_amount = main_data_obj.loc[(main_data_obj['entry_date'] <= check_entry_date) & (main_data_obj['master_id'] == master_id)]
                        qty = rate = amount = 0
                        if len(last_qty_rate_amount) > 0:
                            qty = last_qty_rate_amount['qty'].values[0]
                            rate = last_qty_rate_amount['rate'].values[0]
                            amount = last_qty_rate_amount['amount'].values[0]
                        to_create_list.append(BudgetBreakdown(
                            master_id=master_id,
                            created_by_id=created_by_id,
                            entry_date=check_entry_date,
                            organization_id=organization_id,
                            project_id=project,
                            qty=qty,
                            rate=rate,
                            amount=amount
                        ))
                    dupes.extend(all_data_obj[all_data_obj.duplicated(['master_id'], keep='first')]['id'].tolist())
                if len(to_create_list) > 0:
                    BudgetBreakdown.objects.bulk_create(to_create_list, batch_size=1000)
                # print('dupes',dupes)
                if len(dupes) > 0:
                    BudgetBreakdown.objects.filter(pk__in=dupes).update(is_deleted=True,updated_by_id=created_by_id)
                res1 += len(to_create_list)
                res2 += len(dupes)

            return Response(
                {'results': {
                    'data': {'replicate_data': res1,'del_data_if_multiple': res2},
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})

        # except Exception as e:
        #     print('ERROR', e)
        #     raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})


class BudgetBreakdownBulkAPIView(APIView):
    """
        CRUD API for model: BudgetBreakdown bulk
    """
    
    

    def post(self, request):
        """
        Create a new BudgetBreakdown bulk
        """

        res = []
        try:
            with transaction.atomic():
                if request.data:
                    for i in request.data:
                        '''
                        master
                        project
                        organization
                        entry_date
                        qty
                        rate
                        amount
                        '''
                        master = AccountProjectBudget.cmobjects.filter(pk=i['master']).first()
                        project = ProjectMaster.cmobjects.filter(pk=i['project']).first()
                        org = Organization.objects.filter(pk=i['organization']).first()
                        entry_date = convert_date(i['entry_date'])
                        print('master', master)
                        print(Back.CYAN, 'entry_date', entry_date, Style.RESET_ALL)
                        _ = BudgetBreakdown.cmobjects.create(master=master, project=project, entry_date=entry_date, organization=org)
                        res.append(_.id)
        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})


class updateOrderingAPIView(APIView):
    """
        AccountProjectCostMaster APIView
    """
    
    

    def put(self, request):
        """
        Edit AccountProjectCostMaster
        """
        model = self.request.query_params.get('model', 'AccountProjectBudget')
        method = self.request.query_params.get('method', None)
        data = request.data

        _updated = []
        _not_updated = []
        if method.lower() == 'update-order' and data:
            for item in data:
                id = item['id']
                index = item.get('index', None)
                is_visible = item.get('is_visible', None)

                try:
                    if eval(f'{model}.cmobjects.filter(pk=id, ).exists()'):
                        _details = eval(f'{model}.cmobjects.get(pk=id)')

                        if index is not None:
                            _details.ordering = index

                        if is_visible is not None:
                            _details.is_visible = is_visible

                        _details.save()
                        _updated.append(id)

                except Exception as e:
                    _not_updated.append(id)
                    print('--ERROR--', _not_updated)
                    print(e)

        return Response({'results': {
            'Data': {'updated_id': _updated, 'not_updated_id': _not_updated},
        },
            'msg': "Updated",
            'status': status.HTTP_202_ACCEPTED,
            "request_status": 1
        })


class AccountMaterialProjectGroupAPIView(APIView):
    """
    CRUD API for AccountMaterialProjectGroup model
    """
    
    

    def get(self, request):
        """
        Get a list of all AccountMaterialProjectGroup
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            site_details = AccountMaterialProjectGroup.cmobjects.filter(id=id).first()
            serializer = AccountMaterialProjectGroupSerializer(site_details)
            return Response(serializer.data)

        search = {}

        search = custom_filters(self.request, search, [])

        site_list = AccountMaterialProjectGroup.cmobjects.filter(*search).order_by('-id')
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(site_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountMaterialProjectGroupSerializer(page, many=True)

        if all == 'true':
            serializer = AccountMaterialProjectGroupSerializer(site_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new Site
        """

        request.data['created_by_id'] = request.user.id
        serializer = AccountMaterialProjectGroupSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit a Site
        """

        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        site_id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Site
                """
                if AccountMaterialProjectGroup.cmobjects.filter(pk=site_id, organization_id=organization_id).exists():
                    site_details = AccountMaterialProjectGroup.cmobjects.filter(pk=site_id).first()

                    serializer = AccountMaterialProjectGroupSerializer(site_details, data=request.data, context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Site
                """
                if AccountMaterialProjectGroup.cmobjects.filter(pk=site_id, organization_id=organization_id).exists():
                    _details = AccountMaterialProjectGroup.cmobjects.get(
                        pk=site_id, organization_id=organization_id)
                    _details.is_deleted = True
                    _details.save()

                    return Response({'results': {
                        'site': AccountMaterialProjectGroup.cmobjects.filter(pk=site_id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Site',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountMaterialProjectAPIView(APIView):
    """
        CRUD API for model: AccountProjectBudget
    """
    
    

    def get(self, request):
        """
            Get a list AccountMaterialProject
        """

        project_id = self.request.query_params.get('project', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')

        search = {}
        search = custom_filters(self.request, search,['flat' 'latest_version', 'hideLoader'])

        _list = AccountMaterialProject.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountMaterialProjectSerializer(page, many=True)

        budget_entry_date_project_list = MaterialBudgetBreakdown.cmobjects.filter(master__project_id=project_id,is_zero_budget=False,master__is_deleted=False).order_by('entry_date').values_list('entry_date', flat=True).distinct()
        zero_budget_entry_date_project_list = MaterialBudgetBreakdown.cmobjects.filter(master__project_id=project_id,is_zero_budget=True,master__is_deleted=False).order_by('entry_date').values_list('entry_date', flat=True).distinct()

        if all == 'true':
            serializer = AccountMaterialProjectSerializer(_list, many=True)
            return Response({
                'results': serializer.data,
                'budget_entry_date_project_list': budget_entry_date_project_list,
                'zero_budget_entry_date_project_list': zero_budget_entry_date_project_list,
            })


        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
            'budget_entry_date_project_list': budget_entry_date_project_list,
            'zero_budget_entry_date_project_list': zero_budget_entry_date_project_list,
        })

    def post(self, request):
        """
        Create a new AccountMaterialProject
        """
        request.data['created_by_id'] = request.user.id

        serializer = AccountMaterialProjectSerializer(data=request.data, context={'request': request})

        request_data_copy = self.request.data.copy()

        if request_data_copy:
            for breakdown_item in request_data_copy['breakdown']:
                if request_data_copy['material_code'] != breakdown_item['material_code']:
                    raise APIException({'request_status': 0, 'msg': "Wrong Material code."})

                if breakdown_item['material_code'] and breakdown_item['entry_date']:
                    
                    # check if material_code with same date already exists:
                    if MaterialBudgetBreakdown.cmobjects.filter(
                            is_deleted=False,
                            master__is_deleted=False,
                            master__project__id=request_data_copy["project"],
                            material_code=breakdown_item['material_code'],
                            entry_date=convert_date(breakdown_item['entry_date']),
                    ).exists():
                        raise APIException({'request_status': 0, 'msg': "`Entry Date` with same `material code` exists!"})

        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountMaterialProject
        """
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountMaterialProject
                """
                if AccountMaterialProject.cmobjects.filter(pk=id,).exists():
                    _details = AccountMaterialProject.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountMaterialProjectSerializer(_details, data=request.data, context={'request': request})

                    """ edit validations """
                    request_data_copy = self.request.data.copy()
                    if request_data_copy:
                        for breakdown_item in request_data_copy['breakdown']:

                            if request_data_copy['material_code'] != breakdown_item['material_code']:
                                raise APIException({'request_status': 0, 'msg': "Wrong Material code."})

                            # qs = MaterialBudgetBreakdown.cmobjects.filter(master__project__id=request_data_copy["project"], master__material_code=breakdown_item['material_code'],  material_code=breakdown_item['material_code'], entry_date=convert_date(breakdown_item['entry_date']), master__is_deleted=False,).count()
                            # print(Back.MAGENTA, qs, Style.RESET_ALL)

                            if MaterialBudgetBreakdown.cmobjects.filter(
                                    master__is_deleted=False,
                                    is_deleted=False,
                                    master__project__id=request_data_copy["project"],
                                    master__material_code=breakdown_item['material_code'],
                                    material_code=breakdown_item['material_code'],
                                    entry_date=convert_date(breakdown_item['entry_date']),
                                    ).count() > 1:
                                raise APIException({'request_status': 0, 'msg': "`Entry Date` with same `material code` exists!!!"})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountMaterialProject
                """
                if AccountMaterialProject.cmobjects.filter(pk=id, ).exists():
                    _details = AccountMaterialProject.cmobjects.get(pk=id,)
                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()

                    return Response({'results': {
                        'data': AccountMaterialProject.objects.filter(pk=id,).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountMaterialProjectAddChildAPIView(APIView):
    def post(self, request):
        """
        AccountMaterialProject create child
        """

        project = self.request.query_params.get('project', None)
        created_by = request.user
        res = []
        res2 = []

        def create_child_if_not_exists(_project):
            print('@create_child_if_not_exists ')
            project_obj = ProjectMaster.cmobjects.filter(pk=_project).first()
            # get AccountMaterialProject  under project
            account_material_project = AccountMaterialProject.cmobjects.filter(project=project_obj)
            for master in account_material_project:
                print('master ', master)
                # check if child exists a). MaterialBudgetBreakdown b). MaterialConsumptionBreakdown
                # a)
                if MaterialBudgetBreakdown.cmobjects.filter(master=master).exists():
                    print('child :MaterialBudgetBreakdown exists')
                else:
                    print(Back.BLUE, 'child :MaterialBudgetBreakdown NOT exists', Style.RESET_ALL)
                    # insert a blank child with same `entry_date` under this project
                    _ = MaterialBudgetBreakdown.objects.create(
                        master=master,
                        created_by=created_by,
                        entry_date=master.start_date,
                        material_code=master.material_code,
                        qty=0.,
                        rate=0.,
                        amount=0.
                    )
                    _.save()
                    print('created MaterialBudgetBreakdown ', _)
                    res.append(_.id)
                # b)
                if MaterialConsumptionBreakdown.cmobjects.filter(master=master).exists():
                    print('child :MaterialConsumptionBreakdown exists')
                else:
                    print(Back.CYAN, 'child :MaterialConsumptionBreakdown NOT exists', Style.RESET_ALL)
                    # insert a blank child with same `entry_date` under this project
                    _ = MaterialConsumptionBreakdown.objects.create(
                        master=master,
                        created_by=created_by,
                        entry_date=master.start_date,
                        material_code=master.material_code,
                        consumed_qty=0.,
                        consumed_rate=0.,
                        consumed_amt=0.
                    )
                    _.save()
                    print('created MaterialConsumptionBreakdown', _)
                    res2.append(_.id)

        try:
            with transaction.atomic():
                create_child_if_not_exists(project)

        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': {'response': res, 'response2': res2},
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})


class MaterialBudgetBreakdownAPIView(APIView):
    """
        CRUD API for model: MaterialConsumptionBreakdown
    """
    
    

    def get(self, request):
        """
            Get a list MaterialBudgetBreakdown
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = MaterialBudgetBreakdown.cmobjects.filter(id=id).first()
            serializer = MaterialBudgetBreakdownSerializer2(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = MaterialBudgetBreakdown.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MaterialBudgetBreakdownSerializer2(page, many=True)

        if all == 'true':
            serializer = MaterialBudgetBreakdownSerializer2(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new MaterialBudgetBreakdown
        """

        request.data['created_by_id'] = request.user.id

        serializer = MaterialBudgetBreakdownSerializer2(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit MaterialBudgetBreakdown
        """
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update MaterialBudgetBreakdown
                """
                if MaterialBudgetBreakdown.cmobjects.filter(pk=id).exists():
                    _details = MaterialBudgetBreakdown.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    # is_zero_budget = request.data.get('is_zero_budget')
                    # if is_zero_budget:
                    #     raise APIException({'request_status': 0, 'msg': 'zero_budget can not be edited!'})

                    serializer = MaterialBudgetBreakdownSerializer2(_details, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete MaterialBudgetBreakdown
                """
                if MaterialBudgetBreakdown.cmobjects.filter(pk=id,).exists():
                    _details = MaterialBudgetBreakdown.cmobjects.get(pk=id,)
                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()

                    return Response({'results': {
                        'data': MaterialBudgetBreakdown.objects.filter(pk=id,).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class MaterialConsumptionBreakdownAPIView(APIView):
    """
        CRUD API for model: MaterialConsumptionBreakdown
    """
    
    

    def get(self, request):
        """
            Get a list MaterialConsumptionBreakdown
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = MaterialConsumptionBreakdown.cmobjects.filter(id=id).first()
            serializer = MaterialConsumptionBreakdownSerializer2(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = MaterialConsumptionBreakdown.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = MaterialConsumptionBreakdownSerializer2(page, many=True)

        if all == 'true':
            serializer = MaterialConsumptionBreakdownSerializer2(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new MaterialConsumptionBreakdown
        """

        request.data['created_by_id'] = request.user.id

        serializer = MaterialConsumptionBreakdownSerializer2(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit MaterialConsumptionBreakdown
        """
        method = self.request.query_params.get('method', None)
        id = self.request.query_params.get('id', None)
        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update MaterialConsumptionBreakdown
                """
                if MaterialConsumptionBreakdown.cmobjects.filter(pk=id).exists():
                    _details = MaterialConsumptionBreakdown.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = MaterialConsumptionBreakdownSerializer2(_details, data=request.data, context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete MaterialConsumptionBreakdown
                """
                if MaterialConsumptionBreakdown.cmobjects.filter(pk=id,).exists():
                    _details = MaterialConsumptionBreakdown.cmobjects.get(pk=id,)
                    _details.is_deleted = True
                    _details.save()
                    # _details.delete()

                    return Response({'results': {
                        'data': MaterialConsumptionBreakdown.objects.filter(pk=id,).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})



class MaterialBudgetBreakdownBulkAPIView(APIView):
    """
        CRUD API for model: MaterialConsumptionBreakdown bulk
    """
    
    

    def post(self, request):
        """
        Create a new MaterialBudgetBreakdown bulk
        """

        res = []
        try:
            with transaction.atomic():
                if request.data:
                    for i in request.data:
                        master = AccountMaterialProject.cmobjects.filter(pk=i['master']).first()
                        material_code = i['material_code']
                        is_zero_budget = i['is_zero_budget']
                        entry_date = convert_date(i['entry_date'])

                        print("master", master)
                        print(Back.GREEN, 'entry_date', entry_date, Style.RESET_ALL)

                        _ = MaterialBudgetBreakdown.cmobjects.create(master=master, material_code=material_code, entry_date=entry_date, is_zero_budget=is_zero_budget)
                        res.append(_.id)
        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})


class updateOrderingMaterialAPIView(APIView):
    """
        AccountMaterialProject APIView order update
    """
    
    

    def put(self, request):
        """
        Edit AccountMaterialProject
        """
        method = self.request.query_params.get('method', None)
        data = request.data

        _updated = []
        _not_updated = []
        if method.lower() == 'update-order' and data:
            for item in data:
                id = item['id']
                index = item.get('index', None)

                try:
                    if AccountMaterialProject.cmobjects.filter(pk=id, ).exists():
                        _details = AccountMaterialProject.cmobjects.get(pk=id)
                        if index is not None:
                            _details.ordering = index
                        _details.save()
                        _updated.append(id)
                except Exception as e:
                    _not_updated.append(id)
                    print('--ERROR--', _not_updated)
                    print(e)

        return Response({'results': {
            'Data': {'updated_id': _updated, 'not_updated_id': _not_updated},
        },
            'msg': "Updated",
            'status': status.HTTP_202_ACCEPTED,
            "request_status": 1
        })


class AccountsImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'chainage': 0, 'activity': 0, 'sub_activity': 0, 'project_budget': 0, 'project_data_add': 0, 'project_data_update': 0}
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                type = request.data.get('type', 'budget')
                project_id = request.data.get('project_id', None)
                entry_date = request.data.get('entry_date', None)
                is_zero_budget = True if request.data.get('is_zero_budget', False) else False
                print(Back.CYAN, 'is_zero_budget', is_zero_budget, Style.RESET_ALL)
                organization_id = self.request.query_params.get('organization_id', None)
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")
                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")
                if type == 'budget':
                    all_dates = list(BudgetBreakdown.cmobjects.filter(organization_id=organization_id,project_id=project_id,is_zero_budget=is_zero_budget).values_list('entry_date',flat=True).order_by('-entry_date').distinct())
                    if all_dates:
                        if datetime.strptime(entry_date, "%Y-%m-%d").date() in all_dates and not datetime.strptime(entry_date, "%Y-%m-%d").date() == all_dates[0]:
                            raise APIException("entry date locked")
                for field in ["chainage", "chainage_wbs_code", "activity", "activity_wbs_code", "parent_sub_activity", "sub_activity", "sub_activity_wbs_code", "project_budget", "uom", "qty", "rate", "amount"]:
                    field_map.setdefault(field, field)
                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                    # sheet_xlsx[column] = sheet_xlsx[column].ffill(axis=0)
                # sheet_xlsx = sheet_xlsx.replace(np.nan, None)
                chainage_list = pd.DataFrame(AccountChainageMaster.cmobjects.filter(organization_id=organization_id,project_id=project_id).values('id','name',))
                activity_list = pd.DataFrame(AccountActivityMaster.cmobjects.filter(organization_id=organization_id,chainage__project_id=project_id).values('id','name','chainage_id',))
                sub_activity_list = pd.DataFrame(AccountSubActivityMaster.cmobjects.filter(organization_id=organization_id,activity__chainage__project_id=project_id).order_by('parent_id').values('id','name','activity_id','parent_id',))
                project_budget_list = pd.DataFrame(AccountProjectBudget.cmobjects.filter(organization_id=organization_id,project_id=project_id).values('id','activity','sub_activity_master_id',))
                project_data_list = []
                if type == 'budget':
                    # project_data_list = BudgetBreakdown.cmobjects.filter(organization_id=organization_id,project_id=project_id,entry_date=entry_date,is_zero_budget=is_zero_budget).values('id','qty','rate','amount','master_id',)
                    project_data_list = BudgetBreakdown.cmobjects.filter(organization_id=organization_id, project_id=project_id, entry_date=entry_date,).values('id','qty','rate','amount','master_id',)
                else:
                    project_data_list = AccountConsumptionBreakdown.cmobjects.filter(organization_id=organization_id,project_id=project_id).values('id','qty','rate','amount','master_id',)
                project_data_list = pd.DataFrame(project_data_list)
                
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                chainage_list = chainage_list.fillna(np.nan).replace([np.nan], [None])
                activity_list = activity_list.fillna(np.nan).replace([np.nan], [None])
                sub_activity_list = sub_activity_list.fillna(np.nan).replace([np.nan], [None])
                project_budget_list = project_budget_list.fillna(np.nan).replace([np.nan], [None])
                project_data_list = project_data_list.fillna(np.nan).replace([np.nan], [None])
                
                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x
                
                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                chainage_list = chainage_list.applymap(lambda x: process_str(x))
                activity_list = activity_list.applymap(lambda x: process_str(x))
                sub_activity_list = sub_activity_list.applymap(lambda x: process_str(x))
                project_budget_list = project_budget_list.applymap(lambda x: process_str(x))
                project_data_list = project_data_list.applymap(lambda x: process_str(x))

                sheet_xlsx[field_map['qty']] = pd.to_numeric(sheet_xlsx[field_map['qty']], errors='coerce')
                sheet_xlsx[field_map['rate']] = pd.to_numeric(sheet_xlsx[field_map['rate']], errors='coerce')
                sheet_xlsx[field_map['amount']] = pd.to_numeric(sheet_xlsx[field_map['amount']], errors='coerce')

                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                chainage_list = chainage_list.replace([np.nan], [None])
                activity_list = activity_list.replace([np.nan], [None])
                sub_activity_list = sub_activity_list.replace([np.nan], [None])
                project_budget_list = project_budget_list.replace([np.nan], [None])
                project_data_list = project_data_list.replace([np.nan], [None])

                # print(project_data_list)

                def check_chainage(row):
                    result = None
                    if 'name' in chainage_list and row[field_map['chainage']]:
                        temp = list(chainage_list.loc[(chainage_list['name'].values == process_str(row[field_map['chainage']]).strip())]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_activity(row):
                    result = None
                    if 'name' in activity_list and row[field_map['activity']] and row['chainage_id']:
                        temp = list(activity_list.loc[(activity_list['name'].values == process_str(row[field_map['activity']]).strip()) & (activity_list['chainage_id'].values == row['chainage_id'])]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_parent(row):
                    result = None
                    if 'name' in sub_activity_list and row[field_map['parent_sub_activity']] and row['activity_id']:
                        temp = list(sub_activity_list.loc[(sub_activity_list['name'].values == process_str(row[field_map['parent_sub_activity']]).strip()) & (sub_activity_list['activity_id'].values == row['activity_id'])]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_sub_activity(row):
                    result = None
                    if 'name' in sub_activity_list and row[field_map['sub_activity']] and row['activity_id']:
                        temp = []
                        if row[field_map['parent_sub_activity']]:
                            if row['parent_id']:
                                temp = list(sub_activity_list.loc[(sub_activity_list['name'].values == process_str(row[field_map['sub_activity']]).strip()) & (sub_activity_list['activity_id'].values == row['activity_id']) & (sub_activity_list['parent_id'].values == row['parent_id'])]['id'].items())
                        else:
                            temp = list(sub_activity_list.loc[(sub_activity_list['name'].values == process_str(row[field_map['sub_activity']]).strip()) & (sub_activity_list['activity_id'].values == row['activity_id'])]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_project_budget(row):
                    result = None
                    if 'activity' in project_budget_list and row[field_map['project_budget']] and row['sub_activity_id']:
                        temp = list(project_budget_list.loc[(project_budget_list['activity'].values == process_str(row[field_map['project_budget']]).strip()) & (project_budget_list['sub_activity_master_id'].values == row['sub_activity_id'])]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_project_budget_data(id):
                    result = None
                    if 'master_id' in project_data_list and id:
                        temp = list(project_data_list.loc[project_data_list['master_id'].values == id]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                sheet_xlsx['chainage_id'] = sheet_xlsx.apply(lambda row: check_chainage(row), axis=1)
                sheet_xlsx['activity_id'] = sheet_xlsx.apply(lambda row: check_activity(row), axis=1)
                sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row: check_parent(row), axis=1)
                sheet_xlsx['sub_activity_id'] = sheet_xlsx.apply(lambda row: check_sub_activity(row), axis=1)
                sheet_xlsx['project_budget_id'] = sheet_xlsx.apply(lambda row: check_project_budget(row), axis=1)

                project_data_add = []
                master_id_list = []
                for index, row in sheet_xlsx.iterrows():
                    sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                    if row[field_map['chainage']] and not sheet_xlsx.at[index, 'chainage_id']:
                        instance = AccountChainageMaster.cmobjects.create(
                            organization_id = organization_id,
                            project_id = project_id,
                            name = row[field_map['chainage']],
                            code = row[field_map['chainage_wbs_code']],
                        )
                        sheet_xlsx['chainage_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['chainage']] and row1[field_map['chainage']] and (row[field_map['chainage']] == row1[field_map['chainage']]) else None) if (not row1['chainage_id']) else row1['chainage_id'], axis=1)
                        count_data['chainage'] += 1
                    sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                    if row[field_map['activity']] and not sheet_xlsx.at[index, 'activity_id']:
                        instance = AccountActivityMaster.cmobjects.create(
                            organization_id = organization_id,
                            name = row[field_map['activity']],
                            code = row[field_map['activity_wbs_code']],
                            chainage_id = sheet_xlsx.at[index, 'chainage_id'],
                        )
                        sheet_xlsx['activity_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['activity']] and row1[field_map['activity']] and (row[field_map['activity']] == row1[field_map['activity']]) and (row[field_map['chainage']] == row1[field_map['chainage']]) else None) if (not row1['activity_id']) else row1['activity_id'], axis=1)
                        count_data['activity'] += 1
                    sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                    if row[field_map['parent_sub_activity']] and not sheet_xlsx.at[index, 'parent_id']:
                        instance = AccountSubActivityMaster.cmobjects.create(
                            organization_id = organization_id,
                            name = row[field_map['parent_sub_activity']],
                            activity_id = sheet_xlsx.at[index, 'activity_id'],
                        )
                        sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['parent_sub_activity']] and row1[field_map['parent_sub_activity']] and (row[field_map['parent_sub_activity']] == row1[field_map['parent_sub_activity']]) and (row[field_map['activity']] == row1[field_map['activity']]) and (row[field_map['chainage']] == row1[field_map['chainage']]) else None) if (not row1['parent_id']) else row1['parent_id'], axis=1)
                        sheet_xlsx['sub_activity_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['parent_sub_activity']] and row1[field_map['sub_activity']] and (row[field_map['parent_sub_activity']] == row1[field_map['sub_activity']]) and (row[field_map['activity']] == row1[field_map['activity']]) and (row[field_map['chainage']] == row1[field_map['chainage']]) else None) if (not row1['sub_activity_id']) else row1['sub_activity_id'], axis=1)
                        count_data['sub_activity'] += 1
                    sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                    if row[field_map['sub_activity']] and not sheet_xlsx.at[index, 'sub_activity_id']:
                        instance = AccountSubActivityMaster.cmobjects.create(
                            organization_id = organization_id,
                            name = row[field_map['sub_activity']],
                            code = row[field_map['sub_activity_wbs_code']],
                            activity_id = sheet_xlsx.at[index, 'activity_id'],
                            parent_id = sheet_xlsx.at[index, 'parent_id'],
                        )
                        sheet_xlsx['sub_activity_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['sub_activity']] and row1[field_map['sub_activity']] and (row[field_map['sub_activity']] == row1[field_map['sub_activity']]) and (row[field_map['parent_sub_activity']] == row1[field_map['parent_sub_activity']]) and (row[field_map['activity']] == row1[field_map['activity']]) and (row[field_map['chainage']] == row1[field_map['chainage']]) else None) if (not row1['sub_activity_id']) else row1['sub_activity_id'], axis=1)
                        sheet_xlsx['parent_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['sub_activity']] and row1[field_map['parent_sub_activity']] and (row[field_map['sub_activity']] == row1[field_map['parent_sub_activity']]) and (row[field_map['activity']] == row1[field_map['activity']]) and (row[field_map['chainage']] == row1[field_map['chainage']]) else None) if (not row1['parent_id']) else row1['parent_id'], axis=1)
                        count_data['sub_activity'] += 1
                    sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                    if row[field_map['project_budget']]:
                        if not sheet_xlsx.at[index, 'project_budget_id']:
                            # print(sheet_xlsx.at[index, 'sub_activity_id'])
                            instance = AccountProjectBudget.cmobjects.create(
                                organization_id = organization_id,
                                project_id = project_id,
                                activity = row[field_map['project_budget']],
                                entry_date = entry_date,
                                uom_txt = row[field_map['uom']],
                                sub_activity_master_id = sheet_xlsx.at[index, 'sub_activity_id'],
                            )
                            sheet_xlsx['project_budget_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['project_budget']] and row1[field_map['project_budget']] and (row[field_map['project_budget']] == row1[field_map['project_budget']]) and (row[field_map['sub_activity']] == row1[field_map['sub_activity']]) and (row[field_map['parent_sub_activity']] == row1[field_map['parent_sub_activity']]) and (row[field_map['activity']] == row1[field_map['activity']]) and (row[field_map['chainage']] == row1[field_map['chainage']]) else None) if (not row1['project_budget_id']) else row1['project_budget_id'], axis=1)
                            count_data['project_budget'] += 1
                        project_budget_record = check_project_budget_data(sheet_xlsx.at[index, 'project_budget_id'])
                        # print(project_budget_record)
                        if project_budget_record:
                            data = {
                                'organization_id': organization_id,
                                'project_id': project_id,
                                'qty': row[field_map['qty']] if row[field_map['qty']] else 0,
                                'rate': row[field_map['rate']] if row[field_map['rate']] else 0,
                                'amount': row[field_map['amount']] if row[field_map['amount']] else 0,
                                'entry_date': entry_date,
                                'master_id': sheet_xlsx.at[index, 'project_budget_id'],
                            }
                            if type == 'budget':
                                data['is_zero_budget'] = is_zero_budget
                                instance = BudgetBreakdown.cmobjects.filter(pk=project_budget_record).update(**data)
                            else:
                                instance = AccountConsumptionBreakdown.cmobjects.filter(pk=project_budget_record).update(**data)
                            count_data['project_data_update'] += 1
                        else:
                            if not sheet_xlsx.at[index, 'project_budget_id'] in master_id_list:
                                data = {
                                    'organization_id': organization_id,
                                    'project_id': project_id,
                                    'qty': row[field_map['qty']] if row[field_map['qty']] else 0,
                                    'rate': row[field_map['rate']] if row[field_map['rate']] else 0,
                                    'amount': row[field_map['amount']] if row[field_map['amount']] else 0,
                                    'entry_date': entry_date,
                                    'master_id': sheet_xlsx.at[index, 'project_budget_id'],
                                }
                                if type == 'budget':
                                    data['is_zero_budget'] = is_zero_budget
                                    project_data_add.append(BudgetBreakdown(**data))
                                else:
                                    project_data_add.append(AccountConsumptionBreakdown(**data))
                                master_id_list.append(sheet_xlsx.at[index, 'project_budget_id'])
                                count_data['project_data_add'] += 1
                    # sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                
                if type == 'budget':
                    BudgetBreakdown.objects.bulk_create(project_data_add, batch_size=1000, ignore_conflicts=False)
                else:
                    AccountConsumptionBreakdown.objects.bulk_create(project_data_add, batch_size=1000, ignore_conflicts=False)
                # sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                # print(sheet_xlsx)
                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict(),
                        'count_data': count_data,
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class AccountsImport2APIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        # try:
            with transaction.atomic():
                file_name = request.data.get('file_name', None)
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")
                print(path)
                result = {}
                entity_row = 1
                code_row = 2
                uom_row = 3
                fields = {
                    'project': {
                        'color': 'FF3F65FF',
                        'alignment': None,
                    },
                    'chainage': {
                        'color': 'FF758FF6',
                        'alignment': None,
                    },
                    'activity': {
                        'color': 'FFB3C2FE',
                        'alignment': None,
                    },
                    'sub_activity': {
                        'color': '00000000',
                        'alignment': 'left',
                    },
                    'activity_item': {
                        'color': '00000000',
                        'alignment': 'right',
                    },
                }
                sheet_xlsx = pd.read_excel(path)
                print(sheet_xlsx.columns)
                print(sheet_xlsx)
                # workbook = load_workbook(path, data_only = True)
                # sheet = workbook.worksheets[0]
                # data_list = {
                #     'project': None,
                #     'project_code': None,
                #     'chainage': None,
                #     'chainage_code': None,
                #     'activity': None,
                #     'activity_code': None,
                #     'parent_sub_activity': None,
                #     'sub_activity': None,
                #     'sub_activity_code': None,
                #     'sub_activity_indent': 0,
                #     'activity_item': None,
                #     'uom': None,
                # }
                # result = {}
                # for key in data_list.keys():
                #     result[key] = []
                # result = pd.DataFrame(result)
                # for data in sheet:
                #     for key,value in fields.items():
                #         if data[entity_row].fill.start_color.index == value['color'] and data[entity_row].alignment.horizontal == value['alignment']:
                #             data_list[key] = data[entity_row].value
                #             if key == 'project':
                #                 data_list['project_code'] = data[code_row].value
                #                 data_list['chainage'] = None
                #                 data_list['chainage_code'] = None
                #                 data_list['activity'] = None
                #                 data_list['activity_code'] = None
                #                 data_list['parent_sub_activity'] = None
                #                 data_list['sub_activity'] = None
                #                 data_list['sub_activity_code'] = None
                #                 data_list['sub_activity_indent'] = 0
                #                 data_list['activity_item'] = None
                #             if key == 'chainage':
                #                 data_list['chainage_code'] = data[code_row].value
                #                 data_list['activity'] = None
                #                 data_list['activity_code'] = None
                #                 data_list['parent_sub_activity'] = None
                #                 data_list['sub_activity'] = None
                #                 data_list['sub_activity_code'] = None
                #                 data_list['sub_activity_indent'] = 0
                #                 data_list['activity_item'] = None
                #             if key == 'activity':
                #                 data_list['activity_code'] = data[code_row].value
                #                 data_list['parent_sub_activity'] = None
                #                 data_list['sub_activity'] = None
                #                 data_list['sub_activity_code'] = None
                #                 data_list['sub_activity_indent'] = 0
                #                 data_list['activity_item'] = None
                #             if key == 'sub_activity':
                #                 data_list['sub_activity_code'] = data[code_row].value
                #                 data_list['activity_item'] = None
                #                 data_list['sub_activity_indent'] = int(data[entity_row].alignment.indent)
                #                 data_list['parent_sub_activity'] = None
                #                 if int(data[entity_row].alignment.indent) > 2:
                #                     idx = np.where(result['sub_activity_indent'] == int(int(data[entity_row].alignment.indent)-2), result.index, 0).max()+1
                #                     data_list['parent_sub_activity'] = result.at[idx-1, 'sub_activity']
                #     data_list['uom'] = data[uom_row].value
                #     if data_list['project']:
                #         result.loc[len(result.index)] = list(data_list.values())
                print(result)


                # result = result.replace([np.nan], [None])
                return Response(
                    {'results': {
                        'test': result.to_dict('records')
                        # 'Data': sheet_xlsx.to_dict(),
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        # except Exception as e:
        #     error_message = str(e.args[0]) if e.args else str(e)
        #     print(e)
        #     raise APIException({'request_status': 0, 'msg': error_message})


class AccountsMaterialImportAPIView(APIView):
    
    

    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {'project_budget': 0, 'project_data_add': 0, 'project_data_update': 0}
                file_name = request.data.get('file_name', None)
                field_map = request.data.get('field_map', {})
                type = request.data.get('type', 'budget')
                project_id = request.data.get('project_id', None)
                entry_date = request.data.get('entry_date', None)
                is_zero_budget = True if request.data.get('is_zero_budget', False) else False
                organization_id = self.request.query_params.get('organization_id', None)
                path = 'media/excel/' + file_name
                if not os.path.exists(path):
                    raise APIException("file not found")
                sheet_xlsx = pd.read_excel(path)
                if len(sheet_xlsx.index) == 0:
                    raise APIException("empty sheet")
                if type == 'budget':
                    all_dates = list(MaterialBudgetBreakdown.cmobjects.filter(master__project_id=project_id,is_zero_budget=is_zero_budget).values_list('entry_date',flat=True).order_by('-entry_date').distinct())
                    if all_dates:
                        if datetime.strptime(entry_date, "%Y-%m-%d").date() in all_dates and not datetime.strptime(entry_date, "%Y-%m-%d").date() == all_dates[0]:
                            raise APIException("entry date locked")
                for field in ["material_code", "item_desc", "uom_text", "qty", "rate", "amount"]:
                    field_map.setdefault(field, field)
                for column in field_map.values():
                    if not column in sheet_xlsx:
                        sheet_xlsx[column] = np.nan
                    sheet_xlsx[column] = sheet_xlsx[column].ffill(axis=0)
                # sheet_xlsx = sheet_xlsx.replace(np.nan, None)
                material_code_list = pd.DataFrame(AccountMaterialProject.cmobjects.filter(organization_id=organization_id,project_id=project_id).values('id','material_code','item_desc',))
                project_data_list = []
                if type == 'budget':
                    project_data_list = MaterialBudgetBreakdown.cmobjects.filter(master__project_id=project_id,entry_date=entry_date,is_zero_budget=is_zero_budget).values('id','qty','rate','amount','master_id',)
                else:
                    # project_data_list = MaterialConsumptionBreakdown.cmobjects.filter(master__project_id=project_id).values('id','qty','rate','amount','master_id',)
                    project_data_list = MaterialConsumptionBreakdown.cmobjects.filter(master__project_id=project_id).annotate(qty=F('consumed_qty'), rate=F('consumed_rate'), amount=F('consumed_amt')).values('id','qty','rate','amount','master_id',)
                project_data_list = pd.DataFrame(project_data_list)
                
                sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                material_code_list = material_code_list.fillna(np.nan).replace([np.nan], [None])
                project_data_list = project_data_list.fillna(np.nan).replace([np.nan], [None])
                
                def process_str(x):
                    if isinstance(x, str):
                        x = x.lower().strip().replace(' ', '')
                    return x
                
                sheet_xlsx = sheet_xlsx.applymap(lambda x: x.strip() if isinstance(x, str) else x)
                material_code_list = material_code_list.applymap(lambda x: process_str(x))
                project_data_list = project_data_list.applymap(lambda x: process_str(x))

                sheet_xlsx[field_map['qty']] = pd.to_numeric(sheet_xlsx[field_map['qty']], errors='coerce')
                sheet_xlsx[field_map['rate']] = pd.to_numeric(sheet_xlsx[field_map['rate']], errors='coerce')
                sheet_xlsx[field_map['amount']] = pd.to_numeric(sheet_xlsx[field_map['amount']], errors='coerce')

                sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                material_code_list = material_code_list.replace([np.nan], [None])
                project_data_list = project_data_list.replace([np.nan], [None])

                # print(sheet_xlsx)

                def check_material_code(row):
                    result = None
                    if 'material_code' in material_code_list and 'item_desc' in material_code_list and row[field_map['material_code']] and row[field_map['item_desc']]:
                        temp = list(material_code_list.loc[(material_code_list['material_code'].values == process_str(row[field_map['material_code']]).strip()) & (material_code_list['item_desc'].values == process_str(row[field_map['item_desc']]).strip())]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                def check_material_code_data(id):
                    result = None
                    if 'master_id' in project_data_list and id:
                        temp = list(project_data_list.loc[project_data_list['master_id'].values == id]['id'].items())
                        if len(temp) > 0:
                            result = temp[0][1]
                    return result
                sheet_xlsx['material_code_id'] = sheet_xlsx.apply(lambda row: check_material_code(row), axis=1)

                project_data_add = []
                master_id_list = []
                for index, row in sheet_xlsx.iterrows():
                    sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                    if row[field_map['material_code']]:
                        if not sheet_xlsx.at[index, 'material_code_id']:
                            # print(sheet_xlsx.at[index, 'sub_activity_id'])
                            instance = AccountMaterialProject.cmobjects.create(
                                organization_id = organization_id,
                                project_id = project_id,
                                material_code = row[field_map['material_code']],
                                item_desc = row[field_map['item_desc']],
                                uom_text = row[field_map['uom_text']],
                            )
                            sheet_xlsx['material_code_id'] = sheet_xlsx.apply(lambda row1: (instance.id if row[field_map['material_code']] and row1[field_map['material_code']] and (row[field_map['item_desc']] == row1[field_map['item_desc']]) else None) if (not row1['material_code_id']) else row1['material_code_id'], axis=1)
                            count_data['project_budget'] += 1
                        material_code_record = check_material_code_data(sheet_xlsx.at[index, 'material_code_id'])
                        # print(material_code_record)
                        if material_code_record:
                            if type == 'budget':
                                data = {
                                    'qty': row[field_map['qty']] if row[field_map['qty']] else 0,
                                    'rate': row[field_map['rate']] if row[field_map['rate']] else 0,
                                    'amount': row[field_map['amount']] if row[field_map['amount']] else 0,
                                    'is_zero_budget': is_zero_budget,
                                    'entry_date': entry_date,
                                    'master_id': sheet_xlsx.at[index, 'material_code_id'],
                                }
                                instance = MaterialBudgetBreakdown.cmobjects.filter(pk=material_code_record).update(**data)
                            else:
                                data = {
                                    'consumed_qty': row[field_map['qty']] if row[field_map['qty']] else 0,
                                    'consumed_rate': row[field_map['rate']] if row[field_map['rate']] else 0,
                                    'consumed_amt': row[field_map['amount']] if row[field_map['amount']] else 0,
                                    'entry_date': entry_date,
                                    'master_id': sheet_xlsx.at[index, 'material_code_id'],
                                }
                                instance = MaterialConsumptionBreakdown.cmobjects.filter(pk=material_code_record).update(**data)
                            count_data['project_data_update'] += 1
                        else:
                            if not sheet_xlsx.at[index, 'material_code_id'] in master_id_list:
                                if type == 'budget':
                                    data = {
                                        'qty': row[field_map['qty']] if row[field_map['qty']] else 0,
                                        'rate': row[field_map['rate']] if row[field_map['rate']] else 0,
                                        'amount': row[field_map['amount']] if row[field_map['amount']] else 0,
                                        'is_zero_budget': is_zero_budget,
                                        'entry_date': entry_date,
                                        'master_id': sheet_xlsx.at[index, 'material_code_id'],
                                    }
                                    project_data_add.append(MaterialBudgetBreakdown(**data))
                                else:
                                    data = {
                                        'consumed_qty': row[field_map['qty']] if row[field_map['qty']] else 0,
                                        'consumed_rate': row[field_map['rate']] if row[field_map['rate']] else 0,
                                        'consumed_amt': row[field_map['amount']] if row[field_map['amount']] else 0,
                                        'entry_date': entry_date,
                                        'master_id': sheet_xlsx.at[index, 'material_code_id'],
                                    }
                                    project_data_add.append(MaterialConsumptionBreakdown(**data))
                                master_id_list.append(sheet_xlsx.at[index, 'material_code_id'])
                                count_data['project_data_add'] += 1
                    # sheet_xlsx = sheet_xlsx.replace([np.nan], [None])
                
                if type == 'budget':
                    MaterialBudgetBreakdown.objects.bulk_create(project_data_add, batch_size=1000, ignore_conflicts=False)
                else:
                    MaterialConsumptionBreakdown.objects.bulk_create(project_data_add, batch_size=1000, ignore_conflicts=False)
                # sheet_xlsx = sheet_xlsx.fillna(np.nan).replace([np.nan], [None])
                # print(sheet_xlsx)
                return Response(
                    {'results': {
                        # 'Data': sheet_xlsx.to_dict(),
                        'count_data': count_data,
                    },
                        'msg': 'Successfully created',
                        'status': status.HTTP_201_CREATED,
                        "request_status": 1})
            raise APIException({'request_status': 0, 'msg': 'Something went wrong. If the problem persists, please contact support.'})
        except Exception as e:
            error_message = str(e.args[0]) if e.args else str(e)
            print(e)
            raise APIException({'request_status': 0, 'msg': error_message})


class AccountPRWCategoryAPIView(APIView):
    """
        CRUD API for model: AccountPRWCategory
    """
    
    

    def get(self, request):
        """
            Get a list AccountPRWCategory
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountPRWCategory.cmobjects.filter(id=id).first()
            serializer = AccountPRWCategorySerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = AccountPRWCategory.cmobjects.filter(*search).order_by(
            str(order_by), )
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountPRWCategorySerializer(page, many=True)

        if all == 'true':
            serializer = AccountPRWCategorySerializer(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountPRWCategory
        """

        request.data['created_by_id'] = request.user.id

        serializer = AccountPRWCategorySerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountPRWCategory
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountPRWCategory
                """
                if AccountPRWCategory.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountPRWCategory.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountPRWCategorySerializer(_details, data=request.data,
                                                                 context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountPRWCategory
                """
                if AccountPRWCategory.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountPRWCategory.cmobjects.get(pk=id, organization_id=organization_id)
                    # if AccountPRW.cmobjects.filter(category=_details).exists():
                    #     raise APIException({'request_status': 1, 'msg': "Please delete all children first!"})
                    _details.is_deleted = True
                    _details.save()
                    # # _details.delete()

                    return Response({'results': {
                        'data': AccountPRWCategory.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountPRWAPIView(APIView):
    """
        CRUD API for model: AccountPRW
    """
    
    

    def get(self, request):
        """
            Get a list AccountPRW
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountPRW.cmobjects.filter(id=id).first()
            serializer = AccountPRWSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = AccountPRW.cmobjects.filter(project__is_deleted=False, category__is_deleted=False, *search).order_by(
            str(order_by), )
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountPRWSerializer(page, many=True)

        if all == 'true':
            serializer = AccountPRWSerializer(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountPRW
        """

        request.data['created_by_id'] = request.user.id

        serializer = AccountPRWSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountPRW
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountPRW
                """
                if AccountPRW.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountPRW.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountPRWSerializer(_details, data=request.data,
                                                                 context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountPRW
                """
                if AccountPRW.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountPRW.cmobjects.get(pk=id, organization_id=organization_id)
                    # if AccountPRW.cmobjects.filter(parent=_details).exists():
                    #     raise APIException({'request_status': 0, 'msg': "Please delete all children first!"})
                    _details.is_deleted = True
                    _details.save()
                    # # _details.delete()

                    return Response({'results': {
                        'data': AccountPRW.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountPRWRatesAPIView(APIView):
    """
        CRUD API for model: AccountPRWRates
    """
    
    

    def get(self, request):
        """
            Get a list AccountPRWRates
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountPRWRates.cmobjects.filter(id=id).first()
            serializer = AccountPRWRatesSerializer(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = AccountPRWRates.cmobjects.filter(master__is_deleted=False, *search).order_by(
            str(order_by), )
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountPRWRatesSerializer(page, many=True)

        if all == 'true':
            serializer = AccountPRWRatesSerializer(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """
        Create a new AccountPRWRates
        """

        request.data['created_by_id'] = request.user.id

        serializer = AccountPRWRatesSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """
        Edit AccountPRWRates
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update AccountPRWRates
                """
                if AccountPRWRates.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountPRWRates.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = AccountPRWRatesSerializer(_details, data=request.data,
                                                                 context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete AccountPRWRates
                """
                if AccountPRWRates.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountPRWRates.cmobjects.get(pk=id, organization_id=organization_id)
                    _details.is_deleted = True
                    _details.save()
                    # # _details.delete()

                    return Response({'results': {
                        'data': AccountPRWRates.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


class AccountPRWCategorySummaryAPIView(APIView):
    """
        CRUD API for model: AccountPRWCategory Summary
    """
    
    

    def get(self, request):
        """
            Get a list AccountPRWCategory
        """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountPRWCategory.cmobjects.filter(id=id).first()
            serializer = AccountPRWCategorySerializer2(_details)
            return Response(serializer.data)

        search = {}
        search = custom_filters(self.request, search, ['hideLoader'])

        _list = (AccountPRWCategory.cmobjects.
                 prefetch_related('account_prw_category', 'account_prw_category__account_prw_rates').
                 filter(*search).
                 order_by(*str(order_by).split(",")))

        # print('query', _list.query)
        # print(f"{'*'*20}")

        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountPRWCategorySerializer2(page, many=True)

        if all == 'true':
            serializer = AccountPRWCategorySerializer2(_list, many=True)
            return Response({'results': serializer.data})

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })


class AccountPRWCategorySummary2APIView(APIView):
    """
        CRUD API for model: AccountPRWCategory Summary
    """
    
    

    def get(self, request):
        """
            Get a list AccountPRWCategory
        """
        project_id = self.request.query_params.get('project', None)
        category_order_by = self.request.query_params.get('category_order_by', '-id')
        item_order_by = self.request.query_params.get('item_order_by', '-id')
        rates_order_by = self.request.query_params.get('rates_order_by', '-id')

        prw_category_list = pd.DataFrame(AccountPRWCategory.cmobjects.filter(project_id=project_id).values('id', 'name').order_by(str(category_order_by),))
        account_prw_details = pd.DataFrame(AccountPRW.cmobjects.filter(project_id=project_id,category__is_deleted=False).values('id', 'category', 'project', 'uom_text', 'item', 'parent').order_by(str(item_order_by),))
        rates_list = pd.DataFrame(AccountPRWRates.cmobjects.filter(master__project_id=project_id,master__is_deleted=False,master__category__is_deleted=False).values('id', 'master', 'rate', 'entry_date').order_by(str(rates_order_by),))

        prw_category_list = prw_category_list.fillna(np.nan).replace([np.nan], [None])
        account_prw_details = account_prw_details.fillna(np.nan).replace([np.nan], [None])
        rates_list = rates_list.fillna(np.nan).replace([np.nan], [None])

        account_prw_details['rates_details'] = account_prw_details.apply(
            lambda row: rates_list[rates_list['master'].values == row['id']].to_dict(
                'records') if 'master' in rates_list else [], axis=1)

        prw_category_list['account_prw_details'] = prw_category_list.apply(
            lambda row: account_prw_details[account_prw_details['category'].values == row['id']].to_dict(
                'records') if 'category' in account_prw_details else [], axis=1)
        prw_category_list = prw_category_list.replace([np.nan], [None])

        return Response({
            'results': prw_category_list.to_dict('records'),
            'entry_date_list': sorted(rates_list['entry_date'].unique()) if 'entry_date' in rates_list else [],
            'max_rates_entry_date_project': max(rates_list['entry_date']) if 'entry_date' in rates_list else "",
        })


class AccountPRWRatesBulkAPIView(APIView):
    """
        CRUD API for model: AccountPRWRates bulk
    """
    
    

    def post(self, request):
        """
        Create a new AccountPRWRates bulk
        """

        res = {'add':0,'edit':0}
        try:
            with transaction.atomic():
                if isinstance(request.data, list):
                    for i in request.data:
                        if 'id' in i:
                            instance = AccountPRWRates.objects.filter(pk=i['id']).update(**i)
                            res['edit'] += 1
                        else:
                            instance = AccountPRWRates.objects.create(**i)
                            res['add'] += 1
        except Exception as e:
            print('ERROR', e)
            raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})

        return Response(
            {'results': {
                'data': res,
            },
                'msg': 'Successfully created',
                'status': status.HTTP_201_CREATED,
                "request_status": 1})

class AccountChainageDuplicateAPIView(APIView):
    
    

    def get(self, request):
        x = {
            'AccountChainageMaster': ['project', 'id', 'name', 'code'],
            'AccountActivityMaster': ['chainage', 'id', 'name', 'code', 'chainage__project'],
            'AccountSubActivityMaster': ['activity', 'id', 'name', 'parent', 'code', 'activity__chainage', 'activity__chainage__name', 'activity__chainage__project'],
            'AccountProjectBudget': ['sub_activity_master', 'id', 'activity', 'code', 'sub_activity_master__activity', 'sub_activity_master__activity__name', 'sub_activity_master__activity__chainage', 'sub_activity_master__activity__chainage__name', 'sub_activity_master__activity__chainage__project'],
            'BudgetBreakdown': ['master', 'id', 'entry_date', 'qty', 'rate', 'amount', 'is_zero_budget'],
            'AccountConsumptionBreakdown': ['master', 'id', 'master', 'qty', 'rate', 'amount'],
        }

        resp = {}
        for index, row in x.items():
            model = globals()[index]
            df = pd.DataFrame(model.cmobjects.values(*row, trimmed_name = Func(Func(F(row[2]), Value(' '), Value(''), output_field=CharField(), function='REPLACE'), output_field=CharField(), function='LOWER')).order_by(row[0],'trimmed_name',row[1]))
            temp = df[df[[row[0], 'trimmed_name']].duplicated(keep=False) == True]
            temp = temp.fillna(np.nan).replace([np.nan], [None])
            resp[index] = temp.to_dict('records')
 
        return Response(resp)


class AccountIndirectCostDPRAPI(APIView):
    """
    AccountIndirectCostDPR CURD API
    """
    
    

    def get(self, request):
        """ Get a list of all AccountIndirectCostDPR """

        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        if id:
            _details = AccountIndirectCostDPR.cmobjects.filter(id=id).first()
            serializer = AccountIndirectCostDPRSerializer(_details)
            return Response(serializer.data)
        search = custom_filters(self.request, {}, [])

        _list = AccountIndirectCostDPR.cmobjects.filter(*search).order_by(*str(order_by).split(","))
        if all == 'true':
            serializer = AccountIndirectCostDPRSerializer(_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = AccountIndirectCostDPRSerializer(page, many=True)

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request):
        """ Create a new AccountIndirectCostDPR """
        request.data['created_by'] = request.user.id
        serializer = AccountIndirectCostDPRSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': str(e.args[0]) if e.args else str(e)})
            return Response(
                {'results': {
                    'data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request):
        """ Edit a AccountIndirectCostDPR """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """ Update """
                if AccountIndirectCostDPR.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    _details = AccountIndirectCostDPR.cmobjects.filter(pk=id).first()

                    request.data['updated_by'] = request.user.id
                    serializer = AccountIndirectCostDPRSerializer(_details, data=request.data,
                                                                  context={'request': request})

                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """ Delete """
                if AccountIndirectCostDPR.cmobjects.filter(pk=id, organization_id=organization_id).exists():

                    _details = AccountIndirectCostDPR.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    _details.is_deleted = True
                    _details.updated_by = request.user
                    _details.save()

                    return Response({'results': {
                        'data': AccountIndirectCostDPR.objects.filter(pk=id,
                                                                        organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})


               

class BudgetConsumptionReport(APIView):
    
    

    def get(self, request):
        """ Get a list of all AccountIndirectCostDPR """
        base = {
            "material": {
                "budget": "MaterialBudgetBreakdown",
                "budget_amount": "amount",
                "consumption": "MaterialConsumptionBreakdown",
                "consumption_amount": "consumed_amt",
            },
            "activity": {
                "budget": "BudgetBreakdown",
                "budget_amount": "amount",
                "consumption": "AccountConsumptionBreakdown",
                "consumption_amount": "amount",
            },
        }
        project_id = self.request.query_params.get('project_id', None)
        type = self.request.query_params.get('type', 'material')
        budget = globals()[base[type]['budget']]
        consumption = globals()[base[type]['consumption']]
        data = {}
        search = custom_filters(self.request, {}, ['type','project_id'])
        project_list = ProjectMaster.cmobjects.annotate(
            project_name_from_project_data=Subquery(
                ProjectData.cmobjects.filter(
                    project_id=OuterRef('pk'),
                    form__form_internal_name='project_name'
                ).values('project').annotate(value=GroupConcat('value')).values('value')
            ),
            project_code_from_project_data=Subquery(
                ProjectData.cmobjects.filter(
                    project_id=OuterRef('pk'),
                    form__form_internal_name='project_id'
                ).values('project').annotate(value=GroupConcat('value')).values('value')
            ),
        ).filter(users__in=[request.user])
        if project_id:
            project_list = project_list.filter(id=project_id)
        overrun_count = 0
        for project in project_list:

            latest_date = budget.cmobjects.filter(*search).aggregate(latest_entry_date=Max('entry_date'))['latest_entry_date']

            budgeted_amount = budget.cmobjects.filter(master__project=project, entry_date =latest_date).aggregate(final_amount=Sum(base[type]['budget_amount']))['final_amount'] or 0

            consumption_amount = consumption.cmobjects.filter(master__project=project).aggregate(final_amount=Sum(base[type]['consumption_amount']))['final_amount'] or 0

            remainder = budgeted_amount - consumption_amount
            if remainder < 0:
                overrun_count +=1

            data[project.id] = {
                'latest_date': latest_date,
                'project_id': project.id,
                'project_name': project.project_name_from_project_data,
                'project_code': project.project_code_from_project_data,
                'budgeted_amount': budgeted_amount,
                'consumption': consumption_amount,
                'remainder': remainder
            }


        return Response({
            'results': data,
            'total_count': len(data),
            'overrun_count': overrun_count,
        })
