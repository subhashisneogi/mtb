from django.core.exceptions import ValidationError, NON_FIELD_ERRORS
from django.conf import settings
from django.db import models
from administrations.models import BaseAbstractStructure, Organization, PmsUser
from boq.models import WbsIndirectCostPlaning
from material_master.models import VendorMaterialMaster, UnitOfMesurement
from procurement.models import FinancialYear
from project_and_planning.models import ProjectMaster


class AccountProjectCostMaster(BaseAbstractStructure):
    ordering = models.IntegerField(default=0)
    organization = models.ForeignKey(Organization, related_name='account_cost_master_organization', on_delete=models.CASCADE)
    name = models.CharField(max_length=200, default='')
    level = models.IntegerField(default=0)
    parent = models.ForeignKey('self', related_name='account_cost_master_parent', on_delete=models.CASCADE,
                               null=True, blank=True)

    class Meta:
        db_table = "account_cost_master"
        # ordering = ('-id',)
        verbose_name_plural = "5.a Account Project CostMasters"


class AccountChainageMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_chainage_master_organization', on_delete=models.CASCADE, blank=True, null=True)
    name = models.CharField(max_length=200, blank=True, null=True)
    ordering = models.IntegerField(default=0)
    code = models.CharField(max_length=100, blank=True, null=True)
    project = models.ForeignKey(ProjectMaster, related_name='account_chainage_master_project', on_delete=models.CASCADE)

    def __str__(self):
        return str(self.name) + " ( " + str(self.code) + " )"
    class Meta:
        # ordering = ('name',)
        verbose_name_plural = "5.b Account Chainage Masters"
        db_table = "account_chainage_master"


class AccountActivityMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_activity_master_organization', on_delete=models.CASCADE, blank=True, null=True)
    name = models.CharField(max_length=200, blank=True, null=True)
    ordering = models.IntegerField(default=0)
    code = models.CharField(max_length=100, blank=True, null=True)
    chainage = models.ForeignKey(AccountChainageMaster, related_name='account_activity_master_chainage', blank=True, null=True, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.name) + " ( " + str(self.code) + " )"
    class Meta:
        # ordering = ('name',)
        verbose_name_plural = "5.c Account Activity Masters"
        db_table = "account_activity_master"


class AccountSubActivityMaster(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_sub_activity_master_organization', on_delete=models.CASCADE, blank=True, null=True)
    name = models.CharField(max_length=200, blank=True, null=True)
    ordering = models.IntegerField(default=0)
    code = models.CharField(max_length=100, blank=True, null=True)
    activity = models.ForeignKey(AccountActivityMaster, related_name='account_sub_activity_master_activity', blank=True, null=True, on_delete=models.CASCADE)

    parent = models.ForeignKey('self', related_name='account_sub_activity_master_parent', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return str(self.name) + " ( " + str(self.code) + " )"
    class Meta:
        # ordering = ('name',)
        verbose_name_plural = "5.d Account Sub Activity Masters"
        db_table = "account_sub_activity_master"



class AccountProjectBudgetGroup(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='account_project_budget_grp_organization', on_delete=models.CASCADE, blank=True, null=True)
    project = models.ForeignKey(ProjectMaster, related_name='account_project_budget_grp_project', on_delete=models.CASCADE)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)

    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")

    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_project_budget_grp_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_project_budget_grp_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_project_budget_grp_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_project_budget_grp_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_project_budget_grp_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "account_project_budget_grp"
        verbose_name_plural = "1. Account Project Budgets Group"


class AccountProjectBudget(BaseAbstractStructure):
    ordering = models.IntegerField(default=0)
    tab_count = models.IntegerField(default=0)
    is_visible = models.BooleanField(default=True, blank=True, null=True)

    organization = models.ForeignKey(Organization, related_name='account_project_budget_organization', on_delete=models.CASCADE)

    group = models.ForeignKey(AccountProjectBudgetGroup, related_name='account_project_budget_group', on_delete=models.CASCADE,
                               null=True, blank=True)

    activity = models.CharField(max_length=200, blank=True, null=True, default="")
    activity_group = models.CharField(max_length=200, blank=True, null=True, default="")
    is_header = models.BooleanField(default=False)
    code = models.CharField(max_length=200, blank=True, null=True)
    parent = models.ForeignKey('self', related_name='account_project_budget_parent', on_delete=models.CASCADE,
                               null=True, blank=True)

    material = models.ForeignKey(VendorMaterialMaster, related_name='account_project_budget_material', on_delete=models.CASCADE, blank=True, null=True) # niu
    project = models.ForeignKey(ProjectMaster, related_name='account_project_budget_project', on_delete=models.CASCADE)

    sub_activity_master = models.ForeignKey(AccountSubActivityMaster, related_name='account_project_budget_sub_activity_master', on_delete=models.CASCADE, blank=True, null=True)
    # activity_master = models.ForeignKey(AccountActivityMaster, related_name='+', on_delete=models.CASCADE, blank=True, null=True)
    # chainage_master = models.ForeignKey(AccountChainageMaster, related_name='+', on_delete=models.CASCADE, blank=True, null=True)

    chainage_no = models.IntegerField(default=0)
    chainage_text = models.CharField(max_length=20, null=True, blank=True)

    qty_left = models.FloatField(blank=True, null=True, default=0.)
    budget_left = models.FloatField(blank=True, null=True, default=0.)

    uom = models.ForeignKey(UnitOfMesurement, related_name='account_project_budget_uom', on_delete=models.CASCADE, blank=True, null=True)
    uom_txt = models.CharField(max_length=200, blank=True, null=True)


    entry_date = models.DateField(blank=True, null=True)
    version = models.IntegerField(default=1, blank=True, null=True)
    financialyear = models.ForeignKey(FinancialYear, related_name='account_project_budget_financial_year', on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return str(self.activity)
    class Meta:
        # unique_together = ('organization', 'financialyear', 'project', 'chainage_no',  'entry_date', 'activity', 'activity_group', 'ordering')
        db_table = "account_project_budget"
        verbose_name_plural = "2. Account Project Budgets"
        # ordering = ('ordering',)


class BudgetBreakdown(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_budget_breakdown_organization', on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(AccountProjectBudget, related_name='account_budget_breakdown', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='account_budget_breakdown_project', on_delete=models.CASCADE,)
    qty = models.FloatField(blank=True, null=True, default=0.)
    rate = models.FloatField(blank=True, null=True, default=0.)
    amount = models.FloatField(blank=True, null=True, default=0.)
    entry_date = models.DateField(null=True, blank=True)
    is_zero_budget = models.BooleanField(default=False)

    # def validate_unique(self, *args, **kwargs):
    #     super(BudgetBreakdown, self).validate_unique(*args, **kwargs)
    #
    #     qs = self.__class__._default_manager.filter(
    #         master__entry_date__gte=self.entry_date,
    #         is_deleted=False,
    #         master__is_deleted=False
    #     )
    #
    #     if not self._state.adding and self.pk is not None:
    #         qs = qs.exclude(pk=self.pk)
    #
    #     if qs.exists():
    #         raise ValidationError({
    #             NON_FIELD_ERRORS: ['entry_date should be grater'],
    #         })

    def clean(self, *args, **kwargs):
        # custom validation here
        super().clean(*args, **kwargs)

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    class Meta:
        db_table = "account_budget_breakdown"
        # unique_together = ('project', 'master', 'entry_date')
        verbose_name_plural = "3. Budget Breakdowns"


class AccountConsumptionBreakdown(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_consumption_breakdown_organization', on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(AccountProjectBudget, related_name='account_consumption_breakdown', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='account_consumption_breakdown_project', on_delete=models.CASCADE,)
    qty = models.FloatField(blank=True, null=True, default=0.)
    rate = models.FloatField(blank=True, null=True, default=0.)
    amount = models.FloatField(blank=True, null=True, default=0.)
    entry_date = models.DateField(null=True, blank=True)

    class Meta:
        db_table = "account_consumption_breakdown"
        # unique_together = ('project', 'entry_date')
        verbose_name_plural = "4. Account Consumption Breakdown"



# material

class AccountMaterialProjectGroup(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='account_material_project_grp_organization', on_delete=models.CASCADE, blank=True, null=True)
    project = models.ForeignKey(ProjectMaster, related_name='account_material_project_grp_project', on_delete=models.CASCADE)

    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)

    # state
    is_send_for_checked = models.BooleanField(default=False)


    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_grp_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_grp_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_grp_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_grp_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_grp_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    class Meta:
        db_table = "account_material_project_grp"
        verbose_name_plural = "6. Account Material Projects Group"


class AccountMaterialProject(BaseAbstractStructure):
    APPROVE_STATUS = (
        ('pending', 'Pending'),
        ('checked', 'Checked'),
        ('cancelled', 'Cancelled'),
        ('close', 'Close'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    organization = models.ForeignKey(Organization, related_name='account_material_project_organization', on_delete=models.CASCADE, blank=True, null=True)
    material = models.ForeignKey(VendorMaterialMaster, related_name='account_material_project_material', blank=True, null=True, on_delete=models.CASCADE)

    group = models.ForeignKey(AccountMaterialProjectGroup, related_name='account_material_project_grp', blank=True, null=True, on_delete=models.CASCADE)

    project = models.ForeignKey(ProjectMaster, related_name='account_material_project_project', on_delete=models.CASCADE)
    material_code = models.CharField(max_length=100, blank=True, null=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='account_material_project_uom', blank=True, null=True, on_delete=models.CASCADE)
    uom_text = models.CharField(max_length=100, blank=True, null=True)
    item_desc = models.CharField(max_length=100, blank=True, null=True)

    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)

    qty_left = models.FloatField(null=True, blank=True, default=0.)
    budget_left = models.FloatField(null=True, blank=True, default=0.)

    ordering = models.IntegerField(default=0)

    status = models.CharField(max_length=100, choices=APPROVE_STATUS, blank=True, null=True, default="pending")
    # for APPROVED STATUS user
    checked_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_checked_by", on_delete=models.CASCADE)
    cancelled_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_cancelled_by", on_delete=models.CASCADE)
    close_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_close_by", on_delete=models.CASCADE)
    approved_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_approved_by", on_delete=models.CASCADE)
    rejected_by = models.ForeignKey(PmsUser, blank=True, null=True, related_name="account_material_project_rejected_by", on_delete=models.CASCADE)
    # ts
    checked_by_date = models.DateTimeField(blank=True, null=True, )
    cancelled_by_date = models.DateTimeField(blank=True, null=True, )
    close_by_date = models.DateTimeField(blank=True, null=True, )
    approved_by_date = models.DateTimeField(blank=True, null=True, )
    rejected_by_date = models.DateTimeField(blank=True, null=True, )

    def __str__(self):
        return str(self.id) + ' ' + str(self.material_code)

    class Meta:
        db_table = "account_material_project"
        # ordering = ('entry_date', 'id')
        verbose_name_plural = "7. Account Material Projects"


class MaterialBudgetBreakdown(BaseAbstractStructure):
    master = models.ForeignKey(AccountMaterialProject, related_name='account_material_budget_breakdown', on_delete=models.CASCADE, null=True, blank=True)
    material_code=models.CharField(max_length=100, blank=True, null=True)
    qty = models.FloatField(blank=True, null=True, default=0.)
    rate = models.FloatField(blank=True, null=True, default=0.)
    amount = models.FloatField(blank=True, null=True, default=0.)
    entry_date = models.DateField(null=True, blank=True)
    is_zero_budget = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.rate:
            self.rate = 0
        if not self.qty:
            self.qty = 0
        self.amount = float(self.rate) * float(self.qty)
        super().save(*args, **kwargs)

    def __str__(self):
        return str(self.id)+" ("+str(self.entry_date)+" | "+str(self.is_zero_budget)+") "+str(self.qty)+" * "+str(self.rate)+" = "+str(self.amount)


    class Meta:
        db_table = "account_material_budget_breakdown"
        ordering = ('entry_date', 'id')
        verbose_name_plural = "8. Material Budget Breakdown"


class MaterialConsumptionBreakdown(BaseAbstractStructure):
    master = models.ForeignKey(AccountMaterialProject, related_name='account_mat_consumption_breakdown', on_delete=models.CASCADE, null=True, blank=True)
    material_code = models.CharField(max_length=100, blank=True, null=True)
    consumed_qty = models.FloatField(default=0.0)
    consumed_rate = models.FloatField(default=0.0)
    consumed_amt = models.FloatField(default=0.0)
    entry_date = models.DateField(null=True, blank=True)

    def save(self, *args, **kwargs):
        self.full_clean()
        if not self.consumed_rate:
            self.consumed_rate = 0
        if not self.consumed_qty:
            self.consumed_qty = 0
        self.consumed_amt = float(self.consumed_rate) * float(self.consumed_qty)
        super().save(*args, **kwargs)

    class Meta:
        db_table = "account_mat_consumption_breakdown"
        # ordering = ('entry_date', 'id')
        verbose_name_plural = "9. Material Consumption Breakdowns"


class AccountPRWCategory(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_prw_category_organization', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='account_prw_category_project', on_delete=models.CASCADE, )
    name = models.CharField(max_length=200, blank=True, null=True, default="")
    ordering = models.IntegerField(default=0)
    is_visible = models.BooleanField(default=True, blank=True, null=True)

    class Meta:
        db_table = "account_prw_category"


class AccountPRW(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_prw_organization', on_delete=models.CASCADE, null=True, blank=True)
    category = models.ForeignKey(AccountPRWCategory, related_name='account_prw_category', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='account_prw_project', on_delete=models.CASCADE,)
    parent = models.ForeignKey('self', related_name='account_prw_parent', on_delete=models.CASCADE, null=True, blank=True)
    item = models.TextField(max_length=1000, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMesurement, related_name='account_prw_uom', blank=True, null=True, on_delete=models.CASCADE)
    uom_text = models.CharField(max_length=100, blank=True, null=True)
    ordering = models.IntegerField(default=0)
    is_visible = models.BooleanField(default=True, blank=True, null=True)

    class Meta:
        db_table = "account_prw"


class AccountPRWRates(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_prw_rates_organization', on_delete=models.CASCADE, null=True, blank=True)
    master = models.ForeignKey(AccountPRW, related_name='account_prw_rates', on_delete=models.CASCADE, null=True, blank=True)
    rate = models.FloatField(blank=True, null=True, default=0.)
    entry_date = models.DateField(null=True, blank=True)

    class Meta:
        db_table = "account_prw_rates"


# Indirect Cost Daily Progress Report)
class AccountIndirectCostDPR(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='account_indirect_cost_dpr_organization', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(ProjectMaster, related_name='account_indirect_cost_dpr_project', on_delete=models.CASCADE, null=True, blank=True)
    indirect_cost = models.ForeignKey(WbsIndirectCostPlaning, related_name='account_indirect_cost_dpr', on_delete=models.CASCADE, null=True, blank=True)
    # name = models.CharField(max_length=100, blank=True, null=True)
    purpose = models.CharField(max_length=200, blank=True, null=True)
    date = models.DateField(blank=True, null=True)

    class Meta:
        db_table = "account_indirect_cost_dpr"

