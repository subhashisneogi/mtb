import colorama
from django.db import transaction
from rest_framework import serializers
from rest_framework.exceptions import APIException

from accounts.models import *
from boq.serializers import WbsIndirectCostPlaningSerializer


class CommonFilterListSerializer(serializers.ListSerializer):
    """
    ListSerializer
    cmobject: is_deleted=False
    """
    def to_representation(self, data):
        data = data.filter(is_deleted=False)
        return super(CommonFilterListSerializer, self).to_representation(data)


class AccountProjectCostMasterSerializer(serializers.ModelSerializer):
    """
    AccountProjectCostMaster Serializer
    """
    class Meta:
        model = AccountProjectCostMaster
        fields = '__all__'


class AccountChainageMasterSerializer(serializers.ModelSerializer):
    """
    AccountChainageMaster Serializer
    """
    class Meta:
        model = AccountChainageMaster
        fields = '__all__'


class AccountActivityMasterSerializer(serializers.ModelSerializer):
    """
    AccountActivityMaster Serializer
    """
    class Meta:
        model = AccountActivityMaster
        fields = '__all__'


class AccountSubActivityMasterSerializer(serializers.ModelSerializer):
    """
    AccountSubActivityMaster Serializer
    """

    children_details = serializers.SerializerMethodField()

    def get_children_details(self, instance):

        def children_details_rec(_id, depth):
            __details = []
            _instance = AccountSubActivityMaster.cmobjects.filter(pk=_id).first()
            __details = AccountSubActivityMaster.cmobjects.filter(parent=_instance).values()
            if __details and depth > 0:
                for _i in __details:
                    _i.update({'children_details': children_details_rec(_i['id'], depth-1)})
            return __details

        _details = []
        if instance:
            _details = AccountSubActivityMaster.cmobjects.filter(parent=instance).values()
            for i in _details:
                i.update({'children_details': children_details_rec(i['id'], 2)})
        return _details

    class Meta:
        model = AccountSubActivityMaster
        fields = '__all__'






class BudgetBreakdownSerializer(serializers.ModelSerializer):
    """
    BudgetActivity Serializer
    """
    entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])

    class Meta:
        model = BudgetBreakdown
        fields = '__all__'
        read_only_fields = ['id']

class BudgetBreakdownSerializer2(serializers.ModelSerializer):
    """
    BudgetActivity Serializer
    """

    entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])

    id = serializers.IntegerField(required=False)
    class Meta:
        model = BudgetBreakdown
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class AccountConsumptionBreakdownSerializer(serializers.ModelSerializer):
    """
    AccountConsumptionBreakdown Serializer
    """

    entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])

    id = serializers.IntegerField(required=False)
    class Meta:
        model = AccountConsumptionBreakdown
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class AccountProjectBudgetSerializer(serializers.ModelSerializer):
    """
    AccountProjectBudget Serializer
    """
    entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])

    budget_breakdown = BudgetBreakdownSerializer2(many=True, required=False, source="account_budget_breakdown")
    consumption_breakdown = AccountConsumptionBreakdownSerializer(many=True, required=False, source="account_consumption_breakdown")

    def calculation(self, instance: AccountProjectBudget):
        # print('calculation...')
        instance.qty_left = 0.
        instance.budget_left = 0.

        # 1. qty_left, budget_left
        last_budget = instance.account_budget_breakdown.filter(is_deleted=False,is_zero_budget=False).order_by('-entry_date').first()
        # print('last_budget', last_budget)
        last_consumption = instance.account_consumption_breakdown.filter(is_deleted=False).order_by('-entry_date').first()
        # print('last_consumption', last_consumption)
        if last_budget and last_consumption:
            instance.qty_left = round((last_budget.qty - last_consumption.qty), 4)
            instance.budget_left = round((last_budget.amount - last_consumption.amount), 4)
        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        budget_breakdown_items = validated_data.pop('account_budget_breakdown', [])
        consumption_breakdown_items = validated_data.pop('account_consumption_breakdown', [])

        # create grp if not exists
        # print('validated_data project', validated_data['project'])
        project = validated_data['project']
        start_date = validated_data['entry_date']
        organization = validated_data['organization']
        if not AccountProjectBudgetGroup.cmobjects.filter(project=project).exists():
            grp = AccountProjectBudgetGroup.objects.create(project=project, start_date=start_date, organization=organization)
        else:
            grp = AccountProjectBudgetGroup.cmobjects.filter(project=project).first()

        instance = AccountProjectBudget.objects.create(group=grp, **validated_data)

        # insert items ✅
        _items = None
        for item in budget_breakdown_items:
            [item.pop(k, None) for k in
             ('organization', 'created_by', 'master', 'id',)]

            _items = BudgetBreakdown.objects.create(
                organization=instance.organization,
                created_by=instance.created_by,
                master=instance,
                **item
            )
        self.calculation(instance)

        # insert consumption items ✅
        _items = None
        for item in consumption_breakdown_items:
            [item.pop(k, None) for k in
             ('organization', 'created_by', 'master', 'id',)]

            _items = AccountConsumptionBreakdown.objects.create(
                organization=instance.organization,
                created_by=instance.created_by,
                master=instance,
                **item
            )
        self.calculation(instance)

        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        budget_breakdown_items = validated_data.pop('account_budget_breakdown', [])
        consumption_breakdown_items = validated_data.pop('account_consumption_breakdown', [])

        for key, value in validated_data.items():
            setattr(instance, key, value)

        # update/insert BudgetBreakdown ✅
        old_item_ids = [item.pk for item in instance.account_budget_breakdown.filter(is_deleted=False)]
        updated_item_ids = []
        for item in budget_breakdown_items:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': instance.updated_by},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = BudgetBreakdown.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                _obj, created = BudgetBreakdown.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")

            updated_item_ids.append(id)
        # soft remove excluded items
        # excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        # _ = BudgetBreakdown.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
        #                                                                         updated_by=instance.updated_by)
        # print('deleted BudgetBreakdown', _)
        self.calculation(instance)




        # update/insert AccountConsumptionBreakdown ✅
        old_item_ids = [item.pk for item in instance.account_consumption_breakdown.filter(is_deleted=False)]
        updated_item_ids = []
        for item in consumption_breakdown_items:
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'organization': instance.organization},
                                        {'updated_by': instance.updated_by},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = AccountConsumptionBreakdown.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                _obj, created = AccountConsumptionBreakdown.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")

            updated_item_ids.append(id)
        # soft remove excluded items
        # excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        # _ = AccountConsumptionBreakdown.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
        #                                                                     updated_by=instance.updated_by)
        # print('deleted AccountConsumptionBreakdown', _)
        self.calculation(instance)

        instance.save()
        return instance


    # method fields
    # budget_breakdown_details = serializers.SerializerMethodField()
    # def get_budget_breakdown_details(self, instance):
    #     _details = []
    #     if instance:
    #         _details = BudgetBreakdown.cmobjects.filter(master=instance).values()
    #     return _details


    class Meta:
        model = AccountProjectBudget
        fields = '__all__'


class MaterialBudgetBreakdownSerializer(serializers.ModelSerializer):
    """
    MaterialBudgetBreakdownSerializer Serializer
    """
    entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])

    id = serializers.IntegerField(required=False)
    class Meta:
        model = MaterialBudgetBreakdown
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class MaterialBudgetBreakdownSerializer2(serializers.ModelSerializer):
    """
    MaterialBudgetBreakdownSerializer Serializer
    """
    entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])
    class Meta:
        model = MaterialBudgetBreakdown
        fields = '__all__'
        read_only_fields = ['id']

class MaterialConsumptionBreakdownSerializer(serializers.ModelSerializer):
    """
    MaterialConsumptionBreakdownSerializer Serializer
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = MaterialConsumptionBreakdown
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer


class MaterialConsumptionBreakdownSerializer2(serializers.ModelSerializer):
    """
    MaterialConsumptionBreakdownSerializer Serializer
    """
    class Meta:
        model = MaterialConsumptionBreakdown
        fields = '__all__'
        read_only_fields = ['id']


class AccountMaterialProjectGroupSerializer(serializers.ModelSerializer):
    """
    AccountMaterialProjectGroup  Serializer
    """

    start_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])
    end_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'], required=False)
    class Meta:
        model = AccountMaterialProjectGroup
        fields = '__all__'
        # read_only_fields = ['id']


class AccountMaterialProjectSerializer(serializers.ModelSerializer):
    """
    AccountProjectBudget Serializer
    """
    start_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'])
    end_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'], required=False)


    breakdown = MaterialBudgetBreakdownSerializer(many=True, required=False, source="account_material_budget_breakdown")
    consumption_breakdown = MaterialConsumptionBreakdownSerializer(many=True, required=False, source="account_mat_consumption_breakdown")


    def calculation(self, instance: AccountMaterialProject):
        # print('calculation...')
        instance.qty_left = 0.
        instance.budget_left = 0.

        # 1. qty_left, budget_left
        last_budget = instance.account_material_budget_breakdown.filter(is_deleted=False).last()
        # print('last_budget', last_budget)
        last_consumption = instance.account_mat_consumption_breakdown.filter(is_deleted=False).last()
        # print('last_consumption', last_consumption)
        if last_budget and last_consumption:
            instance.qty_left = (last_budget.qty - last_consumption.consumed_qty)
            instance.budget_left = (last_budget.amount - last_consumption.consumed_amt)

        instance.save()

    @transaction.atomic
    def create(self, validated_data):
        breakdown_items = validated_data.pop('account_material_budget_breakdown', [])
        consumption_breakdown_items = validated_data.pop('account_mat_consumption_breakdown', [])

        # create grp if not exists
        print('validated_data project', validated_data['project'])
        project = validated_data['project']
        start_date = validated_data['start_date']
        if not AccountMaterialProjectGroup.cmobjects.filter(project=project).exists():
            grp = AccountMaterialProjectGroup.objects.create(project=project, start_date=start_date)
        else:
            grp = AccountMaterialProjectGroup.cmobjects.filter(project=project).first()

        instance = AccountMaterialProject.objects.create(group=grp, **validated_data)

        # insert items ✅
        _items = None
        for item in breakdown_items:
            [item.pop(k, None) for k in
             ('created_by', 'master', 'id', 'material_code')]
            # print('master', instance)
            _items = MaterialBudgetBreakdown.objects.create(
                created_by=instance.created_by,
                material_code=instance.material_code,
                master=instance,
                **item
            )
        self.calculation(instance)

        # insert items ✅
        _items = None
        for item in consumption_breakdown_items:
            [item.pop(k, None) for k in
             ('created_by', 'master', 'id', 'material_code')]
            # print('master', instance)
            _items = MaterialConsumptionBreakdown.objects.create(
                created_by=instance.created_by,
                material_code=instance.material_code,
                master=instance,
                **item
            )
        self.calculation(instance)

        instance.save()
        return instance

    @transaction.atomic
    def update(self, instance, validated_data):
        breakdown_items = validated_data.pop('account_material_budget_breakdown', [])
        consumption_breakdown_items = validated_data.pop('account_mat_consumption_breakdown', [])

        # print('breakdown_items',  breakdown_items)
        for key, value in validated_data.items():
            setattr(instance, key, value)

        # update/insert MaterialBudgetBreakdown ✅
        old_item_ids = [item.pk for item in instance.account_material_budget_breakdown.filter(is_deleted=False)]
        updated_item_ids = []
        for item in breakdown_items:
            # print(colorama.Back.GREEN, 'item', item, colorama.Style.RESET_ALL)
            id = item.pop('id', None)
            [item.update(kv) for kv in ({'updated_by': instance.updated_by},
                                        {'material_code': instance.material_code},
                                        {'is_deleted': False},
                                        {'master': instance},)]

            if not id:
                _obj = MaterialBudgetBreakdown.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                _obj = MaterialBudgetBreakdown.objects.filter(pk=id).update(**item)
                print(f"item update {id} {50 * '*'}")


            updated_item_ids.append(id)
        # soft remove excluded items
        # excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        # _ = MaterialBudgetBreakdown.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True, updated_by=instance.updated_by)
        # print('deleted MaterialBudgetBreakdown', _)
        # end update/insert MaterialBudgetBreakdown
        self.calculation(instance)






        ''' 1.  update/insert Items ✅ '''
        old_item_ids = [item.pk for item in instance.account_mat_consumption_breakdown.filter(is_deleted=False)]
        updated_item_ids = []
        for item in consumption_breakdown_items:
            id = item.pop('id', None)
            [item.update(kv) for kv in (
                                        {'updated_by': instance.updated_by},
                                        {'is_deleted': False},
                                        {'master': instance},)]
            if not id:
                _obj = MaterialConsumptionBreakdown.objects.create(**item)
                id = _obj.pk
                print(f"item added {_obj.pk} {50 * '*'} ")
            else:
                _obj, created = MaterialConsumptionBreakdown.objects.update_or_create(pk=id, defaults=item)
                print(f"item update {id} {50 * '*'}")
            # update_item_notes_generic2('MaterialConsumptionBreakdownNotes', item_notes, updated_by=instance.updated_by, master=_obj)
            updated_item_ids.append(id)
        # soft remove excluded items
        excluded_item_ids = list(set(old_item_ids) - set(updated_item_ids))
        _ = MaterialConsumptionBreakdown.objects.filter(pk__in=excluded_item_ids).update(is_deleted=True,
                                                                                 updated_by=instance.updated_by)
        print('deleted MaterialConsumptionBreakdown', _)
        # # end update/insert MaterialConsumptionBreakdown
        self.calculation(instance)

        instance.save()
        return instance

    group_details = serializers.SerializerMethodField()
    def get_group_details(self, instance):
        _details = None
        if instance and instance.group:
            _details = AccountMaterialProjectGroup.cmobjects.filter(pk=instance.group.id).values()
        return _details


    class Meta:
        model = AccountMaterialProject
        fields = '__all__'


class AccountPRWCategorySerializer(serializers.ModelSerializer):
    """
    AccountPRWCategory  Serializer
    """
    class Meta:
        model = AccountPRWCategory
        fields = '__all__'
        # read_only_fields = ['id']


class AccountPRWSerializer(serializers.ModelSerializer):
    """
    AccountPRW  Serializer
    """
    class Meta:
        model = AccountPRW
        fields = '__all__'
        # read_only_fields = ['id']


class AccountPRWRatesSerializer(serializers.ModelSerializer):
    """
    AccountPRWRates  Serializer
    """

    # entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'], required=True)
    class Meta:
        model = AccountPRWRates
        fields = '__all__'
        # read_only_fields = ['id']


class AccountPRWRatesSerializer2(serializers.ModelSerializer):
    """
    AccountPRWRates  Serializer
    """

    # entry_date = serializers.DateField(format="%d-%m-%Y", input_formats=['%d-%m-%Y', 'iso-8601'], required=True)
    class Meta:
        model = AccountPRWRates
        fields = ('id', 'organization',  'master', 'rate', 'entry_date', 'is_deleted',)
        list_serializer_class = CommonFilterListSerializer


class AccountPRWSerializer2(serializers.ModelSerializer):
    """
    AccountPRW  Serializer
    """
    rates_details = AccountPRWRatesSerializer2(many=True, read_only=True, source="account_prw_rates")
    class Meta:
        model = AccountPRW
        fields = ('id', 'organization', 'category', 'project', 'item', 'uom_text', 'rates_details', 'is_deleted')
        list_serializer_class = CommonFilterListSerializer


class AccountPRWCategorySerializer2(serializers.ModelSerializer):
    """
    AccountPRWCategory  Serializer
    """
    account_prw_details = AccountPRWSerializer2(many=True, read_only=True, source="account_prw_category")
    class Meta:
        model = AccountPRWCategory
        fields = ('id', 'organization', 'name', 'account_prw_details', 'is_deleted',)


class AccountIndirectCostDPRSerializer(serializers.ModelSerializer):
    """
    AccountIndirectCostDPR  Serializer
    """
    indirect_cost_details = serializers.SerializerMethodField()

    def get_indirect_cost_details(self, instance):
        return_details = {}
        try:
            if instance.indirect_cost and instance.indirect_cost_id:
                details = WbsIndirectCostPlaning.cmobjects.filter(pk=instance.indirect_cost_id).first()
                serializer = WbsIndirectCostPlaningSerializer(details)
                return_details = serializer.data
        except Exception as e:
            print('ERROR', e)
        return return_details

    class Meta:
            model = AccountIndirectCostDPR
            fields = '__all__'
