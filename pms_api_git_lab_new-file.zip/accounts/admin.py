from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from accounts.models import *


admin.site.register(AccountProjectCostMaster,ModelAdmin)


@admin.register(AccountChainageMaster)
class AccountChainageMasterAdmin(ModelAdmin):
    list_display = ['id', 'name', 'code', 'project',  'is_deleted',]
    search_fields = ('name', 'code')

@admin.register(AccountActivityMaster)
class AccountActivityMasterAdmin(ModelAdmin):
    list_display = ['id', 'name', 'code', 'chainage',  'is_deleted',]
    search_fields = ('name', 'code')

@admin.register(AccountSubActivityMaster)
class AccountSubActivityMasterAdmin(ModelAdmin):
    list_display = ['id', 'name', 'code', 'activity', 'parent',  'is_deleted',]
    search_fields = ('name', 'code')
    autocomplete_fields = ('activity', 'parent')


admin.site.register(AccountProjectBudgetGroup,ModelAdmin)


@admin.register(AccountProjectBudget)
class AccountProjectBudgetAdmin(ModelAdmin):
    list_display = ['id', 'activity', 'code', 'project', 'sub_activity_master', 'is_deleted', 'parent',]
    search_fields = ('activity', 'code')


@admin.register(BudgetBreakdown)
class BudgetBreakdownAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'is_zero_budget', 'master', 'entry_date', 'qty', 'rate']
    search_fields = ('entry_date', )


@admin.register(AccountConsumptionBreakdown)
class AccountConsumptionBreakdownAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'master', 'qty', 'rate']


# materials
admin.site.register(AccountMaterialProjectGroup,ModelAdmin)


@admin.register(AccountMaterialProject)
class AccountMaterialProjectAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'material_code', 'project']
    search_fields = ('material_code',)


@admin.register(MaterialBudgetBreakdown)
class MaterialBudgetBreakdownAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'is_zero_budget', 'material_code', 'amount', 'entry_date']
    search_fields = ('material_code',)

@admin.register(MaterialConsumptionBreakdown)
class MaterialConsumptionBreakdownAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'material_code', 'consumed_amt']
    search_fields = ('material_code',)


@admin.register(AccountPRWCategory)
class AccountPRWCategoryAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'name', 'organization']
    search_fields = ('name',)

@admin.register(AccountPRW)
class AccountPRWAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'parent', 'category', 'project']

@admin.register(AccountPRWRates)
class AccountPRWRatesAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'master', 'rate', 'entry_date']


@admin.register(AccountIndirectCostDPR)
class AccountIndirectCostDPRAdmin(ModelAdmin):
    list_display = ['id', 'is_deleted', 'project', 'indirect_cost', 'purpose', 'date']



