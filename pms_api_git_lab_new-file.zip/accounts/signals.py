from django.db import transaction
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from .models import *
from .helper import *

@receiver(post_save, sender=AccountProjectBudget)
def signal_account_project_budget(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.is_deleted:
            print("in signal AccountProjectBudget")
            print(instance.id)
            print(instance.is_deleted)
            BudgetBreakdown.objects.filter(master=instance).update(is_deleted=True)
            AccountConsumptionBreakdown.objects.filter(master=instance).update(is_deleted=True)

@receiver(post_save, sender=AccountMaterialProject)
def signal_account_material_project(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.is_deleted:
            print("in signal AccountMaterialProject")
            print(instance.id)
            print(instance.is_deleted)
            MaterialBudgetBreakdown.objects.filter(master=instance).update(is_deleted=True)
            MaterialConsumptionBreakdown.objects.filter(master=instance).update(is_deleted=True)


@receiver(post_save, sender=AccountChainageMaster)
def signal_account_chainage_master(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.is_deleted:
            print("in signal AccountChainageMaster")
            print(instance.id)
            print(instance.is_deleted)
            AccountActivityMaster.objects.filter(chainage=instance).update(is_deleted=True)

@receiver(post_save, sender=AccountSubActivityMaster)
def signal_account_subActivity_master(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.is_deleted:
            print("in signal AccountSubActivityMaster")
            print(instance.id)
            print(instance.is_deleted)
            AccountSubActivityMaster.objects.filter(parent=instance).update(is_deleted=True)
            AccountProjectBudget.objects.filter(sub_activity_master=instance).update(is_deleted=True)
            print('---x----')

@receiver(post_save, sender=AccountPRWCategory)
def signal_account_prw_category(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.is_deleted:
            print("in signal AccountPRWCategory")
            print(instance.id)
            print(instance.is_deleted)
            AccountPRW.objects.filter(category=instance).update(is_deleted=True)


@receiver(post_save, sender=AccountPRW)
def signal_account_prw(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.is_deleted:
            print("in signal AccountPRW")
            print(instance.id)
            print(instance.is_deleted)
            AccountPRWRates.objects.filter(master=instance).update(is_deleted=True)


@receiver(pre_save, sender=AccountChainageMaster)
def signal_account_chainage_master_check_code(sender, instance, **kwargs):
    check_code(instance)


@receiver(pre_save, sender=AccountActivityMaster)
def signal_account_activity_check_code(sender, instance, **kwargs):
    check_code(instance)


@receiver(pre_save, sender=AccountSubActivityMaster)
def signal_account_sub_activity_check_code(sender, instance, **kwargs):
    check_code(instance)


@receiver(pre_save, sender=AccountProjectBudget)
def signal_account_project_budget_check_code(sender, instance, **kwargs):
    check_code(instance)



