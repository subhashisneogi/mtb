from colorama import Back, Style
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException
from datetime import date

from .models import *
from .serializers import *
# Create your views here.


class LabourMasterAPIView(APIView):
    """
    CRUD API for LabourMaster model
    """
    
    

    def get(self, request, format=None):
        """
        Get a list of all LabourMaster
        """
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        if id:
            labour_master_details = LabourMaster.cmobjects.filter(id=id).first()
            serializer = LabourMasterSerializer(labour_master_details)
            return Response(serializer.data)
        
        search = {}
        search = custom_filters(self.request, search, [])

        labour_master_list = LabourMaster.cmobjects.filter(*search).select_related('uom').order_by('-id')

        if all == 'true':
            serializer = LabourMasterSerializer(labour_master_list, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(labour_master_list, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = LabourMasterSerializer(page, many=True)

        

        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })

    def post(self, request, format=None):
        """
        Create a new Labour
        """
        request.data['created_by_id'] = request.user.id
        serializer = LabourMasterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        

        raise APIException({'request_status': 0, 'msg': serializer.errors})

    def put(self, request, *args, **kwargs):
        """
        Below are the methods for Edit method and Delete method
        """
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get(
            'organization_id', None)
        id = self.request.query_params.get('id', None)

        with transaction.atomic():
            if method.lower() == 'edit':
                """
                Update a Labour
                """

                if LabourMaster.cmobjects.filter(pk=id,
                                             organization_id=organization_id).exists():

                    labour_details = LabourMaster.cmobjects.filter(pk=id).first()
                    request.data['updated_by_id'] = request.user.id
                    serializer = LabourMasterSerializer(labour_details, data=request.data)

                    if serializer.is_valid():
                        serializer.save()

                        return Response({'results': {
                                        'Data': serializer.data,
                                        },
                            'msg': "Sucessfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})
            elif method.lower() == 'delete':
                """
                Delete a Labour
                """
                if LabourMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    labour_details = LabourMaster.cmobjects.get(
                        pk=id, organization_id=organization_id)
                    labour_details.updated_by_id = request.user.id
                    labour_details.is_deleted = True
                    labour_details.save()

                    return Response({'results': {
                        'labour': LabourMaster.objects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted Labour',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 0, 'msg': "Something went wrong. If the problem persists, please contact support."})