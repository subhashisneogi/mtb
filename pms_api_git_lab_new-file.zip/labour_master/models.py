from django.db import models

from administrations.models import *
from material_master.models import *
# Create your models here.

class LabourMaster(BaseAbstractStructure):
    """
    Labour Master
    """
    VALUE_TYPES = (
        ('DC', 'DC'),
        ('IDC', 'IDC'),
    )
    VALUE_COMPONENT = (
        ('Labour', 'Labour'),
        ('PROW', 'PROW'),
    )
    organization = models.ForeignKey(Organization, related_name='labour_master_organization',
                                     on_delete=models.DO_NOTHING)
    cost_type = models.CharField(max_length=150,choices=VALUE_TYPES, blank=True, null=True, default="DC")
    component = models.CharField(max_length=150,choices=VALUE_COMPONENT, blank=True, null=True, default="Labour")
    name = models.CharField(max_length=255)
    uom = models.ForeignKey(UnitOfMesurement, related_name='labour_master_uom',
                            on_delete=models.DO_NOTHING, blank=True, null=True)
    basic_wage = models.FloatField(default=0)
    vda = models.FloatField(default=0)
    pf = models.FloatField(default=0)
    esi = models.FloatField(default=0)
    rate = models.FloatField(default=0) #basic_wage+vda+pf+esi

    def save(self, *args, **kwargs):
        if not self.basic_wage:
            self.basic_wage = 0
        if not self.vda:
            self.vda = 0
        if not self.pf:
            self.pf = 0
        if not self.esi:
            self.esi = 0
        if self.component == 'PROW':
            self.vda = 0
            self.pf = 0
            self.esi = 0
        self.rate = float(self.basic_wage)+float(self.vda)+float(self.pf)+float(self.esi)
        super().save(*args, **kwargs)

    def __str__(self):
        return str(self.id) + ' ' + str(self.name) + ' ( ' + str(self.cost_type) + ' ' + str(self.component) + ' )'

    class Meta:
        unique_together = ('organization','cost_type','component','name','uom',)
        db_table = "labour_master"
    
