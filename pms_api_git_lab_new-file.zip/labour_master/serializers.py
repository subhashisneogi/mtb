from colorama import Back, Style
from rest_framework import serializers
from .models import *
from procurement.helper import *


class LabourMasterSerializer(serializers.ModelSerializer):
    """"
    Labour Master Serializer
    """
    uom_details = serializers.SerializerMethodField()

    def get_uom_details(self, instance):
        # details = []
        # if instance.uom:
        #     details = UnitOfMesurement.cmobjects.filter(pk=instance.uom_id).values()
        # return details
        return get_details_from_instance(instance.uom)

    class Meta:
        model = LabourMaster
        fields = '__all__'