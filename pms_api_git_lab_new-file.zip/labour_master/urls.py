from django.urls import path
from labour_master import views


urlpatterns = [

    path('labour-master/', views.LabourMasterAPIView.as_view()),

]