from django.urls import path
from tender_eligibility import views


urlpatterns = [
    path('technicaleligibility/', views.TechnicalEligibilityView.as_view()),
    path('financialeligibility/', views.FinancialEligibilityView.as_view()),
    path('specialeligibility/', views.SpecialEligibilityView.as_view()),
    path('tenderevaluationstandalone/', views.TenderEvaluationStandalone.as_view()),
    path('tenderevaluationjv/', views.TenderEvaluationJV.as_view()),

    path('tender_percentage_share_analytics/', views.TenderPercentageShareEvaluation.as_view()),

    path('jv_tender_percentage_share_analytics/', views.TenderPercentageShareForJVEvaluation.as_view()),
]
