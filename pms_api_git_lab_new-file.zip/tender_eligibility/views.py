from colorama import Back, Style
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.exceptions import APIException
from .models import *
from .serializers import *
from custom_management.models import *
from tender.models import *

from knox.auth import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from django.db.models import Q

from knox.auth import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
##################################################################################################################################
####################################################   TechnicalEligibility  Part ###############################################
class TechnicalEligibilityView(APIView):
    
    ####################################################   TechnicalEligibility POST Form #################################################
    def post(self, request):
        organization_id = self.request.query_params.get('organization_id', None)
        form_id = request.data.get('form_id')
        value_character = request.data.get('value_character')
        document = request.FILES.get('document')
        tender_id = request.data.get('tender_id')
        created_by = request.user
        try:
            technical_eligibility = TechnicalEligibility.objects.create(
                organization_id=organization_id,
                form_id=form_id,
                value_character=value_character,
                document=document,
                tender_id_id=tender_id,
                created_by = created_by
            )
            serializer = TechnicalEligibilitySerializer(technical_eligibility)
        
            return Response({'results':serializer.data ,
                                'msg': 'Successfully created Technical Eligibility',
                                'status':status.HTTP_201_CREATED,
                                "request_status": 1})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    ####################################################   TechnicalEligibility EDIT and delete Form #################################################
    def put(self, request):
        method = self.request.query_params.get('method', None)
        technical_eligibility_id = self.request.query_params.get('id', None)
        organization_id = self.request.query_params.get('organization_id', None)

        if method == 'edit':
            form_id = request.data.get('form_id')
            value_character = request.data.get('value_character')
            document = request.FILES.get('document')
            tender_id = request.data.get('tender_id')

            try:
                technical_eligibility = TechnicalEligibility.objects.get(id=technical_eligibility_id,organization_id=organization_id)
                technical_eligibility.form_id = form_id
                technical_eligibility.value_character = value_character
                if document:
                    technical_eligibility.document = document
                technical_eligibility.tender_id_id = tender_id
                technical_eligibility.updated_by = request.user
                technical_eligibility.save()
                serializer = TechnicalEligibilitySerializer(technical_eligibility)
                return Response({'results': serializer.data,
                        'msg': 'Successfully updated Technical eligibility',
                        'status': status.HTTP_200_OK,
                        "request_status": 1})
            except TechnicalEligibility.DoesNotExist:
                return Response({
                        'msg': 'Technical eligibility with current id does not exist',
                        'status': status.HTTP_404_NOT_FOUND,
                        "request_status": 0})
            except Exception as e:
                return Response({
                        'error': str(e),
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
        
        elif method == 'delete':
            try:
                technical_eligibility = TechnicalEligibility.objects.get(id=technical_eligibility_id)
                technical_eligibility.is_deleted = True
                technical_eligibility.save()
                serializer = TechnicalEligibilitySerializer(technical_eligibility)
                return Response({'results': serializer.data,
                    'msg': 'Technical eligibility deleted successfully',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})
            except TechnicalEligibility.DoesNotExist:
                return Response({
                        'msg': 'Technical eligibility with current id does not exist',
                        'status': status.HTTP_404_NOT_FOUND,
                        "request_status": 0})
            except Exception as e:
                return Response({
                        'error': str(e),
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})

        else:
            return Response({
                        'error': str(e),
                        'msg': "Invalid method parameter Please provide edit or delete method",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
            
            
####################################################   TechnicalEligibility  Part end ####################################### 
######################################################################################################################################



##################################################################################################################################
####################################################   FinancialEligibility  Part ###############################################
class FinancialEligibilityView(APIView):
    
    ####################################################   FinancialEligibility POST Form #################################################
    def post(self, request):
        organization_id = self.request.query_params.get('organization_id', None)
        form_id = request.data.get('form_id')
        value_character = request.data.get('value_character')
        tender_id = request.data.get('tender_id')
        created_by = request.user
        try:
            financial_eligibility = FinancialEligibility.objects.create(
                organization_id=organization_id,
                form_id=form_id,
                value_character=value_character,
                tender_id_id=tender_id,
                created_by = created_by
            )
            serializer = FinancialEligibilitySerializer(financial_eligibility)
            
            return Response({'results':serializer.data ,
                                'msg': 'Successfully created Financial Eligibility',
                                'status':status.HTTP_201_CREATED,
                                "request_status": 1})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    ####################################################   FinancialEligibility EDIT and delete Form #################################################
    def put(self, request):
        method = self.request.query_params.get('method', None)
        financial_eligibility_id = self.request.query_params.get('id', None)
        organization_id = self.request.query_params.get('organization_id', None)

        if method == 'edit':
            form_id = request.data.get('form_id')
            value_character = request.data.get('value_character')
            tender_id = request.data.get('tender_id')

            try:
                financial_eligibility_id = FinancialEligibility.objects.get(id=financial_eligibility_id,organization_id=organization_id)
                financial_eligibility_id.form_id = form_id
                financial_eligibility_id.value_character = value_character
                financial_eligibility_id.tender_id_id = tender_id
                financial_eligibility_id.updated_by = request.user
                financial_eligibility_id.save()
                serializer = FinancialEligibilitySerializer(financial_eligibility_id)
                return Response({'results': serializer.data,
                        'msg': 'Successfully updated Financial Eligibility',
                        'status': status.HTTP_200_OK,
                        "request_status": 1})
            except FinancialEligibility.DoesNotExist:
                return Response({
                        'msg': 'Financial Eligibility with current id does not exist',
                        'status': status.HTTP_404_NOT_FOUND,
                        "request_status": 0})
            except Exception as e:
                return Response({
                        'error': str(e),
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
        
        elif method == 'delete':
            try:
                financial_eligibility = FinancialEligibility.objects.get(id=financial_eligibility_id)
                financial_eligibility.is_deleted = True
                financial_eligibility.save()
                serializer = FinancialEligibilitySerializer(financial_eligibility)
                return Response({'results': serializer.data,
                    'msg': 'Financial Eligibility deleted successfully',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})
            except FinancialEligibility.DoesNotExist:
                return Response({
                        'msg': 'Financial Eligibility with current id does not exist',
                        'status': status.HTTP_404_NOT_FOUND,
                        "request_status": 0})
            except Exception as e:
                return Response({
                        'error': str(e),
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})

        else:
            return Response({
                        'msg': "Invalid method parameter Please provide edit or delete method",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
            
            
####################################################   FinancialEligibility  Part end ####################################### 
######################################################################################################################################

##################################################################################################################################
####################################################   SpecialEligibility  Part ###############################################
class SpecialEligibilityView(APIView):
    
    ####################################################   SpecialEligibility POST Form #################################################
    def post(self, request):
        organization_id = self.request.query_params.get('organization_id', None)
        form_id = request.data.get('form_id')
        value_character = request.data.get('value_character')
        tender_id = request.data.get('tender_id')
        created_by = request.user
        try:
            special_eligibility = SpecialEligibility.objects.create(
                organization_id=organization_id,
                form_id=form_id,
                value_character=value_character,
                tender_id_id=tender_id,
                created_by = created_by
            )
            serializer = SpecialEligibilitySerializer(special_eligibility)
            
            return Response({'results':serializer.data ,
                                'msg': 'Successfully created Special Eligibility',
                                'status':status.HTTP_201_CREATED,
                                "request_status": 1})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    ####################################################   SpecialEligibility EDIT and delete Form #################################################
    def put(self, request):
        method = self.request.query_params.get('method', None)
        special_eligibility_id = self.request.query_params.get('id', None)
        organization_id = self.request.query_params.get('organization_id', None)

        if method == 'edit':
            form_id = request.data.get('form_id')
            value_character = request.data.get('value_character')
            tender_id = request.data.get('tender_id')

            try:
                special_eligibility_id = SpecialEligibility.objects.get(id=special_eligibility_id,organization_id=organization_id)
                special_eligibility_id.form_id = form_id
                special_eligibility_id.value_character = value_character
                special_eligibility_id.tender_id_id = tender_id
                special_eligibility_id.updated_by = request.user
                special_eligibility_id.save()
                serializer = SpecialEligibilitySerializer(special_eligibility_id)
                return Response({'results': serializer.data,
                        'msg': 'Successfully updated Special Eligibility',
                        'status': status.HTTP_200_OK,
                        "request_status": 1})
            except SpecialEligibility.DoesNotExist:
                return Response({
                        'msg': 'Special Eligibility with current id does not exist',
                        'status': status.HTTP_404_NOT_FOUND,
                        "request_status": 0})
            except Exception as e:
                return Response({
                        'error': str(e),
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
        
        elif method == 'delete':
            try:
                special_eligibility = SpecialEligibility.objects.get(id=special_eligibility_id)
                special_eligibility.is_deleted = True
                special_eligibility.save()
                serializer = SpecialEligibilitySerializer(special_eligibility)
                return Response({'results': serializer.data,
                    'msg': 'Special Eligibility deleted successfully',
                    'status': status.HTTP_200_OK,
                    "request_status": 1})
            except SpecialEligibility.DoesNotExist:
                return Response({
                        'msg': 'Special Eligibility with current id does not exist',
                        'status': status.HTTP_404_NOT_FOUND,
                        "request_status": 0})
            except Exception as e:
                return Response({
                        'error': str(e),
                        'msg': "Something went wrong. If the problem persists, please contact support.",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})

        else:
            return Response({
                        'msg': "Invalid method parameter Please provide edit or delete method",
                        'status': status.HTTP_400_BAD_REQUEST,
                        "request_status": 0})
            
            
####################################################   FinancialEligibility  Part end ####################################### 
######################################################################################################################################
from django.db.models import IntegerField,FloatField,Sum, Value,Case,F, When,ExpressionWrapper


def common_list(a, b):
    result = [i for i in a if i in b]
    return result

from django.db.models.functions import Cast, Coalesce
class TenderEvaluationStandalone(APIView):
    
    

    def get(self, request):

        organization_id = self.request.query_params.get('organization_id', None)
        form_type = self.request.query_params.get('form_type', None)

        tender_data = TenderData.cmobjects.filter(tender__organization_id=organization_id,
                                                ).order_by('id')
        drop_ids = list(FormDropdownChoices.cmobjects.filter(option="Standalone").values_list('id', flat=True))
        tender_data2 = TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
            form__form_internal_name="participations_mode", tender__organization_id=organization_id,values_int__in=drop_ids)
       
        tender_ids = list(tender_data2.values_list('tender_id', flat=True))
        tender_list_participated_id = list(TenderMaster.cmobjects.filter(Q(organization_id = organization_id), \
                                                        Q(id__in=tender_ids), Q(is_sent_for_approval=True) |\
                                                            Q(is_approved=True)).exclude(is_reject=True).values_list('id', flat=True))
        # print(tender_ids  )
        tender_sum = TenderData.cmobjects.filter(form__form_internal_name="tender_project_cost__eligibility", tender__organization_id=organization_id,\
            tender_id__in=tender_list_participated_id).annotate(values_float=Cast('value', FloatField())).aggregate(
                the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']
        # print (tender_sum)
        tender_values = TenderData.cmobjects.filter(tender__organization_id=organization_id,
                form__form_internal_name__in=["tender_project_cost__eligibility", "bid_bg_%"],
                tender_id__in=tender_list_participated_id
            ).annotate(
                tender_cost=Case(
                    When(form__form_internal_name="tender_project_cost__eligibility", then=Cast('value', FloatField())),
                    default=Value(None),
                    output_field=FloatField()
                ),
                bid_bg_value=Case(
                    When(form__form_internal_name="bid_bg_%", then=Cast('value', FloatField())),
                    default=Value(None),
                    output_field=FloatField()
                )
            ).annotate(
                total_infused=ExpressionWrapper(F('tender_cost')*(Case(When(bid_bg_value__isnull=True, then=Value(1.0)), default=F('bid_bg_value'))/100), output_field=FloatField())
            ).aggregate(total_infused_sum=Sum('total_infused'))
        
        total_infused_sum = tender_values['total_infused_sum']


        #################################### Tender Technically Opened ##############################


        dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='technically_opened_tender_final', \
                                                               option='Yes').values_list('id', flat=True))
        
        technical_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='technically_opened_tender_final', \
                                                      value__in=dropdown_ids).values_list('tender_id', flat=True))
        
        common_technical_ids = common_list(tender_list_participated_id,technical_tender_ids)
        
        technical_opened_tender_count = TenderMaster.cmobjects.filter(id__in=common_technical_ids).exclude(is_reject=True).count()



        technical_opened_tender_sum = TenderData.cmobjects.filter(form__form_internal_name="tender_project_cost__eligibility", tender__organization_id=organization_id,\
            tender_id__in=common_technical_ids).annotate(values_float=Cast('value', FloatField())).aggregate(
                the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']
        


        #################################### Tender Financially Opened ##############################


        dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='financially_opened_tender_final', \
                                                               option='Yes').values_list('id', flat=True))
        
        financial_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='financially_opened_tender_final', \
                                                      value__in=dropdown_ids).values_list('tender_id', flat=True))
        
        common_financial_ids = common_list(tender_list_participated_id,financial_tender_ids)
        
        financial_opened_tender_count = TenderMaster.cmobjects.filter(id__in=common_financial_ids).exclude(is_reject=True).count()

        financial_opened_tender_sum_in_crs = TenderData.cmobjects.filter(form__form_internal_name="tender_project_cost__eligibility", tender__organization_id=organization_id,\
            tender_id__in=common_financial_ids).annotate(values_float=Cast('value', FloatField())).aggregate(
                the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']

        ##############################################################################################

        standalone_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='participations_mode', \
                                                               option='Standalone').values_list('id', flat=True))
        
        standalone_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='participations_mode', \
                                                      value__in=standalone_ids).values_list('tender_id', flat=True))

        tender_list = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                    id__in=standalone_tender_ids).order_by('-id')
        
        ################################### Not Applicable Count ###############################################

        not_applicable_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='participations_mode', \
                                                               option__in=['Standalone','JV']).values_list('id', flat=True))
        
        not_applicable_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='participations_mode', \
                                                      value__in=not_applicable_ids).values_list('tender_id', flat=True))

        not_applicable_list = TenderMaster.cmobjects.filter(\
            organization_id=organization_id).exclude(\
                id__in=not_applicable_tender_ids).order_by('-id')
        

        ################################### Total L1 Count and Value (In CRS) ###############################################


        all_tender_l1_ids = list(TenderData.cmobjects.filter(form__form_internal_name="selected_as_l1", \
                                                         value='true').values_list('tender_id', flat=True))
        
        standalone_tender_l1_ids = common_list(tender_ids, all_tender_l1_ids)

        standalone_l1_tender_count = TenderMaster.cmobjects.filter(id__in=standalone_tender_l1_ids).count()


        standalone_l1_tender_sum_in_crs = TenderData.cmobjects.filter(form__form_internal_name="tender_project_cost__eligibility", tender__organization_id=organization_id,\
            tender_id__in=standalone_tender_l1_ids).annotate(values_float=Cast('value', FloatField())).aggregate(
                the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']
        
        ################################### Performance Calculations in % ###############################################

        particapated_count = len(tender_list_participated_id)

        if standalone_l1_tender_count and particapated_count and particapated_count != 0:
            performance_rate_by_nos = str(round((standalone_l1_tender_count / particapated_count) * 100, 2)) + " %"
        else:
            performance_rate_by_nos = 0

        if standalone_l1_tender_sum_in_crs and tender_sum and tender_sum != 0:
            performance_rate_by_value = str(round((standalone_l1_tender_sum_in_crs / tender_sum) * 100, 2)) + " %"
        else:
            performance_rate_by_value = 0

        ################################### BG Returned Calculation ###############################################

        bg_returned_value = TenderData.cmobjects.filter(form__form_internal_name="bid_bg_returned_value_in_crs_final_evaluation", \
                                                        tender_id__in=tender_ids).annotate(values_float=Cast('value', FloatField())).aggregate(the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']

        bg_returned_on_financial_opened = (financial_opened_tender_sum_in_crs - bg_returned_value) if financial_opened_tender_sum_in_crs and bg_returned_value else ""

        bg_yet_to_return_for_no_financial_opened = (total_infused_sum - bg_returned_value - bg_returned_on_financial_opened) if total_infused_sum and bg_returned_value and bg_returned_on_financial_opened else ""
               
        data = {
            "total_tender": tender_list.count(),
            "total_tender_participated": len(tender_list_participated_id),
            "total_tender_participated_in_cr": format(tender_sum, '.2f') if tender_sum else "",
            "total_BidBG_infused": format(total_infused_sum, '.2f') if total_infused_sum else "",

            "not_applicable_tender_count" : not_applicable_list.count(),

            "technical_opened_tender_count" : technical_opened_tender_count,
            "technical_opened_tender_sum" : format(technical_opened_tender_sum, '.2f') if technical_opened_tender_sum else "",
            "financial_opened_tender_count" : financial_opened_tender_count,
            "financial_opened_tender_sum_in_crs" : format(financial_opened_tender_sum_in_crs, '.2f') if financial_opened_tender_sum_in_crs else "",

            "standalone_l1_tender_count" : standalone_l1_tender_count,
            "standalone_l1_tender_sum_in_crs" : standalone_l1_tender_sum_in_crs,

            "performance_rate_by_nos" : performance_rate_by_nos,
            "performance_rate_by_value" : performance_rate_by_value,

            "bg_returned_value" : format(bg_returned_value, '.2f') if bg_returned_value else "",
            "bg_returned_on_financial_opened" : format(bg_returned_on_financial_opened, '.2f') if bg_returned_on_financial_opened else "",
            "bg_yet_to_return_for_no_financial_opened" : format(bg_yet_to_return_for_no_financial_opened, '.2f') if bg_yet_to_return_for_no_financial_opened else ""
        }
        
        return Response({'msg': data}, status=status.HTTP_200_OK)

class TenderEvaluationJV(APIView):
    
    

    def get(self, request):
        organization_id = self.request.query_params.get('organization_id', None)
        import ast

        result = []

        jv_list = JVMASTER.cmobjects.filter(organization_id=organization_id).order_by('-id')

        for item in jv_list:
            data_dict = {}
            data_dict["name"] = item.party_name
            data_dict["id"] = item.id

            ############################ JV Count Particulars ######################
            
            option_ids = list(FormDependentChoices.cmobjects.filter(form__form_internal_name='party_name', \
                                                               option_id=item.id).values_list('option_id', flat=True))

            # jv_tender_ids = list(TenderData.cmobjects.annotate(values_int=Cast('value', IntegerField())).filter(\
            #                                         form__form_internal_name='party_name', \
            #                                           values_int__in=option_ids).values_list('tender_id', flat=True))
            
            jv_tender_ids = []

            tender_data_list = TenderData.cmobjects.filter(form__form_internal_name='party_name')

            for item1 in tender_data_list:
                try:
                    res = ast.literal_eval(item1.value)
                except Exception as ex:
                    res = []
                for obj in res:
                    if obj in option_ids:
                        jv_tender_ids.append(item1.tender_id)
            
            tender_list = TenderMaster.cmobjects.filter(organization_id=organization_id,\
                                                    id__in=jv_tender_ids).order_by('-id')
            
            data_dict['total_tender'] = tender_list.count()


            tender_list_participated_id = list(TenderMaster.cmobjects.filter(Q(organization_id = organization_id), \
                                                        Q(id__in=jv_tender_ids), Q(is_sent_for_approval=True) |\
                                                            Q(is_approved=True)).exclude(is_reject=True).values_list('id', flat=True))
            
            tender_sum = TenderData.cmobjects.filter(form__form_internal_name="tender_project_cost__eligibility", tender__organization_id=organization_id,\
                                tender_id__in=tender_list_participated_id).annotate(values_float=Cast('value', FloatField())).aggregate(
                                    the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']
            
            tender_values = TenderData.cmobjects.filter(tender__organization_id=organization_id,
                form__form_internal_name__in=["tender_project_cost__eligibility", "bid_bg_%"],
                tender_id__in=tender_list_participated_id
            ).annotate(
                tender_cost=Case(
                    When(form__form_internal_name="tender_project_cost__eligibility", then=Cast('value', FloatField())),
                    default=Value(None),
                    output_field=FloatField()
                ),
                bid_bg_value=Case(
                    When(form__form_internal_name="bid_bg_%", then=Cast('value', FloatField())),
                    default=Value(None),
                    output_field=FloatField()
                )
            ).annotate(
                total_infused=ExpressionWrapper(F('tender_cost')*(Case(When(bid_bg_value__isnull=True, then=Value(1.0)), default=F('bid_bg_value'))/100), output_field=FloatField())
            ).aggregate(total_infused_sum=Sum('total_infused'))
        
            total_infused_sum = tender_values['total_infused_sum']
            
            data_dict['total_tender_participated'] = len(tender_list_participated_id)
            data_dict['total_tender_participated_in_cr'] = format(tender_sum, '.2f') if tender_sum else ""
            data_dict['total_BidBG_infused'] = format(total_infused_sum, '.2f') if total_infused_sum else ""

            #################################### Tender Technically Opened ##############################


            dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='technically_opened_tender_final', \
                                                                option='Yes').values_list('id', flat=True))
            
            technical_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='technically_opened_tender_final', \
                                                        value__in=dropdown_ids).values_list('tender_id', flat=True))
            
            common_technical_ids = common_list(tender_list_participated_id,technical_tender_ids)
            
            technical_opened_tender_count = TenderMaster.cmobjects.filter(id__in=common_technical_ids).exclude(is_reject=True).count()



            technical_opened_tender_sum = TenderData.cmobjects.filter(form__form_internal_name="tender_project_cost__eligibility", tender__organization_id=organization_id,\
                tender_id__in=common_technical_ids).annotate(values_float=Cast('value', FloatField())).aggregate(
                    the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']
            
            data_dict["technical_opened_tender_count"] = technical_opened_tender_count
            data_dict["technical_opened_tender_sum"] = format(technical_opened_tender_sum, '.2f') if technical_opened_tender_sum else ""

            #################################### Tender Financially Opened ##############################


            dropdown_ids = list(FormDropdownChoices.objects.filter(form__form_internal_name='financially_opened_tender_final', \
                                                                option='Yes').values_list('id', flat=True))
            
            financial_tender_ids = list(TenderData.cmobjects.filter(form__form_internal_name='financially_opened_tender_final', \
                                                        value__in=dropdown_ids).values_list('tender_id', flat=True))
            
            common_financial_ids = common_list(tender_list_participated_id,financial_tender_ids)
            
            financial_opened_tender_count = TenderMaster.cmobjects.filter(id__in=common_financial_ids).exclude(is_reject=True).count()

            financial_opened_tender_sum_in_crs = TenderData.cmobjects.filter(form__form_internal_name="tender_project_cost__eligibility", tender__organization_id=organization_id,\
                tender_id__in=common_financial_ids).annotate(values_float=Cast('value', FloatField())).aggregate(
                    the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']
            
            data_dict["financial_opened_tender_count"] = financial_opened_tender_count
            data_dict["financial_opened_tender_sum_in_crs"] = format(financial_opened_tender_sum_in_crs, '.2f') if financial_opened_tender_sum_in_crs else ""

            ##############################################################################################


            ################################### Total L1 Count and Value (In CRS) ###############################################


            all_tender_l1_ids = list(TenderData.cmobjects.filter(form__form_internal_name="selected_as_l1", \
                                                            value='true').values_list('tender_id', flat=True))
            
            jv_tender_l1_ids = common_list(jv_tender_ids, all_tender_l1_ids)

            jv_l1_tender_count = TenderMaster.cmobjects.filter(id__in=jv_tender_l1_ids).count()


            jv_l1_tender_sum_in_crs = TenderData.cmobjects.filter(form__form_internal_name="tender_project_cost__eligibility", tender__organization_id=organization_id,\
                tender_id__in=jv_tender_l1_ids).annotate(values_float=Cast('value', FloatField())).aggregate(
                    the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']
            
            data_dict["jv_l1_tender_count"] = jv_l1_tender_count
            data_dict["jv_l1_tender_sum_in_crs"] = format(jv_l1_tender_sum_in_crs, '.2f') if jv_l1_tender_sum_in_crs else ""


            ################################### Performance Calculations in % ###############################################

            particapated_count = len(tender_list_participated_id)

            if jv_l1_tender_count and particapated_count and particapated_count != 0:
                performance_rate_by_nos = str(round((jv_l1_tender_count / particapated_count) * 100, 2)) + " %"
            else:
                performance_rate_by_nos = 0

            if jv_l1_tender_sum_in_crs and tender_sum and tender_sum != 0:
                performance_rate_by_value = str(round((jv_l1_tender_sum_in_crs / tender_sum) * 100, 2)) + " %"
            else:
                performance_rate_by_value = 0

            data_dict["performance_rate_by_nos"] = performance_rate_by_nos
            data_dict["performance_rate_by_value"] = performance_rate_by_value

            ################################### BG Returned Calculation ###############################################

            bg_returned_value = TenderData.cmobjects.filter(form__form_internal_name="bid_bg_returned_value_in_crs_final_evaluation", \
                                                            tender_id__in=jv_tender_ids).annotate(values_float=Cast('value', FloatField())).aggregate(the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']

            bg_returned_on_financial_opened = (financial_opened_tender_sum_in_crs - bg_returned_value) if financial_opened_tender_sum_in_crs and bg_returned_value else ""

            bg_yet_to_return_for_no_financial_opened = (total_infused_sum - bg_returned_value - bg_returned_on_financial_opened) if total_infused_sum and bg_returned_value and bg_returned_on_financial_opened else ""

            data_dict["bg_returned_value"] = format(bg_returned_value, '.2f') if bg_returned_value else ""
            data_dict["bg_returned_on_financial_opened"] = format(bg_returned_on_financial_opened, '.2f') if bg_returned_on_financial_opened else ""
            data_dict["bg_yet_to_return_for_no_financial_opened"] = format(bg_yet_to_return_for_no_financial_opened, '.2f') if bg_yet_to_return_for_no_financial_opened else ""

            result.append(data_dict)
            
        
        return Response({'result': result}, status=status.HTTP_200_OK)


class TenderPercentageShareEvaluation(APIView):
    
    

    def get(self, request):
        tender_id = self.request.query_params.get('tender_id', None)

        result = []
        result_dict = {}

        tender_master = TenderMaster.cmobjects.filter(id=tender_id).first()

        standalone_company = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='select_own_company').first()

        stand_alone_ids = FormDependentChoices.cmobjects.filter(id=int(standalone_company.value)).first()

        from administrations.models import Company

        company_details = Company.cmobjects.filter(id=stand_alone_ids.option_id).first()

        threshold_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='thresold').first()

        result_dict['threshold'] = format(float(threshold_data.value), '.2f')

        turnover_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='avg_turn_over_for_last__5yrs').first()

        result_dict['turnover'] = format(float(turnover_data.value), '.2f')

        net_worth_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='net_worth').first()

        result_dict['net_worth'] = format(float(net_worth_data.value), '.2f')

        bid_capacity_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='bid_capacity').first()

        result_dict['bid_capacity'] = format(float(bid_capacity_data.value), '.2f')

        similar_work_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='similar_work').first()

        result_dict['similar_work'] = format(float(similar_work_data.value), '.2f')


        party_name_ids_str = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                         form__form_internal_name='party_name').first()
        
        import ast
        
        form_dependent_ids = ast.literal_eval(party_name_ids_str.value)

        jv_ids = list(FormDependentChoices.cmobjects.filter(id__in=form_dependent_ids).values_list('option_id', flat=True))

        jv_list = JVMASTER.cmobjects.filter(id__in=jv_ids, \
                                            organization_id=tender_master.organization_id)

        jv_result_for_required = []

        jv_avail_threshold_sum = 0
        jv_value_of_similar_works_sum = 0
        jv_maximum_span_length_of_bridge_avail_sum = 0
        jv_average_annual_turn_over_sum = 0
        jv_net_worth_sum = 0

        for item in jv_list:
            jv_dict = {}
            jv_dict['id'] = item.id
            jv_dict['party_name'] = item.party_name
            jv_dict['available_threshold'] = format(item.available_threshold, '.2f')
            jv_dict['value_of_similar_works'] = format(item.value_of_similar_works, '.2f')
            jv_dict['maximum_span_length_of_bridge_avail'] = format(item.maximum_span_length_of_bridge_avail, '.2f')
            jv_dict['average_annual_turn_over'] = format(item.average_annual_turn_over, '.2f')
            jv_dict['net_worth'] = format(item.net_worth, '.2f')

            jv_avail_threshold_sum += item.available_threshold
            jv_value_of_similar_works_sum += item.value_of_similar_works
            jv_maximum_span_length_of_bridge_avail_sum += item.maximum_span_length_of_bridge_avail
            jv_average_annual_turn_over_sum += item.average_annual_turn_over
            jv_net_worth_sum += item.net_worth


            order_id = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                   form__form_internal_name='party_name_percentage_share', \
                                                    value=item.party_name).first()
            
            if order_id:
                percentage_share = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                            form__form_internal_name='jv_share__details', \
                                                                by_order=order_id.by_order).first()
                
                percentage_share_value = float(percentage_share.value)
            else:
                percentage_share_value = 0

            jv_dict['required_threshold'] = format((percentage_share_value / 100) * float(threshold_data.value), '.2f') if percentage_share_value != 0 else 0
            jv_dict['required_value_of_similar_works'] = format((percentage_share_value / 100) * float(similar_work_data.value), '.2f') if percentage_share_value != 0 else 0
            jv_dict['required_maximum_span_length_of_bridge_avail'] = format((percentage_share_value / 100) * float(bid_capacity_data.value), '.2f') if percentage_share_value != 0 else 0
            jv_dict['required_average_annual_turn_over'] = format((percentage_share_value / 100) * float(turnover_data.value), '.2f') if percentage_share_value != 0 else 0
            jv_dict['required_net_worth'] = format((percentage_share_value / 100) * float(net_worth_data.value), '.2f') if percentage_share_value != 0 else 0

            jv_result_for_required.append(jv_dict)

        result_dict['jv_details'] = jv_result_for_required

        own_result = []

        own_dict = {}
        
        
        own_dict['company_name'] = company_details.name
        own_dict['company_id'] = company_details.id
        own_dict['available_threshold'] = format(company_details.available_threshold, '.2f')
        own_dict['value_of_similar_works'] = format(company_details.value_of_similar_works, '.2f')
        own_dict['maximum_span_length_of_bridge_avail'] = format(company_details.maximum_span_length_of_bridge_avail, '.2f')
        own_dict['average_annual_turn_over'] = format(company_details.average_annual_turn_over, '.2f')
        own_dict['net_worth'] = format(company_details.net_worth, '.2f')

        company_order_id = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                   form__form_internal_name='party_name_percentage_share', \
                                                    value=company_details.name).first()
            
        if company_order_id:
            company_percentage_share = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                        form__form_internal_name='jv_share__details', \
                                                            by_order=company_order_id.by_order).first()
            
            company_percentage_share_value = float(company_percentage_share.value)
        else:
            company_percentage_share_value = 0

        own_dict['required_threshold'] = format((company_percentage_share_value / 100) * float(threshold_data.value), '.2f') if company_percentage_share_value != 0 else 0
        own_dict['required_value_of_similar_works'] = format((company_percentage_share_value / 100) * float(similar_work_data.value), '.2f') if company_percentage_share_value != 0 else 0
        own_dict['required_maximum_span_length_of_bridge_avail'] = format((company_percentage_share_value / 100) * float(bid_capacity_data.value), '.2f') if company_percentage_share_value != 0 else 0
        own_dict['required_average_annual_turn_over'] = format((company_percentage_share_value / 100) * float(turnover_data.value), '.2f') if company_percentage_share_value != 0 else 0
        own_dict['required_net_worth'] = format((company_percentage_share_value / 100) * float(net_worth_data.value), '.2f') if company_percentage_share_value != 0 else 0
        own_result.append(own_dict)

        result_dict['own_company_details'] = own_result


        result_dict['combined_threshold'] = format(jv_avail_threshold_sum + company_details.available_threshold, '.2f')
        result_dict['combined_value_of_similar_works'] = format(jv_value_of_similar_works_sum + company_details.value_of_similar_works, '.2f')
        result_dict['combined_maximum_span_length_of_bridge_avail'] = format(jv_maximum_span_length_of_bridge_avail_sum + company_details.maximum_span_length_of_bridge_avail, '.2f')
        result_dict['combined_average_annual_turn_over'] = format(jv_average_annual_turn_over_sum + company_details.average_annual_turn_over, '.2f')
        result_dict['combined_net_worth'] = format(jv_net_worth_sum + company_details.net_worth, '.2f')


        result.append(result_dict)



        return Response({'result': result}, status=status.HTTP_200_OK)





class TenderPercentageShareForJVEvaluation(APIView):
    
    

    def get(self, request):
        tender_id = self.request.query_params.get('tender_id', None)

        tender_master = TenderMaster.cmobjects.filter(id=tender_id).first()

        result = []
        result_dict = {}

        standalone_company = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                         form__form_internal_name='select_own_company').first()
        
        if not standalone_company:
            standalone_company = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                         form__form_internal_name='party_name_standalone').first()

        stand_alone_ids = FormDependentChoices.cmobjects.filter(id=int(standalone_company.value)).first()

        from administrations.models import Company

        company_details = Company.cmobjects.filter(id=stand_alone_ids.option_id).first()

        threshold_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='thresold').first()

        result_dict['threshold'] = format(float(threshold_data.value), '.2f')

        turnover_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='avg_turn_over_for_last__5yrs').first()

        result_dict['turnover'] = format(float(turnover_data.value), '.2f')

        net_worth_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='net_worth').first()

        result_dict['net_worth'] = format(float(net_worth_data.value), '.2f')

        bid_capacity_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='bid_capacity').first()

        result_dict['bid_capacity'] = format(float(bid_capacity_data.value), '.2f')

        similar_work_data = TenderData.cmobjects.filter(tender_id=tender_id, form__form_internal_name='similar_work').first()

        result_dict['similar_work'] = format(float(similar_work_data.value), '.2f')


        lead_member_order_id = TenderData.cmobjects.filter(tender_id=tender_id, \
                                               form__form_internal_name='selected_as_lead_jv_analytics', \
                                                value="true").first()
        
        if lead_member_order_id:
            lead_member_percentage_share = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                        form__form_internal_name='jv_share__details', \
                                                            by_order=lead_member_order_id.by_order).first()
            
            lead_member_percentage_share_value = float(lead_member_percentage_share.value)
            other_member_percentage_share_value = 100 - lead_member_percentage_share_value
        else:
            lead_member_percentage_share_value = 0.00
            other_member_percentage_share_value = 0.00

        result_dict['required_threshold_lead_member'] = format((lead_member_percentage_share_value / 100) * float(threshold_data.value), '.2f') if lead_member_percentage_share_value != 0 else 0
        result_dict['required_value_of_similar_works_lead_member'] = format((lead_member_percentage_share_value / 100) * float(similar_work_data.value), '.2f') if lead_member_percentage_share_value != 0 else 0
        result_dict['required_maximum_span_length_of_bridge_avail_lead_member'] = format((lead_member_percentage_share_value / 100) * float(bid_capacity_data.value), '.2f') if lead_member_percentage_share_value != 0 else 0
        result_dict['required_average_annual_turn_over_lead_member'] = format((lead_member_percentage_share_value / 100) * float(turnover_data.value), '.2f') if lead_member_percentage_share_value != 0 else 0
        result_dict['required_net_worth_lead_member'] = format((lead_member_percentage_share_value / 100) * float(net_worth_data.value), '.2f') if lead_member_percentage_share_value != 0 else 0


        result_dict['required_threshold_other_member'] = format((other_member_percentage_share_value / 100) * float(threshold_data.value), '.2f') if other_member_percentage_share_value != 0 else 0
        result_dict['required_value_of_similar_works_other_member'] = format((other_member_percentage_share_value / 100) * float(similar_work_data.value), '.2f') if other_member_percentage_share_value != 0 else 0
        result_dict['required_maximum_span_length_of_bridge_avail_other_member'] = format((other_member_percentage_share_value / 100) * float(bid_capacity_data.value), '.2f') if other_member_percentage_share_value != 0 else 0
        result_dict['required_average_annual_turn_over_other_member'] = format((other_member_percentage_share_value / 100) * float(turnover_data.value), '.2f') if other_member_percentage_share_value != 0 else 0
        result_dict['required_net_worth_other_member'] = format((other_member_percentage_share_value / 100) * float(net_worth_data.value), '.2f') if other_member_percentage_share_value != 0 else 0


        lead_party = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                 form__form_internal_name='party_name_percentage_share',  \
                                                    by_order=lead_member_order_id.by_order).first()
        
        lead_jv_details = JVMASTER.cmobjects.filter(party_name=lead_party.value, \
                                                     organization_id=tender_master.organization_id).first()
        
        lead_company_details = Company.cmobjects.filter(name=lead_party.value, \
                                                     organization_id=tender_master.organization_id).first()
        
        lead_bid_capacity = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                 form__form_internal_name='bid_capacity_percentage_analysis',  \
                                                    by_order=lead_member_order_id.by_order).first()
        
        if lead_company_details:
            result_dict['available_threshold_lead_member'] = format(lead_company_details.available_threshold, '.2f')
            result_dict['value_of_similar_works_lead_member'] = format(lead_company_details.value_of_similar_works, '.2f')
            result_dict['maximum_span_length_of_bridge_avail_lead_member'] = format(float(lead_bid_capacity.value), '.2f')
            result_dict['average_annual_turn_over_lead_member'] = format(lead_company_details.average_annual_turn_over, '.2f')
            result_dict['net_worth_lead_member'] = format(lead_company_details.net_worth, '.2f')


            available_threshold_lead_member = lead_company_details.available_threshold
            value_of_similar_works_lead_member = lead_company_details.value_of_similar_works
            maximum_span_length_of_bridge_avail_lead_member = float(lead_bid_capacity.value)
            average_annual_turn_over_lead_member = lead_company_details.average_annual_turn_over
            net_worth_lead_member = lead_company_details.net_worth

        elif lead_jv_details:
            result_dict['available_threshold_lead_member'] = format(lead_jv_details.available_threshold, '.2f')
            result_dict['value_of_similar_works_lead_member'] = format(lead_jv_details.value_of_similar_works, '.2f')
            result_dict['maximum_span_length_of_bridge_avail_lead_member'] = format(float(lead_bid_capacity.value), '.2f')
            result_dict['average_annual_turn_over_lead_member'] = format(lead_jv_details.average_annual_turn_over, '.2f')
            result_dict['net_worth_lead_member'] = format(lead_jv_details.net_worth, '.2f')

            available_threshold_lead_member = lead_jv_details.available_threshold
            value_of_similar_works_lead_member = lead_jv_details.value_of_similar_works
            maximum_span_length_of_bridge_avail_lead_member = float(lead_bid_capacity.value)
            average_annual_turn_over_lead_member = lead_jv_details.average_annual_turn_over
            net_worth_lead_member = lead_jv_details.net_worth


        other_party_by_orders = list(TenderData.cmobjects.filter(tender_id=tender_id,\
                                                            form__form_internal_name='selected_as_lead_jv_analytics',\
                                                            value='false').values_list('by_order', flat=True))
        
        other_party_names = list(TenderData.cmobjects.filter(tender_id=tender_id, \
                                                 form__form_internal_name='party_name_percentage_share',\
                                                    by_order__in=other_party_by_orders).values_list('value', flat=True))
        
        other_party_bid_capacity = TenderData.cmobjects.filter(form__form_internal_name="bid_capacity_percentage_analysis", by_order__in=other_party_by_orders,\
            tender_id=tender_id).annotate(values_float=Cast('value', FloatField())).aggregate(
                the_sum=Coalesce(Sum('values_float'), Value(0), output_field=FloatField()))['the_sum']
        

        other_avail_threshold_sum = 0
        other_value_of_similar_works_sum = 0
        other_maximum_span_length_of_bridge_avail_sum = other_party_bid_capacity if other_party_bid_capacity else 0
        other_average_annual_turn_over_sum = 0
        other_net_worth_sum = 0
        

        for item in other_party_names:
            other_jv_details = JVMASTER.cmobjects.filter(party_name=item, \
                                                     organization_id=tender_master.organization_id).first()
        
            other_company_details = Company.cmobjects.filter(name=item, \
                                                     organization_id=tender_master.organization_id).first()
            
            if other_jv_details:
                available_threshold = other_jv_details.available_threshold
                value_of_similar_works = other_jv_details.value_of_similar_works
                #maximum_span_length_of_bridge_avail = other_jv_details.maximum_span_length_of_bridge_avail
                average_annual_turn_over = other_jv_details.average_annual_turn_over
                net_worth = other_jv_details.net_worth

            if other_company_details:
                available_threshold = other_company_details.available_threshold
                value_of_similar_works = other_company_details.value_of_similar_works
                #maximum_span_length_of_bridge_avail = other_company_details.maximum_span_length_of_bridge_avail
                average_annual_turn_over = other_company_details.average_annual_turn_over
                net_worth = other_company_details.net_worth

            other_avail_threshold_sum += available_threshold
            other_value_of_similar_works_sum += value_of_similar_works
            #other_maximum_span_length_of_bridge_avail_sum += maximum_span_length_of_bridge_avail
            other_average_annual_turn_over_sum += average_annual_turn_over
            other_net_worth_sum += net_worth

        
        result_dict['other_avail_threshold_sum'] = format(other_avail_threshold_sum, '.2f')
        result_dict['other_value_of_similar_works_sum'] = format(other_value_of_similar_works_sum, '.2f')
        result_dict['other_maximum_span_length_of_bridge_avail_sum'] = format(other_maximum_span_length_of_bridge_avail_sum, '.2f')
        result_dict['other_average_annual_turn_over_sum'] = format(other_average_annual_turn_over_sum, '.2f')
        result_dict['other_net_worth_sum'] = format(other_net_worth_sum, '.2f')
            

        result_dict['combined_threshold'] = format(other_avail_threshold_sum + available_threshold_lead_member, '.2f')
        result_dict['combined_value_of_similar_works'] = format(other_value_of_similar_works_sum + value_of_similar_works_lead_member, '.2f')
        result_dict['combined_maximum_span_length_of_bridge_avail'] = format(other_maximum_span_length_of_bridge_avail_sum + maximum_span_length_of_bridge_avail_lead_member, '.2f')
        result_dict['combined_average_annual_turn_over'] = format(other_average_annual_turn_over_sum + average_annual_turn_over_lead_member, '.2f')
        result_dict['combined_net_worth'] = format(other_net_worth_sum + net_worth_lead_member, '.2f')


        combined_threshold = other_avail_threshold_sum + available_threshold_lead_member
        combined_value_of_similar_works = other_value_of_similar_works_sum + value_of_similar_works_lead_member
        combined_maximum_span_length_of_bridge_avail = other_maximum_span_length_of_bridge_avail_sum + maximum_span_length_of_bridge_avail_lead_member
        combined_average_annual_turn_over = other_average_annual_turn_over_sum + average_annual_turn_over_lead_member
        combined_net_worth = other_net_worth_sum + net_worth_lead_member


        if combined_threshold >= float(threshold_data.value):
            result_dict['threshold_success'] = True
        else:
            result_dict['threshold_success'] = False


        if combined_value_of_similar_works >= float(similar_work_data.value):
            result_dict['similar_work_success'] = True
        else:
            result_dict['similar_work_success'] = False


        if combined_maximum_span_length_of_bridge_avail >= float(bid_capacity_data.value):
            result_dict['bid_capacity_success'] = True
        else:
            result_dict['bid_capacity_success'] = False

        if combined_average_annual_turn_over >= float(turnover_data.value):
            result_dict['turnover_success'] = True
        else:
            result_dict['turnover_success'] = False

        if combined_net_worth >= float(net_worth_data.value):
            result_dict['net_worth_success'] = True
        else:
            result_dict['net_worth_success'] = False

        jv_partys = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                 form__form_internal_name='party_name_percentage_share')
        
        jv_analytics = []
        for jv in jv_partys:
            jv_dict = {}
            per_query = TenderData.cmobjects.filter(tender_id=tender_id, \
                                                        form__form_internal_name='jv_share__details',\
                                                            by_order=jv.by_order).first()
            if per_query:
                jv_dict['party_name'] = jv.value
                
                jv_dict['percentage_share'] = str(per_query.value) + " %"
                jv_analytics.append(jv_dict)

        result_dict['jv_share_analytics'] = jv_analytics

        result.append(result_dict)



        return Response({'result': result}, status=status.HTTP_200_OK)
