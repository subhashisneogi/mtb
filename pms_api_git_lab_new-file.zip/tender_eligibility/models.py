from django.db import models
from tender.models import *
from custom_management.models import *


class TechnicalEligibility(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='TE_organization',on_delete=models.CASCADE, blank=True, null=True)
    form = models.ForeignKey(FormMaster, related_name="TE_formmaster",on_delete=models.CASCADE)
    value_character=models.CharField(max_length=200, blank=True, null=True) 
    document= models.FileField(
        upload_to='TechnicalEligibility/', null=True, blank=True, help_text='documents')
    tender_id = models.ForeignKey(Tender, related_name='TE_tender', on_delete=models.CASCADE, blank=True, null=True)
    
    # upload_file = models.FileField(upload_to='technical_eligibility/', blank=True)
class FinancialEligibility(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='FE_organization',on_delete=models.CASCADE, blank=True, null=True)
    form = models.ForeignKey(FormMaster, related_name="FE_formmaster",on_delete=models.CASCADE)
    value_character=models.CharField(max_length=200, blank=True, null=True) 
    tender_id = models.ForeignKey(Tender, related_name='FE_tender', on_delete=models.CASCADE, blank=True, null=True)



class SpecialEligibility(BaseAbstractStructure):
    organization = models.ForeignKey(Organization, related_name='SE_organization',on_delete=models.CASCADE, blank=True, null=True)
    form = models.ForeignKey(FormMaster, related_name="SE_formmaster",on_delete=models.CASCADE)
    value_character=models.CharField(max_length=200, blank=True, null=True) 
    tender_id = models.ForeignKey(Tender, related_name='SE_tender', on_delete=models.CASCADE, blank=True, null=True)
