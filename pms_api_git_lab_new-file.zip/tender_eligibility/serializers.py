from rest_framework import serializers
from .models import *
from administrations.models import *
class TechnicalEligibilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = TechnicalEligibility
        fields = "__all__"



class FinancialEligibilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = FinancialEligibility
        fields = "__all__"



class SpecialEligibilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = SpecialEligibility
        fields = "__all__"
