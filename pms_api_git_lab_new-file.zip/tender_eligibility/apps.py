from django.apps import AppConfig


class TenderEligibilityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tender_eligibility'
