from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from .models import *
# Register your models here.
admin.site.register(TechnicalEligibility,ModelAdmin)
admin.site.register(FinancialEligibility,ModelAdmin)
admin.site.register(SpecialEligibility,ModelAdmin)