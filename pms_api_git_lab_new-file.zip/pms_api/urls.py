"""pms_api URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include , re_path

from django.conf import settings
from django.conf.urls.static import static
from django.views.static import serve
# from django.conf.urls import url
from filebrowser.sites import site
from rest_framework.routers import DefaultRouter
from push_notifications.api.rest_framework import APNSDeviceAuthorizedViewSet, GCMDeviceAuthorizedViewSet,WebPushDeviceAuthorizedViewSet,WNSDeviceAuthorizedViewSet

router = DefaultRouter()
router.register(r'device/apns', APNSDeviceAuthorizedViewSet, basename="apns-device")
router.register(r'device/gcm', GCMDeviceAuthorizedViewSet, basename="gcm-device")
router.register(r'device/web', WebPushDeviceAuthorizedViewSet, basename="web-device")
router.register(r'device/wns', WNSDeviceAuthorizedViewSet, basename="wns-device")

urlpatterns=[]
if not settings.USE_S3:
    urlpatterns.append(re_path(r'^media/(?P<path>.*)$', serve,{'document_root': settings.MEDIA_ROOT}))
urlpatterns += [
    path("i18n/", include("django.conf.urls.i18n")),
    path('summernote/', include('django_summernote.urls')),
    path('filebrowser/', site.urls),
    path('admin/', admin.site.urls),
    re_path(r'^static/(?P<path>.*)$', serve,{'document_root': settings.STATIC_ROOT}),
    path('', include('administrations.urls')),
    path('', include('adminpanel.urls')),
    path('', include('attendance.urls')),
    path('', include('custom_management.urls')),
    path('', include('user_permissions.urls')),
    path('', include('user_profile.urls')),
    path('', include('tender.urls')),
    path('', include('email_config.urls')),
    path('', include('tender_eligibility.urls')),
    path('', include('insurance.urls')),
    path('', include('hrms_leave.urls')),
    path('', include('plant_machinery.urls')),
    path('', include('vendor.urls')),
    path('', include('project_and_planning.urls')),
    path('', include('material_master.urls')),
    path('', include('procurement.urls')),
    path('', include('labour_master.urls')),
    path('', include('indirect_cost_master.urls')),
    path('', include('boq.urls')),
    path('', include('misc.urls')),
    path('', include('accounts.urls')),
    path('app-versions/', include('mobile_app_version.urls')),
    path('app-controls/', include('mobile_app_version.adminapi.urls')),
    path('', include(router.urls)),

]

