try:
    import pymysql
    pymysql.install_as_MySQLdb()
except ImportError as e:
    pass