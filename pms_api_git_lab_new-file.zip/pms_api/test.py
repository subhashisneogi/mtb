a = ["A", "B", "C", "D", "D", "B", "E", "E"]

def countX(lst):
    d = {x:lst.count(x) for x in lst}
    return d


print(countX(a))