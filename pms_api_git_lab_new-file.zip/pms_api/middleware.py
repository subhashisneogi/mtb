import json
import os
import psutil
import sys
import datetime
import ast

from django.apps import apps
from django.utils.deprecation import MiddlewareMixin
from django.template.defaultfilters import *
from django.db import transaction
from django.db import connection
from django.template import Template, Context
from administrations.models import *
from email_config.models import EmailSend, EmailTemplates
from misc.models import *
from rest_framework.exceptions import APIException

from packaging.version import parse as parse_version
from rest_framework import status
from django.http import JsonResponse

from mobile_app_version.messages import REQUIRED_HEADERS_NOT_SENT
from mobile_app_version.messages import UNSUPPORTED_PLATFORM_MESSAGE
from mobile_app_version.messages import UPGRADE_TO_LATEST_VERSION_MESSAGE
from mobile_app_version.models import MobileAppVersion
from mobile_app_version.serializers import MobileAppVersionSerializer

class CommonMiddleware(MiddlewareMixin):
    def process_response(self, request, response):
        '''
        notify_user_list: {
            "email_list": [1,2,3],
            "sms_list": [3,4,2,5],
            "context": {
                "action": "create",
                "ref_type": "mr",
                "ref_id": 9,
                "ref_link": "test@xyz.in"
            }
        }
        '''
        if response.status_code == 200:
            try:
                notify_user_list = None
                if hasattr(request,'POST'):
                    request_data = request.POST
                    if 'notify_user_list' in request_data:
                        notify_user_list = request_data['notify_user_list']
                        if isinstance(notify_user_list, str):
                            notify_user_list = json.loads(notify_user_list)
                if notify_user_list is None:
                    request_data = getattr(request, '_body', request.body)
                    if request_data:
                        request_data = json.loads(request_data)
                        if 'notify_user_list' in request_data:
                            notify_user_list = request_data['notify_user_list']
                            if isinstance(notify_user_list, str):
                                notify_user_list = json.loads(notify_user_list)
                if notify_user_list is not None:
                    email_list = notify_user_list["email_list"]
                    sms_list = notify_user_list["sms_list"]
                    context = notify_user_list["context"]
                    with transaction.atomic():
                            # send sms
                        for user_id in email_list:
                            if PmsUser.objects.filter(id=user_id).exists():
                                link = 0
                                user = PmsUser.objects.filter(id=user_id).first()
                                if EmailTemplates.cmobjects.filter(template_name='Notify User').exists():
                                    email_template = EmailTemplates.cmobjects.get(template_name='Notify User')
                                    htmly = Template(email_template.body)
                                    email_context = context
                                    email_context["name"] = user.first_name + " " + user.last_name
                                    message = htmly.render(Context(email_context))
                                    email_link = EmailSend.cmobjects.create(
                                        to_email = user.email,
                                        template = email_template,
                                        processed_message = message
                                    )
                                    link = email_link.id
                                NotifyUser.objects.create(
                                    type = "email",
                                    user_id = user_id,
                                    context = context,
                                    link = link,
                                )
                        for user_id in sms_list:
                            if PmsUser.objects.filter(id=user_id).exists():
                                NotifyUser.objects.create(
                                    type = "sms",
                                    user_id = user_id,
                                    context = context,
                                    link = 0,
                                )
            except Exception as e:
                print(e)
        return response


class MemoryUsageMiddleware(MiddlewareMixin):
    def process_request(self, request):
        request._mem = psutil.Process(os.getpid()).memory_info()
        request._start_time = datetime.now()
        request.request_params = json.dumps(request.GET)
        request.request_body = ''
        try:
            request.request_body = str(request.body.decode('utf-8'))
        except Exception as e:
            pass

    def process_response(self, request, response):
        try:
            if not request.path.startswith('/admin/'):
                # print(connection.queries)
                mem = psutil.Process(os.getpid()).memory_info()
                RequestLog.objects.create(
                    created_by = getattr(request,'user',None),
                    request_type = request.method.upper(),
                    request_path = request.path,
                    request_params = request.request_params,
                    request_body = request.request_body if not str(response.status_code).startswith('2') else '',
                    request_start_time = request._start_time.strftime("%c"),
                    request_end_time = datetime.now().strftime("%c"),
                    query_count = length(connection.queries),
                    query_execution_time = sum(float(item['time']) for item in connection.queries),
                    duration = datetime.now() - request._start_time,
                    memory_used = filesizeformat(mem.rss - request._mem.rss),
                    response_size = filesizeformat(len(response.content)),
                    response_code = response.status_code,
                    response_details = str(response.content) if not str(response.status_code).startswith('2') else '',
                )
        except Exception as e:
            print(e)
        return response


class DebugQueryParamMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        debug_param = request.GET.get('my_debug')
        if debug_param == 'true':
            settings.DEBUG = True
        elif request.path.startswith("/admin/"):
            settings.DEBUG = True
        else:
            settings.DEBUG = bool(int(str(os.getenv('DEBUG','0'))))

        response = self.get_response(request)
        return response


class AppVersionControlMiddleware(MiddlewareMixin):
    def process_request(self, request):
        if bool(int(str(os.getenv('VERSION_CHECK','0')))):
            # if request.path.startswith("/admin/"):
            #     return
            app_platform = request.headers.get("App-Platform", None)
            app_version = request.headers.get("App-Version", None)
            if app_platform or app_version:
                supported_platforms = MobileAppVersion.PlatformType.values
                app_platform = app_platform.upper() if app_platform else app_platform
                if not (app_platform and app_version):
                    return JsonResponse(data={
                        "success": False,
                        "message": REQUIRED_HEADERS_NOT_SENT
                    }, status=status.HTTP_400_BAD_REQUEST)

                if app_platform not in supported_platforms:
                    return JsonResponse(data={
                        "success": False,
                        "message": UNSUPPORTED_PLATFORM_MESSAGE,
                    }, status=status.HTTP_400_BAD_REQUEST)

                last_force_update_version = MobileAppVersion.objects.filter(platform_type=app_platform,
                                                                            forcing_update=True).last().version
                if parse_version(app_version) < parse_version(last_force_update_version):
                    latest_app_version = MobileAppVersion.objects.filter(platform_type=app_platform).last()
                    if latest_app_version:
                        app_serializer = MobileAppVersionSerializer(latest_app_version)
                        return JsonResponse(data={
                            "success": False,
                            "message": UPGRADE_TO_LATEST_VERSION_MESSAGE,
                            "data": {
                                "force-update-to": app_serializer.data,
                            },
                        }, status=420)

from rest_framework.views import exception_handler

def flatten_errors(data, parent_key="", sep=": "):
    result = {}
    if isinstance(data, dict):
        for key, value in data.items():
            new_key = f"{parent_key}{sep}{key}" if parent_key else key
            result.update(flatten_errors(value, new_key, sep))
    elif isinstance(data, list):
        for index, value in enumerate(data):
            new_key = f"{parent_key}"
            result.update(flatten_errors(value, new_key, sep))
    else:
        result[parent_key] = data
    return result

def unwrap_msg(value):
    while isinstance(value, str):
        try:
            parsed = ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return value
        if isinstance(parsed, dict) and 'msg' in parsed:
            value = parsed['msg']
        else:
            return value
    return value

def custom_exception_handler(exc, context):
    response = exception_handler(exc, context)
    if response is not None:
        resp = []
        response.data['status_code'] = response.status_code
        if 'detail' in response.data:
            resp.append(f'{response.data['detail']}')
        if 'msg' in response.data:
            obj = flatten_errors(response.data['msg'])
            if isinstance(obj, dict):
                for k, v in obj.items():
                    v = unwrap_msg(v)
                    if isinstance(v, list):
                        for ve in v:
                            resp.append(f'{f'{k}: ' if k else ''}{ve}')
                    else:
                        resp.append(f'{f'{k}: ' if k else ''}{v}')
            else:
                resp.append(f'{obj}')
        response.data['msg'] = ', '.join(resp)
    return response