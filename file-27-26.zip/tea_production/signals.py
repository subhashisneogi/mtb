from django.db.models.signals import pre_save
from django.dispatch import receiver
from django.core.exceptions import ValidationError
from .models import TeaGradeDetails
from rest_framework.exceptions import APIException
# @receiver(pre_save, sender=TeaGradeDetails)
# def validate_unique_tea_grade(sender, instance, **kwargs):
#     if instance.is_deleted:
#         return  # ignore deleted records

#     qs = TeaGradeDetails.objects.filter(
#         tea_type=instance.tea_type,
#         grade__iexact=instance.grade,
#         is_deleted=False
#     )

#     # Exclude self when updating
#     if instance.pk:
#         qs = qs.exclude(pk=instance.pk)

#     if qs.exists():
#         raise APIException("Tea Grade is already booked.")
