from django.shortcuts import render, redirect
from django.contrib import messages
from django.urls import reverse
from django import forms as django_forms
from django.db.models import Q
from django.http import JsonResponse
from django.db.models.functions import Coalesce
from django.db.models import Sum, Count, Value, OuterRef, Subquery, IntegerField, Prefetch
from django.template.loader import render_to_string
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.contrib.auth import get_user_model
User = get_user_model()
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView, DetailView, UpdateView, CreateView
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.paginator import Paginator , EmptyPage, PageNotAnInteger
import openpyxl
from django.http import HttpResponse
from openpyxl.utils import get_column_letter
from django.db import transaction
from django.http import HttpResponse
from datetime import datetime
from master.common import CommonMixin
from .models import *
from .forms import *
from accounts.forms import *
from gardens_managment.models import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from weighment_supply.models import *
from master.utils import *
from django.template import loader
from django.utils import timezone
import pytz
from master.decorators import *
from django.template.loader import get_template
from xhtml2pdf import pisa   
from .helpers import *
import datetime
from decimal import Decimal, InvalidOperation
import requests
from django.urls import resolve
from urllib.parse import quote
import pandas as pd
import fuzzymatcher
from django.db.models import Q
import math
import numpy as np
import requests
import certifi
import fuzzymatcher
from .serializers import *
from .aggregator_api_models import SupplyManagement, GrowerDetailsSupply, PluckingData
from user_profile.blf_api_models import SupplierExit
from leaf_receipt.models import LeafManagement, LeafCollection
from vehicle_management.models import VehicleManagement


def _profile_type_name(user):
	profile = getattr(user, "profile", None)
	if profile and getattr(profile, "user_type", None):
		return str(profile.user_type.name).lower()
	profile = Profile.cmobjects.filter(user=user).select_related("user_type").first()
	return str(profile.user_type.name).lower() if profile and profile.user_type else ""


def _is_admin_user(user):
	return bool(user and (user.is_superuser or _profile_type_name(user) in ("admin", "super admin", "superadmin")))


def _can_access_challan_process(request):
	if not request.user.is_authenticated:
		return False
	return _is_admin_user(request.user) or _is_blf_user(request.user)


def _is_blf_user(user):
	return _profile_type_name(user) == "blf"


def _is_supply_supplier_user(user):
	return _profile_type_name(user) in ("grower", "aggregator")


def _can_access_supply_management(request):
	if not request.user.is_authenticated:
		return False
	return _is_admin_user(request.user) or _is_blf_user(request.user) or _is_supply_supplier_user(request.user)


def _can_manage_supply_management(request):
	if not request.user.is_authenticated:
		return False
	return _is_admin_user(request.user) or _is_blf_user(request.user)


def _logged_blf_profile(request):
	return BlfProfile.cmobjects.filter(user=request.user).first()


def _supply_status(supply):
	if SupplierExit.cmobjects.filter(weighment_txn__supply_challan=supply).exists():
		return "Closed"
	if supply.is_weighment_proceed:
		return "Processed"
	return "Pending"


def _supply_created_by_blf(supply):
	return bool(supply.updated_by_id and supply.created_by_id != supply.updated_by_id and _is_blf_user(supply.updated_by))


def _decorate_supply_items(items, include_status=True):
	for item in items:
		if include_status:
			item.display_status = _supply_status(item)
		item.is_created_by_blf = _supply_created_by_blf(item)
	return items


def _accessible_supply_qs(request):
	queryset = SupplyManagement.cmobjects.select_related(
		"consumer",
		"consumer__profile",
		"consumer__profile__user_type",
		"alloted_vehicle",
		"created_by",
		"created_by__profile",
		"created_by__profile__user_type",
		"updated_by",
		"updated_by__profile",
		"updated_by__profile__user_type",
	).prefetch_related("supply_id__grower").order_by("-created_at", "-id")
	
	if _is_admin_user(request.user):
		return queryset
	if _is_blf_user(request.user):
		return queryset.filter(consumer=request.user)
	if _is_supply_supplier_user(request.user):
		return queryset.filter(created_by=request.user)
	return queryset.none()


def _accessible_grower_qs(request):
	qs = GrowerProfile.cmobjects.select_related("user").prefetch_related("associated_entity", "associated_aggregator")
	if _is_admin_user(request.user):
		return qs.all()
	blf = _logged_blf_profile(request)
	if blf:
		return qs.filter(Q(associated_blf=blf) | Q(associated_entity=blf)).distinct()
	return qs.none()


def _accessible_aggregator_qs(request):
	qs = AggregatorProfile.cmobjects.select_related("user").prefetch_related("associated_entity")
	if _is_admin_user(request.user):
		return qs.all()
	blf = _logged_blf_profile(request)
	if blf:
		return qs.filter(Q(associated_blf=blf) | Q(associated_entity=blf)).distinct()
	return qs.none()


def _supplier_blf_profile(supplier):
	if not supplier:
		return None
	blf = getattr(supplier, "associated_blf", None)
	if blf:
		return blf
	if hasattr(supplier, "associated_entity"):
		return supplier.associated_entity.select_related("user").first()
	return None


def _supplier_consumer_user(request, supplier, selected_blf=None):
	if selected_blf and selected_blf.user_id:
		return selected_blf.user
	if _is_blf_user(request.user):
		return request.user
	if hasattr(supplier, "associated_entity"):
		blf = supplier.associated_entity.select_related("user").first()
		return blf.user if blf else request.user
	return request.user


def _challan_process_blf_list():
	challan_count = (
		WeighmentSupply.cmobjects
		.filter(
			created_by_id=OuterRef("user_id"),
			weignment_supply_txn_id__isnull=False,
			available_weighment_id__isnull=False,
		)
		.values("created_by_id")
		.annotate(total=Count("id"))
		.values("total")
	)
	return (
		BlfProfile.cmobjects
		.select_related("user")
		.only("id", "entity_unit", "entity_name", "email", "user_id", "user__username")
		.annotate(challan_count=Coalesce(Subquery(challan_count[:1], output_field=IntegerField()), Value(0)))
		.order_by("entity_unit")
	)


def _selected_challan_process_blf(request):
	if _is_admin_user(request.user):
		blf_id = request.GET.get("blf_user") or request.POST.get("blf_user")
		if not blf_id:
			return None
		return BlfProfile.cmobjects.select_related("user").filter(pk=blf_id).first()
	return BlfProfile.cmobjects.select_related("user").filter(user=request.user).first()


def _challan_process_owner_user(request):
	selected_blf = _selected_challan_process_blf(request)
	if selected_blf and selected_blf.user_id:
		return selected_blf.user
	if _is_admin_user(request.user):
		return None
	return request.user


def _challan_process_context_query(request):
	query = {}
	blf_id = request.GET.get("blf_user") or request.POST.get("blf_user")
	mode = request.GET.get("mode") or request.POST.get("mode")
	if blf_id:
		query["blf_user"] = blf_id
	if mode:
		query["mode"] = mode
	if not query:
		return ""
	return "?" + "&".join(f"{key}={value}" for key, value in query.items())


def _challan_process_queryset(request, owner_user=None, allow_all_for_admin=False):
	owner_user = owner_user if owner_user is not None else _challan_process_owner_user(request)
	queryset = WeighmentSupply.cmobjects.select_related(
		"supplier",
		"supplier__profile",
		"supplier__profile__user_type",
		"supply_challan",
		"vehicle_no",
		"created_by",
	).filter(
		weignment_supply_txn_id__isnull=False,
		available_weighment_id__isnull=False,
	).distinct().order_by("-id")
	if owner_user:
		queryset = queryset.filter(created_by=owner_user)
	elif _is_admin_user(request.user) and allow_all_for_admin:
		return queryset
	else:
		queryset = queryset.none()
	return queryset


def _supplier_choices_for_challan_process(request, current_user_id=None, owner_blf=None, limit=80):
	owner_blf = owner_blf if owner_blf is not None else _selected_challan_process_blf(request)
	if owner_blf:
		aggregators = AggregatorProfile.cmobjects.select_related("user").filter(associated_entity=owner_blf).only("user_id", "name", "user__username").distinct().order_by("name")
		growers = GrowerProfile.cmobjects.select_related("user").filter(associated_entity=owner_blf).only("user_id", "name", "user__username").distinct().order_by("name")
	elif _is_admin_user(request.user):
		aggregators = AggregatorProfile.cmobjects.none()
		growers = GrowerProfile.cmobjects.none()
	else:
		aggregators = AggregatorProfile.cmobjects.select_related("user").filter(associated_entity__user=request.user).only("user_id", "name", "user__username").distinct().order_by("name")
		growers = GrowerProfile.cmobjects.select_related("user").filter(associated_entity__user=request.user).only("user_id", "name", "user__username").distinct().order_by("name")
	choices = []
	per_group_limit = max(int(limit / 2), 1) if limit else None
	if per_group_limit:
		aggregators = aggregators[:per_group_limit]
		growers = growers[:per_group_limit]
	for profile in aggregators:
		if profile.user_id:
			choices.append((profile.user_id, f"Aggregator - {profile.name or profile.user.username}", "aggregator"))
	for profile in growers:
		if profile.user_id:
			choices.append((profile.user_id, f"Grower - {profile.name or profile.user.username}", "grower"))
	if current_user_id and str(current_user_id) not in {str(user_id) for user_id, _label, _supplier_type in choices}:
		aggregator = AggregatorProfile.cmobjects.select_related("user").only("user_id", "name", "user__username").filter(user_id=current_user_id).first()
		grower = None if aggregator else GrowerProfile.cmobjects.select_related("user").only("user_id", "name", "user__username").filter(user_id=current_user_id).first()
		if aggregator and aggregator.user_id:
			choices.append((aggregator.user_id, f"Aggregator - {aggregator.name or aggregator.user.username}", "aggregator"))
		elif grower and grower.user_id:
			choices.append((grower.user_id, f"Grower - {grower.name or grower.user.username}", "grower"))
	return choices


def _decimal_or_zero(value):
	if value in (None, ""):
		return Decimal("0")
	try:
		return Decimal(str(value))
	except (InvalidOperation, ValueError):
		return Decimal("0")


def _decimal_2(value):
	return _decimal_or_zero(value).quantize(Decimal("0.01"))


def _supply_gross_weight(supply):
	return _decimal_2(getattr(supply, "gross_leaf", None) or getattr(supply, "quantity", None) or 0)


def _challan_supply_supplier_type(supply):
	if AggregatorProfile.cmobjects.filter(user=supply.created_by).exists():
		return "aggregator"
	return "grower"


class ChallanProcessForm(django_forms.Form):
	supplier = django_forms.ChoiceField(required=True)
	supplier_type = django_forms.ChoiceField(choices=(("aggregator", "Aggregator"), ("grower", "Grower")), required=True)
	supply_challan = django_forms.ModelChoiceField(queryset=SupplyManagement.cmobjects.none(), required=True, empty_label="Select challan")
	mode_of_supply = django_forms.ChoiceField(choices=WeighmentSupply.supply_option, required=False)
	supply_date = django_forms.DateField(required=True, widget=django_forms.DateInput(attrs={"type": "date"}))
	vehicle_no = django_forms.ModelChoiceField(queryset=VehicleManagement.cmobjects.none(), required=False, empty_label="Select vehicle")
	total_gross_weight_kg = django_forms.DecimalField(required=True, min_value=Decimal("0"), max_digits=12, decimal_places=2)
	tare_weight_kg = django_forms.DecimalField(required=True, min_value=Decimal("0"), max_digits=12, decimal_places=2)
	weighment_net_weight = django_forms.DecimalField(required=False, min_value=Decimal("0"), max_digits=12, decimal_places=2)
	mobile_number = django_forms.CharField(required=False, max_length=17)
	deduction = django_forms.DecimalField(required=True, min_value=Decimal("0"), max_value=Decimal("100"), max_digits=5, decimal_places=2)
	final_leaf_count = django_forms.DecimalField(required=True, min_value=Decimal("0"), max_value=Decimal("100"), max_digits=5, decimal_places=2)
	net_leaf_weight = django_forms.DecimalField(required=True, min_value=Decimal("0"), max_digits=12, decimal_places=2)
	rate = django_forms.DecimalField(required=False, min_value=Decimal("0"), max_digits=12, decimal_places=2)
	quality_standard = django_forms.ChoiceField(choices=LeafManagement.QUALITY_STANDARD, required=True)
	acknowledge_status = django_forms.ChoiceField(choices=LeafManagement.ACKNOWLEDGE_STATUS, required=True)
	unloaded_vehicle_weight = django_forms.DecimalField(required=True, min_value=Decimal("0"), max_digits=12, decimal_places=2)
	is_released = django_forms.ChoiceField(choices=SupplierExit.released_option, required=True)

	def __init__(self, *args, **kwargs):
		self.request = kwargs.pop("request")
		self.owner_blf = kwargs.pop("owner_blf", None)
		self.owner_user = kwargs.pop("owner_user", None)
		super().__init__(*args, **kwargs)
		self.fields["supply_date"].input_formats = ["%Y-%m-%d"]
		self.fields["supply_date"].widget.format = "%Y-%m-%d"
		self.fields["supplier"].label = "Supplier"
		self.fields["supplier_type"].label = "Supplier Type"
		self.fields["supply_challan"].label = "Supply Challan"
		self.fields["mode_of_supply"].label = "Mode of Supply"
		self.fields["supply_date"].label = "Date of Supply"
		self.fields["vehicle_no"].label = "Vehicle Number"
		self.fields["total_gross_weight_kg"].label = "Gross Weight (Kgs)"
		self.fields["tare_weight_kg"].label = "Tare Weight (Kgs)"
		self.fields["weighment_net_weight"].label = "Net Weight (Kgs)"
		self.fields["mobile_number"].label = "Mobile Number"
		self.fields["deduction"].label = "Deduction %"
		self.fields["final_leaf_count"].label = "Final Leaf %"
		self.fields["net_leaf_weight"].label = "Final Weight (Kgs)"
		self.fields["rate"].label = "Rate"
		self.fields["quality_standard"].label = "Quality Standard"
		self.fields["acknowledge_status"].label = "Acknowledgement Status"
		self.fields["unloaded_vehicle_weight"].label = "Unloaded Vehicle Weight"
		self.fields["is_released"].label = "Is Released?"
		current_supplier_id = self.data.get("supplier") or self.initial.get("supplier")
		self.supplier_choices = _supplier_choices_for_challan_process(self.request, current_user_id=current_supplier_id, owner_blf=self.owner_blf)
		self.valid_supplier_types = {
			str(user_id): choice_type for user_id, _label, choice_type in self.supplier_choices
		}
		self.fields["supplier"].choices = [("", "Select supplier")] + [
			(str(user_id), label) for user_id, label, _supplier_type in self.supplier_choices
		]
		current_challan_id = self.data.get("supply_challan") or self.initial.get("supply_challan")
		current_vehicle_id = self.data.get("vehicle_no") or self.initial.get("vehicle_no")
		if self.owner_user:
			supply_qs = SupplyManagement.cmobjects.filter(consumer=self.owner_user, is_weighment_proceed=False)
			vehicle_qs = VehicleManagement.cmobjects.filter(created_by=self.owner_user, is_available=True)
		elif _is_admin_user(self.request.user):
			supply_qs = SupplyManagement.cmobjects.none()
			vehicle_qs = VehicleManagement.cmobjects.none()
		else:
			supply_qs = SupplyManagement.cmobjects.filter(consumer=self.request.user, is_weighment_proceed=False)
			vehicle_qs = VehicleManagement.cmobjects.filter(created_by=self.request.user, is_available=True)
		supply_ids = list(supply_qs.order_by("-id").values_list("id", flat=True)[:80])
		if current_challan_id:
			supply_ids.append(current_challan_id)
		vehicle_ids = list(vehicle_qs.order_by("vehicle_number").values_list("id", flat=True)[:80])
		if current_vehicle_id:
			vehicle_ids.append(current_vehicle_id)
		self.fields["supply_challan"].queryset = SupplyManagement.cmobjects.filter(id__in=supply_ids).only("id", "supply_challan_id").order_by("-id")
		self.fields["vehicle_no"].queryset = VehicleManagement.cmobjects.filter(id__in=vehicle_ids).only("id", "vehicle_number").order_by("vehicle_number")
		for field in self.fields.values():
			existing_class = field.widget.attrs.get("class", "")
			field.widget.attrs["class"] = f"{existing_class} form-control".strip()
			field.widget.attrs.setdefault("placeholder", field.label)
			if field.required:
				field.widget.attrs["required"] = "required"
		for name in ["total_gross_weight_kg", "tare_weight_kg", "weighment_net_weight", "deduction", "final_leaf_count", "net_leaf_weight", "rate", "unloaded_vehicle_weight"]:
			self.fields[name].widget.attrs.update({
				"step": "0.01",
				"inputmode": "decimal",
				"pattern": r"^\d+(\.\d{1,2})?$",
			})
		for name in ["supply_date", "supplier", "supplier_type", "supply_challan", "vehicle_no", "mode_of_supply", "mobile_number", "total_gross_weight_kg", "weighment_net_weight", "net_leaf_weight"]:
			existing_class = self.fields[name].widget.attrs.get("class", "")
			self.fields[name].widget.attrs["class"] = f"{existing_class} read-only".strip()
		for name in ["supply_date", "mobile_number", "total_gross_weight_kg", "weighment_net_weight", "net_leaf_weight"]:
			self.fields[name].widget.attrs["readonly"] = "readonly"
		for name in ["supplier", "supplier_type", "supply_challan", "vehicle_no", "mode_of_supply"]:
			self.fields[name].widget.attrs["tabindex"] = "-1"

	def clean(self):
		cleaned_data = super().clean()
		supplier = cleaned_data.get("supplier")
		supplier_type = cleaned_data.get("supplier_type")
		if supplier and self.valid_supplier_types.get(str(supplier)) != supplier_type:
			raise django_forms.ValidationError("Selected supplier does not match supplier type.")
		supply = cleaned_data.get("supply_challan")
		if supply:
			expected_supplier_type = _challan_supply_supplier_type(supply)
			gross_weight = _supply_gross_weight(supply)
			cleaned_data["supplier"] = str(supply.created_by_id)
			cleaned_data["supplier_type"] = expected_supplier_type
			cleaned_data["supply_date"] = supply.date_of_supply
			cleaned_data["vehicle_no"] = supply.alloted_vehicle
			cleaned_data["mobile_number"] = supply.mobile_number or cleaned_data.get("mobile_number")
			cleaned_data["total_gross_weight_kg"] = gross_weight
			if not cleaned_data.get("mode_of_supply"):
				cleaned_data["mode_of_supply"] = "Motorised 3 / 4 wheelers vehicle" if supply.alloted_vehicle_id else "By hand"
		total_gross = cleaned_data.get("total_gross_weight_kg") or 0
		tare_weight = cleaned_data.get("tare_weight_kg") or 0
		unloaded = cleaned_data.get("unloaded_vehicle_weight") or 0
		if total_gross < tare_weight:
			raise django_forms.ValidationError("Gross Weight must be greater than or equal to Tare Weight.")
		if unloaded > total_gross:
			raise django_forms.ValidationError("Unloaded vehicle weight cannot be more than total gross weight.")
		weighment_net_weight = _decimal_2(total_gross - tare_weight)
		deduction = cleaned_data.get("deduction") or Decimal("0")
		final_weight = _decimal_2(total_gross - (total_gross * deduction / Decimal("100")))
		cleaned_data["weighment_net_weight"] = weighment_net_weight
		cleaned_data["net_leaf_weight"] = final_weight
		return cleaned_data

	def api_payload(self):
		data = self.cleaned_data.copy()
		data.pop("weighment_net_weight", None)
		if data.get("supply_challan"):
			data["supply_challan"] = data["supply_challan"].id
		if data.get("vehicle_no"):
			data["vehicle_no"] = data["vehicle_no"].id
		return data


def _challan_process_form_initial(weighment):
	leaf_receipt = LeafManagement.cmobjects.filter(weighment_txn=weighment).order_by("-id").first()
	supplier_exit = SupplierExit.cmobjects.filter(weighment_txn=weighment).order_by("-id").first()
	return {
		"supplier": str(weighment.supplier_id) if weighment.supplier_id else "",
		"supplier_type": weighment.supplier_type,
		"supply_challan": weighment.supply_challan_id,
		"mode_of_supply": weighment.mode_of_supply,
		"supply_date": weighment.supply_date,
		"vehicle_no": weighment.vehicle_no_id,
		"total_gross_weight_kg": weighment.total_gross_weight_kg,
		"tare_weight_kg": weighment.tare_weight_kg,
		"weighment_net_weight": _decimal_2((weighment.total_gross_weight_kg or 0) - (weighment.tare_weight_kg or 0)),
		"mobile_number": weighment.mobile_number,
		"deduction": leaf_receipt.deduction if leaf_receipt else None,
		"final_leaf_count": leaf_receipt.final_leaf_count if leaf_receipt else None,
		"net_leaf_weight": leaf_receipt.net_leaf_weight if leaf_receipt else None,
		"rate": leaf_receipt.rate if leaf_receipt else None,
		"quality_standard": leaf_receipt.quality_standard if leaf_receipt else None,
		"acknowledge_status": leaf_receipt.acknowledge_status if leaf_receipt else None,
		"unloaded_vehicle_weight": supplier_exit.unloaded_vehicle_weight if supplier_exit else None,
		"is_released": supplier_exit.is_released if supplier_exit else None,
	}


def _challan_process_grower_rows(weighment):
	if not weighment or not weighment.supply_challan_id:
		return []
	rows = []
	for item in GrowerDetailsSupply.objects.filter(supply_id=weighment.supply_challan_id).select_related("grower").order_by("id"):
		rows.append({
			"name": item.grower.name if item.grower else "NA",
			"initial_weight": item.collected_quantity or item.supply_quantity or "NA",
			"final_weight": item.supply_quantity or item.collected_quantity or "NA",
		})
	return rows


def _challan_process_list_url(request):
	query = request.GET.copy()
	query.pop("next", None)
	url = reverse("user_profile:challan_process_list")
	if query.urlencode():
		return f"{url}?{query.urlencode()}"
	return url


def _challan_process_records_url(request):
	query = request.GET.copy()
	query.pop("next", None)
	url = reverse("user_profile:challan_process_records")
	if query.urlencode():
		return f"{url}?{query.urlencode()}"
	return url


def _supply_management_report_url(request):
	query = request.GET.copy()
	query.pop("next", None)
	url = reverse("user_profile:supply_management_report")
	if query.urlencode():
		return f"{url}?{query.urlencode()}"
	return url


def _supply_management_report_queryset(search_query, date_of_supply_from=None, date_of_supply_to=None, is_weighment_processed=None):
	queryset = _accessible_supply_qs(_supply_management_report_queryset.request)

	if search_query:
		queryset = queryset.filter(
			Q(supply_challan_id__icontains=search_query) |
			Q(supply_to__icontains=search_query) |
			Q(vehicle_option__icontains=search_query) |
			Q(alloted_vehicle__vehicle_number__icontains=search_query) |
			Q(gross_leaf__icontains=search_query) |
			Q(quantity__icontains=search_query) |
			Q(supply_bag_id__icontains=search_query) |
			Q(driver_name__icontains=search_query) |
			Q(mobile_number__icontains=search_query) |
			Q(consumer__username__icontains=search_query) |
			Q(created_by__username__icontains=search_query) |
			Q(created_by__profile__user_type__name__icontains=search_query)
		)
	if date_of_supply_from:
		queryset = queryset.filter(date_of_supply__gte=date_of_supply_from)
	if date_of_supply_to:
		queryset = queryset.filter(date_of_supply__lte=date_of_supply_to)
	if is_weighment_processed == "processed":
		queryset = queryset.filter(is_weighment_proceed=True)
	elif is_weighment_processed == "none_processed":
		queryset = queryset.filter(is_weighment_proceed=False)
	return queryset

@login_required
def supply_management_report(request):
	if not _can_access_supply_management(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	_supply_management_report_queryset.request = request
	search_query = request.GET.get("q", "").strip()
	date_of_supply_from = (request.GET.get("date_of_supply_from") or request.GET.get("date_from") or "").strip()
	date_of_supply_to = (request.GET.get("date_of_supply_to") or request.GET.get("date_to") or "").strip()
	is_weighment_processed = request.GET.get("is_weighment_processed", request.GET.get("is_weighment", "")).strip()
	page_mode = request.GET.get("mode", "").strip()
	is_manage_mode = page_mode == "manage"
	queryset = _supply_management_report_queryset(search_query, date_of_supply_from, date_of_supply_to, is_weighment_processed).prefetch_related(None)
	paginator = Paginator(queryset, 10)
	page_number = request.GET.get("page", 1)
	page_obj = paginator.get_page(page_number)
	_decorate_supply_items(page_obj.object_list, include_status=False)
	context = {
		"supply_list": page_obj.object_list,
		"page_obj": page_obj,
		"paginator": paginator,
		"is_paginated": page_obj.has_other_pages(),
		"search_query": search_query,
		"date_of_supply_from": date_of_supply_from,
		"date_of_supply_to": date_of_supply_to,
		"is_weighment_processed": is_weighment_processed,
		"list_url": reverse("user_profile:supply_management_report"),
		"current_list_url": _supply_management_report_url(request),
		"total_count": paginator.count,
		"can_manage_supply": _can_manage_supply_management(request),
		"page_mode": page_mode,
		"is_manage_mode": is_manage_mode,
		"show_add_supply": is_manage_mode and _is_blf_user(request.user),
		"export_enabled": bool(date_of_supply_from and date_of_supply_to),
	}
	if _is_ajax_request(request):
		return CommonMixin.render(request, "reports/_supply_management_table.html", context)
	return CommonMixin.render(request, "reports/supply_management_list.html", context)


def _challan_process_initial_from_supply(request, owner_user=None):
	supply_id = request.GET.get("supply_challan")
	if not supply_id:
		return {}
	supply_qs = _accessible_supply_qs(request).filter(is_weighment_proceed=False)
	if owner_user:
		supply_qs = supply_qs.filter(consumer=owner_user)
	supply = supply_qs.filter(pk=supply_id).first()
	if not supply:
		return {}
	supplier_type = _challan_supply_supplier_type(supply)
	gross_weight = _supply_gross_weight(supply)
	return {
		"supplier": str(supply.created_by_id) if supply.created_by_id else "",
		"supplier_type": supplier_type,
		"supply_challan": supply.pk,
		"supply_date": supply.date_of_supply,
		"vehicle_no": supply.alloted_vehicle_id,
		"mobile_number": supply.mobile_number,
		"mode_of_supply": "Motorised 3 / 4 wheelers vehicle" if supply.alloted_vehicle_id else "By hand",
		"total_gross_weight_kg": gross_weight,
		"weighment_net_weight": gross_weight,
		"net_leaf_weight": gross_weight,
	}

@login_required
def supply_management_report_detail(request, id):
	if not _can_access_supply_management(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	next_url = get_safe_next_url(request, reverse("user_profile:supply_management_report"))
	supply = _accessible_supply_qs(request).select_related(
		"consumer",
		"alloted_vehicle",
		"created_by",
		"created_by__profile",
		"created_by__profile__user_type",
	).filter(id=id).first()

	if not supply:
		messages.error(request, "Supply management data not found.")
		return redirect(next_url)

	grower_rows = GrowerDetailsSupply.cmobjects.filter(supply=supply).select_related(
		"grower",
		"grower__user",
	).order_by("id")
	grower_collected_total = Decimal("0")
	grower_supply_total = Decimal("0")
	for row in grower_rows:
		try:
			grower_collected_total += Decimal(str(row.collected_quantity or 0))
		except (InvalidOperation, ValueError):
			pass
		try:
			grower_supply_total += Decimal(str(row.supply_quantity or 0))
		except (InvalidOperation, ValueError):
			pass

	return CommonMixin.render(request, "reports/supply_management_detail.html", {
		"supply": supply,
		"grower_rows": grower_rows,
		"grower_collected_total": grower_collected_total,
		"grower_supply_total": grower_supply_total,
		"supply_status": _supply_status(supply),
		"is_created_by_blf": _supply_created_by_blf(supply),
		"can_manage_supply": _can_manage_supply_management(request),
		"next_url": next_url,
	})


def _aggregator_growers_for_supply(request, aggregator, selected_blf=None):
	if not aggregator:
		return GrowerProfile.cmobjects.none()
	qs = _accessible_grower_qs(request).prefetch_related(None).filter(associated_aggregator=aggregator).select_related("user").only("id", "name", "user__username").distinct().order_by("name")
	if _is_admin_user(request.user):
		if selected_blf:
			qs = qs.filter(Q(associated_blf=selected_blf) | Q(associated_entity=selected_blf))
		else:
			qs = GrowerProfile.cmobjects.none()
	return qs


def _grower_quantity_rows(grower_rows, existing_quantities=None):
	existing_quantities = existing_quantities or {}
	return [
		{"grower": grower, "quantity": existing_quantities.get(grower.pk, "")}
		for grower in grower_rows
	]


def _supply_option_label(profile):
	username = getattr(getattr(profile, "user", None), "username", "") or ""
	name = (getattr(profile, "name", None) or "").strip()
	return f"{name} ({username})" if name and username else name or username


@login_required
def supply_management_options(request):
	if not _can_manage_supply_management(request):
		return JsonResponse({"suppliers": [], "vehicles": []}, status=403)

	user_type = request.GET.get("user_type") or "grower"
	blf_id = request.GET.get("blf_entity")
	supplier_id = request.GET.get("supplier")
	selected_blf = BlfProfile.cmobjects.filter(pk=blf_id).first() if _is_admin_user(request.user) and blf_id else _logged_blf_profile(request)
	blf_filter = Q(associated_blf=selected_blf) | Q(associated_entity=selected_blf) if selected_blf else Q(pk__isnull=True)

	if user_type == "aggregator":
		supplier_qs = AggregatorProfile.cmobjects.select_related("user").filter(blf_filter).distinct().order_by("name")
	else:
		supplier_qs = GrowerProfile.cmobjects.select_related("user").filter(blf_filter).distinct().order_by("name")

	suppliers = [{"id": item.pk, "text": _supply_option_label(item)} for item in supplier_qs]
	vehicles = []
	if supplier_id:
		supplier = supplier_qs.filter(pk=supplier_id).first()
		if supplier and supplier.user_id:
			vehicles = [
				{"id": item.pk, "text": item.vehicle_number}
				for item in VehicleManagement.cmobjects.filter(
					created_by=supplier.user,
					is_available=True,
				).order_by("vehicle_number")
			]
	return JsonResponse({"suppliers": suppliers, "vehicles": vehicles})


def _supply_form_initial_from_instance(supply):
	user_type = "aggregator" if AggregatorProfile.cmobjects.filter(user=supply.created_by).exists() else "grower"
	initial = {
		"user_type": user_type,
		"date_of_supply": supply.date_of_supply,
		"quantity": supply.quantity or supply.gross_leaf,
		"vehicle_option": supply.vehicle_option,
		"alloted_vehicle": supply.alloted_vehicle_id,
		"driver_name": supply.driver_name,
		"mobile_number": supply.mobile_number,
	}
	if user_type == "aggregator":
		aggregator = AggregatorProfile.cmobjects.filter(user=supply.created_by).first()
		initial["aggregator"] = aggregator.pk if aggregator else None
		blf = _supplier_blf_profile(aggregator)
	else:
		grower = GrowerProfile.cmobjects.filter(user=supply.created_by).first()
		initial["grower"] = grower.pk if grower else None
		blf = _supplier_blf_profile(grower)
	if blf:
		initial["blf_entity"] = blf.pk
	return initial


# @login_required
# def supply_management_create(request):
# 	if not _can_manage_supply_management(request):
# 		messages.error(request, "You have no permission to create supply records.")
# 		return redirect(reverse("user_profile:supply_management_report"))
# 	selected_aggregator = None
# 	if request.method == "POST":
# 		form = SupplyManagementForm(request.POST, request=request)
# 		selected_aggregator = form.fields["aggregator"].queryset.filter(pk=request.POST.get("aggregator")).first()
# 		grower_rows = _aggregator_growers_for_supply(request, selected_aggregator, form.selected_blf)
# 		if form.is_valid():
# 			with transaction.atomic():
# 				user_type = form.cleaned_data["user_type"]
# 				if user_type == "grower":
# 					grower = form.cleaned_data["grower"]
# 					quantity = form.cleaned_data["quantity"]
# 					supply = SupplyManagement.objects.create(
# 						supply_to="Factory",
# 						consumer=_supplier_consumer_user(request, grower, form.cleaned_data.get("blf_entity")),
# 						vehicle_option=form.cleaned_data.get("vehicle_option") or "No",
# 						date_of_supply=form.cleaned_data["date_of_supply"],
# 						alloted_vehicle=form.cleaned_data.get("alloted_vehicle"),
# 						gross_leaf=str(quantity),
# 						quantity=str(quantity),
# 						driver_name=form.cleaned_data.get("driver_name"),
# 						mobile_number=form.cleaned_data.get("mobile_number"),
# 						created_by=grower.user,
# 						updated_by=request.user,
# 						challan_created_by=request.user,
# 					)
# 				else:
# 					aggregator = form.cleaned_data["aggregator"]
# 					total = 0
# 					rows = []
# 					for grower in grower_rows:
# 						value = (request.POST.get(f"grower_qty_{grower.pk}") or "").strip()
# 						if not value:
# 							continue
# 						try:
# 							qty = float(value)
# 						except ValueError:
# 							form.add_error(None, f"Invalid quantity for {grower.name or grower.user}.")
# 							break
# 						if qty <= 0:
# 							form.add_error(None, f"Quantity for {grower.name or grower.user} must be greater than 0.")
# 							break
# 						total += qty
# 						rows.append((grower, qty))
# 					if not form.errors:
# 						if total <= 0:
# 							form.add_error(None, "Enter at least one Grower quantity greater than 0.")
# 						else:
# 							supply = SupplyManagement.objects.create(
# 								supply_to="Factory",
# 								consumer=_supplier_consumer_user(request, aggregator, form.cleaned_data.get("blf_entity")),
# 								vehicle_option=form.cleaned_data.get("vehicle_option") or "No",
# 								date_of_supply=form.cleaned_data["date_of_supply"],
# 								alloted_vehicle=form.cleaned_data.get("alloted_vehicle"),
# 								gross_leaf=str(total),
# 								quantity=str(total),
# 								driver_name=form.cleaned_data.get("driver_name"),
# 								mobile_number=form.cleaned_data.get("mobile_number"),
# 								created_by=aggregator.user,
# 								updated_by=request.user,
# 								challan_created_by=request.user,
# 							)
# 							GrowerDetailsSupply.objects.bulk_create([
# 								GrowerDetailsSupply(
# 									supply=supply,
# 									grower=grower,
# 									collected_quantity=str(qty),
# 									supply_quantity=str(qty),
# 									collected_date=form.cleaned_data["date_of_supply"],
# 									created_by=request.user,
# 									updated_by=request.user,
# 								)
# 								for grower, qty in rows
# 							])
# 				if not form.errors:
# 					messages.success(request, "Supply record saved successfully. Challan is Pending.")
# 					return redirect(reverse("user_profile:supply_management_report"))
# 	else:
# 		initial = {
# 			"user_type": request.GET.get("user_type", "grower"),
# 			"date_of_supply": request.GET.get("date_of_supply") or timezone.now().date(),
# 			"blf_entity": request.GET.get("blf_entity") or None,
# 			"grower": request.GET.get("grower") or None,
# 			"aggregator": request.GET.get("aggregator") or None,
# 			"alloted_vehicle": request.GET.get("alloted_vehicle") or None,
# 			"quantity": request.GET.get("quantity") or None,
# 			"vehicle_option": request.GET.get("vehicle_option") or None,
# 		}
# 		form = SupplyManagementForm(initial=initial, request=request, selected_aggregator=selected_aggregator)
# 		if request.GET.get("aggregator"):
# 			selected_aggregator = form.fields["aggregator"].queryset.filter(pk=request.GET.get("aggregator")).first()
# 			if selected_aggregator:
# 				form.initial["aggregator"] = selected_aggregator.pk
# 				form.initial["user_type"] = "aggregator"
# 	grower_rows = _aggregator_growers_for_supply(request, selected_aggregator, form.selected_blf)
# 	return CommonMixin.render(request, "reports/supply_management_form.html", {
# 		"form": form,
# 		"form_title": "Add New Supply",
# 		"submit_label": "Submit",
# 		"selected_aggregator": selected_aggregator,
# 		"grower_rows": grower_rows,
# 		"grower_quantity_rows": _grower_quantity_rows(grower_rows),
# 		"is_edit": False,
# 		"show_blf_selector": request.user.is_superuser,
# 	})


@login_required
def supply_management_edit(request, id):
	if not _can_manage_supply_management(request):
		messages.error(request, "You have no permission to edit supply records.")
		return redirect(reverse("user_profile:supply_management_report"))
	supply = _accessible_supply_qs(request).filter(pk=id).first()
	if not supply:
		messages.error(request, "Supply management data not found.")
		return redirect(reverse("user_profile:supply_management_report"))
	initial = _supply_form_initial_from_instance(supply)
	if request.method == "GET" and _is_admin_user(request.user) and request.GET.get("blf_entity"):
		initial["blf_entity"] = request.GET.get("blf_entity")
		initial["grower"] = request.GET.get("grower") or None
		initial["aggregator"] = request.GET.get("aggregator") or None
	selected_aggregator = None
	if initial["user_type"] == "aggregator":
		selected_aggregator = _accessible_aggregator_qs(request).filter(pk=initial.get("aggregator")).first()
	if request.method == "POST":
		form = SupplyManagementForm(request.POST, request=request)
		selected_aggregator = form.fields["aggregator"].queryset.filter(pk=request.POST.get("aggregator")).first()
		grower_rows = _aggregator_growers_for_supply(request, selected_aggregator, form.selected_blf)
		if form.is_valid():
			with transaction.atomic():
				user_type = form.cleaned_data["user_type"]
				supply.supply_to = "Factory"
				supply.consumer = request.user
				supply.vehicle_option = form.cleaned_data.get("vehicle_option") or "No"
				supply.date_of_supply = form.cleaned_data["date_of_supply"]
				supply.alloted_vehicle = form.cleaned_data.get("alloted_vehicle")
				supply.driver_name = form.cleaned_data.get("driver_name")
				supply.mobile_number = form.cleaned_data.get("mobile_number")
				supply.updated_by = request.user
				if user_type == "grower":
					grower = form.cleaned_data["grower"]
					quantity = form.cleaned_data["quantity"]
					supply.created_by = grower.user
					supply.consumer = _supplier_consumer_user(request, grower, form.cleaned_data.get("blf_entity"))
					supply.gross_leaf = str(quantity)
					supply.quantity = str(quantity)
					supply.save()
					supply.supply_id.all().delete()
				else:
					aggregator = form.cleaned_data["aggregator"]
					total = 0
					rows = []
					for grower in grower_rows:
						value = (request.POST.get(f"grower_qty_{grower.pk}") or "").strip()
						if not value:
							continue
						try:
							qty = float(value)
						except ValueError:
							form.add_error(None, f"Invalid quantity for {grower.name or grower.user}.")
							break
						if qty <= 0:
							form.add_error(None, f"Quantity for {grower.name or grower.user} must be greater than 0.")
							break
						total += qty
						rows.append((grower, qty))
					if not form.errors and total <= 0:
						form.add_error(None, "Enter at least one Grower quantity greater than 0.")
					if not form.errors:
						supply.created_by = aggregator.user
						supply.consumer = _supplier_consumer_user(request, aggregator, form.cleaned_data.get("blf_entity"))
						supply.gross_leaf = str(total)
						supply.quantity = str(total)
						supply.save()
						supply.supply_id.all().delete()
						GrowerDetailsSupply.objects.bulk_create([
							GrowerDetailsSupply(
								supply=supply,
								grower=grower,
								collected_quantity=str(qty),
								supply_quantity=str(qty),
								collected_date=form.cleaned_data["date_of_supply"],
								created_by=request.user,
								updated_by=request.user,
							)
							for grower, qty in rows
						])
				if not form.errors:
					messages.success(request, "Supply record updated successfully.")
					return redirect(reverse("user_profile:supply_management_report"))
	else:
		form = SupplyManagementForm(initial=initial, request=request, selected_aggregator=selected_aggregator)
		if initial.get("aggregator"):
			selected_aggregator = form.fields["aggregator"].queryset.filter(pk=initial.get("aggregator")).first()
	grower_rows = _aggregator_growers_for_supply(request, selected_aggregator, form.selected_blf)
	existing_quantities = {row.grower_id: row.supply_quantity for row in supply.supply_id.all()}
	return CommonMixin.render(request, "reports/supply_management_form.html", {
		"form": form,
		"form_title": "Edit Supply",
		"submit_label": "Update",
		"selected_aggregator": selected_aggregator,
		"grower_rows": grower_rows,
		"grower_quantity_rows": _grower_quantity_rows(grower_rows, existing_quantities),
		"existing_quantities": existing_quantities,
		"is_edit": True,
		"show_blf_selector": _is_admin_user(request.user),
	})


@login_required
def supply_management_delete(request, id):
	if not _can_manage_supply_management(request):
		messages.error(request, "You have no permission to delete supply records.")
		return redirect(reverse("user_profile:supply_management_report"))
	supply = _accessible_supply_qs(request).filter(pk=id).first()
	if supply:
		supply.is_deleted = True
		supply.updated_by = request.user
		supply.save()
		messages.success(request, "Supply record deleted successfully.")
	else:
		messages.error(request, "Supply management data not found.")
	return redirect(reverse("user_profile:supply_management_report"))


def _supply_export_queryset(request):
	_supply_management_report_queryset.request = request
	search_query = request.GET.get("q", "").strip()
	date_of_supply_from = (request.GET.get("date_of_supply_from") or request.GET.get("date_from") or "").strip()
	date_of_supply_to = (request.GET.get("date_of_supply_to") or request.GET.get("date_to") or "").strip()
	is_weighment_processed = request.GET.get("is_weighment_processed", request.GET.get("is_weighment", "")).strip()
	queryset = _supply_management_report_queryset(search_query, date_of_supply_from, date_of_supply_to, is_weighment_processed)
	return queryset, search_query, date_of_supply_from, date_of_supply_to


def _supply_supplier_type(supply):
	if AggregatorProfile.cmobjects.filter(user=supply.created_by).exists():
		return "Aggregator"
	if GrowerProfile.cmobjects.filter(user=supply.created_by).exists():
		return "Small Tea Grower"
	return supply.created_by.profile.user_type.name if getattr(supply.created_by, "profile", None) and supply.created_by.profile.user_type else "NA"


def _supply_name(user):
	if not user:
		return "NA"
	profile = getattr(user, "profile", None)
	name = getattr(profile, "full_name", None) if profile else None
	return f"{name or user.username} ({user.username})"


def _break_long_pdf_value(value, chunk_size=11):
	value = str(value or "")
	if value and len(value) > chunk_size and " " not in value:
		return " ".join(value[i:i + chunk_size] for i in range(0, len(value), chunk_size))
	return value


def _decimal_sum(values):
	total = Decimal("0")
	for value in values:
		if value in (None, ""):
			continue
		try:
			total += Decimal(str(value))
		except (InvalidOperation, ValueError):
			continue
	return total


def _web_supply_report_pdf_context(queryset, request, date_from, date_to):
	supply_details = []
	total_supply_quantity_sum = Decimal("0")
	blf_details = BlfProfile.cmobjects.filter(user=request.user).first()
	aggregator_details = AggregatorProfile.cmobjects.filter(user=request.user).first()
	header_profile = aggregator_details or blf_details
	header_name = getattr(header_profile, "name", None) or getattr(header_profile, "entity_unit", None) or getattr(getattr(request.user, "profile", None), "full_name", None) or request.user.username
	header_address = getattr(header_profile, "address", None) or ""
	for supply in queryset.select_related("consumer", "alloted_vehicle").prefetch_related("supply_id"):
		consumer = BlfProfile.cmobjects.filter(user=supply.consumer).first()
		if not consumer:
			consumer = AggregatorProfile.cmobjects.filter(user=supply.consumer).first()
		consumer_name = getattr(consumer, "entity_unit", None) or getattr(consumer, "name", None) or getattr(supply.consumer, "username", None)
		consumer_username = getattr(getattr(consumer, "user", None), "username", None) or getattr(supply.consumer, "username", None)
		grower_rows = list(supply.supply_id.all())
		total_supply_quantity = _decimal_sum(row.supply_quantity for row in grower_rows)
		if total_supply_quantity <= 0:
			total_supply_quantity = _decimal_or_zero(supply.gross_leaf or supply.quantity)
		total_collected_quantity = _decimal_sum(row.collected_quantity for row in grower_rows)
		total_supply_quantity_sum += total_supply_quantity
		supply_details.append({
			"consumer_name": _break_long_pdf_value(consumer_name),
			"consumer_user_name": _break_long_pdf_value(consumer_username),
			"vehicle_number": supply.alloted_vehicle.vehicle_number if supply.alloted_vehicle else None,
			"total_collected_quantity": total_collected_quantity,
			"total_supply_quantity": total_supply_quantity,
			"date_of_supply": supply.date_of_supply,
			"challan_id": _break_long_pdf_value(supply.supply_challan_id),
			"gross_leaf": _decimal_or_zero(supply.gross_leaf or supply.quantity),
		})
	if date_from and date_to:
		try:
			date_from_display = datetime.strptime(date_from, "%Y-%m-%d").strftime("%d-%m-%Y")
			date_to_display = datetime.strptime(date_to, "%Y-%m-%d").strftime("%d-%m-%Y")
		except ValueError:
			date_from_display = date_from
			date_to_display = date_to
	else:
		date_from_display = ""
		date_to_display = ""
	return {
		"aggregator_details": header_name,
		"aggregator_user_name": request.user.username,
		"aggregator_address": header_address,
		"date_from": date_from_display,
		"date_to": date_to_display,
		"supply_details": supply_details,
		"consumer_type": (request.GET.get("consumer_type") or "factory").lower(),
		"total_supply_quantity_sum": total_supply_quantity_sum,
	}


@login_required
def supply_management_excel(request):
	if not _can_access_supply_management(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	queryset, _, date_from, date_to = _supply_export_queryset(request)
	if not date_from or not date_to:
		messages.error(request, "Please select Date Of Supply From and Date Of Supply To before exporting Excel.")
		return redirect(reverse("user_profile:supply_management_report"))
	workbook = openpyxl.Workbook()
	sheet = workbook.active
	sheet.title = "Supply Report"
	headers = [
		"Sr. No", "Supply Challan ID", "Status", "Created by BLF", "Date Of Supply",
		"Created At", "Supplier Type", "Created By", "Supply To", "Supplier Name",
		"Supply Quantity", "Vehicle Number", "Driver Name", "Mobile Number",
	]
	sheet.append(headers)
	for index, supply in enumerate(queryset, start=1):
		sheet.append([
			index,
			supply.supply_challan_id or "NA",
			_supply_status(supply),
			"Yes" if _supply_created_by_blf(supply) else "No",
			supply.date_of_supply.strftime("%d-%m-%Y") if supply.date_of_supply else "NA",
			supply.created_at.strftime("%d-%m-%Y") if supply.created_at else "NA",
			_supply_supplier_type(supply),
			_supply_name(supply.created_by),
			supply.supply_to or "NA",
			_supply_name(supply.consumer),
			supply.gross_leaf or supply.quantity or "NA",
			supply.alloted_vehicle.vehicle_number if supply.alloted_vehicle else "NA",
			supply.driver_name or "NA",
			supply.mobile_number or "NA",
		])
	for column in sheet.columns:
		max_length = max(len(str(cell.value or "")) for cell in column)
		sheet.column_dimensions[get_column_letter(column[0].column)].width = min(max_length + 3, 40)
	response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	response["Content-Disposition"] = 'attachment; filename="supply-management-report.xlsx"'
	workbook.save(response)
	return response


@login_required
def supply_management_report_pdf(request):
	if not _can_access_supply_management(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	queryset, _, date_from, date_to = _supply_export_queryset(request)
	if not date_from or not date_to:
		messages.error(request, "Please select Date Of Supply From and Date Of Supply To before downloading PDF.")
		return redirect(reverse("user_profile:supply_management_report"))
	context = _web_supply_report_pdf_context(queryset, request, date_from, date_to)
	template = get_template("supply_report_pdf.html")
	html = template.render(context)
	response = HttpResponse(content_type="application/pdf")
	response["Content-Disposition"] = 'filename="supply_report.pdf"'
	pisa_status = pisa.CreatePDF(html, dest=response)
	if pisa_status.err:
		return HttpResponse("Unable to generate PDF.", status=500)
	return response


def _transaction_report_queryset(request):
	queryset = _accessible_supply_qs(request)
	search_query = request.GET.get("q", "").strip()
	date_from = request.GET.get("date_from", "").strip()
	date_to = request.GET.get("date_to", "").strip()
	status = request.GET.get("status", "").strip()
	if search_query:
		queryset = queryset.filter(
			Q(supply_challan_id__icontains=search_query) |
			Q(created_by__username__icontains=search_query) |
			Q(created_by__profile__full_name__icontains=search_query) |
			Q(created_by__profile__user_type__name__icontains=search_query)
		)
	if date_from:
		queryset = queryset.filter(created_at__date__gte=date_from)
	if date_to:
		queryset = queryset.filter(created_at__date__lte=date_to)
	if status == "processed":
		queryset = queryset.filter(is_weighment_proceed=True)
	elif status == "pending":
		queryset = queryset.filter(is_weighment_proceed=False)
	return queryset, search_query, date_from, date_to, status


def _transaction_report_rows(queryset):
	rows = []
	for supply in queryset:
		profile = getattr(supply.created_by, "profile", None)
		user_type_name = str(profile.user_type.name) if profile and profile.user_type else "NA"
		if user_type_name.lower() == "grower":
			user_type_name = "Small Tea Grower"
		elif user_type_name.lower() == "aggregator":
			user_type_name = "Aggregator"
		rows.append({
			"created_at": supply.created_at,
			"supplier": _supply_name(supply.created_by),
			"supplier_type": user_type_name,
			"supply_challan": supply.supply_challan_id or "NA",
			"status": "Processed" if supply.is_weighment_proceed else "Pending",
		})
	return rows


@login_required
def daily_transaction_report(request):
	if not _can_access_supply_management(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	queryset, search_query, date_from, date_to, status = _transaction_report_queryset(request)
	paginator = Paginator(queryset, 10)
	page_obj = paginator.get_page(request.GET.get("page", 1))
	context = {
		"transaction_list": page_obj.object_list,
		"page_obj": page_obj,
		"paginator": paginator,
		"is_paginated": page_obj.has_other_pages(),
		"search_query": search_query,
		"date_from": date_from,
		"date_to": date_to,
		"status": status,
		"total_count": paginator.count,
		"list_url": reverse("user_profile:daily_transaction_report"),
		"export_enabled": bool(date_from and date_to),
	}
	if _is_ajax_request(request):
		return CommonMixin.render(request, "reports/_daily_transaction_report_table.html", context)
	return CommonMixin.render(request, "reports/daily_transaction_report.html", context)


@login_required
def daily_transaction_report_pdf(request):
	if not _can_access_supply_management(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	queryset, _, date_from, date_to, _ = _transaction_report_queryset(request)
	if not date_from or not date_to:
		messages.error(request, "Please select From Date and To Date before downloading PDF.")
		return redirect(reverse("user_profile:daily_transaction_report"))
	context = {
		"rows": _transaction_report_rows(queryset),
		"date_from": date_from,
		"date_to": date_to,
	}
	html = get_template("reports/daily_transaction_report_pdf.html").render(context)
	response = HttpResponse(content_type="application/pdf")
	response["Content-Disposition"] = 'attachment; filename="daily-transaction-report.pdf"'
	pisa_status = pisa.CreatePDF(html, dest=response)
	if pisa_status.err:
		return HttpResponse("Unable to generate PDF.", status=500)
	return response


@login_required
def daily_transaction_report_excel(request):
	if not _can_access_supply_management(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	queryset, _, date_from, date_to, _ = _transaction_report_queryset(request)
	if not date_from or not date_to:
		messages.error(request, "Please select From Date and To Date before exporting Excel.")
		return redirect(reverse("user_profile:daily_transaction_report"))
	workbook = openpyxl.Workbook()
	sheet = workbook.active
	sheet.title = "Transactions"
	sheet.append(["Sr. No", "Created Date", "Supplier", "Supplier Type", "Supply Challan", "Challan Process Status"])
	for index, row in enumerate(_transaction_report_rows(queryset), start=1):
		sheet.append([
			index,
			row["created_at"].strftime("%d-%m-%Y") if row["created_at"] else "NA",
			row["supplier"],
			row["supplier_type"],
			row["supply_challan"],
			row["status"],
		])
	for column in sheet.columns:
		max_length = max(len(str(cell.value or "")) for cell in column)
		sheet.column_dimensions[get_column_letter(column[0].column)].width = min(max_length + 3, 40)
	response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	response["Content-Disposition"] = 'attachment; filename="daily-transaction-report.xlsx"'
	workbook.save(response)
	return response


@login_required
def supply_management_challan_pdf(request, id):
	if not _can_access_supply_management(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	supply = _accessible_supply_qs(request).filter(pk=id).first()
	if not supply:
		messages.error(request, "Supply management data not found.")
		return redirect(reverse("user_profile:supply_management_report"))
	grower_rows = list(GrowerDetailsSupply.cmobjects.filter(supply=supply).select_related("grower", "grower__user"))
	aggregator_supplier = AggregatorProfile.cmobjects.select_related("user").filter(user=supply.created_by).first()
	grower_supplier = GrowerProfile.cmobjects.select_related("user").filter(user=supply.created_by).first()
	context = {
		"challan_details": supply,
		"blf_details": BlfProfile.cmobjects.filter(user=supply.consumer).first(),
		"vehicle_details": supply.alloted_vehicle,
		"grower_details_supply": grower_rows,
		"total_qty": supply.gross_leaf or supply.quantity or "0",
		"total_collected_qty": sum(float(row.collected_quantity or row.supply_quantity or 0) for row in grower_rows),
		"agg_supplier_details": aggregator_supplier,
		"grower_supplier_details": grower_supplier,
		"profile_type": "aggregator" if aggregator_supplier else "grower",
		"logged_user_type": _profile_type_name(request.user),
	}
	html = get_template("delivery_challan_pdf.html").render(context)
	response = HttpResponse(content_type="application/pdf")
	filename = supply.supply_challan_id or f"supply-{supply.id}"
	response["Content-Disposition"] = f'attachment; filename="{filename}.pdf"'
	pisa_status = pisa.CreatePDF(html, dest=response)
	if pisa_status.err:
		return HttpResponse("Unable to generate challan PDF.", status=500)
	return response


@login_required
def challan_process_list(request):
	if not _can_access_challan_process(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	if not _is_admin_user(request.user):
		mode = request.GET.get("mode", "").strip()
		target = reverse("user_profile:challan_process_records")
		return redirect(f"{target}?mode={mode}" if mode else target)

	search_query = request.GET.get("q", "").strip()
	page_mode = request.GET.get("mode", "").strip()
	is_report_mode = page_mode == "report"
	queryset = _challan_process_blf_list()
	if search_query:
		queryset = queryset.filter(
			Q(entity_unit__icontains=search_query) |
			Q(entity_name__icontains=search_query) |
			Q(email__icontains=search_query) |
			Q(user__username__icontains=search_query)
		)
	paginator = Paginator(queryset, 10)
	page_obj = paginator.get_page(request.GET.get("page", 1))
	context = {
		"page_obj": page_obj,
		"paginator": paginator,
		"is_paginated": page_obj.has_other_pages(),
		"blf_results": page_obj.object_list,
		"search_query": search_query,
		"list_url": reverse("user_profile:challan_process_list"),
		"total_count": paginator.count,
		"page_mode": page_mode,
		"is_report_mode": is_report_mode,
	}
	if _is_ajax_request(request):
		return CommonMixin.render(request, "challan_process/_blf_results.html", context)
	return CommonMixin.render(request, "challan_process/list.html", context)


@login_required
def challan_process_records(request):
	if not _can_access_challan_process(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	page_mode = request.GET.get("mode", "").strip()
	is_report_mode = page_mode == "report"
	selected_blf = _selected_challan_process_blf(request)
	owner_user = selected_blf.user if selected_blf and selected_blf.user_id else None
	if _is_admin_user(request.user) and not owner_user and not is_report_mode:
		messages.error(request, "Please select BLF user first.")
		return redirect(reverse("user_profile:challan_process_list"))
	queryset = _challan_process_queryset(request, owner_user=owner_user, allow_all_for_admin=is_report_mode)
	search_query = request.GET.get("q", "").strip()
	date_from = request.GET.get("date_from", "").strip()
	date_to = request.GET.get("date_to", "").strip()
	if search_query:
		queryset = queryset.filter(
			Q(weighment_txn_id__icontains=search_query) |
			Q(supplier__username__icontains=search_query) |
			Q(supplier__profile__full_name__icontains=search_query) |
			Q(supply_challan__supply_challan_id__icontains=search_query) |
			Q(vehicle_no__vehicle_number__icontains=search_query)
		)
	if date_from:
		queryset = queryset.filter(supply_date__gte=date_from)
	if date_to:
		queryset = queryset.filter(supply_date__lte=date_to)
	paginator = Paginator(queryset, 10)
	page_obj = paginator.get_page(request.GET.get("page", 1))
	context = {
		"page_obj": page_obj,
		"paginator": paginator,
		"is_paginated": page_obj.has_other_pages(),
		"process_list": page_obj.object_list,
		"search_query": search_query,
		"date_from": date_from,
		"date_to": date_to,
		"list_url": reverse("user_profile:challan_process_records"),
		"current_list_url": _challan_process_records_url(request),
		"total_count": paginator.count,
		"selected_blf": selected_blf,
		"selected_blf_id": str(selected_blf.id) if selected_blf else "",
		"blf_query": _challan_process_context_query(request),
		"page_mode": page_mode,
		"is_report_mode": is_report_mode,
		"export_enabled": bool(is_report_mode and date_from and date_to),
	}
	if _is_ajax_request(request):
		return CommonMixin.render(request, "challan_process/_table.html", context)
	return CommonMixin.render(request, "challan_process/records.html", context)


def _challan_process_filtered_queryset(request):
	selected_blf = _selected_challan_process_blf(request)
	owner_user = selected_blf.user if selected_blf and selected_blf.user_id else None
	allow_all_for_admin = _is_admin_user(request.user) and request.GET.get("mode", "").strip() == "report" and not owner_user
	queryset = _challan_process_queryset(request, owner_user=owner_user, allow_all_for_admin=allow_all_for_admin)
	search_query = request.GET.get("q", "").strip()
	date_from = request.GET.get("date_from", "").strip()
	date_to = request.GET.get("date_to", "").strip()
	if search_query:
		queryset = queryset.filter(
			Q(weighment_txn_id__icontains=search_query) |
			Q(supplier__username__icontains=search_query) |
			Q(supplier__profile__full_name__icontains=search_query) |
			Q(supply_challan__supply_challan_id__icontains=search_query) |
			Q(vehicle_no__vehicle_number__icontains=search_query)
		)
	if date_from:
		queryset = queryset.filter(supply_date__gte=date_from)
	if date_to:
		queryset = queryset.filter(supply_date__lte=date_to)
	return queryset, selected_blf, search_query, date_from, date_to


def _challan_history_status(item):
	if item.is_supplier_exit_proceed:
		return "Closed"
	if item.is_processed:
		return "Processed"
	return "Pending"


def _challan_history_rows(queryset):
	rows = []
	for item in queryset:
		supply = item.supply_challan
		rows.append({
			"created_at": item.created_at,
			"supplier": _supply_name(item.supplier),
			"supplier_type": item.supplier_type or _profile_type_name(item.supplier),
			"supply_challan": supply.supply_challan_id if supply and supply.supply_challan_id else "NA",
			"weighment_txn_id": item.weighment_txn_id or "NA",
			"supply_date": item.supply_date,
			"gross_weight": item.total_gross_weight_kg or 0,
			"status": _challan_history_status(item),
		})
	return rows


@login_required
def challan_history_report_pdf(request):
	if not _can_access_challan_process(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	queryset, selected_blf, _, date_from, date_to = _challan_process_filtered_queryset(request)
	if not date_from or not date_to:
		messages.error(request, "Please select From Date and To Date before downloading PDF.")
		return redirect(reverse("user_profile:challan_process_records") + _challan_process_context_query(request))
	context = {
		"rows": _challan_history_rows(queryset),
		"date_from": date_from,
		"date_to": date_to,
		"selected_blf": selected_blf,
	}
	html = get_template("reports/challan_history_report_pdf.html").render(context)
	response = HttpResponse(content_type="application/pdf")
	response["Content-Disposition"] = 'attachment; filename="challan-history-report.pdf"'
	pisa_status = pisa.CreatePDF(html, dest=response)
	if pisa_status.err:
		return HttpResponse("Unable to generate PDF.", status=500)
	return response


@login_required
def challan_history_report_excel(request):
	if not _can_access_challan_process(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	queryset, _, _, date_from, date_to = _challan_process_filtered_queryset(request)
	if not date_from or not date_to:
		messages.error(request, "Please select From Date and To Date before exporting Excel.")
		return redirect(reverse("user_profile:challan_process_records") + _challan_process_context_query(request))
	workbook = openpyxl.Workbook()
	sheet = workbook.active
	sheet.title = "Challan History"
	sheet.append(["Sr. No", "Created Date", "Supplier", "Supplier Type", "Supply Challan", "Weighment TXN", "Supply Date", "Gross Weight", "Status"])
	for index, row in enumerate(_challan_history_rows(queryset), start=1):
		sheet.append([
			index,
			row["created_at"].strftime("%d-%m-%Y") if row["created_at"] else "NA",
			row["supplier"],
			row["supplier_type"] or "NA",
			row["supply_challan"],
			row["weighment_txn_id"],
			row["supply_date"].strftime("%d-%m-%Y") if row["supply_date"] else "NA",
			row["gross_weight"],
			row["status"],
		])
	for column in sheet.columns:
		max_length = max(len(str(cell.value or "")) for cell in column)
		sheet.column_dimensions[get_column_letter(column[0].column)].width = min(max_length + 3, 40)
	response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	response["Content-Disposition"] = 'attachment; filename="challan-history-report.xlsx"'
	workbook.save(response)
	return response


@login_required
def challan_process_detail(request, pk):
	if not _can_access_challan_process(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	selected_blf = _selected_challan_process_blf(request)
	owner_user = selected_blf.user if selected_blf and selected_blf.user_id else None
	is_report_mode = request.GET.get("mode", "").strip() == "report"
	weighment = _challan_process_queryset(request, owner_user=owner_user, allow_all_for_admin=is_report_mode).filter(pk=pk).first()
	if not weighment:
		messages.error(request, "Challan process record not found.")
		return redirect(reverse("user_profile:challan_process_records") + _challan_process_context_query(request))
	leaf_receipt = LeafManagement.cmobjects.filter(weighment_txn=weighment).order_by("-id").first()
	supplier_exit = SupplierExit.cmobjects.filter(weighment_txn=weighment).order_by("-id").first()
	leaf_collection = LeafCollection.objects.filter(weighment_supply_id=weighment).order_by("-id").first()
	return CommonMixin.render(request, "challan_process/detail.html", {
		"weighment": weighment,
		"leaf_receipt": leaf_receipt,
		"supplier_exit": supplier_exit,
		"leaf_collection": leaf_collection,
		"blf_query": _challan_process_context_query(request),
		"back_url": get_safe_next_url(request, reverse("user_profile:challan_process_records") + _challan_process_context_query(request)),
	})


@login_required
def challan_process_create(request):
	if not _can_access_challan_process(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	selected_blf = _selected_challan_process_blf(request)
	owner_user = selected_blf.user if selected_blf and selected_blf.user_id else None
	if _is_admin_user(request.user) and not owner_user:
		messages.error(request, "Please select BLF user first.")
		return redirect(reverse("user_profile:challan_process_list") + _challan_process_context_query(request))
	if request.method == "POST":
		form = ChallanProcessForm(request.POST, request=request, owner_blf=selected_blf, owner_user=owner_user)
		if form.is_valid():
			from user_profile.challan_process_services import create_challan_process_records
			try:
				result = create_challan_process_records(form.api_payload(), owner_user or request.user)
			except Exception as error:
				messages.error(request, str(error))
			else:
				messages.success(request, "Challan processed successfully.")
				return redirect(reverse("user_profile:challan_process_detail", kwargs={"pk": result["weighment"].pk}) + _challan_process_context_query(request))
		else:
			messages.error(request, "Please correct the errors below.")
	else:
		form = ChallanProcessForm(initial=_challan_process_initial_from_supply(request, owner_user=owner_user), request=request, owner_blf=selected_blf, owner_user=owner_user)
	return CommonMixin.render(request, "challan_process/form.html", {
		"form": form,
		"form_title": "Create Process Challan",
		"submit_label": "Finalize Challan",
		"grower_rows": [],
		"selected_blf_id": str(selected_blf.id) if selected_blf else "",
		"back_url": get_safe_next_url(request, reverse("user_profile:challan_process_records") + _challan_process_context_query(request)),
		"supplier_choices_json": [
			{"id": str(user_id), "type": supplier_type} for user_id, _label, supplier_type in form.supplier_choices
		],
	})


@login_required
def challan_process_edit(request, pk):
	if not _can_access_challan_process(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	selected_blf = _selected_challan_process_blf(request)
	owner_user = selected_blf.user if selected_blf and selected_blf.user_id else None
	weighment = _challan_process_queryset(request, owner_user=owner_user).filter(pk=pk).first()
	if not weighment:
		messages.error(request, "Challan process record not found.")
		return redirect(reverse("user_profile:challan_process_records") + _challan_process_context_query(request))
	if request.method == "POST":
		form = ChallanProcessForm(request.POST, request=request, owner_blf=selected_blf, owner_user=owner_user)
		if form.is_valid():
			from user_profile.challan_process_services import update_challan_process_records
			try:
				update_challan_process_records(pk, form.api_payload(), owner_user or request.user)
			except Exception as error:
				messages.error(request, str(error))
			else:
				messages.success(request, "Challan process updated successfully.")
				return redirect(reverse("user_profile:challan_process_detail", kwargs={"pk": pk}) + _challan_process_context_query(request))
		else:
			messages.error(request, "Please correct the errors below.")
	else:
		form = ChallanProcessForm(initial=_challan_process_form_initial(weighment), request=request, owner_blf=selected_blf, owner_user=owner_user)
	return CommonMixin.render(request, "challan_process/form.html", {
		"form": form,
		"form_title": "Edit Process Challan",
		"submit_label": "Update Challan",
		"weighment": weighment,
		"grower_rows": _challan_process_grower_rows(weighment),
		"selected_blf_id": str(selected_blf.id) if selected_blf else "",
		"back_url": reverse("user_profile:challan_process_records") + _challan_process_context_query(request),
		"supplier_choices_json": [
			{"id": str(user_id), "type": supplier_type} for user_id, _label, supplier_type in form.supplier_choices
		],
	})


@login_required
def challan_process_delete(request, pk):
	if not _can_access_challan_process(request):
		messages.error(request, "You have no permission to access the requested resource!")
		return redirect(reverse("index"))
	next_url = get_safe_next_url(request, reverse("user_profile:challan_process_records") + _challan_process_context_query(request))
	if request.method != "POST":
		return redirect(reverse("user_profile:challan_process_detail", kwargs={"pk": pk}))
	from user_profile.challan_process_services import delete_challan_process_records
	try:
		delete_challan_process_records(pk, request.user)
	except Exception as error:
		messages.error(request, str(error))
		return redirect(reverse("user_profile:challan_process_detail", kwargs={"pk": pk}))
	messages.success(request, "Challan process deleted successfully.")
	return redirect(next_url)


def _is_ajax_request(request):
	return request.META.get("HTTP_X_REQUESTED_WITH") == "XMLHttpRequest"


def _display_value(value):
	if value is None or value == "":
		return "NA"
	return str(value)


def _join_values(values):
	values = [str(value) for value in values if value]
	return ", ".join(values) if values else "NA"


def _garden_cell(item):
	names = [garden.name for garden in item.gardens_grower.all()]
	if any(names):
		return _join_values(names)
	if item.user_id:
		url = reverse("user_profile:grower_profile_edit", kwargs={"user_create_pk": item.user_id})
		return f'<a href="{url}" class="btn bg-warning btn-xs text-white pl-3 pr-3"><i class="fa fa-edit mr-1"></i>Edit Profile</a>'
	return "NA"


def _related_names(manager, attr="name"):
	return _join_values(getattr(obj, attr, None) for obj in manager.all())


def _related_usernames(manager):
	return _join_values(obj.user.username for obj in manager.all() if getattr(obj, "user", None))


def _grower_blf_display(item):
	if getattr(item, "associated_blf", None):
		return _display_value(item.associated_blf.user.username if item.associated_blf.user else None)
	return _related_usernames(item.associated_entity)


def _aggregator_blf_display(item):
	if getattr(item, "associated_blf", None):
		return _display_value(item.associated_blf.user.username if item.associated_blf.user else None)
	return _related_usernames(item.associated_entity)


def _grower_aggregator_display(item):
	return _related_usernames(item.associated_aggregator)


def _profile_list_config():
	return {
		"grower": {
			"model": GrowerProfile,
			"edit_url": "user_profile:grower_profile_edit",
			"select_related": ["user", "user__profile"],
			"only": [
				"id",
				"user_id",
				"name",
				"grower_type",
				"user__id",
				"user__username",
				"user__is_active",
				"user__profile__default_password_active",
			],
			"prefetch_related": [
				Prefetch(
					"associated_aggregator",
					queryset=AggregatorProfile.cmobjects.select_related("user").only("id", "user__username"),
				),
				Prefetch(
					"gardens_grower",
					queryset=Gardens.cmobjects.only("id", "grower_id", "name").order_by("id"),
				),
			],
			"page_size": 10,
			"filters": [
				{"name": "user_id", "label": "User Id/ Username", "type": "text", "lookup": "user__username__icontains"},
				{"name": "name", "label": "Name", "type": "text", "lookup": "name__icontains"},
				{"name": "associated_entity", "label": "Asso.. Entity", "type": "select", "lookup": "associated_blf__user__username__icontains"},
				{"name": "mobile_number", "label": "Contact no", "type": "tel", "lookup": "mobile_number__icontains"},
				{"name": "is_tcms_user", "label": "TCMS Verified", "type": "select", "lookup": "is_tcms_user", "choices": [("True", "YES"), ("False", "NO")]},
			],
			"columns": ["Sr. No", "Username/ID", "Name", "Grower Type", "Associated Aggregator", "Gardens", "User Status", "Action"],
			"row": lambda item, index: [
				index,
				_display_value(item.user.username if item.user else None),
				_display_value(item.name),
				_display_value(item.grower_type),
				_grower_aggregator_display(item),
				_garden_cell(item),
			],
			"visiting_card": True,
			"visiting_card_in_action": True,
		},
		"aggregator": {
			"model": AggregatorProfile,
			"edit_url": "user_profile:aggregator_profile_edit",
			"select_related": ["user", "user__profile", "region", "profile_type", "associated_blf__user"],
			"prefetch_related": ["associated_entity__user"],
			"page_size": 10,
			"filters": [
				{"name": "user_id", "label": "User Id/ Username", "type": "text", "lookup": "user__username__icontains"},
				{"name": "name", "label": "Name", "type": "text", "lookup": "name__icontains"},
				{"name": "mobile_number", "label": "Contact no", "type": "tel", "lookup": "mobile_number__icontains"},
				{"name": "is_tcms_user", "label": "TCMS Verified", "type": "select", "lookup": "is_tcms_user", "choices": [("True", "YES"), ("False", "NO")]},
			],
			"columns": ["Sr. No", "Username/ID", "Name", "Aggregator Type", "Associated BLF", "Contact No", "Visiting Card", "User Status", "Action"],
			"row": lambda item, index: [
				index,
				_display_value(item.user.username if item.user else None),
				_display_value(item.name),
				_display_value(item.aggregator_type),
				_aggregator_blf_display(item),
				_display_value(item.mobile_number),
			],
			"visiting_card": True,
		},
		"blf": {
			"model": BlfProfile,
			"edit_url": "user_profile:blf_profile_edit",
			"select_related": ["user", "user__profile", "region"],
			"prefetch_related": [],
			"attach_page_counts": True,
			"page_size": 10,
			"filters": [
				{"name": "user_id", "label": "User Id/ Username", "type": "text", "lookup": "user__username__icontains"},
				{"name": "entity_unit", "label": "Entity Unit", "type": "text", "lookup": "entity_unit__icontains"},
				{"name": "is_tcms_user", "label": "TCMS Verified", "type": "select", "lookup": "is_tcms_user", "choices": [("True", "YES"), ("False", "NO")]},
			],
			"columns": ["Sr. No", "Username/ID", "Entity Unit", "TCMO No.", "Region", "TCMS Verified", "User Status", "Action"],
			"row": lambda item, index: [
				index,
				_display_value(item.user.username if item.user else None),
				_display_value(item.entity_unit),
				_display_value(item.tcmo_no),
				_display_value(item.region),
				"YES" if item.is_tcms_user else "NO",
			],
		},
		"estate": {
			"model": EstateProfile,
			"edit_url": "user_profile:estate_profile_edit",
			"select_related": ["user", "user__profile", "region", "profile_type"],
			"prefetch_related": ["estate_gardens"],
			"page_size": 10,
			"filters": [
				{"name": "user_id", "label": "User Id/ Username", "type": "text", "lookup": "user__username__icontains"},
				{"name": "entity_unit", "label": "Garden/Entity Unit", "type": "text", "lookup": "entity_unit__icontains"},
			],
			"columns": ["Sr. No", "Username/ID", "Garden/Entity Unit", "Region", "Gardens", "Trough Details", "User Status", "Action"],
			"row": lambda item, index: [
				index,
				_display_value(item.user.username if item.user else None),
				_display_value(item.entity_unit),
				_display_value(item.region),
				_related_names(item.estate_gardens),
			],
			"trough_details": True,
		},
		"advisory": {
			"model": AdvisoryProfile,
			"edit_url": "user_profile:advisory_profile_edit",
			"select_related": ["user", "user__profile", "region", "profile_type"],
			"prefetch_related": [],
			"page_size": 10,
			"filters": [
				{"name": "user_id", "label": "User Id/ Username", "type": "text", "lookup": "user__username__icontains"},
				{"name": "organization_name", "label": "Organization Name", "type": "text", "lookup": "organization_name__icontains"},
			],
			"columns": ["Sr. No", "Username/ID", "Organization", "Expert Name", "Region", "User Status", "Action"],
			"row": lambda item, index: [
				index,
				_display_value(item.user.username if item.user else None),
				_display_value(item.organization_name),
				_display_value(item.expert_name),
				_display_value(item.region),
			],
		},
		"consignee": {
			"model": ConsigneeProfile,
			"edit_url": "user_profile:consignee_profile_edit",
			"select_related": ["user", "user__profile", "region", "profile_type"],
			"prefetch_related": [],
			"page_size": 10,
			"filters": [
				{"name": "user_id", "label": "User Id/ Username", "type": "text", "lookup": "user__username__icontains"},
				{"name": "mobile_number", "label": "Contact no", "type": "tel", "lookup": "mobile_number__icontains"},
			],
			"columns": ["Sr. No", "Username/ID", "Organization", "Buyer Name", "Contact No", "Region", "User Status", "Action"],
			"row": lambda item, index: [
				index,
				_display_value(item.user.username if item.user else None),
				_display_value(item.organization_name),
				_display_value(item.buyer_name),
				_display_value(item.mobile_number),
				_display_value(item.region),
			],
		},
		"shg": {
			"model": ShgCooperativeProfile,
			"edit_url": "user_profile:shg_profile_edit",
			"select_related": ["user", "user__profile", "region", "shg_cooperative_type", "profile_type"],
			"prefetch_related": [],
			"page_size": 10,
			"filters": [
				{"name": "user_id", "label": "User Id/ Username", "type": "text", "lookup": "user__username__icontains"},
				{"name": "name", "label": "Name", "type": "text", "lookup": "name__icontains"},
				{"name": "mobile_number", "label": "Contact no", "type": "tel", "lookup": "mobile_number__icontains"},
			],
			"columns": ["Sr. No", "Username/ID", "Name", "SHG/Cooperative Type", "Contact No", "Region", "User Status", "Action"],
			"row": lambda item, index: [
				index,
				_display_value(item.user.username if item.user else None),
				_display_value(item.name),
				_display_value(item.shg_cooperative_type),
				_display_value(item.mobile_number),
				_display_value(item.region),
			],
		},
	}


def _profile_model_for_type(user_type):
	config = _profile_list_config().get(str(user_type).lower())
	return config["model"] if config else None


def _append_next(url, next_url):
	if not next_url:
		return url
	separator = "&" if "?" in url else "?"
	return f"{url}{separator}next={quote(next_url)}"


def _profile_list_default(user_type):
	return reverse("user_profile:all_users", kwargs={"usertype_slug": user_type})


def _mark_default_password_active(user, actor, note="Default password assigned by admin."):
	profile, _created = Profile.objects.get_or_create(user=user)
	profile.default_password_active = True
	profile.password_reset_required = True
	profile.updated_by = actor
	profile.save(update_fields=["default_password_active", "password_reset_required", "updated_by", "updated_at"])
	UserPasswordResetAudit.objects.create(
		target_user=user,
		created_by=actor,
		updated_by=actor,
		note=note,
	)


def _mark_default_password_changed(user):
	Profile.objects.filter(user=user).update(
		default_password_active=False,
		password_reset_required=False,
	)


def _ensure_default_grower_garden_and_plot(grower, actor=None):
	if not grower:
		return None, None
	garden = Gardens.objects.filter(grower=grower).order_by("id").first()
	if garden:
		if not garden.name:
			garden.name = grower.name
			garden.updated_by = actor or grower.user
			garden.save(update_fields=["name", "updated_by", "updated_at"])
	else:
		garden = Gardens.objects.create(
			grower=grower,
			name=grower.name,
			is_division=False,
			created_by=actor or grower.user,
			updated_by=actor or grower.user,
		)
	plot = Plot.objects.filter(garden=garden).order_by("id").first()
	if plot:
		plot.name = grower.name
		plot.save(update_fields=["name"])
	else:
		plot = Plot.objects.create(garden=garden, name=grower.name)
	return garden, plot


def _grower_garden_queryset(profile):
	if not profile:
		return Gardens.cmobjects.none()
	return Gardens.cmobjects.filter(grower=profile).order_by("id")


def _initial_grower_gardens(profile_form=None, profile=None):
	if profile:
		return [{"name": profile.name or "", "production_area": profile.production_area or ""}]
	initial_name = ""
	initial_area = ""
	if profile_form:
		initial_name = profile_form.initial.get("name", "") or ""
		initial_area = profile_form.initial.get("production_area", "") or ""
	return [{"name": initial_name, "production_area": initial_area}]


def _save_grower_garden_formset(formset, profile, request):
	first_active_garden = None
	for form in formset.deleted_forms:
		if form.instance and form.instance.pk:
			form.instance.is_deleted = True
			form.instance.updated_by = request.user
			form.instance.save(update_fields=["is_deleted", "updated_by", "updated_at"])

	for form in formset.forms:
		if form in formset.deleted_forms:
			continue
		garden = form.save(commit=False)
		garden.grower = profile
		garden.user = profile.user
		garden.is_division = False
		if not garden.created_by_id:
			garden.created_by = request.user
		garden.updated_by = request.user
		garden.save()
		if first_active_garden is None:
			first_active_garden = garden
		plot = Plot.objects.filter(garden=garden).order_by("id").first()
		if plot:
			if not plot.name:
				plot.name = garden.name
				plot.save(update_fields=["name"])
		else:
			Plot.objects.create(garden=garden, name=garden.name)
	if first_active_garden:
		profile.garden_name = first_active_garden.name
		profile.production_area = first_active_garden.production_area
		profile.save(update_fields=["garden_name", "production_area", "updated_at"])


def _profile_display_name(profile):
	if not profile:
		return ""
	for attr in ("name", "entity_unit", "organization_name", "buyer_name"):
		value = getattr(profile, attr, None)
		if value:
			return value
	return ""


def _profile_create_config(user_type):
	return {
		"aggregator": {
			"form": AggregatorProfileForm,
			"model": AggregatorProfile,
			"template": "profile/aggregator_profile_create.html",
		},
		"blf": {
			"form": BlfProfileForm,
			"model": BlfProfile,
			"template": "profile/blf_profile_create.html",
		},
		"estate": {
			"form": EstateProfileForm,
			"model": EstateProfile,
			"template": "profile/estate_profile_create.html",
		},
		"advisory": {
			"form": AdvisoryProfileForm,
			"model": AdvisoryProfile,
			"template": "profile/advisory_profile_create.html",
		},
		"consignee": {
			"form": ConsigneeProfileForm,
			"model": ConsigneeProfile,
			"template": "profile/consignee_profile_create.html",
		},
		"shg": {
			"form": ShgCooperativeProfileForm,
			"model": ShgCooperativeProfile,
			"template": "profile/shg_profile_create.html",
		},
	}.get(str(user_type).lower())


def _profile_create_context(profile_type, user_form, profile_form, next_url, template_extra=None):
	context = {
		'profile_type': profile_type,
		'profile_details': {'profile_type': profile_type, 'user': {'username': ''}},
		'user_form': user_form,
		'form': profile_form,
		'is_create': True,
		'default_password': DEFAULT_USER_PASSWORD,
		'current_url': True,
		'next_url': next_url,
	}
	if template_extra:
		context.update(template_extra)
	return context


def _profile_lookup_requires_distinct(lookup):
	return lookup.startswith("associated_entity__") or lookup.startswith("associated_aggregator__")


def _apply_profile_filters(queryset, filters, request):
	blf_entity = request.GET.get("blf_entity", "").strip()
	if queryset.model == GrowerProfile:
		if blf_entity.isdigit():
			queryset = queryset.filter(Q(associated_blf_id=blf_entity) | Q(associated_entity__id=blf_entity))
			needs_distinct = True
		else:
			needs_distinct = False
	elif queryset.model == AggregatorProfile:
		if blf_entity.isdigit():
			queryset = queryset.filter(Q(associated_entity__id=blf_entity)| Q(associated_blf_id=blf_entity))
			needs_distinct = True
		else:
			needs_distinct = False
	else:
		needs_distinct = False
	query = request.GET.get("q", "").strip()
	if query:
		search = Q(user__username__icontains=query)
		for field in filters:
			lookup = field.get("lookup")
			if not lookup or field["type"] == "select" and lookup == "is_tcms_user":
				continue
			if _profile_lookup_requires_distinct(lookup):
				needs_distinct = True
			search |= Q(**{lookup: query})
		queryset = queryset.filter(search)

	for field in filters:
		value = request.GET.get(field["name"])
		if value in (None, "", field["label"]):
			continue
		if field["type"] == "select" and field.get("lookup") == "is_tcms_user":
			queryset = queryset.filter(is_tcms_user=(value == "True"))
			continue
		if _profile_lookup_requires_distinct(field["lookup"]):
			needs_distinct = True
		queryset = queryset.filter(**{field["lookup"]: value.strip()})
	return queryset.distinct() if needs_distinct else queryset


def _build_profile_rows(page_obj, config, user_type, start_index, current_list_url=""):
	rows = []
	for offset, item in enumerate(page_obj.object_list, start=start_index):
		user = item.user
		user_id = user.id if user else None
		is_active = bool(user and user.is_active)
		edit_url = reverse(config["edit_url"], kwargs={"user_create_pk": user_id}) if user_id and is_active else None
		view_url = reverse("user_profile:user_profile_view", kwargs={"user_create_pk": user_id, "user_type": user_type}) if user_id else None
		delete_url = reverse("user_profile:user_profile_delete", kwargs={"user_create_pk": user_id, "user_type": user_type}) if user_id else None
		row = {
			"cells": config["row"](item, offset),
			"is_active": is_active,
			"view_url": _append_next(view_url, current_list_url) if view_url else None,
			"edit_url": _append_next(edit_url, current_list_url) if edit_url else None,
			"delete_url": _append_next(delete_url, current_list_url) if delete_url else None,
			"reset_password_url": _append_next(reverse("accounts:reset_default_password", kwargs={"user_id": user_id}), current_list_url) if user_id else None,
			"default_password_active": bool(getattr(getattr(user, "profile", None), "default_password_active", False)) if user else False,
			"activate_url": _append_next(reverse("user_profile:user_profile_active", kwargs={"user_create_pk": user_id, "user_type": user_type}), current_list_url) if user_id and not is_active else None,
			"deactivate_url": _append_next(reverse("user_profile:user_profile_deactive", kwargs={"user_create_pk": user_id, "user_type": user_type}), current_list_url) if user_id and is_active else None,
			"visiting_card_url": None,
			"visiting_card_in_action": bool(config.get("visiting_card_in_action")),
			"trough_details_url": None,
			"grower_list_url": None,
			"aggregator_list_url": None,
		}
		if config.get("visiting_card") and user_id:
			row["visiting_card_url"] = reverse("user_profile:visting_card_download", kwargs={"user_pk": user_id, "user_type": user_type})
		if config.get("trough_details") and user_id:
			row["trough_details_url"] = reverse("user_profile:estate_trough_details_list", kwargs={"user_create_pk": user_id})
		if user_type == "blf":
			row["grower_list_url"] = f'{reverse("user_profile:all_users", kwargs={"usertype_slug": "grower"})}?blf_entity={item.id}'
			row["aggregator_list_url"] = f'{reverse("user_profile:all_users", kwargs={"usertype_slug": "aggregator"})}?blf_entity={item.id}'
			row["grower_count"] = getattr(item, "grower_count", 0)
			row["aggregator_count"] = getattr(item, "aggregator_count", 0)
		rows.append(row)
	return rows


def _visible_profile_page_numbers(page_obj, radius=2):
	start = max(1, page_obj.number - radius)
	stop = min(page_obj.paginator.num_pages, page_obj.number + radius)
	return range(start, stop + 1)


def _attach_blf_page_counts(page_obj):
	blf_ids = [item.id for item in page_obj.object_list]
	if not blf_ids:
		return
	grower_counts = dict(
		GrowerProfile.associated_entity.through.objects
		.filter(blfprofile_id__in=blf_ids)
		.values_list("blfprofile_id")
		.annotate(total=Count("growerprofile_id", distinct=True))
	)
	aggregator_counts = dict(
		AggregatorProfile.associated_entity.through.objects
		.filter(blfprofile_id__in=blf_ids)
		.values_list("blfprofile_id")
		.annotate(total=Count("aggregatorprofile_id", distinct=True))
	)
	for item in page_obj.object_list:
		item.grower_count = grower_counts.get(item.id, 0)
		item.aggregator_count = aggregator_counts.get(item.id, 0)


@permission_required_admin
def users_list(request, usertype_slug):
	configs = _profile_list_config()
	config = configs.get(usertype_slug)
	if not config:
		messages.error(request, "Invalid user type.")
		return redirect(reverse("index"))

	queryset = config["model"].cmobjects.select_related(*config["select_related"]).prefetch_related(*config["prefetch_related"])
	if config.get("only"):
		queryset = queryset.only(*config["only"])
	if config.get("annotations"):
		queryset = queryset.annotate(**config["annotations"])
	queryset = queryset.order_by("-id")
	queryset = _apply_profile_filters(queryset, config["filters"], request)

	paginator = Paginator(queryset, config["page_size"])
	page_number = request.GET.get("page", 1)
	try:
		profile_list = paginator.page(page_number)
	except PageNotAnInteger:
		profile_list = paginator.page(1)
	except EmptyPage:
		profile_list = paginator.page(paginator.num_pages)
	if config.get("attach_page_counts"):
		_attach_blf_page_counts(profile_list)

	query_params = request.GET.copy()
	query_params.pop("page", None)
	context = {
		"profile_list": profile_list,
		"rows": _build_profile_rows(profile_list, config, usertype_slug, profile_list.start_index(), request.get_full_path()),
		"columns": config["columns"],
		"filters": config["filters"],
		"user_type": usertype_slug,
		"profile_type": usertype_slug,
		"tot_count": paginator.count,
		"querystring": query_params.urlencode(),
		"visible_page_numbers": _visible_profile_page_numbers(profile_list),
		"search_query": request.GET.get("q", "").strip(),
		"list_url": reverse("user_profile:all_users", kwargs={"usertype_slug": usertype_slug}),
		"current_list_url": request.get_full_path(),
		"has_filters": any(request.GET.get(field["name"]) for field in config["filters"]),
		"blf_entities": BlfProfile.cmobjects.select_related("user").order_by("entity_unit", "user__username") if usertype_slug in ("grower", "aggregator") else BlfProfile.cmobjects.none(),
		"selected_blf_entity": request.GET.get("blf_entity", "").strip(),
		"requires_blf_selection": False,
		"selected_tcms_verified": request.GET.get("is_tcms_user", "").strip(),
		"has_tcms_filter": any(field.get("lookup") == "is_tcms_user" for field in config["filters"]),
		"current_url": True,
		"url": request.path,
	}
	if _is_ajax_request(request):
		return CommonMixin.render(request, "profile/_user_table.html", context)
	return CommonMixin.render(request, "profile/user_list.html", context)

def aggregator_list(request, usertype_slug):

	profile_details = BlfProfile.cmobjects.filter(user_id=request.user.id).first()
	agg_list = AggregatorProfile.cmobjects.filter(created_by_id=request.user.id).order_by('-id')
	print(profile_details)
	user_type = "aggregator"
	context={
		'user_type' : usertype_slug,
		'agg_list' : agg_list, 
		'profile_type' : usertype_slug,

	}
	return CommonMixin.render(request, 'profile/aggregator_list.html', context)


@login_required
def search_profile(request):
	profile_type = request.GET.get('user_type')
	if not profile_type:
		messages.error(request, "User type is required.")
		return redirect(reverse("index"))
	return users_list(request, profile_type)


@login_required
@permission_required_admin
def profile_detail(request, user_create_pk, user_type):
	model = _profile_model_for_type(user_type)
	if not model:
		messages.error(request, "Invalid user type.")
		return redirect(reverse("index"))

	queryset = model.cmobjects.select_related("user", "region", "profile_type")
	if user_type == "grower":
		queryset = queryset.select_related("state", "district", "associated_unit", "associated_blf__user").prefetch_related(
			"associated_entity",
			"associated_aggregator",
			"grower_proof_id_attachments",
		)
	profile_details = queryset.filter(user_id=user_create_pk).first()
	if not profile_details:
		messages.error(request, "Profile not found.")
		return redirect(reverse("user_profile:all_users", kwargs={"usertype_slug": user_type}))

	proof_attachments = []
	garden_details = []
	if user_type == "grower":
		proof_attachments = UserProfileAttachments.cmobjects.filter(
			grower=profile_details,
			doc_type="id_proof",
		).order_by("id")
		garden_details = Gardens.cmobjects.filter(grower=profile_details).select_related("land_type").order_by("id")
	supply_notifications = []
	if user_type in ("grower", "aggregator") and profile_details.user_id:
		supply_notifications = list(
			SupplyManagement.cmobjects
			.filter(created_by=profile_details.user, updated_by__profile__user_type__name__iexact="blf")
			.select_related("updated_by", "updated_by__profile", "alloted_vehicle")
			.order_by("-created_at")[:10]
		)
		_decorate_supply_items(supply_notifications)

	context = {
		"profile_details": profile_details,
		"proof_attachments": proof_attachments,
		"garden_details": garden_details,
		"supply_notifications": supply_notifications,
		"user_type": user_type,
		"next_url": get_safe_next_url(request, reverse("user_profile:all_users", kwargs={"usertype_slug": user_type})),
	}
	return CommonMixin.render(request, "profile/user_profile_detail.html", context)



class EstateUserList(LoginRequiredMixin, CommonMixin, ListView):
    """
    Tea Grade List View
    """
    model = EstateProfile
    context_object_name = 'profile_list'
    template_name = 'estate_list.html'
    paginate_by = 5

    def get(self, request, *args, **kwargs):
    # checking if the user is Admin
        try:
            if not self.request.user.is_superuser:
                messages.error(self.request, 'You have no permission to access the requested resource!')
                return redirect(reverse('index'))
        except AttributeError as error:
            messages.error(self.request, 'You have no permission to access the requested resource!')
            return redirect(reverse('index'))

        return super().get(request, *args, **kwargs)

    def get_queryset(self, *args, **kwargs):

        qs = super().get_queryset(*args, **kwargs)
        tea_type=self.request.GET.get('tea_type')
        grade=self.request.GET.get('grade')
        if tea_type:
            return qs.filter(tea_type__name__icontains=tea_type)
        if grade:
            return qs.filter(grade__icontains=grade)
       
        return TeaGradeDetails.objects.all().order_by('-id')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        context['tea_type_list'] = TeaType.objects.all().order_by('id')
        return context







@login_required
def delete_profile(request, user_create_pk, user_type):

	try:
		if not request.user.is_superuser:
			messages.error(request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))
	except AttributeError as error:
		messages.error(request, 'You have no permission to access the requested resource!')
		return redirect(reverse('index'))

	profile_model = _profile_model_for_type(user_type)
	if not profile_model:
		messages.error(request, "Invalid user type.")
		return redirect(reverse("index"))

	
	# profile_details.delete()

	with transaction.atomic():
		profile_details = profile_model.cmobjects.filter(user_id=user_create_pk).first()
		if not profile_details:
			messages.error(request, "Profile not found.")
			return redirect(get_safe_next_url(request, reverse('user_profile:all_users', kwargs={"usertype_slug": user_type })))
		profile_details.is_deleted = True
		try:
			profile_details.save()
		except APIException as exception:
			messages.error(request, get_api_exception_message(exception))
			return redirect(get_safe_next_url(request, reverse('user_profile:all_users', kwargs={"usertype_slug": user_type })))
		# profile_details.delete()

		User.objects.filter(id=profile_details.user_id).update(is_active=False) 
		messages.success(
			request, 'User Profile Deleted Successfully')

	return redirect(get_safe_next_url(request, reverse('user_profile:all_users', kwargs={"usertype_slug": user_type })))



@login_required
def user_profile_active(request, user_create_pk, user_type):

	try:
		if not request.user.is_superuser:
			messages.error(request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))
	except AttributeError as error:
		messages.error(request, 'You have no permission to access the requested resource!')
		return redirect(reverse('index'))

	if  user_type == "grower":
		profile_model = GrowerProfile
	elif user_type == "aggregator":
		profile_model = AggregatorProfile
	elif user_type == "blf":
		profile_model = BlfProfile
	elif user_type == "advisory":
		profile_model = AdvisoryProfile
	elif user_type == "estate":
		profile_model = EstateProfile
	elif user_type == "consignee":
		profile_model = ConsigneeProfile
	elif user_type == "shg":
		profile_model = ShgCooperativeProfile

	# profile_model.objects.filter(user_id=user_create_pk).update(is_active=True)
	User.objects.filter(id=user_create_pk).update(is_active=True)
	messages.success(request, 'User Profile is Successfully Activated!')
	# return HttpResponseRedirect(request.META.get("HTTP_REFERER"))
	
	return redirect(get_safe_next_url(request, reverse('user_profile:all_users', kwargs={"usertype_slug": user_type })))


@login_required
def user_profile_deactive(request, user_create_pk, user_type):

	try:
		if not request.user.is_superuser:
			messages.error(request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))
	except AttributeError as error:
		messages.error(request, 'You have no permission to access the requested resource!')
		return redirect(reverse('index'))

	if  user_type == "grower":
		profile_model = GrowerProfile
	elif user_type == "aggregator":
		profile_model = AggregatorProfile
	elif user_type == "blf":
		profile_model = BlfProfile
	elif user_type == "advisory":
		profile_model = AdvisoryProfile
	elif user_type == "estate":
		profile_model = EstateProfile
	elif user_type == "consignee":
		profile_model = ConsigneeProfile
	elif user_type == "shg":
		profile_model = ShgCooperativeProfile

	print(" dwedefe ")

	# profile_model.objects.filter(user_id=user_create_pk).update(is_active=False)
	User.objects.filter(id=user_create_pk).update(is_active=False)
	messages.success(request, 'User Profile is Successfully Deactivated!')
	# return HttpResponseRedirect(request.META.get("HTTP_REFERER"))

	return redirect(get_safe_next_url(request, reverse('user_profile:all_users', kwargs={"usertype_slug": user_type })))




class ProfileListView(LoginRequiredMixin, ListView, CommonMixin):
	"""
	Profile List View
	"""
	model = GrowerProfile
	context_object_name = "user_list"
	template_name = "profile/user_list.html"
	paginate_by = 10

	def get_queryset(self):
		return self.model.cmobjects.filter(user__is_active=True).order_by('user__username')

	def get_context_data(self, **kwargs):   
		context = super(ProfileListView, self).get_context_data(**kwargs)

		# context['admin_list'] = Profile.objects.filter(user_type = 'ADMIN', user__is_active=True).order_by('user__username')

		# context['employee_list'] = Profile.objects.filter(user_type = 'EMPLOYEE', user__is_active=True).order_by('user__username')

		# context['manager_list'] = Profile.objects.filter(user_type = 'REPORTING MANAGER', user__is_active=True).order_by('user__username')

        # context['']

		return context


@login_required
def user_create(request, usertype_slug):
	# User create view for all Users Type 
	profile_type = ProfileType.objects.filter(
		slug=usertype_slug).first()
	next_url = get_safe_next_url(request, reverse('user_profile:all_users', kwargs={"usertype_slug": usertype_slug}))

	if str(profile_type).lower() == "grower":
		selected_blf_id = request.POST.get("associated_blf") if request.method == "POST" else request.GET.get("blf_id")
		selected_blf = _selected_grower_blf(selected_blf_id=selected_blf_id)
		requires_blf_selection = request.method == "GET" and not selected_blf
		if request.method == "POST":
			user_form = AdminUserCreateForm(request.POST)
			profile_form = GrowerProfileForm(request.POST, request.FILES, selected_blf=selected_blf)
			attachment_formset = GrowerIDProofAttachmentFormSet(
				request.POST,
				request.FILES,
				prefix="idproof",
			)
			garden_formset = GrowerGardenFormSet(
				request.POST,
				prefix="gardens",
			)
			if user_form.is_valid() and profile_form.is_valid() and attachment_formset.is_valid() and garden_formset.is_valid():
				with transaction.atomic():
					create = user_form.save()
					profile = profile_form.save(commit=False)
					profile.user = create
					profile.email = user_form.cleaned_data.get("email")
					profile.profile_type = profile_type
					profile.created_by = request.user
					profile.updated_by = request.user
					profile.save()
					profile_form.save_m2m()
					_sync_grower_associated_entity(profile)
					Profile.objects.update_or_create(
						user=create,
						defaults={
							'user_type': profile_type,
							'email': user_form.cleaned_data.get("email") or None,
							'full_name': profile.name,
							'phone_no': profile.mobile_number,
							'region': profile.region,
							'state': profile.state,
							'district': profile.district,
							'created_by': request.user,
							'updated_by': request.user,
							'default_password_active': True,
							'password_reset_required': True,
						}
					)
					_save_grower_id_proof_formset(attachment_formset, profile, request)
					_save_grower_garden_formset(garden_formset, profile, request)
					GrowerQrCode.objects.update_or_create(grower_id=profile.pk, defaults={'name': profile.name})
					UserPasswordResetAudit.objects.create(
						target_user=create,
						created_by=request.user,
						updated_by=request.user,
						note="Default password assigned during user creation.",
					)
				messages.success(request, 'Grower user and profile created successfully. Default password is Secret@123.')
				return redirect(next_url)
			messages.error(request, "Please correct the errors below.")
			if not user_form.is_valid():
				_add_form_errors_to_messages(request, user_form)
			if not profile_form.is_valid():
				_add_form_errors_to_messages(request, profile_form)
			if not attachment_formset.is_valid():
				_add_formset_errors_to_messages(request, attachment_formset)
			if not garden_formset.is_valid():
				_add_formset_errors_to_messages(request, garden_formset)
				
		else:
			
			user_form = AdminUserCreateForm()
			profile_form = GrowerProfileForm(selected_blf=selected_blf)
			attachment_formset = GrowerIDProofAttachmentCreateFormSet(prefix="idproof")
			garden_formset = GrowerGardenCreateFormSet(
				prefix="gardens",
				queryset=Gardens.objects.none(),
			)
		context = {
			'profile_type': profile_type,
			'user_form': user_form,
			'form': profile_form,
			'attachment_formset': attachment_formset,
			'garden_formset': garden_formset,
			'is_create': True,
			'default_password': DEFAULT_USER_PASSWORD,
			'current_url': True,
			'url': reverse('user_profile:all_users', kwargs={"usertype_slug": usertype_slug}),
			'next_url': next_url,
			'blf_entities': BlfProfile.cmobjects.select_related("user").order_by("entity_unit", "user__username"),
			'selected_blf': selected_blf,
			'requires_blf_selection': requires_blf_selection,
		}
		return CommonMixin.render(request, 'profile/grower_profile_update.html', context)

	create_config = _profile_create_config(profile_type)
	if create_config:
		form_class = create_config["form"]
		if request.method == "POST":
			user_form = AdminUserCreateForm(request.POST)
			profile_form = form_class(request.POST, request.FILES)
			if user_form.is_valid() and profile_form.is_valid():
				with transaction.atomic():
					create = user_form.save()
					profile = profile_form.save(commit=False)
					profile.user = create
					if hasattr(profile, "email"):
						profile.email = user_form.cleaned_data.get("email") or getattr(profile, "email", "")
					if hasattr(profile, "profile_type"):
						profile.profile_type = profile_type
					profile.created_by = request.user
					profile.updated_by = request.user
					profile.save()
					profile_form.save_m2m()
					if str(profile_type).lower() == "aggregator":
						_sync_aggregator_associated_entity(profile)
					if str(profile_type).lower() == "blf":
						_save_blf_repeat_rows(profile, request)
					Profile.objects.update_or_create(
						user=create,
						defaults={
							'user_type': profile_type,
							'email': user_form.cleaned_data.get("email"),
							'full_name': _profile_display_name(profile),
							'phone_no': getattr(profile, "mobile_number", None),
							'region': getattr(profile, "region", None),
							'state': getattr(profile, "state", None),
							'district': getattr(profile, "district", None),
							'created_by': request.user,
							'updated_by': request.user,
							'default_password_active': True,
							'password_reset_required': True,
						}
					)
					if str(profile_type).lower() == "estate":
						Gardens.objects.update_or_create(
							user=create,
							defaults={
								'name': getattr(profile, "entity_unit", None) or getattr(profile, "entity_name", None),
								'is_division': False,
								'estate': profile,
								'created_by': request.user,
								'updated_by': request.user,
							}
						)
					UserPasswordResetAudit.objects.create(
						target_user=create,
						created_by=request.user,
						updated_by=request.user,
						note="Default password assigned during user creation.",
					)
				messages.success(request, f'{profile_type} user and profile created successfully. Default password is {DEFAULT_USER_PASSWORD}.')
				return redirect(next_url)
			messages.error(request, "Please correct the errors below.")
		else:
			
			user_form = AdminUserCreateForm()
			if str(profile_type).lower() == "aggregator":
				selected_blf = BlfProfile.cmobjects.select_related("user").filter(id=request.GET.get("blf_id")).first()
				profile_form = form_class(selected_blf=selected_blf)
			else:
				profile_form = form_class()
		template_extra = {}
		if str(profile_type).lower() == "blf":
			if request.method == "POST":
				production_rows, trough_rows = _blf_rows_from_post(request)
			else:
				production_rows, trough_rows = [], []
			production_rows, trough_rows = _default_blf_repeat_rows(production_rows, trough_rows)
			template_extra = {
				"blf_tea_production_rows": production_rows,
				"blf_trough_rows": trough_rows,
				"tea_type_options": TeaType.objects.filter(is_deleted=False).order_by("name"),
				"tea_grade_options": TeaGradeDetails.objects.filter(is_deleted=False).select_related("tea_type").order_by("grade"),
				"leaf_type_options": BlfTroughDetails.LEAF_TYPE,
			}
		return CommonMixin.render(
			request,
			create_config["template"],
			_profile_create_context(profile_type, user_form, profile_form, next_url, template_extra),
		)
	
	if request.method == 'POST':
		form = AdminUserCreateForm(request.POST)
		if form.is_valid():
			email = form.cleaned_data.get('email')
			create = form.save()
			_mark_default_password_active(create, request.user, "Default password assigned during user creation.")
			user_id = create.pk

			# print(profile_type)
			
			if str(profile_type) == "aggregator":


				AggregatorProfile.cmobjects.update_or_create(user=create, defaults={
						'email': email, 'profile_type': profile_type, 'created_by' : request.user,})
				Profile.objects.update_or_create(user=create, defaults={
						'user_type': profile_type})
				print("aggregator check wdwdwedf")
				messages.success(request, 'User Created Successfully')
				return redirect(_append_next(reverse('user_profile:aggregator_profile_create', kwargs={"user_create_pk": user_id }), next_url))
	
			elif str(profile_type) == "grower":
				GrowerProfile.cmobjects.update_or_create(user=create, defaults={
						'email': email, 'profile_type': profile_type, 'created_by' : request.user})
				Profile.objects.update_or_create(user=create, defaults={
						'user_type': profile_type})
				gr_id = GrowerProfile.objects.filter(user_id=user_id).first()
				_ensure_default_grower_garden_and_plot(gr_id, request.user)
				messages.success(request, 'User Created Successfully')
				return redirect(_append_next(reverse('user_profile:grower_profile_create', kwargs={"user_create_pk": user_id }), next_url))	
			

			elif str(profile_type) == "blf":
				BlfProfile.cmobjects.update_or_create(user=create, defaults={
						'email': email, 'profile_type': profile_type, 'created_by' : request.user})
				Profile.objects.update_or_create(user=create, defaults={
						'user_type': profile_type})
				messages.success(request, 'User Created Successfully')
				return redirect(_append_next(reverse('user_profile:blf_profile_create', kwargs={"user_create_pk": user_id }), next_url))
			
			elif str(profile_type) == "advisory":
				AdvisoryProfile.cmobjects.update_or_create(user=create, defaults={
						'email': email, 'profile_type': profile_type, 'created_by' : request.user})
				Profile.objects.update_or_create(user=create, defaults={
						'user_type': profile_type})
				messages.success(request, 'User Created Successfully')
				return redirect(_append_next(reverse('user_profile:advisory_profile_create', kwargs={"user_create_pk": user_id }), next_url))
			

			elif str(profile_type) == "estate":
				EstateProfile.cmobjects.update_or_create(user=create, defaults={
						'email': email, 'profile_type': profile_type, 'created_by' : request.user})
				Profile.objects.update_or_create(user=create, defaults={
						'user_type': profile_type})
				est_id = EstateProfile.objects.filter(user_id=user_id).first()
				# print(est_id)
				Gardens.objects.update_or_create(user=create, defaults={'is_division': False, 'estate' : est_id })
				messages.success(request, 'User Created Successfully')
				return redirect(_append_next(reverse('user_profile:estate_profile_create', kwargs={"user_create_pk": user_id }), next_url))
			

			elif str(profile_type) == "consignee":
				ConsigneeProfile.cmobjects.update_or_create(user=create, defaults={
						'email': email, 'profile_type': profile_type, 'created_by' : request.user})
				Profile.objects.update_or_create(user=create, defaults={
						'user_type': profile_type})
				messages.success(request, 'User Created Successfully')
				return redirect(_append_next(reverse('user_profile:consignee_profile_create', kwargs={"user_create_pk": user_id }), next_url))
			elif str(profile_type) == "SHG":
				ShgCooperativeProfile.cmobjects.update_or_create(user=create, defaults={
						'email': email, 'profile_type': profile_type, 'created_by' : request.user})
				Profile.objects.update_or_create(user=create, defaults={
						'user_type': profile_type})
				messages.success(request, 'User Created Successfully')
				return redirect(_append_next(reverse('user_profile:shg_profile_create', kwargs={"user_create_pk": user_id }), next_url))
		else:
			for field, errors in form.errors.items():
				field_label = form.fields[field].label if field in form.fields else None
				for error in errors:
					if field_label:
						messages.error(request, f"{field_label}: {error}")
					else:
						messages.error(request, error)
	else:
		form = AdminUserCreateForm()
	context={
		'profile_type' : profile_type,
		'form' : form,
		'current_url': True,
		'url': reverse('user_profile:all_users', kwargs={"usertype_slug": usertype_slug}),
		'next_url': next_url,


	}
	return CommonMixin.render(request, 'profile/user_create.html', context)


@login_required
def validate_user_create_fields(request):
	username = request.GET.get('username', '').strip()
	email = request.GET.get('email', '').strip()
	errors = {}

	if username and User.objects.filter(username__iexact=username).exists():
		errors['username'] = 'This username/user ID already exists.'

	if email and User.objects.filter(email__iexact=email).exists():
		errors['email'] = 'This email address is already registered.'

	return JsonResponse({
		'is_valid': not bool(errors),
		'errors': errors,
	})


class GrowerProfileCreateView(LoginRequiredMixin, CommonMixin, CreateView):

	model = GrowerProfile
	form_class = GrowerProfileForm
	second_form_class = CreateUserForm
	template_name = 'profile/grower_profile_create.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)
	

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Grower Profile Updated Successfully')
		return reverse('user_profile:grower_profile_create', kwargs={"user_create_pk": self.kwargs['user_create_pk'] }  )


	def get_object(self):
		profile_type = ProfileType.objects.filter(slug=self.kwargs['usertype_slug']).first()
		return profile_type

	def get_context_data(self, **kwargs):
		kwargs['active_client'] = True
		if 'form' not in kwargs:
			kwargs['form'] = self.form_class(instance=self.get_object())
		if 'form2' not in kwargs:
			kwargs['form2'] = self.second_form_class(instance=self.get_object())


		

		context = super(GrowerProfileCreateView, self).get_context_data(**kwargs)
		context['profile_type'] = self.get_object()
		return context
	
	def form_valid(self, form):
		self.object = form.save(commit=False)
		self.object.is_active = False
		self.object.save()

		return super().form_valid(form)
	
	# def post(self, request, *args, **kwargs):
	# 	user_form = CreateUserForm(data = request.POST)
	# 	profile_form = GrowerProfileForm(data = request.POST)
	# 	if user_form.is_valid() and profile_form.is_valid():
	# 		user = user_form.save()
	# 		user.set_password(user.password)
	# 		user.save()
	# 		profile = profile_form.save(commit=False)
	# 		profile.user = user
	# 		profile.save()
	# 		registered = True
		
	# 	else:
	# 		user_form = CreateUserForm()
	# 		profile_form = GrowerProfileForm()

	# 	return reverse('user_profile:all_users',kwargs={"usertype_slug": 'grower' })	
	
	# def form_valid(self, form):
		
	# 	print("###########  Print here  $$$$")
	# 	# print(self.form2.instance.id)

	# 	# self.user_id = self.object
	# 	print('form_valid')
	# 	context = self.get_context_data()

	# 	with transaction.atomic():
	# 		self.object = form.save()

		# return super(GrowerProfileCreateView, self).form_valid(form)

	
#######################################################################################
############  Grower Profile Section ################


class GrowerCreateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	Grower Profile Create View 
	"""
	model = GrowerProfile
	form_class = GrowerProfileForm
	template_name = 'profile/grower_profile_create.html'
	import datetime
	print(datetime.date.today())
	
	def get(self, request, *args, **kwargs):
	# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)


	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Grower Profile Updated Successfully')
		# return reverse('user_profile:grower_profile_create', kwargs={"user_create_pk": self.kwargs['user_create_pk'] }  )
		profile_details = GrowerProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()

		gardens_details = Gardens.objects.filter(grower_id=profile_details.pk).first()

		print("grower ID")
		print(profile_details.pk)

		print("garden ID")
		print(gardens_details.pk)

		# garden_id = gardens_details.pk

		if str(profile_details.grower_type) == "LTG":
			return reverse('gardens_managment:garden_update', kwargs={"garden_pk": gardens_details.pk, "grower_pk": profile_details.pk })
			# return reverse('index')

		if str(profile_details.grower_type) == "STG":
			return reverse('gardens_managment:garden_update', kwargs={"garden_pk": gardens_details.pk, "grower_pk": profile_details.pk })
		else:
			return reverse('user_profile:all_users', kwargs={"usertype_slug": 'grower' }) 
			# return reverse('index')


	def get_object(self):
		profile_details = GrowerProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(GrowerCreateView, self).get_context_data(**kwargs)

		context['profile_details'] = self.get_object()

		context['aggregator_list'] = AggregatorProfile.cmobjects.filter(user__is_active=True).select_related('user').order_by('-id')[:100]
		context['next_url'] = get_safe_next_url(self.request, _profile_list_default("grower"))

		return context
	
	def form_valid(self, form):
		
		self.user_id = self.kwargs['user_create_pk']

		context = self.get_context_data()

		profile_details = GrowerProfile.cmobjects.filter(user_id=self.kwargs['user_create_pk']).first()
		garden_details = Gardens.objects.filter(grower_id=profile_details.pk).first()
		Gardens.objects.filter(grower_id=profile_details.pk).update(name = form.instance.name)
		Plot.objects.filter(garden_id=garden_details.pk).update_or_create(garden_id=garden_details.pk, defaults={
			'name': form.instance.name,})
		
		# BlfAssociatedUsers.objects.update_or_create(grower_id=form.instance,\
		# 			       defaults={ 'associated_entity' : form.instance.associated_entity})
		
		GrowerQrCode.objects.update_or_create(grower_id=profile_details.pk, \
					defaults={'name': form.instance.name})
		


		# new_mymodels = []

		# for i in GrowerProfile.objects.all():
		# 	new_mymodels = BlfAssociatedUsers(
		# 		blf=i['blf'],
		# 		grower=i['grower'],
		# 		aggregator=i['aggregator'],
		# 	)
		with transaction.atomic():
			self.object = form.save()
		return super(GrowerCreateView, self).form_valid(form)


def _grower_id_proof_queryset(profile):
	if not profile:
		return UserProfileAttachments.cmobjects.none()
	return UserProfileAttachments.cmobjects.filter(
		grower=profile,
		doc_type="id_proof",
	).order_by("id")


def _save_grower_id_proof_formset(formset, profile, request):
	for form in formset.deleted_forms:
		if form.instance and form.instance.pk:
			form.instance.is_deleted = True
			form.instance.updated_by = request.user
			form.instance.save(update_fields=["is_deleted", "updated_by", "updated_at"])

	for form in formset.forms:
		if form in formset.deleted_forms or not form.has_changed():
			continue
		attachment = form.save(commit=False)
		attachment.grower = profile
		attachment.doc_type = "id_proof"
		if not attachment.created_by_id:
			attachment.created_by = request.user
		attachment.updated_by = request.user
		attachment.save()


def _selected_grower_blf(profile=None, selected_blf_id=None):
	if selected_blf_id:
		return BlfProfile.cmobjects.select_related("user").filter(id=selected_blf_id).first()
	if profile and profile.associated_blf_id:
		return profile.associated_blf
	if profile and profile.pk:
		return profile.associated_entity.select_related("user").order_by("id").first()
	return None


def _sync_grower_associated_entity(profile):
	if profile and profile.associated_blf_id:
		profile.associated_entity.set([profile.associated_blf])


def _sync_aggregator_associated_entity(profile):
	if profile and profile.associated_blf_id:
		profile.associated_entity.set([profile.associated_blf])


@login_required
def blf_profile_details_ajax(request):
	blf_id = request.GET.get("id")
	if not str(blf_id or "").isdigit():
		return JsonResponse({"detail": "BLF not found."}, status=404)
	blf = (
		BlfProfile.cmobjects
		.select_related("region", "state", "district", "user")
		.filter(id=blf_id)
		.first()
	)
	if not blf:
		return JsonResponse({"detail": "BLF not found."}, status=404)
	return JsonResponse({
		"id": blf.id,
		"label": blf_dropdown_label(blf),
		"region_id": blf.region_id,
		"region_name": blf.region.region_name if blf.region else "",
		"state_id": blf.state_id,
		"state_name": blf.state.name if blf.state else "",
		"district_id": blf.district_id,
		"district_name": blf.district.name if blf.district else "",
	})


def _add_formset_errors_to_messages(request, formset):
	for error in formset.non_form_errors():
		messages.error(request, error)
	for form in formset.forms:
		for field_name, errors in form.errors.items():
			label = form.fields[field_name].label if field_name in form.fields else "ID proof"
			for error in errors:
				messages.error(request, f"{label}: {error}")


def _add_form_errors_to_messages(request, form):
	for field_name, errors in form.errors.items():
		label = form.fields[field_name].label if field_name in form.fields else ""
		for error in errors:
			messages.error(request, f"{label}: {error}" if label else error)


@login_required
def update_profile(request, user_create_pk):
	profile = GrowerProfile.cmobjects.select_related('user', 'associated_blf__user').filter(
				user_id=user_create_pk).first()
	next_url = get_safe_next_url(request, _profile_list_default("grower"))
	current_page_url = request.get_full_path()
	is_create_route = getattr(request.resolver_match, "url_name", "") == "grower_profile_create"
	if not profile:
		messages.error(request, "Profile not found.")
		return redirect(next_url)

	selected_blf_id = request.POST.get("associated_blf") if request.method == "POST" else request.GET.get("blf_id")
	selected_blf = _selected_grower_blf(profile=profile, selected_blf_id=selected_blf_id)
	requires_blf_selection = request.method == "GET" and not selected_blf
	if request.method == "POST":
		form = GrowerProfileForm(request.POST, request.FILES, instance=profile, selected_blf=selected_blf)
		attachment_formset = GrowerIDProofAttachmentFormSet(
			request.POST,
			request.FILES,
			instance=profile,
			queryset=_grower_id_proof_queryset(profile),
			prefix="idproof",
		)
		garden_formset = GrowerGardenFormSet(
			request.POST,
			instance=profile,
			queryset=_grower_garden_queryset(profile),
			prefix="gardens",
		)
		if form.is_valid() and attachment_formset.is_valid() and garden_formset.is_valid():
			with transaction.atomic():
				profile = form.save()
				_sync_grower_associated_entity(profile)
				_save_grower_id_proof_formset(attachment_formset, profile, request)
				_save_grower_garden_formset(garden_formset, profile, request)
				GrowerQrCode.objects.update_or_create(grower_id=profile.pk, defaults={'name': profile.name})
			messages.success(request, "Grower profile saved successfully!" if is_create_route else "Profile updated successfully!")
			return redirect(next_url if is_create_route else current_page_url)
		else:
			messages.error(request, "Please correct the errors below.")
			if not form.is_valid():
				_add_form_errors_to_messages(request, form)
			if not attachment_formset.is_valid():
				_add_formset_errors_to_messages(request, attachment_formset)
			if not garden_formset.is_valid():
				_add_formset_errors_to_messages(request, garden_formset)
	else:
		form = GrowerProfileForm(instance=profile, selected_blf=selected_blf)
		attachment_formset = GrowerIDProofAttachmentFormSet(
			instance=profile,
			queryset=_grower_id_proof_queryset(profile),
			prefix="idproof",
		)
		garden_queryset = _grower_garden_queryset(profile)
		garden_formset_kwargs = {
			"instance": profile,
			"queryset": garden_queryset,
			"prefix": "gardens",
		}
		if not garden_queryset.exists():
			garden_formset_kwargs["initial"] = _initial_grower_gardens(profile=profile)
		garden_formset = GrowerGardenFormSet(**garden_formset_kwargs)

	context = {
		"form": form,
		"attachment_formset": attachment_formset,
		"garden_formset": garden_formset,
		"profile_details": profile,
		"account_user": profile.user,
		"user_id" : user_create_pk,
		"current_url" : True,
		"next_url": next_url,
		"reset_password_url": reverse("accounts:reset_default_password", kwargs={"user_id": profile.user_id}) if profile.user_id else "",
		"default_password": DEFAULT_USER_PASSWORD,
		"selected_blf": selected_blf,
		"requires_blf_selection": requires_blf_selection,
		"blf_entities": BlfProfile.cmobjects.select_related("user").order_by("entity_unit", "user__username"),
	}
	return CommonMixin.render(request, "profile/grower_profile_update.html", context)

class GrowerProfileUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
    """
    Grower Profile Update View (Optimized)
    """
    model = GrowerProfile
    form_class = GrowerProfileForm
    template_name = 'profile/grower_profile_update.html'

    def dispatch(self, request, *args, **kwargs):
        """
        Handle permission in one place instead of overriding get()
        """
        if not getattr(request.user, "is_superuser", False):
            messages.error(request, 'You have no permission to access the requested resource!')
            return redirect(reverse('index'))
        return super().dispatch(request, *args, **kwargs)

    def get_object(self):
        """
        Fetch object with related user in single query
        """
        return GrowerProfile.cmobjects.select_related('user').filter(
            user_id=self.kwargs['user_create_pk']
        ).first()

    def get_success_url(self):
        messages.success(self.request, 'Grower Profile Updated Successfully')
        return reverse('user_profile:grower_profile_edit', kwargs={"user_create_pk": self.kwargs['user_create_pk'] } )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile = self.object or self.get_object()
        context.update({
            'active_client': True,
            'form': kwargs.get('form') or self.form_class(instance=profile),
            'profile_details': profile,
            'next_url': get_safe_next_url(self.request, _profile_list_default("grower")),
        })
        return context

    def form_valid(self, form):
        profile = self.get_object()
        if not profile:
            messages.error(self.request, "Profile not found")
            return redirect(reverse('index'))
        with transaction.atomic():
            # Save main profile
            self.object = form.save()
            # Update Garden (single query)
            garden = Gardens.objects.filter(grower_id=profile.pk).first()
            if garden:
                garden.name = form.instance.name
                garden.save(update_fields=['name'])
                Plot.objects.update_or_create(
                    garden_id=garden.pk,
                    defaults={'name': form.instance.name}
                )
            # Update/Create QR Code
            GrowerQrCode.objects.update_or_create(
                grower_id=profile.pk,
                defaults={'name': form.instance.name}
            )
        return super().form_valid(form)



class AggregatorProfileUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	Aggregator Profile Update View @vivek
	"""
	model = AggregatorProfile
	form_class = AggregatorProfileForm
	template_name = 'profile/aggregator_profile_create.html'

	def get(self, request, *args, **kwargs):
		# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Aggregator Profile Updated Successfully')
		return reverse('user_profile:aggregator_profile_edit', kwargs={"user_create_pk": self.kwargs['user_create_pk'] } )

	def get_object(self):
		profile_details = AggregatorProfile.cmobjects.filter(user_id=self.kwargs['user_create_pk']).first()
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(AggregatorProfileUpdateView, self).get_context_data(**kwargs)
		profile = getattr(self, "object", None) or self.get_object()
		context['profile_details'] = profile
		context['usertype_slug'] = "aggregator"
		context["current_url"] = True
		context["next_url"] = get_safe_next_url(self.request, _profile_list_default("aggregator"))
		context["reset_password_url"] = reverse("accounts:reset_default_password", kwargs={"user_id": profile.user_id}) if profile and profile.user_id else ""
		context["default_password"] = DEFAULT_USER_PASSWORD
		
		return context

	def form_valid(self, form):
		
		self.user_id = self.kwargs['user_create_pk']
		context = self.get_context_data()

		profile_details = AggregatorProfile.cmobjects.filter(user_id=self.kwargs['user_create_pk']).first()
		print("Aggregator")
		print(profile_details.pk)

		AggregatorQrCode.objects.update_or_create(aggregator_id=profile_details.pk, \
					defaults={'name': form.instance.name })
		
		# BlfSupplier.objects.update_or_create(aggregator_id=profile_details.pk, \
		# 		        defaults={'supplier_type': "aggregator", 'blf' : form.instance })

		print(self.kwargs['user_create_pk'])

		with transaction.atomic():
			self.object = form.save()
			_sync_aggregator_associated_entity(self.object)

		return super(AggregatorProfileUpdateView, self).form_valid(form)




class AdvisoryProfileUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	Advisory Profile Update View @vivek
	"""
	model = AdvisoryProfile
	form_class = AdvisoryProfileForm
	template_name = 'profile/advisory_profile_create.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Advisory Profile Updated Successfully')
		return get_safe_next_url(self.request, _profile_list_default("advisory"))

	def get_object(self):
		profile_details = AdvisoryProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(AdvisoryProfileUpdateView, self).get_context_data(**kwargs)
		context['profile_details'] = self.get_object()
		context["current_url"] = True
		context["next_url"] = get_safe_next_url(self.request, _profile_list_default("advisory"))
		return context
	def form_valid(self, form):
		
		self.user_id = self.kwargs['user_create_pk']
		context = self.get_context_data()


		with transaction.atomic():
			self.object = form.save()


		return super(AdvisoryProfileUpdateView, self).form_valid(form)



class ConsigneeProfileUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	Consignee Profile Update View @vivek
	"""
	model = ConsigneeProfile
	form_class = ConsigneeProfileForm
	template_name = 'profile/consignee_profile_create.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Consignee Profile Updated Successfully')
		return get_safe_next_url(self.request, _profile_list_default("consignee"))

	def get_object(self):
		profile_details = ConsigneeProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(ConsigneeProfileUpdateView, self).get_context_data(**kwargs)
		context['profile_details'] = self.get_object()
		context["current_url"] = True
		context["next_url"] = get_safe_next_url(self.request, _profile_list_default("consignee"))
		return context
	def form_valid(self, form):
		self.user_id = self.kwargs['user_create_pk']
		context = self.get_context_data()
		with transaction.atomic():
			self.object = form.save()
		return super(ConsigneeProfileUpdateView, self).form_valid(form)
	
class ShgProfileUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	SHG Pofile Update View @vivek
	"""
	model = ShgCooperativeProfile
	form_class = ShgCooperativeProfileForm
	template_name = 'profile/shg_profile_create.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Shg Profile Updated Successfully')
		return get_safe_next_url(self.request, _profile_list_default("shg"))

	def get_object(self):
		profile_details = ShgCooperativeProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(ShgProfileUpdateView, self).get_context_data(**kwargs)

		context['profile_details'] = self.get_object()
		context["next_url"] = get_safe_next_url(self.request, _profile_list_default("shg"))
		return context	
	def form_valid(self, form):
		
		self.user_id = self.kwargs['user_create_pk']
		context = self.get_context_data()


		with transaction.atomic():
			self.object = form.save()


		return super(ShgProfileUpdateView, self).form_valid(form)


########## BLF PROFILE UPDATE VIEW ###############

def _blf_post_list(request, name):
	return [value.strip() for value in request.POST.getlist(name)]


def _blf_rows_from_post(request):
	tea_type_ids = _blf_post_list(request, "production_tea_type[]")
	tea_grade_ids = _blf_post_list(request, "production_tea_grade[]")
	marks_values = _blf_post_list(request, "production_marks[]")
	quantity_values = _blf_post_list(request, "production_quantity[]")
	production_rows = []
	for index, tea_type_id in enumerate(tea_type_ids):
		tea_grade_id = tea_grade_ids[index] if index < len(tea_grade_ids) else ""
		marks = marks_values[index] if index < len(marks_values) else ""
		quantity = quantity_values[index] if index < len(quantity_values) else ""
		if tea_type_id or tea_grade_id or marks or quantity:
			production_rows.append({
				"tea_type_id": tea_type_id,
				"tea_grade_id": tea_grade_id,
				"marks": marks,
				"quantity": quantity,
			})

	capacity_values = _blf_post_list(request, "trough_capacity_qty[]")
	width_values = _blf_post_list(request, "trough_size_width[]")
	height_values = _blf_post_list(request, "trough_size_height[]")
	name_values = _blf_post_list(request, "trough_name[]")
	leaf_type_values = _blf_post_list(request, "trough_leaf_type[]")
	trough_rows = []
	for index, capacity in enumerate(capacity_values):
		width = width_values[index] if index < len(width_values) else ""
		height = height_values[index] if index < len(height_values) else ""
		name = name_values[index] if index < len(name_values) else ""
		leaf_type = leaf_type_values[index] if index < len(leaf_type_values) else ""
		if capacity or width or height or name or leaf_type:
			trough_rows.append({
				"capacity_qty": capacity,
				"size_width": width,
				"size_height": height,
				"name": name,
				"leaf_type": leaf_type,
			})
	return production_rows, trough_rows


def _blf_rows_from_instance(blf):
	if not blf:
		return [], []
	production_rows = [
		{
			"tea_type_id": item.tea_type_id,
			"tea_grade_id": item.tea_grade_id,
			"marks": item.marks or "",
			"quantity": item.quantity or "",
		}
		for item in blf.tea_productions_blf.select_related("tea_type", "tea_grade").order_by("id")
	]
	trough_rows = [
		{
			"capacity_qty": item.capacity_qty or "",
			"size_width": item.size_width or "",
			"size_height": item.size_height or "",
			"name": item.name or "",
			"leaf_type": item.leaf_type or "",
		}
		for item in blf.blf_trough_details.order_by("id")
	]
	return production_rows, trough_rows


def _default_blf_repeat_rows(production_rows, trough_rows):
	if not production_rows:
		production_rows = [{
			"tea_type_id": "",
			"tea_grade_id": "",
			"marks": "",
			"quantity": "",
		}]
	if not trough_rows:
		trough_rows = [{
			"capacity_qty": "",
			"size_width": "",
			"size_height": "",
			"name": "",
			"leaf_type": "",
		}]
	return production_rows, trough_rows


def _save_blf_repeat_rows(blf, request):
	production_rows, trough_rows = _blf_rows_from_post(request)
	BlfTeaProduction.objects.filter(blf=blf).delete()
	BlfTroughDetails.objects.filter(user_profile_blf=blf).delete()

	production_objects = []
	for row in production_rows:
		production_objects.append(BlfTeaProduction(
			blf=blf,
			tea_type_id=row["tea_type_id"] or None,
			tea_grade_id=row["tea_grade_id"] or None,
			marks=row["marks"],
			quantity=row["quantity"],
		))
	if production_objects:
		BlfTeaProduction.objects.bulk_create(production_objects)

	trough_objects = []
	for row in trough_rows:
		trough_objects.append(BlfTroughDetails(
			user_profile_blf=blf,
			capacity_qty=row["capacity_qty"],
			size_width=row["size_width"],
			size_height=row["size_height"],
			name=row["name"],
			leaf_type=row["leaf_type"],
		))
	if trough_objects:
		BlfTroughDetails.objects.bulk_create(trough_objects)


class BlfProfileUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	BLF PROFILE Update View
	"""
	model = BlfProfile
	form_class = BlfProfileForm
	template_name = 'profile/blf_profile_create.html'

	def get(self, request, *args, **kwargs):
		# checking if the user is Admin
		# try:
		# 	if request.user.profile.user_type == 'ADMIN':
		# 		messages.error(request, 'You have no permission to access the requested resource!')
		# 		return redirect(reverse('hr:employee_dashboard'))
		# 	elif request.user.profile.user_type == 'CUSTOMER':
		# 		messages.error(request, 'You have no permission to access the requested resource!')
		# 		return redirect(reverse('index'))
		# except AttributeError as error:
		# 	messages.error(request, 'You have no permission to access the requested resource!')
		# 	return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'BLF Profile Updated Successfully')
		return reverse('user_profile:blf_profile_create', kwargs={"user_create_pk": self.kwargs['user_create_pk'] } )
		

	def get_object(self):
		profile_details = BlfProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(BlfProfileUpdateView, self).get_context_data(**kwargs)
		profile = getattr(self, "object", None) or self.get_object()
		context['profile_details'] = profile
		if self.request.POST:
			production_rows, trough_rows = _blf_rows_from_post(self.request)
		else:
			production_rows, trough_rows = _blf_rows_from_instance(profile)
		production_rows, trough_rows = _default_blf_repeat_rows(production_rows, trough_rows)
		context["blf_tea_production_rows"] = production_rows
		context["blf_trough_rows"] = trough_rows
		context["tea_type_options"] = TeaType.objects.filter(is_deleted=False).order_by("name")
		context["tea_grade_options"] = TeaGradeDetails.objects.filter(is_deleted=False).select_related("tea_type").order_by("grade")
		context["leaf_type_options"] = BlfTroughDetails.LEAF_TYPE
		context["current_url"] = True
		context["next_url"] = get_safe_next_url(self.request, _profile_list_default("blf"))
		context["reset_password_url"] = reverse("accounts:reset_default_password", kwargs={"user_id": profile.user_id}) if profile and profile.user_id else ""
		context["default_password"] = DEFAULT_USER_PASSWORD
		return context


	def form_valid(self, form):
		self.user_id = self.kwargs['user_create_pk']

		with transaction.atomic():
			self.object = form.save()
			_save_blf_repeat_rows(self.object, self.request)

		return super(BlfProfileUpdateView, self).form_valid(form)


class BlfProfileDetailView(LoginRequiredMixin, CommonMixin, DetailView):
	""" Blf Profile Details View """
	context_object_name = 'blf_detail'
	model = BlfProfile
	template_name = "profile/blf_profile_view.html"

	def get_object(self):
		blf_detail = BlfProfile.objects.filter(
			user_id=self.kwargs['user_create_pk']).first()
		return blf_detail

	def get_context_data(self, **kwargs):
		context = super(BlfProfileDetailView,
						self).get_context_data(**kwargs)

		blf_details = self.get_object()

		if self.request.POST:
			context['blf_tea_production_row_formset'] = BLF_TEA_PRODUCTION_FORM_SET(self.request.POST, instance=self.get_object())
		else:
			context['blf_tea_production_row_formset'] = BLF_TEA_PRODUCTION_FORM_SET(instance=self.get_object())

		if self.request.POST:
			context['blf_through_formset'] = BLF_TROUGH_FORMSET(self.request.POST, instance=self.get_object())
		else:
			context['blf_through_formset'] = BLF_TROUGH_FORMSET(instance=self.get_object())

		context['form'] = BlfProfileForm(instance=blf_details)
		context["next_url"] = get_safe_next_url(self.request, _profile_list_default("blf"))

		return context



# API views to fetch Entity details

def get_entity_list_view(request):

	entity_list = get_entity_list_from_api()
	unit_list = get_unit_list_from_api()

	context = {
		'entity_list' : entity_list,
		'unit_list' : unit_list
	}
	return CommonMixin.render(request, 'profile/api_entity_details.html', context)



def ajax_entity_unit_list(request):
	unit_list = get_unit_list_from_api()
	# cities = City.objects.filter(country_id=country_id).order_by('name')
	# print("Subhashis")
	context = {
		
	}
	return render(request, 'profile/unit_list.html', context)
	

def unit_details(request):

	id = request.GET.get('id', None)


	value = get_unit_list_details_from_api(id)

	data = {
		"value" : value
	}

	return JsonResponse(data)
	# return render(request, 'profile/unit_list.html', JsonResponse(data))


def entity_details(request):
	id = request.GET.get('id', None)
	value = get_entity_list_details_from_api(id)
	data = {
		"value" : value
	}
	return JsonResponse(data)



# def create_factory_marks(request):

# 	print("############## Here isb post ############")

# 	if request.method == "POST":
# 		form = FactoryDetailsMarksForm(request.POST)
# 		if form.is_valid():
# 			name = request.POST.get('name')
# 			created = FactoryDetailsMarks.objects.create(name=name)
# 			created.save()
			
# 			print("Frm Submited ############## ")
# 			# response_data = {}
# 			# created = FactoryDetailsMarks.objects.create(name=name)
# 			# created.save()
# 			# post = FactoryDetailsMarks(name=name)
# 			# post.save()

# 			# response_data['result'] = 'Create post successful!'
# 			# response_data['name'] = post.name

# 			messages.success(request, 'Successfully Created!')
# 		else:
# 			messages.error(request, 'Please Correct The Error Below.')
# 	else:
# 		form = FactoryDetailsMarksForm()

# 	# return HttpResponse(
# 	# 		json.dumps(response_data),
# 	# 		content_type="application/json"
# 	# 	)
# 	return HttpResponseRedirect(request.META.get("HTTP_REFERER"))




########## Estate PROFILE VIEW ###############

class EstateCreateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	Estate Profile Create View 
	"""
	model = EstateProfile
	form_class = EstateProfileForm
	template_name = 'estate_create.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)


	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Estate Profile Updated Successfully')
		factory_details = FactoryTroughDetails.objects.filter(user_id=self.kwargs['user_create_pk']).first()

		return reverse('user_profile:estate_trough_details_update', kwargs={"user_create_pk": self.kwargs['user_create_pk'], \
								       "factory_pk": factory_details.pk})

	def get_object(self):	
		profile_details = EstateProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(EstateCreateView, self).get_context_data(**kwargs)
		context['profile_details'] = self.get_object()
		if self.request.POST:
			context['estate_production_row_formset'] = ESTATE_PRODUCTIONS_FORM_SET(self.request.POST, instance=self.get_object())
		else:
			context['estate_production_row_formset'] = ESTATE_PRODUCTIONS_FORM_SET(instance=self.get_object())

		return context
	
	def form_invalid(self, form):
		error_message = 'Error saving the Form, check fields below.'
		messages.error(self.request, error_message)
		return super().form_invalid(form)

	def form_valid(self, form):

		self.user_id = self.kwargs['user_create_pk']
		context = self.get_context_data()

		estate_production_row_formset = context['estate_production_row_formset']

		FactoryTroughDetails.objects.update_or_create(user_id=self.kwargs['user_create_pk'], defaults={
			'estate': form.instance,})

		with transaction.atomic():
			self.object = form.save()

			if estate_production_row_formset.is_valid():
				estate_production_row_formset.instance = self.object
				estate_production_row_formset.save()

			if not form.is_valid() or not estate_production_row_formset.is_valid():
				return self.render_to_response(context)

		return super(EstateCreateView, self).form_valid(form)
	


class EstateProfileUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	Estate PROFILE Update View
	"""
	model = EstateProfile
	form_class = EstateProfileForm
	template_name = 'profile/estate_profile_create.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Estate Profile Updated Successfully')
		return get_safe_next_url(self.request, _profile_list_default("estate"))

	def get_object(self):
		profile_details = EstateProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(EstateProfileUpdateView, self).get_context_data(**kwargs)

		context['profile_details'] = self.get_object()

		if self.request.POST:
			context['estate_production_row_formset'] = ESTATE_PRODUCTIONS_FORM_SET(self.request.POST, instance=self.get_object())
		else:
			context['estate_production_row_formset'] = ESTATE_PRODUCTIONS_FORM_SET(instance=self.get_object())
		context["current_url"] = True
		context["next_url"] = get_safe_next_url(self.request, _profile_list_default("estate"))
		return context
	
	
	def form_invalid(self, form):
		error_message = 'Error saving the Form, check fields below.'
		messages.error(self.request, error_message)
		return super().form_invalid(form)

	def form_valid(self, form):

		self.user_id = self.kwargs['user_create_pk']
		context = self.get_context_data()

		estate_production_row_formset = context['estate_production_row_formset']

		# FactoryTroughDetails.objects.update_or_create(user_id=self.kwargs['user_create_pk'], defaults={
		# 	'estate': form.instance,})

		with transaction.atomic():
			self.object = form.save()

			if estate_production_row_formset.is_valid():
				estate_production_row_formset.instance = self.object
				estate_production_row_formset.save()

			if not form.is_valid() or not estate_production_row_formset.is_valid():
				return self.render_to_response(context)

		return super(EstateProfileUpdateView, self).form_valid(form)
	


class EstateTroughList(LoginRequiredMixin, CommonMixin, ListView):
	"""
	Estate Trough Details List View
	"""
	model = FactoryTroughDetails
	context_object_name = 'factory_trough_list'
	template_name = 'factory_trough_list.html'
	paginate_by = 10

	def get(self, request, *args, **kwargs):
	# checking if the user is customer
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_queryset(self):
		print(self.kwargs['user_create_pk'])
		return FactoryTroughDetails.objects.filter(user_id=self.kwargs['user_create_pk']).order_by('-id')

	def get_context_data(self, **kwargs):
		context = super().get_context_data(**kwargs)
		context['profile_type'] = "estate"
		context['user_id'] = self.kwargs['user_create_pk']
		print(self.kwargs['user_create_pk'])
		return context




class EstateTroughUpdate(LoginRequiredMixin, CommonMixin, UpdateView):

	model = FactoryTroughDetails
	form_class = FactoryTroughDetailsForm
	template_name = 'estate_trough_form.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is customer
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Updated Successfully')
		profile_details = EstateProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return reverse('user_profile:estate_trough_details_list', kwargs={"user_create_pk": self.kwargs['user_create_pk'] })
		# return reverse('gardens_managment:garden_details', kwargs={"grower_pk": grower_details })

	def get_object(self):
		profile_details = EstateProfile.cmobjects.filter(user_id=self.kwargs['user_create_pk']).first()
		factory_through_details = FactoryTroughDetails.objects.filter(pk=self.kwargs['factory_pk']).first()
		return factory_through_details

	def get_context_data(self, **kwargs):
		context = super(EstateTroughUpdate, self).get_context_data(**kwargs)
		context['factory_through_details'] = self.get_object()

		context['profile_type'] = "estate"
		context['user_id'] = self.kwargs['user_create_pk']

		if self.request.POST:
			context['estate_trough_form_set'] = ESTATE_TROUGH_FORM_SET(self.request.POST, instance=self.get_object())	
		else:
			context['estate_trough_form_set'] = ESTATE_TROUGH_FORM_SET(instance=self.get_object())

		return context

	def form_valid(self, form):
		profile_details = EstateProfile.cmobjects.filter(user_id=self.kwargs['user_create_pk']).first()
		print(profile_details.pk)
		self.estate_id = profile_details.pk
		context = self.get_context_data()
		estate_trough_form_set = context['estate_trough_form_set']

		with transaction.atomic():
			self.object = form.save()

			if estate_trough_form_set.is_valid():
				estate_trough_form_set.instance = self.object
				estate_trough_form_set.save()

			if not form.is_valid() or not estate_trough_form_set.is_valid():
				# formsets or form is invalid; render the form with error
				return self.render_to_response(context)

		return super(EstateTroughUpdate, self).form_valid(form)



class EstateTroughCreate(LoginRequiredMixin, CommonMixin, CreateView):

	model = FactoryTroughDetails
	form_class = FactoryTroughDetailsForm
	template_name = 'estate_trough_form.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is customer
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Updated Successfully')
		profile_details = EstateProfile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return reverse('user_profile:estate_trough_details_list', kwargs={"user_create_pk": self.kwargs['user_create_pk'] })
		# return reverse('gardens_managment:garden_details', kwargs={"grower_pk": grower_details })

	def get_context_data(self, **kwargs):
		context = super(EstateTroughCreate, self).get_context_data(**kwargs)
		context['profile_type'] = "estate"
		context['user_id'] = self.kwargs['user_create_pk']

		if self.request.POST:
			context['estate_trough_form_set'] = ESTATE_TROUGH_FORM_SET(self.request.POST)	
		else:
			context['estate_trough_form_set'] = ESTATE_TROUGH_FORM_SET()
		return context

	def form_valid(self, form):
		profile_details = EstateProfile.cmobjects.filter(user_id=self.kwargs['user_create_pk']).first()
		context = self.get_context_data()
		estate_trough_form_set = context['estate_trough_form_set']

		with transaction.atomic():
			form.instance.user_id = self.kwargs['user_create_pk']
			form.instance.estate_id = profile_details.pk

			self.object = form.save()
			if estate_trough_form_set.is_valid():
				estate_trough_form_set.instance = self.object
				estate_trough_form_set.save()

			if not form.is_valid() or not estate_trough_form_set.is_valid():
				# formsets or form is invalid; render the form with error
				return self.render_to_response(context)

		return super(EstateTroughCreate, self).form_valid(form)


def estate_factory_trough_details(request, user_create_pk, factory_pk):
	factory_details = FactoryTroughDetails.objects.filter(pk=factory_pk).first()
	trough_list = EstateTroughDetails.objects.filter(factory_id=factory_pk).order_by('-id')
	context={
		'factory_details' : factory_details,
		'user_id' : user_create_pk, 
		'trough_list' : trough_list,
	}

	return CommonMixin.render(request, 'factory_trough_details.html', context)


def estate_factory_delete(request, factory_pk, user_create_pk):
	with transaction.atomic():
		factory_details = FactoryTroughDetails.objects.filter(pk=factory_pk).first()
		factory_details.delete()
		messages.success(
			request, 'Deleted Successfully')

	return redirect(reverse('user_profile:estate_trough_details_list', kwargs={"user_create_pk": user_create_pk }))

	
# PROFILE UPDATE VIEW

class ProfileUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	PROFILE Update View
	"""
	model = Profile
	form_class = ProfileForm
	template_name = 'edit_profile.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is Admin
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Profile Updated Successfully')
		return reverse('user_profile:grower_profile_edit', kwargs={"user_create_pk": self.kwargs['user_create_pk'] } )
		


	def get_object(self):
		profile_details = Profile.objects.filter(user_id=self.kwargs['user_create_pk']).first()
		return profile_details

	def get_context_data(self, **kwargs):
		context = super(ProfileUpdateView, self).get_context_data(**kwargs)

		context['profile_details'] = self.get_object()

		return context
	
	def form_invalid(self, form):
		error_message = 'Error saving the Form, check fields below.'
		messages.error(self.request, error_message)
		return super().form_invalid(form)

	def form_valid(self, form):

		self.user_id = self.kwargs['user_create_pk']
		context = self.get_context_data()

		with transaction.atomic():
			self.object = form.save()

			if not form.is_valid():
				return self.render_to_response(context)

		return super(ProfileUpdateView, self).form_valid(form)
	



def qr_code_generator(request):
	import pyqrcode
	import png
	from pyqrcode import QRCode

	s = "www.geeksforgeeks.org"

	url = pyqrcode.create(s)

	# Create and save the svg file naming "myqr.svg"
	url.svg("myqr.svg", scale = 8)

	# Create and save the png file naming "myqr.png"
	url.png('myqr.png', scale = 6)


	context = {

	}

	return render(request, 'qr_code.html', context)



# QR CODE VIEWS

def grower_qr_code(request, grower_pk):
   qr_code=GrowerQrCode.objects.filter(grower_id=grower_pk).first()
   print()
   context ={
		'qr_code':qr_code,
   }
   return render(request,"qrcode.html", context)



def aggregator_qr_code(request, aggragator_pk):
   
   qr_code=AggregatorQrCode.objects.filter(aggregator_id=aggragator_pk).first()
   
   context ={
		'qr_code':qr_code,
   }

   return render(request,"qrcode.html", context)


###############   Grower Form    ################

# def blf_list_region_wise(request):
# 	""" Region   """
# 	print("HEllo Region wise Entity")
# 	id = request.GET.get('id', None)
# 	print(id)
# 	# supply_date = weighment_details.supply_date
# 	blf_list_region_wise = BlfProfile.cmobjects.filter(region__region_name__exact=id).values('id', 'user')
# 	print(blf_list_region_wise)

# 	options = '<option value="">---------</option>'
# 	for subcategory in blf_list_region_wise:
# 		options += f'<option value="{subcategory.id}">{subcategory.user}</option>'

# 	# value = list(blf_list_region_wise)

# 	data = {'options': options}

# 	# data = {
# 	# 	"value" : value,
# 	# }
# 	return JsonResponse(data)


# def entity_details(request):
# 	id = request.GET.get('id', None)
# 	value = get_entity_list_details_from_api(id)
# 	data = {
# 		"value" : value
# 	}
# 	return JsonResponse(data)


# def region_list_easy_mode_wise(request):
# 	mode = request.GET.get('mode', None)
# 	mode_wise_region = BlfProfile.objects.filter(easy_weight_system=mode)
# 	# Get a list of distinct values for the easy_weight_system field
# 	# distinct_values = mode_wise_region.values_list('easy_weight_system', flat=True).distinct()
# 	# distinct_values = list(set(mode_wise_region.values_list('easy_weight_system', flat=True)))

# 	# print(f"VALUES = {distinct_values}")

# 	context = {
# 		'mode_wise_region': mode_wise_region
# 	}
# 	return render(request, 'mode_wise_region.html', context)


def region_list_easy_mode_wise(request):
	mode = request.GET.get('mode', None)
	mode_wise_profiles = BlfProfile.objects.filter(easy_weight_system=mode).exclude(region__isnull=True)
	# Get a list of distinct region names
	distinct_regions = mode_wise_profiles.values_list('region__region_name', flat=True).distinct()

	context = {
		'mode_wise_region': distinct_regions,
		'mode_wise_profiles' : mode_wise_profiles,
		'selected_mode': mode,
	}
	return render(request, 'mode_wise_region.html', context)




def blf_list_region_wise_back(request):
	
	id = request.GET.get('id', None)
	mode = str(request.GET.get('mode', None))
	if not id.isdigit():
		# id is a positive integer
		id_str = str(id)
		region_details = Region.cmobjects.filter(region_name__exact=id_str).first()
		id = region_details.pk

	if mode:
		blf_list_region_wise = BlfProfile.cmobjects.filter(region_id=id, easy_weight_system__exact=mode)
	else:
		blf_list_region_wise = BlfProfile.cmobjects.filter(region_id=id)

	context = {
		'blf_list_region_wise': blf_list_region_wise
	}

	return render(request, 'blf_ajax_list.html', context)




def blf_list_region_wise(request):
	id = request.GET.get('id', None)
	if not id.isdigit():
		# id is a positive integer
		id_str = str(id)
		region_details = Region.cmobjects.filter(region_name__exact=id_str).first()
		id = region_details.pk
	
	blf_list_region_wise = BlfProfile.cmobjects.filter(region_id=id)
	context = {
		'blf_list_region_wise': blf_list_region_wise
	}
	return render(request, 'blf_ajax_list.html', context)





def aggregator_list_blf_wise(request):
	id = request.GET.get('id', None)
	agg_list_blf_wise = (
		AggregatorProfile.objects
		.filter(Q(associated_blf_id=id) | Q(associated_entity=id), user__is_active=True)
		.select_related("user")
		.distinct()
		.order_by('user__username')
	)
	context = {
		'agg_list_blf_wise': agg_list_blf_wise
	}
	return render(request, 'agg_list_blf_wise.html', context)

###### Visiting Card #################################################
def generate_qr_code(qr_code, user_id,user_type):
		qr = qrcode.QRCode(
		    version=1,
		    error_correction=qrcode.constants.ERROR_CORRECT_L,
		    box_size=10,
		    border=4,
		)
		qr.add_data(qr_code)

		qr.make(fit=True)
		qr_code_image = qr.make_image(fill_color="black", back_color="white")	
		# Specify the directory where you want to save the QR code image
		qr_code_directory = os.path.join(settings.MEDIA_DIR, "qrcode")  # Create a 'qrcodes' directory
		os.makedirs(qr_code_directory, exist_ok=True)		
		# Specify the filename for the QR code image
		qr_code_image_filename = f"{user_type}_{user_id}_qrcode.png"	
		# Save the QR code image using the file storage
		qr_code_image_path = os.path.join(qr_code_directory, qr_code_image_filename)
		qr_code_image.save(qr_code_image_path)		
		
		return qr_code_image_path
def GrowerVistingCard(request, grower_pk):
   
	details=GrowerProfile.objects.filter(id=grower_pk).first()
	if details:
		user_type=details.profile_type.name
		# qr_code=GrowerProfile.objects.filter(user_id=user).first()	
		user_id=details.user
		# qr_code= "Grower ID : " + str(details.user) + "\n" + "Name : " + str(details.name)
		# print("print qr",qr_code)
		qr_code = {
			'userid': details.user.id,
			'name': details.name,
			'id': details.id,
			'username': details.user.username
					}
		qr_code_image_path = generate_qr_code(qr_code,user_id ,user_type)

		media_url = settings.MEDIA_URL.rstrip('/')  # Remove trailing slash if present
		absolute_qr_code_image_url = request.build_absolute_uri(qr_code_image_path.replace(settings.MEDIA_DIR, media_url).replace("\\", "/"))
		if details is not None:
			if details.photo:
				details_photo_url = request.build_absolute_uri(details.photo.url)
			else:
				details_photo_url = None
		else:
			details_photo_url = None
		context ={
			'details':details,
			'user_type':user_type,
			'details_photo_url':details_photo_url,
			'absolute_qr_code_image_url':absolute_qr_code_image_url

		}
		return render(request,"visiting.html", context)	
	else:
		messages.error(request, "Grower details not found")
		# Return an appropriate response in case details are not found
		return HttpResponse("Grower details not found")
def AggregatorVistingCard(request, aggregator_pk):
   
	details=AggregatorProfile.objects.filter(id=aggregator_pk).first()
	if details:
		user_type=details.profile_type.name
		# qr_code=GrowerProfile.objects.filter(user_id=user).first()	
		user_id=details.user
		# qr_code= "Aggregator ID : " + str(details.user) + "\n" + "Name : " + str(details.name)
		qr_code = {
		'userid': details.user.id,
		'name': details.name,
		'id': details.id,
		'username': details.user.username
				}
		qr_code_image_path = generate_qr_code(qr_code,user_id ,user_type)

		media_url = settings.MEDIA_URL.rstrip('/')  # Remove trailing slash if present
		absolute_qr_code_image_url = request.build_absolute_uri(qr_code_image_path.replace(settings.MEDIA_DIR, media_url).replace("\\", "/"))
		if details is not None:
			if details.user_file:
				details_photo_url = request.build_absolute_uri(details.user_file.url)
			else:
				details_photo_url = None
		else:
			details_photo_url = None
		context ={
			'details':details,
			'user_type':user_type,
			'details_photo_url':details_photo_url,
			'absolute_qr_code_image_url':absolute_qr_code_image_url

	}
	return render(request,"visiting.html", context)	
	    


#### AJAX TEA GRADE LOAD

def blf_tea_grade_ajax(request):
	tea_type = request.GET.get('tea_type', None)
	print("TEA GRADE dwdwd ########################",  tea_type)
	tea_type = request.GET.get('tea_type', None)
	print("Tea Type ###################gggw", tea_type)
	tea_grade_list = TeaGradeDetails.objects.filter(tea_type_id=tea_type).order_by('-id')
	print("tea_grade_listt", tea_grade_list)
	context = {
		'tea_grade_list': tea_grade_list
	}
	return render(request, 'tea_type_ajax.html', context)



	# logged_user_type = Profile.objects.filter(user_id=request.user.id).first()
	# user_type = logged_user_type.user_type
	# try:
	# 	if not str(user_type.name) == "blf" and request.user.is_authenticated:
	# 		messages.error(request, 'You have no permission to access the requested resource!')
	# 		return redirect(reverse('index'))
	# except AttributeError as error:
	# 	messages.error(request, 'You have no permission to access the requested resource!')
	# 	return redirect(reverse('index'))



	# range = range_details.bag_sl_no_range
	# print(range)

	# if request.is_ajax():
	# 	html = render_to_string('tea_type_ajax.html',
	# 							context, request=request)
	# data = {
	# 	'html': html
	# }

	# data = {
	# 	'value': tea_type
	# }

	# return JsonResponse(data)

	# context = {
	# 	'tea_grade_list': tea_grade_list
	# }

	# return render(request, 'tea_type_ajax.html', context)
	# 	}
	# 	return render(request,"visiting.html", context)	
	# else:
	# 	messages.error(request, "Aggregator details not found")
	# 	# Return an appropriate response in case details are not found
	# 	return HttpResponse("Aggregator details not found")

from django.shortcuts import render
def DownloadVistingCard(request, user_pk, user_type):
    print('user_type', user_type)

    if user_type.lower() == 'grower':
        details = GrowerProfile.objects.filter(user_id=user_pk).first()
        if details:
            print("details", details)
            user_type = details.profile_type.name
            user_id = details.user
            
            qr_code = {
                'userid': details.user.id,
                'name': details.name,
                'id': details.id,
                'username': details.user.username
            }
            
            qr_code_image_path = generate_qr_code(qr_code, user_id, user_type)
            media_url = settings.MEDIA_URL.rstrip('/')  # Remove trailing slash if present
            absolute_qr_code_image_url = request.build_absolute_uri(qr_code_image_path.replace(settings.MEDIA_DIR, media_url).replace("\\", "/"))
            
            if details is not None:
                if details.photo:
                    details_photo_url = request.build_absolute_uri(details.photo.url)
                else:
                    details_photo_url = None
            else:
                details_photo_url = None
            
            context = {
                'details': details,
                'user_type': user_type,
                'details_photo_url': details_photo_url,
                'absolute_qr_code_image_url': absolute_qr_code_image_url
            }
            
            template_path = 'visiting_download.html'
            html = get_template(template_path).render(context)
            
            response = HttpResponse(content_type='application/pdf')
            response['Content-Disposition'] = 'attachment; filename="visiting_card.pdf"'
            
            # Generate PDF from HTML content
            pisa_status = pisa.CreatePDF(html, dest=response)
            if pisa_status.err:
                error_message = f"Something went wrong"
                return render(request, 'error.html', {'error_message': error_message})
            
            return response
            
        else:
            error_message = f"Something went wrong"
            return render(request, 'error.html', {'error_message': error_message})

    elif user_type.lower() == 'aggregator':
        details = AggregatorProfile.objects.filter(user_id=user_pk).first()
        if details:
            user_type = details.profile_type.name
            user_id = details.user

            qr_code = {
                'userid': details.user.id,
                'name': details.name,
                'id': details.id,
                'username': details.user.username
            }

            qr_code_image_path = generate_qr_code(qr_code, user_id, user_type)
            media_url = settings.MEDIA_URL.rstrip('/')  # Remove trailing slash if present
            absolute_qr_code_image_url = request.build_absolute_uri(qr_code_image_path.replace(settings.MEDIA_DIR, media_url).replace("\\", "/"))

            if details is not None:
                if details.user_file:
                    details_photo_url = request.build_absolute_uri(details.user_file.url)
                else:
                    details_photo_url = None
            else:
                details_photo_url = None

            context = {
                'details': details,
                'user_type': user_type,
                'details_photo_url': details_photo_url,
                'absolute_qr_code_image_url': absolute_qr_code_image_url
            }
            template_path = 'visiting_download.html'
            html = get_template(template_path).render(context)

            response = HttpResponse(content_type='application/pdf')
            response['Content-Disposition'] = 'attachment; filename="visiting_card.pdf"'

            # Generate PDF from HTML content
            pisa_status = pisa.CreatePDF(html, dest=response)
            if pisa_status.err:
                error_message = f"Something went wrong"
                return render(request, 'error.html', {'error_message': error_message})

            return response

        else:
            error_message = f"Something went wrong"
            return render(request, 'error.html', {'error_message': error_message})


		









#####################  Reports View ######################

def _report_page(queryset, page_number, per_page=10):
	paginator = Paginator(queryset, per_page)
	try:
		return paginator.page(page_number or 1), paginator
	except PageNotAnInteger:
		return paginator.page(1), paginator
	except EmptyPage:
		return paginator.page(paginator.num_pages), paginator


def _report_querystring(request):
	query_params = request.GET.copy()
	query_params.pop("page", None)
	return query_params.urlencode()


def _selected_report_blf(request):
	blf_id = request.GET.get("blf_entity", "").strip()
	if not blf_id.isdigit():
		return None
	return BlfProfile.cmobjects.select_related("user").filter(pk=blf_id).first()


def _register_report_context(request, report_type, queryset, selected_blf=None, extra=None):
	page_obj, paginator = _report_page(queryset, request.GET.get("page", 1))
	current_path = request.get_full_path()
	context = {
		"report_type": report_type,
		"page_obj": page_obj,
		"paginator": paginator,
		"total_count": paginator.count,
		"querystring": _report_querystring(request),
		"search_query": request.GET.get("q", "").strip(),
		"selected_blf": selected_blf,
		"selected_blf_entity": request.GET.get("blf_entity", "").strip(),
		"selected_tcms_verified": request.GET.get("is_tcms_user", "").strip(),
		"blf_entities": BlfProfile.cmobjects.select_related("user").order_by("entity_unit", "user__username"),
		"requires_blf_selection": report_type in ("aggregator", "grower") and not selected_blf,
		"current_list_url": current_path,
		"query_has_filter": any(
			request.GET.get(param, "").strip()
			for param in ("q", "blf_entity", "is_tcms_user")
		),
	}
	context["export_enabled"] = context["query_has_filter"] and paginator.count > 0
	if extra:
		context.update(extra)
	return context


def _aggregator_register_queryset(request):
	selected_blf = _selected_report_blf(request)
	if not selected_blf:
		return AggregatorProfile.cmobjects.none(), None
	queryset = (
		AggregatorProfile.cmobjects
		.filter(associated_entity=selected_blf)
		.select_related("user", "region", "state", "district")
		.distinct()
		.order_by("-id")
	)
	search_query = request.GET.get("q", "").strip()
	if search_query:
		queryset = queryset.filter(
			Q(user__username__icontains=search_query)
			| Q(name__icontains=search_query)
			| Q(mobile_number__icontains=search_query)
			| Q(region__region_name__icontains=search_query)
			| Q(state__name__icontains=search_query)
			| Q(district__name__icontains=search_query)
		)
	return queryset, selected_blf


@login_required
def aggregator_register_list_blf_report(request):
	queryset, selected_blf = _aggregator_register_queryset(request)
	context = _register_report_context(request, "aggregator", queryset, selected_blf)
	if _is_ajax_request(request):
		return CommonMixin.render(request, "reports/_register_report_table.html", context)
	return CommonMixin.render(request, "reports/register_report_list.html", context)



from django.utils import timezone


def _register_export_columns(report_type):
	if report_type == "aggregator":
		return [
			("Sr. No", lambda item, index: index),
			("Username/ID", lambda item, index: item.user.username if item.user else "NA"),
			("Name", lambda item, index: item.name or "NA"),
			("Type", lambda item, index: item.aggregator_type or "NA"),
			("Region", lambda item, index: item.region.region_name if item.region else "NA"),
			("State", lambda item, index: item.state.name if item.state else "NA"),
			("District", lambda item, index: item.district.name if item.district else "NA"),
			("Mobile No.", lambda item, index: item.mobile_number or "NA"),
			("GSTIN ID", lambda item, index: item.gstin_no or "NA"),
		]
	if report_type == "grower":
		return [
			("Sr. No", lambda item, index: index),
			("Username/ID", lambda item, index: item.user.username if item.user else "NA"),
			("Name", lambda item, index: item.name or "NA"),
			("Grower Type", lambda item, index: item.grower_type or "NA"),
			("Associated Aggregator", lambda item, index: ", ".join(str(agg.user) for agg in item.associated_aggregator.all()) or "NA"),
			("Region", lambda item, index: item.region.region_name if item.region else "NA"),
			("State", lambda item, index: item.state.name if item.state else "NA"),
			("District", lambda item, index: item.district.name if item.district else "NA"),
			("Mobile No.", lambda item, index: item.mobile_number or "NA"),
			("TBR No.", lambda item, index: item.tea_board_id or "NA"),
		]
	return [
		("Sr. No", lambda item, index: index),
		("Username/ID", lambda item, index: item.user.username if item.user else "NA"),
		("Entity Unit", lambda item, index: item.entity_unit or "NA"),
		("TCMO No.", lambda item, index: getattr(item, "tcms_unit_id", None) or "NA"),
		("Region", lambda item, index: item.region.region_name if item.region else "NA"),
		("TCMS Verified", lambda item, index: "YES" if item.is_tcms_user else "NO"),
	]


def _register_export_queryset(request, report_type):
	if report_type == "aggregator":
		return _aggregator_register_queryset(request)
	if report_type == "grower":
		return _grower_register_queryset(request)
	return _entity_register_queryset(request), None


def _register_export_filename(report_type, selected_blf, extension):
	if selected_blf:
		prefix = (selected_blf.entity_unit or selected_blf.user.username or report_type).replace(" ", "_")
	else:
		prefix = report_type
	return f"{prefix}_{report_type}_register.{extension}"


def _register_export_allowed(request, queryset, report_type, selected_blf):
	if report_type in ("aggregator", "grower") and not selected_blf:
		return False
	has_filter = any(request.GET.get(param, "").strip() for param in ("q", "blf_entity", "is_tcms_user"))
	return has_filter and queryset.exists()


def _register_report_pdf(request, report_type):
	queryset, selected_blf = _register_export_queryset(request, report_type)
	if not _register_export_allowed(request, queryset, report_type, selected_blf):
		return redirect(reverse({
			"aggregator": "user_profile:aggregator_register_reports",
			"grower": "user_profile:grower_register_reports",
			"entity": "user_profile:entity_register_list",
		}[report_type]))
	columns = _register_export_columns(report_type)
	response = HttpResponse(content_type="application/pdf")
	response["Content-Disposition"] = f'attachment; filename="{_register_export_filename(report_type, selected_blf, "pdf")}"'
	html = get_template("reports/register_report_pdf.html").render({
		"title": f"{report_type.title()} Register",
		"selected_blf": selected_blf,
		"columns": [column[0] for column in columns],
		"rows": [[getter(item, index) for _, getter in columns] for index, item in enumerate(queryset, start=1)],
		"current_date": timezone.localdate(),
	})
	pisa.CreatePDF(html, dest=response)
	return response


def _register_report_excel(request, report_type):
	queryset, selected_blf = _register_export_queryset(request, report_type)
	if not _register_export_allowed(request, queryset, report_type, selected_blf):
		return redirect(reverse({
			"aggregator": "user_profile:aggregator_register_reports",
			"grower": "user_profile:grower_register_reports",
			"entity": "user_profile:entity_register_list",
		}[report_type]))
	columns = _register_export_columns(report_type)
	wb = openpyxl.Workbook()
	ws = wb.active
	ws.title = f"{report_type.title()} Register"
	for col_num, (header, _) in enumerate(columns, start=1):
		ws.cell(row=1, column=col_num, value=header)
	for row_num, item in enumerate(queryset, start=2):
		for col_num, (_, getter) in enumerate(columns, start=1):
			ws.cell(row=row_num, column=col_num, value=getter(item, row_num - 1))
	response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	response["Content-Disposition"] = f'attachment; filename="{_register_export_filename(report_type, selected_blf, "xlsx")}"'
	wb.save(response)
	return response


def report_aggregator_register_pdf(request):
	return _register_report_pdf(request, "aggregator")


def report_aggregator_register_excel(request):
	return _register_report_excel(request, "aggregator")

from django.shortcuts import get_object_or_404



def _grower_register_queryset(request):
	selected_blf = _selected_report_blf(request)
	if not selected_blf:
		return GrowerProfile.cmobjects.none(), None
	queryset = (
		GrowerProfile.cmobjects
		.filter(Q(associated_blf=selected_blf) | Q(associated_entity=selected_blf))
		.select_related("user", "region", "state", "district")
		.prefetch_related("associated_aggregator", "gardens_grower")
		.distinct()
		.order_by("-id")
	)
	search_query = request.GET.get("q", "").strip()
	if search_query:
		queryset = queryset.filter(
			Q(user__username__icontains=search_query)
			| Q(name__icontains=search_query)
			| Q(mobile_number__icontains=search_query)
			| Q(region__region_name__icontains=search_query)
			| Q(state__name__icontains=search_query)
			| Q(district__name__icontains=search_query)
			| Q(associated_aggregator__name__icontains=search_query)
		).distinct()
	return queryset, selected_blf


@login_required
def grower_register_list_blf_report(request):
	queryset, selected_blf = _grower_register_queryset(request)
	context = _register_report_context(request, "grower", queryset, selected_blf)
	if _is_ajax_request(request):
		return CommonMixin.render(request, "reports/_register_report_table.html", context)
	return CommonMixin.render(request, "reports/register_report_list.html", context)






def report_grower_register_pdf(request):
	return _register_report_pdf(request, "grower")


def report_grower_register_excel(request):
	return _register_report_excel(request, "grower")





def _entity_register_queryset(request):
	queryset = (
		BlfProfile.cmobjects
		.select_related("user", "region", "state", "district")
		.order_by("-id")
	)
	search_query = request.GET.get("q", "").strip()
	if search_query:
		queryset = queryset.filter(
			Q(user__username__icontains=search_query)
			| Q(entity_name__icontains=search_query)
			| Q(entity_unit__icontains=search_query)
			| Q(region__region_name__icontains=search_query)
			| Q(state__name__icontains=search_query)
			| Q(district__name__icontains=search_query)
		)
	tcms_filter = request.GET.get("is_tcms_user", "").strip()
	if tcms_filter in ("True", "False"):
		queryset = queryset.filter(is_tcms_user=(tcms_filter == "True"))
	return queryset


@login_required
def entity_register_list_blf_report(request):
	queryset = _entity_register_queryset(request)
	context = _register_report_context(request, "entity", queryset)
	if _is_ajax_request(request):
		return CommonMixin.render(request, "reports/_register_report_table.html", context)
	return CommonMixin.render(request, "reports/register_report_list.html", context)


def report_entity_register_pdf(request):
	return _register_report_pdf(request, "entity")


def report_entity_register_excel(request):
	return _register_report_excel(request, "entity")
from rest_framework import status

class DownloadVistingCardPDF(APIView):
	authentication_classes = (TokenAuthentication,)
	permission_classes = (IsAuthenticated,)
	# permission_classes = (AllowAny,)
	def get(self, request, *args, **kwargs):
		user_pk = self.request.query_params.get('user_id', None)
		user_type = self.request.query_params.get('user_type', None)

		try:
			if not user_pk or not user_type:
				raise ValueError('Invalid parameters')

			if user_type.lower() == 'grower':
				details = GrowerProfile.objects.filter(user_id=user_pk).first()
			elif user_type.lower() == 'aggregator':
				details = AggregatorProfile.objects.filter(user_id=user_pk).first()
			else:
				return Response({
				'msg': 'Invalid user type',
				'status': status.HTTP_400_BAD_REQUEST,
				'request_status': 0
			}, status=status.HTTP_400_BAD_REQUEST)

			if not details:
				return Response({
				'msg': 'User details not found',
				'status': status.HTTP_404_NOT_FOUND,
				'request_status': 0
			}, status=status.HTTP_200_OK)

			user_type = details.profile_type.name
			user_id = details.user

			qr_code = {
				'userid': details.user.id,
				'name': details.name,
				'id': details.id,
				'username': details.user.username
			}

			qr_code_image_path = generate_qr_code(qr_code, user_id, user_type)
			media_url = settings.MEDIA_URL.rstrip('/')  # Remove trailing slash if present
			absolute_qr_code_image_url = self.request.build_absolute_uri(qr_code_image_path.replace(settings.MEDIA_DIR, media_url).replace("\\", "/"))

			if details.photo:
				details_photo_url = self.request.build_absolute_uri(details.photo.url)
			else:
				details_photo_url = None

			context = {
				'details': details,
				'user_type': user_type,
				'details_photo_url': details_photo_url,
				'absolute_qr_code_image_url': absolute_qr_code_image_url
			}

			template_path = 'visiting_download.html'
			html = get_template(template_path).render(context)

			response = HttpResponse(content_type='application/pdf')
			response['Content-Disposition'] = 'attachment; filename="visiting_card.pdf"'

			# Generate PDF from HTML content
			pisa_status = pisa.CreatePDF(html, dest=response)
			if pisa_status.err:
				return Response({
					'msg': 'pdf generation failed',
					'status': status.HTTP_400_BAD_REQUEST,
					'request_status': 0
				}, status=status.HTTP_400_BAD_REQUEST)

			return response

		except Exception as e:
			return Response({
				'msg': 'An error occurred while retrieving visiting cad',
				'status': status.HTTP_400_BAD_REQUEST,
				'request_status': 0
			}, status=status.HTTP_400_BAD_REQUEST)
class VisitingCardGenerateWebAPIViewUrl(APIView):
	authentication_classes = (TokenAuthentication,)
	permission_classes = (IsAuthenticated,)
	def get(self, request, *args, **kwargs):
		try:
			user_type = self.request.query_params.get('user_type', None)
			id = self.request.query_params.get('id', None)

			if user_type == 'grower':
				url = reverse('user_profile:visiting_card_web', args=[user_type, id])

				print(url)
				absolute_url = request.build_absolute_uri(url)
				response_data = {
					'url': absolute_url,
				}
			elif user_type == 'aggregator':
				url = reverse('user_profile:visiting_card_web', args=[user_type, id])

				absolute_url = request.build_absolute_uri(url)
				response_data = {
					'url': absolute_url,
				}
			else:
				return Response({
					'msg': 'Invalid user type',
					'status': status.HTTP_400_BAD_REQUEST,
					'request_status': 0
				}, status=status.HTTP_400_BAD_REQUEST)

			return Response({
				'results': {'Data': response_data},
				'msg': 'Successful',
				'status': status.HTTP_200_OK,
				'request_status': 1
			})

		except Exception as e:
			return Response({
				'msg': str(e),
				'status': status.HTTP_400_BAD_REQUEST,
				'request_status': 0
			}, status=status.HTTP_400_BAD_REQUEST)
class VistingCardWebView(APIView):
	permission_classes = [AllowAny]

	def get(self, request, user_type,id):
		"""For APP """
		try:
			if user_type =='grower':
				details=GrowerProfile.objects.filter(id=id).first()
				print(details)
				if details:
					user_type=details.profile_type.name
					# qr_code=GrowerProfile.objects.filter(user_id=user).first()	
					user_id=details.user
					qr_code = {
						'userid': details.user.id,
						'name': details.name,
						'id': details.id,
						'username': details.user.username
					}
					qr_code_image_path = generate_qr_code(qr_code,user_id ,user_type)

					media_url = settings.MEDIA_URL.rstrip('/')  # Remove trailing slash if present
					absolute_qr_code_image_url = request.build_absolute_uri(qr_code_image_path.replace(settings.MEDIA_DIR, media_url).replace("\\", "/"))
					if details is not None:
						if details.photo:
							details_photo_url = request.build_absolute_uri(details.photo.url)
						else:
							details_photo_url = None
					else:
						details_photo_url = None
					context ={
						'details':details,
						'user_type':user_type,
						'details_photo_url':details_photo_url,
						'absolute_qr_code_image_url':absolute_qr_code_image_url

					}
		
				return render(request,"visiting.html", context)	
			elif user_type == 'aggregator':
				details=AggregatorProfile.objects.filter(id=id).first()
				if details:
					user_type=details.profile_type.name
					# qr_code=GrowerProfile.objects.filter(user_id=user).first()	
					user_id=details.user
					# qr_code= "Aggregator ID : " + str(details.user) + "\n" + "Name : " + str(details.name)
					qr_code = {
						'userid': details.user.id,
						'name': details.name,
						'id': details.id,
						'username': details.user.username
					}
					qr_code_image_path = generate_qr_code(qr_code,user_id ,user_type)

					media_url = settings.MEDIA_URL.rstrip('/')  # Remove trailing slash if present
					absolute_qr_code_image_url = request.build_absolute_uri(qr_code_image_path.replace(settings.MEDIA_DIR, media_url).replace("\\", "/"))
					if details is not None:
						if details.user_file:
							details_photo_url = request.build_absolute_uri(details.user_file.url)
						else:
							details_photo_url = None
					else:
						details_photo_url = None
					context ={
						'details':details,
						'user_type':user_type,
						'details_photo_url':details_photo_url,
						'absolute_qr_code_image_url':absolute_qr_code_image_url
				}
				return render(request,"visiting.html", context)			
			else:
				messages.error(request, "Grower details not found")
				# Return an appropriate response in case details are not found
				return HttpResponse("Grower details not found")
		except (ValueError) as e:
			error_message = "Something went wrong."
			return render(request, 'error.html', {'error_message': error_message}) 
		except Exception as e:
			error_message = "Something went wrong."
			return render(request, 'error.html', {'error_message': error_message}) 
		
#######  NEW USER PROFILE API #######
# class UserProfileMainAPIView(APIView):
# 	authentication_classes = (TokenAuthentication,)
# 	permission_classes = (IsAuthenticated,)
# 	def get(self, request, *args, **kwargs):
# 		default_type = 'grower'
# 		user_type = self.request.query_params.get('user_type', None)
# 		if not user_type:
# 			raise APIException({'request_status': 0, 'msg': "User type required"})
# 		search = {}
# 		search = custom_filters(self.request, search, ['user_type'])
# 		# id = self.request.query_params.get('id', None)
# 		all = request.query_params.get('all', None)
# 		order_by = request.query_params.get('order_by', '-id')
# 		created_by__full_name__icontains = request.query_params.get('created_by__full_name__icontains', None)
# 		USER_TYPE_CONFIG = {
# 			"grower": {
# 				"model": GrowerProfile,
# 				"serializer": GrowerProfileSerializer,
# 				"select_related" : ['state', 'user', 'region', 'district', 'profile_type'],
# 				"prefetch_related" : ["associated_aggregator", "associated_entity"],
# 				"values": [
# 					'id','user__username', 'is_tcms_user', 'tcms_supplier_code',
# 					'name', 'age', 'gender', 'date_of_birth', 'grower_type',
# 					'region__region_name', 'state__name', 'district__name',
# 					'region', 'state', 'district', 'production_area',
# 					'email', 'mobile_number', 'aadhar_no', 'address', 'tea_board_id', 'associated_aggregator', 
# 					'associated_entity', 'poi_type', 'poi_id',
# 				],
# 			},
# 			"aggregator": {
# 				"model": AggregatorProfile,
# 				"serializer": AggregatorProfileSerializer,
# 				"select_related" : ['state', 'user', 'region', 'district', 'profile_type'],
# 				"prefetch_related" : [],
# 				"values": [],
# 			},
# 			"blf": {
# 				"model": BlfProfile,
# 				"serializer": BlfProfileSerializer,
# 				"select_related" : ['state', 'user', 'region', 'district', 'profile_type'],
# 				"prefetch_related" : [],
# 				"values": [],
# 			},
# 		}
# 		config = USER_TYPE_CONFIG.get(user_type)
# 		if not config:
# 			raise APIException({'request_status': 0, 'msg': "Invalid user_type"})
# 		model = config["model"]
# 		values = config["values"]   

# 		_list = model.cmobjects.select_related(*config["select_related"]).prefetch_related(*config["prefetch_related"]).values(*values).distinct()
# 		_list = _list.filter(*search).order_by(*str(order_by).split(","))
# 		if all == 'true':
# 			return Response({'results': list(_list)})
# 		page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
# 		paginator = Paginator(_list, page_size)
# 		page_number = request.query_params.get('page', 1)
# 		page = paginator.get_page(page_number)
# 		return Response({
# 			'count': paginator.count,
# 			'next': page.next_page_number() if page.has_next() else None,
# 			'previous': page.previous_page_number() if page.has_previous() else None,
# 			'results': {
# 				'data': list(page.object_list),
# 			},
# 		})
	
class UserProfileMainAPIView(APIView):
	authentication_classes = (TokenAuthentication,)
	permission_classes = (IsAuthenticated,)

	def get(self, request, *args, **kwargs):
		user_type = self.request.query_params.get('user_type', None)
		if not user_type:
			raise APIException({'request_status': 0, 'msg': "User type required"})
		search ={}
		search['user__is_active'] = True
		search = custom_filters(self.request, search, ['user_type'])
		all = request.query_params.get('all', None)
		order_by = request.query_params.get('order_by', '-id')
		USER_TYPE_CONFIG = {
			"grower": {
				"model": GrowerProfile,
				"select_related": ['state', 'user', 'region', 'district', 'profile_type'],
				"prefetch_related": ["associated_aggregator", "associated_entity"],
				"values": [
					'id','user__username', 'is_tcms_user', 'tcms_supplier_code',
					'name', 'age', 'gender', 'date_of_birth', 'grower_type',
					'region__region_name', 'state__name', 'district__name',
					'region', 'state', 'district', 'production_area',
					'email', 'mobile_number', 'aadhar_no', 'address', 'tea_board_id',
					'associated_aggregator', 'associated_entity', 'poi_type', 'poi_id',
					# annotated fields
					# 'total_quantity_plucked', 'total_area_plucked',
				],
			},
			"aggregator": {
				"model": AggregatorProfile,
				"select_related": ['state', 'user', 'region', 'district', 'profile_type'],
				"prefetch_related": [],
				"values": [],
			},
			"blf": {
				"model": BlfProfile,
				"select_related": ['state', 'user', 'region', 'district', 'profile_type'],
				"prefetch_related": [],
				"values": [],
			},
		}
		
		config = USER_TYPE_CONFIG.get(user_type)
		if not config:
			raise APIException({'request_status': 0, 'msg': "Invalid user_type"})

		model = config["model"]
		values = config["values"]

		# Subqueries for totals
		plucking_qs = PluckingData.cmobjects.filter(grower=OuterRef('pk'))
		# Cast the CharField to IntegerField before summing
		total_quantity = (
			plucking_qs
			.annotate(q_int=Cast('quantity_plucked', IntegerField()))
			.values('grower')
			.annotate(total=Sum('q_int'))
			.values('total')[:1]
		)
		total_area = (
			plucking_qs
			.annotate(a_int=Cast('area_plucked', IntegerField()))
			.values('grower')
			.annotate(total=Sum('a_int'))
			.values('total')[:1]
		)
		# _list = (
		# 	model.cmobjects
		# 	.select_related(*config["select_related"]).prefetch_related(*config["prefetch_related"])
		# 	.annotate(
		# 		total_quantity_plucked=Coalesce(Subquery(total_quantity), Value(0),),
		# 		total_area_plucked=Coalesce(Subquery(total_area), Value(0)),
		# 	)
		# 	.values(*values).filter(*search).order_by(*str(order_by).split(",")) 
		# )
		# _list = _list.filter(*search).order_by(*str(order_by).split(",")).distinct()


		qs = (
			model.cmobjects
			.select_related(*config["select_related"])
			.prefetch_related(*config["prefetch_related"])
			.annotate(
				total_quantity_plucked=Coalesce(Subquery(total_quantity), Value(0)),
				total_area_plucked=Coalesce(Subquery(total_area), Value(0)),
			)
			.filter(*search)
			.distinct()
		)

		order_by_fields = str(order_by).split(",")
		if not any(f in order_by_fields for f in ["id", "-id"]):
			order_by_fields.append("id")

		_list = qs.values(*values).order_by(*order_by_fields)
		
		if all == 'true':
			return Response({'results': list(_list)})
		page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
		paginator = Paginator(_list, page_size)
		page_number = request.query_params.get('page', 1)
		page = paginator.get_page(page_number)

		return Response({
			'count': paginator.count,
			'next': page.next_page_number() if page.has_next() else None,
			'previous': page.previous_page_number() if page.has_previous() else None,
			'results': {
				'data': list(page.object_list),
			},
		})





class UserProfileAPIView(APIView):
	authentication_classes = (TokenAuthentication,)
	permission_classes = (IsAuthenticated,)
	USER_TYPE_CONFIG = {
		"grower": {
			"model": GrowerProfile,
			"serializer" : GrowerProfileSerializer,
		},
		"aggregator": {
			"model": AggregatorProfile,
			"serializer" : AggregatorProfileSerializer,
		},
		"blf": {
			"model": BlfProfile,
			"serializer" : BlfProfileSerializer,
		},
	}
	def get_config(self, user_type):
		config = self.USER_TYPE_CONFIG.get(user_type)
		if not config:
			raise ValidationError({"msg": "Invalid user_type"})
		return config
	def get(self, request):
		user_type = self.request.query_params.get('user_type', None)
		if not user_type:
			raise APIException({'request_status': 0, 'msg': "User type required"})
		id = self.request.query_params.get('id', None)
		all = self.request.query_params.get('all', None)
		order_by = self.request.query_params.get('order_by', '-id')
		search = {}
		search['user__is_active'] = True
		search = custom_filters(self.request, search, ['user_type'])
		config = self.get_config(user_type)
		model = config["model"]
		serializer_class = config["serializer"]
		if id:
			list_data = model.cmobjects.filter(id=id).first()
			serializer = serializer_class(list_data)
			return Response(serializer.data)
		
		list_data = model.cmobjects.filter(*search).order_by(*str(order_by).split(","))
		if all == 'true':
			serializer = serializer_class(list_data, many=True)
			return Response({'results': serializer.data})
		
		page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
		paginator = Paginator(list_data, page_size)
		page_number = self.request.query_params.get('page', 1)
		page = paginator.get_page(page_number)
		serializer = serializer_class(page, many=True)
		return Response({
			'count': paginator.count,
			'next': page.next_page_number() if page.has_next() else None,
			'previous': page.previous_page_number() if page.has_previous() else None,
			'results': serializer.data,
		})
	def post(self, request):
		request.data['created_by'] = request.user.id
		user_type = self.request.query_params.get('user_type', None)
		config = self.get_config(user_type)
		model = config["model"]
		serializer_class = config["serializer"]

		serializer = serializer_class(data=request.data, context={'request': request})
		if serializer.is_valid():
			try:
				serializer.save()
			except Exception as e:
				error_message = str(e.args[0]) if e.args else str(e)
				raise APIException({'request_status': 0, 'msg': error_message})
			return Response(
				{'results': {'Data': serializer.data,},
					'msg': 'Successfully created',
					'status': status.HTTP_201_CREATED,
					"request_status": 1})
		else:
			error_message = next(iter(serializer.errors.values()))[0]
			raise APIException({
				"request_status": 0,
				"msg": error_message
			})
		raise APIException({'request_status': 0, 'msg': serializer.errors})
	def put(self, request):
		method = request.query_params.get('method')
		id = request.query_params.get('id')
		user_type = self.request.query_params.get('user_type', None)
		if not method:
			raise APIException({'request_status': 0, 'msg': "Method parameter is required"})
		if not id:
			raise APIException({'request_status': 0, 'msg': "ID parameter is required"})
		config = self.get_config(user_type)
		model = config["model"]
		serializer_class = config["serializer"]
		with transaction.atomic():
			if method.lower() == 'edit':
				supply = model.cmobjects.filter(pk=id).first()
				if not supply:
					raise APIException({'request_status': 0, 'msg': "Users not found"})

				serializer = serializer_class(
					supply, data=request.data, context={'request': request}
				)
				if serializer.is_valid():
					# try:
					serializer.save()
					# except Exception as e:
					# 	error_message = str(e.args[0]) if e.args else str(e)
					# 	raise APIException({'request_status': 0, 'msg': error_message})
					return Response({
						'results': {'Data': serializer.data},
						'msg': "Successfully updated",
						'status': status.HTTP_202_ACCEPTED,
						'request_status': 1
					})
				else:
					raise APIException({'request_status': 0, 'msg': serializer.errors})
				
			elif method.lower() == 'delete':
				supply = model.cmobjects.filter(pk=id).first()
				if not supply:
					raise APIException({'request_status': 0, 'msg': "User not found"})
				supply.is_deleted = True
				supply.updated_by_id = request.user.id
				supply.save()
				return Response({
					'results': {'data': model.cmobjects.filter(pk=id).values()},
					'msg': 'Successfully deleted',
					'request_status': 1
				})
			else:
				raise APIException({'request_status': 0, 'msg': "Invalid method parameter"})

class ValidateTcmsUsers2(APIView):
	authentication_classes = (TokenAuthentication,)
	permission_classes = (IsAuthenticated,)

	def post(self, request, *args, **kwargs):
		results = []
		updated_count = 0
		api_url = os.getenv("TCMS_ENTITY_URL")
		if not api_url:
			return Response({"error": "TCMS_ENTITY_URL not configured"}, status=500)

		try:
			response = requests.get(api_url, verify=certifi.where(), timeout=30)
			response.raise_for_status()
			json_data = response.json()
		except Exception as e:
			return Response({"error": f"Failed to fetch TCMS data: {str(e)}"}, status=502)

# @login_required
def generate_excel_blf(results):
	output_dir = os.path.join(settings.MEDIA_ROOT, "excel", "validate", "tcms_data")
	os.makedirs(output_dir, exist_ok=True) 
	output_file = os.path.join(output_dir, f"entity_validate_data.xlsx")
	df = pd.DataFrame(results)
	df.to_excel(output_file, index=False)

def sanitize_float(value):
    """Safely convert a value to float, returning None for NaN/inf/invalid."""
    try:
        if value is None:
            return None
        if isinstance(value, (float, np.floating)):
            if math.isnan(value) or math.isinf(value):
                return None
            return float(value)
        return float(value)
    except Exception:
        return None



class ValidateTcmsBlfUsers(APIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):

        results = []
        updated_count = 0
        matched_users_ids = []
        unmatched_users_ids = []

        api_url = os.getenv("TCMS_ENTITY_URL")

        if not api_url:
            return Response(
                {"error": "TCMS_ENTITY_URL not configured"},
                status=500
            )

        # --------------------------------------------------
        # STEP 1: Fetch TCMS Data
        # --------------------------------------------------
        try:
            response = requests.get(
                api_url,
                verify=certifi.where(),
                timeout=30
            )
            response.raise_for_status()
            json_data = response.json()
        except Exception as e:
            return Response(
                {"error": f"Failed to fetch TCMS data: {str(e)}"},
                status=502
            )

        api_entities = []

        for entity in json_data.get("data", []):
            entity_details = entity.get("entity_details") or {}

            api_entities.append({
                "unit_name": str(entity.get("name", "") or "").strip(),
                "user_name": str(entity_details.get("user_name", "") or "").strip(),
                "state": str(entity.get("state", "") or "").strip(),
                "district": str(entity.get("district", "") or "").strip(),
            })

        if not api_entities:
            return Response({
                "count": 0,
                "updated_count": 0,
                "results": [],
                "message": "No TCMS data found"
            })

        api_df = pd.DataFrame(api_entities)

        # --------------------------------------------------
        # STEP 2: Fetch Local Profiles
        # --------------------------------------------------
        profiles = BlfProfile.cmobjects.all().values(
            "id",
            "entity_unit",
            "user__username",
            "state__name",
            "district__name",
        )

        profiles_df = pd.DataFrame(list(profiles))

        if profiles_df.empty:
            return Response({
                "count": 0,
                "updated_count": 0,
                "results": [],
                "message": "No BLF profiles found"
            })

        # Clean profile fields
        profiles_df["entity_unit"] = profiles_df["entity_unit"].astype(str).str.strip()
        profiles_df["user__username"] = profiles_df["user__username"].astype(str).str.strip()
        profiles_df["state__name"] = profiles_df["state__name"].astype(str).str.strip()
        profiles_df["district__name"] = profiles_df["district__name"].astype(str).str.strip()

        # --------------------------------------------------
        # STEP 3: FUZZY MATCHING (No ID Matching)
        # --------------------------------------------------
        fuzzy_matches = fuzzymatcher.link_table(
            api_df,
            profiles_df,
            left_on=[
                "unit_name",
                "user_name",
                "state",
                "district",
            ],
            right_on=[
                "entity_unit",
                "user__username",
                "state__name",
                "district__name",
            ],
        )

        fuzzy_matches = (
            fuzzy_matches
            .sort_values("match_score", ascending=False)
            .drop_duplicates("unit_name")
        )

        fuzzy_matches["match_score"] = fuzzy_matches["match_score"].fillna(0.0)

        # --------------------------------------------------
        # STEP 4: UPDATE MATCHED USERS
        # --------------------------------------------------
        with transaction.atomic():

            for _, row in fuzzy_matches.iterrows():

                profile_id = row.get("id")
                raw_score = row.get("match_score", 0.0)

                if pd.isna(raw_score):
                    raw_score = 0.0

                match_score = round(float(raw_score) * 100, 2)

                # 🔥 IMPORTANT: Proper threshold
                # if profile_id and match_score >= 70:
					
                #     # update_count = BlfProfile.cmobjects.filter(
                #     #     id=profile_id
                #     # ).update(
                #     #     is_tcms_user=True
                #     # )

                #     # if update_count:
                #     #     updated_count += 1
                #     #     matched_users_ids.append(profile_id)
                #     #     user_update = "true"
                #     # else:
                #     #     user_update = "false"
                # else:
                #     user_update = "false"
                #     if profile_id:
                #         unmatched_users_ids.append(profile_id)

                results.append({
                    "profile_id": profile_id,
                    "tracetea_entity_unit": row.get("entity_unit", ""),
                    "tcms_entity_unit": row.get("unit_name", ""),
                    # "match_score": match_score,
                    # "user_update": user_update
                })

        # --------------------------------------------------
        # FINAL RESPONSE
        # --------------------------------------------------
        return Response({
            "count": len(results),
            "updated_count": updated_count,
            "results": results,
            "matched_users_ids": list(set(matched_users_ids)),
            "unmatched_users_ids": list(set(unmatched_users_ids)),
        })







class ValidateTcmsBlfUsers2(APIView):
	authentication_classes = (TokenAuthentication,)
	permission_classes = (IsAuthenticated,)
	def post(self, request, *args, **kwargs):
		results = []
		updated_count = 0
		api_url = os.getenv("TCMS_ENTITY_URL")
		if not api_url:
			return Response({"error": "TCMS_ENTITY_URL not configured"}, status=500)
		try:
			response = requests.get(api_url, verify=certifi.where(), timeout=30)
			response.raise_for_status()
			json_data = response.json()
		except Exception as e:
			return Response({"error": f"Failed to fetch TCMS data: {str(e)}"}, status=502)
		api_entities = []
		for entity in json_data.get("data", []):
			entity_details = entity.get("entity_details") or {}
			api_entities.append({
				"unit_name": entity.get("name", ""),
				"entity_name" : entity_details.get("name", ""),
				"user_name": entity_details.get("user_name", ""),
				"state": entity.get("state", ""),
				"district": entity.get("district", ""),
				"region_name": entity_details.get("region_name", ""),
				"whats_app_no" : entity_details.get("whats_app_no", ""),	
				"head_contact_name": entity.get("head_contact_name", ""),
				"head_contact_phone": entity.get("head_contact_phone", ""),
				"head_contact_email": entity.get("head_contact_email", ""),
				"tcmo_no" : entity.get("tcmo_no", ""),
				"unit_id": entity.get("unit_id", ""),
				"password": entity_details.get("actual_password", ""),
			})
		api_df = pd.DataFrame(api_entities)
		profiles = BlfProfile.cmobjects.all().values(
			"id", "entity_unit", "user__username", "region__region_name",
			"state__name", "district__name", "ho_contact_person",
			"ho_contact_number", "ho_contact_email", "profile_type",
		)
		profiles_df = pd.DataFrame(list(profiles))
		matched = fuzzymatcher.link_table(
			api_df,
			profiles_df,
			left_on=[
				"unit_name", "user_name", "state", "district",
				"unit_id", 
			],
			right_on=[
				"entity_unit", "user__username", "state__name", "district__name", "id",
			],
		)
		matched = matched.sort_values("match_score", ascending=False).drop_duplicates("unit_name")
		matched["match_score"] = matched["match_score"].fillna(0.0)
		matched_users_ids = []
		unmatched_users_ids = []
		for _, row in matched.iterrows():
			raw_score = row.get("match_score", 0.0)
			# print("raw_score ####", raw_score)
			if pd.isna(raw_score) or raw_score in ["nan", None]:
				raw_score = 0.0
			match_score = round(float(raw_score) * 100, 2)
			if str(row.get("unit_name", "")).strip().lower() == str(row.get("entity_unit", "")).strip().lower():
				match_score = 150.0
			elif (
				str(row.get("unit_name", "")).strip().lower() == str(row.get("entity_unit", "")).strip().lower()
				and str(row.get("state", "")).strip().lower() == str(row.get("state__name", "")).strip().lower()
				and str(row.get("district", "")).strip().lower() == str(row.get("district__name", "")).strip().lower()
			):
				match_score = 120.0
			user_update = "false"
			if match_score >= 0:
				profile_id = row.get("id", None)  
				update_data = BlfProfile.cmobjects.filter(id=profile_id).update(
					is_tcms_user=True,
					# tcms_unit_id=row.get("unit_id", ""),
					# tcmo_no=row.get("tcmo_no", ""),
				)
				if update_data:
					updated_count += 1
					user_update = "true"
					matched_users_ids.append(row.get("id"))
			else:
				unmatched_users_ids.append(row.get("id"))

			results.append({
				"tracetea_username": row.get("user__username", ""),
				"tcms_username": row.get("user_name", ""),
				"tracetea_entity_unit": row.get("entity_unit", ""),
				"tcms_entity": row.get("unit_name", ""),
				"tracetea_state": row.get("state__name", ""),
				"tcms_state": row.get("state", ""),
				"tracetea_district": row.get("district__name", ""),
				"tcms_district": row.get("district", ""),
				"match_score": sanitize_float(match_score),
				"user_update" : user_update
			})
			# generate_excel_blf(results)
		return Response({
			"count": len(results),
			"updated_count": updated_count,
			"results": results,
			"unmatched_users_ids" : set(unmatched_users_ids),
			"matched_users_ids" : set(unmatched_users_ids),
		})

class ValidateTcmsSupplierUsers(APIView):
	authentication_classes = (TokenAuthentication,)
	permission_classes = (IsAuthenticated,)
	
	def post(self, request, *args, **kwargs):
		results = []
		updated_count = 0
		supplier_mode = self.request.query_params.get('supplier_mode', "LEAD FARMER")
		blf_unit_ids_param = self.request.query_params.get("blf_unit_ids", None)
		if blf_unit_ids_param:
			unit_ids = [int(x.strip()) for x in blf_unit_ids_param.split(",") if x.strip().isdigit()]
		else:
			# tcms_unit_id = list(BlfProfile.cmobjects.values_list("tcms_unit_id", flat=True))
			# unit_ids = [int(x) for x in tcms_unit_id if x is not None]
			unit_ids = [1474,1258]

		api_url = os.getenv("TCMS_SUPPLIER_URL")
		if not api_url:
			return Response({"error": "TCMS_SUPPLIER_URL not configured"}, status=500)
		api_suppliers = []

		for unit_id in unit_ids:
			payload = {
				"unit_id": unit_id,
				"filters": [
					{"key": "supply_mode", "value": supplier_mode},
					# {"key": "land_type", "value": "Own"}, DIRECT,
				],
			}
			try:
				response = requests.post(
					api_url,
					json=payload,
					verify=certifi.where(),
					timeout=30,
				)
				response.raise_for_status()
				json_data = response.json()
			except Exception as e:
				return Response({"error": f"Failed to fetch TCMS data: {str(e)}"}, status=502)

			for supplier in json_data.get("data", []):
				api_suppliers.append({
					"unit_id": unit_id,
					"supplier_code": supplier.get("supplier_code", ""),
					"supplier_name": supplier.get("supplier_name", ""),
					"supply_mode": supplier.get("supply_mode", ""),
					"supplier_type": supplier.get("supplier_type", ""),
					"region": supplier.get("region", ""),
					"state": supplier.get("state", ""),
					"district": supplier.get("district", ""),
					"address": supplier.get("address", ""),
					"sex": supplier.get("sex", ""),
					"land_type": supplier.get("land_type", ""),
					"annual_production": supplier.get("annual_production", ""),
					"phone_number": supplier.get("phone_number", ""),
					"male_worker" : supplier.get("male_worker", ""),
					"female_worker" : supplier.get("female_worker", ""),
				})

		api_df = pd.DataFrame(api_suppliers)
		supply_mode = "LEAD FARMER"

		if supply_mode == "LEAD FARMER":
			print("AGG DATA HERE ################")
			model_name = AggregatorProfile
			profiles = model_name.cmobjects.all().values(
				"id", "name", "user__username", "region__region_name",
				"state__name", "district__name", "aggregator_type",
				"address", "mobile_number",
			)
			left_on_data = [
				"supplier_name", "region", "state", "district",
				"address", "phone_number", "supplier_code", 
			]
			right_on_data = [
				"name", "region__region_name", "state__name", "district__name",
				"address", "mobile_number", "aggregator_type", "id", "user__username",
			]
		else:
			model_name = GrowerProfile
			profiles = model_name.cmobjects.all().values(
				"id", "name", "user__username", "region__region_name",
				"state__name", "district__name", "age",
				"gender", "grower_type", "village_or_town", "address",
				"mobile_number", "estimated_production_of_made_tea", "estimated_production_of_green_tea",
				"production_area", "total_female_worker", "total_male_worker",
			)
			left_on_data = [
				"supplier_name", "region", "state", "district",
				"address", "phone_number", "sex", "male_worker", 
				"female_worker", "supplier_code", 
			]
			right_on_data = [
				"name", "region__region_name", "state__name", "district__name",
				"address", "mobile_number", "gender", "total_male_worker", "total_female_worker", 
				"id",
			]
		profiles_df = pd.DataFrame(list(profiles))
		matched = fuzzymatcher.link_table(
			api_df,
			profiles_df,
			left_on=left_on_data,
			right_on=right_on_data
		)
		matched = matched.sort_values("match_score", ascending=False).drop_duplicates("supplier_name")
		for _, row in matched.iterrows():
			raw_score = row.get("match_score", 0.0)
			if pd.isna(raw_score):
				raw_score = 0.0
			match_score = round(float(raw_score) * 100, 2)
			user_update = "false"
			if match_score >= 100:
				profile_id = row.get("id")
				model_name.cmobjects.filter(id=profile_id).update(
				    is_tcms_user=True,
				    tcms_unit_id=row.get("unit_id", ""),
				)
				user_update = "true"
				updated_count += 1
			results.append({
				"tracetea_username": row.get("user__username", ""),
				"tcms_username": row.get("user_name", ""),
				"tracetea_supplier_name": row.get("name", ""),
				"tcms_supplier_name": row.get("supplier_name", ""),
				"tracetea_region": row.get("region__region_name", ""),
				"tcms_region": row.get("region", ""),
				"tracetea_state": row.get("state__name", ""),
				"tcms_state": row.get("state", ""),
				"tracetea_district": row.get("district__name", ""),
				"tcms_district": row.get("district", ""),
				"tracetea_phone_number": row.get("mobile_number", ""),
				"tcms_phone_number": row.get("phone_number", ""),
				"tracetea_male_worker": row.get("mobile_number", ""),
				"tcms_male_worker": row.get("male_worker", ""),
				"tracetea_female_worker": row.get("female_worker", ""),
				"tcms_female_worker": row.get("female_worker", ""),
				"match_score": sanitize_float(match_score),
				"user_update": user_update
			})
		return Response({
			"count": len(results),
			"updated_count": updated_count,
			"results": results,
		})



@permission_required_admin
def users_profile_list(request, usertype_slug):
	user_type = usertype_slug
	if not user_type:
		raise APIException({'request_status': 0, 'msg': "User type required"})
	search = {}
	search = custom_web_filters(request, search, [])
	all = request.GET.get('all', None)
	order_by = request.GET.get('order_by', '-id')

	USER_TYPE_CONFIG = {
		"grower": {
			"model": GrowerProfile,
			"serializer": GrowerProfileSerializer,
			"select_related" : ['state', 'user', 'region', 'district', 'profile_type'],
			"prefetch_related" : ["associated_aggregator", "associated_entity"],
			"edit_url" : 'user_profile:grower_profile_edit',
			"values": [
				'id','user__username', 'is_tcms_user', 'tcms_supplier_code',
				'name', 'age', 'gender', 'date_of_birth', 'grower_type',
				'region__region_name', 'state__name', 'district__name',
				'region', 'state', 'district',
				'email', 'mobile_number', 'aadhar_no', 'address', 'tea_board_id', 'associated_aggregator', 
				'associated_entity', 'poi_type', 'poi_id',
			],
		},
		"aggregator": {
			"model": AggregatorProfile,
			"serializer": AggregatorProfileSerializer,
			"select_related" : ['state', 'user', 'region', 'district', 'profile_type'],
			"prefetch_related" : [],
			"values": [],
			"edit_url" : 'user_profile:aggregator_profile_edit',
		},
		"blf": {
			"model": BlfProfile,
			"serializer": BlfProfileSerializer,
			"select_related" : ['state', 'user', 'region', 'district', 'profile_type'],
			"prefetch_related" : [],
			"values": [],
			"edit_url" : 'user_profile:blf_profile_edit'
		},
	}
	config = USER_TYPE_CONFIG.get(user_type)
	if not config:
		raise APIException({'request_status': 0, 'msg': "Invalid user_type"})
	model = config["model"]
	values = config["values"] 
	edit_url = config["edit_url"] 

	_list = model.cmobjects.select_related(*config["select_related"]).prefetch_related(*config["prefetch_related"]).values(*values).distinct()
	_list = _list.filter(*search).order_by(*str(order_by).split(","))
	
	tot_count = _list.count()
	page = request.GET.get('page', 1)
	paginator = Paginator(_list, settings.MIN_PAGE_SIZE)
	try:
		_list = paginator.page(page)
	except PageNotAnInteger:
		_list = paginator.page(1)
	except EmptyPage:
		_list = paginator.page(paginator.num_pages)
	context = {
		'tot_count' : tot_count,
		'user_type' : usertype_slug,
		'edit_url' : edit_url,
		'count': paginator.count,
		'profile_list' : _list,
	}
	return render(request, 'profile/user_profile_lists.html', context)










class GrowerProfileALLUpdateAPIView(APIView):
    permission_classes = (AllowAny,)

    def put(self, request):
        with transaction.atomic():
            triggered_count = 0
            for grower in GrowerProfile.objects.all():
                post_save.send(sender=GrowerProfile, instance=grower, created=False)
                triggered_count += 1

        return Response({
            'results': {'Data': triggered_count},
            'msg': "Signals manually triggered",
            'status': status.HTTP_202_ACCEPTED,
            'request_status': 1
        })

class SupplyManagementCreateView(LoginRequiredMixin, CommonMixin, CreateView):
	"""
	Use Of Supply Data
	"""
	model = SupplyManagement
	form_class = SupplyManagementForm
	template_name = 'reports/supply_management_form.html'

	def dispatch(self, request, *args, **kwargs):
		if not request.user.is_authenticated:
			return super(SupplyManagementCreateView, self).dispatch(request, *args, **kwargs)
		if not _is_blf_user(request.user):
			messages.error(request, "Only BLF users can add supply records from this page.")
			return redirect(reverse("user_profile:supply_management_report"))
		return super(SupplyManagementCreateView, self).dispatch(request, *args, **kwargs)

	def get(self, request, *args, **kwargs):
		return super(SupplyManagementCreateView, self).get(request, *args, **kwargs)
	
	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Supply record saved successfully. Challan is Pending.')
		return reverse("user_profile:supply_management_report") + "?mode=manage"

	def get_context_data(self, **kwargs):
		context = super(SupplyManagementCreateView, self).get_context_data(**kwargs)
		# context['grower_pk'] = self.kwargs['grower_pk']/
		context['blf_list'] = BlfProfile.cmobjects.filter(user__is_active=True).order_by('-id')
		return context
	def get_form_kwargs(self, **kwargs):
		kwargs = super(SupplyManagementCreateView, self).get_form_kwargs()
		kwargs['request'] = self.request
		return kwargs

	def get_initial(self):
		initial = super(SupplyManagementCreateView, self).get_initial()
		initial.setdefault("date_of_supply", timezone.now().date())
		return initial

	def _supplier_queryset(self, supplier_type):
		blf = _logged_blf_profile(self.request)
		if not blf:
			return None
		blf_filter = Q(associated_blf=blf) | Q(associated_entity=blf)
		if supplier_type == "Grower":
			return GrowerProfile.cmobjects.select_related("user").filter(
				blf_filter,
				user__is_active=True,
			).distinct()
		if supplier_type == "Aggregator":
			return AggregatorProfile.cmobjects.select_related("user").filter(
				blf_filter,
				user__is_active=True,
			).distinct()
		return None

	def _add_form_error(self, form, message):
		form.add_error(None, message)
		return self.form_invalid(form)

	def form_invalid(self, form):
		for field_name, errors in form.errors.items():
			label = form.fields[field_name].label if field_name in form.fields else ""
			for error in errors:
				messages.error(self.request, f"{label}: {error}" if label else error)
		return super(SupplyManagementCreateView, self).form_invalid(form)

	def form_valid(self, form):
		supplier_type = (self.request.POST.get("supply_to") or "").strip()
		supplier_user_id = (self.request.POST.get("created_by") or "").strip()
		if supplier_type not in ("Grower", "Aggregator"):
			return self._add_form_error(form, "Select Supplier To.")
		if not supplier_user_id:
			return self._add_form_error(form, "Select Supplier Name.")

		supplier_qs = self._supplier_queryset(supplier_type)
		if supplier_qs is None:
			return self._add_form_error(form, "Unable to find BLF profile for logged in user.")
		supplier_profile = supplier_qs.filter(user_id=supplier_user_id).first()
		if not supplier_profile or not supplier_profile.user_id:
			return self._add_form_error(form, "Selected supplier is not mapped with logged in BLF.")
		selected_vehicle = form.cleaned_data.get("alloted_vehicle")
		if not selected_vehicle or selected_vehicle.created_by_id != supplier_profile.user_id or not selected_vehicle.is_available:
			return self._add_form_error(form, "Selected vehicle is not available for this supplier.")

		quantity = form.cleaned_data["gross_leaf"]
		grower_rows = []
		declared_grower_ids = []
		if supplier_type == "Aggregator":
			grower_ids = self.request.POST.getlist("grower_ids")
			if not grower_ids:
				return self._add_form_error(form, "Select an Aggregator with mapped Growers.")
			valid_growers = {
				str(grower.pk): grower
				for grower in get_supplier_grower_queryset(self.request, supplier_profile).filter(pk__in=grower_ids)
			}
			plucked_quantity_by_grower = get_plucked_declared_quantity_map(valid_growers.keys())
			total = Decimal("0")
			for grower_id in grower_ids:
				grower = valid_growers.get(str(grower_id))
				if not grower:
					return self._add_form_error(form, "One or more selected Growers are not mapped with this Aggregator.")
				raw_qty = (self.request.POST.get(f"grower_qty_{grower_id}") or "").strip()
				if not raw_qty:
					return self._add_form_error(form, f"Enter quantity for {grower.name or grower.user.username}.")
				try:
					grower_qty = Decimal(raw_qty)
				except (InvalidOperation, ValueError):
					return self._add_form_error(form, f"Invalid quantity for {grower.name or grower.user.username}.")
				if grower_qty <= 0:
					return self._add_form_error(form, f"Quantity for {grower.name or grower.user.username} must be greater than 0.")
				if abs(grower_qty.as_tuple().exponent) > 2:
					return self._add_form_error(form, f"Quantity for {grower.name or grower.user.username} can have only two decimal places.")
				grower_qty = grower_qty.quantize(Decimal("0.01"))
				grower_plucked_quantity = plucked_quantity_by_grower.get(grower.pk, Decimal("0"))
				if grower_qty > grower_plucked_quantity:
					return self._add_form_error(
						form,
						f"Quantity for {grower.name or grower.user.username} should not be greater than Plucked Quantity ({grower_plucked_quantity:.2f})."
					)
				total += grower_qty
				grower_rows.append((grower, grower_qty))
				declared_grower_ids.append(grower.pk)
			if not grower_rows:
				return self._add_form_error(form, "Enter at least one Grower quantity greater than 0.")
			quantity = total
		else:
			declared_grower_ids = [supplier_profile.pk]

		declared_quantity = get_plucked_declared_quantity_total(declared_grower_ids)
		if declared_quantity > 0 and quantity > declared_quantity:
			return self._add_form_error(
				form,
				f"Quantity should not be greater than Plucked Declared Quantity ({declared_quantity})."
			)

		with transaction.atomic():
			supply = form.save(commit=False)
			supply.supply_to = "Factory"
			supply.supply_from = supplier_type
			supply.consumer = self.request.user
			supply.created_by = supplier_profile.user
			supply.updated_by = self.request.user
			supply.challan_created_by = self.request.user
			supply.gross_leaf = str(quantity)
			supply.quantity = str(quantity)
			supply.supply_challan_id = generate_supply_challan_id(supplier_profile.user)
			supply._declared_quantity_limit = declared_quantity
			supply.save()
			if grower_rows:
				GrowerDetailsSupply.objects.bulk_create([
					GrowerDetailsSupply(
						supply=supply,
						grower=grower,
						collected_quantity=str(grower_qty),
						supply_quantity=str(grower_qty),
						collected_date=supply.date_of_supply,
						created_by=supplier_profile.user,
						updated_by=self.request.user,
					)
					for grower, grower_qty in grower_rows
				])
			self.object = supply
		return HttpResponseRedirect(self.get_success_url())

def _json_forbidden(message):
	return JsonResponse({"data": [], "message": message}, status=403)


def get_logged_blf_for_ajax(request):
	if not request.user.is_authenticated or not _is_blf_user(request.user):
		return None
	return _logged_blf_profile(request)


def get_supplier_grower_queryset(request, aggregator):
	blf = _logged_blf_profile(request)
	if not blf or not aggregator:
		return GrowerProfile.cmobjects.none()
	return GrowerProfile.cmobjects.select_related("user").filter(
		Q(associated_blf=blf) | Q(associated_entity=blf),
		associated_aggregator=aggregator,
		user__is_active=True,
	).distinct().order_by("name", "user__username")


def get_plucked_declared_quantity_total(grower_ids):
	return sum(get_plucked_declared_quantity_map(grower_ids).values(), Decimal("0"))


def get_plucked_declared_quantity_map(grower_ids):
	if not grower_ids:
		return {}
	grower_totals = {int(grower_id): Decimal("0") for grower_id in grower_ids if str(grower_id).isdigit()}
	for grower_id, quantity_plucked in PluckingData.cmobjects.filter(
		grower_id__in=grower_totals.keys(),
		quantity_plucked__isnull=False,
	).values_list("grower_id", "quantity_plucked"):
		if quantity_plucked in (None, ""):
			continue
		try:
			grower_totals[grower_id] += Decimal(str(quantity_plucked or 0))
		except (InvalidOperation, ValueError):
			continue
	return grower_totals


def get_supplier_vehicle_queryset(request, supplier_user_id):
	blf = _logged_blf_profile(request)
	if not blf or not supplier_user_id:
		return VehicleManagement.cmobjects.none()
	supplier_user_id = str(supplier_user_id)
	grower_exists = GrowerProfile.cmobjects.filter(
		Q(associated_blf=blf) | Q(associated_entity=blf),
		user_id=supplier_user_id,
		user__is_active=True,
	).distinct().exists()
	aggregator_exists = AggregatorProfile.cmobjects.filter(
		Q(associated_blf=blf) | Q(associated_entity=blf),
		user_id=supplier_user_id,
		user__is_active=True,
	).distinct().exists()
	if not (grower_exists or aggregator_exists):
		return VehicleManagement.cmobjects.none()
	return VehicleManagement.cmobjects.filter(
		created_by_id=supplier_user_id,
		is_available=True,
	).order_by("vehicle_number")


def get_supplier_region_code(user):
	aggregator = AggregatorProfile.cmobjects.select_related("region").filter(user=user).first()
	if aggregator and aggregator.region:
		return aggregator.region.region_id or ""
	grower = GrowerProfile.cmobjects.select_related("region").filter(user=user).first()
	if grower and grower.region:
		return grower.region.region_id or ""
	return ""


def generate_supply_challan_id(supplier_user):
	region_code = get_supplier_region_code(supplier_user)
	username = str(supplier_user.username or supplier_user).upper()
	prefix = f"CH{region_code}{username}"
	last_challan = (
		SupplyManagement.objects
		.filter(supply_challan_id__startswith=prefix, created_by=supplier_user)
		.order_by("-id")
		.first()
	)
	next_number = 1
	if last_challan and last_challan.supply_challan_id:
		suffix = last_challan.supply_challan_id[len(prefix):]
		try:
			next_number = int(suffix) + 1
		except (TypeError, ValueError):
			next_number = 1
	while True:
		challan_id = f"{prefix}{next_number:0>2d}"
		if not SupplyManagement.objects.filter(supply_challan_id=challan_id).exists():
			return challan_id
		next_number += 1


@login_required
def get_supplier_list(request):
	supply_type = request.GET.get('type')
	blf = get_logged_blf_for_ajax(request)
	if not blf:
		return _json_forbidden("Only BLF users can load suppliers.")
	data = []
	if supply_type == "Grower":
		objs = GrowerProfile.cmobjects.select_related("user").filter(
			Q(associated_blf=blf) | Q(associated_entity=blf),
			user__is_active=True,
		).distinct().order_by("name", "user__username")
		for obj in objs:
			data.append({
				'user_id': obj.user.id,
				'id' : obj.id,  
				'name': obj.name or obj.user.username,
				'username': obj.user.username,
				'text': _supply_option_label(obj),
			})

	elif supply_type == "Aggregator":
		objs = AggregatorProfile.cmobjects.select_related("user").filter(
			Q(associated_blf=blf) | Q(associated_entity=blf),
			user__is_active=True,
		).distinct().order_by("name", "user__username")
		for obj in objs:
			data.append({
				'user_id': obj.user.id,
				'id': obj.id,
				'name': obj.name or obj.user.username,
				'username': obj.user.username,
				'text': _supply_option_label(obj),
			})
	return JsonResponse({'data': data})


@login_required
def get_supplier_vehicle_list(request):
	blf = get_logged_blf_for_ajax(request)
	if not blf:
		return _json_forbidden("Only BLF users can load supplier vehicles.")
	supplier_user_id = request.GET.get("supplier_user_id") or request.GET.get("user_id")
	data = [
		{
			"id": vehicle.id,
			"text": vehicle.vehicle_number,
			"mobile_number": vehicle.mobile_number or "",
		}
		for vehicle in get_supplier_vehicle_queryset(request, supplier_user_id)
	]
	return JsonResponse({"data": data})


@login_required
def get_plucked_declared_quantity(request):
	blf = get_logged_blf_for_ajax(request)
	if not blf:
		return _json_forbidden("Only BLF users can load plucked declared quantity.")
	grower_ids = request.GET.getlist("grower_ids[]") or request.GET.getlist("grower_ids")
	grower_id = request.GET.get("grower_id")
	if grower_id:
		grower_ids.append(grower_id)
	valid_grower_ids = list(
		GrowerProfile.cmobjects.filter(
			Q(associated_blf=blf) | Q(associated_entity=blf),
			id__in=grower_ids,
			user__is_active=True,
		).distinct().values_list("id", flat=True)
	)
	total = get_plucked_declared_quantity_total(valid_grower_ids)
	return JsonResponse({
		"total": str(total),
		"total_display": f"{total:.2f}",
	})


@login_required
def get_associated_map_agg_growers(request):
	blf = get_logged_blf_for_ajax(request)
	if not blf:
		return _json_forbidden("Only BLF users can load mapped Growers.")
	aggregator_user_id = request.GET.get('user_id') or request.GET.get('id')
	aggregator = AggregatorProfile.cmobjects.filter(
		Q(associated_blf=blf) | Q(associated_entity=blf),
		user_id=aggregator_user_id,
		user__is_active=True,
	).distinct().first()
	if not aggregator:
		return JsonResponse({'data': []})
	growers = list(get_supplier_grower_queryset(request, aggregator))
	plucked_quantity_by_grower = get_plucked_declared_quantity_map([grower.pk for grower in growers])
	data = []
	for g in growers:
		plucked_quantity = plucked_quantity_by_grower.get(g.pk, Decimal("0"))
		data.append({
			'id': g.id,
			'name': g.name or "",
			'username': g.user.username if g.user else "",
			'plucked_quantity': str(plucked_quantity),
			'plucked_quantity_display': f"{plucked_quantity:.2f}",
		})

	return JsonResponse({'data': data})
