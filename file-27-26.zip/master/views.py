import collections
import dateutil
import datetime
import json
import os
import re
from types import SimpleNamespace
from uuid import uuid4
from datetime import datetime, date
import csv
from datetime import date, timedelta
from rest_framework.response import Response
from django.shortcuts import render, redirect
from django.urls import reverse
from django.http import JsonResponse
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.template.loader import render_to_string
from django.views.decorators.cache import cache_page
from django.db.models import Sum, Value, Count, Avg, Case, When, F, Q
from django.db.models.functions import Coalesce
from django.utils.http import url_has_allowed_host_and_scheme
from master.common import CommonMixin
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.generic import TemplateView, ListView, DetailView, CreateView, UpdateView, DeleteView
from rest_framework.decorators  import api_view, permission_classes, authentication_classes
from .models import *
from .forms import *
from .serializers import *
import pandas as pd
from django.db import transaction
import numpy as np
import datetime
from master.decorators import *
from leaf_receipt.models import *
from user_profile.blf_api_models import SupplierExit
from user_profile.grower_api_models import *
from user_profile.helpers import soft_delete_instance_for_web
from django.db.models import FloatField
from django.db.models.functions import ExtractYear, ExtractMonth
from django.db.models import Count, F, Sum, Avg
from chemical_data.models import *
from .utils import months,  get_year_dict
from accounts.forms import DEFAULT_USER_PASSWORD
from gardens_managment.models import Gardens, Plot
from user_profile.models import (
    AggregatorProfile,
    BlfProfile,
    District,
    GrowerProfile,
    Profile,
    ProfileType,
    Region,
    State,
)
from openpyxl import Workbook

User = get_user_model()

def daterange(start, end, step=1):
    current_year = start
    while current_year <= end:
        yield current_year
        current_year += step

def is_ajax_request(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

def get_safe_next_url(request, default_url):
    next_url = request.GET.get('next') or request.POST.get('next')
    if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
        return next_url
    return default_url

def landing_page(request):
    """ Landing page view """

    if request.user.is_authenticated:
        return redirect(reverse('index'))

    region_list = Region.cmobjects.all()
    # grower_count = BlfProfile.cmobjects.filter().aggregate(
    #                 partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    # BLF
    west_bengal_blf_count = BlfProfile.cmobjects.filter(region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    south_india_blf_count = BlfProfile.cmobjects.filter(region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    assam_blf_count = BlfProfile.cmobjects.filter(region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    north_east_blf_count = BlfProfile.cmobjects.filter(region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    

    # STG
    west_bengal_stg_count = GrowerProfile.cmobjects.filter(region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    south_india_stg_count = GrowerProfile.cmobjects.filter(region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    assam_stg_count = GrowerProfile.cmobjects.filter(region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    north_east_stg_count = GrowerProfile.cmobjects.filter(region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']


    # AGGREGATOR

    west_bengal_agg_count = AggregatorProfile.cmobjects.filter(region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    south_india_agg_count = AggregatorProfile.cmobjects.filter(region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    assam_agg_count = AggregatorProfile.cmobjects.filter(region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    north_east_agg_count = AggregatorProfile.cmobjects.filter(region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    # farmer
    # west_bengal_farmers_count = GrowerProfile.cmobjects.filter(grower_type__in=['STG', 'LTG']).aggregate(
    #                 partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    # south_india_farmers_count = GrowerProfile.cmobjects.filter(grower_type__in=['STG', 'LTG']).aggregate(
    #                 partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    # assam_farmers_count = GrowerProfile.cmobjects.filter(grower_type__in=['STG', 'LTG']).aggregate(
    #                 partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    # north_east_farmers_count = GrowerProfile.cmobjects.filter(grower_type__in=['STG', 'LTG']).aggregate(
    #                 partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    

    #use Of chemical
    west_bengal_farmers_useof_chemical = UseOfChemical.cmobjects.filter(grower__region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_farmers_useof_chemical = UseOfChemical.cmobjects.filter(grower__region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_farmers_useof_chemical = UseOfChemical.cmobjects.filter(grower__region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_farmers_useof_chemical = UseOfChemical.cmobjects.filter(grower__region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    #plucking Data
    west_bengal_farmers_plucking = PluckingData.cmobjects.filter(grower__region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_farmers_plucking = PluckingData.cmobjects.filter(grower__region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_farmers_plucking = PluckingData.cmobjects.filter(grower__region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_farmers_plucking = PluckingData.cmobjects.filter(grower__region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']


    #Labours Data
    west_bengal_farmers_labour = Labour.cmobjects.filter(grower__region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_farmers_labour = Labour.cmobjects.filter(grower__region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_farmers_labour = Labour.cmobjects.filter(grower__region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_farmers_labour= Labour.cmobjects.filter(grower__region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']


    #Monthly Schedule Data
    west_bengal_farmers_monthly = MonthlySchedule.cmobjects.filter(grower__region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_farmers_monthly = MonthlySchedule.cmobjects.filter(grower__region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_farmers_monthly = MonthlySchedule.cmobjects.filter(grower__region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_farmers_monthly = MonthlySchedule.cmobjects.filter(grower__region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    wb_total_farm_diary = west_bengal_farmers_useof_chemical + west_bengal_farmers_plucking + west_bengal_farmers_labour + west_bengal_farmers_monthly
    print("wb_total_farm_diary", wb_total_farm_diary)
    si_total_farm_diary = south_india_farmers_useof_chemical + south_india_farmers_plucking + south_india_farmers_labour + south_india_farmers_monthly
    assam_total_farm_diary = assam_farmers_useof_chemical + assam_farmers_plucking + assam_farmers_labour + assam_farmers_monthly
    north_east_total_farm_diary = north_east_farmers_useof_chemical + north_east_farmers_plucking + north_east_farmers_labour + north_east_farmers_monthly
    context ={
        "region_list" : region_list,

        "west_bengal_blf_count" : west_bengal_blf_count,
        "south_india_blf_count" : south_india_blf_count,
        "assam_blf_count" : assam_blf_count,
        "north_east_blf_count" : north_east_blf_count,

        "west_bengal_stg_count" : west_bengal_stg_count,
        "south_india_stg_count" : south_india_stg_count,
        "assam_stg_count" : assam_stg_count,
        "north_east_stg_count" : north_east_stg_count,

        "west_bengal_agg_count" : west_bengal_agg_count,
        "south_india_agg_count" : south_india_agg_count,
        "assam_agg_count" : assam_agg_count,
        "north_east_agg_count" : north_east_agg_count,

        "wb_total_farm_diary" : wb_total_farm_diary,
        "si_total_farm_diary" : si_total_farm_diary,
        "assam_total_farm_diary" : assam_total_farm_diary,
        "north_east_total_farm_diary" : north_east_total_farm_diary,

        # "west_bengal_farmers_count" : west_bengal_farmers_count,
        # "south_india_farmers_count" : south_india_farmers_count,
        # "assam_farmers_count" : assam_farmers_count,
        # "north_east_farmers_count" : north_east_farmers_count,
    }

    return render(request, 'landing_page.html', context)

# @cache_page(60 * 15)
@login_required
# @user_type_required(user_type='blf')s
def index(request):
    """
    Index Dashboard View View
    """
    logged_user_type = Profile.objects.filter(user_id=request.user.id).first()
    user_type = logged_user_type.user_type

    todays_date = date.today()
    year = todays_date.year

    results = get_monthly_total_qty_dict(year, request.user.id)[0]
    tot_net_weight = get_monthly_total_qty_dict(year, request.user.id)[1]

    invoice_result = get_monthly_total_invoice_dict(int(year), request.user.id)[0]
    tot_invoice = get_monthly_total_invoice_dict(int(year), request.user.id)[1]


    year = []
    for i in range(2022, todays_date.year+1):
        year.append(i)

    # if not request.user.id == 1:

    if not request.user.is_superuser and str(user_type.name) == "blf":
        user_blf_account_details = request.user.profile_id_blf
        grower_male_count = user_blf_account_details.grower_associated_entity.filter(gender='Male', grower_type="STG").aggregate(
                partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
        grower_female_count = user_blf_account_details.grower_associated_entity.filter(gender='Female', grower_type="STG").aggregate(
                partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
        
        grower_other_count = user_blf_account_details.grower_associated_entity.filter(gender='Other', grower_type="STG").aggregate(
                partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
        
        tot_stg_growers = grower_male_count + grower_female_count + grower_other_count

        # Aggregator

        total_growers = user_blf_account_details.grower_associated_entity.all().aggregate(
                partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
        
        total_aggegators = AggregatorProfile.cmobjects.filter(associated_entity=user_blf_account_details).aggregate(
                        partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

        tot_growers_agg = total_growers + total_aggegators


    else:
        grower_male_count = ""
        grower_female_count = ""
        grower_other_count = ""
        tot_net_weight =""
        tot_stg_growers = ""
        total_aggegators = ""
        tot_growers_agg =""
        total_growers = ""

    #### ADMIN DASHBOARD
    region_list = Region.cmobjects.all()
    
    # BLF
    west_bengal_blf_count = BlfProfile.cmobjects.filter(region_id=4, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_blf_count = BlfProfile.cmobjects.filter(region_id=5, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_blf_count = BlfProfile.cmobjects.filter(region_id=6, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_blf_count = BlfProfile.cmobjects.filter(region_id=7, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']    
    
    others_blf = BlfProfile.cmobjects.filter(region_id__isnull=True, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    tot_blf = BlfProfile.cmobjects.filter(is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    

    # STG
    west_bengal_stg_count = GrowerProfile.cmobjects.filter(region_id=4, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_stg_count = GrowerProfile.cmobjects.filter(region_id=5, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_stg_count = GrowerProfile.cmobjects.filter(region_id=6, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_stg_count = GrowerProfile.cmobjects.filter(region_id=7, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    others_stg = GrowerProfile.cmobjects.filter(region_id__isnull=True, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total'] 

    tot_stg = GrowerProfile.cmobjects.filter(is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    # AGGREGATOR
    west_bengal_agg_count = AggregatorProfile.cmobjects.filter(region_id=4, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_agg_count = AggregatorProfile.cmobjects.filter(region_id=5, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_agg_count = AggregatorProfile.cmobjects.filter(region_id=6, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_agg_count = AggregatorProfile.cmobjects.filter(region_id=7, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    others_agg = AggregatorProfile.cmobjects.filter(region_id__isnull=True, is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']     
    tot_agg = AggregatorProfile.cmobjects.filter(is_active=True).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
                    
    # FARM DIARY 

    #use Of chemical
    west_bengal_farmers_useof_chemical = UseOfChemical.cmobjects.filter(grower__region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_farmers_useof_chemical = UseOfChemical.cmobjects.filter(grower__region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_farmers_useof_chemical = UseOfChemical.cmobjects.filter(grower__region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_farmers_useof_chemical = UseOfChemical.cmobjects.filter(grower__region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    
    #plucking Data
    west_bengal_farmers_plucking = PluckingData.cmobjects.filter(grower__region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_farmers_plucking = PluckingData.cmobjects.filter(grower__region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_farmers_plucking = PluckingData.cmobjects.filter(grower__region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_farmers_plucking = PluckingData.cmobjects.filter(grower__region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']


    #Labours Data
    west_bengal_farmers_labour = Labour.cmobjects.filter(grower__region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_farmers_labour = Labour.cmobjects.filter(grower__region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_farmers_labour = Labour.cmobjects.filter(grower__region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_farmers_labour= Labour.cmobjects.filter(grower__region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']


    #Monthly Schedule Data
    west_bengal_farmers_monthly = MonthlySchedule.cmobjects.filter(grower__region_id=4).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    south_india_farmers_monthly = MonthlySchedule.cmobjects.filter(grower__region_id=5).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    assam_farmers_monthly = MonthlySchedule.cmobjects.filter(grower__region_id=6).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']
    north_east_farmers_monthly = MonthlySchedule.cmobjects.filter(grower__region_id=7).aggregate(
                    partial_total=Coalesce(Count('id'), Value(0)))['partial_total']

    wb_total_farm_diary = west_bengal_farmers_useof_chemical + west_bengal_farmers_plucking + west_bengal_farmers_labour + west_bengal_farmers_monthly
   
    # print("wb_total_farm_diary", wb_total_farm_diary)
   
    si_total_farm_diary = south_india_farmers_useof_chemical + south_india_farmers_plucking + south_india_farmers_labour + south_india_farmers_monthly
    assam_total_farm_diary = assam_farmers_useof_chemical + assam_farmers_plucking + assam_farmers_labour + assam_farmers_monthly
    north_east_total_farm_diary = north_east_farmers_useof_chemical + north_east_farmers_plucking + north_east_farmers_labour + north_east_farmers_monthly

    tot_farms = si_total_farm_diary + wb_total_farm_diary + assam_total_farm_diary + north_east_total_farm_diary

    # BAR CHAT for supply collection
    select_year = request.GET.get('select_year', None)
    region = request.GET.get('region', None)

    if request.method == 'GET' and select_year and region:
        graph_select_year = select_year
        results = get_monthly_total_supply_entity_wise_qty_dict(int(select_year), region)[0]
        region_entity_wise_tot_net_weight = get_monthly_total_supply_entity_wise_qty_dict(int(select_year), region)[1]

    else:
         results = get_monthly_total_supply_entity_wise_qty_dict(int(todays_date.year), region)[0]
         region_entity_wise_tot_net_weight = get_monthly_total_supply_entity_wise_qty_dict(int(todays_date.year), region)[1]
         graph_select_year = todays_date.year

    region_entity_wise_tot_net_weight = 0

    # BAR CHAT for supply collection with Entity
    region = request.GET.get('region', None)
    entity_id = request.GET.get('entity_id', None)

    if request.method == 'GET' and select_year and region and entity_id:
        pass

    context = {
            "region_list" : region_list,
            'year' : year,
            'results': results,
            'current_year' : todays_date.year,
            'grower_male_count' : grower_male_count,
            'grower_female_count' : grower_female_count, 
            'grower_other_count' : grower_other_count,
            'tot_net_weight' : tot_net_weight,
            'tot_stg_growers' : tot_stg_growers,
            'total_aggegators' : total_aggegators,
            'tot_growers_agg' : tot_growers_agg,
            'total_growers' : total_growers,
            'invoice_result' : invoice_result,
            'tot_invoice' : tot_invoice,

            "region_list" : region_list,
            # blf region wise
            "west_bengal_blf_count" : west_bengal_blf_count,
            "south_india_blf_count" : south_india_blf_count,
            "assam_blf_count" : assam_blf_count,
            "north_east_blf_count" : north_east_blf_count,
            "tot_blf" : tot_blf,
            "others_blf" : others_blf,
            # stg
            "west_bengal_stg_count" : west_bengal_stg_count,
            "south_india_stg_count" : south_india_stg_count,
            "assam_stg_count" : assam_stg_count,
            "north_east_stg_count" : north_east_stg_count,
            "tot_stg" : tot_stg,
            "others_stg" : others_stg,
            # agg
            "west_bengal_agg_count" : west_bengal_agg_count,
            "south_india_agg_count" : south_india_agg_count,
            "assam_agg_count" : assam_agg_count,
            "north_east_agg_count" : north_east_agg_count,
            "tot_agg" : tot_agg,
            "others_agg" : others_agg,

            # Farm Diary
            "wb_total_farm_diary" : wb_total_farm_diary,
            "si_total_farm_diary" : si_total_farm_diary,
            "assam_total_farm_diary" : assam_total_farm_diary,
            "north_east_total_farm_diary" : north_east_total_farm_diary,
            "tot_farms" : tot_farms,

            # 'year' : year,
            "results" : results,
            "select_year" : select_year,
            "region_entity_wise_tot_net_weight" : region_entity_wise_tot_net_weight,

            "graph_select_year" : graph_select_year,
            
    }

    return CommonMixin.render(request, 'index.html', context)






def dashboard_supply_collection_region_wise_graph(request):
    """
    Supply Collection Graph Region for ADMIN 
    """
    year = request.GET.get('year', None)
    region = request.GET.get('region', None)

    region_details = Region.cmobjects.filter(pk=region).first()

    print(region)
    print(year)

    results = get_monthly_total_supply_qty_dict(int(year), region)[0]
    tot_net_weight = get_monthly_total_supply_qty_dict(int(year), region)[1]

    context = {
        'results': results,
        'tot_net_weight' : tot_net_weight,
        'year' : year,
        "region" : region,
        "region_details" : region_details,
    }
    if request.is_ajax():
        html = render_to_string('suply_collection_region_wise.html',
                                context, request=request)
        
    data = {"html" : html, 'tot_net_weight' : tot_net_weight, 'year' : year}

    return JsonResponse(data)




def dashboard_invoice_entity_wise_graph(request):
    """
     Invoice  Graph Region for ADMIN 
    """
    year = request.GET.get('year', None)
    region = request.GET.get('region', None)
    entity_id = request.GET.get('entity_id', None)

    blf_details = BlfProfile.cmobjects.filter(id=entity_id).first()
    user_details = User.objects.filter(username=blf_details).first()
    user_id = user_details.pk


    print(region)
    print(year)
    print(entity_id)

    results = get_monthly_total_invoice_entity_dict(int(year), user_id)[0]
    tot_invoice = get_monthly_total_invoice_entity_dict(int(year), user_id)[1]

    context = {
        'results': results,
        'tot_invoice' : tot_invoice,
        'year' : year,
        "region" : region,
        "blf_details" : blf_details,
    }
    if request.is_ajax():
        html = render_to_string('invoice_entity_wise_graph.html',
                                context, request=request)
        
    data = {"html" : html, 'tot_invoice' : tot_invoice, 'year' : year}

    return JsonResponse(data)




def dashboard_supply_collection_entity_wise_graph(request):
    """
    Supply Collection Graph for ADMIN 
    """
    year = request.GET.get('year', None)
    region = request.GET.get('region', None)
    entity_id = request.GET.get('entity_id', None)

    blf_details = BlfProfile.cmobjects.filter(id=entity_id).first()
    user_details = User.objects.filter(username=blf_details).first()
    user_id = user_details.pk

    results = get_monthly_total_supply_entity_wise_qty_dict(int(year), user_id)[0]
    tot_net_weight = get_monthly_total_supply_entity_wise_qty_dict(int(year), user_id)[1]
    
    context = {
        'results': results,
        'tot_net_weight' : tot_net_weight,
        'year' : year,
        "blf_details" : blf_details,
    }

    if request.is_ajax():
        html = render_to_string('suply_collection_entity_wise.html',
                                context, request=request)
        
    data = {"html" : html, 'tot_net_weight' : tot_net_weight, 'year' : year}

    return JsonResponse(data)





def dashboard_graph_ajax(request):
    """
    Ajax Request To Update Bar Graph Based on Year
    """
    year = request.GET.get('year', None)

    results = get_monthly_total_qty_dict(int(year), request.user.id)[0]

    usertype_list = ProfileType.objects.exclude(name="ADMIN").order_by('-id')
    blf_details = BlfProfile.objects.filter(user_id=request.user.id).first()
    user_details = Profile.objects.filter(user_id=request.user.id).first()
    logged_user_type = str(user_details.user_type)
    tot_net_weight = get_monthly_total_qty_dict(int(year), request.user.id)[1]

    invoice_result = get_monthly_total_invoice_dict(int(year), request.user.id)[0]

    tot_invoice = get_monthly_total_invoice_dict(int(year), request.user.id)[1]

    context = {
        'results': results,
        'usertype_list': usertype_list,
        'blf_details' : blf_details,
        'logged_user_type': logged_user_type,
        'year' : year,
        'tot_net_weight' : tot_net_weight,
        'invoice_result' : invoice_result,
        'tot_invoice' : tot_invoice,
    }

    if request.is_ajax():
        html = render_to_string('leaf_collection_graph_ajax.html',
                                context, request=request)
        
    data = {"html" : html, 'tot_net_weight' : tot_net_weight, 'tot_invoice' : tot_invoice, 'year' : year}

    return JsonResponse(data)


def dashboard_invoice_graph_ajax(request):
    """
    Ajax Request To Update Bar Graph Based on Year -- Invoice graph
    """
    year = request.GET.get('year', None)
    results = get_monthly_total_qty_dict(int(year), request.user.id)[0]
    usertype_list = ProfileType.objects.exclude(name="ADMIN").order_by('-id')
    blf_details = BlfProfile.objects.filter(user_id=request.user.id).first()
    user_details = Profile.objects.filter(user_id=request.user.id).first()
    logged_user_type = str(user_details.user_type)
    tot_net_weight = get_monthly_total_qty_dict(int(year), request.user.id)[1]
    context = {
        'results': results,
        'usertype_list': usertype_list,
        'blf_details' : blf_details,
        'logged_user_type': logged_user_type,
        'year' : year,
        'tot_net_weight' : tot_net_weight
    }
    if request.is_ajax():
        html = render_to_string('graph_invoice_data.html',
                                context, request=request)
    data = {"html" : html, 'tot_net_weight' : tot_net_weight, 'year' : year}
    return JsonResponse(data)













################# Region Render Start ###############################################
# @api_view(['GET','POST'])

class RegionListView(LoginRequiredMixin, CommonMixin, ListView):
    """
    Region List View
    """
    model = Region
    context_object_name = 'region_list'
    template_name = 'master/region_list.html'
    paginate_by = 5

    def get(self, request, *args, **kwargs):
        try:
            if not self.request.user.is_superuser:
                messages.error(self.request, 'You have no permission to access the requested resource!')
                return redirect(reverse('index'))
        except AttributeError as error:
            messages.error(self.request, 'You have no permission to access the requested resource!')
            return redirect(reverse('index'))

        return super().get(request, *args, **kwargs)

    def get_queryset(self, *args, **kwargs):
        query = self.request.GET.get('q', '').strip()
        qs = Region.objects.prefetch_related('state').filter(is_deleted=False)
        if query:
            qs = qs.filter(
                Q(region_name__icontains=query) |
                Q(abbrevation__icontains=query) |
                Q(state__name__icontains=query)
            ).distinct()
        return qs.order_by('-id')
        
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['list_url'] = reverse('region_list')
        context['current_list_url'] = self.request.get_full_path()
        return context

    def render_to_response(self, context, **response_kwargs):
        if is_ajax_request(self.request):
            return render(self.request, 'master/_region_table.html', context)
        return super().render_to_response(context, **response_kwargs)
    



@login_required
def RegionSearch(request):

    if request.method == 'POST':
        """Search Region Trace Tea@vivek"""
        region_name=request.POST.get('region_name')
        region=Region.cmobjects.filter(region_name__icontains=region_name).order_by('-id')
        page = request.GET.get('page',1)  
        paginator = Paginator(region, 3)  ########### implementation of pagination 
        try:
            region_list = paginator.page(page)
        except PageNotAnInteger:
            region_list = paginator.page(1)
        except EmptyPage:
            region_list = paginator.page(paginator.num_pages)
        context = {'region_list':region_list}
    else:
             print("No information to show")
             return CommonMixin.render(request, 'master/region_list.html', {})      
    return CommonMixin.render(request, 'master/region_list.html',context)



class RegionCreateView(LoginRequiredMixin, CreateView, CommonMixin):
    """
    Region Create View
    """
    form_class = RegionForm
    template_name = 'master/region_add.html'

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    def get_success_url(self, **kwargs):
        messages.success(self.request, 'Region Created Successfully')
        return get_safe_next_url(self.request, reverse('region_list'))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['next_url'] = get_safe_next_url(self.request, reverse('region_list'))
        return context

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

    # def form_invalid(self, form):
    #     messages.error(self.request, "Please correct the errors below.")

    #     # Optional: show all field errors in messages
    #     for field, errors in form.errors.items():
    #         for error in errors:
    #             messages.error(self.request, f"{field}: {error}")

    #     return super().form_invalid(form)




from django.shortcuts import get_object_or_404

class RegionUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	Region Update View @vivek
	"""
	model = Region
	form_class = RegionForm
	template_name = 'master/region_add.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is customer
		try:
			if not self.request.user.is_superuser:
				messages.error(self.request, 'You have no permission to access the requested resource!')
				return redirect(reverse('index'))
		except AttributeError as error:
			messages.error(self.request, 'You have no permission to access the requested resource!')
			return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Region Updated Successfully')
		return get_safe_next_url(self.request, reverse('region_list'))


	def get_object(self,queryset=None):
		region_details = get_object_or_404(Region, pk=self.kwargs['id'], is_deleted=False)
		return region_details

	def get_context_data(self, **kwargs):
		context = super(RegionUpdateView, self).get_context_data(**kwargs)

		context['region_details'] = self.get_object()
		context['next_url'] = get_safe_next_url(self.request, reverse('region_list'))
		return context
	def form_valid(self, form):
		
		self.id = self.kwargs['id']
		context = self.get_context_data()


		with transaction.atomic():
			self.object = form.save()


		return super(RegionUpdateView, self).form_valid(form)
	


# @login_required

# def RegionDelete(request,id):
#     if request.method == 'POST':
#         """Delete Region Trace Tea@vivek"""
#         # region_id=request.POST.get('region_id')
#         region_select=Region.cmobjects.filter(id=id)
#         region_select.delete()
#         messages.success(request, "Region Deleted")
#         return HttpResponseRedirect(reverse('region_list'))
#     return CommonMixin.render(request, 'master/region_list.html')



@login_required
def RegionDelete(request, id):

    try:
        if not request.user.is_superuser:
            messages.error(request, 'You have no permission to access the requested resource!')
            return redirect(reverse('index'))
    except AttributeError as error:
        messages.error(request, 'You have no permission to access the requested resource!')
        return redirect(reverse('index'))

    region = Region.objects.filter(id=id, is_deleted=False).first()
    return soft_delete_instance_for_web(
        request,
        region,
        get_safe_next_url(request, reverse('region_list')),
        success_message='Region Deleted Successfully',
        not_found_message='Region not found.',
    )


@login_required
def RegionView(request, id):
    region_details = Region.objects.filter(pk=id, is_deleted=False).first()
    context={
        'region_details' : region_details,
        'next_url': get_safe_next_url(request, reverse('region_list')),
     }
    return CommonMixin.render(request, 'master/region_view.html',context)    
	



############### Region Render End####################################

def load_state(request):
    """ load state according to region @vivek"""
    region_id = request.GET.get('region_id')
    if not str(region_id or "").isdigit():
        return render(request, 'master/state_dropdown_list_options.html', {'states': []})
    states = Region.objects.filter(id=region_id, state__isnull=False).values('state__name','state__state_id','state__id').distinct()
  
    return render(request, 'master/state_dropdown_list_options.html', {'states':states,})

def load_district(request):
    """ load district according to state @vivek"""

    state_id= request.GET.get('state_id')
    if not str(state_id or "").isdigit():
        return render(request, 'master/district_dropdown_list_options.html', {'districts': []})
    state_name = State.objects.filter(id=state_id)
    districts = District.objects.none()
    for data in state_name:
        districts=District.objects.filter(state__name=data.name).values('name','id','district_id')

    return render(request, 'master/district_dropdown_list_options.html', {'districts': districts})

# def load_associated_entity(request):
#     """ load associated_entity according to region @vivek"""

#     region_id= request.GET.get('region_id')
#     entity = AssociatedEntity.objects.filter(region_id=region_id).values('name','id')
#     return render(request, 'master/associated_entity_list_options.html', {'entity': entity})



from .utils import *
# @csrf_exempt

import xlwt
@permission_required_admin

# def export_data_to_excel(request):
#     objs=Region.objects.all()
#     data=[]
     
#     output = BytesIO()
#     for obj in objs:
#         data.append({
#                "region_id":obj.region_id,
#                "region_name":obj.region_name,
#           })
#     df=pd.DataFrame(data).to_excel('out.xlsx')
    
   
def ExportRegionData(request):
    """Export or download template for bulk upload @vivek"""

    if request.method == 'GET':
        # Get selected option from form
        # type=request.GET.get('type')
        # if type=='region':
        master_resource = RegionResource()
        dataset = master_resource.export()
        response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="region.xls"'
        # if type=='state':
        #     master_resource = MasterResource()
        #     dataset = master_resource.export()
        #     response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
        #     response['Content-Disposition'] = 'attachment; filename="state.xls"'
        # if type=='district':
        #     master_resource = MasterResource()
        #     dataset = master_resource.export() 
        #     response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
        #     response['Content-Disposition'] = 'attachment; filename="district.xls"'   
        
        # response2 = HttpResponse(dataset1.xls, content_type='application/vnd.ms-excel')

        
        # response2['Content-Disposition'] = 'attachment; filename="district.xls"'

        # wb = xlwt.Workbook(encoding='utf-8')
        # ws = wb.add_sheet('Region')
        # wb.save(response)
        return response
def ExportStateData(request):
    """Export or download template for bulk upload @vivek"""

    if request.method == 'GET':
     
        master_resource = StateResource()
        dataset = master_resource.export()
        response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="state.xls"'
       
        return response    
def ExportDistrictData(request):
    """Export or download template for bulk upload @vivek"""

    if request.method == 'GET':
     
        master_resource = DistrictResource()
        dataset = master_resource.export()
        response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="district.xls"'
       
        return response   



GROWER_BULK_CREATE_COLUMNS = [
    'username', 'password', 'name', 'tea_board_id', 'land_document_no',
    'lease_agreement_no', 'gaon_bura_certificate_no', 'enjoyment_certificate_no',
    'age', 'gender', 'date_of_birth', 'grower_type', 'region', 'state', 'district',
    'village_or_town', 'address', 'mobile_number', 'associated_aggregator',
    'associated_entity', 'total_male_worker', 'total_female_worker',
    'estimated_production_of_green_tea', 'estimated_production_of_made_tea',
    'production_area',
]

# Bulk update intentionally uses the same sheet layout as bulk create.
# In update mode, `username` is the required Unique Grower ID used for matching.
GROWER_BULK_UPDATE_COLUMNS = GROWER_BULK_CREATE_COLUMNS

GROWER_REGISTRATION_IDENTIFIER_COLUMNS = [
    'tea_board_id',
    'land_document_no',
    'lease_agreement_no',
    'gaon_bura_certificate_no',
    'enjoyment_certificate_no',
]

GROWER_REGISTRATION_IDENTIFIER_LABELS = {
    'tea_board_id': 'Tea Board Registration Number',
    'land_document_no': 'Land Document Number',
    'lease_agreement_no': 'Lease Agreement Number',
    'gaon_bura_certificate_no': 'Gaon Bura Certificate Number',
    'enjoyment_certificate_no': 'Enjoyment Certificate Number',
}

GROWER_BULK_CREATE_SAMPLE_ROW = {
    'username': '',
    'password': '',
    'name': 'BADRUL JAMAL',
    'tea_board_id': '',
    'land_document_no': '',
    'lease_agreement_no': '',
    'gaon_bura_certificate_no': '',
    'enjoyment_certificate_no': '',
    'age': '',
    'gender': 'Male',
    'date_of_birth': '',
    'grower_type': 'STG',
    'region': 'West Bengal',
    'state': 'West Bengal',
    'district': 'Uttar Dinajpur',
    'village_or_town': 'CHARGHORIA',
    'address': 'BHAKTISINGGACHH',
    'mobile_number': '9932479428',
    'associated_aggregator': 'BADRUL JAMAL / WAJID ALAM / MD NAZIR HUSSAIN / PAMPA SINGHA DEBNATH',
    'associated_entity': '',
    'total_male_worker': 2,
    'total_female_worker': 1,
    'estimated_production_of_green_tea': 40035,
    'estimated_production_of_made_tea': '',
    'production_area': 2.55,
}


def _clean_bulk_value(value):
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ''
    return str(value).strip()


def _bulk_int_or_none(value):
    value = _clean_bulk_value(value)
    if not value:
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _bulk_date_or_none(value):
    value = _clean_bulk_value(value)
    if not value:
        return None
    try:
        return pd.to_datetime(value).date()
    except Exception:
        return None


def _bulk_normalise(value):
    return _clean_bulk_value(value).casefold()


def _bulk_identifier_key(value):
    return _clean_bulk_value(value).casefold()


def _grower_identifier_label(field_name):
    return GROWER_REGISTRATION_IDENTIFIER_LABELS.get(
        field_name,
        field_name.replace('_', ' ').title(),
    )


def _validate_grower_identifier_unique_in_db(field_name, value, refs=None, update_profile=None):
    value = _clean_bulk_value(value)
    if not value:
        return None

    if refs and 'existing_identifiers' in refs:
        duplicate = refs['existing_identifiers'].get((field_name, _bulk_identifier_key(value)))
        if not duplicate:
            return None
        duplicate_pk = duplicate.get('pk')
        if update_profile and update_profile.pk and duplicate_pk == update_profile.pk:
            return None
        duplicate_username = duplicate.get('username') or duplicate_pk
        return f"{_grower_identifier_label(field_name)} '{value}' already exists for Grower ID {duplicate_username}."

    queryset = GrowerProfile.objects.filter(**{field_name: value})
    if update_profile and update_profile.pk:
        queryset = queryset.exclude(pk=update_profile.pk)
    duplicate = queryset.select_related('user').first()
    if not duplicate:
        return None

    duplicate_username = duplicate.user.username if duplicate.user else duplicate.pk
    return f"{_grower_identifier_label(field_name)} '{value}' already exists for Grower ID {duplicate_username}."


def _validate_grower_identifier_unique_in_file(record, row_number, seen_identifiers, update_profile=None):
    errors = []
    for field_name in GROWER_REGISTRATION_IDENTIFIER_COLUMNS:
        value = _clean_bulk_value(record.get(field_name))
        if not value and update_profile:
            value = _clean_bulk_value(getattr(update_profile, field_name, ''))
        if not value:
            continue

        key = (field_name, _bulk_identifier_key(value))
        if key in seen_identifiers:
            first_row = seen_identifiers[key]
            errors.append(
                f"Row {row_number}: {_grower_identifier_label(field_name)} '{value}' is duplicated in the uploaded file. First used in row {first_row}."
            )
        else:
            seen_identifiers[key] = row_number
    return errors


def _write_grower_workbook(columns, rows=None, filename='grower.xlsx'):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = 'Growers'
    worksheet.append(columns)
    for row in rows or []:
        worksheet.append([row.get(column, '') for column in columns])
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    workbook.save(response)
    return response


def _bulk_pending_path(token):
    directory = os.path.join('media', 'excel', 'pending_grower_bulk')
    os.makedirs(directory, exist_ok=True)
    return os.path.join(directory, f'{token}.json')


def _save_pending_grower_rows(rows):
    token = uuid4().hex
    with open(_bulk_pending_path(token), 'w', encoding='utf-8') as handle:
        json.dump(rows, handle, default=str)
    return token


def _load_pending_grower_rows(token):
    with open(_bulk_pending_path(token), 'r', encoding='utf-8') as handle:
        return json.load(handle)


def _delete_pending_grower_rows(token):
    path = _bulk_pending_path(token)
    if os.path.exists(path):
        os.remove(path)


def _grower_bulk_reference_data(dataframe=None):
    def column_values(column_name):
        if dataframe is None or column_name not in dataframe.columns:
            return set()
        return {
            _clean_bulk_value(value)
            for value in dataframe[column_name].tolist()
            if _clean_bulk_value(value)
        }

    upload_usernames = column_values('username')
    upload_names = column_values('name')
    upload_identifier_values = {
        field_name: column_values(field_name)
        for field_name in GROWER_REGISTRATION_IDENTIFIER_COLUMNS
    }
    upload_aggregator_names = set()
    if dataframe is not None and 'associated_aggregator' in dataframe.columns:
        for value in dataframe['associated_aggregator'].tolist():
            upload_aggregator_names.update(
                item.strip()
                for item in _clean_bulk_value(value).split('/')
                if item.strip()
            )

    existing_identifiers = {}
    grower_profiles_by_username = {}
    duplicate_candidates_by_name = {}
    grower_filter = Q()
    if upload_usernames:
        grower_filter |= Q(user__username__in=upload_usernames)
    if upload_names:
        grower_filter |= Q(name__in=upload_names)
    for field_name, values in upload_identifier_values.items():
        if values:
            grower_filter |= Q(**{f'{field_name}__in': values})

    grower_queryset = GrowerProfile.cmobjects.select_related(
        'user',
        'region',
        'state',
        'district',
        'associated_blf',
    ).prefetch_related('associated_entity')
    if grower_filter:
        grower_queryset = grower_queryset.filter(grower_filter)
    else:
        grower_queryset = GrowerProfile.cmobjects.none()

    for profile in grower_queryset:
        if profile.user and profile.user.username:
            grower_profiles_by_username[_bulk_normalise(profile.user.username)] = profile
        for field_name in GROWER_REGISTRATION_IDENTIFIER_COLUMNS:
            value = _clean_bulk_value(getattr(profile, field_name, ''))
            if value:
                existing_identifiers[(field_name, _bulk_identifier_key(value))] = {
                    'pk': profile.pk,
                    'username': profile.user.username if profile.user else '',
                }
        name_key = _bulk_normalise(profile.name)
        if name_key:
            associated_entities = list(profile.associated_entity.all())
            duplicate_candidates_by_name.setdefault(name_key, []).append({
                'username': profile.user.username if profile.user else '',
                'name': profile.name or '',
                'region': profile.region.region_name if profile.region else '',
                'tbr_number': profile.tea_board_id or '',
                'district': profile.district.name if profile.district else '',
                'mobile_number': profile.mobile_number or '',
                'associated_blf': (
                    profile.associated_blf.entity_unit
                    if profile.associated_blf else
                    (associated_entities[0].entity_unit if associated_entities else '')
                ),
            })

    aggregators_by_name = {}
    aggregators_by_blf_name = {}
    aggregator_queryset = AggregatorProfile.cmobjects.select_related('user').prefetch_related('associated_entity')
    if upload_aggregator_names:
        aggregator_queryset = aggregator_queryset.filter(name__in=upload_aggregator_names)
    else:
        aggregator_queryset = AggregatorProfile.cmobjects.none()
    for aggregator in aggregator_queryset:
        name_key = _bulk_normalise(aggregator.name)
        if not name_key:
            continue
        linked_blf_ids = {blf.id for blf in aggregator.associated_entity.all()}
        aggregator._bulk_linked_blf_ids = linked_blf_ids
        aggregators_by_name.setdefault(name_key, []).append(aggregator)
        for blf_id in linked_blf_ids:
            aggregators_by_blf_name[(blf_id, name_key)] = aggregator

    return {
        'regions': {_bulk_normalise(item.region_name): item for item in Region.cmobjects.all()},
        'states': {_bulk_normalise(item.name): item for item in State.objects.filter(is_deleted=False)},
        'districts': {_bulk_normalise(item.name): item for item in District.objects.filter(is_deleted=False)},
        'blfs': {_bulk_normalise(item.entity_unit): item for item in BlfProfile.cmobjects.select_related('user', 'region')},
        'usernames': {
            _bulk_normalise(username)
            for username in User.objects.filter(username__in=upload_usernames).values_list('username', flat=True)
        },
        'existing_identifiers': existing_identifiers,
        'grower_profiles_by_username': grower_profiles_by_username,
        'duplicate_candidates_by_name': duplicate_candidates_by_name,
        'aggregators_by_name': aggregators_by_name,
        'aggregators_by_blf_name': aggregators_by_blf_name,
    }


def _generate_bulk_grower_username(full_name, village, serial_number, reserved_usernames=None, existing_usernames=None):
    full_name = _clean_bulk_value(full_name).upper()
    village = _clean_bulk_value(village).upper()
    reserved_usernames = reserved_usernames or set()
    should_query_existing_usernames = existing_usernames is None
    existing_usernames = existing_usernames or set()
    if not full_name:
        raise ValueError('Full name cannot be empty.')
    if not village:
        raise ValueError('Village or town is required when username is blank.')

    name_parts = [part for part in full_name.split() if part]
    first_name = name_parts[0]
    last_part = name_parts[-1][:2] if len(name_parts) >= 2 else ''
    first_part = first_name if len(first_name) == 1 else first_name[:2]

    for village_length in range(2, len(village) + 1):
        village_part = village[:village_length]
        prefix = (first_part + last_part + village_part) if last_part else (first_part + village_part)
        username = (prefix + f"{serial_number:02d}").replace('.', '').replace(' ', '')
        username_key = username.casefold()
        exists_in_db = should_query_existing_usernames and User.objects.filter(username__iexact=username).exists()
        if username_key not in reserved_usernames and username_key not in existing_usernames and not exists_in_db:
            return username

    candidate_serial = serial_number + 1
    while True:
        prefix = (first_part + last_part + village) if last_part else (first_part + village)
        username = (prefix + f"{candidate_serial:02d}").replace('.', '').replace(' ', '')
        username_key = username.casefold()
        exists_in_db = should_query_existing_usernames and User.objects.filter(username__iexact=username).exists()
        if username_key not in reserved_usernames and username_key not in existing_usernames and not exists_in_db:
            return username
        candidate_serial += 1


def _validate_grower_bulk_row(row, row_number, refs, update_profile=None, serial_number=None, reserved_usernames=None):
    errors = []
    resolved = {}
    values = {column: _clean_bulk_value(row.get(column)) for column in GROWER_BULK_CREATE_COLUMNS}

    if not update_profile:
        if not values['username']:
            try:
                values['username'] = _generate_bulk_grower_username(
                    values['name'],
                    values['village_or_town'],
                    serial_number or row_number - 1,
                    reserved_usernames=reserved_usernames,
                )
            except ValueError as error:
                errors.append(str(error))
        for field_name in ('name', 'grower_type', 'region', 'state', 'district', 'gender'):
            if not values[field_name]:
                errors.append(f"{field_name.replace('_', ' ').title()} is required.")
        if values['username'] and _bulk_normalise(values['username']) in refs.get('usernames', set()):
            errors.append('Username already exists.')
    else:
        values['username'] = update_profile.user.username
        for field_name in ('name', 'grower_type', 'region', 'state', 'district', 'gender'):
            if not values[field_name]:
                current_value = getattr(update_profile, field_name, None)
                if field_name == 'associated_entity':
                    current_value = update_profile.associated_blf or update_profile.associated_entity.first()
                if not current_value:
                    errors.append(f"{field_name.replace('_', ' ').title()} is required.")

    merged_identifiers = {
        field: values[field] or (_clean_bulk_value(getattr(update_profile, field, '')) if update_profile else '')
        for field in GROWER_REGISTRATION_IDENTIFIER_COLUMNS
    }
    if not any(merged_identifiers.values()):
        errors.append('At least one grower identification number is required.')

    for field_name in GROWER_REGISTRATION_IDENTIFIER_COLUMNS:
        if values[field_name] and not re.match(r'^[A-Za-z0-9]+$', values[field_name]):
            errors.append(f"{_grower_identifier_label(field_name)} must be alphanumeric.")
        duplicate_error = _validate_grower_identifier_unique_in_db(
            field_name,
            merged_identifiers.get(field_name),
            refs=refs,
            update_profile=update_profile,
        )
        if duplicate_error:
            errors.append(duplicate_error)

    grower_type = values['grower_type'] or (update_profile.grower_type if update_profile else '')
    if grower_type and grower_type not in dict(GrowerProfile.grower_option):
        errors.append('Grower Type is invalid.')
    gender = values['gender'].title() if values['gender'] else (update_profile.gender if update_profile else '')
    if gender and gender not in dict(GrowerProfile.GENDER_TYPE):
        errors.append('Gender is invalid.')

    for field_name, ref_key in (('region', 'regions'), ('state', 'states'), ('district', 'districts'), ('associated_entity', 'blfs')):
        raw_value = values[field_name]
        if raw_value:
            resolved[field_name] = refs[ref_key].get(_bulk_normalise(raw_value))
            if not resolved[field_name]:
                errors.append(f"{field_name.replace('_', ' ').title()} '{raw_value}' was not found.")
        elif update_profile:
            if field_name == 'associated_entity':
                resolved[field_name] = update_profile.associated_blf or update_profile.associated_entity.first()
            else:
                resolved[field_name] = getattr(update_profile, field_name)

    if resolved.get('state') and resolved.get('district') and resolved['district'].state_id != resolved['state'].id:
        errors.append('District does not belong to the selected State.')

    aggregator_names = [item.strip() for item in values['associated_aggregator'].split('/') if item.strip()]
    aggregators = []
    if not resolved.get('associated_entity') and aggregator_names:
        candidate_blf_ids = None
        missing_names = []
        for name in aggregator_names:
            matching_aggregators = refs.get('aggregators_by_name', {}).get(_bulk_normalise(name), [])
            if not matching_aggregators:
                missing_names.append(name)
                continue
            linked_blf_ids = set()
            for aggregator in matching_aggregators:
                linked_blf_ids.update(getattr(aggregator, '_bulk_linked_blf_ids', set()))
            candidate_blf_ids = linked_blf_ids if candidate_blf_ids is None else candidate_blf_ids & linked_blf_ids
        if missing_names:
            errors.append(f"Associated Aggregator not found: {', '.join(missing_names)}.")
        elif candidate_blf_ids and len(candidate_blf_ids) == 1:
            selected_blf_id = next(iter(candidate_blf_ids))
            resolved['associated_entity'] = next(
                (blf for blf in refs.get('blfs', {}).values() if blf.id == selected_blf_id),
                None,
            )
        else:
            errors.append('Associated Entity is required when aggregators do not resolve to one common BLF.')
    if not resolved.get('associated_entity'):
        errors.append('Associated Entity is required.')

    selected_blf = resolved.get('associated_entity')
    if selected_blf and resolved.get('region') and selected_blf.region_id != resolved['region'].id:
        blf_region_name = selected_blf.region.region_name if selected_blf.region else 'not set'
        selected_region_name = resolved['region'].region_name
        errors.append(f"Region must be same as selected BLF region. Selected BLF region is '{blf_region_name}', uploaded region is '{selected_region_name}'.")

    if aggregator_names and selected_blf:
        missing = []
        for name in aggregator_names:
            aggregator = refs.get('aggregators_by_blf_name', {}).get((selected_blf.id, _bulk_normalise(name)))
            if aggregator:
                aggregators.append(aggregator)
            else:
                missing.append(name)
        if missing:
            errors.append(f"Associated Aggregator not linked to selected BLF: {', '.join(missing)}.")

    if errors:
        return None, [f"Row {row_number}: {error}" for error in errors]

    cleaned = {
        **values,
        'gender': gender or None,
        'grower_type': grower_type or None,
        'date_of_birth': _bulk_date_or_none(values['date_of_birth']),
        'age': _bulk_int_or_none(values['age']),
        'total_male_worker': _bulk_int_or_none(values['total_male_worker']),
        'total_female_worker': _bulk_int_or_none(values['total_female_worker']),
        'region_id': resolved['region'].id,
        'state_id': resolved['state'].id,
        'district_id': resolved['district'].id,
        'associated_blf_id': resolved['associated_entity'].id,
        'aggregator_ids': [item.id for item in aggregators],
    }
    return cleaned, []


def _grower_duplicate_candidates(name, refs=None):
    if refs and 'duplicate_candidates_by_name' in refs:
        return refs['duplicate_candidates_by_name'].get(_bulk_normalise(name), [])[:10]

    matches = GrowerProfile.cmobjects.select_related('region', 'district', 'associated_blf__user', 'user').filter(
        name__iexact=name
    )[:10]
    return [
        {
            'username': match.user.username if match.user else '',
            'name': match.name or '',
            'region': match.region.region_name if match.region else '',
            'tbr_number': match.tea_board_id or '',
            'district': match.district.name if match.district else '',
            'mobile_number': match.mobile_number or '',
            'associated_blf': (
                match.associated_blf.entity_unit
                if match.associated_blf else
                ((match.associated_entity.first().entity_unit) if match.associated_entity.exists() else '')
            ),
        }
        for match in matches
    ]


def _create_bulk_grower(record, actor):
    profile_type = ProfileType.objects.filter(name__iexact='grower').first()
    user = User.objects.create_user(
        username=record['username'],
        password=record.get('password') or DEFAULT_USER_PASSWORD,
        first_name=(record['name'] or '')[:30],
    )
    profile = GrowerProfile(
        user=user,
        profile_type=profile_type,
        name=record['name'],
        grower_type=record['grower_type'],
        region_id=record['region_id'],
        state_id=record['state_id'],
        district_id=record['district_id'],
        associated_blf_id=record['associated_blf_id'],
        gender=record['gender'],
        date_of_birth=record['date_of_birth'],
        age=record['age'],
        mobile_number=record['mobile_number'] or None,
        village_or_town=record['village_or_town'] or None,
        address=record['address'] or None,
        father_name=record.get('father_name') or None,
        tea_board_id=record['tea_board_id'] or None,
        land_document_no=record['land_document_no'] or None,
        lease_agreement_no=record['lease_agreement_no'] or None,
        gaon_bura_certificate_no=record['gaon_bura_certificate_no'] or None,
        enjoyment_certificate_no=record['enjoyment_certificate_no'] or None,
        total_male_worker=record['total_male_worker'],
        total_female_worker=record['total_female_worker'],
        estimated_production_of_green_tea=record['estimated_production_of_green_tea'] or None,
        estimated_production_of_made_tea=record['estimated_production_of_made_tea'] or None,
        garden_name=record.get('garden_name') or None,
        production_area=record['production_area'] or None,
        created_by=actor,
        updated_by=actor,
    )
    profile._skip_optional_unique_validation = True
    profile.save()
    profile.associated_entity.set([record['associated_blf_id']])
    profile.associated_aggregator.set(record['aggregator_ids'])
    Profile.objects.update_or_create(
        user=user,
        defaults={
            'user_type': profile_type,
            'full_name': profile.name,
            'phone_no': profile.mobile_number,
            'region_id': profile.region_id,
            'state_id': profile.state_id,
            'district_id': profile.district_id,
            'address': profile.address,
            'trustea_id': profile.tea_board_id,
            'created_by': actor,
            'updated_by': actor,
            'default_password_active': True,
            'password_reset_required': True,
        },
    )
    garden, _created = Gardens.objects.update_or_create(
        grower=profile,
        defaults={
            'user': user,
            'name': record.get('garden_name') or profile.name,
            'is_division': False,
            'is_plot': True,
            'production_area': record['production_area'] or None,
        },
    )
    Plot.objects.update_or_create(garden=garden, defaults={'name': profile.name, 'plot_status': True})


def _update_bulk_grower(profile, record):
    for field_name in (
        'name', 'grower_type', 'gender', 'date_of_birth', 'age', 'mobile_number', 'village_or_town',
        'address', 'father_name', 'tea_board_id', 'land_document_no', 'lease_agreement_no',
        'gaon_bura_certificate_no', 'enjoyment_certificate_no', 'total_male_worker', 'total_female_worker',
        'estimated_production_of_green_tea', 'estimated_production_of_made_tea', 'garden_name', 'production_area',
    ):
        value = record.get(field_name)
        if value not in ('', None):
            setattr(profile, field_name, value)
    profile.region_id = record['region_id']
    profile.state_id = record['state_id']
    profile.district_id = record['district_id']
    profile.associated_blf_id = record['associated_blf_id']
    profile._skip_optional_unique_validation = True
    profile.save()
    profile.associated_entity.set([record['associated_blf_id']])
    if record['aggregator_ids']:
        profile.associated_aggregator.set(record['aggregator_ids'])
    if record.get('password'):
        profile.user.set_password(record['password'])
        profile.user.save(update_fields=['password'])


def ExportGrowerTemplate(request):
    """Export blank create template for bulk grower upload."""
    if request.method == 'GET':
        return _write_grower_workbook(
            GROWER_BULK_CREATE_COLUMNS,
            rows=[GROWER_BULK_CREATE_SAMPLE_ROW],
            filename='grower.xlsx',
        )


def ExportGrowerUpdateTemplate(request):
    """Export update template populated with current growers."""
    if request.method == 'GET':
        rows = []
        queryset = GrowerProfile.cmobjects.select_related(
            'user', 'region', 'state', 'district', 'associated_blf'
        ).prefetch_related('associated_entity', 'associated_aggregator')
        for profile in queryset.iterator():
            selected_blf = profile.associated_blf or profile.associated_entity.first()
            rows.append({
                'username': profile.user.username if profile.user else '',
                'password': '',
                'name': profile.name or '',
                'grower_type': profile.grower_type or '',
                'region': profile.region.region_name if profile.region else '',
                'state': profile.state.name if profile.state else '',
                'district': profile.district.name if profile.district else '',
                'associated_entity': selected_blf.entity_unit if selected_blf else '',
                'associated_aggregator': '/'.join(item.name or '' for item in profile.associated_aggregator.all()),
                'gender': profile.gender or '',
                'date_of_birth': profile.date_of_birth or '',
                'age': profile.age or '',
                'mobile_number': profile.mobile_number or '',
                'village_or_town': profile.village_or_town or '',
                'address': profile.address or '',
                'tea_board_id': profile.tea_board_id or '',
                'land_document_no': profile.land_document_no or '',
                'lease_agreement_no': profile.lease_agreement_no or '',
                'gaon_bura_certificate_no': profile.gaon_bura_certificate_no or '',
                'enjoyment_certificate_no': profile.enjoyment_certificate_no or '',
                'total_male_worker': profile.total_male_worker or '',
                'total_female_worker': profile.total_female_worker or '',
                'estimated_production_of_green_tea': profile.estimated_production_of_green_tea or '',
                'estimated_production_of_made_tea': profile.estimated_production_of_made_tea or '',
                'production_area': profile.production_area or '',
            })
        return _write_grower_workbook(
            GROWER_BULK_UPDATE_COLUMNS,
            rows=rows,
            filename='grower_bulk_update_template.xlsx',
        )
    





@permission_required_admin
def BulkEnrollmentGrower(request):
    "Bulk create and update grower data with explicit review steps."
    context = {
        'duplicate_rows': [],
        'invalid_rows': [],
        'invalid_update_rows': [],
        'pending_token': '',
    }
    if request.method == 'POST':
        operation = request.POST.get('operation', 'create_upload')
        if operation == 'confirm_create':
            token = request.POST.get('pending_token', '')
            approved_rows = {int(value) for value in request.POST.getlist('approved_rows') if value.isdigit()}
            pending_rows = _load_pending_grower_rows(token) if token else []
            created_count = 0
            with transaction.atomic():
                for record in pending_rows:
                    if not record.get('duplicates') or record['row_index'] in approved_rows:
                        _create_bulk_grower(record['record'], request.user)
                        created_count += 1
            _delete_pending_grower_rows(token)
            messages.success(request, f'Grower bulk upload completed. Created: {created_count}.')
            return redirect('bulk_import_grower')

        uploaded_file = request.FILES.get('file')
        if not uploaded_file:
            messages.error(request, 'Please select a grower Excel file.')
            return CommonMixin.render(request, 'master/export_grower.html', context)
        if not uploaded_file.name.lower().endswith(('.xlsx', '.xls')):
            messages.error(request, 'Please upload a valid Excel file.')
            return CommonMixin.render(request, 'master/export_grower.html', context)

        try:
            dataframe = pd.read_excel(uploaded_file, dtype=str).fillna('')
            refs = _grower_bulk_reference_data(dataframe)

            if operation == 'update_upload':
                missing_columns = set(GROWER_BULK_UPDATE_COLUMNS) - set(dataframe.columns)
                if missing_columns:
                    messages.error(request, f"Update template is missing columns: {', '.join(sorted(missing_columns))}.")
                    return CommonMixin.render(request, 'master/export_grower.html', context)
                updated_count = 0
                invalid_rows = []
                seen_identifiers = {}
                with transaction.atomic():
                    for offset, row in dataframe.iterrows():
                        row_number = offset + 2
                        unique_grower_id = _clean_bulk_value(row.get('username'))
                        if not unique_grower_id:
                            invalid_rows.append({'row_number': row_number, 'unique_grower_id': '', 'reason': 'Unique Grower ID is required.'})
                            continue
                        profile = refs.get('grower_profiles_by_username', {}).get(_bulk_normalise(unique_grower_id))
                        if not profile:
                            invalid_rows.append({'row_number': row_number, 'unique_grower_id': unique_grower_id, 'reason': 'Grower ID does not exist.'})
                            continue
                        record, errors = _validate_grower_bulk_row(row, row_number, refs, update_profile=profile)
                        if errors:
                            invalid_rows.extend({
                                'row_number': row_number,
                                'unique_grower_id': unique_grower_id,
                                'reason': error.split(': ', 1)[-1],
                            } for error in errors)
                            continue
                        duplicate_identifier_errors = _validate_grower_identifier_unique_in_file(
                            record,
                            row_number,
                            seen_identifiers,
                            update_profile=profile,
                        )
                        if duplicate_identifier_errors:
                            invalid_rows.extend({
                                'row_number': row_number,
                                'unique_grower_id': unique_grower_id,
                                'reason': error.split(': ', 1)[-1],
                            } for error in duplicate_identifier_errors)
                            continue
                        _update_bulk_grower(profile, record)
                        updated_count += 1
                context['invalid_update_rows'] = invalid_rows
                messages.success(request, f'Grower bulk update completed. Updated: {updated_count}. Skipped: {len(invalid_rows)}.')
                return CommonMixin.render(request, 'master/export_grower.html', context)

            missing_columns = set(GROWER_BULK_CREATE_COLUMNS) - set(dataframe.columns)
            if missing_columns:
                messages.error(request, f"Create template is missing columns: {', '.join(sorted(missing_columns))}.")
                return CommonMixin.render(request, 'master/export_grower.html', context)

            pending_rows = []
            invalid_rows = []
            duplicate_rows = []
            seen_usernames = set()
            seen_identifiers = {}
            for offset, row in dataframe.iterrows():
                row_number = offset + 2
                record, errors = _validate_grower_bulk_row(
                    row,
                    row_number,
                    refs,
                    serial_number=offset + 1,
                    reserved_usernames=seen_usernames,
                )
                if errors:
                    invalid_rows.extend({'row_number': row_number, 'reason': error.split(': ', 1)[-1]} for error in errors)
                    continue
                username_key = _bulk_normalise(record['username'])
                if username_key in seen_usernames:
                    invalid_rows.append({'row_number': row_number, 'reason': 'Username is duplicated in the uploaded file.'})
                    continue
                if username_key:
                    seen_usernames.add(username_key)
                duplicate_identifier_errors = _validate_grower_identifier_unique_in_file(
                    record,
                    row_number,
                    seen_identifiers,
                )
                if duplicate_identifier_errors:
                    invalid_rows.extend({'row_number': row_number, 'reason': error.split(': ', 1)[-1]} for error in duplicate_identifier_errors)
                    continue
                duplicates = _grower_duplicate_candidates(record['name'], refs=refs)
                pending_row = {
                    'row_index': len(pending_rows),
                    'row_number': row_number,
                    'record': record,
                    'duplicates': duplicates,
                }
                pending_rows.append(pending_row)
                if duplicates:
                    duplicate_rows.append(pending_row)

            context['invalid_rows'] = invalid_rows
            if duplicate_rows:
                context['duplicate_rows'] = duplicate_rows
                context['pending_token'] = _save_pending_grower_rows(pending_rows)
                messages.warning(request, 'Potential duplicate grower names were found. Review them before insertion.')
            else:
                with transaction.atomic():
                    for pending_row in pending_rows:
                        _create_bulk_grower(pending_row['record'], request.user)
                messages.success(request, f'Grower bulk upload completed. Created: {len(pending_rows)}. Rejected: {len(invalid_rows)}.')
        except Exception as error:
            messages.error(request, f'Grower import failed: {error}')

    return CommonMixin.render(request, 'master/export_grower.html', context)



@permission_required_admin
def ExportAggregatorTemplate(request):
    """Export or download template for Aggregator bulk upload @vivek"""

    if request.method == 'GET':
        # Get selected option from form
    
        aggregator_resource = AggregatorProfileResource()
        # user_resource=user_resource.UserDetails()
        dataset = aggregator_resource.export()
     
        
        response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="aggregator.xls"'
        return response   

from django.db import transaction
from django.db.models import Q 

@permission_required_admin
def BulkEnrollmentAggregator(request):
    "Bulk import aggregator @vivek"
    if request.method == 'POST':
        file=request.FILES['file']
        df = pd.read_excel(file)
        columns_in_file = list(df.columns)
        required_columns = ['username', 'password', 'name', 'region', 'state', 'district', 'associated_entity', 'mobile_number']
        # Check if the uploaded file has all the required columns and no extra columns
        if set(columns_in_file) != set(required_columns):
            messages.error(request, 'Uploaded file should contain exactly the required columns of aggregator.')
            return CommonMixin.render(request, 'master/export_aggregator.html', {})
        path = 'media/excel/' + file.name
        if not os.path.exists('media/excel'):
            os.makedirs('media/excel')
        with open(path, 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)
        df = pd.read_excel(path)
        if df.empty == True:
            messages.error(request,'Empty excel file')
        df=df.replace({np.nan: None})
        successful_upload=0
        try:
            for index, row in df.iterrows(): 
                with transaction.atomic():   
                    # try:     
                        if row['username'] is None:
                             messages.error(request,'Username is not be blank ,Please enter Username in excel')
                        elif row['password'] is None:
                             messages.error(request,'Passwordd is not be blank,Please enter Password in excel')
                        elif User.objects.filter(username=row['username']).exists():
                            messages.error( request, 'Username'+ " : " + str(row['username']) + ' already exists in Aggregator List',\
                                             )
                        elif not Region.objects.filter(region_id=row['region']).exists() :  
                            messages.error(request,f"Entered region id for username {row['username']} is not exist,refer master list")  

                        elif not State.objects.filter(state_id=row['state']).exists():
                            
                            messages.error(request,f"Entered state id for username {row['username']} is not exist,refer master list")             
                        elif not District.objects.filter(district_id=row['district']).exists():
                            
                            messages.error(request,f"Entered district id for username {row['username']} is not exist,refer master list")            
                        
                        #         # if region:
                        #         #     obj2.region=region 
                        #     except  Region.DoesNotExist:
                        #             messages.error(request,f"Entered region id for username {row['username']} is not exist,refer master list")  
                        # elif row['state']:
                        #     try :
                        #         state=State.objects.get(state_id=row['state'])
                        #         # if state:
                        #         #       obj2.state=state
                        #     except  State.DoesNotExist:
                        #             messages.error(request,f"Entered state id for username {row['username']} is not exist, refer master list")
                        # elif row['district']:
                        #     try :
                        #         district=District.objects.get(district_id=row['district'])
                        #         # if district :
                        #         #     obj2.district=district
                        #     except  District.DoesNotExist:
                        #              messages.error(request,f"Entered district id for username {row['username']} is not exist,refer master list")  
                       
                        else:
                        
                            try:
                                # if str(row['password']) is not None:
                                password=str(row['password'])
                                # else:
                                #     password="123"    
                                obj = User.objects.create_user(username=row['username'],password= password)

                                obj2=AggregatorProfile(user=obj)
                                obj2.save()


                                # obj2.profile_type=ProfileType.objects.get(name='aggregator')
                                if row['name']:
                                    obj2.name=row['name']
                                if row['mobile_number'] :   
                                    obj2.mobile_number=int(row['mobile_number'])
                                obj2.profile_type=ProfileType.objects.get(name="aggregator")#insert profile type
                                obj5=Profile(user=obj, user_type_id=obj2.profile_type.id)
                                obj5.save()
                                if row['region']:
                                    # try :
                                    region=Region.objects.filter(region_id=row['region']).first()
                                    if region:
                                        obj2.region=region 
                                    # except  Region.DoesNotExist:
                                    #         messages.error(request,f"Entered region id for username {row['username']} is not exist,refer master list")  
                                if row['state']:
                                    # try :
                                    state=State.objects.filter(state_id=row['state']).first()
                                    if state:
                                         obj2.state=state
                                    # except  State.DoesNotExist:
                                    #         messages.error(request,f"Entered state id for username {row['username']} is not exist, refer master list")
                                if row['district']:
                                    # try :
                                    district=District.objects.filter(district_id=row['district']).first()
                                    if district :
                                        obj2.district=district
                                    # except  District.DoesNotExist:
                                    #          messages.error(request,f"Entered district id for username {row['username']} is not exist,refer master list")    
                                if row['associated_entity']:
                                    if isinstance(row['associated_entity'], str):
                                        associated_entities_list = row['associated_entity'].split(',')
                                    else:
                                        associated_entities_list = str(row['associated_entity']).split(',')
                                    for username in associated_entities_list:
                                        username = username.strip() 
                                        try :
                                            associated_entity=BlfProfile.objects.filter(user__username=username).first()
                                            if associated_entity: 
                                                obj2.associated_entity.add(associated_entity)
                                        except  BlfProfile.DoesNotExist:
                                            messages.error(request,"")  
                                # try :
                                #     # associated_entity=BlfProfile.objects.get(user__username=row['associated_entity']) 

                                #     # associated_entity=BlfProfile.objects.get(id=row['associated_entity'])
                                #     # if type(row['associated_entity']) == int:
                                        
                                #     #     associated_entity=BlfProfile.objects.get(Q(user__username=row['associated_entity']) | \
                                #     #                                          Q(id=row['associated_entity']))
                                #     # else:
                                #     associated_entity=BlfProfile.objects.filter(user__username=row['associated_entity']).first()
                                #     if associated_entity: 
                                #         obj2.associated_entity.add(associated_entity)
                                # except  BlfProfile.DoesNotExist:
                                #         messages.error(request,"")              
                            

                                obj2.save()
                                successful_upload +=1
                                # messages.success(request, str(row['username']) + ' Data uploaded successfully in aggregator list')
                            except  User.DoesNotExist:
                                    # messages.error(request,"something went wrong")
                                    pass
                    # except  KeyError:
                    #         messages.error(request,"something went wrong") 
            if successful_upload > 0  :    
                messages.success(request, "Total " +str(successful_upload) + ' data uploaded successfully in aggregator list')           
        except  KeyError:
                messages.error(request,"something went wrong")    
        except Exception as e:
            messages.error(request, f"Something went wrong")              
    context={}

    return CommonMixin.render(request, 'master/export_aggregator.html',context)


@permission_required_admin
def ViewMasterData(request):
    url = 'grower'
    if request.method== 'GET':

        type=request.GET.get('type')
        print(type)
  
        if type=='region':
            # master_list=Region.objects.all()
            master_list=Region.objects.filter(is_deleted=False).order_by('region_name')
            # state_list=Region.objects.filter(id=id).values('state__name')
            # state_list=Region.objects.values('state__name')

            print(master_list)
            
        elif type=='state':
            master_list=State.objects.filter(is_deleted=False).order_by('name') 
            # master_list=State.objects.all()
        elif type=='district':
            # master_list=District.objects.all()  
            master_list=District.objects.filter(is_deleted=False).order_by('name') 
        else:
            master_list= "" 
        # state_list=""
        context={'master_list':master_list,url:'url'}    
        return CommonMixin.render(request, 'master/master_list.html',context)
@login_required
def state_view(request):
        # if request.method=='GET':
     
    id=request.GET.get('id')  
    print(id)
    result = Region.objects.filter(id=id).values('state__name')
    print(result)


    context={
		    	'state_list' :result,
    
		    }

    return CommonMixin.render(request, 'master/state_view.html', context)	
	    



####################################################################
    #############  Warehouse Views  ###############
#####################################################################


# Create your views here.
class WarehouseListView(LoginRequiredMixin, CommonMixin, ListView):
    """
    Warehouse List View
    """
    model = WarehouseManagement
    context_object_name = 'warehouse_list'
    template_name = 'master/warehouse_list.html'
    paginate_by = 5

    def get(self, request, *args, **kwargs):
        try:
            if self.request.user.is_superuser:
                messages.error(self.request, 'You have no permission to access the requested resource!')
                return redirect(reverse('index'))
        except AttributeError as error:
            messages.error(self.request, 'You have no permission to access the requested resource!')
            return redirect(reverse('index'))

        return super().get(request, *args, **kwargs)


    def get_queryset(self, *args, **kwargs):
        qs = super().get_queryset(*args, **kwargs)
        name=self.request.GET.get('name')
        if name:
            return qs.filter(name__icontains=name)
        return WarehouseManagement.objects.filter(created_by_id=self.request.user.id).order_by('-id')


    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['type_list'] = WarehouseType.objects.all().order_by('id')
        
        return context
    


class WarehouseCreateView(LoginRequiredMixin, CreateView, CommonMixin):
    """
    Stock Group Create View
    """
    form_class = WarehouseManagementForm
    template_name = 'master/warehouse_create.html'

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)


    def get_success_url(self, **kwargs):
        messages.success(self.request, 'Warehouse Created Successfully')
        return reverse('warehouse_list')

    def form_valid(self, form):
    
        context = self.get_context_data()

        with transaction.atomic():
            form.instance.created_by_id = self.request.user.id
            self.object = form.save()

        return super(WarehouseCreateView, self).form_valid(form)




    def form_invalid(self, form):
        error_message = 'Error saving the Form, check fields below.'
        messages.error(self.request, error_message)
        return super().form_invalid(form)
    




from django.shortcuts import get_object_or_404

class WarehouseUpdateView(LoginRequiredMixin, CommonMixin, UpdateView):
	"""
	Chemical Data Create and Update View @vivek
	"""
	model = WarehouseManagement
	form_class = WarehouseManagementForm
	template_name = 'master/warehouse_create.html'

	def get(self, request, *args, **kwargs):
	# checking if the user is customer
		# try:
		# 	if self.request.user.is_superuser:
		# 		messages.error(self.request, 'You have no permission to access the requested resource!')
		# 		return redirect(reverse('index'))
		# except AttributeError as error:
		# 	messages.error(self.request, 'You have no permission to access the requested resource!')
		# 	return redirect(reverse('index'))

		return super().get(request, *args, **kwargs)

	def get_success_url(self, **kwargs):
		messages.success(self.request, 'Warehouse Updated Successfully')
		return reverse('warehouse_list')


	def get_object(self,queryset=None):
		warehouse_details = get_object_or_404(WarehouseManagement,pk=self.kwargs['id'])
		return warehouse_details

	def get_context_data(self, **kwargs):
		context = super(WarehouseUpdateView, self).get_context_data(**kwargs)

		context['warehouse_details'] = self.get_object()
		return context
     

	def form_valid(self, form):
		
		self.id = self.kwargs['id']
		context = self.get_context_data()


		with transaction.atomic():
               
			self.object = form.save()


		return super(WarehouseUpdateView, self).form_valid(form)
	
@login_required
def warehouse_delete(request, id):

	# try:
	# 	if not request.user.is_superuser:
	# 		messages.error(request, 'You have no permission to access the requested resource!')
	# 		return redirect(reverse('index'))
	# except AttributeError as error:
	# 	messages.error(request, 'You have no permission to access the requested resource!')
	# 	return redirect(reverse('index'))



	warehouse = WarehouseManagement.objects.filter(id=id).first()
	warehouse.delete()
	# user_type = 
	messages.success(
		request, 'Warehouse Deleted Successfully')
	
	return redirect(reverse('warehouse_list', ))    



@login_required
def warehouse_search(request):
	if request.method == "POST":
		name= request.POST.get('name')


		edit_url = 'warehouse_edit'



		filter = {}
		
		if name:
			filter["name__icontains"] = name


		result = WarehouseManagement.objects.filter(**filter)
		print(result)

		print(filter)

		context={
			'warehouse_list' : result,
			'edit_url' : edit_url,
			'name' : name,
		}

		return CommonMixin.render(request, 'master/warehouse_list.html', context)


@login_required
def warehouse_view(request,id):
		warehouse_details = WarehouseManagement.objects.filter(pk=id).first()
		context={
			'warehouse_details' : warehouse_details,
		}
		return CommonMixin.render(request, 'master/warehouse_view.html', context)	



# ERROR 500 and 400
def my_custom_permission_denied_view(request, *args, **kwargs):
    """
     404 Page  View
    """
    context = {

    }
    return CommonMixin.render(request,'404.html',context)


def error_500(request):
    return render(request, '500.html')





def account_details(request):

    user_details = Profile.objects.filter(user_id=request.user).first()


    context ={
        'user_details': user_details,
    }

    return  CommonMixin.render(request, 'account_details.html', context )






##############  TYPING SPEED ##############

def typing_speed_view(request):
    # from .type_speed import Game

    result =  "Game().run()"
    return  result



def privacy(request):
    """ Privacy Policy page """

    privacy_details = PrivacyPolicy.objects.filter(sample__exact='PRIVACY-POLICY').first()

    context = {
        'privacy_details': privacy_details,
    }
    return render(request, 'privacy.html', context)





from knox.auth import TokenAuthentication
from rest_framework import permissions
from knox.models import AuthToken
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException



from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from rest_framework.exceptions import ValidationError
from django.core.paginator import Paginator



class AndroidVersionAPIView(APIView):
    # authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def get(self, request, *args, **kwargs):
        try:
            queryset = AndroidVersion.objects.all().order_by('-id')

            page_size = int(request.query_params.get('page_size', 10))
            paginator = Paginator(queryset, page_size)
            page_number = request.query_params.get('page', 1)
            page = paginator.get_page(page_number)
            serializer = AndroidVersionSerializer(page, many=True)

            return Response({
                'count': paginator.count,
                'next': page.next_page_number() if page.has_next() else None,
                'previous': page.previous_page_number() if page.has_previous() else None,
                'results': serializer.data,
            })

        except Exception as e:
            raise ValidationError({'status': '400 Bad Request', 'request_status': 0, 'msg': str(e)})

from django.apps import apps
class ModelPayloadAPIView(APIView):
    """
        API endpoint to generate JSON payload for a given Django model.
    """
    def get(self, request):
        model_name= self.request.query_params.get('model_name', "Labour")
        if not model_name:
            return Response(
                {"error": "Please provide a model name"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        app_labels = ['master', 'user_profile', 'vehicle_management', 'invoicing',
                      'leaf_receipt', 'lot_batch_details', 'chemical_data', 'gardens_managment']
        model_class = None
        for label in app_labels:
            try:
                model_class = apps.get_model(label, model_name)
                if model_class:
                    break
            except LookupError:
                continue
        if not model_class:
            return Response(
                {"error": f"Model '{model_name}' not found in any of {app_labels}."},
                status=status.HTTP_404_NOT_FOUND,
            )
        payload = model_to_json_payload(model_class)
        return Response(payload, status=status.HTTP_200_OK)
