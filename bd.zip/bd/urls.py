from django.urls import path
from bd import views

urlpatterns = [
    path('bd-department-master/', views.BDDepartmentMasterAPIView.as_view()),
    path('bd-department-master-import/', views.BDDepartmentMasterImportAPIView.as_view()),
    path('bd-master/', views.BDMasterAPIView.as_view()),
]
