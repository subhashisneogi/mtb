import colorama
from rest_framework import serializers
from django.db.models import F, Sum
from datetime import date
from administrations.utils import get_dependent_values_details
from .models import *
from datetime import timedelta
from colorama import Fore, Back, Style
from procurement.helper import get_details_from_instance, process_attachments
from administrations.serializers import CompanySerializer, JVMASTERSerializer 
from django.db import transaction
from procurement.serializers import CommonFilterListSerializer 

class BDDepartmentMasterSerializer(serializers.ModelSerializer):
    sector_details = serializers.SerializerMethodField()
    state_details = serializers.SerializerMethodField()
    city_details = serializers.SerializerMethodField()

    def get_state_details(self, instance):
        return get_details_from_instance(instance.state, type="dict")
    def get_city_details(self, instance):
        return get_details_from_instance(instance.city)
    def get_sector_details(self, instance):
        return get_details_from_instance(instance.tender_sector)

    class Meta:
        model = BDDepartmentMaster
        fields = '__all__'
        CommonFilterListSerializer


class BDMasterConcerenedDetailsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = BDMasterConcerenedDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class BDMasterDepartmentProgressSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = BDMasterDepartmentProgress
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class BDMasterCompetitorsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = BDMasterCompetitors
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class BDMasterVisitDetailsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = BDMasterVisitDetails
        fields = '__all__'
        read_only_fields = ['id']
        list_serializer_class = CommonFilterListSerializer

class BDMasterSerializer(serializers.ModelSerializer):
    sector_details = serializers.SerializerMethodField()
    state_details = serializers.SerializerMethodField()
    city_details = serializers.SerializerMethodField()

    def get_state_details(self, instance):
        return get_details_from_instance(instance.state, type="dict")
    def get_city_details(self, instance):
        return get_details_from_instance(instance.city)
    def get_sector_details(self, instance):
        return get_details_from_instance(instance.tender_sector)
    class Meta:
        model = BDMaster
        fields = '__all__'
        read_only_fields = ['id']
