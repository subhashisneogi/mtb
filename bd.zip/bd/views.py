import os
from django.shortcuts import render
import pandas as pd
from rest_framework.views import APIView
from time import gmtime, strftime, localtime
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from django.core.paginator import Paginator
from knox.auth import TokenAuthentication
from django.db import transaction
from rest_framework import status
from rest_framework.exceptions import APIException
# from datetime import date
from datetime import datetime, timedelta, date
from django.db.models import Prefetch
from django.db.models import IntegerField, Q, Sum, Value, Count, CharField, Exists, BooleanField
from django.db.models.functions import Cast, Coalesce
from django.db.models.expressions import Subquery, OuterRef, Case, When
from procurement.helper import GroupConcat, custom_filters
from administrations.utils import schedule_generic_mail , trigger_notifications
from user_permissions.models import UserWiseModulePermissions
from django.db import transaction, IntegrityError
from django.db.models import F, Value
from django.db.models.functions import Trim, Replace
from django.db.models.functions import Concat
from . serializers import * 
import re 
import numpy as np

class BDDepartmentMasterAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = {}
        search = custom_filters(self.request, search, [])
        if id:
            list_data = BDDepartmentMaster.cmobjects.filter(id=id).first()
            serializer = BDDepartmentMasterSerializer(list_data)
            return Response(serializer.data)
        list_data = BDDepartmentMaster.cmobjects.filter(*search).order_by(*str(order_by).split(",")).distinct()
        if all == 'true':
            serializer = BDDepartmentMasterSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BDDepartmentMasterSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = BDDepartmentMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                obj = serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        request.data['updated_by'] = request.user.id
        details = BDDepartmentMaster.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if BDDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = BDDepartmentMaster.cmobjects.filter(pk=id).first()
                    serializer = BDDepartmentMasterSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if BDDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = BDDepartmentMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': BDDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})

class BDDepartmentMasterImportAPIView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                count_data = {
                    'items_created': 0,
                    'errors': 0,
                    'sheets_processed': [],
                    'sector_data_count': {}
                }
                errors = []
                organization_id = request.query_params.get('organization_id')
                if not organization_id:
                    raise APIException("Organization ID is required")

                file_name = request.data.get('file_name')
                field_map = request.data.get('field_map')

                if not file_name or not field_map:
                    raise APIException({'request_status': 0, 'msg': "Missing file_name or field_map"})

                file_path = os.path.join('media', 'excel', file_name)
                if not os.path.exists(file_path):
                    raise APIException({'request_status': 0, 'msg': f"File '{file_name}' not found on server"})

                try:
                    excel_file = pd.ExcelFile(file_path)
                    all_sheets = {}
                    for sheet_name in excel_file.sheet_names:
                        sheet_df = pd.read_excel(excel_file, sheet_name=sheet_name)
                        # Clean data
                        sheet_df = sheet_df.fillna("").applymap(lambda x: x.strip() if isinstance(x, str) else x)
                        sheet_df = sheet_df.fillna(np.nan).replace([np.nan], [None])
                        all_sheets[sheet_name] = sheet_df
                except Exception as e:
                    raise APIException({'request_status': 0, 'msg': f"Error reading and cleaning Excel: {str(e)}"})

                # Load reference data
                sector_list = pd.DataFrame(TenderSector.cmobjects.filter(organization_id=organization_id).values('id', 'name'))
                state_list = pd.DataFrame(State.objects.all().values('state_id', 'name'))
                city_list = pd.DataFrame(City.objects.all().values('city_id', 'name'))

                def process_str(x):
                    if isinstance(x, str):
                        return x.strip()
                    return x

                def check_sector(name):
                    if pd.isna(name) or not name:
                        return None
                    name_clean = str(name).strip().lower()
                    match = sector_list[sector_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['id'] if not match.empty else None

                def check_state(name):
                    if pd.isna(name) or not name:
                        return None
                    name_clean = str(name).strip().lower()
                    match = state_list[state_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['state_id'] if not match.empty else None

                def check_city(name):
                    if pd.isna(name) or not name:
                        return None
                    name_clean = str(name).strip().lower()
                    match = city_list[city_list['name'].str.strip().str.lower() == name_clean]
                    return match.iloc[0]['city_id'] if not match.empty else None

                for sheet_name, sheet_df in all_sheets.items():
                    if sheet_df.empty:
                        continue
                    
                    sheet_df.columns = [str(col).strip() for col in sheet_df.columns]
                    count_data['sheets_processed'].append(sheet_name)

                    for index, row in sheet_df.iterrows():
                        row_index = index + 2 
                        row_data = {col: row[col] for col in sheet_df.columns}

                        name_column = field_map.get('name')
                        if not name_column or name_column not in row_data:
                            errors.append(f"Department column missing for sheet {sheet_name}")
                            count_data['errors'] += 1
                            continue

                        name_raw = str(row_data.get(name_column, "")).strip()
                        if not name_raw:
                            errors.append(f"Department row {index} in {sheet_name}")
                            count_data['errors'] += 1
                            continue
                        name_val = name_raw.lower()

                        # Get other mapped fields
                        state_val = str(row_data.get(field_map.get('state'), "")).strip()
                        city_val = str(row_data.get(field_map.get('city'), "")).strip().lower()
                        sector_val = str(row_data.get(field_map.get('sector'))).strip().lower()
                        # Lookup IDs
                        sector_id = check_sector(sector_val)
                        state_id = check_state(state_val)
                        city_id = check_city(city_val)

                        if not sector_id:
                            errors.append(f"Row {row_index}: Sector '{sector_val}' not found in {sheet_name}")
                            count_data['errors'] += 1
                            continue

                        if not state_id:
                            errors.append(f"Row {row_index}: State '{state_val}' not found in {sheet_name}")
                            count_data['errors'] += 1
                            continue

                        if not city_id:
                            errors.append(f"Row {row_index}: City not found for '{city_val}' in {sheet_name}")
                            count_data['errors'] += 1
                            continue

                        # Prepare data for BDDepartmentMaster
                        data = {
                            'organization_id': organization_id,
                            'name': str(row_data.get(name_column, "")).strip() if name_column else "",
                            'tender_sector_id': sector_id,
                            'state_id': state_id,
                            'city_id': city_id,
                            'address': str(row_data.get(field_map.get('address'), "")).strip(),
                            'created_by_id': request.user.id,
                        }
                        created = BDDepartmentMaster.objects.create(**data)
                        if created:
                            count_data['items_created'] += 1
 
                return Response({
                    'request_status': 1,
                    'msg': 'Department master data imported successfully.',
                    'data': count_data,
                    'errors': errors,
                })
        except Exception as e:
            print(f"Import error: {e}")
            raise APIException({'request_status': 0, 'msg': str(e)})
        
class BDMasterAPIView(APIView):
    def get(self, request):
        id = self.request.query_params.get('id', None)
        all = self.request.query_params.get('all', None)
        order_by = self.request.query_params.get('order_by', '-id')
        search = {}
        search = custom_filters(self.request, search, [])
        if id:
            list_data = BDDepartmentMaster.cmobjects.filter(id=id).first()
            serializer = BDDepartmentMasterSerializer(list_data)
            return Response(serializer.data)
        list_data = BDDepartmentMaster.cmobjects.filter(*search).order_by(*str(order_by).split(",")).distinct()
        if all == 'true':
            serializer = BDDepartmentMasterSerializer(list_data, many=True)
            return Response({'results': serializer.data})
        page_size = int(request.query_params.get('page_size', settings.MIN_PAGE_SIZE))
        paginator = Paginator(list_data, page_size)
        page_number = self.request.query_params.get('page', 1)
        page = paginator.get_page(page_number)
        serializer = BDDepartmentMasterSerializer(page, many=True)
        return Response({
            'count': paginator.count,
            'next': page.next_page_number() if page.has_next() else None,
            'previous': page.previous_page_number() if page.has_previous() else None,
            'results': serializer.data,
        })
    def post(self, request):
        request.data['created_by'] = request.user.id
        serializer = BDDepartmentMasterSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            try:
                obj = serializer.save()
            except Exception as e:
                error_message = str(e.args[0]) if e.args else str(e)
                raise APIException({'request_status': 0, 'msg': error_message})
            return Response(
                {'results': {
                    'Data': serializer.data,
                },
                    'msg': 'Successfully created',
                    'status': status.HTTP_201_CREATED,
                    "request_status": 1})
        raise APIException({'request_status': 0, 'msg': serializer.errors})
    def put(self, request):
        method = self.request.query_params.get('method', None)
        organization_id = self.request.query_params.get('organization', None)
        id = self.request.query_params.get('id', None)
        request.data['updated_by'] = request.user.id
        details = BDDepartmentMaster.cmobjects.filter(pk=id).first()
        with transaction.atomic():
            if method.lower() == 'edit':
                if BDDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = BDDepartmentMaster.cmobjects.filter(pk=id).first()
                    serializer = BDDepartmentMasterSerializer(details, data=request.data,
                                                          context={'request': request})
                    if serializer.is_valid():
                        try:
                            serializer.save()
                        except Exception as e:
                            error_message = str(e.args[0]) if e.args else str(e)
                            raise APIException({'request_status': 0, 'msg': error_message})

                        return Response({'results': {
                            'Data': serializer.data,
                        },
                            'msg': "Successfully updated",
                            'status': status.HTTP_202_ACCEPTED,
                            "request_status": 1})
                    raise APIException({'request_status': 0, 'msg': serializer.errors})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
                
            elif method.lower() == 'delete':
                if BDDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).exists():
                    details = BDDepartmentMaster.cmobjects.get(pk=id, organization_id=organization_id)
                    details.is_deleted = True
                    details.save()
                    return Response({'results': {
                        'details': BDDepartmentMaster.cmobjects.filter(pk=id, organization_id=organization_id).values(),
                    },
                        'msg': 'Successfully deleted',
                        "request_status": 1})
                else:
                    raise APIException({'request_status': 1, 'msg': "Something went wrong. If the problem persists, please contact support."})
