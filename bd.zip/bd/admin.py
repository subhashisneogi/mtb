from django.contrib import admin
from misc.admin import ModelAdmin,StackedInline
from django.utils.safestring import mark_safe
from .models import *

@admin.register(BDDepartmentMaster)
class BDDepartmentMasterAdmin(ModelAdmin):
    list_display = ['id', 'name', 'tender_sector', 'state', 'city', 'address']

@admin.register(BDMaster)
class BDMasterAdmin(ModelAdmin):
    list_display = ['id', 'name', 'tender_sector', 'state', 'city', 'sinpl_progress_status', 'next_action_plan']

@admin.register(BDMasterConcerenedDetails)
class BDMasterConcerenedDetailsAdmin(ModelAdmin):
    list_display = ['id', 'bd_master', 'name', 'designation', 'contact_no', 'email']

@admin.register(BDMasterDepartmentProgress)
class BDMasterDepartmentProgressAdmin(ModelAdmin):
    list_display = ['id', 'bd_master', 'type', 'name',]

@admin.register(BDMasterCompetitors)
class BDMasterCompetitorsAdmin(ModelAdmin):
    list_display = ['id', 'bd_master', 'name',]

@admin.register(BDMasterVisitDetails)
class BDMasterVisitDetailsAdmin(ModelAdmin):
    list_display = ['id', 'bd_master', 'name',]