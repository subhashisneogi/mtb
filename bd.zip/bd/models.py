from django.core.exceptions import ValidationError, NON_FIELD_ERRORS
from django.conf import settings
from django.db import models
from administrations.models import BaseAbstractStructure, Organization, PmsUser
from tender.models import TenderSector
from administrations.models import State,City

class BDDepartmentMaster(BaseAbstractStructure):
    """ BD Module Department Master Model"""
    organization = models.ForeignKey(Organization, related_name='bd_department_master_organization',on_delete=models.CASCADE)
    name = models.CharField(max_length=200,null=True, blank=True)
    tender_sector = models.ForeignKey(TenderSector, related_name="bd_department_master_tender_sector", on_delete=models.CASCADE, null=True, blank=True)
    state = models.ForeignKey(State, related_name="bd_department_master_state", on_delete=models.CASCADE, null=True, blank=True)
    city = models.ForeignKey(City, related_name="bd_department_master_city", on_delete=models.CASCADE, null=True, blank=True)
    address = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        unique_together = ('organization','name','tender_sector','state','city','address')
        db_table = "bd_department_master"
class BDMaster(BaseAbstractStructure):
    """ BD Master Model """
    organization = models.ForeignKey(Organization, related_name='bd_master_organization',on_delete=models.CASCADE)
    name = models.CharField(max_length=200,null=True, blank=True)
    tender_sector = models.ForeignKey(TenderSector, related_name="bd_master_tender_sector", on_delete=models.CASCADE, null=True, blank=True)
    state = models.ForeignKey(State, related_name="bd_master_state", on_delete=models.CASCADE, null=True, blank=True)
    city = models.ForeignKey(City, related_name="bd_master_city", on_delete=models.CASCADE, null=True, blank=True)
    no_of_tenders_publisher_year = models.IntegerField(null=True, blank=True)
    sinpl_progress_status = models.TextField(null=True, blank=True)
    next_action_plan = models.TextField(null=True, blank=True)
    remarks =  models.TextField(null=True, blank=True)
    class Meta:
        db_table = "bd_master"

class BDMasterConcerenedDetails(BaseAbstractStructure):
    """  BD Concerened Details """
    organization = models.ForeignKey(Organization, related_name='bd_concerened_details_organization',on_delete=models.CASCADE)
    bd_master = models.ForeignKey(BDMaster, related_name='bd_master_concerened_details_bd_master',on_delete=models.CASCADE)
    name = models.CharField(max_length=255, null=True, blank=True)
    designation = models.CharField(max_length=255, null=True, blank=True)
    contact_no = models.CharField(max_length=255, null=True, blank=True)
    email = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "bd_master_concerened_details"

class BDMasterDepartmentProgress(BaseAbstractStructure):
    """  BD Concerened Details """
    organization = models.ForeignKey(Organization, related_name='bd_master_department_progress_organization',on_delete=models.CASCADE)
    bd_master = models.ForeignKey(BDMaster, related_name='bd_master_department_progress_bd_master',on_delete=models.CASCADE)
    type = models.CharField(max_length=255, null=True, blank=True)
    name = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "bd_master_department_progress"

class BDMasterCompetitors(BaseAbstractStructure):
    """  BD Concerened Details """
    organization = models.ForeignKey(Organization, related_name='bd_master_competitors_organization',on_delete=models.CASCADE)
    bd_master = models.ForeignKey(BDMaster, related_name='bd_master_competitors_bd_master',on_delete=models.CASCADE)
    name = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "bd_master_competitors"

class BDMasterVisitDetails(BaseAbstractStructure):
    """  BD Concerened Details """
    organization = models.ForeignKey(Organization, related_name='bd_master_visit_details_organization',on_delete=models.CASCADE)
    bd_master = models.ForeignKey(BDMaster, related_name='bd_master_visit_details_bd_master',on_delete=models.CASCADE)
    name = models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = "bd_master_visit_details"
 