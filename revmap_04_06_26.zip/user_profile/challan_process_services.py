from django.contrib.auth import get_user_model
from django.db import transaction
from rest_framework.exceptions import APIException
from decimal import Decimal, InvalidOperation

from leaf_receipt.models import LeafCollection, LeafManagement
from vehicle_management.models import VehicleManagement
from weighment_supply.models import WeighmentSupply

from .aggregator_api_models import CollectionFromGrower, PluckingData, SupplyManagement
from .blf_api_models import SupplierExit
from .models import AggregatorProfile, GrowerProfile

User = get_user_model()


def _decimal_or_zero(value):
    if value in (None, ""):
        return Decimal("0")
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return Decimal("0")


def _decimal_2(value):
    return _decimal_or_zero(value).quantize(Decimal("0.01"))


def _leaf_final_weight(total_gross_weight, tare_weight, deduction):
    total_gross_weight = _decimal_or_zero(total_gross_weight)
    tare_weight = _decimal_or_zero(tare_weight)
    deduction = _decimal_or_zero(deduction)
    net_weight = total_gross_weight - tare_weight
    return _decimal_2(net_weight - (net_weight * deduction / Decimal("100")))


def _validate_payment_record_rate(payment_record_option, rate):
    if str(payment_record_option or "").lower() == "yes" and rate in (None, ""):
        raise APIException({
            "request_status": 0,
            "msg": "Rate is required when Payment Record Option is Yes.",
        })
    return None if str(payment_record_option or "").lower() == "no" else rate


def _next_weighment_txn_id():
    last_txn = (
        WeighmentSupply.objects
        .select_for_update()
        .filter(weighment_txn_id__startswith="TXN")
        .order_by("-id")
        .first()
    )
    if not last_txn or not last_txn.weighment_txn_id:
        next_number = 1
    else:
        try:
            next_number = int(last_txn.weighment_txn_id.replace("TXN", "")) + 1
        except ValueError:
            next_number = last_txn.id + 1
    txn_id = f"TXN{next_number:09d}"
    while WeighmentSupply.objects.filter(weighment_txn_id=txn_id).exists():
        next_number += 1
        txn_id = f"TXN{next_number:09d}"
    return txn_id


def _supplier_profile_for_weighment(weighment):
    if str(weighment.supplier_type).lower() == "aggregator":
        return AggregatorProfile.cmobjects.filter(user_id=weighment.supplier_id).first()
    if str(weighment.supplier_type).lower() == "grower":
        return GrowerProfile.cmobjects.filter(user_id=weighment.supplier_id).first()
    return None


def _create_leaf_collection_for_challan_process(weighment, leaf_receipt, supplier_exit, request_user):
    supplier_profile = _supplier_profile_for_weighment(weighment)
    if not supplier_profile:
        return None
    collection_kwargs = {
        "leaf_receipt_id": leaf_receipt,
        "suppler_exit_id": supplier_exit,
        "weighment_supply_id": weighment,
        "supply_id": weighment.supply_challan,
        "supplier_id": weighment.supplier_id,
        "nt_wght": supplier_exit.net_supplied_qty,
        "collection_date": weighment.supply_challan.date_of_supply if weighment.supply_challan else weighment.supply_date,
        "supplier_type": weighment.supplier_type,
        "supply_date": weighment.supply_challan.date_of_supply if weighment.supply_challan else weighment.supply_date,
        "created_by_id": request_user.id,
    }
    if str(weighment.supplier_type).lower() == "aggregator":
        collection_kwargs["aggregator_id"] = supplier_profile.id
    elif str(weighment.supplier_type).lower() == "grower":
        collection_kwargs["grower_id"] = supplier_profile.id
        plucking_details = PluckingData.cmobjects.filter(grower_id=supplier_profile.id).first()
        if plucking_details:
            collection_kwargs["plucking_data_id"] = plucking_details.id
    return LeafCollection.objects.create(**collection_kwargs)


def _validate_weights(total_gross_weight, tare_weight, unloaded_vehicle_weight, deduction):
    total_gross_weight = _decimal_or_zero(total_gross_weight)
    tare_weight = _decimal_or_zero(tare_weight)
    unloaded_vehicle_weight = _decimal_or_zero(unloaded_vehicle_weight)
    if total_gross_weight < tare_weight:
        raise APIException({"request_status": 0, "msg": "Gross Weight must be greater than or equal to Tare Weight."})
    final_weight = _leaf_final_weight(total_gross_weight, tare_weight, deduction)
    if unloaded_vehicle_weight > total_gross_weight:
        raise APIException({
            "request_status": 0,
            "msg": "Unloaded Vehicle Weight cannot be greater than Final Weight (Kgs).",
        })


def _recalculate_supplier_exit(weighment, leaf_receipt, supplier_exit):
    total_gross_weight = _decimal_or_zero(weighment.total_gross_weight_kg)
    tare_weight = _decimal_or_zero(weighment.tare_weight_kg)
    unloaded_vehicle_weight = _decimal_or_zero(supplier_exit.unloaded_vehicle_weight)
    _validate_weights(total_gross_weight, tare_weight, unloaded_vehicle_weight, leaf_receipt.deduction)
    leaf_receipt.net_leaf_weight = float(_leaf_final_weight(total_gross_weight, tare_weight, leaf_receipt.deduction))
    supplier_exit.net_supplied_qty = leaf_receipt.net_leaf_weight


def _apply_challan_process_status(weighment, leaf_receipt, supplier_exit):
    acknowledge_status = str(leaf_receipt.acknowledge_status or "").lower()
    is_leaf_rejected = acknowledge_status == "rejected"
    is_received = acknowledge_status == "received"
    update_kwargs = {
        "is_processed": True,
        "is_supplier_exit_proceed": True,
        "is_leaf_rejected": is_leaf_rejected,
    }
    leaf_receipt.is_complete = is_received
    if weighment.supply_challan_id:
        SupplyManagement.cmobjects.filter(pk=weighment.supply_challan_id).update(is_weighment_proceed=True)
    if weighment.supply_challan and weighment.supply_challan.alloted_vehicle_id:
        vehicle_id = weighment.supply_challan.alloted_vehicle_id
        if is_leaf_rejected:
            VehicleManagement.cmobjects.filter(pk=vehicle_id).update(is_available=True)
        elif is_received:
            VehicleManagement.cmobjects.filter(pk=vehicle_id).update(is_available=False)
        CollectionFromGrower.objects.filter(vehicle_number_id=vehicle_id).update(is_complete=True)
        VehicleManagement.cmobjects.filter(pk=vehicle_id).update(is_available=True)
    WeighmentSupply.cmobjects.filter(pk=weighment.pk).update(**update_kwargs)
    weighment.is_processed = True
    weighment.is_supplier_exit_proceed = True
    weighment.is_leaf_rejected = is_leaf_rejected


def create_challan_process_records(data, request_user):
    supplier_id = data.get("supplier")
    if not supplier_id:
        raise APIException({"request_status": 0, "msg": "supplier is required"})
    supplier = User.objects.filter(pk=supplier_id).first()
    if not supplier:
        raise APIException({"request_status": 0, "msg": "Supplier does not exist"})

    total_gross_weight = _decimal_2(data.get("total_gross_weight_kg"))
    tare_weight = _decimal_2(data.get("tare_weight_kg"))
    unloaded_vehicle_weight = _decimal_2(data.get("unloaded_vehicle_weight"))
    deduction = _decimal_2(data.get("deduction"))
    payment_record_option = data.get("payment_record_option") or data.get("keep_payment_record")
    rate = _validate_payment_record_rate(payment_record_option, data.get("rate"))
    _validate_weights(total_gross_weight, tare_weight, unloaded_vehicle_weight, deduction)
    final_leaf_weight = _leaf_final_weight(total_gross_weight, tare_weight, deduction)

    with transaction.atomic():
        txn_id = _next_weighment_txn_id()
        weighment = WeighmentSupply.objects.create(
            supplier_id=supplier_id,
            supplier_type=data.get("supplier_type"),
            supply_date=data.get("supply_date"),
            total_gross_weight_kg=float(total_gross_weight),
            tare_weight_kg=float(tare_weight),
            mobile_number=data.get("mobile_number"),
            mode_of_supply=data.get("mode_of_supply") or "Motorised 3 / 4 wheelers vehicle",
            vehicle_no_id=data.get("vehicle_no") or data.get("vehicle_no_id") or None,
            supply_challan_id=data.get("supply_challan") or data.get("challan_id") or None,
            weighment_txn_id=txn_id,
            created_by=request_user,
        )
        leaf_receipt = LeafManagement.objects.create(
            weighment_txn=weighment,
            supply_date=data.get("supply_date"),
            deduction=float(deduction),
            final_leaf_count=float(_decimal_2(data.get("final_leaf_count"))),
            net_leaf_weight=float(final_leaf_weight),
            rate=str(_decimal_2(rate)) if rate not in (None, "") else None,
            quality_standard=data.get("quality_standard"),
            acknowledge_status=data.get("acknowledge_status"),
            payment_record_option=payment_record_option,
            created_by=request_user,
        )
        supplier_exit = SupplierExit.objects.create(
            weighment_txn=weighment,
            unloaded_vehicle_weight=float(unloaded_vehicle_weight),
            date_of_supply=data.get("supply_date"),
            is_released=data.get("is_released"),
            net_supplied_qty=float(final_leaf_weight),
            created_by=request_user,
        )
        _apply_challan_process_status(weighment, leaf_receipt, supplier_exit)
        leaf_receipt.save(update_fields=["is_complete", "updated_at"])
        leaf_collection = _create_leaf_collection_for_challan_process(weighment, leaf_receipt, supplier_exit, request_user)

    return {"weighment": weighment, "leaf_receipt": leaf_receipt, "supplier_exit": supplier_exit, "leaf_collection": leaf_collection}


def update_challan_process_records(weighment_id, data, request_user):
    weighment = WeighmentSupply.cmobjects.filter(pk=weighment_id).first()
    if not weighment:
        raise APIException({"request_status": 0, "msg": "Challan process record not found"})
    leaf_receipt = LeafManagement.cmobjects.filter(weighment_txn=weighment).order_by("-id").first()
    supplier_exit = SupplierExit.cmobjects.filter(weighment_txn=weighment).order_by("-id").first()
    if not leaf_receipt or not supplier_exit:
        raise APIException({"request_status": 0, "msg": "Linked leaf receipt or supplier exit record not found"})

    payment_record_option = data.get("payment_record_option", data.get("keep_payment_record", leaf_receipt.payment_record_option))
    rate = _validate_payment_record_rate(payment_record_option, data.get("rate", leaf_receipt.rate))
    with transaction.atomic():
        for field in ["supplier_type", "supplier", "supply_date", "total_gross_weight_kg", "tare_weight_kg", "mobile_number", "mode_of_supply"]:
            if field in data:
                setattr(weighment, f"{field}_id" if field == "supplier" else field, data.get(field))
        if "total_gross_weight_kg" in data:
            weighment.total_gross_weight_kg = float(_decimal_2(data.get("total_gross_weight_kg")))
        if "tare_weight_kg" in data:
            weighment.tare_weight_kg = float(_decimal_2(data.get("tare_weight_kg")))
        if "vehicle_no" in data or "vehicle_no_id" in data:
            weighment.vehicle_no_id = data.get("vehicle_no") or data.get("vehicle_no_id")
        if "supply_challan" in data or "challan_id" in data:
            weighment.supply_challan_id = data.get("supply_challan") or data.get("challan_id")
        weighment.updated_by = request_user
        weighment.save(update_fields=[
            "supplier_type", "supplier", "supply_date", "total_gross_weight_kg", "tare_weight_kg",
            "mobile_number", "mode_of_supply", "vehicle_no", "supply_challan", "updated_by", "updated_at",
        ])
        for field in ["supply_date", "quality_standard", "acknowledge_status", "payment_record_option"]:
            if field in data:
                setattr(leaf_receipt, field, data.get(field))
        if "deduction" in data:
            leaf_receipt.deduction = float(_decimal_2(data.get("deduction")))
        if "final_leaf_count" in data:
            leaf_receipt.final_leaf_count = float(_decimal_2(data.get("final_leaf_count")))
        leaf_receipt.rate = str(_decimal_2(rate)) if rate not in (None, "") else None
        leaf_receipt.payment_record_option = payment_record_option
        if "keep_payment_record" in data:
            leaf_receipt.payment_record_option = data.get("keep_payment_record")
        if "unloaded_vehicle_weight" in data:
            supplier_exit.unloaded_vehicle_weight = float(_decimal_2(data.get("unloaded_vehicle_weight")))
        if "is_released" in data:
            supplier_exit.is_released = data.get("is_released")
        if "supply_date" in data:
            supplier_exit.date_of_supply = data.get("supply_date")
        supplier_exit.updated_by = request_user
        _recalculate_supplier_exit(weighment, leaf_receipt, supplier_exit)
        _apply_challan_process_status(weighment, leaf_receipt, supplier_exit)
        leaf_receipt.save(update_fields=[
            "supply_date", "deduction", "final_leaf_count", "net_leaf_weight", "rate",
            "quality_standard", "acknowledge_status", "payment_record_option", "is_complete", "updated_at",
        ])
        supplier_exit.save(update_fields=["unloaded_vehicle_weight", "is_released", "date_of_supply", "net_supplied_qty", "updated_by", "updated_at"])
        LeafCollection.objects.filter(weighment_supply_id=weighment).delete()
        leaf_collection = _create_leaf_collection_for_challan_process(weighment, leaf_receipt, supplier_exit, request_user)
        weighment.refresh_from_db()

    return {"weighment": weighment, "leaf_receipt": leaf_receipt, "supplier_exit": supplier_exit, "leaf_collection": leaf_collection}


def delete_challan_process_records(weighment_id, request_user):
    weighment = WeighmentSupply.cmobjects.filter(pk=weighment_id).first()
    if not weighment:
        raise APIException({"request_status": 0, "msg": "Challan process record not found"})
    with transaction.atomic():
        LeafCollection.objects.filter(weighment_supply_id=weighment).delete()
        LeafManagement.cmobjects.filter(weighment_txn=weighment).update(is_deleted=True)
        SupplierExit.cmobjects.filter(weighment_txn=weighment).update(is_deleted=True, updated_by=request_user)
        if weighment.supply_challan_id:
            SupplyManagement.objects.filter(pk=weighment.supply_challan_id).update(is_weighment_proceed=False)
        weighment.is_deleted = True
        weighment.updated_by = request_user
        weighment.save()
    return weighment
