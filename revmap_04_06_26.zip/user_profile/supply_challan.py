import logging

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import Q


logger = logging.getLogger(__name__)

MAX_CHALLAN_ID_ATTEMPTS = 1000


def get_supply_challan_prefix(supplier_user):
    if not supplier_user or not supplier_user.pk:
        raise ValidationError(
            {"supply_challan_id": "A valid supplier is required to generate the supply challan ID."}
        )

    from user_profile.aggregator_api_models import AggregatorProfile, GrowerProfile

    aggregator = (
        AggregatorProfile.cmobjects
        .select_related("region")
        .filter(user_id=supplier_user.pk)
        .first()
    )
    grower = (
        GrowerProfile.cmobjects
        .select_related("region")
        .filter(user_id=supplier_user.pk)
        .first()
    )
    supplier_profile = aggregator or grower
    region_code = ""
    if supplier_profile and supplier_profile.region:
        region_code = str(supplier_profile.region.region_id or "").strip().upper()

    username = str(supplier_user.username or "").strip().upper()
    if not username:
        raise ValidationError(
            {"supply_challan_id": "Supplier username is required to generate the supply challan ID."}
        )
    return f"CH{region_code}{username}"


def _extract_supply_challan_serial(challan_id, prefix):
    if not challan_id or not str(challan_id).startswith(prefix):
        return None
    suffix = str(challan_id)[len(prefix):]
    if len(suffix) < 2 or not suffix.isdigit():
        return None
    serial_number = int(suffix)
    return serial_number if serial_number > 0 else None


def _next_supply_challan_id(supplier_user, exclude_pk=None):
    from user_profile.aggregator_api_models import SupplyManagement

    prefix = get_supply_challan_prefix(supplier_user)
    supplier_challans = (
        SupplyManagement.objects
        .select_for_update()
        .filter(created_by_id=supplier_user.pk, supply_challan_id__startswith=prefix)
    )
    if exclude_pk:
        supplier_challans = supplier_challans.exclude(pk=exclude_pk)

    used_serials = {
        serial_number
        for challan_id in supplier_challans.values_list("supply_challan_id", flat=True)
        for serial_number in [_extract_supply_challan_serial(challan_id, prefix)]
        if serial_number is not None
    }
    serial_number = 1
    collision_checks = 0
    while collision_checks < MAX_CHALLAN_ID_ATTEMPTS:
        if serial_number in used_serials:
            serial_number += 1
            continue
        challan_id = f"{prefix}{serial_number:02d}"
        duplicate = SupplyManagement.objects.filter(supply_challan_id=challan_id)
        if exclude_pk:
            duplicate = duplicate.exclude(pk=exclude_pk)
        if not duplicate.exists():
            return challan_id
        serial_number += 1
        collision_checks += 1

    raise ValidationError(
        {"supply_challan_id": "Unable to generate a unique supply challan ID. Please try again."}
    )


def _validate_existing_supply_challan_id(instance):
    from user_profile.aggregator_api_models import SupplyManagement

    prefix = get_supply_challan_prefix(instance.created_by)
    if _extract_supply_challan_serial(instance.supply_challan_id, prefix) is None:
        raise ValidationError(
            {
                "supply_challan_id": (
                    f"Supply challan ID must start with {prefix} and end with a numeric serial "
                    "number containing at least two digits."
                )
            }
        )
    duplicate = (
        SupplyManagement.objects
        .filter(supply_challan_id=instance.supply_challan_id)
        .exclude(pk=instance.pk)
        .exists()
    )
    if duplicate:
        raise ValidationError({"supply_challan_id": "Supply challan ID already exists."})
    return instance.supply_challan_id


def assign_supply_challan_id(instance):
    from user_profile.aggregator_api_models import SupplyManagement

    if not instance.created_by_id:
        raise ValidationError(
            {"supply_challan_id": "Supplier is required to generate the supply challan ID."}
        )
    if instance.supply_challan_id:
        return _validate_existing_supply_challan_id(instance)

    for _attempt in range(MAX_CHALLAN_ID_ATTEMPTS):
        try:
            with transaction.atomic():
                challan_id = _next_supply_challan_id(instance.created_by, exclude_pk=instance.pk)
                updated = (
                    SupplyManagement.objects
                    .filter(pk=instance.pk)
                    .filter(Q(supply_challan_id__isnull=True) | Q(supply_challan_id=""))
                    .update(supply_challan_id=challan_id)
                )
                if updated:
                    instance.supply_challan_id = challan_id
                    return challan_id
        except IntegrityError:
            logger.warning(
                "Supply challan ID collision while assigning a code for supply record %s.",
                instance.pk,
            )
            continue

        instance.refresh_from_db(fields=["supply_challan_id"])
        if instance.supply_challan_id:
            return _validate_existing_supply_challan_id(instance)

    raise ValidationError(
        {"supply_challan_id": "Unable to generate a unique supply challan ID. Please try again."}
    )
