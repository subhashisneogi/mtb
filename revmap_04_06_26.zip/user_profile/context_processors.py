from user_profile.models import BlfProfile, Profile
from user_profile.permissions import get_permission_map, is_super_admin


def menu_permissions(request):
    user = getattr(request, "user", None)
    if not user or not user.is_authenticated:
        return {
            "menu_permissions": {},
            "is_super_admin_user": False,
            "is_admin_user": False,
            "logged_user_type": "",
            "logged_user_type_key": "",
            "blf_details": None,
        }
    profile = Profile.cmobjects.filter(user=user).select_related("user_type").first()
    logged_user_type = str(profile.user_type) if profile and profile.user_type else ""
    logged_user_type_key = logged_user_type.strip().lower()
    return {
        "menu_permissions": get_permission_map(user),
        "is_super_admin_user": is_super_admin(user),
        "is_admin_user": bool(user.is_superuser or logged_user_type_key in ("admin", "super admin", "superadmin")),
        "logged_user_type": logged_user_type,
        "logged_user_type_key": logged_user_type_key,
        "blf_details": BlfProfile.cmobjects.filter(user=user).first(),
    }
