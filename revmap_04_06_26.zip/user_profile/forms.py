"""
Forms
"""

from django import forms
import re
import os
from decimal import Decimal, InvalidOperation
from django.db.models import Q
from django.core.exceptions import ValidationError
from django.forms import inlineformset_factory
from django.forms.models import BaseInlineFormSet
from django.forms import ModelForm, Textarea
from django.utils import timezone as django_timezone
from .models import *
from .aggregator_api_models import SupplyManagement
from django.contrib.auth import get_user_model
User = get_user_model()
from django.db.models import CharField, Value
from django.db.models.functions import Concat
from gardens_managment.models import Gardens
from vehicle_management.models import VehicleManagement

GROWER_IDENTIFIER_FIELDS = (
	'tea_board_id',
	'land_document_no',
	'lease_agreement_no',
	'gaon_bura_certificate_no',
	'enjoyment_certificate_no',
)

GROWER_ID_PROOF_FIELDS = (
	'voter_id',
	'pan_no',
	'driving_licence_no',
	'ration_card_no',
)

GROWER_ID_PROOF_DOCUMENT_EXTENSIONS = (
	'.jpg',
	'.jpeg',
	'.png',
	'.webp',
	'.pdf',
	'.doc',
	'.docx',
)


def scoped_fk_queryset(model, selected_id=None, **filters):
	qs = model.objects.filter(**filters) if filters else model.objects.all()
	if selected_id:
		qs = (qs | model.objects.filter(id=selected_id)).distinct()
	return qs


def scoped_m2m_queryset(model, selected_ids=None, **filters):
	selected_ids = list(selected_ids or [])
	qs = model.cmobjects.filter(**filters) if hasattr(model, "cmobjects") else model.objects.filter(**filters)
	if selected_ids:
		base = model.cmobjects if hasattr(model, "cmobjects") else model.objects
		qs = (qs | base.filter(id__in=selected_ids)).distinct()
	return qs


def blf_dropdown_label(blf):
	unit_name = (getattr(blf, "entity_unit", None) or "").strip()
	username = getattr(getattr(blf, "user", None), "username", "") or ""
	if unit_name and username:
		return f"{unit_name} ({username})"
	return unit_name or username


def normalize_pk(value):
	return value if str(value or "").isdigit() else None


class DateInput(forms.DateInput):
    """
    Widgets support for date input
    """
    input_type = 'date'


def _supply_blf_queryset():
	return (
		BlfProfile.cmobjects
		.select_related("user")
		.order_by("entity_unit", "user__username")
	)


def _logged_blf_profile(user):
	return BlfProfile.cmobjects.filter(user=user).first()


# class SupplyManagementForm(forms.ModelForm):
# 	"""Create/update one SupplyManagement record."""

# 	blf_entity = forms.ModelChoiceField(queryset=BlfProfile.cmobjects.none(), required=False, empty_label="Select BLF")
# 	user_type = forms.ChoiceField(
# 		choices=(("grower", "Small Tea Grower (STG)"), ("aggregator", "Aggregator")),
# 		required=True,
# 	)
# 	grower = forms.ModelChoiceField(queryset=GrowerProfile.cmobjects.none(), required=False, empty_label="Select Grower")
# 	aggregator = forms.ModelChoiceField(queryset=AggregatorProfile.cmobjects.none(), required=False, empty_label="Select Aggregator")
# 	quantity = forms.FloatField(required=False, min_value=0.01)

# 	class Meta:
# 		model = SupplyManagement
# 		fields = (
# 			"date_of_supply",
# 			"vehicle_option",
# 			"alloted_vehicle",
# 			"driver_name",
# 			"mobile_number",
# 		)
# 		widgets = {
# 			"date_of_supply": DateInput(format="%Y-%m-%d", attrs={"autocomplete": "off"}),
# 		}

# 	def __init__(self, *args, request=None, selected_aggregator=None, **kwargs):
# 		self.request = request
# 		self.selected_blf = None
# 		super().__init__(*args, **kwargs)

# 		for field in self.fields.values():
# 			field.widget.attrs["class"] = "form-control"

# 		self.fields["blf_entity"].label_from_instance = blf_dropdown_label
# 		self.fields["date_of_supply"].required = True
# 		self.fields["date_of_supply"].input_formats = ["%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"]
# 		self.fields["date_of_supply"].widget.attrs["max"] = django_timezone.now().date().isoformat()
# 		self.fields["date_of_supply"].initial = self.fields["date_of_supply"].initial or django_timezone.now().date()
# 		self.fields["vehicle_option"].choices = (("", "Select Vehicle Option"), ("Yes", "Yes"), ("No", "No"))
# 		self.fields["vehicle_option"].required = False
# 		self.fields["alloted_vehicle"].required = True
# 		self.fields["alloted_vehicle"].empty_label = "Select Vehicle Number"
# 		self.fields["alloted_vehicle"].queryset = VehicleManagement.cmobjects.none()

# 		if not request:
# 			return

# 		current_blf_id = self.data.get("blf_entity") or self.initial.get("blf_entity")
# 		current_user_type = self.data.get("user_type") or self.initial.get("user_type") or "grower"
# 		current_grower_id = self.data.get("grower") or self.initial.get("grower")
# 		current_aggregator_id = self.data.get("aggregator") or self.initial.get("aggregator") or getattr(selected_aggregator, "pk", None)

# 		if request.user.is_superuser:
# 			self.fields["blf_entity"].required = True
# 			self.fields["blf_entity"].queryset = _supply_blf_queryset()
# 			self.selected_blf = self.fields["blf_entity"].queryset.filter(pk=current_blf_id).first() if current_blf_id else None
# 		else:
# 			self.fields["blf_entity"].widget = forms.HiddenInput()
# 			self.selected_blf = _logged_blf_profile(request.user)

# 		if self.selected_blf:
# 			blf_filter = Q(associated_blf=self.selected_blf) | Q(associated_entity=self.selected_blf)
# 			grower_qs = GrowerProfile.cmobjects.select_related("user").filter(blf_filter).distinct().order_by("name")
# 			aggregator_qs = AggregatorProfile.cmobjects.select_related("user").filter(blf_filter).distinct().order_by("name")
# 		else:
# 			grower_qs = GrowerProfile.cmobjects.none()
# 			aggregator_qs = AggregatorProfile.cmobjects.none()

# 		self.fields["grower"].queryset = grower_qs
# 		self.fields["aggregator"].queryset = aggregator_qs

# 		supplier = None
# 		if current_user_type == "aggregator" and current_aggregator_id:
# 			supplier = aggregator_qs.filter(pk=current_aggregator_id).first()
# 		elif current_user_type == "grower" and current_grower_id:
# 			supplier = grower_qs.filter(pk=current_grower_id).first()

# 		if supplier and supplier.user_id:
# 			self.fields["alloted_vehicle"].queryset = (
# 				VehicleManagement.cmobjects
# 				.filter(created_by=supplier.user, is_available=True)
# 				.order_by("vehicle_number")
# 			)

# 	def clean(self):
# 		cleaned_data = super().clean()
# 		if self.request and self.request.user.is_superuser and not cleaned_data.get("blf_entity"):
# 			self.add_error("blf_entity", "Select BLF.")

# 		if cleaned_data.get("user_type") == "grower":
# 			if not cleaned_data.get("grower"):
# 				self.add_error("grower", "Select Grower.")
# 			if not cleaned_data.get("quantity"):
# 				self.add_error("quantity", "Quantity must be greater than 0.")
# 		elif cleaned_data.get("user_type") == "aggregator" and not cleaned_data.get("aggregator"):
# 			self.add_error("aggregator", "Select Aggregator.")

# 		if not cleaned_data.get("alloted_vehicle") and "alloted_vehicle" not in self.errors:
# 			self.add_error("alloted_vehicle", "Select Vehicle Number.")
# 		if cleaned_data.get("alloted_vehicle") and not cleaned_data.get("vehicle_option"):
# 			cleaned_data["vehicle_option"] = "Yes"
# 		return cleaned_data


class GrowerProfileForm(forms.ModelForm):
	""" Employee Profile Create Form """

	def __init__(self, *args, **kwargs):
		user_create_pk = kwargs.pop('user_create_pk', None)
		logged_user_id = kwargs.pop('logged_user', None)
		selected_blf = kwargs.pop('selected_blf', None)
		super(GrowerProfileForm, self).__init__(*args, **kwargs)

		self.fields['grower_type'].widget.attrs = {'class': 'select2_demo form-control', 'id' : 'id_grower_type'}
		
		self.fields['voter_id'].required = False
		self.fields['name'].required = True
		self.fields['mobile_number'].required = False
		self.fields['grower_type'].required = True
		self.fields['associated_blf'].required = True
		self.fields['state'].required = True
		self.fields['district'].required = True
		self.fields['region'].required = True
		self.fields['village_or_town'].required = False
		self.fields["age"].widget.attrs["readonly"] = False
		self.fields["gender"].required = True

		
		for field in self.fields.values():
			field.widget.attrs = {"class": "form-control"}

		self.fields['name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Name"}
		self.fields['mobile_number'].widget.attrs = {
			'class': 'form-control mobile-number-input',
			'placeholder' : "Mobile No",
			'inputmode': 'numeric',
			'maxlength': '10',
			'pattern': r'[0-9]{10}',
			'title': 'Enter 10 digit mobile number',
		}
		self.fields['certificate_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Certificate No."}
		self.fields['region'].widget.attrs = {'class': 'form-control', 'placeholder' : "Region", 'id' : 'id_region'}
		self.fields['state'].widget.attrs = {'class': 'form-control', 'placeholder' : "State"}
		self.fields['district'].widget.attrs = {'class': 'form-control', 'placeholder' : "District"}
		self.fields['address'].widget.attrs = {'class': 'form-control', 'placeholder' : "Address"}
		self.fields['village_or_town'].widget.attrs = {'class': 'form-control', 'placeholder' : "Village or Town"}
		self.fields['postoffice'].widget.attrs = {'class': 'form-control', 'placeholder' : "Post office."}
		self.fields['pincode'].widget.attrs = {
			'class': 'form-control',
			'placeholder' : "Pincode",
			'inputmode': 'numeric',
			'maxlength': '6',
			'pattern': r'[1-9][0-9]{5}',
			'title': 'Enter a valid 6 digit PIN code',
		}
		self.fields['voter_id'].widget.attrs = {'class': 'form-control', 'placeholder' : "Voter ID"}
		self.fields['pan_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "PAN No."}
		self.fields['driving_licence_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Driving License No."}
		self.fields['ration_card_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Ration Card No."}
		self.fields['aadhar_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Aadhar No."}
		self.fields['trustea_id'].widget.attrs = {'class': 'form-control', 'placeholder' : "Trust tea id"}
		self.fields['existing_trust_tea_id'].widget.attrs = {'class': 'form-control', 'placeholder' : "Existing trust tea id"}
		self.fields['father_name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Father's Name"}
		self.fields['date_of_birth'].widget.attrs = {'class': 'form-control', 'placeholder' : "MM/DD/YYYY", 'id' : 'date_of_birth', 'onchange' : 'ageCalculator(this)'}
		self.fields['age'].widget.attrs = {'class': 'form-control readonly-field', 'placeholder' : "Age", 'readonly' : 'readonly', 'id' : 'age'}
		self.fields['tea_board_id'].widget.attrs = {'class': 'form-control', 'placeholder' : "Tea Board Registration No."}
		self.fields['land_document_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Land Document No."}
		self.fields['lease_agreement_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Lease Agreement No."}
		self.fields['gaon_bura_certificate_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Gaon Bura Certificate No."}
		self.fields['enjoyment_certificate_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Enjoyment Certificate No."}
		for field_name in GROWER_IDENTIFIER_FIELDS + GROWER_ID_PROOF_FIELDS:
			self.fields[field_name].widget.attrs.update({
				'pattern': r'[A-Za-z0-9]+',
				'title': 'Use letters and numbers only',
			})
		self.fields['total_male_worker'].widget.attrs = {'class': 'form-control', 'placeholder' : "Total male worker", 'min': '0', 'step': '1', 'inputmode': 'numeric'}
		self.fields['total_female_worker'].widget.attrs = {'class': 'form-control', 'placeholder' : "Total female worker", 'min': '0', 'step': '1', 'inputmode': 'numeric'}
		self.fields['estimated_production_of_green_tea'].widget = forms.TextInput(attrs={
			'class': 'form-control decimal-input',
			'placeholder' : "Estimated production of green tea",
			'inputmode': 'decimal',
			'pattern': r'\d+(\.\d{1,2})?',
			'title': 'Enter a non-negative decimal number with up to 2 decimal places',
		})
		self.fields['estimated_production_of_made_tea'].widget = forms.TextInput(attrs={
			'class': 'form-control decimal-input',
			'placeholder' : "Estimated production of made tea",
			'inputmode': 'decimal',
			'pattern': r'\d+(\.\d{1,2})?',
			'title': 'Enter a non-negative decimal number with up to 2 decimal places',
		})
		self.fields['additional_information'].widget.attrs = {'class': 'form-control', 'placeholder' : "Additional information", 'id' : 'id_additional_information'}
		self.fields['photo'].widget.attrs = {
			'class': 'file-upload',
			'accept': 'image/jpeg,image/jpg,image/png,image/svg+xml,image/webp',
		}
		# self.fields['state'].queryset = State.objects.none()

		self.fields['region'].queryset = Region.objects.filter(is_deleted=False).order_by('region_name')
		if self.instance and self.instance.pk:
			self.fields['state'].queryset = scoped_fk_queryset(State, getattr(self.instance, "state_id", None)).order_by('name')
			self.fields['district'].queryset = scoped_fk_queryset(District, getattr(self.instance, "district_id", None), state_id=getattr(self.instance, "state_id", None)).order_by('name')
		self.fields['associated_unit'].widget.attrs = {'class': 'form-control'}

		self.fields['associated_blf'].widget.attrs = {'class': 'form-control', 'id' : 'associated_blf'}
		self.fields['associated_blf'].label_from_instance = blf_dropdown_label
		
		self.fields['associated_aggregator'].widget.attrs = {'class': 'form-control select2_ass_agg', 'id' : 'id_aggregator'}
		selected_aggregators = self.instance.associated_aggregator.values_list("id", flat=True) if self.instance and self.instance.pk else []
		selected_blf_id = normalize_pk(getattr(selected_blf, "id", None))
		if not selected_blf_id and self.is_bound:
			selected_blf_id = normalize_pk(self.data.get("associated_blf"))
		if not selected_blf_id and self.instance and self.instance.pk:
			selected_blf_id = self.instance.associated_blf_id or self.instance.associated_entity.values_list("id", flat=True).first()
		selected_blf = selected_blf or BlfProfile.cmobjects.filter(id=selected_blf_id).first()
		if selected_blf_id:
			self.fields['associated_aggregator'].queryset = scoped_m2m_queryset(
				AggregatorProfile,
				selected_aggregators,
				user__is_active=True,
				associated_entity=selected_blf_id,
			).select_related("user").order_by('user__username')
		else:
			self.fields['associated_aggregator'].queryset = scoped_m2m_queryset(
				AggregatorProfile,
				selected_aggregators,
				pk__in=selected_aggregators,
			).select_related("user").order_by('user__username')
		self.fields['associated_blf'].queryset = scoped_fk_queryset(
			BlfProfile,
			selected_blf_id,
			user__is_active=True,
		).select_related("user").order_by('entity_unit', 'user__username')
		for field_name, field in self.fields.items():
			if field.required and not field.disabled and not isinstance(field.widget, forms.HiddenInput):
				field.widget.attrs["required"] = "required"
		if selected_blf_id and not self.is_bound:
			self.initial['associated_blf'] = selected_blf_id
		if selected_blf:
			self.initial["region"] = selected_blf.region_id
			self.fields["region"].disabled = True

		if 'state' in self.data:
			try:
				state_id = int(self.data.get('state'))
				self.fields['state'].queryset=State.objects.filter(id=state_id).order_by('name')
				state_id=State.objects.filter(id=state_id).values('id')
				
				for data in state_id:
					data=data.get('id')
					self.fields['district'].queryset=District.objects.filter(state_id=data).order_by('name')
			except (ValueError, TypeError):
				pass  # invalid input from the client; ignore and fallback to empty City queryset

	class Meta:
		model = GrowerProfile
		fields = ('name', 'mobile_number', 'grower_type', 'certificate_no', 'region', 'state', 'district', 'address', 'village_or_town', 
	    		'postoffice', 'pincode', 'voter_id', 'aadhar_no', 'pan_no', 'driving_licence_no', 'ration_card_no',
				'trustea_id', 'existing_trust_tea_id', 'associated_blf',
				'associated_aggregator', 'associated_unit', 'father_name', 'date_of_birth', 'age', 'gender', 'tea_board_id',
	    		'land_document_no', 'lease_agreement_no', 'gaon_bura_certificate_no', 'enjoyment_certificate_no',
	    		'total_male_worker', 'total_female_worker', 'estimated_production_of_green_tea', 'estimated_production_of_made_tea',
			    'id_proof_type', 'id_proof_file', 'additional_information', 'photo',
		  )
		
		widgets = {
            'address': Textarea(attrs={'rows':80, 'cols':20}),
	    	'date_of_birth': DateInput(),
        }

	def clean(self):
		cleaned_data = super().clean()
		selected_blf = cleaned_data.get("associated_blf")
		if selected_blf:
			cleaned_data["region"] = selected_blf.region
		has_registration_identifier = any((cleaned_data.get(field) or '').strip() for field in GROWER_IDENTIFIER_FIELDS)
		if not has_registration_identifier:
			self.add_error(
				None,
				"Enter at least one grower identification number: TBR No., Land Document No., Lease Agreement No., Gaon Bura/Gram Panchayet Pradhan Certificate No., or Enjoyment Certificate No."
			)
		pincode = (cleaned_data.get("pincode") or "").strip()
		cleaned_data["pincode"] = pincode or None
		if pincode and not re.match(r'^[1-9][0-9]{5}$', pincode):
			self.add_error("pincode", "Enter a valid 6 digit PIN code.")
		for field in GROWER_IDENTIFIER_FIELDS + GROWER_ID_PROOF_FIELDS:
			value = (cleaned_data.get(field) or '').strip()
			cleaned_data[field] = value or None
			if value and not re.match(r'^[A-Za-z0-9]+$', value):
				self.add_error(field, "Only alphanumeric values are allowed.")

		current_values = {}
		if self.instance and self.instance.pk:
			current_values = (
				GrowerProfile.objects.filter(pk=self.instance.pk)
				.values(*GROWER_IDENTIFIER_FIELDS)
				.first()
				or {}
			)
		for field in GROWER_IDENTIFIER_FIELDS:
			value = cleaned_data.get(field)
			if not value:
				continue
			current_value = (current_values.get(field) or '').strip() or None
			if self.instance and self.instance.pk and current_value == value:
				continue
			if GrowerProfile.objects.exclude(pk=getattr(self.instance, 'pk', None)).filter(**{field: value}).exists():
				field_label = self.fields[field].label or GrowerProfile._meta.get_field(field).verbose_name.title()
				self.add_error(field, f"{field_label} already exists.")
		for field in ("estimated_production_of_green_tea", "estimated_production_of_made_tea"):
			value = cleaned_data.get(field)
			if value in (None, ""):
				continue
			value = str(value).strip()
			if not re.match(r'^\d+(\.\d{1,2})?$', value):
				self.add_error(field, "Enter a valid decimal value.")
			else:
				try:
					cleaned_data[field] = str(Decimal(value).quantize(Decimal("0.01")))
				except InvalidOperation:
					self.add_error(field, "Enter a valid decimal value.")
		for field in ("total_male_worker", "total_female_worker"):
			value = cleaned_data.get(field)
			if value in (None, ""):
				continue
			if value < 0:
				self.add_error(field, "Enter a non-negative number.")
		return cleaned_data


class GrowerIDProofAttachmentForm(forms.ModelForm):
	"""Multiple ID proof upload form for grower profile edit."""

	class Meta:
		model = UserProfileAttachments
		fields = ("attachment_name", "doc_no", "attachment")
		widgets = {
			"attachment_name": forms.Select(attrs={"class": "form-control proof-type"}),
			"doc_no": forms.TextInput(attrs={
				"class": "form-control",
				"placeholder": "Document number",
				"pattern": r"[A-Za-z0-9]+",
				"title": "Use letters and numbers only",
			}),
			"attachment": forms.ClearableFileInput(attrs={
				"class": "form-control proof-file",
				"accept": "image/jpeg,image/jpg,image/png,image/webp,application/pdf,.doc,.docx",
			}),
		}

	def clean(self):
		cleaned_data = super().clean()
		if cleaned_data.get("DELETE"):
			return cleaned_data

		attachment_name = cleaned_data.get("attachment_name")
		doc_no = (cleaned_data.get("doc_no") or "").strip() or None
		cleaned_data["doc_no"] = doc_no
		attachment = cleaned_data.get("attachment")
		has_existing_file = bool(getattr(self.instance, "attachment", None))
		has_any_value = bool(attachment_name or doc_no or attachment or has_existing_file)

		if self.instance and self.instance.pk and attachment_name and not doc_no and not attachment and not has_existing_file:
			return cleaned_data

		if not has_any_value:
			return cleaned_data

		if not attachment_name:
			self.add_error("attachment_name", "Select ID proof type.")
		if not doc_no:
			self.add_error("doc_no", "Enter document number.")
		else:
			if not re.match(r'^[A-Za-z0-9]+$', doc_no):
				self.add_error("doc_no", "Only alphanumeric values are allowed.")
			else:
				current_doc_no = None
				if self.instance and self.instance.pk:
					current_doc_no = (
						UserProfileAttachments.objects.filter(pk=self.instance.pk)
						.values_list("doc_no", flat=True)
						.first()
					)
					current_doc_no = (current_doc_no or "").strip() or None
				if not (self.instance and self.instance.pk and current_doc_no == doc_no):
					duplicate_exists = (
						UserProfileAttachments.objects.exclude(pk=getattr(self.instance, "pk", None))
						.filter(doc_no=doc_no)
						.exists()
					)
					if duplicate_exists:
						self.add_error("doc_no", "Document number already exists.")
		if not attachment and not has_existing_file:
			self.add_error("attachment", "Upload ID proof document.")
		if attachment:
			extension = os.path.splitext(attachment.name)[1].lower()
			if extension not in GROWER_ID_PROOF_DOCUMENT_EXTENSIONS:
				self.add_error("attachment", "Upload only image, PDF, DOC, or DOCX file.")
		return cleaned_data


class BaseGrowerIDProofAttachmentFormSet(BaseInlineFormSet):
	"""Require at least one complete ID proof upload row for grower forms."""

	def clean(self):
		super().clean()
		if any(self.errors):
			return

		has_active_proof = False
		used_proof_types = {}
		for form in self.forms:
			cleaned_data = getattr(form, "cleaned_data", None) or {}
			if cleaned_data.get("DELETE"):
				continue
			attachment_name = cleaned_data.get("attachment_name")
			doc_no = cleaned_data.get("doc_no")
			attachment = cleaned_data.get("attachment")
			has_existing_file = bool(getattr(form.instance, "attachment", None))
			if attachment_name:
				if attachment_name in used_proof_types:
					form.add_error("attachment_name", "This ID proof type is already selected.")
					used_proof_types[attachment_name].add_error("attachment_name", "This ID proof type is already selected.")
				else:
					used_proof_types[attachment_name] = form
			if attachment_name and doc_no and (attachment or has_existing_file):
				has_active_proof = True

		if not has_active_proof:
			raise ValidationError("Add at least one ID proof upload with document number.")
		if any(form.errors for form in self.forms):
			raise ValidationError("Do not select the same ID proof type more than once.")


GrowerIDProofAttachmentFormSet = inlineformset_factory(
	GrowerProfile,
	UserProfileAttachments,
	form=GrowerIDProofAttachmentForm,
	formset=BaseGrowerIDProofAttachmentFormSet,
	extra=0,
	max_num=5,
	validate_max=True,
	can_delete=True,
)

GrowerIDProofAttachmentCreateFormSet = inlineformset_factory(
	GrowerProfile,
	UserProfileAttachments,
	form=GrowerIDProofAttachmentForm,
	formset=BaseGrowerIDProofAttachmentFormSet,
	extra=1,
	max_num=5,
	validate_max=True,
	can_delete=True,
)


class GrowerGardenForm(forms.ModelForm):
	"""Repeatable garden row on the grower profile form."""
	class Meta:
		model = Gardens
		fields = '__all__'
		widgets = {
			"name": forms.TextInput(attrs={"class": "form-control garden-name", "placeholder": "Garden name"}),
			"production_area": forms.TextInput(attrs={
				"class": "form-control decimal-input",
				"placeholder": "Production area",
				"inputmode": "decimal",
				"pattern": r"\d+(\.\d{1,2})?",
				"min" : "1",
				"step" : "0.1",
				"title": "Enter a non-negative decimal number with up to 2 decimal places",
			}),
		}

	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		self.fields["name"].required = True
		self.fields["production_area"].required = True

	def clean(self):
		cleaned_data = super().clean()
		if cleaned_data.get("DELETE"):
			return cleaned_data
		production_area = (cleaned_data.get("production_area") or "").strip()
		cleaned_data["production_area"] = production_area
		if production_area and not re.match(r'^\d+(\.\d{1,2})?$', production_area):
			self.add_error("production_area", "Enter a valid non-negative decimal value.")
		elif production_area:
			try:
				cleaned_data["production_area"] = str(Decimal(production_area).quantize(Decimal("0.01")))
			except InvalidOperation:
				self.add_error("production_area", "Enter a valid non-negative decimal value.")
		return cleaned_data


class BaseGrowerGardenFormSet(BaseInlineFormSet):
	"""Require at least one active garden row for each grower."""

	def clean(self):
		super().clean()
		if any(self.errors):
			return
		has_active_garden = any(
			(form.cleaned_data.get("name") and form.cleaned_data.get("production_area"))
			for form in self.forms
			if getattr(form, "cleaned_data", None) and not form.cleaned_data.get("DELETE")
		)
		if not has_active_garden:
			raise ValidationError("Add at least one garden with garden name and production area.")


GrowerGardenFormSet = inlineformset_factory(
	GrowerProfile,
	Gardens,
	form=GrowerGardenForm,
	formset=BaseGrowerGardenFormSet,
	extra=0,
	min_num=0,
	validate_min=False,
	can_delete=True,
)

GrowerGardenCreateFormSet = inlineformset_factory(
	GrowerProfile,
	Gardens,
	form=GrowerGardenForm,
	formset=BaseGrowerGardenFormSet,
	extra=1,
	min_num=0,
	validate_min=False,
	can_delete=True,
)


class AggregatorProfileForm(forms.ModelForm):
	""" Aggregator Profile Create Form @vivek"""

	def __init__(self, *args, **kwargs):
		user_create_pk = kwargs.pop('user_create_pk', None)
		logged_user_id = kwargs.pop('logged_user', None)
		selected_blf = kwargs.pop('selected_blf', None)
		super(AggregatorProfileForm, self).__init__(*args, **kwargs)
		
		self.fields['state'].required = True
		self.fields['district'].required = True
		self.fields['region'].required = True
		self.fields['name'].required = True
		self.fields['mobile_number'].required = False
		self.fields['associated_blf'].required = True
		self.fields['aggregator_type'].required = True

		# self.fields['grower_type'].required = True
		# self.fields['grower_type'].required = True
		# self.fields['grower_type'].required = True

		self.fields['aggregator_type'].widget.attrs = {'class': 'select2_demo form-control', 'id' : 'aggregator_type'}
		# self.fields['associated_entity'].widget.attrs = {'class': 'select2_demo form-control', 'id' : 'associated_entity'}
		# self.fields['state'].widget.attrs = {'class': 'select2_demo form-control', 'id' : 'state'}
		# self.fields['district'].widget.attrs = {'class': 'select2_demo form-control', 'id' : 'district'}
		for field in self.fields.values():
			field.widget.attrs = {"class": "form-control"}
		self.fields['name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Name"}
		self.fields['mobile_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Mobile No"}
		# self.fields['aggregator_type'].widget.attrs = {'class': 'form-control', 'placeholder' : "Aggregator Type"}
		self.fields['region'].widget.attrs = {'class': 'form-control', 'placeholder' : "Region"}
		# self.fields['state'].widget.attrs = {'class': 'form-control', 'placeholder' : "State"}
		# self.fields['district'].widget.attrs = {'class': 'form-control', 'placeholder' : "District"}
		self.fields['address'].widget.attrs = {'class': 'form-control', 'placeholder' : "Address"}
		self.fields['associated_blf'].widget.attrs = {'class': 'form-control', 'id' : 'associated_blf'}
		self.fields['associated_blf'].label_from_instance = blf_dropdown_label
		self.fields['gstin_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "GSTIN NO."}
		# self.fields['state'].queryset = State.objects.none()
		# self.fields['district'].queryset = District.objects.none()	
		# self.fields['associated_entity'].queryset = AssociatedEntity.objects.none()
		self.fields['region'].queryset = Region.objects.filter(is_deleted=False).order_by('region_name')
		if self.instance and self.instance.pk:
			self.fields['state'].queryset = scoped_fk_queryset(State, getattr(self.instance, "state_id", None)).order_by('name')
			self.fields['district'].queryset = scoped_fk_queryset(District, getattr(self.instance, "district_id", None), state_id=getattr(self.instance, "state_id", None)).order_by('name')

		selected_blf_id = normalize_pk(getattr(selected_blf, "id", None))
		if not selected_blf_id and self.is_bound:
			selected_blf_id = normalize_pk(self.data.get("associated_blf"))
		if not selected_blf_id and self.instance and self.instance.pk:
			selected_blf_id = self.instance.associated_blf_id or self.instance.associated_entity.values_list("id", flat=True).first()
		selected_blf = selected_blf or BlfProfile.cmobjects.filter(id=selected_blf_id).first()
		self.fields['associated_blf'].queryset = scoped_fk_queryset(
			BlfProfile,
			selected_blf_id,
			user__is_active=True,
		).select_related("user").order_by('entity_unit', 'user__username')
		if selected_blf_id and not self.is_bound:
			self.initial['associated_blf'] = selected_blf_id
		if selected_blf:
			self.initial["region"] = selected_blf.region_id
			self.fields["region"].disabled = True
	
		if 'state' in self.data :
			try:
				state_id = int(self.data.get('state'))
				self.fields['state'].queryset=State.objects.filter(id=state_id).order_by('name')
				state_id=State.objects.filter(id=state_id).values('id')
				
				for data in state_id:
					data=data.get('id')
					self.fields['district'].queryset=District.objects.filter(state_id=data).order_by('name')
			except (ValueError, TypeError):
				pass  # invalid input from the client; ignore and fallback to empty City queryset
		
		
	class Meta:
		model = AggregatorProfile
		fields = ('name', 'email','mobile_number', 'aggregator_type', 'region', 'state', 'district',
	     'address', 'associated_blf', \
	     'gstin_no', 'user_file'
	     
	     )
		widgets = {
            'address': Textarea(attrs={'rows':80, 'cols':20}),
        }

	def clean(self):
		cleaned_data = super().clean()
		selected_blf = cleaned_data.get("associated_blf")
		if selected_blf:
			cleaned_data["region"] = selected_blf.region
		return cleaned_data
		

class BlfProfileForm(forms.ModelForm):
	""" BLF Profile Create Form """

	def __init__(self, *args, **kwargs):
		user_create_pk = kwargs.pop('user_create_pk', None)
		logged_user_id = kwargs.pop('logged_user', None)
		super(BlfProfileForm, self).__init__(*args, **kwargs)

		for field in self.fields.values():
			field.widget.attrs = {"class": "form-control"}

		self.fields['state'].required = True
		self.fields['district'].required = True
		self.fields['region'].required = True
		self.fields["entity_unit"].required = True

		self.fields['entity_name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Entity Name"}
		self.fields['entity_unit'].widget.attrs = {'class': 'form-control', 'placeholder' : "Unit Name"}
		self.fields['tcmo_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "TMCO No"}
		self.fields['certificate_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Certificate No"}
		self.fields['region'].widget.attrs = {'class': 'form-control', 'placeholder' : "Region"}
		self.fields['address'].widget.attrs = {'class': 'form-control', 'placeholder' : "Address"}
		self.fields['ho_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['ho_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['ho_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['garden_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['garden_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['garden_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['manager_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['manager_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['manager_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['trust_tea_officer_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['trust_tea_officer_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['trust_tea_officer_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['data_operator_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['data_operator_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['data_operator_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['factory_details_likely_production'].widget.attrs = {'class': 'form-control', 'placeholder' : "in Mn.kg", "step" : '0.01'}
		# self.fields['factory_details_marks'].widget.attrs = {'class': 'form-control select2_demo_marks', 'placeholder' : "Marks"}
		self.fields['factory_details_other_certificate'].widget.attrs = {'class': 'form-control', 'placeholder' : "Certificate No."}
		self.fields['ownership_details_managing_company'].widget.attrs = {'class': 'form-control', 'placeholder' : "Managing company"}
		self.fields['ownership_details_name_of_tea_company'].widget.attrs = {'class': 'form-control', 'placeholder' : "Name of tea company"}
		self.fields['ownership_details_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Mailing Address"}
		self.fields['user_file'].widget.attrs = {'class': 'file-upload'}

			
		self.fields['region'].queryset = Region.objects.filter(is_deleted=False)

		if 'state' in self.data:
			try:
				state_id = int(self.data.get('state'))
				self.fields['state'].queryset=State.objects.filter(id=state_id).order_by('name')
				state_id=State.objects.filter(id=state_id).values('id')
				
				for data in state_id:
					data=data.get('id')
					print(data)
					self.fields['district'].queryset=District.objects.filter(state_id=data).order_by('name')
			except (ValueError, TypeError):
				pass  # invalid input from the client; ignore and fallback to empty City queryset

	class Meta:
		model = BlfProfile

		fields = ('certificate_no', 'tcmo_no', 'region', 'state', 'district',
	     'address', 'ho_contact_number', 'ho_contact_person', 'ho_contact_email', 'garden_contact_number', 'garden_contact_person',
		  'garden_contact_email', 'manager_contact_number', 'manager_contact_person', 'manager_contact_email',
		    'trust_tea_officer_contact_number',
		   'trust_tea_officer_contact_person', 'trust_tea_officer_contact_email',
		     'data_operator_contact_number',
		    'data_operator_contact_person', 'data_operator_contact_email', 'factory_details_likely_production', 
			 'factory_details_other_certificate', 'ownership_details_managing_company', 'ownership_details_name_of_tea_company',
			  'ownership_details_email', 'user_file',
			    'entity_name', 'entity_unit', 'easy_weight_system'
			   )
		
		widgets = {
            'address': Textarea(attrs={'rows':80, 'cols':20}),
        }




class EstateProfileForm(forms.ModelForm):
	""" Estate Profile Create Form """

	def __init__(self, *args, **kwargs):
		user_create_pk = kwargs.pop('user_create_pk', None)
		logged_user_id = kwargs.pop('logged_user', None)
		super(EstateProfileForm, self).__init__(*args, **kwargs)

		for field in self.fields.values():
			field.widget.attrs = {"class": "form-control"}

		self.fields['is_fetch_from_tcms'].required = False
		
		self.fields['state'].required = True
		self.fields['district'].required = True
		self.fields['region'].required = True


		self.fields['certificate_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Certificate No"}
		self.fields['region'].widget.attrs = {'class': 'form-control', 'placeholder' : "Region"}
		self.fields['address'].widget.attrs = {'class': 'form-control', 'placeholder' : "Address"}
		self.fields['ho_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['ho_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['ho_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['garden_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['garden_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['garden_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['manager_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['manager_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['manager_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['trust_tea_officer_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['trust_tea_officer_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['trust_tea_officer_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['data_operator_contact_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Number"}
		self.fields['data_operator_contact_person'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact Person"}
		self.fields['data_operator_contact_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email Address"}
		self.fields['factory_details_likely_production'].widget.attrs = {'class': 'form-control', 'placeholder' : "in Mn.kg", 'step' : '0.01'}
		# self.fields['factory_details_marks'].widget.attrs = {'class': 'form-control select2_demo_marks', 'placeholder' : "Marks"}
		self.fields['factory_details_other_certificate'].widget.attrs = {'class': 'form-control', 'placeholder' : "Certificate No."}
		self.fields['ownership_details_managing_company'].widget.attrs = {'class': 'form-control', 'placeholder' : "Managing company"}
		self.fields['ownership_details_name_of_tea_company'].widget.attrs = {'class': 'form-control', 'placeholder' : "Name of tea company"}
		self.fields['ownership_details_email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Mailing Address" }
		self.fields['user_file'].widget.attrs = {'class': 'file-upload'}

		self.fields['entity_name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Estate Name"}
		self.fields['entity_unit'].widget.attrs = {'class': 'form-control', 'placeholder' : "Garden/Entity Unit"}

		self.fields['total_male_worker'].widget.attrs = {'class': 'form-control', 'placeholder' : "Total male worker"}
		self.fields['total_female_worker'].widget.attrs = {'class': 'form-control', 'placeholder' : "Total Female worker"}
		self.fields['estimated_production_of_green_leaves'].widget.attrs = {'class': 'form-control', 'placeholder' : "Estimated Production of Green Leaves (Kg)"}
		self.fields['estimated_production_of_made_tea'].widget.attrs = {'class': 'form-control', 'placeholder' : "Estimated Production of Made Tea (Kg)"}

		self.fields['is_fetch_from_tcms'].widget.attrs = {'class': 'form-control', 'id' : "is_fetch_from_tcms"}

		# self.fields['state'].queryset = State.objects.none()
		# self.fields['district'].queryset = District.objects.none()

		self.fields['region'].queryset = Region.objects.filter(is_deleted=False)
		
		if 'state' in self.data:
			try:
				state_id = int(self.data.get('state'))
				self.fields['state'].queryset=State.objects.filter(id=state_id).order_by('name')
				# self.fields['factory_estate_state'].queryset=State.objects.filter(id=state_id).order_by('name')
				state_id=State.objects.filter(id=state_id).values('id')
				
				for data in state_id:
					data=data.get('id')
					print(data)
					self.fields['district'].queryset=District.objects.filter(state_id=data).order_by('name')
					# self.fields['factory_estate_district'].queryset=District.objects.filter(state_id=data).order_by('name')
			except (ValueError, TypeError):
				pass 


	class Meta:
		model = EstateProfile
		fields = ('certificate_no', 'region', 'state', 'district',
	     'address', 'ho_contact_number', 'ho_contact_person', 'ho_contact_email', 'garden_contact_number', 'garden_contact_person',
		  'garden_contact_email', 'manager_contact_number', 'manager_contact_person', 'manager_contact_email',
		    'trust_tea_officer_contact_number',
		   'trust_tea_officer_contact_person', 'trust_tea_officer_contact_email',
		     'data_operator_contact_number',
		    'data_operator_contact_person', 'data_operator_contact_email', 'factory_details_likely_production', 
			 'factory_details_other_certificate', 'ownership_details_managing_company', 'ownership_details_name_of_tea_company',
			  'ownership_details_email', 'user_file', 'is_fetch_from_tcms', 'third_party_easy_weight_system',
			  'total_male_worker', 'total_female_worker', 'estimated_production_of_green_leaves',
			    'estimated_production_of_made_tea', 'api_entity_name', 'api_entity_unit', 'entity_name', 'entity_unit', 'easy_weight_system'
			   )
		
		widgets = {
            'address': Textarea(attrs={'rows':80, 'cols':20}),
        }




		

class BlfTroughDetailsForm(forms.ModelForm):

	class Meta:
		model = BlfTroughDetails
		fields = ('capacity_qty', 'name', 'leaf_type', 'size_width', 'size_height')

	def __init__(self, *args, **kwargs):
		super(BlfTroughDetailsForm, self).__init__(*args, **kwargs)

		self.fields['capacity_qty'].widget.attrs = {'class': 'form-control', 'placeholder' : "Capacity Qty"}
		self.fields['size_width'].widget.attrs = {'class': 'form-control', 'placeholder' : "width"}
		self.fields['size_height'].widget.attrs = {'class': 'form-control', 'placeholder' : "height"}
		self.fields['name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Trough Name"}
		self.fields['leaf_type'].widget.attrs = {'class': 'form-control', 'placeholder' : "Type of Leaf"}







class EstateProductionForm(forms.ModelForm):

	class Meta:
		model = EstateTeaProduction
		fields = ('tea_type', 'tea_grade', 'marks', 'quantity')

	def __init__(self, *args, **kwargs):
		super(EstateProductionForm, self).__init__(*args, **kwargs)

		self.fields['tea_type'].widget.attrs = {'class': 'form-control select2_tea_type', "onchange": "product_type_change(this)" }
		self.fields['tea_grade'].widget.attrs = {'class': 'form-control select2_tea_grade'}
		self.fields['marks'].widget.attrs = {'class': 'form-control select2_marks'}
		self.fields['quantity'].widget.attrs = {'class': 'form-control', 'placeholder' : "Quantity"}


class EstateTeaProductionForm(forms.ModelForm):

	class Meta:
		model = EstateTeaProduction
		fields = ('tea_type', 'tea_grade', 'marks', 'quantity')

	def __init__(self, *args, **kwargs):
		super(EstateTeaProductionForm, self).__init__(*args, **kwargs)

		self.fields['tea_type'].widget.attrs = {'class': 'form-control ' }
		self.fields['tea_grade'].widget.attrs = {'class': 'form-control '}
		self.fields['marks'].widget.attrs = {'class': 'form-control '}
		self.fields['quantity'].widget.attrs = {'class': 'form-control', 'placeholder' : "Quantity"}


class EstateProductionTeaTypeForm(forms.ModelForm):

	class Meta:
		model = EstateProductionTeaType
		fields = ('tea_type', 'tea_grade', 'marks', 'quantity')

	def __init__(self, *args, **kwargs):
		super(EstateProductionTeaTypeForm, self).__init__(*args, **kwargs)

		self.fields['tea_type'].widget.attrs = {'class': 'form-control' }
		self.fields['tea_grade'].widget.attrs = {'class': 'form-control'}
		self.fields['marks'].widget.attrs = {'class': 'form-control'}
		self.fields['quantity'].widget.attrs = {'class': 'form-control', 'placeholder' : "Quantity"}



class BlfTeaProductionForm(forms.ModelForm):

	class Meta:
		model = BlfTeaProduction
		fields = ('tea_type', 'tea_grade', 'marks', 'quantity')

	def __init__(self, *args, **kwargs):
		super(BlfTeaProductionForm, self).__init__(*args, **kwargs)

		self.fields['tea_type'].widget.attrs = {'class': 'form-control', "onchange": "product_type_change(this)" }
		self.fields['tea_grade'].widget.attrs = {'class': 'form-control'}
		self.fields['marks'].widget.attrs = {'class': 'form-control'}
		self.fields['quantity'].widget.attrs = {'class': 'form-control', 'placeholder' : "Quantity"}




class BlfFactoryDetailsMarksForm(forms.ModelForm):

	class Meta:
		model = BlfFactoryDetailsMarks
		fields = ('name',)

	def __init__(self, *args, **kwargs):
		super(BlfFactoryDetailsMarksForm, self).__init__(*args, **kwargs)

		self.fields['name'].widget.attrs = {'class': 'form-control' , 'placeholder' : 'Creatre marks', 'id' : 'factory_marks_id'}


class FactoryDetailsMarksForm(forms.ModelForm):

	class Meta:
		model = FactoryDetailsMarks
		fields = ('name',)

	def __init__(self, *args, **kwargs):
		super(FactoryDetailsMarksForm, self).__init__(*args, **kwargs)

		self.fields['name'].widget.attrs = {'class': 'form-control' , 'placeholder' : 'Creatre marks', 'id' : 'factory_marks_id'}



class BlfMarksForm(forms.ModelForm):

	class Meta:
		model = BlfFactoryMarks
		fields = ('name',)

	def __init__(self, *args, **kwargs):
		super(BlfMarksForm, self).__init__(*args, **kwargs)

		self.fields['name'].widget.attrs = {'class': 'form-control' , 'placeholder' : 'Creatre marks', 'id' : 'factory_marks_id'}





############ Estate Trough Details FORMS #########

class FactoryTroughDetailsForm(forms.ModelForm):
    """
    Factory Trough Details Form
    """
    class Meta:
        model = FactoryTroughDetails
        fields = ('name',)

    def __init__(self, *args, **kwargs):
        super(FactoryTroughDetailsForm, self).__init__(*args, **kwargs)

        self.fields['name'].widget.attrs = {'class': 'form-control', 'placeholder' : "*Name"}


class EstateTroughDetailsForm(forms.ModelForm):
	"""
	Estate Trough Details Form
	"""
	class Meta:
		model = EstateTroughDetails
		fields = ('name', 'capacity_qty', 'size_width', 'size_height', 'leaf_type')

	def __init__(self, *args, **kwargs):
		super(EstateTroughDetailsForm, self).__init__(*args, **kwargs)

		self.fields['capacity_qty'].widget.attrs = {'class': 'form-control', 'placeholder' : "Capacity Qty"}
		self.fields['size_width'].widget.attrs = {'class': 'form-control', 'placeholder' : "width"}
		self.fields['size_height'].widget.attrs = {'class': 'form-control', 'placeholder' : "height"}
		self.fields['name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Trough Name"}
		self.fields['leaf_type'].widget.attrs = {'class': 'form-control', 'placeholder' : "Type of Leaf"}



ESTATE_TROUGH_FORM_SET = inlineformset_factory(
    FactoryTroughDetails,
    EstateTroughDetails,
    form=EstateTroughDetailsForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,
    can_delete=True
)



# ########### END #######################


BLF_MAARKS_FORM_SET = inlineformset_factory(
    BlfProfile,
    BlfFactoryMarks,
    form=BlfMarksForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,
    can_delete=True
)



FACTORY_DETAILS_MARKS_FORM_SET = inlineformset_factory(
    EstateProfile,
    FactoryDetailsMarks,
    form=FactoryDetailsMarksForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,
    can_delete=True
)

BLF_TROUGH_FORMSET = inlineformset_factory(
    BlfProfile,
    BlfTroughDetails,
    form=BlfTroughDetailsForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,				
    can_delete=True
)


ESTATE_TROUGH_DETAILS_ROW_FORM_SET = inlineformset_factory(
    EstateProfile,
    TroughDetailsEstate,
    form=BlfTroughDetailsForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,
    can_delete=True
)

ESTATE_TEA_PRODUCTION_FORM_SET = inlineformset_factory(
    EstateProfile,
    EstateTeaProduction,
    form=EstateProductionForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,
    can_delete=True
)

ESTATE_PRODUCTIONS_FORM_SET = inlineformset_factory(
    EstateProfile,
    EstateProductionTeaType,
    form=EstateProductionTeaTypeForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,
    can_delete=True
)









BLF_TEA_PRODUCTION_FORM_SET = inlineformset_factory(
    BlfProfile,
    BlfTeaProduction,
    form=BlfTeaProductionForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,
    can_delete=True
)


BLF_FACTORY_DETAILS_MARKS_FORM_SET = inlineformset_factory(
    BlfProfile,
    BlfFactoryDetailsMarks,
    form=BlfFactoryDetailsMarksForm,
    extra=0,
    min_num=1,
    max_num=100,
    validate_max=True,
    can_delete=True
)


class AdvisoryProfileForm(forms.ModelForm):
	""" Advisory User Profile Create Form @vivek"""

	def __init__(self, *args, **kwargs):
		user_create_pk = kwargs.pop('user_create_pk', None)
		logged_user_id = kwargs.pop('logged_user', None)
		super(AdvisoryProfileForm, self).__init__(*args, **kwargs)

		for field in self.fields.values():
			field.widget.attrs = {"class": "form-control"}

		self.fields['region'].required = True
		self.fields['organization_name'].required = True


		self.fields['name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Name"}
		self.fields['mobile_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Mobile No"}
		self.fields['region'].widget.attrs = {'class': 'form-control', 'placeholder' : "Region"}
		self.fields['state'].widget.attrs = {'class': 'form-control', 'placeholder' : "State"}
		self.fields['district'].widget.attrs = {'class': 'form-control', 'placeholder' : "District"}
		self.fields['organization_name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Organization name"}
		self.fields['expert_name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Expert name"}
			
		# self.fields['state'].queryset = State.objects.none()
		# self.fields['district'].queryset = District.objects.none()	
		self.fields['region'].queryset = Region.objects.filter(is_deleted=False)
	
		if 'state' in self.data:
			try:
				state_id = int(self.data.get('state'))
				self.fields['state'].queryset=State.objects.filter(id=state_id).order_by('name')
				state_id=State.objects.filter(id=state_id).values('id')
				
				for data in state_id:
					data=data.get('id')
					print(data)
					self.fields['district'].queryset=District.objects.filter(state_id=data).order_by('name')
			except (ValueError, TypeError):
				pass  




	class Meta:
		model = AdvisoryProfile
		fields = ('name', 'email','mobile_number', 'region', 'state', 'district',\
	      'organization_name', \
	     'expert_name',  'user_file', \
	     
	     )
		widgets = {
            'address': Textarea(attrs={'rows':80, 'cols':20}),
        }
	
class ConsigneeProfileForm(forms.ModelForm):
	""" Consignee User Profile Create Form @vivek"""

	def __init__(self, *args, **kwargs):
		user_create_pk = kwargs.pop('user_create_pk', None)
		logged_user_id = kwargs.pop('logged_user', None)
		super(ConsigneeProfileForm, self).__init__(*args, **kwargs)

		for field in self.fields.values():
			field.widget.attrs = {"class": "form-control"}

		self.fields['organization_name'].required = True
		self.fields['buyer_name'].required = False
		self.fields['mobile_number'].required = False
		self.fields['region'].required = False

		self.fields['mobile_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Mobile No"}
		self.fields['region'].widget.attrs = {'class': 'form-control', 'placeholder' : "Region"}
		self.fields['buyer_name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Buyer name"}
		self.fields['organization_name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Organization Name"}	

		self.fields['region'].queryset = Region.objects.filter(is_deleted=False)
		
	class Meta:
		model = ConsigneeProfile
		fields = ('mobile_number', 'region', 'buyer_name', 'organization_name')
		
		


class ShgCooperativeProfileForm(forms.ModelForm):
	""" SHG Cooperative User Profile Create Form @vivek"""

	def __init__(self, *args, **kwargs):
		user_create_pk = kwargs.pop('user_create_pk', None)
		logged_user_id = kwargs.pop('logged_user', None)
		super(ShgCooperativeProfileForm, self).__init__(*args, **kwargs)
		self.fields['shg_cooperative_type'].widget.attrs = {'class': 'select2_demo form-control', 'id' : 'shg_cooperative_type'}

		for field in self.fields.values():
			field.widget.attrs = {"class": "form-control"}
		self.fields['name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Name"}
		self.fields['mobile_number'].widget.attrs = {'class': 'form-control', 'placeholder' : "Mobile No"}
		# self.fields['shg_cooperative_type'].widget.attrs = {'class': 'form-control', 'placeholder' : "SHG type"}

		self.fields['region'].widget.attrs = {'class': 'form-control', 'placeholder' : "Region"}
		self.fields['state'].widget.attrs = {'class': 'form-control', 'placeholder' : "State"}
		self.fields['district'].widget.attrs = {'class': 'form-control', 'placeholder' : "District"}
		self.fields['total_no_members'].widget.attrs = {'class': 'form-control', 'placeholder' : "Total member"}
		self.fields['no_of_associated_non_member'].widget.attrs = {'class': 'form-control', 'placeholder' : "No. of associated non member"}
		self.fields['govt_registration_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Govt. registration no."}
		self.fields['trustea_id'].widget.attrs = {'class': 'form-control', 'placeholder' : "Trust tea id"}
		self.fields['address'].widget.attrs = {'class': 'form-control', 'placeholder' : "Address"}
		self.fields['region'].queryset = Region.objects.filter(is_deleted=False)	
		# self.fields['state'].queryset = State.objects.none()
		# self.fields['district'].queryset = District.objects.none()	
		
	
		if 'state' in self.data:
			try:
				state_id = int(self.data.get('state'))
				self.fields['state'].queryset=State.objects.filter(id=state_id).order_by('name')
				state_id=State.objects.filter(id=state_id).values('id')
				
				for data in state_id:
					data=data.get('id')
					print(data)
					self.fields['district'].queryset=District.objects.filter(state_id=data).order_by('name')
			except (ValueError, TypeError):
				pass  
		

	class Meta:
		model = ShgCooperativeProfile
		fields = ('name','email', 'mobile_number','shg_cooperative_type', 'region', 'state', 'district','address',\
	      'total_no_members','no_of_associated_non_member','govt_registration_no' ,'trustea_id',\
	      'user_file', \
	     
	     )
		widgets = {
            'address': Textarea(attrs={'rows':80, 'cols':20}),
        }
		



class ProfileForm(forms.ModelForm):
	""" Profile Create Form"""

	def __init__(self, *args, **kwargs):
		user_create_pk = kwargs.pop('user_create_pk', None)
		logged_user_id = kwargs.pop('logged_user', None)
		super(ProfileForm, self).__init__(*args, **kwargs)

		for field in self.fields.values():
			field.widget.attrs = {"class": "form-control"}

		self.fields['full_name'].required = True
		self.fields['trustea_id'].required = True
		self.fields['region'].required = True

		self.fields['full_name'].widget.attrs = {'class': 'form-control', 'placeholder' : "Full Name"}
		self.fields['region'].widget.attrs = {'class': 'form-control', 'placeholder' : "Region"}
		self.fields['phone_no'].widget.attrs = {'class': 'form-control', 'placeholder' : "Contact No"}
		self.fields['address'].widget.attrs = {'class': 'form-control', 'placeholder' : "Address"}	
		self.fields['state'].widget.attrs = {'class': 'form-control'}
		self.fields['district'].widget.attrs = {'class': 'form-control'}
		self.fields['email'].widget.attrs = {'class': 'form-control', 'placeholder' : "Email"}
		self.fields['region'].widget.attrs = {'class': 'form-control'}
		self.fields['trustea_id'].widget.attrs = {'class': 'form-control', 'placeholder' : "Trustea Id"}	
		self.fields['region'].queryset = Region.objects.filter(is_deleted=False)
		
	class Meta:
		model = Profile
		fields = ('full_name', 'email', 'phone_no', 'region', 'address', 'state', 'district', 'trustea_id')


class SupplyManagementForm(forms.ModelForm):
	gross_leaf = forms.DecimalField(
		min_value=0.01,
		max_digits=12,
		decimal_places=2,
		widget=forms.NumberInput(attrs={"step": "0.01", "min": "0.01"}),
	)

	class Meta:
		model = SupplyManagement
		fields = (
			'date_of_supply',
			'alloted_vehicle',
			'gross_leaf',
			'supply_bag_id',
			'driver_name',
			'mobile_number',
		)
		widgets = {
			'date_of_supply': forms.DateInput(attrs={'type': 'date'}),
		}
	def __init__(self, *args, **kwargs):
		self.request = kwargs.pop('request', None)  # handle custom kwarg
		super().__init__(*args, **kwargs)

		for field in self.fields.values():
			field.widget.attrs.update({"class": "form-control"})
		self.fields['date_of_supply'].label = "Date Of Supply"
		self.fields['gross_leaf'].label = "Quantity"
		self.fields['alloted_vehicle'].label = "Vehicle Number"
		self.fields['mobile_number'].label = "Mobile Number"
		self.fields['date_of_supply'].required = True
		self.fields['gross_leaf'].required = True
		self.fields['alloted_vehicle'].required = True
		self.fields['mobile_number'].required = True
		self.fields['mobile_number'].widget.attrs.update({
			"type": "tel",
			"maxlength": "10",
			"inputmode": "numeric",
			"pattern": "[6-9][0-9]{9}",
			"data-mobile-error": "mobile-number-validation-error",
			"data-mobile-short-error": "true",
			"placeholder": "Mobile Number",
		})
		selected_vehicle_id = self.data.get("alloted_vehicle") if self.data else self.initial.get("alloted_vehicle")
		self.fields['alloted_vehicle'].queryset = (
			VehicleManagement.cmobjects.filter(pk=selected_vehicle_id)
			if selected_vehicle_id
			else VehicleManagement.cmobjects.none()
		)

	def clean_mobile_number(self):
		mobile_number = re.sub(r"\D", "", self.cleaned_data.get("mobile_number") or "")
		if not re.fullmatch(r"[6-9]\d{9}", mobile_number) or re.fullmatch(r"(\d)\1{9}", mobile_number):
			raise ValidationError("Enter a valid 10 digit mobile number starting with 6, 7, 8, or 9. Repeated digits are not allowed.")
		return mobile_number

	def clean(self):
		cleaned_data = super().clean()
		if not cleaned_data.get("date_of_supply"):
			self.add_error("date_of_supply", "Select date of supply.")
		if not cleaned_data.get("gross_leaf"):
			self.add_error("gross_leaf", "Enter quantity.")
		return cleaned_data
