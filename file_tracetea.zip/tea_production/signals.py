from django.db.models.signals import pre_save
from django.dispatch import receiver
from rest_framework.exceptions import APIException

from .models import TeaGradeDetails


DUPLICATE_TEA_GRADE_MESSAGE = "This tea type and grade combination already exists."


@receiver(pre_save, sender=TeaGradeDetails)
def validate_unique_tea_grade(sender, instance, **kwargs):
    if instance.is_deleted or not instance.tea_type_id or not instance.grade:
        return

    qs = TeaGradeDetails.objects.filter(
        tea_type_id=instance.tea_type_id,
        grade__iexact=instance.grade.strip(),
        is_deleted=False,
    )
    if instance.pk:
        qs = qs.exclude(pk=instance.pk)
    if qs.exists():
        raise APIException(DUPLICATE_TEA_GRADE_MESSAGE)
