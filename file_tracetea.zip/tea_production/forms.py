"""
Forms
"""
from django import forms
from django.db.models import Q
from django.core.exceptions import ValidationError
from django.forms import inlineformset_factory
from django.forms import ModelForm, Textarea

from .models import *


class DateInput(forms.DateInput):
    """
    Widgets support for date input
    """
    input_type = 'date'


from django import forms
from django.core.exceptions import ValidationError
from .models import TeaGradeDetails, TeaType

class TeaGradeForm(forms.ModelForm):
    """
    Tea Grade Form
    """
    class Meta:
        model = TeaGradeDetails
        fields = ('tea_type', 'grade')

    def __init__(self, *args, **kwargs):
        super(TeaGradeForm, self).__init__(*args, **kwargs)

        self.fields['tea_type'].required = True
        self.fields['grade'].required = True
        self.fields['tea_type'].queryset = TeaType.objects.filter(is_deleted=False).order_by('name')

        self.fields['tea_type'].widget.attrs = {
            'class': 'select2_demo_1 form-control', 'id': 'grade_id'
        }
        self.fields['grade'].widget.attrs = {
            'class': 'form-control', 'placeholder': 'Tea Grade',
        }

    # ✅ VALIDATION HERE
    def clean(self):
        cleaned_data = super().clean()
        tea_type = cleaned_data.get('tea_type')
        grade = cleaned_data.get('grade')

        if tea_type and grade:
            qs = TeaGradeDetails.objects.filter(
                tea_type=tea_type,
                grade__iexact=grade,
                is_deleted=False
            )

            # Exclude current instance (for update)
            if self.instance and self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)

            if qs.exists():
                raise ValidationError("This tea type and grade combination already exists.")

        return cleaned_data
        
