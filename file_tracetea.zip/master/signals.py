from django.db.models.signals import pre_save
from django.dispatch import receiver
from rest_framework.exceptions import APIException

from .models import Region


DUPLICATE_REGION_MESSAGE = "This region name already exists. Please choose a different name."


@receiver(pre_save, sender=Region)
def region_data_validation(sender, instance, **kwargs):
    if instance.is_deleted or not instance.region_name:
        return

    qs = Region.objects.filter(
        region_name__iexact=instance.region_name.strip(),
        is_deleted=False,
    )
    if instance.pk:
        qs = qs.exclude(pk=instance.pk)
    if qs.exists():
        raise APIException(DUPLICATE_REGION_MESSAGE)
