
from django.db.models.signals import pre_save
from django.dispatch import receiver
from rest_framework.exceptions import APIException
from .models import UseOfChemical
from user_profile.aggregator_api_models import Labour


DUPLICATE_CHEMICAL_MESSAGE = "This chemical has already been recorded for the selected Date, Labour, and Plot"
DUPLICATE_LABOUR_MESSAGE = "This labour data already exists for the selected profile."


@receiver(pre_save, sender=UseOfChemical)
def chemical_data_validation(sender, instance, **kwargs):
    if all([instance.created_by_id, instance.date, instance.chemical_id, instance.labour_id, instance.plot_id]):
        qs = UseOfChemical.cmobjects.filter(
            date=instance.date,
            chemical_id=instance.chemical_id,
            labour_id=instance.labour_id,
            plot_id=instance.plot_id,
            created_by_id=instance.created_by_id,
        )
        if instance.pk:
            qs = qs.exclude(pk=instance.pk)
        if qs.exists():
            raise APIException(DUPLICATE_CHEMICAL_MESSAGE)


@receiver(pre_save, sender=Labour)
def labour_data_validation(sender, instance, **kwargs):
    if instance.is_deleted or not instance.name:
        return

    owner_filter = {}
    if instance.grower_id:
        owner_filter["grower_id"] = instance.grower_id
    elif instance.aggregator_id:
        owner_filter["aggregator_id"] = instance.aggregator_id
    elif instance.blf_id:
        owner_filter["blf_id"] = instance.blf_id
    else:
        return

    qs = Labour.cmobjects.filter(
        name__iexact=instance.name.strip(),
        **owner_filter,
    )
    if instance.pk:
        qs = qs.exclude(pk=instance.pk)
    if qs.exists():
        raise APIException(DUPLICATE_LABOUR_MESSAGE)

