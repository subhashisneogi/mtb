from django.contrib import messages
from django.http import HttpResponseForbidden
from django.shortcuts import redirect
from django.urls import reverse

from user_profile.permissions import has_menu_permission, is_super_admin, permission_for_url_name


class UserMenuPermissionMiddleware:
    """
    Enforces configured menu/action permissions from URL names.
    Super admins bypass all checks; unmapped URLs keep their existing behavior.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        return self.get_response(request)

    def process_view(self, request, view_func, view_args, view_kwargs):
        resolver_match = getattr(request, "resolver_match", None)
        user = getattr(request, "user", None)
        if resolver_match and user and user.is_authenticated and not is_super_admin(user):
            permission = self._permission_for_request(request, resolver_match.url_name)
            if permission:
                menu_key, action = permission
                if not has_menu_permission(user, menu_key, action):
                    if resolver_match.url_name == "index":
                        return HttpResponseForbidden("You have no permission to access the requested resource!")
                    messages.error(request, "You have no permission to access the requested resource!")
                    return redirect(reverse("index"))
        return None

    def _permission_for_request(self, request, url_name):
        mode = request.GET.get("mode", "").strip()
        if url_name in (
            "farmdiary_user_list",
            "chemical_type_list",
            "chemical_view_list",
            "farm_diary_record_detail",
            "plucking_data_view_list",
            "farmdiary_labour_list",
            "farmdiary_monthly_shedule_list",
            "farmers_aggreements_forms_list",
        ) and mode == "report":
            return ("farm_diary_report", "view")
        if url_name == "supply_management_report" and mode != "manage":
            return ("supply_report", "view")
        if url_name in ("challan_process_records", "challan_process_list") and mode == "report":
            return ("challan_history_report", "view")
        return permission_for_url_name(url_name)
